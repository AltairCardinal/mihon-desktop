"""Final round regressions (written before the fixes).

Boundary 1 - close drain end point.  Confirmed counterexample: q=1, service=4;
prefetch@0 -> close@1 -> probe@2 -> the cancelled task really exits @4.  The R9/LC
runner logged close_end at t=2 with occupied=1 (it declared the drain finished as soon
as it met an ordinary external event).  Required: request / logical close / physical
drain are separate, timed events; the cancelled task keeps its slot until its real exit;
no result is admitted and no work is restarted after close; nothing is faked by clearing
the task table; repeated close and probes during closing are handled; resources are
released only after the drain.

Boundary 2 - zero-time proofs.  Attempt identity = due time is only unique for q_u > 0 on
one serial proof lane; with q_u = 0 an old-epoch proof event was delivered as the current
attempt and the current attempt was dropped (results/raw/final/q0_repro_before_fix.jsonl).
Decision: option A -- the shadow runners reject q_u <= 0 at construction.
"""
import sys
import unittest
from copy import deepcopy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import fixLC_shadow as LS  # noqa: E402
import fix_main_shadow as FS  # noqa: E402
import wpA_lib as A  # noqa: E402


def close_trace(extra=()):
    tr = LS.fixture_trace()
    ev = [dict(at=0, op='prefetch', item=3), dict(at=1, op='close'), dict(at=2, op='probe_after_close', target=12)]
    ev += list(extra)
    return dict(tr, events=sorted(ev, key=lambda e: e['at']))


def runners():
    return [('lc', LS.LifeShadowRunner), ('mainfix', FS.life_fixed_runner_class())]


class CloseDrain(unittest.TestCase):
    def _run(self, cls, bound, extra=()):
        r = cls(close_trace(extra), policy='gated_shadow', service_u=4, q_u=1, bound=bound)
        return r, r.run_life()

    def test_drain_ends_only_at_real_exit(self):
        for name, cls in runners():
            for bound in (False, True):
                r, rows = self._run(cls, bound)
                ops = [x['op'] for x in rows]
                self.assertIn('close_requested', ops, name)
                self.assertIn('close_logical', ops, name)
                end = [x for x in rows if x['op'] == 'close_end']
                self.assertEqual(len(end), 1, (name, ops))
                self.assertEqual(end[0]['t'], 4, (name, 'drain completes at the real exit'))
                self.assertEqual(end[0]['ret']['occupied'], 0, name)
                self.assertEqual((end[0]['ret']['raw'], end[0]['ret']['certs']), (0, 0), name)
                self.assertEqual(end[0]['residency'], 0, name)
                times = end[0]['ret']['times']
                self.assertEqual((times['requested'], times['logical'], times['drained']), (1, 1, 4), name)

    def test_slot_held_until_exit_and_probe_rejected(self):
        for name, cls in runners():
            r, rows = self._run(cls, True)
            probe = [x for x in rows if x['op'] == 'probe_after_close'][0]
            self.assertEqual(probe['t'], 2, name)
            self.assertEqual(probe['occupied'], 1, (name, 'cancelled task still holds its slot'))
            self.assertNotEqual(probe['ret']['certify'], 'accepted', name)
            self.assertNotEqual(probe['ret']['publish'], 'published', name)
            self.assertNotEqual(probe['ret']['confirm'], 'confirmed', name)
            ex = [x for x in rows if x['op'] == 'exit_after_close']
            self.assertEqual([x['t'] for x in ex], [4], name)
            self.assertEqual(ex[0]['ret'], 'discarded', (name, 'late completion never admitted'))
            self.assertEqual(ex[0]['occupied'], 0, name)

    def test_repeated_close_and_no_restart(self):
        for name, cls in runners():
            extra = [dict(at=3, op='close'), dict(at=3, op='prefetch', item=5), dict(at=6, op='close'),
                     dict(at=7, op='target', target=19), dict(at=8, op='probe_after_close', target=12)]
            r, rows = self._run(cls, True, extra)
            rep = [x for x in rows if x['op'] == 'close_repeat']
            self.assertEqual([x['ret'] for x in rep], ['already_closing', 'already_closed'], name)
            admissions_at_request = [x for x in rows if x['op'] == 'close_requested'][0]['ret']['physical_admissions']
            self.assertEqual(r.session.metrics['physical_admissions'], admissions_at_request, (name, 'no work restarted'))
            ign = [x for x in rows if x['op'] == 'event_after_close_ignored']
            self.assertEqual(sorted(x['args']['op'] for x in ign), ['prefetch', 'target'], name)
            last = [x for x in rows if x['op'] == 'probe_after_close'][-1]
            self.assertEqual(last['occupied'], 0, name)
            self.assertEqual(len([x for x in rows if x['op'] == 'close_end']), 1, name)

    def test_task_table_not_faked(self):
        # the drain must come from finish(): physical finishes counted, discarded completions counted
        for name, cls in runners():
            r, rows = self._run(cls, True)
            m = r.session.metrics
            self.assertEqual(m['physical_finishes'], m['physical_admissions'], name)
            self.assertGreaterEqual(m['discarded_completions'], 1, name)

    def test_existing_lifecycle_scripts_still_pass(self):
        cls = FS.life_fixed_runner_class()
        for var in ('touched', 'untouched'):
            r, rows = LS.run_shadow(variant=var, bound=True, rebind_item=13, runner_cls=cls)
            fails = [(c['group'], c['name']) for c in LS.evaluate(r, rows, var) if not c['ok']]
            self.assertEqual(fails, [], var)


class ZeroTimeProofs(unittest.TestCase):
    def test_shadow_runners_reject_nonpositive_q(self):
        tr = A.reserved_eviction(0, n=40)
        for q in (0, -1):
            with self.assertRaises(ValueError):
                FS.FixedShadowRunner(tr, policy='gated_shadow', service_u=4, q_u=q)
            with self.assertRaises(ValueError):
                FS.life_fixed_runner_class()(tr, policy='gated_shadow', service_u=4, q_u=q, bound=True)

    def test_positive_q_same_instant_double_rebind_keeps_current_attempt(self):
        tr = A.reserved_eviction(0, n=40)
        w20 = deepcopy(tr['world'][20])
        tr = dict(tr, events=[dict(at=0, op='target', target=8), dict(at=0, op='rebind', item=20, witness=deepcopy(w20)),
                              dict(at=0, op='rebind', item=20, witness=deepcopy(w20))])
        for q in (1, 2):
            r = FS.life_fixed_runner_class()(tr, policy='gated_shadow', service_u=4, q_u=q, bound=True)
            rows = r.run_life()
            dropped = [x for x in rows if x['op'] == 'proof_stale_attempt_dropped']
            delivered = [x for x in rows if x['op'] == 'proof_delivered']
            self.assertEqual(len(dropped), 2, q)
            self.assertEqual(len(delivered), 1, q)
            self.assertTrue(all(d['args']['due'] < delivered[0]['t'] for d in dropped), q)
            self.assertEqual(r.wrong, 0, q)

    def test_incumbent_unaffected(self):
        tr = A.reserved_eviction(0, n=40)
        FS.FixedIncumbentRunner(tr, service_u=4, q_u=0)        # never schedules proofs


if __name__ == '__main__':
    unittest.main()
