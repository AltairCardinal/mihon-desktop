"""Fix round: rebuild the revised deliverable tables from R9 tables + fix-round fragments + D3 index.

Never destroys R9 records: on first run copies REPORT.md, coverage.csv, ADOPTION_MATRIX.csv,
NEXT_IMPLEMENTER.md, hypotheses.csv to *_R9.* (read-only history), then writes revised
coverage.csv, hypotheses.csv, ADOPTION_MATRIX.csv and results/summary/fix/COUNTS.json.
REPORT.md / NEXT_IMPLEMENTER.md are written by hand (main session).

Question depth rule (fix round):
  claimed = depth from the fix fragment for that question if any, else the R9 row
            ('D3 候选（待正式计时）' counts as claimed D3)
  if claimed >= D3: the question must be served by a registered mechanism in D3_INDEX.csv;
      achieved = max depth of those mechanisms; final = min(claimed, achieved)
      (LC rows claimed only the lifecycle part: final = achieved)
  no registered mechanism -> D2.
"""
import csv, json, shutil
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
ORDER = {'D1': 1, 'D2': 2, 'D3': 3, 'D4': 4}

for name in ('REPORT.md', 'coverage.csv', 'ADOPTION_MATRIX.csv', 'NEXT_IMPLEMENTER.md', 'hypotheses.csv'):
    src = OUT / name
    dst = OUT / (name.replace('.', '_R9.', 1))
    if not dst.exists():
        shutil.copy2(src, dst)


def rd(p):
    with open(OUT / p, newline='') as fh:
        return list(csv.DictReader(fh))


cov = rd('coverage_R9.csv')
cols = list(cov[0].keys())
frag = {}
for f in ('fix_LC', 'fix_Q1', 'fix_Q2', 'fix_PH'):
    for r in rd(f'coverage_parts/{f}.csv'):
        frag.setdefault(r['question_id'], []).append((f, r))
# main-session overrides: questions whose fork fragment was capped only for lack of formal timing (now timed),
# or whose decision was superseded by main-session work after the forks finished
MAIN = {
    'A01': dict(decision='adopt only the lifecycle-complete runner (F1 attempt identity, F2 re-intent with physical mirroring) '
                         'with bound confirmation; physical work unchanged (S1, 352 held-out cells); virtual latency -0.5..-2.7% '
                         'held-out (dev grid -8.5%); R9 runner downgraded; "gain iff q<service" refuted on held-out'),
    'A02': dict(decision='rule gate kept with the fixed runner (same evidence as A01); adaptive gates rejected'),
    'P03': dict(decision='do not adopt the persistent tree as default: dominated by the fresh exact route on the A grid '
                         '(13 433 vs 1 895 evaluations, 96 vs 33 ms strong compute); R9 "3-13x" withdrawn (0 evaluations recorded pre-fix)'),
    'B01': dict(decision='tables default for block summaries (one mechanism: core + session wiring); not in the priority list; '
                         'ZDD conditional (compacted smaller in 40/45 cells; formal wall 1.125x of tables)'),
    'X05': dict(claim='D3', decision='organisation 1 (shared graph carrying support, AB1) conditional; organisation 2 dropped; '
                                     'formal 0.613 vs group 0; held-out HO-6 AB1<=AB2 on 24/24 streams'),
    'T04': dict(claim='D3', decision='keep both routes (route 2 proof-carrying certificate for cross-trust hand-off, route 1 '
                                     're-derivation checker); route 1 must add a domain-legality check (62 accepted G0 domain mislabels)'),
    'O01': dict(decision='independent certification; a shared persistent tree is dominated by fresh exact (see P03)'),
    'A06': dict(decision='safe fallback = the shadow form itself: proof failure or budget stop has no physical effect and the L0 '
                         'path continues (BC-2 stop issues nothing); the R9 recommendation of the persistent tree is withdrawn'),
    'X21': dict(decision='combination not adopted: its A arm (shared persistent tree) is dominated by the fresh exact route; '
                         'per-publication revalidation stays required'),
    'K01': dict(decision='specification alignment (model-fidelity correction to NATIVE_OWNER.pseudo order), not a candidate '
                         'and not a gain; full-configuration cost with bound confirmation not measured'),
}
idx = rd('results/summary/fix/D3_INDEX.csv')
qmech = {}
for m in idx:
    for q in [x.strip() for x in m['questions'].replace('，', ',').split(',') if x.strip()]:
        q = q.split('(')[0]
        qmech.setdefault(q, []).append(m)


def norm(d):
    d = (d or '').strip()
    return 'D3' if d.startswith('D3') else (d if d in ORDER else 'D2')


PH_NH = {r['nh']: r for r in rd('hypotheses_parts/fix_PH.csv')}
QDEPTH = {}
out = []
for r in sorted(cov, key=lambda r: r['question_id'].startswith('NH')):   # questions first, so NH rows can read their depth
    q = r['question_id']
    row = dict(r)
    src = 'R9'
    claimed = norm(r['depth'])
    lc_d3 = False
    for f, fr in frag.get(q, []):
        if f == 'fix_LC':                       # lifecycle-only fragment: keep the row, update decision/note
            row['decision'] = fr['decision']
            row['proof_or_counterexample'] = (row['proof_or_counterexample'] + ' | fix LC: ' + fr['proof_or_counterexample'])[:900]
            lc_d3 = ORDER[norm(fr.get('depth'))] >= 3
            src = src if src != 'R9' else 'fix_LC'
        else:                                   # re-done question: its fragment replaces the row and the claim
            for k in cols:
                if k in fr and fr[k] != '':
                    row[k] = fr[k]
            claimed = norm(fr.get('depth'))
            src = f
    if lc_d3:
        claimed = 'D4' if src == 'fix_LC' else max(claimed, 'D4', key=lambda d: ORDER[d])
    if q in MAIN:
        row['decision'] = MAIN[q].get('decision', row['decision'])
        if 'claim' in MAIN[q]:
            claimed = max(claimed, MAIN[q]['claim'], key=lambda d: ORDER[d])
        src += '+main'
    mechs = qmech.get(q, [])
    note = []
    if ORDER[claimed] >= 3 and not q.startswith('NH'):
        if not mechs:
            final = 'D2'
            note.append('no registered formally timed mechanism in results/summary/fix/D3_INDEX.csv -> D2')
        else:
            achieved = max((m['depth'] for m in mechs), key=lambda d: ORDER[d])
            final = min(claimed, achieved, key=lambda d: ORDER[d])
            note.append('mechanisms ' + ','.join(f"{m['mechanism_id']}={m['depth']}" + (f"(missing {m['missing_for_D3']})" if m['missing_for_D3'] else '')
                                                for m in mechs))
    else:
        final = claimed
    if q.startswith('NH'):
        ph_row = PH_NH.get(q)
        rel = [x.strip() for x in (ph_row or {}).get('related_questions', '').replace('/', ',').split(',') if x.strip()]
        rel_depths = [QDEPTH[x] for x in rel if x in QDEPTH]
        cap = max(rel_depths, key=lambda d: ORDER[d]) if rel_depths else 'D2'
        final = min(norm(r['depth']), cap, key=lambda d: ORDER[d])
        note.append(f"new-hypothesis row reclassified {ph_row and ph_row.get('reclassification')} of {','.join(rel) or '?'}; "
                    f"depth capped by the related question(s) ({cap})")
    row['depth'] = final
    if not q.startswith('NH'):
        QDEPTH[q] = final
    row['audit_note'] = ('fix round: source=' + src + '; claimed ' + claimed + ' -> ' + final + '; ' + '; '.join(note)
                         + (' || R9: ' + r.get('audit_note', '') if r.get('audit_note') else ''))[:1200]
    out.append(row)
with open(OUT / 'coverage.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader(); w.writerows(out)

# hypotheses: R9 columns + PH reclassification
hyp = rd('hypotheses_R9.csv')
ph = {r['nh']: r for r in rd('hypotheses_parts/fix_PH.csv')}
hcols = list(hyp[0].keys()) + ['fix_reclassification', 'fix_related_questions', 'fix_reason', 'fix_counts_as_new_direction']
for h in hyp:
    p = ph.get(h['nh'], {})
    h['fix_reclassification'] = p.get('reclassification', '')
    h['fix_related_questions'] = p.get('related_questions', '')
    h['fix_reason'] = p.get('reason', '')
    h['fix_counts_as_new_direction'] = p.get('counts_as_new_direction', '')
with open(OUT / 'hypotheses.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=hcols)
    w.writeheader(); w.writerows(hyp)

# adoption matrix: R9 rows (decision corrected where the fix round changed it) + fix rows
am = rd('ADOPTION_MATRIX_R9.csv')
acols = list(am[0].keys()) + ['fix_class', 'fix_note']
CLASS = json.loads((OUT / 'results/summary/fix/adoption_classes.json').read_text())
for r in am:
    c = CLASS.get(r['candidate'], {})
    r['fix_class'] = c.get('class', '')
    r['fix_note'] = c.get('note', '')
    if c.get('decision'):
        r['decision'] = c['decision']
extra = []
for f in ('fix_LC', 'fix_Q1', 'fix_main'):
    p = OUT / f'adoption_parts/{f}.csv'
    if p.exists():
        for r in rd(f'adoption_parts/{f}.csv'):
            row = {k: '' for k in acols}
            for k, v in r.items():
                kk = 'route' if k.startswith('route') else k
                if kk in row:
                    row[kk] = v
            row['work_package'] = f
            if not row['fix_class']:
                row['fix_class'] = r.get('class', '') or r.get('fix_class', '')
            extra.append(row)
with open(OUT / 'ADOPTION_MATRIX_detail.csv', 'w', newline='') as fh:     # history + fragments; current = ADOPTION_MATRIX.csv
    w = csv.DictWriter(fh, fieldnames=acols, extrasaction='ignore')
    w.writeheader(); w.writerows(am + extra)

counts = dict(questions=sum(1 for r in out if not r['question_id'].startswith('NH')),
              question_depth={d: sum(1 for r in out if not r['question_id'].startswith('NH') and r['depth'] == d) for d in ('D2', 'D3', 'D4')},
              status={s: sum(1 for r in out if not r['question_id'].startswith('NH') and r['status'] == s)
                      for s in sorted({r['status'] for r in out})},
              mechanisms=json.loads((OUT / 'results/summary/fix/D3_COUNTS.json').read_text()),
              hypotheses=dict(total=len(hyp), **{k: sum(1 for h in hyp if h['fix_reclassification'] == k) for k in ('duplicate', 'refinement', 'new')}),
              adoption_rows=len(am) + len(extra))
(OUT / 'results/summary/fix/COUNTS.json').write_text(json.dumps(counts, indent=1, ensure_ascii=False))
print(json.dumps(counts, indent=1, ensure_ascii=False))
