"""Final round, boundary 2: zero-time proofs.  Trigger (user-confirmed): reserved_eviction(seed 0, n 40),
target 8 at t=0, item 20 rebound twice at the same instant, q_u=0, service_u=4.
Runs the lifecycle-logging fixed shadow runner with the q>0 guard bypassed (unsupported domain) and
writes every event row to results/raw/final/q0_repro_<label>.jsonl plus a short verdict."""
import json, sys
from copy import deepcopy
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import wpA_lib as A
import fix_main_shadow as FS


def trace():
    tr = A.reserved_eviction(0, n=40)
    w20 = deepcopy(tr['world'][20])
    ev = [dict(at=0, op='target', target=8),
          dict(at=0, op='rebind', item=20, witness=deepcopy(w20)),
          dict(at=0, op='rebind', item=20, witness=deepcopy(w20)),
          dict(at=40, op='probe_after_close', target=8)]
    return dict(tr, events=ev)


def run(label, q_u=0):
    cls = FS.life_fixed_runner_class()
    cls._unsupported_zero_q = True            # bypass the q>0 guard (demonstration of the rejected domain)
    try:
        r = cls(trace(), policy='gated_shadow', service_u=4, q_u=q_u, bound=True)
        rows = r.run_life()
    finally:
        cls._unsupported_zero_q = False
    ops = [(x['t'], x['op'], x.get('args'), x.get('ret')) for x in rows]
    starts = [x for x in rows if x['op'] in ('proof_delivered', 'proof_stale_attempt_dropped', 'proof_dropped')]
    path = OUT / f'results/raw/final/q0_repro_{label}.jsonl'
    with open(path, 'w') as fh:
        for x in rows:
            fh.write(json.dumps(x, default=str) + '\n')
    verdict = dict(label=label, q_u=q_u, proof_events=[(x['t'], x['op'], x['args'], x.get('ret')) for x in starts],
                   first_pub=r.first_pub, rebinds=r.rebinds, wrong=r.wrong,
                   stale_delivered=sum(1 for x in starts if x['op'] == 'proof_delivered' and x['args'].get('status') == 'certified'
                                       and x['t'] == 0 and r.rebinds > 0))
    print(json.dumps(verdict, default=str))
    return verdict


def guard():
    try:
        FS.life_fixed_runner_class()(trace(), policy='gated_shadow', service_u=4, q_u=0, bound=True)
        return 'accepted (no guard)'
    except ValueError as e:
        return 'rejected: ' + str(e)


if __name__ == '__main__':
    print('construction with q_u=0:', guard())
    out = [dict(construction_q0=guard())] + [run(sys.argv[1] if len(sys.argv) > 1 else 'run', 0), run((sys.argv[1] if len(sys.argv) > 1 else 'run') + '_q1', 1)]
    (OUT / f'results/raw/final/q0_repro_{sys.argv[1] if len(sys.argv) > 1 else "run"}_verdict.json').write_text(json.dumps(out, indent=1, default=str))
