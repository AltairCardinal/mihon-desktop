"""Fix round, item 4: per-mechanism D3/D4 evidence index (one row per independent mechanism).

Inputs (all produced by committed scripts):
  results/summary/formal/<module>.json          R9 formal timing (3 serial processes)  -- reused only if unaffected
  results/summary/formal_fix/<module>.json      fix-round formal timing (3 serial processes)
  results/raw/fix/costprobe/<module>.jsonl      tracemalloc peak / retained / live blocks per cell
  results/raw/fix/main/costs_postfreeze.json    LC session-level costs re-measured after freeze (entries, close)
  results/summary/fix/LC/d4_verdicts.json + results/raw/fix/main/*lifecycle*.json + heldout ho2
Output: results/summary/fix/D3_INDEX.csv, D3_INDEX.md, D3_COUNTS.json

D3 rule (all required; a missing item caps the mechanism at D2 and is listed):
  B  correct strong baseline formally timed in the same run (paired ratios)
  A  key ablation present (timed or counted, with pointer)
  P  three serial independent measurement processes (distinct PIDs, process_index 0..2)
  T  absolute wall time (median ms of candidate and baseline)
  M  maintenance cost (counter with pointer)
  R  extra residency in structure entries (measured)
  K  peak bytes (tracemalloc) of candidate and baseline
  X  exit release (retained bytes after the run / after close, entries after close)
  S  sensitivity (parameter grid with pointer)
  W  worst degradation (max paired ratio + worst virtual/work metric)
D4 rule: D3 + LC lifecycle groups all pass (with bound confirmation) + frozen held-out (HO-1/HO-2) pass.
Layers are kept separate: entries (structure), bytes (tracemalloc, Python objects), u (virtual), ms (wall).
"""
import csv, json, statistics
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
S = OUT / 'results/summary'


def jload(p):
    p = OUT / p
    return json.loads(p.read_text()) if p.exists() else None


FORMAL = {}
for src, d in (('R9', 'results/summary/formal'), ('fix', 'results/summary/formal_fix'), ('final', 'results/summary/formal_final')):
    for p in sorted((OUT / d).glob('bench_*.json')):
        FORMAL[(src, p.stem)] = json.loads(p.read_text())
RAWPIDS = {}
for src, d in (('R9', 'results/raw/formal'), ('fix', 'results/raw/formal_fix'), ('final', 'results/raw/formal_final')):
    for p in sorted((OUT / d).glob('bench_*.jsonl')):
        pids, procs = set(), set()
        for line in p.read_text().splitlines():
            r = json.loads(line)
            if r.get('pid'):
                pids.add(r['pid']); procs.add(r.get('process_index'))
        RAWPIDS[(src, p.stem)] = (len(pids), sorted(x for x in procs if x is not None))
PROBE = {}
for p in sorted((OUT / 'results/raw/fix/costprobe').glob('*.jsonl')) if (OUT / 'results/raw/fix/costprobe').exists() else []:
    for line in p.read_text().splitlines():
        r = json.loads(line)
        PROBE.setdefault((r['module'], r['candidate']), []).append(r)
def _lc_summary(raw):
    out = {}
    for r in raw:
        rows = r['rows']
        out[r['mechanism']] = dict(mechanism=r['mechanism'], residency_peak=[x['residency_peak'] for x in rows],
                                   residency_after_close=[x['residency_after_close'] for x in rows],
                                   traced_peak_max=max(x['traced_peak'] for x in rows),
                                   retained_after_close_max=max(x['retained_after_close'] for x in rows),
                                   positive_delta_sum_total=sum(x['positive_delta_sum'] for x in rows),
                                   certification_steps=sum(x['certification_steps'] for x in rows),
                                   strong_evaluations=sum(x['strong_evaluations'] for x in rows),
                                   publication_read_checks=sum(x['publication_read_checks'] for x in rows),
                                   all_published_truthful=all(x['all_published_truthful'] for x in rows))
    return out


_pf = jload('results/raw/fix/main/costs_postfreeze.json')
LCCOST = _lc_summary(_pf) if _pf else {r['mechanism']: r for r in (jload('results/summary/fix/LC/costs.json') or [])}
LCCOST_SRC = 'results/raw/fix/main/costs_postfreeze.json' if _pf else 'results/summary/fix/LC/costs.json (pre-freeze)'
LCV = jload('results/summary/fix/LC/d4_verdicts.json') or {}
HO2 = (jload('results/summary/fix/heldout/ho2.json') or {}).get('per_mechanism', {})
HO1 = jload('results/summary/fix/heldout/ho1.json') or {}


def formal(src, module, cand, scen_filter=None):
    f = FORMAL.get((src, module))
    if f is None:
        return None
    cells = [c for c in f['cells'] if c['candidate'] == cand and (scen_filter is None or scen_filter in c['scenario'])]
    if not cells:
        return None
    incs = {c['scenario']: c for c in f['cells'] if c['candidate'] == cells[0]['incumbent']}
    rat = [c['ratio']['median'] for c in cells if c['ratio']]
    mn = [c['ratio']['min'] for c in cells if c['ratio']]
    mx = [c['ratio']['max'] for c in cells if c['ratio']]
    abs_c = [c['wall_ms_median'] for c in cells if c['wall_ms_median'] is not None]
    abs_i = [incs[c['scenario']]['wall_ms_median'] for c in cells if c['scenario'] in incs and incs[c['scenario']]['wall_ms_median'] is not None]
    npid, procs = RAWPIDS.get((src, module), (0, []))
    return dict(src=src, module=module, candidate=cand, incumbent=cells[0]['incumbent'], scenarios=len(cells),
                ratio_median=round(statistics.median(rat), 3) if rat else None,
                ratio_min=min(mn) if mn else None, ratio_max=max(mx) if mx else None,
                wall_ms_candidate=round(statistics.median(abs_c), 3) if abs_c else None,
                wall_ms_incumbent=round(statistics.median(abs_i), 3) if abs_i else None,
                processes=procs, pids=npid, not_ok=sum(c['not_ok_rows'] for c in cells))


def probe(module, cand):
    rows = [r for r in PROBE.get((module, cand), []) if 'error' not in r]
    if not rows:
        return None
    return dict(cells=len(rows), peak_bytes_median=int(statistics.median(r['peak_bytes'] for r in rows)),
                peak_bytes_max=max(r['peak_bytes'] for r in rows),
                retained_bytes_max=max(r['retained_bytes'] for r in rows),
                structure=[r['structure'] for r in rows if r.get('structure')][:3])


# --------------------------------------------------------------------------- registry
# formal: list of (src, module, candidate, scenario filter); the first entry is the primary timing.
# baseline: (src, module, candidate) of the correct strong baseline (paired in the same run) or None.
M = []


def mech(mid, name, qs, layer, formal_cells, baseline, ablation, maint, resid, sens, worst, lc=None, decision='',
         affected='', notes='', resid_ptr=None):
    M.append(dict(mid=mid, name=name, questions=qs, layer=layer, formal=formal_cells, baseline=baseline,
                  ablation=ablation, maintenance=maint, residency=resid, sensitivity=sens, worst=worst, lc=lc,
                  decision=decision, affected=affected, notes=notes, resid_ptr=resid_ptr))


# final round: D4 requires correctness AND cost in the same full configuration (bound confirmation included)
COST_SCOPE_INCOMPLETE = {      # timed cells cover only part of the mechanism's cost
    'M39': 'only the checker kernel is timed; certificate construction and maintenance are not',
}

FULL_CONFIG = {
    'M01': 'bench_final gated_shadow_fixed_bound (tree route) vs incumbent_fixed_bound; correctness: LC runner scripts with bound, HO-1',
    'M31': 'bench_final inc_revoke_bound vs package_bound; correctness: LC groups with bound, HO-2/HO-3',
    'M32': 'bound confirmation is itself the configuration (R9 bench_wpH + bench_fixLC bound_confirm); correctness HO-2',
}

RESID_PTR = {   # measured residency for cells whose formal work dict does not expose it
    'M06': 'results/raw/fix/main/residency_d04.json: INTERVAL memo entries/support keys = corrected owner, 0 extra fields',
    'M07': 'results/raw/fix/main/residency_d04.json: SIG memo entries/support keys = corrected owner, 0 extra fields',
    'M19': 'formal work counter normalize_calls = prefix-cache elements per batch (cache dropped per batch)',
    'M01': 'results/raw/fix/main/residency_misc.json#A_policies: policy structures peak 27 (median 2) vs incumbent 8; mirror released at close (postfreeze change)',
    'M42': 'results/raw/fix/main/residency_misc.json#A_policies race_keep: peak 22 (median 1), end 13',
    'M43': 'results/raw/fix/main/residency_misc.json#A_policies race_cancel: peak 27 (median 2), end 13',
    'M44': 'results/raw/fix/main/residency_misc.json#A_policies adaptive: peak 27 (median 2), end 13',
    'M45': 'results/raw/fix/main/residency_misc.json#A_policies ski: peak 19 (median 3), end 11',
    'M46': 'results/raw/fix/main/residency_misc.json#A_policies gated_proof_first: peak 23 (median 2), end 10',
    'M16': 'results/raw/fix/main/residency_misc.json#rope: n+n/32 entries (1 056 at n=1024) vs rebuild 0',
    'M26': 'results/raw/fix/main/residency_misc.json#posrev: n ints + 15-23 positions per 4 memo entries',
    'M08': 'results/raw/fix/main/residency_misc.json#bitset: memo entries equal to symbolic (420 on G0)',
    'M39': 'results/raw/fix/Q2/t04.json#size: certificate elements/assignment entries (bytes median 218, max 24 KB)',
}


A_SENS = 'A grid: service 2-8 u x q 1-9 u x capacity 1-3 (results/raw/wpA/grid_*.jsonl; adoption boundary q<service 28/28 dev cells) + held-out HO-1 4 (service,q) cells'
mech('M01', 'gated_shadow（修复版运行器 F1/F2）', 'A01,A02,A06,X01', 'L1',
     [('final', 'bench_final', 'gated_shadow_fixed_bound', None), ('fix', 'bench_fix_main', 'gated_shadow_fixed', None),
      ('R9', 'bench_wpA', 'gated_shadow', None)],
     ('final', 'bench_final', 'incumbent_fixed_bound'),
     'ungated shadow (R9 bench_wpA shadow) and blocking gated_proof_first (R9 bench_wpA); unfixed runner gated_shadow_r9 (bench_fix_main)',
     'proof lane time (lane_busy_u) + strong evaluations per gated attempt (work counters in formal raw)',
     'runner queues only (LifeShadowRunner.residency; 0 after close); session as incumbent',
     A_SENS, 'max paired wall ratio (formal) ; virtual: never worse per target (Lemma S1, HO-1)', lc='shadow_mainfix',
     decision='P2 条件候选：修正版运行器 + bound 确认 + 树路线（独立计算 lane、q_u>0、q 小于 L0 剩余串行服务时间）',
     affected='runner changed in fix round (F1/F2); final round: async close drain, q_u>0 required')
mech('M02', '持久关系树（PersistentStrongSession）', 'P03,O01,X21', 'L1',
     [('fix', 'bench_fix_main', 'persistent_gated_shadow_fixed', None), ('fix', 'bench_wpA', 'persistent_gated_shadow', None),
      ('fix', 'bench_fixLC', 'persistent_tree', None)],
     ('fix', 'bench_fix_main', 'gated_shadow_exact_fixed'),
     'fresh tree (gated_shadow_fixed) = same algorithm without persistence; fresh exact = strongest fresh route',
     'persistent_leaf_updates + persistent_compose + rebuilds (session metrics); BC-2 charged evaluations',
     'segment tree 2*size relations (LC costs residency 64 at n=32)', 'n 24-72 (A grid traces); rebind density (lifecycle scenario)',
     'max paired ratio; rebuild on every identity/settings change', lc='persistent_tree',
     decision='条件候选（只减计算；与 fresh exact 比见索引）', affected='BC-2 charging + rollback (fix §1)')
mech('M03', '块摘要（BlockSummary 核心 + BlockSession 会话接线，同一机制两层证据）', 'B01,B04,X02', 'L1',
     [('fix', 'bench_wpB', 'gated_blocks', 'coupled'), ('R9', 'bench_wpB', 'blocks8', 'inc'), ('fix', 'bench_fixLC', 'block_session', None)],
     ('fix', 'bench_wpB', 'gated_exact'),
     'gated_tree (same gate, tree route); block size 32 and tree (core layer, R9 bench_wpB inc family)',
     'block_updates / invalidated blocks / rollbacks (session metrics); table invalidation per update (core)',
     'table entries + exit keys + frontier boundaries (LC costs; R9 B01_blowup)',
     'n 32-128, pu 0.3/0.6 (core); coupled W01/W05/W06/RP/W02', 'core: n128 pu0.6 more evaluations than frontier; coupled: W02 proof_first evals > exact',
     lc='block_session', decision='条件候选（不在优先列表）', affected='BC-2 + transaction snapshot + release fix (fix §1, LC E5)',
     notes='R9 and the fix round counted the core (M04) and the session wiring (M03) as two mechanisms; merged in the final round')
mech('M05', '分层/反向剪枝（seeded/goal）', 'B03,B05', 'L1', [('R9', 'bench_wpB', 'goal', 'layer'), ('R9', 'bench_wpB', 'seeded', 'layer')],
     ('R9', 'bench_wpB', 'exact0'), 'tree only (R9 studies)', 'none (single queries)', 'none retained',
     'n 16/64/128 (R9 layer family); fix Q1 B05 54-case grid + maintenance stream', '2-5x evaluations',
     decision='淘汰（fix Q1 再次确认）')
mech('M06', 'D04 差值区间 memo（INTERVAL）', 'D04', 'L0', [('fix', 'bench_fixQ1', 'interval', 'd04')], ('fix', 'bench_fixQ1', 'owner'),
     'exact signature memo SIG (same run)', 'interval bookkeeping per miss (owner metrics interval_hits/typed reads)',
     'memo entries (owner memo, bounded by capacity)', '8 change modes x n 24-64 (fix Q1 d04_study) + held-out HO-4',
     'random G0 workloads: no gain', decision='P1 等价优化（owner 内部，替换 SIG）')
mech('M07', 'D04 比较签名 memo（SIG）', 'D04', 'L0', [('R9', 'bench_wpB', 'sig', 'sig'), ('fix', 'bench_fixQ1', 'sig', 'd04')],
     ('R9', 'bench_wpB', 'owner'), 'order-blind mutant (R9 tests)', 'signature build per miss', 'memo entries',
     'n 16/64 order vs shuffle', 'order changes: 81.6->113.5 ms trial', decision='被 INTERVAL 取代')
mech('M08', '位集数值域（bitset）', 'D01', 'L1', [('R9', 'bench_wpB', 'bitset', 'feas')], ('R9', 'bench_wpB', 'symbolic'),
     'symbolic feasibility (baseline itself)', 'mask build per variable', 'masks per variable', 'G0 vs ext',
     '3.7x slower on G0', decision='淘汰（除带洞域）')
mech('M09', 'B01 规范 ZDD 摘要', 'B01', 'L1', [('fix', 'bench_fixQ1', 'zdd', 'b01')], ('fix', 'bench_fixQ1', 'table'),
     'uncompressed ZDD (fix Q1 b01_blowup)', 'unique-table maintenance / compaction', 'ZDD nodes vs table entries (fix Q1 b01_blowup, tracemalloc)',
     '45 (n, pu, pe, block) cells (fix Q1)', 'uncompressed: larger in 41/45 cells', decision='条件候选（需定期压缩）')
for mid, cand, q, dec in (('M10', 'hybrid', 'C03', '条件候选'), ('M11', 'skikeep', 'P01,X06', '条件候选'),
                          ('M12', 'lazytree', 'C01', '条件候选'), ('M13', 'dirtylog', 'C02', '条件候选'),
                          ('M14', 'sparsecp', 'C01', '条件候选'), ('M15', 'skirental', 'C03,P01', '条件候选')):
    mech(mid, f'按需结构 {cand}', q, 'L0', [('R9', 'bench_wpC', cand, 'struct')], ('R9', 'bench_wpC', 'r8tree'),
         'r8resync / prefixscan (same family, timed)', 'leaf invalidations / promotions (work counters)',
         'residency() structural entries (wpC_structures)', 'n 256/1024 x 5 query patterns (R9 struct family)',
         'max paired ratio (alternating phases)', decision=dec)
mech('M16', 'rope 计划', 'C04', 'L0', [('R9', 'bench_wpC', 'rope', 'rope')], ('R9', 'bench_wpC', 'rebuild'),
     'chunk size (R9 C04 study)', 'chunk recompose per edit', 'chunks', 'n 256/1024', 'settings with absolute ordinals: inapplicable',
     decision='条件候选')
mech('M17', '差分输出 DiffPlan', 'C06,O02', 'L2', [('R9', 'bench_wpC', 'diffplan', 'diff')], ('R9', 'bench_wpC', 'fulloutput'),
     'local vs flip', 'diff log', 'plan + diff', 'local vs phase-flip', 'flip: Ω(n) per flip (proved for the PH family)',
     decision='条件候选（接口选择）')
mech('M18', '共享输出结构', 'X09', 'L0', [('R9', 'bench_wpC', 'shared', 'consumer')], ('R9', 'bench_wpC', 'scan_only'),
     'dedicated structures (same run)', 'shared maintenance', 'structure entries', 'one switching scenario only', 'single scenario',
     decision='条件候选')
mech('M19', '见证前缀归一化（fused_prefix）', 'E06,X14', 'L0', [('R9', 'bench_wpC', 'fused_prefix', 'witness')],
     ('R9', 'bench_wpC', 'separate'), 'fused_eager / fused_lazy (same run)', 'prefix cache per batch', 'cache per batch',
     'near/far/mixed x fan 0/2', 'fused_eager worst 1059x (ablation, not the candidate)', decision='采用候选')
mech('M20', '门控全信息索引', 'NH12(=O/P 族细化)', 'L1', [('fix', 'bench_wpC', 'indexed', 'coupled'), ('fix', 'bench_fixLC', 'gated_index_I', None)],
     ('fix', 'bench_wpC', 'incumbent'), 'selector (same run); gate (rank-only strong) arm', 'index refresh per delta (index_evaluations)',
     'index leaves/nodes + bad lists (LC costs)', 'W01 n96 / RP dense / W05 / W06', 'RP sparse: no wins, +47% wall (R9)',
     lc='gated_index_I', decision='条件候选（只改成本，从不扩大可发布集合）', affected='BC-2 (C4)')
mech('M21', '选择器 SEL', 'P01', 'L1', [('fix', 'bench_wpC', 'selector', 'coupled'), ('fix', 'bench_fixLC', 'gated_index_SEL', None)],
     ('fix', 'bench_wpC', 'incumbent'), 'indexed / gated (same run)', 'as M20 + strong attempts', 'as M20', 'as M20',
     'W01 holes4 latency 16->26 (R9)', lc='gated_index_SEL', decision='不采用', affected='BC-2 (C4)')
mech('M22', 'derive_first（模型修正）', 'K01', 'L0', [('R9', 'bench_wpG', 'derive', 'coupled'), ('fix', 'bench_fixLC', 'derive_first', None)],
     ('R9', 'bench_wpG', 'lru'), 'useless_first / both (same run)', 'none extra (one transient raw slot)', 'peak_raw r+1',
     'raw capacity 1-4 (R9 K01 held-out, now development evidence)', 'rc=1 livelock removed (model artefact, not a gain)',
     lc='derive_first', decision='模型修正（不计收益）')
mech('M23', '投影支撑', 'G01', 'L0', [('R9', 'bench_wpG', 'proj_support', 'owner'), ('fix', 'bench_fixLC', 'proj_support', None)],
     ('R9', 'bench_wpG', 'incumbent'), 'fact_support (same run)', 'projection per stored key + exact dict', 'memo projection entries (LC costs 4)',
     '12 owner scenarios (refresh/dependent/unrelated/churn/quiet/chain)', 'proj_posrev max ratio', lc='proj_support',
     decision='等价优化（owner 层）')
mech('M24', '重签（GSession reissue eager/lazy）', 'G05,X20', 'L0', [('fix', 'bench_wpG', 'reissue', 'coupled'), ('fix', 'bench_wpG', 'proj_reissue', 'coupled'),
     ('fix', 'bench_fixLC', 'reissue_eager', None)], ('fix', 'bench_wpG', 'lru'), 'lazy vs eager (LC + R9 X20)',
     '+publication read checks, +certification calls', 'certificate set', '5 coupled scenarios (rc 1-3)', 'max ratio 1.7 (R9)',
     lc='reissue_eager', decision='条件候选', affected='GSession counter fix (fix §4)')
mech('M25', 'noop_none 生产者提示', 'G04', 'L0', [('R9', 'bench_wpG', 'noop_none', 'owner')], ('R9', 'bench_wpG', 'incumbent'),
     'hint variant (R9 G04 study)', 'none', 'none', '12 owner scenarios', 'wrong producer hint goes stale (G04 counterexample)',
     decision='条件候选（依赖生产者合同）')
mech('M26', 'posrev 屏障', 'G03', 'L0', [('R9', 'bench_wpG', 'posrev', 'owner')], ('R9', 'bench_wpG', 'incumbent'),
     'proj_posrev (same run)', 'posrev checks', 'n ints + position tuple per entry', '12 owner scenarios', 'coupled: +357 checks, 0 saved',
     decision='条件候选（仅 owner 层）')
mech('M27', '留存 GDS（字节/步数估计）', 'K02,K03,X26', 'L0', [('R9', 'bench_wpG', 'gds_clock', 'retention'), ('R9', 'bench_wpG', 'gds_steps', 'retention')],
     ('R9', 'bench_wpG', 'lru4'), 'bytes LRU (same run)', 'clock samples / size accounting', 'byte budget (equal space)',
     'one formal scenario (retention_skewed); held-out seeds in R9 study', 'gain vanished on held-out', decision='淘汰')
mech('M28', 'LUT 融合算子', 'L03', 'L0', [('R9', 'bench_wpG', 'lut_fused', 'operator')], ('R9', 'bench_wpG', 'optimized'),
     'none timed', '256-entry LUT once', '256 entries', 'one scenario', 'n/a', decision='仅 Python 层')
mech('M29', 'straight-line 转移', 'L01', 'L0', [('R9', 'bench_wpG', 'straight', 'compose')], ('R9', 'bench_wpG', 'tuple'),
     'packed_int / bytes_translate (same run)', 'none', 'none', 'one scenario', 'packed_int 1.53x (ablation)', decision='仅 Python 层')
mech('M30', 'OwnerView', 'L05', 'L0', [('R9', 'bench_wpG', 'view', 'view')], ('R9', 'bench_wpG', 'snapshot'),
     'none', 'revision check per read', 'view object', 'n 64/1024', 'stale after writes', decision='表示效应，不计算法收益')
mech('M31', '增量撤销 inc_revoke', 'H03,H02', 'L0', [('final', 'bench_final', 'inc_revoke_bound', 'life'), ('R9', 'bench_wpH', 'inc_revoke', 'revoke'),
     ('fix', 'bench_fixLC', 'inc_revoke', None)],
     ('final', 'bench_final', 'package_bound'), 'full revalidation fallback on guard change (built in); mutant skipping a key (LC)',
     'reverse index updates per publish/drop (LC costs entries 211-669)', 'reverse index entries', 'RP/W02/W06 x seeds; held-out HO-3',
     'every write a guard change => equal to full', lc='inc_revoke', decision='P1 等价优化（与 bound 确认组合）')
mech('M32', '句柄绑定确认 bound_confirm', 'H04', 'L0', [('R9', 'bench_wpH', 'bound_confirm', 'confirm'), ('fix', 'bench_fixLC', 'bound_confirm', None)],
     ('R9', 'bench_wpH', 'package_confirm'), 'unbound mutant (LC)', 'handle carried by callers', 'none', 'RP/W02/W06; expiry/mixed streams',
     'caller migration cost (interface change)', lc='bound_confirm', decision='P0 接口强化（所有 D4 的前提）')
mech('M33', 'value 复用 + incarnation 授权', 'H05,X22', 'L0', [('R9', 'bench_wpH', 'value_cache', 'value'), ('fix', 'bench_fixLC', 'value_cache', None)],
     ('R9', 'bench_wpH', 'identity_only'), 'migrate_resign combination (R9 X22)', 'cache entries per computed witness', 'cache entries (LC 2-14)',
     'fresh vs carry rebind (R9 X22)', 'label reuse => stale value (contract)', lc='value_cache', decision='条件候选（生产者合同）')
mech('M34', 'reserve1 预留', 'I02', 'L1', [('R9', 'bench_wpH', 'reserve1', 'reserve'), ('fix', 'bench_fixLC', 'reserve1', None)],
     ('R9', 'bench_wpH', 'no_reserve'), 'dyn reserve (sim)', 'reservation bookkeeping', 'one reserved slot', 'RP/W02/W06',
     'refusals of optional prefetch', lc='reserve1', decision='不采用（无收益，保留反例）')
mech('M35', '微批 batch_peritem', 'I05', 'L1', [('R9', 'bench_wpH', 'batch_peritem', 'microbatch')], ('R9', 'bench_wpH', 'immediate'),
     'batch_barrier (same run)', 'batch bookkeeping', 'batch buffer', 'setup 3-4 u (sim seeds 200/201)', 'barrier with slow member',
     decision='条件候选（仿真层）')
mech('M36', '退款隔离信用 refund_isolated', 'J06', 'L1', [('R9', 'bench_wpH', 'refund_isolated', 'spec_credit')], ('R9', 'bench_wpH', 'none'),
     'global / isolated (same run)', 'credit ledger', 'credits per requester', 'sim seeds 200/201', 'always-wrong requester',
     decision='条件候选（仿真层）')
mech('M37', '动态预留/固定预留（调度）', 'I02,J02', 'L1', [('R9', 'bench_wpH', 'dyn_b10', 'sched_reserve'), ('R9', 'bench_wpH', 'fixed1', 'sched_reserve')],
     ('R9', 'bench_wpH', 'none'), 'fixed1 vs dyn_b10 (same run)', 'bound declaration', 'reserved capacity', 'B 10..20 (sim)',
     'dishonest bounds void the guarantee', decision='条件候选（仿真层）')
mech('M38', '跨 rebind 重签（MigratingSession）', 'Q03,X22', 'L0', [('fix', 'bench_fixLC', 'migrate_resign', None)],
     ('fix', 'bench_fixLC', 'package_session'), 'value_cache combination (R9 X22)', 'support comparison per migrated certificate',
     'migration candidates (cleared after first certify)', 'lifecycle W01/W05/RP', 'certify public fields differ (first=None, steps=0)',
     lc='migrate_resign', decision='条件候选（公开字段变化）')
mech('M39', 'T04 携证明证书 + 小校验器（只测了校验器内核成本）', 'T04', 'core', [('fix', 'bench_fixQ2', 'route2', 't04')], ('fix', 'bench_fixQ2', 'route1'),
     '10 mutant classes (fix Q2)', 'certificate construction per issued certificate', 'certificate size (median 218 B, max 24 KB)',
     '4 scenarios (small/W05/RP/W02)', 'rejects true claims when proof object mismatches (completeness loss)',
     decision='不在优先列表：只测了校验器内核成本（证书构造/维护未计时）；旧校验器未补域检查前不能作授权器')
mech('M40', 'X05 共享图携支撑（AB1）', 'X05', 'L1', [('fix', 'bench_fixQ2', 'AB1', 'x05')], ('fix', 'bench_fixQ2', '0'),
     'A, B, AB2 arms (same run)', 'validation reads / delta fan-out / release work (fix Q2 counters)', 'residency_peak (entries)',
     'W01/RP/W05 x hot/jump (+ held-out HO-6)', 'AB2 worse on all metrics; 9 residency-peak exceptions per stream', decision='采用候选（组合）')
mech('M41', 'X30 L2 迁移（cut16）组合', 'X30', 'L2', [('fix', 'bench_fixQ2', 'AB_perunit', 'x30'), ('fix', 'bench_fixQ2', 'B_perunit', 'x30')],
     ('fix', 'bench_fixQ2', '0'), 'switch vs per-unit (same run)', 'revocations / republications', 'n/a',
     'migration at 1/4, 1/2, 3/4 of trace (fix Q2)', 'B acquisitions -3.7%..+2.1% by migration time', decision='不采用 L2')
for mid, cand, q, dec in (('M42', 'race_keep', 'A03,F04', '淘汰（K1 反例）'), ('M43', 'race_cancel', 'A03', '淘汰'),
                          ('M44', 'adaptive', 'F06,A02', '淘汰（对手比 3.49-4.49x）'), ('M45', 'ski', 'P05', '淘汰'),
                          ('M46', 'gated_proof_first', 'A03', '条件（只在省一次接纳时）')):
    mech(mid, f'采用策略 {cand}', q, 'L1', [('R9', 'bench_wpA', cand, None)], ('R9', 'bench_wpA', 'incumbent'),
         'gated_shadow (same run)', 'proof lane + acquisitions (work counters)', 'runner queues only', A_SENS,
         'max paired ratio', decision=dec)


def has(x):
    return x not in (None, '', 'none', 'n/a', 'none timed', 'none retained')


def e5_passed(lc):
    if lc is None:
        return False
    ho = HO2.get(lc)
    if ho and ho['groups'] == ho['ok']:
        return True
    return False


rows = []
for m in M:
    prim = None
    timings = []
    for (src, mod, cand, flt) in m['formal']:
        f = formal(src, mod, cand, flt)
        if f:
            timings.append(f)
    prim = timings[0] if timings else None
    bl = formal(*m['baseline'], m['formal'][0][3]) if m['baseline'] else None
    pr = probe(m['formal'][0][1], m['formal'][0][2])
    pr_inc = probe(m['formal'][0][1], prim['incumbent']) if prim else None
    lcc = LCCOST.get(m['lc']) if m['lc'] else None
    checks = {}
    checks['B'] = bool(prim and bl and prim['src'] == bl['src'] and prim['module'] == bl['module'])
    checks['A'] = has(m['ablation'])
    checks['P'] = bool(prim and prim['pids'] >= 3 and prim['processes'] == [0, 1, 2])
    checks['T'] = bool(prim and prim['wall_ms_candidate'] is not None and prim['wall_ms_incumbent'] is not None) \
        and m['mid'] not in COST_SCOPE_INCOMPLETE
    checks['M'] = has(m['maintenance'])
    checks['R'] = bool((lcc and lcc.get('residency_peak') and lcc['residency_peak'][0] is not None) or
                       (lcc and e5_passed(m['lc'])) or          # residency hook None + reachable-bytes check passed (E5)
                       (pr and pr['structure']) or m['mid'] in RESID_PTR or
                       m['residency'] in ('none retained', 'runner queues only (LifeShadowRunner.residency; 0 after close); session as incumbent'))
    checks['K'] = bool(pr and pr_inc)
    checks['X'] = bool(pr is not None or (lcc and lcc.get('residency_after_close')))
    checks['S'] = has(m['sensitivity']) and 'one scenario' not in m['sensitivity'] and 'one formal scenario' not in m['sensitivity'] \
        and 'one switching scenario' not in m['sensitivity']
    checks['W'] = bool(prim and prim['ratio_max'] is not None) and has(m['worst'])
    missing = [k for k, v in checks.items() if not v]
    d3 = not missing
    lcv = None
    if m['lc']:
        lcv = dict(ho2=HO2.get(m['lc']))
    d4 = False
    d4_note = ''
    if d3 and m['lc'] and m['mid'] not in FULL_CONFIG:
        d4_note = 'D4 parts (lifecycle with bound, held-out) pass, but cost was not measured in the full configuration (with bound confirmation) -> D3'
    elif d3 and m['lc']:
        ho = HO2.get(m['lc'])
        if m['lc'] == 'shadow_mainfix':
            sh = jload('results/raw/fix/main/shadow_mainfix_lifecycle.json') or []
            lc_ok = bool(sh) and all(not r['failed'] for r in sh if r['bound'])
            ho_ok = bool(HO1) and HO1.get('s1_violations') == 0 and HO1.get('wrong') == 0 and HO1.get('targets_worse') == 0
            d4 = lc_ok and ho_ok
            d4_note = f"LC runner groups (bound) all pass={lc_ok}; HO-1 S1/wrong/worse ok={ho_ok}"
        elif ho:
            d4 = ho['groups'] == ho['ok']
            d4_note = f"HO-2 held-out lifecycle {ho['ok']}/{ho['groups']} groups"
    depth = 'D4' if d4 else ('D3' if d3 else 'D2')
    rows.append(dict(mechanism_id=m['mid'], mechanism=m['name'], questions=m['questions'], layer=m['layer'],
                     decision=m['decision'], depth=depth, missing_for_D3=''.join(missing), d4_evidence=d4_note,
                     primary_timing=json.dumps(prim, ensure_ascii=False) if prim else '',
                     other_timings=json.dumps(timings[1:], ensure_ascii=False) if len(timings) > 1 else '',
                     strong_baseline=json.dumps(bl, ensure_ascii=False) if bl else '',
                     ablation=m['ablation'], maintenance=m['maintenance'],
                     residency_entries=json.dumps(dict(lc_peak=lcc.get('residency_peak'), lc_after_close=lcc.get('residency_after_close'),
                                                       note='None = no candidate-held structure; E5 reachable-bytes check') if lcc else
                                                  (RESID_PTR.get(m['mid']) or (pr['structure'] if pr and pr['structure'] else m['residency'])),
                                                  ensure_ascii=False),
                     peak_bytes=json.dumps(dict(candidate=pr and pr['peak_bytes_median'], incumbent=pr_inc and pr_inc['peak_bytes_median'],
                                                lc_traced_peak=lcc and lcc.get('traced_peak_max'))),
                     exit_release=json.dumps(dict(retained_bytes_after_run_max=pr and pr['retained_bytes_max'],
                                                  lc_retained_after_close=lcc and lcc.get('retained_after_close_max'),
                                                  lc_entries_after_close=lcc and lcc.get('residency_after_close'))),
                     cumulative_alloc='unavailable (Python layer has no allocation counter; LC positive-increment sum is a lower bound only)',
                     sensitivity=m['sensitivity'], worst=m['worst'], affected_by_fix=m['affected'], notes=m['notes']))

(S / 'fix').mkdir(parents=True, exist_ok=True)
with open(S / 'fix/D3_INDEX.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader(); w.writerows(rows)
counts = dict(mechanisms=len(rows), D4=sum(r['depth'] == 'D4' for r in rows), D3=sum(r['depth'] == 'D3' for r in rows),
              D2=sum(r['depth'] == 'D2' for r in rows),
              missing_histogram={k: sum(k in r['missing_for_D3'] for r in rows) for k in 'BAPTMRKXSW'})
(S / 'fix/D3_COUNTS.json').write_text(json.dumps(counts, indent=1, ensure_ascii=False))
L = ['# 逐机制 D3/D4 证据索引（bench/build_fix_d3_index.py 生成）', '',
     '判据字母：B 正确强基线同轮配对计时 · A 关键消融 · P 三个串行独立进程 · T 绝对耗时 · M 维护成本 · R 结构条目驻留 · '
     'K 峰值字节 · X 退出释放 · S 敏感性 · W 最坏退化。缺任一项封顶 D2。D4 = D3 + 生命周期全组通过（bound 确认）+ 冻结后留出通过。',
     '层次分开：结构条目（entries）、tracemalloc 字节（Python 对象）、虚拟服务单位 u、墙钟 ms；累计分配在本层不可测，只报"不可用"。', '',
     f"机制数 {counts['mechanisms']}：D4 {counts['D4']}、D3 {counts['D3']}、D2 {counts['D2']}；缺项分布 {counts['missing_histogram']}", '',
     '| ID | 机制 | 题目 | 深度 | 缺项 | 主计时（候选/基线 ms，比值中位[最小,最大]，场景，进程） | 强基线比 | 峰值 B（候选/基线） | 退出保留 B | 结论 |',
     '|---|---|---|---|---|---|---|---|---|---|']
for r in rows:
    p = json.loads(r['primary_timing']) if r['primary_timing'] else None
    b = json.loads(r['strong_baseline']) if r['strong_baseline'] else None
    pk = json.loads(r['peak_bytes']); ex = json.loads(r['exit_release'])
    pt = (f"{p['src']}:{p['module']} {p['wall_ms_candidate']}/{p['wall_ms_incumbent']}, {p['ratio_median']} [{p['ratio_min']}, {p['ratio_max']}], "
          f"{p['scenarios']}, {len(p['processes'])}") if p else '—'
    bt = ((f"{b['candidate']} {b['ratio_median']}" if b['ratio_median'] is not None else f"{b['candidate']}（=incumbent）") if b else '—')
    L.append(f"| {r['mechanism_id']} | {r['mechanism']} | {r['questions']} | {r['depth']} | {r['missing_for_D3'] or '—'} | {pt} | {bt} | "
             f"{pk['candidate']}/{pk['incumbent']} | {ex['retained_bytes_after_run_max'] if ex['retained_bytes_after_run_max'] is not None else ex['lc_retained_after_close']} | {r['decision']} |")
(S / 'fix/D3_INDEX.md').write_text('\n'.join(L) + '\n')
print(json.dumps(counts, ensure_ascii=False))
