"""Final round: the CURRENT adoption matrix (one row per mechanism of D3_INDEX + the three required
interfaces), with priority, full-configuration evidence and the complete gain metrics.
Historical R9 rows and fork fragments stay in ADOPTION_MATRIX_detail.csv / ADOPTION_MATRIX_R9.csv."""
import csv, json
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
idx = {r['mechanism_id']: r for r in csv.DictReader(open(OUT / 'results/summary/fix/D3_INDEX.csv'))}
H = ['mechanism_id', 'candidate', 'class', 'priority', 'current_decision', 'depth', 'full_config_correctness', 'full_config_cost',
     'interfaces', 'contracts_to_verify', 'gain_metrics', 'reversal', 'missing_native_calibration', 'evidence']
P = [
 dict(mechanism_id='I1', candidate='会话级 close（异步：请求 / 逻辑关闭 / 物理排空）', class_='接口强化', priority='P0 必需',
      current_decision='实现；包内 Session 没有 close', depth='—（协议）',
      full_config_correctness='LC E5 全部机制；最终轮关闭排空回归 8 项（tests/test_final_boundaries.py）', full_config_cost='协议，未计时',
      interfaces='Session.close() 或等价；候选 close() 钩子', contracts_to_verify='取消任务占槽到真实退出；排空完成才关闭 owner、释放存储；重复关闭只应答；关闭期间拒绝请求、不重启工作、不接纳旧结果',
      gain_metrics='无收益指标（正确性要求）', reversal='—', missing_native_calibration='原生任务退出时延分布', evidence='results/raw/final/close_repro_*'),
 dict(mechanism_id='M32', candidate='句柄绑定确认 bound_confirm', class_='接口强化', priority='P0 必需',
      current_decision='实现 confirm(target, handle)，两阶段迁移', depth=idx['M32']['depth'],
      full_config_correctness='LC 全组 + HO-2 留出', full_config_cost='R9 bench_wpH 0.995；bench_fixLC 0.981',
      interfaces='publish 返回句柄随回调令牌下发；重签产生新句柄', contracts_to_verify='无句柄→unbound；旧句柄/rebind/关闭后→stale_callback；过期重发后旧回调确认数 = 0',
      gain_metrics='误确认数（开发 expiry 流 128→0）；迁移期被拒的旧式调用数（83）', reversal='无（只有迁移成本）', missing_native_calibration='迟到回调频率与延迟、旧式调用方数量',
      evidence='sections/fix_LC.md §5'),
 dict(mechanism_id='I2', candidate='强证明预算合同 BC-2', class_='接口强化', priority='P0 必需（任何强路线的前提）',
      current_decision='实现', depth='—（合同）', full_config_correctness='tests/test_budget_contract.py 10 项；HO-7 40 检查',
      full_config_cost='计量包装与回滚日志包含在所有强路线的正式计时中', interfaces='certify(..., mode S, budget) 语义；共享结构事务化',
      contracts_to_verify='同一单位；建树/更新/查询全部计费；越限不发证；停止回滚；证书复用不计费', gain_metrics='—', reversal='—',
      missing_native_calibration='原生单次步评估成本', evidence='proofs/fix_budget.md'),
 dict(mechanism_id='M31', candidate='增量撤销 inc_revoke（+ bound 确认）', class_='等价优化', priority='P1',
      current_decision='采用', depth=idx['M31']['depth'],
      full_config_correctness='LC 全组（bound）+ HO-2；公开观察开发 156 000 + 留出 54 000 事件 0 差异（有界随机搜索，非机器证明）',
      full_config_cost='bench_final：inc_revoke+bound / package+bound 墙钟 0.157 [0.146, 0.159]（32.8 vs 209.3 ms/轨迹中位）；发布读校验 84 778→2 411；物理获取 21=21',
      interfaces='owner 原子写入报告可能改变的读键；守卫/epoch 变化全量回退', contracts_to_verify='逐事件公开观察 = 全量重验（含设置变化、rebind、关闭、过期交错）',
      gain_metrics='发布读校验数、墙钟；反向索引条目（211–669，关闭后 0）；物理工作不变', reversal='每次写入都是守卫变化时退化为全量 + 索引维护',
      missing_native_calibration='原生写入组合中守卫变化/项目写入比、每支撑键当前发布数', evidence='results/summary/formal_final/'),
 dict(mechanism_id='M06', candidate='D04 差值区间 memo（INTERVAL，替换 SIG）', class_='等价优化', priority='P1',
      current_decision='采用（owner 内部）', depth=idx['M06']['depth'],
      full_config_correctness='3 996 变化 0 观察改变；HO-4 留出 0 不一致；变异体被拒', full_config_cost='bench_fixQ1 owner 层 1.0 [0.824, 1.117]；驻留与 owner 相同',
      interfaces='无（owner 内部校验）', contracts_to_verify='公开结果逐字段 = 新建 corrected owner；边界写错的变异体必须被拒',
      gain_metrics='引擎运行（链抖动 392→245 等）、墙钟；随机 G0 抖动无收益', reversal='秩值随机抖动（无收益，只剩校验开销）',
      missing_native_calibration='原生秩抖动形态（序不变的比例）', evidence='sections/fix_Q1.md'),
 dict(mechanism_id='M01', candidate='gated_shadow：修正版运行器（F1/F2）+ bound 确认 + 树路线', class_='条件候选', priority='P2 条件',
      current_decision='只在独立计算 lane、q_u>0、q 小于 L0 剩余串行服务时间时启用；默认关闭', depth=idx['M01']['depth'],
      full_config_correctness='LC 运行器脚本（bound）全部组通过；HO-1 352 格 S1 全等、wrong 0、无目标变慢（HO-1 轨迹没有确认事件，bound 适配不被调用）；q_u≤0 拒绝',
      full_config_cost='bench_final：墙钟比 1.067 [0.979, 1.856]（29.7 vs 28.6 ms/场景中位）；强评估 16 936/98 格；lane 170u；判定哈希与无 bound 运行 196/196 相同',
      interfaces='bound 确认；证明尝试身份（正 q、单 lane）；再意图物理镜像；异步 close；BC-2', contracts_to_verify='物理调度 = incumbent（S1）；每目标延迟 ≤ incumbent；过期发布可重新取得；关闭后镜像为 0',
      gain_metrics='虚拟延迟：冻结留出 −0.5%～−2.7%（开发网格 −8.5%）；物理获取不变（0 节省）；增加强证明计算与墙钟 6.7%；没有原生提速证据',
      reversal='证明与请求共用 lane（+75%）；gate/胜出率为 0', missing_native_calibration='q 与 service 分布、lane 空闲率、自然 gate/胜出率、L0 剩余串行服务步数',
      evidence='results/summary/formal_final/; results/summary/fix/heldout/ho1.json'),
]
EXTRA = dict(
    M22=('规格对齐', '不是候选：按 NATIVE_OWNER.pseudo 先派生后驱逐；不计收益'),
    M02=('不采用', '被 fresh exact 支配'),
)
rows = []
for d in P:
    d = dict(d); d['class'] = d.pop('class_')
    rows.append(d)
done = {d['mechanism_id'] for d in P}
for mid, r in idx.items():
    if mid in done:
        continue
    pri, dec = EXTRA.get(mid, (None, None))
    if pri is None:
        txt = r['decision']
        pri = '不采用' if any(x in txt for x in ('淘汰', '不采用', '取代')) else ('表示效应' if '表示' in txt or 'Python' in txt else '不默认（条件/未验证）')
    rows.append(dict(mechanism_id=mid, candidate=r['mechanism'], **{'class': ''}, priority=pri, current_decision=dec or r['decision'],
                     depth=r['depth'], full_config_correctness='见 D3_INDEX d4_evidence' if r['d4_evidence'] else '',
                     full_config_cost=('未在含 bound 的完整配置下计时' if r['d4_evidence'].startswith('D4 parts') else ''),
                     interfaces='', contracts_to_verify='', gain_metrics='', reversal='', missing_native_calibration='',
                     evidence='results/summary/fix/D3_INDEX.csv'))
rows.append(dict(mechanism_id='(M01 变体)', candidate='gated_shadow 用 fresh exact 路线', **{'class': '条件候选'}, priority='未验证',
                 current_decision='开发网格评估更少（1 895 vs 16 936）、墙钟比 1.037；冻结留出未用此配置运行，不推荐为默认', depth='D2（留出未验证）',
                 full_config_correctness='开发网格 98 格 S1 与 wrong 0', full_config_cost='bench_fix_main（无 bound）', interfaces='', contracts_to_verify='',
                 gain_metrics='', reversal='', missing_native_calibration='', evidence='results/summary/formal_fix/bench_fix_main.json'))
with open(OUT / 'ADOPTION_MATRIX.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=H)
    w.writeheader(); w.writerows(rows)
print(len(rows))
