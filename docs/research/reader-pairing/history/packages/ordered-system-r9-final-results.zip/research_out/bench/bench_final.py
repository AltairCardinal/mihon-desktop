"""Final round: formal timing of the RECOMMENDED full configurations only (same configuration as
their correctness acceptance).  Bound confirmation is part of every configuration.
  life_*    LV lifecycle traces (same driver as bench_fixLC 'life'): package+bound [0] vs inc_revoke+bound
  A grid    98 bench_wpA scenarios: fixed incumbent+bound [0] vs fixed gated_shadow (tree route)+bound
Correctness of the same configurations: LC groups / HO-2 with bound (inc_revoke); LC runner scripts
with bound + HO-1 (gated_shadow; HO-1 traces carry no confirm events and BoundMixin overrides only
confirm, so HO-1 exercised the same behaviour; verdict hashes are also compared with bench_fix_main)."""
import hashlib, json, time
import paths  # noqa: F401
import bench_wpA as BA
import bench_fixLC as BL
import fixLC_groups as G
from fixLC_lifecycle import Life
from current_baseline import typed
import fix_main_shadow as FS

LIFE = ['package_bound', 'inc_revoke_bound']
SHADOW = ['incumbent_fixed_bound', 'gated_shadow_fixed_bound']
SCENARIOS = [dict(name='life_' + n, fam='life', trace=n) for n, _ in G.LV_TRACES] + \
            [dict(sc, fam='A') for sc in BA.SCENARIOS]
CANDIDATES = LIFE


def FAMILY_CANDIDATES(sc):
    return LIFE if sc['fam'] == 'life' else SHADOW


def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


def run_one(sc, cand, rep=0):
    if sc['fam'] == 'life':
        name = dict(package_bound='package_session', inc_revoke_bound='inc_revoke')[cand]
        tr = dict(G.LV_TRACES)[sc['trace']]()
        targets = []
        for ev in tr['events']:
            if ev['op'] == 'target' and ev['target'] not in targets:
                targets.append(ev['target'])
        t0 = time.perf_counter_ns()
        life = Life(G.spec(name, True), tr)
        pubs, ok = [], True
        for t in targets:
            p, v = life.drive(t, limit=300, confirm=True)
            ok &= bool(p and typed(v['unit']) == typed(life.truth[t]))
            pubs.append((t, typed(v['unit']) if p else None))
        while life.due:
            life.advance()
        life.close()
        wall = time.perf_counter_ns() - t0
        s = life.s
        released = s.occupied == 0 and s.raw_size == 0 and s.certificate_count == 0 and life.residency() in (0, None)
        m = s.metrics
        return dict(wall_ns=wall, verdict_sha256=_sha(pubs), ok=ok and released,
                    work=dict(admissions=m['physical_admissions'], certification_steps=m['certification_steps'],
                              publication_read_checks=m['publication_read_checks'], confirmations=m['confirmations'],
                              events=len(life.rows), released=released, session_class=type(s).__name__))
    tr = BA._trace(sc)
    kw = dict(service_u=sc['service_u'], q_u=sc['q_u'], capacity=sc['capacity'], bound=True)
    runner = FS.FixedIncumbentRunner(tr, **kw) if cand == 'incumbent_fixed_bound' else \
        FS.FixedShadowRunner(tr, policy='gated_shadow', **kw)
    t0 = time.perf_counter_ns()
    r = runner.run(max_steps=40000)
    wall = time.perf_counter_ns() - t0
    pubs = sorted((int(k), repr(v)) for k, v in runner.session.published.items())
    sha = hashlib.sha256(json.dumps(dict(pubs=pubs, first=sorted(runner.first_pub)), sort_keys=True).encode()).hexdigest()
    ok = r['wrong'] == 0 and r['published'] == r['intents'] and not r['livelock']
    work = {k: r.get(k, 0) for k in ('total_latency_u', 'physical_admissions', 'strong_evaluations', 'lane_busy_u',
                                      'proof_wins', 'reintents', 'reintents_served')}
    work['session_class'] = type(runner.session).__name__
    return dict(wall_ns=wall, verdict_sha256=sha, ok=ok, work=work)
