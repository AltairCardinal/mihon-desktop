"""Recompute the headline numbers quoted in REPORT.md / sections/fix_main.md from raw files and assert them."""
import collections, csv, json
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
J = lambda p: json.loads((OUT / p).read_text())
chk = {}
# §1 budget
before = J('results/raw/fix/budget_probe_before_fix.json'); after = J('results/raw/fix/budget_probe_after_fix.json')
chk['bypass_before'] = sorted({r['route'] for r in before if r['budget'] == 0 and r['strong_certificate_issued']}) == ['block', 'index', 'persistent']
chk['no_bypass_after'] = not any(r['strong_certificate_issued'] for r in after if r['budget'] in (0, 1))
d = J('results/summary/fix/differential.json'); chk['differential_1016_956'] = (d['cells'], d['cells_identical']) == (1016, 956)
# A grid evaluations (formal_fix, deterministic work)
agg = collections.Counter()
for c in J('results/summary/formal_fix/bench_fix_main.json')['cells']:
    agg[c['candidate']] += (c['work'] or {}).get('strong_evaluations', 0)
chk['A_grid_evals'] = (agg['gated_shadow_exact_fixed'], agg['persistent_gated_shadow_fixed'], agg['gated_shadow_fixed']) == (1895, 13433, 16936)
lat = collections.Counter(); adm = collections.Counter()
for c in J('results/summary/formal_fix/bench_fix_main.json')['cells']:
    lat[c['candidate']] += c['work']['total_latency_u']; adm[c['candidate']] += c['work']['physical_admissions']
chk['A_grid_latency_1497_1370_admissions_411'] = (lat['incumbent_fixed'], lat['gated_shadow_fixed'], adm['incumbent_fixed'], adm['gated_shadow_fixed']) == (1497, 1370, 411, 411)
# HO-1 recomputed from the raw jsonl
rows = [json.loads(l) for l in open(OUT / 'results/raw/fix/heldout/ho1.jsonl')]
ran = [r for r in rows if r.get('ok')]
chk['HO1_cells_352'] = len(ran) == 352
chk['HO1_S1_all_equal'] = all(r['s1_equal'] for r in ran)
chk['HO1_wrong_0'] = sum(r['gs']['wrong'] + r['inc']['wrong'] for r in ran) == 0
chk['HO1_no_worse_target'] = sum(r['targets_worse'] for r in ran) == 0
q23 = [r for r in ran if (r['service_u'], r['q_u']) == (2, 3) and r['targets_better'] > 0]
chk['HO1_q_gt_service_improved_5_all_cap1'] = len(q23) == 5 and all(r['capacity'] == 1 for r in q23)
pct = {}
for su, q in ((4, 1), (3, 1), (2, 1), (2, 3)):
    a = sum(r['inc']['total_latency_u'] for r in ran if (r['service_u'], r['q_u']) == (su, q))
    b = sum(r['gs']['total_latency_u'] for r in ran if (r['service_u'], r['q_u']) == (su, q))
    pct[f'{su},{q}'] = round(100 * (b - a) / a, 1)
chk['HO1_latency_pct'] = pct
# HO-2..7
ho2 = J('results/summary/fix/heldout/ho2.json')['per_mechanism']
chk['HO2_14_candidates_all_pass'] = sum(1 for m, v in ho2.items() if m != 'package_session' and v['groups'] == v['ok']) == 14
ho3 = J('results/raw/fix/heldout/ho3.json')['summary']
chk['HO3_inc_revoke_0'] = all(v['traces_with_difference'] == 0 for k, v in ho3.items() if k.startswith('inc_revoke'))
chk['HO3_inc_revoke_events_54000'] = sum(v['events'] for k, v in ho3.items() if k.startswith('inc_revoke')) == 54000
chk['HO4_0_mismatch'] = sum(J('results/raw/fix/heldout/ho4.json')['public_output_mismatches'].values()) == 0
chk['HO5_0_mismatch'] = J('results/raw/fix/heldout/ho5.json')['zdd_mismatch'] == 0 == J('results/raw/fix/heldout/ho5.json')['table_mismatch']
h6 = J('results/raw/fix/heldout/ho6.json'); chk['HO6_24_of_24'] = h6['streams_AB1_evals_le_AB2'] == h6['streams'] == 24
chk['HO7_0_violations'] = J('results/raw/fix/heldout/ho7.json')['violations'] == 0
# D3 / coverage counts
dc = J('results/summary/fix/D3_COUNTS.json'); chk['mechanisms_45_3_31_11'] = (dc['mechanisms'], dc['D4'], dc['D3'], dc['D2']) == (45, 3, 31, 11)
cov = [r for r in csv.DictReader(open(OUT / 'coverage.csv')) if not r['question_id'].startswith('NH')]
cnt = collections.Counter(r['depth'] for r in cov); chk['questions_4_27_119'] = (cnt['D4'], cnt['D3'], cnt['D2']) == (4, 27, 119)
# final round
for runner in ('lc', 'mainfix'):
    rows = [json.loads(l) for l in open(OUT / f'results/raw/final/close_repro_before_fix_{runner}_minimal.jsonl')]
    end = [x for x in rows if x['op'] == 'close_end'][0]
    chk[f'close_bug_reproduced_{runner}'] = (end['t'], end['ret']['occupied']) == (2, 1)
    rows = [json.loads(l) for l in open(OUT / f'results/raw/final/close_repro_after_fix_{runner}_minimal.jsonl')]
    end = [x for x in rows if x['op'] == 'close_end'][0]
    chk[f'close_fixed_{runner}'] = (end['t'], end['ret']['occupied'], end['ret']['times']) == (4, 0, dict(requested=1, logical=1, drained=4))
q0 = J('results/raw/final/q0_repro_after_fix_verdict.json')
chk['q0_rejected_and_defect_reproduced_in_bypass'] = q0[0]['construction_q0'].startswith('rejected') and q0[1]['stale_delivered'] == 1 and q0[2]['stale_delivered'] == 0
ff = J('results/summary/formal_final/bench_final.json')
pc = {a['candidate']: a for a in ff['per_candidate']}
chk['final_inc_revoke_ratio'] = pc['inc_revoke_bound']['median_of_scenario_medians'] == 0.157
chk['final_shadow_ratio'] = pc['gated_shadow_fixed_bound']['median_of_scenario_medians'] == 1.067
chk['final_hash_equal_196'] = J('results/summary/formal_final/final_config_comparison.json')['verdict_hash_equal_vs_bench_fix_main'] == 196
hy = list(csv.DictReader(open(OUT / 'hypotheses.csv')))
chk['hypotheses_15_15_0'] = collections.Counter(h['fix_reclassification'] for h in hy) == collections.Counter({'duplicate': 15, 'refinement': 15})
ok = all(v is True for k, v in chk.items() if k != 'HO1_latency_pct')
(OUT / 'results/summary/fix/claims_check.json').write_text(json.dumps(dict(all_ok=ok, checks=chk), indent=1))
print(ok, json.dumps(chk, indent=0))
