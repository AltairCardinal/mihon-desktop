"""Final round, boundary 1: close drain end point.  Confirmed counterexample: q=1, service=4,
prefetch@0 -> close@1 -> probe@2 -> real exit of the cancelled task @4 (+ repeated close @3/@6,
work events @3/@7, probe @8).  Writes every event row of both shadow runners (LC and main-fix) to
results/raw/final/close_repro_<label>_<runner>.jsonl and a verdict json."""
import json, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates')); sys.path.insert(0, str(OUT / 'tests'))
import paths  # noqa
import fixLC_shadow as LS
import fix_main_shadow as FS
from test_final_boundaries import close_trace

label = sys.argv[1] if len(sys.argv) > 1 else 'run'
extra = [dict(at=3, op='close'), dict(at=3, op='prefetch', item=5), dict(at=6, op='close'),
         dict(at=7, op='target', target=19), dict(at=8, op='probe_after_close', target=12)]
out = []
for name, cls in (('lc', LS.LifeShadowRunner), ('mainfix', FS.life_fixed_runner_class())):
    for scen, ex in (('minimal', ()), ('repeat', extra)):
        r = cls(close_trace(ex), policy='gated_shadow', service_u=4, q_u=1, bound=True)
        rows = r.run_life()
        with open(OUT / f'results/raw/final/close_repro_{label}_{name}_{scen}.jsonl', 'w') as fh:
            for x in rows:
                fh.write(json.dumps(x, default=str) + '\n')
        end = [x for x in rows if x['op'] == 'close_end']
        out.append(dict(runner=name, scenario=scen, close_end=[(x['t'], x['ret']) for x in end],
                        occupied_at_close_end=[x['ret'].get('occupied') if isinstance(x['ret'], dict) else None for x in end],
                        events=[(x['t'], x['op'], x.get('ret') if not isinstance(x.get('ret'), dict) else
                                 {k: v for k, v in x['ret'].items() if k != 'times'}, x['occupied']) for x in rows]))
(OUT / f'results/raw/final/close_repro_{label}_verdict.json').write_text(json.dumps(out, indent=1, default=str))
for o in out:
    print(o['runner'], o['scenario'], 'close_end', o['close_end'])
