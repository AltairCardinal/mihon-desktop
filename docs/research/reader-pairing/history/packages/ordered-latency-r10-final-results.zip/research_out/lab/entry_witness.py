"""Q053 route B (R10 revision): is a cheaper, exact entry relation possible, or is C08's backward extent forced?

Claim tested (information boundary). Let p be a position with cert.first < p <= t-2, i.e. a position where C09 did
NOT certify. If we can exhibit two complete worlds that agree on every fact at positions >= p (and on settings) but
give different target units, then NO sound certifier can certify the target while reading only positions >= p:
whatever it reads is identical in both worlds. Each such witness pair therefore proves that C09's backward
extension past p is necessary, i.e. that the 'over-approximation' at p is an information boundary, not slack in
C08's entry relation. A checkpoint (route A) escapes the bound only because it supplies left information (the
exact cursor) that must itself be identity-validated.

Witness construction (explicit, re-checked with the full plan G.plan, not with the search shortcut):
  prefix [0, q) = all SHAPE_Y (every Y is a single unit, the cursor at q is (q, opening=True, reserved=-1))
  or      [0, q) = an opening pair (0,1) followed by SHAPE_Y singles (cursor (q, False, -1));
  window [q, p) = sampled facts (state, side, score) from the declared value domain;
  suffix [p, n) = the original world's facts, unchanged.
Search is seeded random sampling with a budget; positions with no witness found are reported as 'undetermined'
(never as 'no witness exists').
"""
import random

import gamma as G

LEFT, RIGHT, UNK = G.LEFT, G.RIGHT, G.UNK


def full_unit(states, sides, scores, settings, t):
    return G.unit_of(G.plan(G.make_case(list(states), list(sides), dict(scores), settings)), t)


def _key(u):
    return (u["slots"], u["certain"], u["reason"])


def base_prefixes(q, settings):
    """Prefix gadgets of length q with their claimed cursor at q (verified later by the full plan)."""
    rtl = settings["direction"] == "RTL"
    trail = LEFT if rtl else RIGHT
    out = [("all_Y", ["SHAPE_Y"] * q, [UNK] * q, {})]
    if q >= 3 and settings.get("automatic"):
        # opening pair (0,1): object 1 analysed with the trailing side, object 0 not trailing; object 2 = Y
        out.append(("pair_then_Y", ["SHAPE_X", "SHAPE_X"] + ["SHAPE_Y"] * (q - 2), [UNK, trail] + [UNK] * (q - 2), {0: None, 1: None}))
    return out


def find_witness(world, settings, t, p, rng, budget=300, window=3, smax=40):
    states, sides, scores = world
    n = len(states)
    q = max(0, p - window)
    suffix_s, suffix_d = list(states[p:]), list(sides[p:])
    suffix_e = {i: scores.get(i) for i in range(p, n - 1)}
    seen = {}
    for name, ps, pd, pe in base_prefixes(q, settings):
        for k in range(budget):
            ws = ["SHAPE_Y" if rng.random() < 0.25 else "SHAPE_X" for _ in range(p - q)]
            wd = [rng.choice((LEFT, RIGHT, UNK, UNK)) for _ in range(p - q)]
            if k == 0:  # deterministic first sample: the original window
                ws, wd = list(states[q:p]), list(sides[q:p])
            st = ps + ws + suffix_s
            sd = pd + wd + suffix_d
            sc = dict(pe)
            for i in range(len(ps), p):
                sc[i] = None if rng.random() < 0.3 else rng.randint(0, smax)
            if k == 0:
                for i in range(q, p):
                    sc[i] = scores.get(i)
            if q > 0:
                sc[q - 1] = None
            sc.update(suffix_e)
            u = _key(full_unit(st, sd, sc, settings, t))
            if u not in seen:
                seen[u] = (name, st, sd, sc)
                if len(seen) >= 2:
                    (u1, w1), (u2, w2) = list(seen.items())[:2]
                    # re-verify the pair independently: suffix equality and different full-plan units
                    assert w1[1][p:] == w2[1][p:] and w1[2][p:] == w2[2][p:]
                    assert all(w1[3].get(i) == w2[3].get(i) for i in range(p, n - 1))
                    assert _key(full_unit(*w1[1:], settings, t)) != _key(full_unit(*w2[1:], settings, t))
                    return {"prefix_gadgets": [w1[0], w2[0]], "units": [str(u1), str(u2)]}
    return None


def run(worlds, settings, rng_targets, budget=300):
    """For every world: certify with C09, then look for a witness at every position p in (cert.first, t-2]."""
    stats = {"worlds": 0, "positions_checked": 0, "witness_found": 0, "undetermined": 0, "worlds_all_forced": 0,
             "extra_backward_hist": {}}
    examples, undetermined = [], []
    rng = random.Random(5301)
    for w in worlds:
        case = G.make_case(*w, settings)
        t = rng_targets.randrange(25, 55)
        cert = G.certify(case, t)
        assert cert["status"] == "Certified" and cert["unit"] == G.unit_of(G.plan(case), t)
        stats["worlds"] += 1
        lo, hi = cert["first"] + 1, max(0, t - 2)
        extra = max(0, hi - cert["first"])
        stats["extra_backward_hist"][extra] = stats["extra_backward_hist"].get(extra, 0) + 1
        all_forced = True
        for p in range(lo, hi + 1):
            stats["positions_checked"] += 1
            wit = None
            for win in (3, 6, 10):
                wit = find_witness(w, settings, t, p, rng, budget, window=win)
                if wit:
                    wit["window"] = win
                    break
            if wit:
                stats["witness_found"] += 1
                if len(examples) < 3:
                    examples.append({"t": t, "cert_first": cert["first"], "p": p, **wit})
            else:
                stats["undetermined"] += 1
                all_forced = False
                if len(undetermined) < 5:
                    undetermined.append({"t": t, "cert_first": cert["first"], "p": p})
        stats["worlds_all_forced"] += all_forced
    stats["extra_backward_hist"] = dict(sorted(stats["extra_backward_hist"].items()))
    return {"stats": stats, "examples": examples, "undetermined_examples": undetermined}
