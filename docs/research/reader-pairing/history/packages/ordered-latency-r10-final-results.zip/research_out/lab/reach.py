"""Pass 1: exact order-statistic reachability and identifiable sub-intervals of the formal data.

Evidence level: anonymous historical data recomputation + derivation. No new sampling.
Everything is integer ns / exact Fraction. Output: raw/pass1/reach.json
"""
import itertools
import random
from collections import defaultdict
from fractions import Fraction

from common import (GUARD, RAW, REF_MEDIAN, T_CEIL, formal_rows, load_jsonl, median, num, write_json, PKG)


# ---------------------------------------------------------------------------
# Lemma R1 (even-n median): for n = 2m, median(y) <= T  <=>  y_(m) + y_(m+1) <= 2T.
# Consequently y_(m) <= T, i.e. at least m samples must be <= T.
# ---------------------------------------------------------------------------

def median_ok(values, T):
    return median(values) <= T


def lemma_r1_bruteforce(n_max=8, vmax=6):
    """Bounded exhaustion of Lemma R1 and its corollary on small integer domains."""
    checked = 0
    for n in range(2, n_max + 1, 2):
        m = n // 2
        for T2 in range(0, 2 * vmax + 1):  # 2T integer
            T = Fraction(T2, 2)
            for vals in itertools.combinations_with_replacement(range(vmax + 1), n):
                s = sorted(vals)
                a = median_ok(s, T)
                b = s[m - 1] + s[m] <= 2 * T
                c = sum(v <= T for v in s) >= m
                checked += 1
                if a != b or (a and not c):
                    return {"ok": False, "counterexample": [n, T2, s]}
    return {"ok": True, "checked": checked, "domain": f"even n<= {n_max}, values 0..{vmax}, 2T 0..{2*vmax}"}


def min_total_reduction(base, T):
    """Minimum sum of per-sample reductions r_i >= 0 so that median(base - r) <= T (n even).

    Regressions never help the median, so the optimum only lowers samples. The optimum lowers the
    m+1 smallest samples: the m lowest to <= a and the (m+1)-th to <= 2T - a, a <= T. Cost is convex
    piecewise linear in a; we minimise exactly over all breakpoints.
    """
    v = sorted(base)
    n = len(v)
    assert n % 2 == 0
    m = n // 2
    low, nxt = v[:m], v[m]
    cands = {Fraction(T)} | {Fraction(x) for x in low if x <= T} | {Fraction(2 * T - nxt)}
    cands = {a for a in cands if a <= T}
    best = None
    for a in sorted(cands):
        cost = sum(max(Fraction(0), x - a) for x in low) + max(Fraction(0), nxt - (2 * T - a))
        if best is None or cost < best[0]:
            best = (cost, a)
    return {"min_total_reduction_ns": best[0], "a_ns": best[1],
            "samples_that_must_change": sum(1 for x in v[:m + 1] if x > T),
            "per_sample_cut_ns_sorted": [max(0, x - T) for x in v[:m + 1]]}


def restricted_feasibility(rows, T, frozen_scenarios):
    """If samples of `frozen_scenarios` keep their latency, can any change of the others pass?"""
    n = len(rows)
    m = n // 2
    frozen = [r["unit_latency_ns"] for r in rows if r["scenario"] in frozen_scenarios]
    free = n - len(frozen)
    # Best case: every free sample goes to 0.
    best = sorted(frozen + [0] * free)
    feasible = best[m - 1] + best[m] <= 2 * T
    return {"frozen": sorted(frozen_scenarios), "free_samples": free, "frozen_samples": len(frozen),
            "frozen_le_T": sum(x <= T for x in frozen), "feasible_even_if_free_go_to_zero": feasible}


def per_scenario_requirement(rows, T):
    """Necessary: at least n/2 samples <= T. Count how many each scenario can at most supply."""
    by = defaultdict(list)
    for r in rows:
        by[r["scenario"]].append(r["unit_latency_ns"])
    return {s: {"n": len(v), "min_ns": min(v), "median_ns": median(v), "cut_to_T_for_min_ns": max(0, min(v) - T)}
            for s, v in sorted(by.items())}


def partner_gap(rows):
    out = defaultdict(list)
    for r in rows:
        out[(r["group"], r["scenario"], r["target_object"])].append(r["unit_ack_ns"] - r["target_ack_ns"])
    res = {}
    for k, v in sorted(out.items()):
        res["/".join(map(str, k))] = {"n": len(v), "min": min(v), "median": median(v), "max": max(v), "zeros": sum(x == 0 for x in v)}
    return res


def first_member_bound(rows, T):
    """Mechanisms acting only after the first member ack cannot push L below target_latency.

    So median(L_candidate) >= median(target_latency) for any such mechanism (componentwise L >= target_latency)."""
    res = {}
    for g in ["F0", "F1"]:
        tl = [r["target_latency_ns"] for r in rows if r["group"] == g]
        ul = [r["unit_latency_ns"] for r in rows if r["group"] == g]
        gaps = [u - t for u, t in zip(ul, tl)]
        res[g] = {"median_unit": median(ul), "median_target": median(tl), "max_saving_by_partner_only": median(ul) - median(tl),
                  "sum_gap_ns": sum(gaps), "partner_only_can_reach_T": median(tl) <= T}
    return res


def idle_gaps(rows):
    """Previous complete-unit ack to next intent inside one clock scope (same group)."""
    res = {}
    for g in ["F0", "F1"]:
        rs = sorted([r for r in rows if r["group"] == g], key=lambda r: r["intent_ns"])
        chain, first = [], []
        for prev, r in zip(rs, rs[1:]):
            gap = r["intent_ns"] - prev["unit_ack_ns"]
            assert gap >= 0
            (chain if (r["scenario"] == "advance" and prev["scenario"] == "advance" and prev["runtime"] == r["runtime"]) else first).append(
                {"sample": r["sample"], "scenario": r["scenario"], "gap_ns": gap})
        res[g] = {"within_advance_chain": {"n": len(chain), "min": min(x["gap_ns"] for x in chain),
                                           "median": median([x["gap_ns"] for x in chain]),
                                           "max": max(x["gap_ns"] for x in chain)},
                  "other_transitions": {"n": len(first), "min": min(x["gap_ns"] for x in first),
                                        "median": median([x["gap_ns"] for x in first]), "max": max(x["gap_ns"] for x in first)},
                  "chain_rows": chain}
    return res


def chain_throughput(rows):
    """Back-to-back advance chains: wall span from the chain's first intent to last unit ack."""
    res = []
    for g in ["F0", "F1"]:
        rs = sorted([r for r in rows if r["group"] == g and r["scenario"] == "advance"], key=lambda r: r["intent_ns"])
        by = defaultdict(list)
        for r in rs:
            by[r["runtime"]].append(r)
        for rt, ch in sorted(by.items()):
            span = ch[-1]["unit_ack_ns"] - ch[0]["intent_ns"]
            lat = sum(r["unit_latency_ns"] for r in ch)
            res.append({"group": g, "runtime": rt, "samples": len(ch), "span_ns": span, "sum_latency_ns": lat,
                        "sum_gaps_ns": span - lat, "pre_chain_idle_ns": ch[0]["intent_ns"] - ch[0]["setup_ready_ns"]})
    return res


def rounds_vs_latency(rows):
    """Within identical design cells (group, scenario, target): pairs whose rounds differ >= 5x."""
    cells = defaultdict(list)
    for r in rows:
        cells[(r["group"], r["scenario"], r["target_object"])].append(r)
    pairs = []
    for k, rs in cells.items():
        for a, b in itertools.combinations(rs, 2):
            lo, hi = sorted([a, b], key=lambda r: r["observed_rounds"])
            if hi["observed_rounds"] >= 5 * lo["observed_rounds"]:
                pairs.append({"cell": list(k), "low_rounds": [lo["sample"], lo["observed_rounds"], lo["unit_latency_ns"]],
                              "high_rounds": [hi["sample"], hi["observed_rounds"], hi["unit_latency_ns"]],
                              "latency_diff_ns": hi["unit_latency_ns"] - lo["unit_latency_ns"]})
    return pairs


def support_vs_position(rows):
    res = {}
    for g in ["F0", "F1"]:
        for s in ["new_start", "reopen"]:
            for t in [29, 169]:
                v = [r for r in rows if r["group"] == g and r["scenario"] == s and r["target_object"] == t]
                res[f"{g}/{s}/{t}"] = {"n": len(v), "support": len(v[0]["support_objects"]),
                                       "support_range": [min(v[0]["support_objects"]), max(v[0]["support_objects"])],
                                       "median_latency": median([r["unit_latency_ns"] for r in v]),
                                       "rounds": sorted(r["observed_rounds"] for r in v)}
    return res


def rejected_first_slot(path):
    rows = load_jsonl(path)
    wrong = [r for r in rows if r["actual_objects"] is not None and r["actual_objects"] != r["expected_objects"]]
    missing = [r for r in rows if r["actual_objects"] is None]
    return {"planned": len(rows), "wrong_members": [[r["sample"], r["scenario"], r["target_object"], r["expected_objects"], r["actual_objects"]] for r in wrong],
            "missing_unit": [[r["sample"], r["scenario"], r["failure_detail"]] for r in missing],
            "note": "R0 replaced candidate: wrong first unit at target 169 ([169,170] instead of [168,169]). Known cause "
                    "(INPUT_ERRATA E3): complete certification/canonical was correct; the publication/history layer locked a guessed "
                    "result before Certified. NOT an instance of fixed-window truncation. Success subset may not be used for gain."}


def guard_slack(rows):
    """Group regression guards only bound regressions; report the improvement each group would need anyway."""
    out = []
    for fam, fields in [("target", ["target_object"]), ("action", ["scenario", "action", "target_object"])]:
        groups = defaultdict(list)
        for r in rows:
            if r["group"] == "F0":
                groups[tuple(r[f] for f in fields)].append(r["unit_latency_ns"])
        for k, v in sorted(groups.items(), key=lambda kv: str(kv[0])):
            out.append({"family": fam, "key": list(k), "n": len(v), "F0_median": median(v), "allowed_candidate_median_max": median(v) + GUARD})
    return out


def null_rerun_demo():
    pass


def main():
    rows = formal_rows()
    T = T_CEIL
    out = {"evidence_level": "historical recomputation + derivation (no new sampling)", "T_ceiling_ns": T}
    out["lemma_r1"] = lemma_r1_bruteforce()
    for g in ["F0", "F1"]:
        base = [r["unit_latency_ns"] for r in rows if r["group"] == g]
        s = sorted(base)
        out[f"{g}_order"] = {"x25": s[24], "x26": s[25], "median": median(base), "min": s[0],
                             "count_le_T": sum(x <= T for x in base),
                             "x25_x26_scenarios": [r["scenario"] for r in sorted([r for r in rows if r["group"] == g], key=lambda r: r["unit_latency_ns"])[24:26]]}
        out[f"{g}_min_reduction"] = min_total_reduction(base, T)
        grows = [r for r in rows if r["group"] == g]
        out[f"{g}_restricted"] = [restricted_feasibility(grows, T, fz) for fz in
                                  [{"advance"}, {"new_start", "reopen"}, {"new_start"}, {"reopen"}]]
        out[f"{g}_per_scenario"] = per_scenario_requirement(grows, T)
        out[f"{g}_uniform"] = {"additive_shift_needed_ns": median(base) - T,
                               "multiplicative_factor_max": Fraction(T) / median(base)}
    out["partner_gap"] = partner_gap(rows)
    out["first_member_bound"] = first_member_bound(rows, T)
    out["idle_gaps"] = idle_gaps(rows)
    out["chain_throughput"] = chain_throughput(rows)
    out["rounds_vs_latency_pairs"] = rounds_vs_latency(rows)
    out["support_vs_position"] = support_vs_position(rows)
    out["rejected_R0"] = rejected_first_slot(PKG / "data/rejected_samples.jsonl")
    out["guard_slack"] = guard_slack(rows)
    write_json(RAW / "pass1/reach.json", out)
    return out


if __name__ == "__main__":
    o = main()
    import json
    brief = {k: o[k] for k in ["lemma_r1", "F0_order", "F0_min_reduction", "F1_min_reduction", "F0_restricted", "F0_uniform",
                               "first_member_bound", "chain_throughput"]}
    brief["idle"] = {g: {k: v for k, v in o["idle_gaps"][g].items() if k != "chain_rows"} for g in o["idle_gaps"]}
    brief["rounds_pairs"] = o["rounds_vs_latency_pairs"]
    print(json.dumps(brief, default=str, indent=1)[:9000])
