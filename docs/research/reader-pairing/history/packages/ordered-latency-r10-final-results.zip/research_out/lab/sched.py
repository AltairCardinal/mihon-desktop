"""Synthetic resource/lifecycle discrete-event model for F03/F05/F06/F07/F11/F19 and the combinations.

Hypothesis model, integer time units (NOT ns, NOT calibrated). Frozen structural rules implemented:
  * required+speculative share LOGICAL_RS = 4 admission slots; optional has LOGICAL_OPT = 2 separate slots
  * all fact-side work runs on `physical` non-preemptive workers (shared by all roles; default 4)
  * optional attempts per scope <= 16 (required is NOT capped at 16)
  * byte window: reserve on start (declared upper bound), settle actual on exit, refund unused; window 32 MiB
  * cancel != exit: a cancelled running task keeps its worker and its admission slot until its real exit
  * completion results (T04 rework): a finished result with no live consumer goes to a bounded result POOL
    (capacity `mailbox`, None = unbounded). If the pool is full the result is HELD: it keeps its physical
    worker AND its logical admission slot AND its result memory until pool space frees or a consumer accepts.
    Three distinct resources are tracked: physical workers (running + held), logical slots (running + held,
    per role pool), result occupancy (pool + held). Consumption, cancel, close and late exits release each
    result exactly once (double releases are counted and must be 0).
  * consumer stall: `stall_until[consumer]` delays acceptance by that consumer (e.g. a UI pause)
  * acceptance is recorded PER CONSUMER (`Task.accepted_by`); a result delivered to one live consumer is
    consumer-side afterwards (its producer-side occupancy is released once) and another registered consumer accepts
    it only when that consumer itself is live (no producer resource changes hands a second time)
  * consumption (`consume[c] = (needed task ids, service)`, fix F3 of the closing round): consumer c starts
    consuming only when c is live AND c has accepted every needed result; a live consumer accepts a needed,
    finished result (from the pool/held, or already delivered) at that moment. consume_done = start + service.
    A consumption is discarded (never recorded as done) if the scope closes before it ends, if a needed task is
    cancelled before it ends, or if c's need set changes (the old completion event is stale). A completion recorded
    before a need-set change is moved to `consumption_superseded`. After close() the consumption state is frozen:
    later need changes neither start nor supersede anything (a completion before close stays valid)
  * visible consumption runs on its own path (consume lane(s)), not limited by the fact-side slots
  * close: request -> logical close (reject new work, cancel all) -> physical drain (last real exit) -> release
Policies are plain functions so that two mechanisms can be compared on identical inputs and ledgers.
"""
import heapq
import itertools
from dataclasses import dataclass, field

LOGICAL_RS, LOGICAL_OPT, OPT_CAP = 4, 2, 16
WINDOW_BYTES = 32 * 1024 * 1024


@dataclass
class Task:
    id: str
    role: str                    # required | speculative | optional
    service: int                 # physical service units once started
    release: int = 0
    deps: tuple = ()
    consumers: set = field(default_factory=set)
    bytes_upper: int = 0
    bytes_actual: int = 0
    segments: int = 1            # cooperative exit points: can stop at k*service/segments boundaries
    obj: str = ""
    # runtime
    state: str = "pending"       # pending|queued|running|exited
    start: int = None
    end: int = None
    cancelled: bool = False
    upgraded_at: int = None
    accepted: bool = False
    done: bool = False           # service finished and result not cancelled
    released: bool = False       # result occupancy released (accepted/dropped)
    accepted_at: int = None      # first acceptance by any consumer (kept for C05/Q028)
    accepted_by: dict = field(default_factory=dict)   # consumer -> acceptance time (per consumer)
    failed: bool = False         # service ends with an exception: no result, worker/slot/bytes released at exit


class Sim:
    def __init__(self, tasks, physical=4, mailbox=None, policy="priority", reserve_required=0,
                 spec_budget=None, borrow=False, upgrade="in_place", segment_exit=False, opt_slots=LOGICAL_OPT,
                 rs_slots=LOGICAL_RS, window=WINDOW_BYTES, consume=None, trace=False, reserve_physical=0,
                 stall_until=None, pool_policy="fifo", pool_reserved_required=0, result_size=None, gate=None,
                 pool_reserved_unit=0, unit_of=None, drop_on_full=False, after_event=None):
        self.tasks = {t.id: t for t in tasks}
        self.physical, self.mailbox_cap = physical, mailbox
        self.policy, self.reserve_required = policy, reserve_required
        self.spec_budget, self.borrow, self.upgrade, self.segment_exit = spec_budget, borrow, upgrade, segment_exit
        self.opt_slots, self.rs_slots, self.window = opt_slots, rs_slots, window
        self.reserve_physical = reserve_physical  # physical workers kept free for required work
        self.consume = consume or {}       # consumer -> (set of task ids it needs, consume service)
        self.now = 0
        self.events = []
        self.seq = itertools.count()
        self.used_bytes = 0
        self.opt_attempted = 0
        self.mailbox = []            # result pool (task ids), bounded by mailbox_cap
        self.held = []               # completed results waiting for pool space; they keep worker + slot
        self.stall_until = dict(stall_until or {})
        self.pool_policy = pool_policy              # 'fifo' | 'required_first' (drain/admit required results first)
        self.pool_reserved_required = pool_reserved_required  # pool places only required results may use
        self.result_size = result_size or (lambda t: 1)
        self.gate = gate                            # optional admission predicate gate(sim, task) -> bool
        self.pool_reserved_unit = pool_reserved_unit  # pool places reserved for members of an awaited unit
        self.unit_of = unit_of or (lambda t: None)  # task -> unit id (or None for independent results)
        self.drop_on_full = drop_on_full            # speculative result dropped (recompute later) instead of held
        self.after_event = after_event              # consumer policy hook, called after every event (exact timing)
        self.dropped = []
        self.violations = []
        self.release_calls = {}
        self.held_since, self.held_worker_time = {}, 0
        self.result_releases, self.double_releases = 0, 0
        self.peak_resident = 0
        self.log = [] if trace else None
        self.consumer_done = {}                     # consumer -> completion time (valid completions only)
        self._consumption = {}                      # consumer -> {"key", "token", "start"} of the current consumption
        self.consumption_discarded = []             # (time, consumer, reason) of consumptions that did not complete
        self.consumption_superseded = []            # (time, consumer, old completion, old need) when the need set changes
        self._stall_scheduled = {}                  # consumer -> stall end for which a stall_end event is queued
        self.work = 0
        self.closed_at = None
        self.peak = {"running": 0, "mailbox": 0, "bytes": 0, "held": 0, "resident_results": 0}
        for t in tasks:
            self._push(t.release, "release", t.id)

    # -------------------------------------------------------------- helpers
    def _push(self, at, kind, ref):
        heapq.heappush(self.events, (at, next(self.seq), kind, ref))

    def _note(self, *a):
        if self.log is not None:
            self.log.append((self.now,) + a)

    def running(self, roles=None):
        """Tasks occupying a physical worker and a logical slot: running OR completed-but-held."""
        return [t for t in self.tasks.values() if t.state in ("running", "held") and (roles is None or t.role in roles)]

    def queued(self):
        return [t for t in self.tasks.values() if t.state == "queued"]

    def deps_done(self, t):
        return all(self.tasks[d].done for d in t.deps)

    def logical_ok(self, t):
        rs = len([x for x in self.running(("required", "speculative"))])
        op = len(self.running(("optional",)))
        if t.role in ("required", "speculative"):
            if rs >= self.rs_slots:
                return False
            if t.role == "speculative":
                if self.spec_budget is not None and len(self.running(("speculative",))) >= self.spec_budget:
                    return False
                # keep `reserve_required` slots free for required work unless borrowing is allowed and no
                # required work is visible
                free_after = self.rs_slots - rs - 1
                if free_after < self.reserve_required and not (self.borrow and not self._visible_required()):
                    return False
            return True
        if op >= self.opt_slots or self.opt_attempted >= OPT_CAP:
            return False
        return True

    def _visible_required(self):
        return any(t.role == "required" and t.state in ("queued", "pending") and t.release <= self.now and not t.cancelled
                   for t in self.tasks.values())

    def physical_free(self):
        return self.physical - len(self.running())

    def pool_has_space(self, t):
        if self.mailbox_cap is None:
            return True
        free = self.mailbox_cap - len(self.mailbox)
        if t.role != "required":
            free -= max(0, self.pool_reserved_required - sum(1 for x in self.mailbox if self.tasks[x].role == "required"))
        if self.unit_of(t) is None:
            free -= max(0, self.pool_reserved_unit - sum(1 for x in self.mailbox if self.unit_of(self.tasks[x]) is not None))
        return free > 0

    def consumer_live(self, t):
        return any(self.live(c) for c in t.consumers)

    def live(self, c):
        return self.now >= self.stall_until.get(c, -1)

    def _mark_accepted(self, t, consumer):
        t.accepted_by.setdefault(consumer, self.now)
        if t.accepted_at is None:
            t.accepted_at = self.now

    def _release_result(self, t, how):
        self.release_calls[t.id] = self.release_calls.get(t.id, 0) + 1
        if t.released:
            self.double_releases += 1
            return
        t.released = True
        self.result_releases += 1
        self._note("result_release", t.id, how)

    def _place_result(self, t):
        """Called when service ends (not cancelled): deliver, pool, or hold."""
        if t.consumers and self.consumer_live(t):
            t.state, t.accepted = "delivered", True
            for c in sorted(t.consumers):
                if self.live(c):
                    self._mark_accepted(t, c)
            self._release_result(t, "delivered")
        elif self.pool_has_space(t):
            t.state = "pooled"
            self.mailbox.append(t.id)
        elif self.drop_on_full and t.role != "required":
            t.state, t.done = "exited", False      # result discarded; must be recomputed if demanded later
            self.dropped.append(t.id)
            self._release_result(t, "dropped_full")
        else:
            t.state = "held"
            self.held.append(t.id)
            self.held_since[t.id] = self.now
        self._account()

    def _unhold(self, tid):
        if tid in self.held_since:
            self.held_worker_time += self.now - self.held_since.pop(tid)

    def _account(self):
        self.peak["mailbox"] = max(self.peak["mailbox"], len(self.mailbox))
        self.peak["held"] = max(self.peak["held"], len(self.held))
        # shared underlying resources are counted once (dedupe by obj when set)
        seen, res = set(), 0
        for x in self.mailbox + self.held:
            t = self.tasks[x]
            key = t.obj or t.id
            if key not in seen:
                seen.add(key)
                res += self.result_size(t)
        self.peak["resident_results"] = max(self.peak["resident_results"], res)

    def _refill_pool(self):
        order = list(self.held)
        if self.pool_policy == "required_first":
            order.sort(key=lambda x: (self.tasks[x].role != "required", self.held.index(x)))
        elif self.pool_policy == "unit_first":
            order.sort(key=lambda x: (self.unit_of(self.tasks[x]) is None, self.held.index(x)))
        for x in order:
            t = self.tasks[x]
            if self.pool_has_space(t):
                self.held.remove(x)
                self._unhold(x)
                t.state = "pooled"
                self.mailbox.append(x)
        self._account()

    def accept(self, tid, consumer="consumer"):
        t = self.tasks[tid]
        if t.state in ("pooled", "held"):
            (self.mailbox if t.state == "pooled" else self.held).remove(tid)
            self._unhold(tid)
            t.state, t.accepted = "delivered", True
            t.consumers.add(consumer)
            self._mark_accepted(t, consumer)
            self._release_result(t, "accepted")
            self._refill_pool()
        elif t.state == "delivered" and not t.cancelled and consumer not in t.accepted_by:
            t.consumers.add(consumer)                 # already consumer-side: no producer resource changes hands
            self._mark_accepted(t, consumer)

    def accept_all(self, consumer="consumer"):
        order = list(self.mailbox) + list(self.held)
        if self.pool_policy == "required_first":
            order.sort(key=lambda x: self.tasks[x].role != "required")
        for x in order:
            self.accept(x, consumer)

    def order(self, cands):
        if self.policy == "fifo":
            return sorted(cands, key=lambda t: (t.release, t.id))
        rank = {"required": 0, "speculative": 1, "optional": 2}
        return sorted(cands, key=lambda t: (rank[t.role], t.release, t.id))

    # -------------------------------------------------------------- dispatcher
    def dispatch(self):
        if self.closed_at is not None:
            return
        progress = True
        while progress:
            progress = False
            for t in self.order([x for x in self.queued() if self.deps_done(x) and not x.cancelled]):
                if self.physical_free() <= 0:
                    return
                if not self.logical_ok(t):
                    continue
                if t.role != "required" and self.physical_free() <= self.reserve_physical:
                    continue
                if self.used_bytes + t.bytes_upper > self.window:
                    continue
                if self.gate is not None and not self.gate(self, t):
                    continue
                t.state, t.start = "running", self.now
                self.used_bytes += t.bytes_upper
                if t.role == "optional":
                    self.opt_attempted += 1
                self._push(self.now + t.service, "exit", t.id)
                self._note("start", t.id, t.role)
                self.peak["running"] = max(self.peak["running"], len(self.running()))
                self.peak["bytes"] = max(self.peak["bytes"], self.used_bytes)
                progress = True
                break

    # -------------------------------------------------------------- external actions
    def cancel(self, tid):
        t = self.tasks[tid]
        t.cancelled = True
        if t.state in ("pooled", "held"):
            (self.mailbox if t.state == "pooled" else self.held).remove(tid)
            self._unhold(tid)
            t.state, t.done = "exited", False
            self._release_result(t, "cancelled")
            self._refill_pool()
            return
        if t.state in ("pending", "queued"):
            t.state = "exited"
            t.end = self.now
            self._note("cancel_queued", tid)
        elif t.state == "running" and self.segment_exit and t.segments > 1:
            seg = t.service // t.segments
            done = self.now - t.start
            nxt = t.start + ((done + seg - 1) // seg) * seg if seg else self.now
            self._push(max(nxt, self.now), "exit", tid)   # cooperative exit at next segment boundary
            self._note("cancel_running_segment", tid, nxt)
        else:
            self._note("cancel_running_noop", tid)

    def upgrade_task(self, tid, consumer):
        t = self.tasks[tid]
        if self.upgrade == "in_place":
            if t.role == "speculative":
                t.role = "required"
            t.upgraded_at = self.now
            t.consumers.add(consumer)
            self._note("upgrade_in_place", tid)
            return tid
        # cancel-and-restart (anti-pattern used as a control): new physical work for the same object
        self.cancel(tid)
        nid = tid + "'"
        while nid in self.tasks:                     # a second restart must not overwrite a running replacement
            nid += "'"
        nt = Task(nid, "required", t.service, self.now, t.deps, {consumer}, t.bytes_upper, t.bytes_actual, t.segments, t.obj)
        nt.state = "queued"
        self.tasks[nid] = nt
        self._note("upgrade_restart", tid, nid)
        return nid

    def close(self):
        self.closed_at = self.now
        for t in self.tasks.values():
            if t.state in ("pending", "queued", "running"):
                self.cancel(t.id)
        for x in list(self.mailbox) + list(self.held):   # drop unconsumed results, each released once
            t = self.tasks[x]
            self._unhold(x)
            t.state = "exited"
            self._release_result(t, "closed")
        self.mailbox.clear()
        self.held.clear()
        self._note("close_logical")

    # -------------------------------------------------------------- main loop
    def run(self, actions=(), until=None):
        """actions: list of (time, callable(sim)) external events."""
        for at, fn in actions:
            self._push(at, "action", fn)
        self._schedule_stall_ends()
        while self.events:
            at, _, kind, ref = heapq.heappop(self.events)
            if until is not None and at > until:
                break
            self.now = at
            if kind == "release":
                t = self.tasks[ref]
                if t.state == "pending" and not t.cancelled:
                    if self.closed_at is not None:
                        t.state, t.end = "exited", self.now
                    else:
                        t.state = "queued"
            elif kind == "exit":
                t = self.tasks[ref]
                if t.state != "running":
                    continue
                t.end = self.now
                self.work += t.end - t.start
                self.used_bytes -= t.bytes_upper   # byte reservation settled once at the real exit
                if t.failed and not t.cancelled:
                    t.state = "exited"             # exception: no result; resources settle once at the real exit
                elif not t.cancelled and self.closed_at is None:
                    t.done = True
                    self._place_result(t)
                else:
                    t.state = "exited"             # late/cancelled completion: discarded, nothing to release
                self._note("exit", ref, "cancelled" if t.cancelled else t.state)
            elif kind == "action":
                ref(self)
            elif kind == "consume_done":
                self._finish_consumption(*ref)
            elif kind == "stall_end" and self.live(ref):   # an outdated stall_end (stall extended later) does nothing
                for x in list(self.mailbox) + list(self.held):
                    if ref in self.tasks[x].consumers:
                        self.accept(x, ref)
                for t in self.tasks.values():
                    if t.state == "delivered" and ref in t.consumers and ref not in t.accepted_by:
                        self.accept(t.id, ref)
            self._schedule_stall_ends()              # stall_until changed by an action/hook after run() started
            self._check_consumers()
            if self.after_event is not None:
                self.after_event(self)
                self._schedule_stall_ends()          # a hook may change stall_until too
                self._check_consumers()
            self.dispatch()
            self._invariants()
        return self

    def _invariants(self):
        """Capacity invariants checked after EVERY event (T04): violations are recorded, never silently clipped."""
        v = self.violations
        if self.mailbox_cap is not None and len(self.mailbox) > self.mailbox_cap:
            v.append((self.now, "pool_over_capacity", len(self.mailbox)))
        if len(self.running()) > self.physical:
            v.append((self.now, "workers_over_capacity", len(self.running())))
        if len(self.running(("required", "speculative"))) > self.rs_slots:
            v.append((self.now, "rs_slots_over_capacity"))
        if len(self.running(("optional",))) > self.opt_slots:
            v.append((self.now, "opt_slots_over_capacity"))
        if not (0 <= self.used_bytes <= self.window):
            v.append((self.now, "byte_window", self.used_bytes))
        if len(set(self.mailbox)) != len(self.mailbox) or set(self.mailbox) & set(self.held):
            v.append((self.now, "result_in_two_places"))

    def _schedule_stall_ends(self):
        for c, at in self.stall_until.items():
            if at < 10 ** 9 and self._stall_scheduled.get(c) != at:   # 'never live' consumers: actions/hooks only
                self._stall_scheduled[c] = at
                self._push(max(at, self.now), "stall_end", c)

    def _check_consumers(self):
        """Start a consumption when the consumer is live and has accepted every needed result (fix F3)."""
        if self.closed_at is not None:
            return
        for c, (need, svc) in self.consume.items():
            key = (frozenset(need), svc)
            cur = self._consumption.get(c)
            if cur is not None and cur["key"] == key:
                continue                                  # started (or finished) for this need set
            if cur is not None:
                if c in self.consumer_done:          # a completion for the OLD need set does not count for the new one
                    self.consumption_superseded.append((self.now, c, self.consumer_done.pop(c), sorted(cur["key"][0])))
                else:
                    self.consumption_discarded.append((self.now, c, "need_changed"))
                del self._consumption[c]
            if not self.live(c):
                continue
            ready = True
            for x in sorted(need):
                t = self.tasks.get(x)
                if t is None or not t.done or t.cancelled:
                    ready = False
                    continue
                if c not in t.accepted_by:
                    self.accept(x, c)
                ready = ready and c in t.accepted_by
            if ready:
                tok = next(self.seq)
                self._consumption[c] = {"key": key, "token": tok, "start": self.now}
                self._push(self.now + svc, "consume_done", (c, tok))

    def _finish_consumption(self, c, tok):
        cur = self._consumption.get(c)
        if cur is None or cur["token"] != tok:
            self.consumption_discarded.append((self.now, c, "stale_event"))
            return
        need = cur["key"][0]
        if self.closed_at is not None:
            self.consumption_discarded.append((self.now, c, "closed"))
            return
        if any(self.tasks[x].cancelled for x in need):
            self.consumption_discarded.append((self.now, c, "input_cancelled"))
            return
        self.consumer_done[c] = self.now

    # -------------------------------------------------------------- metrics
    def metrics(self):
        return {"consumer_done": {k: v for k, v in self.consumer_done.items() if not k.startswith("_sched_")},
                "physical_work": self.work,
                "wasted_work": sum(t.end - t.start for t in self.tasks.values() if t.start is not None and t.end is not None
                                   and (t.cancelled or not (t.accepted or t.consumers))),
                "peak": dict(self.peak), "drain_end": max([t.end for t in self.tasks.values() if t.end is not None], default=0),
                "unexited": [t.id for t in self.tasks.values() if t.state == "running"],
                "results_in_pool": len(self.mailbox), "results_held_on_worker": len(self.held),
                "workers_occupied_by_held_results": sum(1 for t in self.tasks.values() if t.state == "held"),
                "result_releases": self.result_releases, "double_releases": self.double_releases,
                "dropped_results": list(self.dropped), "bytes_outstanding": self.used_bytes,
                "held_worker_time": self.held_worker_time + sum(self.now - v for v in self.held_since.values())}


# ---------------------------------------------------------------------- exact optimum for small instances
def optimal_target_completion(tasks, physical, target, rs_slots=LOGICAL_RS):
    """Exact minimum completion time of `target` over all non-preemptive schedules (idle insertion allowed),
    deterministic services/releases, admission <= rs_slots for required+speculative. Exhaustive DFS over decision
    points (small instances only). Tasks that are already running at time 0 (release<0 trick) are fixed."""
    T = {t.id: t for t in tasks}
    best = [None]
    fixed = {t.id: (t.start, t.start + t.service) for t in tasks if t.start is not None}

    def dfs(now, done, running, started):
        # running: dict id->end
        if target in done:
            c = done[target]
            if best[0] is None or c < best[0]:
                best[0] = c
            return
        if best[0] is not None and now >= best[0]:
            return
        ready = [x for x in T if x not in started and T[x].release <= now and all(d in done for d in T[x].deps)]
        free = physical - len(running)
        # option A: start any subset of ready tasks (size <= free) now
        if ready and free > 0:
            for k in range(min(free, len(ready)), 0, -1):
                for sub in itertools.combinations(ready, k):
                    if len(running) + k > rs_slots:
                        continue
                    r2 = dict(running)
                    for x in sub:
                        r2[x] = now + T[x].service
                    nxt = min(list(r2.values()) + [T[x].release for x in T if x not in started and T[x].release > now], default=None)
                    advance(nxt, done, r2, started | set(sub))
        # option B: start nothing now; wait for next event
        nxt = min(list(running.values()) + [T[x].release for x in T if x not in started and T[x].release > now], default=None)
        if nxt is not None and nxt > now:
            advance(nxt, done, running, started)

    def advance(t, done, running, started):
        if t is None:
            return
        d2 = dict(done)
        r2 = {}
        for x, e in running.items():
            if e <= t:
                d2[x] = e
            else:
                r2[x] = e
        dfs(t, d2, r2, started)

    running0 = {x: e for x, (s, e) in fixed.items()}
    dfs(0, {}, running0, set(fixed))
    return best[0]
