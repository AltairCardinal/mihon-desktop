"""Possible worlds Ω(K), target projections π_tΓ and certificate soundness/completeness on bounded domains.

Uses gamma.py (researcher reconstruction of Γ). Knowledge per object is one of
  none      : analysis NotAnalyzed, no descriptor
  dim       : descriptor known (state only; side unresolved)
  full      : analysis Computed (state + side)
and per edge (i,i+1): unknown | Computed(score). Worlds are complete assignments.
Domains:
  shape(n)      automatic off, state in {X,Y}; settings vary (forced/manual/opening)
  auto(n)       automatic on, state in {X,Y}, side in {L,R,U}, score in {None,1,2}
Everything is exhaustive inside the declared bounds unless a function says 'sampled'.
"""
import itertools
import random
from functools import lru_cache

import gamma as G

SIDES = (G.LEFT, G.RIGHT, G.UNK)
SCORES = (None, 1, 2)


class Domain:
    def __init__(self, n, automatic, settings=None, states=("SHAPE_X", "SHAPE_Y"), sides=SIDES, scores=SCORES):
        self.n, self.automatic = n, automatic
        self.settings = dict(settings or {}, automatic=automatic)
        self.states, self.sides, self.scores = states, (sides if automatic else (G.UNK,)), (scores if automatic else (None,))
        self.worlds = list(itertools.product(itertools.product(self.states, repeat=n),
                                             itertools.product(self.sides, repeat=n),
                                             itertools.product(self.scores, repeat=max(0, n - 1))))
        self._units = {}

    def case(self, world, know=None):
        """know: (obj_levels tuple of 'none'/'dim'/'full', edge_known tuple of bool). None = all full."""
        states, sides, scores = world
        n = self.n
        if know is None:
            know = (("full",) * n, (True,) * (n - 1))
        lv, ek = know
        items = []
        for i in range(n):
            it = {"id": f"o{i}", "content_version": 0, "rotation": 0, "orientation": 1}
            if lv[i] == "full":
                it["analysis"] = G.computed(states[i], sides[i])
            else:
                it["analysis"] = {"status": "NotAnalyzed"}
                if lv[i] == "dim":
                    it["descriptor"] = G.fact(states[i])
            items.append(it)
        edges = {}
        for i in range(n - 1):
            if ek[i]:
                edges[(i, i + 1)] = {"status": "Computed", "score": scores[i], "version": 1}
        return {"items": items, "edges": edges, "settings": self.settings}

    def unit(self, w, t):
        if w not in self._units:
            self._units[w] = G.plan(self.case(w))
        return G.unit_of(self._units[w], t)

    def consistent(self, w, ref, know):
        lv, ek = know
        s1, d1, e1 = w
        s0, d0, e0 = ref
        for i in range(self.n):
            if lv[i] in ("dim", "full") and s1[i] != s0[i]:
                return False
            if lv[i] == "full" and d1[i] != d0[i]:
                return False
        for i in range(self.n - 1):
            if ek[i] and e1[i] != e0[i]:
                return False
        return True

    def projections(self, ref, know, t):
        return {self._key(self.unit(w, t)) for w in self.worlds if self.consistent(w, ref, know)}

    @staticmethod
    def _key(u):
        return (u["slots"], u["certain"], u["reason"])

    def knowledge_space(self):
        levels = ("none", "dim", "full") if self.automatic else ("none", "full")
        edge_opts = (False, True) if self.automatic else (False,)
        for lv in itertools.product(levels, repeat=self.n):
            for ek in itertools.product(edge_opts, repeat=max(0, self.n - 1)):
                yield (lv, ek)


def fact_count(know):
    lv, ek = know
    return sum({"none": 0, "dim": 1, "full": 2}[x] for x in lv) + sum(ek)


def soundness_completeness(dom, worlds=None, targets=None, knows=None, limit=None):
    """Exhaustive (or restricted) check of: Certified => π_t singleton & equal; and incompleteness gaps."""
    res = {"checked": 0, "certified": 0, "unsound": 0, "need": 0, "blocked": 0, "gap_singleton_but_not_certified": 0,
           "examples_unsound": [], "examples_gap": []}
    worlds = worlds if worlds is not None else dom.worlds
    targets = targets if targets is not None else range(dom.n)
    knows = list(knows if knows is not None else dom.knowledge_space())
    for w in worlds:
        for know in knows:
            for t in targets:
                res["checked"] += 1
                c = G.certify(dom.case(w, know), t)
                proj = dom.projections(w, know, t)
                if c["status"] == "Certified":
                    res["certified"] += 1
                    if proj != {Domain._key(c["unit"])}:
                        res["unsound"] += 1
                        if len(res["examples_unsound"]) < 3:
                            res["examples_unsound"].append({"world": w, "know": know, "t": t, "unit": c["unit"], "proj": sorted(map(str, proj))})
                else:
                    res["need" if c["status"] == "NeedFacts" else "blocked"] += 1
                    if len(proj) == 1:
                        res["gap_singleton_but_not_certified"] += 1
                        if len(res["examples_gap"]) < 5:
                            res["examples_gap"].append({"world": w, "know": know, "t": t, "status": c["status"],
                                                        "needs": c["needs"], "unit": sorted(map(str, proj))})
                if limit and res["checked"] >= limit:
                    return res
    return res


def minimal_evidence(dom, w, t):
    """Smallest fact count knowledge K (consistent with w) making π_t a singleton. Exhaustive over K-space."""
    best = None
    for know in sorted(dom.knowledge_space(), key=fact_count):
        k = fact_count(know)
        if best is not None and k > best[0]:
            break
        if len(dom.projections(w, know, t)) == 1:
            if best is None:
                best = (k, [know])
            else:
                best[1].append(know)
    return best


def adaptive_loop(dom, w, t, batch=None):
    """Simulate certify -> needs -> acquire-all-needs rounds from empty knowledge. Returns rounds and facts.

    batch: optional function(needs, know) -> extra objects to fetch speculatively (dimension level) in the
    same round; models a prefetch policy. Speculative facts that are never read by the final certificate are
    counted as waste."""
    n = dom.n
    lv = ["none"] * n
    ek = [False] * (n - 1)
    rounds, fetched = 0, 0
    while True:
        know = (tuple(lv), tuple(ek))
        c = G.certify(dom.case(w, know), t)
        if c["status"] == "Certified":
            return {"rounds": rounds, "fetched": fetched, "first": c["first"], "unit": c["unit"],
                    "support": len(c["dependent_objects"])}
        if c["status"] == "RetryableBlocked":
            return {"rounds": rounds, "blocked": True}
        rounds += 1
        want = set()
        for nd in c["needs"]:
            want.add((nd["kind"], nd["object"], nd.get("second")))
        if batch:
            for o in batch(c, know):
                if 0 <= o < n:
                    want.add(("DIMENSIONS" if not dom.automatic else "ORIGINAL_ANALYSIS", o, None))
        for kind, o, sec in want:
            if kind == "DIMENSIONS":
                if lv[o] == "none":
                    lv[o] = "dim" if dom.automatic else "full"
                    fetched += 1
            elif kind == "ORIGINAL_ANALYSIS":
                if lv[o] != "full":
                    fetched += 1 if lv[o] == "dim" else 2
                    lv[o] = "full"
            elif kind == "EDGE_SAMPLES":
                if not ek[o]:
                    ek[o] = True
                    fetched += 1
        if rounds > 4 * n + 10:
            raise AssertionError("adaptive loop did not converge")


# ---------------------------------------------------------------- faster projection tables
def observe(dom, w, know):
    lv, ek = know
    s, d, e = w
    return (tuple(s[i] if lv[i] != "none" else None for i in range(dom.n)),
            tuple(d[i] if lv[i] == "full" else None for i in range(dom.n)),
            tuple(e[i] if ek[i] else "?" for i in range(dom.n - 1)))


_TABLES = {}


def dom_signature(dom):
    """Stable key for a domain. (R10 revision, self-found SF-2: the cache used id(dom); a freed Domain's id can be
    reused by a later Domain with different settings, which then read the wrong projection table.)"""
    return (dom.n, dom.automatic, repr(sorted(dom.settings.items())), dom.states, dom.sides, dom.scores)


def proj_table(dom, know, t):
    key = (dom_signature(dom), know, t)
    if key not in _TABLES:
        tab = {}
        for w in dom.worlds:
            tab.setdefault(observe(dom, w, know), set()).add(Domain._key(dom.unit(w, t)))
        _TABLES[key] = tab
    return _TABLES[key]


def projections_fast(dom, w, know, t):
    return proj_table(dom, know, t)[observe(dom, w, know)]


def member_closure(dom, w, know, t):
    """Add the dimension facts of the true unit's members (consumption must materialise them anyway)."""
    lv, ek = know
    lv = list(lv)
    for o, _ in dom.unit(w, t)["slots"]:
        if lv[o] == "none":
            lv[o] = "dim" if dom.automatic else "full"
    return (tuple(lv), ek)


def check(dom, worlds, knows_fn, targets=None, seed=0):
    """Soundness + incompleteness classification with fast projections.
    gap classes: 'member_only' = certified once member dimensions (needed for consumption anyway) are added;
                 'extra' = still not certified -> a stronger certificate could avoid real acquisitions."""
    rng = random.Random(seed)
    res = {"checked": 0, "certified": 0, "unsound": 0, "not_certified": 0, "gap_member_only": 0, "gap_extra": 0,
           "examples_unsound": [], "examples_gap_extra": []}
    for w in worlds:
        for know in knows_fn(rng):
            for t in (targets if targets is not None else range(dom.n)):
                res["checked"] += 1
                c = G.certify(dom.case(w, know), t)
                proj = projections_fast(dom, w, know, t)
                if c["status"] == "Certified":
                    res["certified"] += 1
                    if proj != {Domain._key(c["unit"])}:
                        res["unsound"] += 1
                        if len(res["examples_unsound"]) < 3:
                            res["examples_unsound"].append({"world": w, "know": know, "t": t})
                    continue
                res["not_certified"] += 1
                if len(proj) == 1:
                    k2 = member_closure(dom, w, know, t)
                    c2 = G.certify(dom.case(w, k2), t)
                    if c2["status"] == "Certified":
                        res["gap_member_only"] += 1
                    else:
                        res["gap_extra"] += 1
                        if len(res["examples_gap_extra"]) < 4:
                            res["examples_gap_extra"].append({"world": w, "know": know, "t": t, "needs_after_members": c2["needs"]})
    return res


def projections_by_completion(dom, w, know, t, cap=5000):
    """π_t over Ω(K) by enumerating only the completions of unknown facts. Returns None if > cap completions."""
    lv, ek = know
    s0, d0, e0 = w
    choices = []
    for i in range(dom.n):
        if lv[i] == "none":
            choices.append([("s", i, st, "d", d) for st in dom.states for d in dom.sides])
        elif lv[i] == "dim":
            choices.append([("s", i, s0[i], "d", d) for d in dom.sides])
    for i in range(dom.n - 1):
        if not ek[i]:
            choices.append([("e", i, sc) for sc in dom.scores])
    size = 1
    for c in choices:
        size *= len(c)
        if size > cap:
            return None
    out = set()
    for combo in itertools.product(*choices):
        s, d, e = list(s0), list(d0), list(e0)
        for ch in combo:
            if ch[0] == "s":
                s[ch[1]], d[ch[1]] = ch[2], ch[4]
            else:
                e[ch[1]] = ch[2]
        out.add(Domain._key(dom.unit((tuple(s), tuple(d), tuple(e)), t)))
    return out
