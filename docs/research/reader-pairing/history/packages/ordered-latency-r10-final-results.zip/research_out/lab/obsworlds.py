"""Pass 1: observation-equivalent legal worlds for every formal sample (identifiability).

For each formal sample we build explicit synthetic DAG worlds (package API causal.bounds, fixed lanes) that
reproduce *every* recorded field we use: intent, target_ack, unit_ack, observed_rounds, support size, idle gap.
They differ only in unobserved stage durations. We then apply the SAME intervention in each world and show that
the candidate median lands on different sides of the 30196850 ns ceiling. This proves that "fact-side work can
reach the target" is not identifiable from the formal data. R10 revision (T01): the authorisation time C_i alone does
NOT fix the decision (phase-locked vs required-service worlds share C_i and U_i, see t01_counterexample); a lower
bound s_i on unremovable post-authorisation service (e.g. via B_i or the opportunity schedule) is needed.

All durations below are hypothesis parameters, NOT fitted observations. Output raw/pass1/obsworlds.json
"""
from fractions import Fraction

from common import RAW, T_CEIL, formal_rows, median, num, write_json
from causal import bounds


def world(row, fact_share, rounds_serial=True):
    """A legal synthetic world: fact rounds (serial, compute lane) -> authorise -> consume first -> consume partner.

    fact_share in [0,1]: fraction of target_latency spent in fact rounds before authorisation.
    The remaining (target_latency - fact) is a consumption path that starts only after authorisation.
    The partner wait (unit_ack - target_ack) is a separately observed interval after the first-member ack.
    """
    L1 = row["target_latency_ns"]
    gap = row["unit_ack_ns"] - row["target_ack_ns"]
    r = max(1, row["observed_rounds"])
    fact_total = int(Fraction(L1) * Fraction(fact_share).limit_denominator(1000))
    if rounds_serial:
        per = [fact_total // r] * r
        per[-1] += fact_total - sum(per)
    else:  # already-parallel rounds: each round spans the whole fact phase so the observation is identical
        per = [fact_total] * r
    tasks = [{"id": f"round{k}", "lower_ns": d, "upper_ns": d, "resource": "fact", "observed_service": True, "kind": "fact"}
             for k, d in enumerate(per)]
    tasks.append({"id": "consume_first", "lower_ns": L1 - fact_total, "upper_ns": L1 - fact_total, "resource": "frame",
                  "observed_service": True, "kind": "consume"})
    tasks.append({"id": "consume_partner", "lower_ns": gap, "upper_ns": gap, "resource": "frame", "observed_service": True,
                  "kind": "consume"})
    edges = [(f"round{k}", f"round{k+1}") for k in range(r - 1)] + [(f"round{r-1}", "consume_first")]
    lanes = {"fact": [[f"round{k}" for k in range(r)]] if rounds_serial else [[f"round{k}"] for k in range(r)],
             "frame": [["consume_first", "consume_partner"]]}
    if not rounds_serial:
        edges = [(f"round{k}", "consume_first") for k in range(r)]
    return tasks, edges, lanes


def evaluate(row, fact_share, intervention, rounds_serial=True):
    tasks, edges, lanes = world(row, fact_share, rounds_serial)
    base = bounds(tasks, edges, lanes)
    assert base["lower_ns"] == base["upper_ns"] == row["unit_latency_ns"], (row["sample"], base)
    first_done = base["finishes"]["consume_first"][0]
    assert first_done == row["target_latency_ns"]
    C = max([base["finishes"][t["id"]][0] for t in tasks if t["kind"] == "fact"], default=0)
    if intervention == "fact_free":
        shorten = {t["id"]: 0 for t in tasks if t["kind"] == "fact"}
    elif intervention == "fact_half":
        shorten = {t["id"]: t["upper_ns"] // 2 for t in tasks if t["kind"] == "fact"}
    elif intervention == "parallelise_rounds":
        shorten = {}
        if rounds_serial:  # re-run the scheduler with one lane per round and all rounds feeding authorisation
            r = sum(1 for t in tasks if t["kind"] == "fact")
            chains = [[f"round{k}" for k in range(r) if k % 4 == j] for j in range(min(4, r))]
            lanes = dict(lanes, fact=chains)  # frozen 4 logical required+speculative slots
            edges = [(f"round{k}", "consume_first") for k in range(r)]
    else:
        raise ValueError(intervention)
    cf = bounds(tasks, edges, lanes, shorten)
    return {"observed_L": base["upper_ns"], "C_authorised_offset": C, "counterfactual_L": cf["upper_ns"]}


def interval_route(rows):
    """Route A, restricted model class M_TI: authorisation lies in [intent, first-member ack] AND tail invariance
    holds (the post-authorisation path is unchanged by the intervention). Within M_TI the per-sample residual after
    removing all pre-authorisation work lies in [U_i - target_ack_i, U_i]. Outside M_TI (phase-locked or queued
    consumption) the residual can be smaller than U_i - target_ack_i (see t01_counterexample): the interval is NOT
    a bound over all compatible worlds."""
    lo = [r["unit_ack_ns"] - r["target_ack_ns"] for r in rows]
    hi = [r["unit_latency_ns"] for r in rows]
    return {"candidate_median_interval_ns": [median(lo), median(hi)], "ceiling_ns": T_CEIL,
            "decision_identified": not (median(lo) <= T_CEIL <= median(hi)),
            "model_class": "M_TI only (tail invariance); not all compatible decompositions",
            "note": "the interval straddles the ceiling -> the GO/NO-GO decision for pre-authorisation mechanisms is not identified even inside M_TI"}


def main():
    rows = [r for r in formal_rows() if r["group"] == "F0"]
    out = {"evidence_level": "derivation with explicit synthetic worlds; durations are hypotheses",
           "observed_fields_reproduced": ["intent_ns", "target_ack_ns", "unit_ack_ns", "observed_rounds (as round count)",
                                          "support_objects (unchanged)", "idle gaps (outside window, untouched)"],
           "worlds": {}}
    for name, share in [("W_fact_bound", Fraction(9, 10)), ("W_consume_bound", Fraction(1, 50)), ("W_mid", Fraction(1, 2))]:
        res = {}
        for iv in ["fact_free", "fact_half"]:
            per = [evaluate(r, share, iv) for r in rows]
            cf = [p["counterfactual_L"] for p in per]
            res[iv] = {"median_ns": median(cf), "passes_ceiling": median(cf) <= T_CEIL,
                       "observed_median_ns": median([p["observed_L"] for p in per])}
        res["median_unit_minus_C_ns"] = median([r["unit_latency_ns"] - evaluate(r, share, "fact_free")["C_authorised_offset"] for r in rows])
        out["worlds"][name] = {"fact_share_of_first_member_latency": share, **res}
    # Decision rule (R10 revision: the old C_i-only rule is retracted, see T01):
    out["decision_rule_RETRACTED"] = ("old: 'if median(U_i - C_i) > T, pre-authorisation-only mechanisms cannot pass' - RETRACTED: "
                                      "valid only under tail invariance; refuted by t01_counterexample")
    out["decision_rule"] = ("revised: if median_i(s_i) > T where s_i is an established lower bound on post-authorisation service "
                            "that no pre-authorisation intervention removes, pre-authorisation-only mechanisms cannot pass; "
                            "median(U_i - C_i) may replace s_i only when tail invariance has been tested")
    out["T01"] = t01_check()
    # Distinguishing power: all worlds agree on every recorded field but differ in C_i.
    out["worlds_agree_on_recorded_fields"] = True
    out["serial_vs_parallel_rounds"] = {}
    for name, ser in [("serial", True), ("parallel", False)]:
        per = [evaluate(r, Fraction(9, 10), "parallelise_rounds", ser) for r in rows]
        out["serial_vs_parallel_rounds"][name] = {"intervention": "parallelise fact rounds over the 4 shared logical slots",
                                                  "median_observed_ns": median([p["observed_L"] for p in per]),
                                                  "median_cf_ns": median([p["counterfactual_L"] for p in per]),
                                                  "passes_ceiling": median([p["counterfactual_L"] for p in per]) <= T_CEIL}
    out["route_A_interval_model_class_M_TI"] = interval_route(rows)
    write_json(RAW / "pass1/obsworlds.json", out)
    return out


# ============================================================================ T01 rework (2026-10-27 revision)
# The old decision rule assumed that the post-authorisation duration U_i - C_i is unchanged by any intervention
# that only shortens pre-authorisation work ("tail invariance", TI). It is false when consumption is phase-locked
# to discrete opportunities, queued behind other work, or coupled through shared resources.

T_MS = Fraction(30196850, 10**6)


def phase_world(C, opportunities=(Fraction(4), Fraction(13019685, 10**5))):
    """World P: consumption happens at the first opportunity >= C; service at the opportunity is 0."""
    return min(o for o in opportunities if o >= C)


def service_world(C, service=Fraction(12519685, 10**5)):
    """World S: after authorisation an unremovable consumption service of 125.19685 ms runs immediately."""
    return C + service


def t01_counterexample(n=50):
    out = {}
    for name, fn in (("P_phase_locked", phase_world), ("S_required_service", service_world)):
        C0, C1 = Fraction(5), Fraction(3)
        U0, U1 = fn(C0), fn(C1)
        old_stat = median([U0 - C0] * n)
        cand = median([U1] * n)
        out[name] = {"original_C_ms": float(C0), "original_U_ms": float(U0), "old_median_U_minus_C_ms": float(old_stat),
                     "old_rule_says_no_go": old_stat > T_MS,
                     "intervention": "shorten only pre-authorisation work: C 5 -> 3 ms (backend and opportunities unchanged)",
                     "candidate_U_ms": float(U1), "candidate_median_ms": float(cand), "candidate_passes": cand <= T_MS}
    P, S_ = out["P_phase_locked"], out["S_required_service"]
    out["old_proposition_refuted"] = P["old_rule_says_no_go"] and P["candidate_passes"]
    out["same_observation_with_C_i"] = (P["original_C_ms"], P["original_U_ms"]) == (S_["original_C_ms"], S_["original_U_ms"])
    # minimal extra observation that separates them: start of post-authorisation busy service B_i (or the
    # opportunity schedule). P: B = 130.19685 (service 0 at the opportunity); S: B = 5 (service 125.19685).
    out["separating_observation"] = {"P": {"B_ms": float(phase_world(Fraction(5))), "required_service_ms": 0.0},
                                     "S": {"B_ms": 5.0, "required_service_ms": 125.19685}}
    out["note"] = "synthetic counterexample to a general proposition; not a real gain estimate"
    return out


def revised_rule(samples):
    """Revised sufficient NO-GO rule. Each sample supplies s_i = an established lower bound on post-authorisation
    service that NO pre-authorisation intervention can remove (required service, not measured waiting).
    If median_i(s_i) > T then every pre-authorisation-only intervention fails, because L'_i >= s_i for all i
    and the median is monotone. Without s_i (only C_i, U_i) the rule is valid only under tail invariance TI."""
    s = [x["required_service_ms"] for x in samples]
    return {"median_required_service_ms": float(median(s)), "no_go": median(s) > T_MS}


def t01_check():
    P = [{"required_service_ms": Fraction(0)}] * 50
    S_ = [{"required_service_ms": Fraction(12519685, 10**5)}] * 50
    rp, rs = revised_rule(P), revised_rule(S_)
    ce = t01_counterexample()
    return {"counterexample": ce,
            "revised_rule_on_P": rp, "revised_rule_on_S": rs,
            "revised_rule_consistent_with_P": (not rp["no_go"]) and ce["P_phase_locked"]["candidate_passes"],
            "revised_rule_consistent_with_S": rs["no_go"] and not ce["S_required_service"]["candidate_passes"],
            "tail_invariance": {
                "statement": "TI: for every admissible pre-authorisation intervention, U'_i - C'_i >= U_i - C_i",
                "holds_when": ["post-authorisation path is pure service that starts at C_i", "no phase-locked commit/draw opportunity",
                               "no queueing behind work whose amount depends on C_i", "no shared-resource feedback from the intervention"],
                "tests": ["record B_i (start of post-authorisation busy service) and the opportunity schedule; TI-relevant service = U_i - B_i "
                          "only if the backend is not interleaved",
                          "controlled authorisation delay delta (probe build only): under TI, U shifts by exactly delta for every delta; "
                          "phase-locking shows U unchanged for delta below the opportunity gap",
                          "correlate U_i - C_i with C_i modulo the opportunity period"]},
            "still_unidentified_with_C_i": "whether U_i - C_i is required service or waiting for an opportunity/queue; "
                                           "P and S above have identical (C_i, U_i)"}


if __name__ == "__main__":
    import json
    from common import jsonable
    print(json.dumps(jsonable(main()), indent=1))
