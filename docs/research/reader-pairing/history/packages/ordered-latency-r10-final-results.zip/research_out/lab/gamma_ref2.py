"""Independent second reading of the R10 scan rule (S01-S10, D04, D06) used ONLY as a neutral checker.

Written separately from gamma.py: it does not import gamma.py and shares no code with it. It implements only the
complete snapshot plan (S10) over a simple input: per object (state, side, analysed) and per edge a score
(None = no score or not computed) with an explicit 'edge_known' flag. It is a checker, not an oracle supplied by
the package; agreement with gamma.py is evidence that both readings of the pseudocode coincide.
"""

L, R, U = "LEFT", "RIGHT", "UNKNOWN"


def plan(objs, edges, settings):
    """objs: list of dicts {state: 'X'|'Y'|None, side: L|R|U, analysed: bool};
    edges: dict i -> (known: bool, score: int|None) for the pair (i, i+1);
    settings: {direction, automatic, forced, manual, opening}. Returns list of (tuple(object, slot), certain, reason)."""
    n = len(objs)
    rtl = settings.get("direction", "LTR") == "RTL"
    lead, trail = (R, L) if rtl else (L, R)
    auto = bool(settings.get("automatic", False))
    forced = set(settings.get("forced", ()))
    opening_mode = settings.get("opening", "AUTO")
    starts = set(settings.get("manual", ())) | ({0} if opening_mode == "FIRST_DOUBLE" else set())
    cache = {}

    def Y(i):
        return 0 <= i < n and objs[i]["state"] == "Y"

    def K(i):
        return 0 <= i < n and objs[i]["state"] in ("X", "Y")

    def sd(i):  # side used by the scan: only from an analysed object, only when automatic
        if not auto or not (0 <= i < n) or not objs[i]["analysed"]:
            return U
        return objs[i]["side"]

    def res(i):  # resolvedSide: analysed -> side, else "unresolved"
        if 0 <= i < n and objs[i]["analysed"]:
            return objs[i]["side"]
        return "unresolved"

    def man(i):
        if i not in starts or not (0 <= i < n - 1):
            return False
        if i in cache:
            return cache[i]
        chain, j, base = [], i, False
        while j >= 0 and j in starts:
            if j in cache:
                base = cache[j]
                break
            if j in forced or (j + 1) in forced or Y(j) or Y(j + 1):
                cache[j] = False
                break
            chain.append(j)
            j -= 1
        val = base
        for c in sorted(chain):
            val = not val
            cache[c] = val
        return cache[i]

    def ok(i):
        if i < 0 or i >= n - 1 or i in forced or (i + 1) in forced or Y(i) or Y(i + 1):
            return False
        if man(i):
            return True
        if man(i - 1) or man(i + 1):
            return False
        if auto and (res(i) == trail or res(i + 1) == lead):
            return False
        if i == 0 and not (opening_mode == "AUTO" and K(0) and K(1) and sd(1) == trail and sd(0) != trail):
            return False
        return sd(i) != trail and sd(i + 1) != lead

    def st(i):
        if not ok(i):
            return -1
        if man(i):
            return 3
        return 2 if (sd(i) == lead or sd(i + 1) == trail) else 0

    def dist(i):
        k, v = edges.get(i, (False, None))
        return v if k else None

    def later(i):
        a, b = st(i), st(i + 1)
        if a != b:
            return b > a
        if not auto or b < 0 or i + 2 >= n:
            return False
        near, far = dist(i), dist(i + 1)
        return far is not None and (near is None or far < near)

    out, i, opening, reserved = [], 0, True, -1
    while i < n:
        can = ok(i)
        if can and (i == reserved or not later(i)):
            out.append((((i, lead), (i + 1, trail)), K(i) and K(i + 1), None))
            i, opening = i + 2, False
            continue
        new_res = i + 1 if (i > 0 and can) else reserved
        if n == 1:
            why = "ONLY"
        elif Y(i):
            why = "SHAPE_Y"
        elif i == 0:
            why = "FIRST"
        elif i in forced:
            why = "MANUAL_BOUNDARY"
        elif i == n - 1:
            why = "TAIL"
        elif opening and Y(i + 1):
            why = "OPENING"
        elif Y(i + 1) and Y(i - 1):
            why = "AMBIGUOUS"
        elif Y(i + 1):
            why = "BEFORE_SHAPE_Y"
        elif later(i):
            why = "MATCH_BOUNDARY"
        else:
            why = "UNRESOLVED"
        if why in ("SHAPE_Y", "ONLY"):
            slot = "FULL"
        elif sd(i) in (L, R):
            slot = sd(i)
        elif why == "MANUAL_BOUNDARY":
            slot = lead
        elif why in ("AMBIGUOUS", "UNRESOLVED"):
            slot = "FULL"
        else:
            right_flag = why in ("TAIL", "BEFORE_SHAPE_Y")
            slot = R if rtl == right_flag else L
        out.append((((i, slot),), K(i), why))
        reserved = new_res
        i += 1
    return out


def from_gamma_case(case):
    """Convert a gamma.make_case-style dict to this module's input WITHOUT calling gamma's logic (data mapping only)."""
    objs = []
    for it in case["items"]:
        a = it.get("analysis", {"status": "NotAnalyzed"})
        if a["status"] == "Computed":
            f = a["fact"]
            ok = f["width"] > 0 and f["height"] > 0
            w, h = (f["height"], f["width"]) if f.get("rotation", 0) in (90, 270) else (f["width"], f["height"])
            good = ok and f["state"] == ("SHAPE_Y" if w >= h else "SHAPE_X")
            objs.append({"state": {"SHAPE_X": "X", "SHAPE_Y": "Y"}.get(f["state"]) if good else None, "side": f["side"], "analysed": True})
        else:
            d = it.get("descriptor")
            st = None
            if d and d["width"] > 0 and d["height"] > 0:
                w, h = (d["height"], d["width"]) if d.get("rotation", 0) in (90, 270) else (d["width"], d["height"])
                if d["state"] == ("SHAPE_Y" if w >= h else "SHAPE_X"):
                    st = {"SHAPE_X": "X", "SHAPE_Y": "Y"}[d["state"]]
            objs.append({"state": st, "side": U, "analysed": False})
    edges = {}
    for (a, b), e in case.get("edges", {}).items():
        edges[a] = (e["status"] == "Computed", e.get("score") if e["status"] == "Computed" else None)
    return objs, edges, case.get("settings", {})


# Hand-worked golden examples (derived manually from S01-S10; see tests/test_revision.py for the derivations).
GOLDEN = [
    # 5 X objects, automatic off, RTL: 0 single FIRST (opening not usable without sides) -> LEFT; then (1,2), (3,4)
    ({"n": 5, "states": "XXXXX", "settings": {"direction": "RTL", "automatic": False}},
     [((0, "LEFT"),), ((1, "RIGHT"), (2, "LEFT")), ((3, "RIGHT"), (4, "LEFT"))]),
    # X Y X X, automatic off, LTR: 0 FIRST single (RIGHT in LTR); 1 SHAPE_Y FULL; (2,3) pair LEFT/RIGHT
    ({"n": 4, "states": "XYXX", "settings": {"direction": "LTR", "automatic": False}},
     [((0, "RIGHT"),), ((1, "FULL"),), ((2, "LEFT"), (3, "RIGHT"))]),
    # X X X with forced {1}, automatic off, RTL: 0 FIRST LEFT; 1 MANUAL_BOUNDARY -> leading (RIGHT); 2 TAIL -> RTL flag true -> RIGHT
    ({"n": 3, "states": "XXX", "settings": {"direction": "RTL", "automatic": False, "forced": [1]}},
     [((0, "LEFT"),), ((1, "RIGHT"),), ((2, "RIGHT"),)]),
    # automatic ON, RTL, X X X with sides (UNK, LEFT, UNK): opening pair allowed at 0 (side(1)=trailing LEFT, side(0)
    # not trailing); strength(0)=2 (side(1)==trailing), strength(1)=-1 (resolved(1)==trailing) -> pair (0,1)=(RIGHT,LEFT);
    # 2 = TAIL single, no side -> RTL & TAIL flag -> RIGHT
    ({"n": 3, "states": "XXX", "sides": ["UNKNOWN", "LEFT", "UNKNOWN"], "settings": {"direction": "RTL", "automatic": True}},
     [((0, "RIGHT"), (1, "LEFT")), ((2, "RIGHT"),)]),
    # 4 X with FIRST_DOUBLE: start 0 is a manual start -> (0,1) pair; then (2,3)
    ({"n": 4, "states": "XXXX", "settings": {"direction": "LTR", "automatic": False, "opening": "FIRST_DOUBLE"}},
     [((0, "LEFT"), (1, "RIGHT")), ((2, "LEFT"), (3, "RIGHT"))]),
]
