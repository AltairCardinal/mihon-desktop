"""Differential check: gamma.py (built from R10 pseudocode) vs the previous package's executable reference.

The previous (R9) package was delivered to this researcher by the same commissioner; its reference.py is used
ONLY as an independent cross-check of the reconstruction under an explicit token mapping, never as the R10
oracle. If the file is absent the check is skipped (reported as not run). Path: env R9_REFERENCE or default.

Token mapping R9 -> R10: AB->LTR (A=LEFT, B=RIGHT), BA->RTL; WIDE->SHAPE_Y, NARROW->SHAPE_X; ALL->FULL;
ISOLATE->MANUAL_BOUNDARY; BETWEEN_WIDE->AMBIGUOUS; BEFORE_WIDE->BEFORE_SHAPE_Y; RANK_BOUNDARY->MATCH_BOUNDARY;
hard_isolates->forced; pinned_links->manual; opening PAIR->FIRST_DOUBLE; ANALYSIS->ORIGINAL_ANALYSIS;
RANK->EDGE_SAMPLES; analysis unknown/computed/failed -> NotAnalyzed/Computed/RetryableFailure; header->descriptor.
R9's evidence provider derives edge evidence from endpoint analyses; we materialise that provider's output as
R10 directional edge evidence, so the comparison tests the scan/certification logic, not the provider.
"""
import importlib.util
import os
import random
import sys

import gamma
from common import RAW, write_json

R9 = os.environ.get("R9_REFERENCE", "/home/claude/r9/ordered-system-r9/reference.py")
SLOT = {"A": "LEFT", "B": "RIGHT", "ALL": "FULL"}
REASON = {"WIDE": "SHAPE_Y", "ISOLATE": "MANUAL_BOUNDARY", "BETWEEN_WIDE": "AMBIGUOUS", "BEFORE_WIDE": "BEFORE_SHAPE_Y",
          "RANK_BOUNDARY": "MATCH_BOUNDARY", None: None}
STATE = {"WIDE": "SHAPE_Y", "NARROW": "SHAPE_X", "UNKNOWN": "UNKNOWN", "FAILED": "FAILED"}
NEED = {"DIMENSIONS": "DIMENSIONS", "ANALYSIS": "ORIGINAL_ANALYSIS", "RANK": "EDGE_SAMPLES"}


def load_r9():
    if not os.path.exists(R9):
        return None
    spec = importlib.util.spec_from_file_location("r9_reference", R9)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def rfact(rng, wide=None):
    st = rng.choice(["WIDE", "NARROW"]) if wide is None else ("WIDE" if wide else "NARROW")
    w, h = (200, 150) if st == "WIDE" else (100, 150)
    if rng.random() < 0.05:
        st = rng.choice(["UNKNOWN", "FAILED"])
    return dict(state=st, width=w, height=h, rotation=0, orientation=1, side=rng.choice(["A", "B", "UNKNOWN", "UNKNOWN"]))


def gen_case(rng, n):
    items = []
    for i in range(n):
        it = {"id": f"x{i}"}
        u = rng.random()
        if u < 0.65:
            it["analysis"] = {"status": "computed", "fact": rfact(rng)}
        elif u < 0.75:
            it["analysis"] = {"status": "failed", "reason": rng.choice(["IO", "DECODE"])}
        else:
            it["analysis"] = {"status": "unknown"}
        if rng.random() < 0.5:
            it["header"] = rfact(rng)
        items.append(it)
    edges = []
    for i in range(n - 1):
        u = rng.random()
        if u < 0.7:
            edges.append({"first": i, "second": i + 1, "status": "computed", "score": rng.choice([None, 1, 2, 3, 3, 5])})
        elif u < 0.8:
            edges.append({"first": i, "second": i + 1, "status": "failed", "failures": {f"e{i}": "IO"}})
    settings = {"direction": rng.choice(["AB", "BA"]), "automatic": rng.random() < 0.7,
                "hard_isolates": rng.sample(range(n), k=min(n, rng.choice([0, 0, 1, 2]))) if n else [],
                "pinned_links": rng.sample(range(n), k=min(n, rng.choice([0, 0, 1, 2, 3]))) if n else [],
                "opening": rng.choice(["AUTO", "AUTO", "PAIR", "SINGLE"])}
    return {"items": items, "edges": edges, "settings": settings}


def mfact(f):
    if f is None:
        return None
    return {"state": STATE[f["state"]], "width": f["width"], "height": f["height"], "rotation": f["rotation"],
            "orientation": f["orientation"], "side": SLOT.get(f["side"], "UNKNOWN") if f["side"] in ("A", "B") else "UNKNOWN"}


def to_r10(r9, case):
    data = r9._Input(case)
    items = []
    for i, it in enumerate(case["items"]):
        a = it.get("analysis", {"status": "unknown"})
        if a["status"] == "computed":
            an = {"status": "Computed", "fact": mfact(r9._fact(a["fact"])), "version": 1}
        elif a["status"] == "failed":
            an = {"status": "RetryableFailure", "reason": a["reason"]}
        else:
            an = {"status": "NotAnalyzed"}
        items.append({"id": it["id"], "content_version": 0, "rotation": 0, "orientation": 1, "analysis": an,
                      "descriptor": mfact(r9._fact(it.get("header")))})
    edges = {}
    for i in range(len(items) - 1):
        e = data.edge(i, i + 1)
        if e["status"] == "computed":
            edges[(i, i + 1)] = {"status": "Computed", "score": e.get("score"), "version": 1}
        elif e["status"] == "failed":
            edges[(i, i + 1)] = {"status": "RetryableFailure", "failures": e.get("failures", {})}
    s = case["settings"]
    settings = {"direction": "LTR" if s["direction"] == "AB" else "RTL", "automatic": s["automatic"],
                "forced": s["hard_isolates"], "manual": s["pinned_links"],
                "opening": {"AUTO": "AUTO", "PAIR": "FIRST_DOUBLE", "SINGLE": "FIRST_SINGLE"}[s["opening"]]}
    return {"items": items, "edges": edges, "settings": settings}


def map_unit(u):
    if u is None:
        return None
    return {"slots": tuple((s["item"], SLOT[s["slot"]]) for s in u["slots"]), "certain": u["certain"], "reason": REASON.get(u["reason"], u["reason"])}


def map_needs(ns):
    out = []
    for x in ns:
        d = {"object": x["item"], "kind": NEED[x["kind"]]}
        if "second" in x:
            d["second"] = x["second"]
        out.append(d)
    return sorted(out, key=lambda x: (x["object"], x["kind"], x.get("second", -1)))


def run(trials=20000, seed=10, nmax=9):
    r9 = load_r9()
    if r9 is None:
        return {"run": False, "reason": f"previous reference not found at {R9}"}
    rng = random.Random(seed)
    stats = {"plans": 0, "certs": 0, "plan_mismatch": 0, "cert_mismatch": 0, "status": {}}
    mismatches = []
    for t in range(trials):
        n = rng.randint(1, nmax)
        case = gen_case(rng, n)
        try:
            r10 = to_r10(r9, case)
        except Exception as ex:  # malformed generator output would be a bug in this harness
            raise
        p9 = [map_unit(u) for u in r9.complete_plan(case)]
        p10 = gamma.plan(r10)
        stats["plans"] += 1
        if p9 != p10:
            # Known, documented divergence: R9 complete_plan takes `side` from the effective fact, i.e. from a
            # descriptor when the analysis is not Computed; R10 D04/S01 take side ONLY from a Computed analysis.
            # Re-run R9 with descriptor sides neutralised: if the plans then agree the mismatch is that class.
            import copy
            neutral = copy.deepcopy(case)
            for it in neutral["items"]:
                if it.get("header") and it.get("analysis", {}).get("status") != "computed":
                    it["header"]["side"] = "UNKNOWN"
            if [map_unit(u) for u in r9.complete_plan(neutral)] == p10:
                stats["plan_mismatch_descriptor_side_class"] = stats.get("plan_mismatch_descriptor_side_class", 0) + 1
            else:
                stats["plan_mismatch"] += 1
                if len(mismatches) < 5:
                    mismatches.append({"kind": "plan", "case": repr(case), "r9": p9, "r10": p10})
        tgt = rng.randrange(n)
        e9 = e10 = None
        try:
            c9 = r9.certify(case, tgt, 2)
        except Exception as ex:
            e9 = type(ex).__name__
        try:
            c10 = gamma.certify(r10, tgt, 2)
        except Exception as ex:
            e10 = type(ex).__name__
        stats["certs"] += 1
        if e9 or e10:
            if e9 != e10:
                stats["cert_mismatch"] += 1
                mismatches.append({"kind": "cert-exception", "case": repr(case), "target": tgt, "r9": e9, "r10": e10})
            continue
        st9 = {"certified": "Certified", "need_facts": "NeedFacts", "blocked": "RetryableBlocked"}[c9["status"]]
        stats["status"][st9] = stats["status"].get(st9, 0) + 1
        a = (st9, map_unit(c9["unit"]), c9["first"], c9["steps"], map_needs(c9["needs"]), c9["dependent_items"])
        b = (c10["status"], c10["unit"], c10["first"], c10["steps"], c10["needs"], c10["dependent_objects"])
        if a != b:
            stats["cert_mismatch"] += 1
            if len(mismatches) < 10:
                mismatches.append({"kind": "cert", "case": repr(case), "target": tgt, "r9": repr(a), "r10": repr(b)})
    return {"run": True, "trials": trials, "seed": seed, "nmax": nmax, **stats, "examples": mismatches}


if __name__ == "__main__":
    import sys
    res = run(int(sys.argv[1]) if len(sys.argv) > 1 else 20000)
    res["evidence_class"] = ("HISTORICAL: depends on the previous package's reference.py (R9_REFERENCE), which is not "
                             "shipped with this package; not independently reproducible here. Self-contained neutral check: "
                             "lab/gamma_ref2.py + tests/test_revision.py::NeutralPlanChecker")
    if res.get("run"):
        write_json(RAW / "gamma/xcheck_r9.json", res)
    else:   # keep the historical result; record that this reproduction could not run it
        write_json(RAW / "gamma/xcheck_r9_status.json", {"status": "NOT_RUN", **res})
    print({k: v for k, v in res.items() if k != "examples"})
