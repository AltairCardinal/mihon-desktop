"""Researcher reconstruction of the R10 frozen rule Γ and its finite-entry certification.

Built ONLY from code/semantic_reference/{00,01,02}*.txt (S01-S10, C01-C12, D01-D07). It is an executable
reading of that pseudocode for bounded research. It is NOT the production implementation and NOT an oracle
supplied by the package: where the pseudocode is silent we choose the narrowest literal reading and list it in
AMBIGUITIES. Cross-checked by differential testing against the previous package's executable reference
(see gamma_xcheck.py) under an explicit token mapping.

Data model (all plain dict/tuple, deterministic):
  item  = {id, content_version, rotation, orientation, analysis, descriptor}
  analysis = {"status": "NotAnalyzed"} | {"status": "Computed", "fact": FACT, "version": v}
           | {"status": "RetryableFailure", "reason": r}
  FACT  = {state: UNKNOWN|SHAPE_X|SHAPE_Y|FAILED, width, height, rotation, orientation, side: LEFT|RIGHT|UNKNOWN}
  edges = {(a, a+1): {"status": "NotAnalyzed"} | {"status": "Computed", "score": int|None, "version": v}
                     | {"status": "RetryableFailure", "failures": {...}}}
  settings = {direction: LTR|RTL, automatic: bool, forced: [..], manual: [..], opening: AUTO|FIRST_DOUBLE|FIRST_SINGLE}
"""
from copy import deepcopy

LEFT, RIGHT, FULL, UNK = "LEFT", "RIGHT", "FULL", "UNKNOWN"
NOT_ANALYZED = {"status": "NotAnalyzed"}

AMBIGUITIES = [
    "A1 opening modes other than AUTO/FIRST_DOUBLE are treated like 'not AUTO' at S03 step 5 (no pair at 0 unless manual).",
    "A2 C02 'effective fact' for the identity check compares fact.rotation/orientation with the item's content identity.",
    "A3 C04 directional edge evidence is keyed (a,a+1); evidence for other pairs is never consulted by S05.",
    "A4 C08 'O[first-1], O[first] both not forced' is evaluated on the forced set F only (not on SHAPE_Y).",
    "A5 Unit equality (C09/C10) compares full slots (object, position), certain and reason.",
]


def norm_fact(f):
    if f is None:
        return None
    return {"state": f.get("state", UNK), "width": f.get("width", 0), "height": f.get("height", 0),
            "rotation": f.get("rotation", 0), "orientation": f.get("orientation", 1), "side": f.get("side", UNK)}


def geometry_ok(f):
    """D02: positive size and state consistent with the rotated shape (rotated w>=h -> SHAPE_Y)."""
    if f is None or f["width"] <= 0 or f["height"] <= 0:
        return False
    w, h = f["width"], f["height"]
    if f["rotation"] in (90, 270):
        w, h = h, w
    return f["state"] == ("SHAPE_Y" if w >= h else "SHAPE_X")


class Case:
    def __init__(self, case):
        self.case = case
        self.items = case["items"]
        s = case.get("settings", {})
        self.settings = {"direction": s.get("direction", "LTR"), "automatic": bool(s.get("automatic", False)),
                         "forced": sorted(set(s.get("forced", []))), "manual": sorted(set(s.get("manual", []))),
                         "opening": s.get("opening", "AUTO")}
        assert self.settings["direction"] in ("LTR", "RTL")
        self.identity = {"generation": case.get("generation", 0), "revision": case.get("revision", 0),
                         "items": [{"id": x.get("id", str(i)), "content_version": x.get("content_version", 0),
                                    "rotation": x.get("rotation", 0), "orientation": x.get("orientation", 1)}
                                   for i, x in enumerate(self.items)]}
        if len({x["id"] for x in self.identity["items"]}) != len(self.items):
            raise ValueError("duplicate object")
        self.edges = case.get("edges", {})

    def analysis(self, i):
        a = deepcopy(self.items[i].get("analysis", NOT_ANALYZED))
        if a["status"] == "Computed":
            a["fact"] = norm_fact(a["fact"])
            a.setdefault("version", 1)
        elif a["status"] not in ("NotAnalyzed", "RetryableFailure"):
            raise ValueError("bad analysis status")
        return a

    def descriptor(self, i):
        return norm_fact(self.items[i].get("descriptor"))

    def effective(self, i):
        a = self.analysis(i)
        return a["fact"] if a["status"] == "Computed" else self.descriptor(i)

    def edge(self, a, b):
        e = deepcopy(self.edges.get((a, b), NOT_ANALYZED))
        if e["status"] == "Computed":
            e.setdefault("score", None)
            e.setdefault("version", 1)
        return e


class Scan:
    """S01-S09. Query functions are injected so that plan and certification share one step."""

    def __init__(self, n, settings, dimension, side_q, resolved_q, distance_q):
        self.n, self.s = n, settings
        self.dimension, self.side_q, self.resolved_q, self.distance_q = dimension, side_q, resolved_q, distance_q
        rtl = settings["direction"] == "RTL"
        self.leading, self.trailing = (RIGHT, LEFT) if rtl else (LEFT, RIGHT)
        self.forced = set(settings["forced"])
        self.starts = set(settings["manual"]) | ({0} if settings["opening"] == "FIRST_DOUBLE" else set())
        self.manual_cache = {}
        self.calls = {"allowed": 0, "later_wins": 0, "manual": 0}

    def isY(self, i):
        f = self.dimension(i) if 0 <= i < self.n else None
        return f is not None and f["state"] == "SHAPE_Y"

    def known(self, i):
        f = self.dimension(i) if 0 <= i < self.n else None
        return f is not None and f["state"] in ("SHAPE_X", "SHAPE_Y")

    def side(self, i):
        return self.side_q(i) if self.s["automatic"] and 0 <= i < self.n else UNK

    def manual(self, i):  # S02
        self.calls["manual"] += 1
        if i not in self.starts or not (0 <= i < self.n - 1):
            return False
        if i in self.manual_cache:
            return self.manual_cache[i]
        o, pending, prev = i, [], False
        while o >= 0 and o in self.starts:
            if o in self.manual_cache:
                prev = self.manual_cache[o]
                break
            ok = (o not in self.forced and o + 1 not in self.forced and not self.isY(o) and not self.isY(o + 1))
            if not ok:
                self.manual_cache[o] = False
                break
            pending.append(o)
            o -= 1
        for c in reversed(pending):
            prev = not prev
            self.manual_cache[c] = prev
        return self.manual_cache[i]

    def allowed(self, i):  # S03
        self.calls["allowed"] += 1
        if not (0 <= i < self.n - 1) or i in self.forced or i + 1 in self.forced or self.isY(i) or self.isY(i + 1):
            return False
        if self.manual(i):
            return True
        if self.manual(i - 1) or self.manual(i + 1):
            return False
        if self.s["automatic"] and (self.resolved_q(i) == self.trailing or self.resolved_q(i + 1) == self.leading):
            return False
        if i == 0:
            if not (self.s["opening"] == "AUTO" and self.known(0) and self.known(1)
                    and self.side(1) == self.trailing and self.side(0) != self.trailing):
                return False
        return self.side(i) != self.trailing and self.side(i + 1) != self.leading

    def strength(self, i):  # S04
        if not self.allowed(i):
            return -1
        if self.manual(i):
            return 3
        if self.side(i) == self.leading or self.side(i + 1) == self.trailing:
            return 2
        return 0

    def later_wins(self, i):  # S05
        self.calls["later_wins"] += 1
        near, later = self.strength(i), self.strength(i + 1)
        if near != later:
            return later > near
        if not self.s["automatic"] or later < 0 or i + 2 >= self.n:
            return False
        a = self.distance_q(i, i + 1)
        b = self.distance_q(i + 1, i + 2)
        return b is not None and (a is None or b < a)

    def single_slot(self, i, reason):  # S09 + D06
        if reason in ("SHAPE_Y", "ONLY"):
            return FULL
        sd = self.side(i)
        if sd in (LEFT, RIGHT):
            return sd
        if reason == "MANUAL_BOUNDARY":
            return self.leading
        if reason in ("AMBIGUOUS", "UNRESOLVED"):
            return FULL
        flag = reason in ("TAIL", "BEFORE_SHAPE_Y")
        return RIGHT if (self.s["direction"] == "RTL") == flag else LEFT

    def step(self, cursor, include_single=True, include_double=True):  # S06-S09
        i, opening, reserved = cursor
        assert 0 <= i < self.n
        can = self.allowed(i)
        if can and (i == reserved or not self.later_wins(i)):
            nxt = (i + 2, False, reserved)
            if not include_double:
                return None, nxt
            unit = {"slots": ((i, self.leading), (i + 1, self.trailing)),
                    "certain": self.known(i) and self.known(i + 1), "reason": None}
            return unit, nxt
        nxt = (i + 1, opening, i + 1 if (i > 0 and can) else reserved)
        if not include_single:
            return None, nxt
        if self.n == 1:
            reason = "ONLY"
        elif self.isY(i):
            reason = "SHAPE_Y"
        elif i == 0:
            reason = "FIRST"
        elif i in self.forced:
            reason = "MANUAL_BOUNDARY"
        elif i == self.n - 1:
            reason = "TAIL"
        elif opening and self.isY(i + 1):
            reason = "OPENING"
        elif self.isY(i + 1) and self.isY(i - 1):
            reason = "AMBIGUOUS"
        elif self.isY(i + 1):
            reason = "BEFORE_SHAPE_Y"
        elif self.later_wins(i):
            reason = "MATCH_BOUNDARY"
        else:
            reason = "UNRESOLVED"
        unit = {"slots": ((i, self.single_slot(i, reason)),), "certain": self.known(i), "reason": reason}
        return unit, nxt


def snapshot_queries(c):
    def dim(i):
        return c.effective(i)

    def side(i):
        a = c.analysis(i)
        return a["fact"]["side"] if a["status"] == "Computed" else UNK

    def resolved(i):
        a = c.analysis(i)
        return a["fact"]["side"] if a["status"] == "Computed" else None

    def dist(a, b):
        e = c.edge(a, b)
        return e["score"] if e["status"] == "Computed" else None
    return dim, side, resolved, dist


def plan(case, with_cursors=False):
    """S10: full snapshot plan (provisional where facts are missing)."""
    c = Case(case)
    sc = Scan(len(c.items), c.settings, *snapshot_queries(c))
    units, cursor, cursors = [], (0, True, -1), []
    while cursor[0] < len(c.items):
        cursors.append(cursor)
        u, cursor = sc.step(cursor)
        units.append(u)
    return (units, cursors) if with_cursors else units


def unit_of(units, t):
    for u in units:
        if any(o == t for o, _ in u["slots"]):
            return u
    raise KeyError(t)


class _Unknown(Exception):
    pass


def certify(case, target, lookbehind=2, closed=False, prune=False):
    """C01-C11 finite-entry certification. Returns dict with status Certified|NeedFacts|RetryableBlocked.

    prune=True (R10 revision, Q053 route B, NOT part of the frozen rule): before C09, drop C08 entries at `first`
    that no predecessor configuration can reach. Predecessors: every syntactic cursor at first-2 and first-1, every
    assignment of the facts LEFT of `first` (states, sides, edge scores over an ordering-complete value set), and the
    KNOWN facts at >= first (which are added to the support so C12 currency stays exact). If any needed fact at
    >= first is unknown, nothing is pruned. With prune=False the function is unchanged."""
    c = Case(case)
    n = len(c.items)
    if closed or not (0 <= target < n):
        raise ValueError("closed owner or missing target")
    reads = {"Identity": deepcopy(c.identity), "Settings": deepcopy(c.settings)}
    needs, failures = {}, {}
    sup_dim, sup_an, sup_edge = {}, {}, {}

    def rec(k, v):
        reads[k] = deepcopy(v)
        return v

    def analysis(i):
        return rec(f"Analysis:{i}", c.analysis(i))

    def dimension(i):  # C02
        if not (0 <= i < n):
            return None
        a = analysis(i)
        f = a["fact"] if a["status"] == "Computed" else rec(f"Descriptor:{i}", c.descriptor(i))
        normalized = dict(f, side=UNK) if f else None
        rec(f"Dimension:{i}", normalized)
        ident = c.identity["items"][i]
        if f is None or not geometry_ok(f) or f["rotation"] != ident["rotation"] or f["orientation"] != ident["orientation"]:
            if a["status"] == "RetryableFailure":
                failures[i] = a.get("reason", "FAILED")
            elif f is not None and f["state"] == "FAILED":
                failures[i] = "READ"
            needs[(i, "DIMENSIONS")] = {"object": i, "kind": "DIMENSIONS"}
            return None
        sup_dim[i] = normalized
        return f

    def side(i):  # C03
        a = analysis(i)
        if a["status"] == "Computed":
            sup_an[i] = a
            return a["fact"]["side"]
        if a["status"] == "RetryableFailure":
            failures[i] = a.get("reason", "FAILED")
        needs[(i, "ORIGINAL_ANALYSIS")] = {"object": i, "kind": "ORIGINAL_ANALYSIS"}
        return UNK

    def resolved(i):
        a = analysis(i)
        if a["status"] == "Computed":
            sup_an[i] = a
            return a["fact"]["side"]
        return None

    def distance(a, b):  # C04
        e = rec(f"Edge:{a}:{b}", c.edge(a, b))
        if e["status"] == "Computed":
            sup_edge[(a, b)] = e
            return e["score"]
        if e["status"] == "RetryableFailure":
            for k, v in e.get("failures", {"edge": "FAILED"}).items():
                failures[(a, b, k)] = v
        needs[(a, "EDGE_SAMPLES", b)] = {"object": a, "kind": "EDGE_SAMPLES", "second": b}
        return None

    sc = Scan(n, c.settings, dimension, side, resolved, distance)
    memo, steps = {}, [0]

    def target_unit(cursor):  # C06
        path, result = [], None
        while cursor[0] <= target:
            i, opening, reserved = cursor
            key = (i, opening, reserved == i)
            if key in memo:
                result = memo[key]
                break
            path.append(key)
            u, cursor = sc.step((i, opening, i if key[2] else -1), include_single=(i == target),
                                include_double=(i + 1 >= target))
            steps[0] += 1
            if u is not None and any(o == target for o, _ in u["slots"]):
                result = u
                break
        for k in path:
            memo[k] = result
        return result

    def deps():  # C05
        d = set(sup_dim) | set(sup_an)
        for a, b in sup_edge:
            d |= {a, b}
        for nd in needs.values():
            d.add(nd["object"])
            if "second" in nd:
                d.add(nd["second"])
        return d

    def out(first, unit=None):
        if unit is not None:
            status = "Certified"
            dep = set(sup_dim) | set(sup_an) | {x for e in sup_edge for x in e}
        else:
            status = "RetryableBlocked" if failures else "NeedFacts"
            dep = deps()
        return {"status": status, "unit": unit, "first": first, "steps": steps[0],
                "needs": sorted(needs.values(), key=lambda x: (x["object"], x["kind"], x.get("second", -1))),
                "failures": {str(k): v for k, v in failures.items()}, "dependent_objects": sorted(dep),
                "support": {"dimension": deepcopy(sup_dim), "analysis": deepcopy(sup_an),
                            "edge": {f"{a}:{b}": v for (a, b), v in sup_edge.items()}},
                "reads": reads, "generation": c.identity["generation"], "revision": c.identity["revision"],
                "settings": deepcopy(c.settings), "order": [x["id"] for x in c.identity["items"]],
                "content": {i: c.identity["items"][i] for i in (dep if unit is not None else [])},
                "scan_calls": dict(sc.calls)}

    def reachable_entries(first):
        """Set of normalised cursors (i, opening, reserved == i) reachable at first/first+1, or None (= no pruning)."""
        if first < 4 or sc.starts & set(range(0, first + 3)) or sc.forced & set(range(first - 3, first + 3)):
            return None
        peeked = {"dim": {}, "an": {}, "edge": {}}

        memo_q = {}

        def cached(kind, key, fn):
            k = (kind, key)
            if k not in memo_q:
                try:
                    memo_q[k] = (True, fn())
                except _Unknown as ex:
                    memo_q[k] = (False, ex)
            ok, v = memo_q[k]
            if not ok:
                raise v
            return v

        def peek_dim(i):
            return cached("dim", i, lambda: _peek_dim(i))

        def peek_side(i):
            return cached("side", i, lambda: _peek_side(i))

        def peek_edge(a_, b_):
            return cached("edge", (a_, b_), lambda: _peek_edge(a_, b_))

        def _peek_dim(i):
            if i >= n:
                return None
            a = c.analysis(i)
            f = a["fact"] if a["status"] == "Computed" else c.descriptor(i)
            ident = c.identity["items"][i]
            if f is None or not geometry_ok(f) or f["rotation"] != ident["rotation"] or f["orientation"] != ident["orientation"]:
                raise _Unknown(i)
            peeked["dim"][i] = dict(f, side=UNK)
            return f

        def _peek_side(i):
            a = c.analysis(i)
            if a["status"] != "Computed":
                raise _Unknown(i)
            peeked["an"][i] = a
            return a["fact"]["side"]

        def _peek_edge(a_, b_):
            e = c.edge(a_, b_)
            if e["status"] != "Computed":
                raise _Unknown((a_, b_))
            peeked["edge"][(a_, b_)] = e
            return e["score"]

        known_scores = set()
        for k in range(first, min(n - 1, first + 3)):
            try:
                v = peek_edge(k, k + 1) if c.settings["automatic"] else None
            except _Unknown:
                v = None
            if v is not None:
                known_scores |= {v - 1, v, v + 1}
        score_vals = sorted({0, 10 ** 6} | {v for v in known_scores if v >= 0}) + [None]
        sides = (LEFT, RIGHT, UNK) if c.settings["automatic"] else (UNK,)
        win = [first - 2, first - 1]
        edges_w = [first - 2, first - 1] if c.settings["automatic"] else []   # S05 at first-2/first-1 reads only these + known
        reach = set()
        import itertools as _it
        try:
            for states in _it.product(("SHAPE_X", "SHAPE_Y"), repeat=2):
                for sds in _it.product(sides, repeat=2):
                    for scs in _it.product(score_vals, repeat=len(edges_w)):
                        wf = {o: fact(st_, sd_) for o, st_, sd_ in zip(win, states, sds)}
                        we = dict(zip(edges_w, scs))

                        def dim_q(i, wf=wf):
                            if i in wf:
                                return wf[i]
                            if i < first - 2:
                                return fact("SHAPE_X")  # only consulted by reason labels, never by the cursor
                            return peek_dim(i)

                        def side_q(i, wf=wf):
                            if i in wf:
                                return wf[i]["side"]
                            if i < first - 2:
                                return UNK
                            return peek_side(i)

                        def dist_q(a_, b_, we=we):
                            if a_ in we:
                                return we[a_]
                            if a_ < first - 3:
                                return None
                            return peek_edge(a_, b_)

                        s2 = Scan(n, c.settings, dim_q, side_q, side_q, dist_q)
                        for start in (first - 2, first - 1):
                            for op in (True, False):
                                for res in (-1, start):
                                    cur = (start, op, res)
                                    while cur[0] < first:
                                        _, cur = s2.step(cur)
                                    reach.add((cur[0], cur[1], cur[2] == cur[0]))
        except _Unknown:
            return None
        sup_dim.update(peeked["dim"])
        sup_an.update(peeked["an"])
        sup_edge.update(peeked["edge"])
        return reach

    tf = dimension(target)  # C07
    if tf is None:
        return out(target)
    isolated = tf["state"] == "SHAPE_Y" or target in sc.forced
    first = target if isolated else max(0, target - lookbehind)
    while True:
        if first == 0:  # C08
            entries = [(0, True, -1)]
        elif isolated:
            entries = [(first, True, -1), (first, False, -1)]
        else:
            entries = []
            free = (first - 1) not in sc.forced and first not in sc.forced
            for op in ([True] if first == 1 else [True, False]):
                entries.append((first, op, -1))
                if first > 1 and free:
                    entries.append((first, op, first))
            if free:
                entries.append((first + 1, False, -1))
        cands = [target_unit(e) for e in entries]  # C09
        if prune and first > 0 and not (failures or needs) and len(entries) > 1 and not all(u == cands[0] for u in cands):
            r = reachable_entries(first)   # only where C09 would otherwise fail at this first
            if r is not None:
                keep = [k for k, e in enumerate(entries) if (e[0], e[1], e[2] == e[0]) in r]
                if keep:
                    entries = [entries[k] for k in keep]
                    cands = [cands[k] for k in keep]
        if failures or needs:
            return out(first)
        u0 = cands[0]
        if u0 is not None and all(u == u0 for u in cands):
            return out(first, u0)
        if first > 0 and not sc.allowed(first - 1):  # C10
            if failures or needs:
                return out(first)
            normal = [target_unit((first, o, -1)) for o in (True, False)]
            if normal[0] is not None and normal[0] == normal[1]:
                return out(first, normal[0])
        if first <= 0:
            raise AssertionError("unique origin must determine the target unit")
        first -= 1


def is_current(cert, case, closed=False):
    """C12 exact currency check of a Certified segment."""
    if closed or cert["status"] != "Certified":
        return False
    c = Case(case)
    if (c.identity["generation"], c.identity["revision"]) != (cert["generation"], cert["revision"]):
        return False
    if [x["id"] for x in c.identity["items"]] != cert["order"] or c.settings != cert["settings"]:
        return False
    for i, ident in cert["content"].items():
        if c.identity["items"][i] != ident:
            return False
    for i, v in cert["support"]["dimension"].items():
        f = c.effective(i)
        if (dict(f, side=UNK) if f else None) != v:
            return False
    for i, v in cert["support"]["analysis"].items():
        if c.analysis(i) != v:
            return False
    for k, v in cert["support"]["edge"].items():
        a, b = map(int, k.split(":"))
        if c.edge(a, b) != v:
            return False
    return True


# ---------------------------------------------------------------- helpers for building cases
def fact(state, side=UNK, rotation=0, orientation=1):
    w, h = (100, 150) if state == "SHAPE_X" else (200, 150) if state == "SHAPE_Y" else (0, 0)
    return {"state": state, "width": w, "height": h, "rotation": rotation, "orientation": orientation, "side": side}


def computed(state, side=UNK):
    return {"status": "Computed", "fact": fact(state, side), "version": 1}


def make_case(states, sides=None, scores=None, settings=None, known=None, edge_known=None, descriptors=None):
    """states: list of SHAPE_X/SHAPE_Y; sides: LEFT/RIGHT/UNKNOWN; scores: dict (i)->int|None for edge (i,i+1).
    known: set of objects whose analysis is Computed (default all); others NotAnalyzed (descriptor if given).
    edge_known: set of i whose edge (i,i+1) is Computed (default all)."""
    n = len(states)
    sides = sides or [UNK] * n
    scores = scores if scores is not None else {}
    known = set(range(n)) if known is None else set(known)
    edge_known = set(range(n - 1)) if edge_known is None else set(edge_known)
    items = []
    for i in range(n):
        it = {"id": f"o{i}", "content_version": 0, "rotation": 0, "orientation": 1}
        it["analysis"] = computed(states[i], sides[i]) if i in known else dict(NOT_ANALYZED)
        if descriptors and i in descriptors:
            it["descriptor"] = descriptors[i]
        items.append(it)
    edges = {}
    for i in range(n - 1):
        if i in edge_known:
            edges[(i, i + 1)] = {"status": "Computed", "score": scores.get(i), "version": 1}
    return {"items": items, "edges": edges, "settings": settings or {}}
