"""Regression tests for the final targeted fixes (R10 closing round):

  F1  C30 stop decision (bench/joint_d.py::c30): a positive NECESSARY reduction is not evidence of no headroom.
  F2  ChunkedLazy (bench/joint_b.py): accumulated updates must not be cleared by exit-cursor convergence.
  F3  consumer_done (lab/sched.py): consumption starts only after the consumer is live AND has accepted every
      needed result; per consumer; close/cancel/stale events never fabricate a completion.
  F4  Windows test fixture (tests/test_revision.py::Integrity): fixture bytes are fixed, not platform text mode.

Every test drives the real implementation under repair. Oracles:
  F1  soundness is judged against the package's own compatible worlds (lab/obsworlds.py W_* / T01 P,S) and
      against per-sample bounds recomputed from data/ via common.formal_rows(); the classifier is not used as
      its own oracle.
  F2  the oracle is the complete left-to-right Gamma plan of the CURRENT case (gamma.plan), i.e. full
      recomputation with the same step semantics; it checks the incremental bookkeeping, not gamma.Scan itself.
  F3  expected times are written out by hand from the event semantics stated in each test.
  F4  the checker (check_integrity.verify_manifest) is the code under test only for its strictness; the fixture
      is what changed. Native Windows execution: NOT_RUN (no Windows host). The CRLF test below EMULATES Windows
      text mode on this platform; it is not a Windows run.

Run:  python3 -B research_out/tests/test_final_fixes.py
"""
import json
import random
import shutil
import statistics
import sys
import tempfile
import unittest
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
PKG = OUT.parent
sys.path.insert(0, str(OUT / "lab"))
sys.path.insert(0, str(OUT / "bench"))
sys.path.insert(0, str(OUT))
sys.path.insert(0, str(OUT / "tests"))
import common  # noqa: E402
import check_integrity as CI  # noqa: E402
import evidence as E  # noqa: E402
import gamma as G  # noqa: E402
import sched as S  # noqa: E402
import joint_b as JB  # noqa: E402
import joint_d as JD  # noqa: E402

T = common.T_CEIL


# ============================================================================================ F1 C30
def _actions(cell, domains):
    """Per-domain action of a C30 cell. New output carries cost['actions']; the pre-fix output only listed
    'trials' and silently EXCLUDED (= stopped) every other domain, which is how it is read here."""
    cost = cell["cost"]
    if "actions" in cost:
        return cost["actions"]
    return {d: ("trial" if d in cost["trials"] else "stop") for d in domains}


class C30Decision(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.res = JD.c30()
        cls.reach = json.loads((OUT / "raw/pass1/reach.json").read_text(encoding="utf-8"))
        cls.ow = json.loads((OUT / "raw/pass1/obsworlds.json").read_text(encoding="utf-8"))

    def test_premise_of_reported_counterexample_holds_in_package(self):
        self.assertGreater(self.reach["F0_min_reduction"]["min_total_reduction_ns"], 0)
        ff = self.ow["worlds"]["W_fact_bound"]["fact_free"]
        self.assertTrue(ff["passes_ceiling"])
        self.assertLessEqual(ff["median_ns"], T)

    def test_positive_necessary_reduction_with_compatible_passing_world_is_not_stopped(self):
        cells = self.res["inputs"]["package_artifacts"]["cells"]
        for c in ("B_I", "AB_I", "B_II", "AB_II"):
            act = _actions(cells[c], ["D1_main_gate", "D2_result_pool", "D3_pruned_entries"])
            self.assertNotEqual(act["D1_main_gate"], "stop", (c, act))        # pre-fix: excluded by minred > 0
            self.assertNotEqual(act["D1_main_gate"], "trial", (c, act))       # unknown never approves a trial
            self.assertEqual(act["D1_main_gate"], "observe", (c, act))

    def test_classifier_minred_alone_is_unknown(self):
        v = JD.c30_classify({"min_total_reduction_ns": 1859290300})
        self.assertEqual((v["verdict"], v["action"]), ("unknown", "observe"))

    def test_valid_irremovable_lower_bound_gives_no_go(self):
        s = [125196850] * 50                                   # T01 world S: required service 125.19685 ms
        v = JD.c30_classify({"required_service_lower_ns": s})
        self.assertEqual((v["verdict"], v["action"]), ("no_go", "stop"))
        self.assertIn("required_service_lower_ns", v["basis"])

    def test_valid_removable_work_upper_bound_gives_no_go(self):
        rows = [r for r in common.formal_rows() if r["group"] == "F0"]
        # H2: a partner-only mechanism leaves the first-member ack unchanged -> L_i >= target_latency_i
        v = JD.c30_classify({"latency_ns": [r["unit_latency_ns"] for r in rows],
                             "removable_upper_ns": [r["unit_latency_ns"] - r["target_latency_ns"] for r in rows]})
        self.assertEqual(v["verdict"], "no_go")
        self.assertGreater(statistics.median([r["target_latency_ns"] for r in rows]), T)

    def test_lower_bound_at_or_below_ceiling_is_not_no_go(self):
        v = JD.c30_classify({"required_service_lower_ns": [T] * 50})
        self.assertEqual(v["verdict"], "unknown")
        v = JD.c30_classify({"required_service_lower_ns": [0] * 25 + [10 ** 9] * 25})   # median = (0 + 1e9) / 2 > T
        self.assertEqual(v["verdict"], "no_go")
        v = JD.c30_classify({"required_service_lower_ns": [0] * 26 + [10 ** 9] * 24})
        self.assertEqual(v["verdict"], "unknown")

    def test_missing_decisive_data_stays_unknown(self):
        for ev in ({}, {"min_total_reduction_ns": 0}, {"latency_ns": [10 ** 8] * 50}):
            v = JD.c30_classify(ev)
            self.assertEqual((v["verdict"], v["action"]), ("unknown", "observe"), ev)

    def test_model_only_upper_bound_does_not_approve_real_trial(self):
        v = JD.c30_classify({"post_latency_upper_ns": [10 ** 6] * 50, "upper_scope": "model"})
        self.assertEqual((v["verdict"], v["action"]), ("unknown", "observe"))
        v = JD.c30_classify({"post_latency_upper_ns": [10 ** 6] * 50, "upper_scope": "real"})
        self.assertEqual((v["verdict"], v["action"]), ("go_supported", "trial"))

    def test_contradictory_bounds_are_reported_not_resolved(self):
        v = JD.c30_classify({"required_service_lower_ns": [10 ** 9] * 50, "post_latency_upper_ns": [1] * 50,
                             "upper_scope": "real"})
        self.assertEqual(v["verdict"], "inconsistent")
        self.assertEqual(v["action"], "observe")

    def test_no_preset_answer_outcome_follows_evidence(self):
        self.assertNotIn("should be 0", self.res["metric"])
        acts = {}
        for name, inp in self.res["inputs"].items():
            acts[name] = _actions(inp["cells"]["AB_II"], ["D1_main_gate"])["D1_main_gate"]
        self.assertEqual(acts["package_artifacts"], "observe")
        self.assertEqual(acts["synthetic_required_service"], "stop")
        self.assertEqual(acts["synthetic_real_upper_bound"], "trial")
        self.assertEqual(acts["missing_data"], "observe")
        self.assertEqual(acts["synthetic_lower_bound_below_T"], "observe")
        self.assertEqual(acts["synthetic_model_upper_bound"], "observe")

    def test_verdict_cells_are_sound_and_naive_cells_are_not(self):
        for name, inp in self.res["inputs"].items():
            for c in ("B_I", "AB_I", "B_II", "AB_II"):
                self.assertEqual(inp["cells"][c]["m"], 0, (name, c, inp["cells"][c]))
            self.assertGreater(inp["cells"]["0"]["m"], 0, name)

    def test_retracted_rule_is_kept_and_shown_unsound(self):
        r = self.res["notes"]["retracted_rule"]
        self.assertEqual(r["old_rule"], "headroom_possible = min_total_reduction_ns <= 0")
        self.assertEqual(r["old_action_D1"], "stop")
        self.assertTrue(r["unsound_on_package_artifacts"])
        self.assertIn("W_fact_bound", r["counter_world"])

    def test_simplistic_rules_are_penalised_by_the_study_metric(self):
        # acceptance findings: an always-observe rule scored 0 under the first metric; value-blind and scope-blind
        # rules scored 0 before inputs with present-but-indecisive evidence were added
        orig = JD.c30_classify

        def stub(rule):
            def f(ev, T=T):
                return {"verdict": "stub", "action": rule(ev), "basis": "stub", "lower_median_ns": None,
                        "upper_median_ns": None, "upper_scope": None, "min_total_reduction_ns_informational": None}
            return f
        rules = {
            "always_observe": lambda ev: "observe", "always_stop": lambda ev: "stop", "always_trial": lambda ev: "trial",
            "old_minred_rule": lambda ev: "stop" if ev.get("min_total_reduction_ns", 0) > 0 else "trial",
            "value_blind": lambda ev: ("stop" if (ev.get("required_service_lower_ns") is not None or ev.get("removable_upper_ns") is not None)
                                       else "trial" if ev.get("post_latency_upper_ns") is not None else "observe"),
            "scope_blind": lambda ev: orig(dict(ev, upper_scope="real") if ev.get("post_latency_upper_ns") is not None else ev)["action"],
        }
        scores = {}
        try:
            for name, rule in rules.items():
                JD.c30_classify = stub(rule)
                r = JD.c30()
                scores[name] = sum(v["cells"]["AB_II"]["m"] for v in r["inputs"].values())
        finally:
            JD.c30_classify = orig
        real = sum(v["cells"]["AB_II"]["m"] for v in JD.c30()["inputs"].values())
        self.assertEqual(real, 0)
        for name, sc in scores.items():
            self.assertGreater(sc, 0, name)

    def test_invalid_or_contradictory_bounds(self):
        with self.assertRaises(ValueError):
            JD.c30_classify({"latency_ns": [10], "removable_upper_ns": [-10 ** 9]})
        with self.assertRaises(ValueError):
            JD.c30_classify({"required_service_lower_ns": [-1]})
        v = JD.c30_classify({"required_service_lower_ns": [10 ** 9], "latency_ns": [5]})
        self.assertEqual((v["verdict"], v["action"]), ("inconsistent", "observe"))
        with self.assertRaises(ValueError):
            JD.c30_classify({"required_service_lower_ns": [float("nan")]})
        with self.assertRaises(ValueError):
            JD.c30_classify({"required_service_lower_ns": [10 ** 9] * 50, "post_latency_upper_ns": [1] * 10, "upper_scope": "real"})
        v = JD.c30_classify({"required_service_lower_ns": [10 ** 9] * 5, "post_latency_upper_ns": [1] * 5, "upper_scope": "model"})
        self.assertEqual(v["verdict"], "no_go")
        self.assertTrue(v["conflict_with_model_upper_bound"])

    def test_scope_is_main_gate_only(self):
        self.assertIn("MAIN-GATE", self.res["notes"]["scope"])
        self.assertIn("C05/Q028", self.res["notes"]["scope"])

    def test_proven_conditional_no_go_domains_use_package_bounds(self):
        acts = _actions(self.res["inputs"]["package_artifacts"]["cells"]["AB_II"], [])
        self.assertEqual(acts["D1p_partner_only"], "stop")       # H2 premise: first-member ack unchanged
        self.assertEqual(acts["D1s_start_reopen_only"], "stop")  # H3 premise: advance samples unchanged
        self.assertEqual(acts["D2_result_pool"], "observe")
        self.assertEqual(acts["D3_pruned_entries"], "observe")


class ReportCheckerCatchesSubListMisplacement(unittest.TestCase):
    """Self-found SF-5: check_report_consistency.py never inspected the indented sub-lists under 'stop'."""

    def test_misplaced_id_in_stop_sub_list_is_reported(self):
        import subprocess
        tmp = Path(tempfile.mkdtemp())
        try:
            d = tmp / "research_out"
            d.mkdir()
            for f in ("check_report_consistency.py", "coverage.csv"):
                shutil.copy(OUT / f, d / f)
            (d / "raw").symlink_to(OUT / "raw")
            text = (OUT / "REPORT.md").read_text(encoding="utf-8")
            (d / "REPORT.md").write_text(text, encoding="utf-8")
            ok = subprocess.run([sys.executable, "-B", str(d / "check_report_consistency.py")], capture_output=True, text=True, cwd=tmp)
            self.assertEqual(ok.returncode, 0, ok.stdout[-500:])
            bad = text.replace("C25。\n", "C25、C02。\n", 1)          # C02 is engineering_trial, put it under a stop sub-list
            self.assertNotEqual(bad, text)
            (d / "REPORT.md").write_text(bad, encoding="utf-8")
            r = subprocess.run([sys.executable, "-B", str(d / "check_report_consistency.py")], capture_output=True, text=True, cwd=tmp)
            self.assertEqual(r.returncode, 1)
            self.assertIn("('C02', 'listed under stop', 'engineering_trial')", r.stdout)
        finally:
            shutil.rmtree(tmp)


# ============================================================================================ F2 ChunkedLazy
LTR_OFF = {"direction": "LTR", "automatic": False}


def _case(states, settings, sides=None, scores=None):
    return G.make_case(list(states), sides, scores, dict(settings))


def _truth(case, t):
    return G.unit_of(G.plan(case), t)


class ChunkedLazyUpdates(unittest.TestCase):
    def _run(self, n, settings, script, chunk=8, warm=True, lazy=True, init=None):
        """script: list of ('set', pos, state) | ('q', t). Every query is compared with the full plan."""
        states = list(init or ["SHAPE_X"] * n)
        case = _case(states, settings)
        cl = JB.ChunkedLazy(case, chunk, lazy=lazy)
        if warm:
            cl.ensure(cl.nk - 1)
        for op in script:
            if op[0] == "set":
                states[op[1]] = op[2]
                case = _case(states, settings)
                cl.update(case, op[1])
            else:
                self.assertEqual(cl.unit(op[1]), _truth(case, op[1]), (script, op))
        return cl

    def test_reported_counterexample(self):
        self._run(40, LTR_OFF, [("set", 0, "SHAPE_Y"), ("set", 24, "SHAPE_Y"), ("q", 24)])

    def test_reported_counterexample_exact_values(self):
        states = ["SHAPE_X"] * 40
        cl = JB.ChunkedLazy(_case(states, LTR_OFF), 8)
        cl.ensure(cl.nk - 1)
        states[0] = "SHAPE_Y"
        cl.update(_case(states, LTR_OFF), 0)
        states[24] = "SHAPE_Y"
        cl.update(_case(states, LTR_OFF), 24)
        self.assertEqual(cl.unit(24), {"slots": ((24, G.FULL),), "certain": True, "reason": "SHAPE_Y"})

    def test_reversed_order(self):
        self._run(40, LTR_OFF, [("set", 24, "SHAPE_Y"), ("set", 0, "SHAPE_Y"), ("q", 24), ("q", 0)])

    def test_same_position_repeatedly(self):
        self._run(40, LTR_OFF, [("set", 24, "SHAPE_Y"), ("set", 24, "SHAPE_X"), ("set", 24, "SHAPE_Y"), ("q", 24),
                                ("set", 24, "SHAPE_X"), ("q", 23), ("q", 24)])

    def test_same_chunk_and_different_chunks(self):
        self._run(40, LTR_OFF, [("set", 17, "SHAPE_Y"), ("set", 20, "SHAPE_Y"), ("q", 20), ("q", 17)])
        self._run(40, LTR_OFF, [("set", 3, "SHAPE_Y"), ("set", 35, "SHAPE_Y"), ("q", 35), ("q", 3)])

    def test_query_between_and_after(self):
        self._run(40, LTR_OFF, [("set", 0, "SHAPE_Y"), ("q", 10), ("set", 24, "SHAPE_Y"), ("q", 24), ("q", 39)])
        self._run(40, LTR_OFF, [("set", 0, "SHAPE_Y"), ("q", 30), ("set", 24, "SHAPE_Y"), ("q", 24)])

    def test_single_change_crossing_a_chunk_boundary(self):
        # change at the first object of a chunk: the previous chunk re-expands and converges first
        self._run(16, LTR_OFF, [("set", 8, "SHAPE_Y"), ("q", 8), ("q", 9)])
        self._run(6, LTR_OFF, [("set", 4, "SHAPE_Y"), ("q", 3), ("q", 4)], chunk=3)
        # change at the last object of a chunk: the next chunk's first step reads it (i-1)
        self._run(16, LTR_OFF, [("set", 7, "SHAPE_Y"), ("q", 8), ("q", 9)])

    def test_boundaries(self):
        for chunk in (1, 2, 3, 8, 64):
            self._run(13, LTR_OFF, [("set", 0, "SHAPE_Y"), ("set", 12, "SHAPE_Y"), ("q", 12), ("q", 0), ("q", 11)], chunk=chunk)
            self._run(13, LTR_OFF, [("set", 12, "SHAPE_Y"), ("q", 12)], chunk=chunk, warm=False)

    def test_manual_constraint_long_dependency(self):
        # a contiguous run of manual starts: manual(i) walks back to the start of the run, so the unit at 30
        # depends on object 1 through the alternation parity (long dependency through hand-set constraints)
        st = {"direction": "LTR", "automatic": False, "manual": list(range(0, 40))}
        self._run(40, st, [("set", 1, "SHAPE_Y"), ("q", 30), ("set", 1, "SHAPE_X"), ("q", 30), ("q", 31)])
        self._run(40, st, [("set", 1, "SHAPE_Y"), ("set", 33, "SHAPE_Y"), ("q", 30), ("q", 34)])
        st2 = {"direction": "RTL", "automatic": False, "manual": list(range(5, 30)), "forced": [31]}
        self._run(40, st2, [("set", 6, "SHAPE_Y"), ("set", 28, "SHAPE_Y"), ("q", 29), ("q", 20)], chunk=4)

    def test_lazy_false_and_cold_start(self):
        self._run(40, LTR_OFF, [("set", 0, "SHAPE_Y"), ("set", 24, "SHAPE_Y"), ("q", 24)], lazy=False)
        self._run(40, LTR_OFF, [("set", 0, "SHAPE_Y"), ("set", 24, "SHAPE_Y"), ("q", 24)], warm=False)

    def test_random_multi_update_sequences(self):
        rng = random.Random(20261028)
        for case_no in range(300):
            n = rng.randint(4, 48)
            states, sides, scores = E.random_world(n, rng, p_y=rng.choice([0.05, 0.2, 0.4]))
            st = {"direction": rng.choice(["LTR", "RTL"]), "automatic": rng.random() < 0.5}
            if rng.random() < 0.6:
                a = rng.randrange(n)
                st["manual"] = list(range(a, min(n, a + rng.randint(1, n))))
            if rng.random() < 0.3:
                st["forced"] = sorted(rng.sample(range(n), 2))
            if rng.random() < 0.3:
                st["opening"] = "FIRST_DOUBLE"
            case = _case(states, st, sides, scores)
            cl = JB.ChunkedLazy(case, rng.choice([1, 2, 3, 5, 8]), lazy=rng.random() < 0.8)
            if rng.random() < 0.5:
                cl.ensure(cl.nk - 1)
            for _ in range(rng.randint(2, 10)):
                if rng.random() < 0.55:
                    pos = rng.randrange(n)
                    states[pos] = "SHAPE_Y" if states[pos] == "SHAPE_X" else "SHAPE_X"
                    if rng.random() < 0.3:
                        sides[pos] = rng.choice([G.LEFT, G.RIGHT, G.UNK])
                    if rng.random() < 0.3 and pos < n - 1:
                        scores[pos] = rng.choice([None, rng.randint(0, 20)])
                    case = _case(states, st, sides, scores)
                    cl.update(case, pos)
                else:
                    t = rng.randrange(n)
                    self.assertEqual(cl.unit(t), _truth(case, t), (case_no, n, st, t))

    def test_settings_change_falls_back_exactly_and_is_counted(self):
        states = ["SHAPE_X"] * 20
        cl = JB.ChunkedLazy(_case(states, LTR_OFF), 4)
        cl.ensure(cl.nk - 1)
        st2 = {"direction": "RTL", "automatic": False}
        case2 = _case(states, st2)
        cl.update(case2, 0)
        self.assertEqual(cl.unit(10), _truth(case2, 10))
        self.assertEqual(cl.fallbacks, 1)

    def test_in_place_mutation_then_update_is_detected(self):
        # acceptance finding: the caller mutates its case object in place, then calls update(case, pos)
        case = G.make_case(["SHAPE_X"] * 40, None, None, dict(LTR_OFF))
        cl = JB.ChunkedLazy(case, 8)
        cl.ensure(cl.nk - 1)
        case["items"][24]["analysis"] = G.computed("SHAPE_Y", G.UNK)
        cl.update(case, 24)
        self.assertEqual(cl.unit(24), _truth(case, 24))
        case["settings"]["direction"] = "RTL"                         # in-place settings change -> exact fallback
        cl.update(case, 0)
        self.assertEqual(cl.unit(30), _truth(case, 30))
        self.assertEqual(cl.fallbacks, 1)

    def test_no_change_costs_no_steps(self):
        states = ["SHAPE_X"] * 40
        case = _case(states, LTR_OFF)
        cl = JB.ChunkedLazy(case, 8)
        cl.ensure(cl.nk - 1)
        cl.ops = 0
        cl.update(case, 5)                 # same content: nothing is dirty
        self.assertEqual(cl.unit(30), _truth(case, 30))
        self.assertEqual(cl.ops, 0)


class OtherIncrementalStructuresMultiUpdate(unittest.TestCase):
    """Acceptance check for 'no missed invalidation under several updates' on the two other incremental structures
    used by the studies (lab/summarytree.py SummaryTree and Checkpoints). Not changed by this round."""

    def test_random_multi_update_sequences(self):
        import summarytree as STR
        rng = random.Random(4242)
        for case_no in range(150):
            n = rng.randint(4, 48)
            states, sides, scores = E.random_world(n, rng, p_y=rng.choice([0.05, 0.2, 0.4]))
            st = {"direction": rng.choice(["LTR", "RTL"]), "automatic": rng.random() < 0.5}
            if rng.random() < 0.6:
                a = rng.randrange(n)
                st["manual"] = list(range(a, min(n, a + rng.randint(1, n))))
            case = _case(states, st, sides, scores)
            structs = [STR.SummaryTree(case, rng.choice([2, 4, 8])), STR.Checkpoints(case, rng.choice([4, 8, 16]))]
            for _ in range(rng.randint(2, 10)):
                if rng.random() < 0.55:
                    pos = rng.randrange(n)
                    states[pos] = "SHAPE_Y" if states[pos] == "SHAPE_X" else "SHAPE_X"
                    case = _case(states, st, sides, scores)
                    for x in structs:
                        x.update(case, pos)
                else:
                    t = rng.randrange(n)
                    for x in structs:
                        self.assertEqual(x.unit(t), _truth(case, t), (case_no, type(x).__name__, st, t))


# ============================================================================================ F3 consumer_done
def _sim(tasks, **kw):
    return S.Sim(tasks, **kw)


class ConsumerDone(unittest.TestCase):
    def _ledger_ok(self, sim):
        m = sim.metrics()
        self.assertEqual(sim.violations, [])
        self.assertEqual(m["double_releases"], 0)
        self.assertLessEqual(max(sim.release_calls.values(), default=0), 1)
        self.assertEqual(m["bytes_outstanding"], 0)
        return m

    def test_reported_counterexample(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1,
                   consume={"ui": ({"x"}, 2)}, stall_until={"ui": 40}).run()
        self.assertEqual(sim.tasks["x"].accepted_at, 40)
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 42})

    def test_no_stall(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1, consume={"ui": ({"x"}, 2)}).run()
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 7})

    def test_unregistered_consumer_accepts_from_pool_when_live(self):
        # the result has no registered consumer (pooled); a live consumer that needs it accepts it at completion
        sim = _sim([S.Task("x", "required", 5, 0)], physical=1, consume={"c": ({"x"}, 2)}).run()
        self.assertEqual(sim.tasks["x"].accepted_by, {"c": 5})
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"c": 7})

    def test_stall_ends_before_completion(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1,
                   consume={"ui": ({"x"}, 2)}, stall_until={"ui": 3}).run()
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 7})

    def test_stall_ends_after_completion_with_bounded_pool(self):
        tasks = [S.Task("x", "required", 5, 0, consumers={"ui"}), S.Task("r", "required", 3, 10)]
        sim = _sim(tasks, physical=1, mailbox=0, consume={"ui": ({"x"}, 2)}, stall_until={"ui": 40}).run()
        m = self._ledger_ok(sim)
        self.assertEqual(sim.tasks["x"].accepted_at, 40)
        self.assertEqual(m["consumer_done"], {"ui": 42})
        self.assertEqual(sim.tasks["r"].start, 40)        # the held result kept the only worker until 40

    def test_multiple_dependencies(self):
        tasks = [S.Task("x", "required", 5, 0, consumers={"ui"}), S.Task("y", "required", 9, 0, consumers={"ui"})]
        sim = _sim(tasks, physical=2, consume={"ui": ({"x", "y"}, 2)}, stall_until={"ui": 7}).run()
        self.assertEqual((sim.tasks["x"].accepted_at, sim.tasks["y"].accepted_at), (7, 9))
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 11})
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"}), S.Task("y", "required", 9, 0, consumers={"ui"})],
                   physical=2, consume={"ui": ({"x", "y"}, 2)}, stall_until={"ui": 20}).run()
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 22})

    def test_multiple_consumers_are_checked_separately(self):
        t = S.Task("x", "required", 5, 0, consumers={"ui", "log"})
        sim = _sim([t], physical=1, consume={"ui": ({"x"}, 2), "log": ({"x"}, 1)}, stall_until={"ui": 40}).run()
        self.assertEqual(sim.tasks["x"].accepted_by, {"log": 5, "ui": 40})
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"log": 6, "ui": 42})

    def test_other_consumers_acceptance_does_not_count(self):
        # ui needs x and y; x was accepted by log only (ui stalled) -> ui may not start before its own acceptance
        tasks = [S.Task("x", "required", 5, 0, consumers={"log", "ui"}), S.Task("y", "required", 2, 0, consumers={"ui"})]
        sim = _sim(tasks, physical=2, consume={"ui": ({"x", "y"}, 3), "log": ({"x"}, 1)}, stall_until={"ui": 30}).run()
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"log": 6, "ui": 33})

    def test_close_before_acceptance_gives_no_completion(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1,
                   consume={"ui": ({"x"}, 2)}, stall_until={"ui": 40})
        sim.run([(20, lambda s: s.close())])
        m = self._ledger_ok(sim)
        self.assertEqual(m["consumer_done"], {})
        self.assertEqual(m["results_in_pool"] + m["results_held_on_worker"], 0)

    def test_close_during_consumption_gives_no_completion(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1, consume={"ui": ({"x"}, 4)})
        sim.run([(7, lambda s: s.close())])
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {})

    def test_cancel_before_and_during_consumption(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1,
                   consume={"ui": ({"x"}, 2)}, stall_until={"ui": 40})
        sim.run([(20, lambda s: s.cancel("x"))])
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {})
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1, consume={"ui": ({"x"}, 4)})
        sim.run([(6, lambda s: s.cancel("x"))])
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {})

    def test_stale_consumption_after_need_change(self):
        tasks = [S.Task("x", "required", 5, 0, consumers={"c"}), S.Task("y", "required", 20, 0, consumers={"c"})]
        sim = _sim(tasks, physical=2, consume={"c": ({"x"}, 10)})
        sim.run([(8, lambda s: s.consume.update({"c": ({"y"}, 10)}))])
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"c": 30})

    def test_completion_superseded_by_later_need_change(self):
        # acceptance finding: a completion for the old need set must not stand for the new one
        tasks = [S.Task("x", "required", 5, 0, consumers={"c"}), S.Task("y", "required", 100, 0, consumers={"c"})]
        sim = _sim(tasks, physical=2, consume={"c": ({"x"}, 2)})
        sim.run([(10, lambda s: s.consume.update({"c": ({"x", "y"}, 2)})), (50, lambda s: s.close())])
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {})
        self.assertEqual([(c, t) for _, c, t, _ in sim.consumption_superseded], [("c", 7)])

    def test_stall_set_after_run_started(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1, consume={"ui": ({"x"}, 2)})
        sim.run([(1, lambda s: s.stall_until.update({"ui": 40}))])
        self.assertEqual(sim.tasks["x"].accepted_at, 40)
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 42})

    def test_stall_extended_makes_old_stall_end_outdated(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1, consume={"ui": ({"x"}, 2)},
                   stall_until={"ui": 10})
        sim.run([(2, lambda s: s.stall_until.update({"ui": 30}))])
        self.assertEqual(sim.tasks["x"].accepted_at, 30)
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 32})

    def test_stall_changed_by_hook_is_applied_at_once(self):
        def hook(s):
            if s.now == 5:
                s.stall_until["ui"] = 10
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1, consume={"ui": ({"x"}, 2)},
                   stall_until={"ui": 10 ** 9}, after_event=hook).run()
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {"ui": 12})

    def test_double_restart_upgrade_keeps_ledger(self):
        # older defect found during acceptance: a second restart overwrote the running replacement x'
        t = S.Task("x", "speculative", 10, 0, bytes_upper=5)
        sim = _sim([t], physical=2, upgrade="restart")
        sim.run([(1, lambda s: s.upgrade_task("x", "c")), (2, lambda s: s.upgrade_task("x", "c"))])
        m = self._ledger_ok(sim)
        self.assertEqual(m["unexited"], [])
        self.assertIn("x''", sim.tasks)

    def test_never_live_consumer_never_completes(self):
        sim = _sim([S.Task("x", "required", 5, 0, consumers={"ui"})], physical=1,
                   consume={"ui": ({"x"}, 2)}, stall_until={"ui": 10 ** 9}).run()
        self.assertEqual(self._ledger_ok(sim)["consumer_done"], {})

    def test_fuzz_completion_never_precedes_acceptance_or_liveness(self):
        rng = random.Random(77)
        for case in range(500):
            n = rng.randint(1, 6)
            tasks = []
            for i in range(n):
                t = S.Task(f"t{i}", rng.choice(["required", "speculative"]), rng.randint(1, 8), rng.randint(0, 6))
                for c in ("c1", "c2"):
                    if rng.random() < 0.5:
                        t.consumers.add(c)
                tasks.append(t)
            consume = {c: (set(rng.sample([t.id for t in tasks], rng.randint(1, n))), rng.randint(0, 4))
                       for c in ("c1", "c2") if rng.random() < 0.8}
            stall = {c: rng.randint(0, 30) for c in ("c1", "c2") if rng.random() < 0.6}
            sim = S.Sim(tasks, physical=rng.randint(1, 3), mailbox=rng.choice([None, 0, 1, 2]), stall_until=stall,
                        consume=consume)
            acts = []
            if rng.random() < 0.3:
                acts.append((rng.randint(0, 30), lambda s: s.close()))
            if rng.random() < 0.3:
                tid = rng.choice(tasks).id
                acts.append((rng.randint(0, 30), lambda s, tid=tid: s.cancel(tid)))
            if consume and rng.random() < 0.3:               # need-set change mid-run
                c = rng.choice(sorted(consume))
                new = (set(rng.sample([t.id for t in tasks], rng.randint(1, n))), rng.randint(0, 4))
                acts.append((rng.randint(0, 30), lambda s, c=c, new=new: s.consume.update({c: new})))
            stall_changed = rng.random() < 0.3
            if stall_changed:                                # stall change mid-run
                c = rng.choice(["c1", "c2"])
                at = rng.randint(0, 40)
                acts.append((rng.randint(0, 20), lambda s, c=c, at=at: s.stall_until.update({c: at})))
            sim.run(acts)
            m = self._ledger_ok(sim)
            for c, done in m["consumer_done"].items():
                need, svc = sim._consumption[c]["key"]          # the need set this completion consumed
                if sim.closed_at is None:
                    self.assertEqual((set(need), svc), (set(sim.consume[c][0]), sim.consume[c][1]), (case, c))
                acc = [sim.tasks[x].accepted_by.get(c) for x in need]
                self.assertNotIn(None, acc, (case, c))
                self.assertGreaterEqual(done, max(acc) + svc, (case, c))
                if not stall_changed:   # a stall set AFTER a finished consumption does not undo it
                    self.assertGreaterEqual(done, stall.get(c, 0) + svc, (case, c))
                self.assertEqual(done, sim._consumption[c]["start"] + svc, (case, c))
                for x in need:
                    self.assertFalse(sim.tasks[x].cancelled and sim.tasks[x].accepted_by.get(c) is None)
                if sim.closed_at is not None:
                    self.assertLessEqual(done, sim.closed_at, (case, c))


# ============================================================================================ F4 Windows fixture
class WindowsFixture(unittest.TestCase):
    """Runs the real Integrity fixture of test_revision.py under EMULATED Windows text mode (Path.write_text
    translating '\\n' to '\\r\\n', as Python does on Windows). Native Windows: NOT_RUN."""

    def _run_integrity_tests(self, emulate_crlf):
        import test_revision as TR
        orig = Path.write_text

        def win_write_text(self_, data, encoding=None, errors=None, newline=None):
            return orig(self_, data, encoding=encoding, errors=errors, newline="\r\n" if newline is None else newline)
        if emulate_crlf:
            Path.write_text = win_write_text
        try:
            suite = unittest.defaultTestLoader.loadTestsFromTestCase(TR.Integrity)
            import io
            res = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(suite)
        finally:
            Path.write_text = orig
        return res

    def test_integrity_fixture_passes_with_platform_newlines(self):
        res = self._run_integrity_tests(False)
        self.assertTrue(res.wasSuccessful(), [str(f[0]) for f in res.failures + res.errors])

    def test_integrity_fixture_passes_under_emulated_windows_text_mode(self):
        res = self._run_integrity_tests(True)
        self.assertTrue(res.wasSuccessful(), [(str(f[0]), f[1][-300:]) for f in res.failures + res.errors])


if __name__ == "__main__":
    unittest.main(verbosity=1)
