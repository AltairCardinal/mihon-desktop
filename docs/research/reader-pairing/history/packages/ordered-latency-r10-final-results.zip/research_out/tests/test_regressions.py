"""Regression tests for defects found in the returned R10 package (T03 prefetch bound, T04 mailbox capacity).
Written BEFORE the fixes; the pre-fix failure output is kept in raw/regressions/before_fix.txt.
Run:  python3 -B research_out/tests/test_regressions.py
"""
import sys
import unittest
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / "lab"))
import common  # noqa: E402,F401
import cachemodel as CM  # noqa: E402
import gamma as G  # noqa: E402
import sched as S  # noqa: E402


def nav_case(states, settings):
    return (states, [G.UNK] * len(states), {i: None for i in range(len(states) - 1)}), settings


class PrefetchBound(unittest.TestCase):
    """T03: Nav.go compared the next OBJECT index with len(plan) (the number of UNITS)."""

    def test_spec_example(self):
        w, st = nav_case(["SHAPE_X"] * 4, {"direction": "RTL", "automatic": False})
        self.assertEqual([tuple(o for o, _ in u["slots"]) for u in G.plan(G.make_case(*w, st))], [(0,), (1, 2), (3,)])
        nav = CM.Nav(w, st, prefetch=True)
        nav.go(1, +1)                          # consumes [1,2]; legal next object is 3
        self.assertIn(3, nav.mat.d, "prefetch must materialise the next unit [3]")

    def test_backward_and_tail(self):
        w, st = nav_case(["SHAPE_X"] * 4, {"direction": "RTL", "automatic": False})
        nav = CM.Nav(w, st, prefetch=True)
        nav.go(3, +1)                          # tail: no next object, nothing extra
        self.assertEqual(set(nav.mat.d), {3})
        nav2 = CM.Nav(w, st, prefetch=True)
        nav2.go(3, -1)                         # backward from [3]: previous unit is [1,2]
        self.assertTrue({1, 2} <= set(nav2.mat.d))
        nav3 = CM.Nav(w, st, prefetch=True)
        nav3.go(0, -1)                         # backward at the head: nothing before 0
        self.assertEqual(set(nav3.mat.d), {0})

    def test_unit_count_much_smaller_than_object_count(self):
        # 10 objects -> 6 units ([0],[1,2],...,[9]); prefetch after [7,8] must reach object 9 (>= len(plan)=6)
        w, st = nav_case(["SHAPE_X"] * 10, {"direction": "RTL", "automatic": False})
        plan = G.plan(G.make_case(*w, st))
        self.assertLess(len(plan), 10)
        nav = CM.Nav(w, st, prefetch=True)
        nav.go(7, +1)
        self.assertIn(9, nav.mat.d)

    def test_mixed_unit_sizes_with_shape_y(self):
        w, st = nav_case(["SHAPE_X", "SHAPE_X", "SHAPE_X", "SHAPE_Y", "SHAPE_X", "SHAPE_X"], {"direction": "LTR", "automatic": False})
        plan = G.plan(G.make_case(*w, st))
        starts = [u["slots"][0][0] for u in plan]
        for k, s0 in enumerate(starts[:-1]):
            nav = CM.Nav(w, st, prefetch=True)
            nav.go(s0, +1)
            for o, _ in plan[k + 1]["slots"]:
                self.assertIn(o, nav.mat.d, (s0, plan[k + 1]))


class MailboxCapacity(unittest.TestCase):
    """T04: a mailbox of capacity 1 must never hold more than 1 result, whatever the interleaving."""

    def run_sim(self, cap, n=4, service=5, accept_at=None):
        tasks = [S.Task(f"s{i}", "speculative", service, 0) for i in range(n)]
        sim = S.Sim(tasks, physical=4, mailbox=cap)
        acts = []
        if accept_at is not None:
            acts.append((accept_at, lambda s: s.accept_all("late_consumer")))
        sim.run(acts)
        return sim

    def test_capacity_one_simultaneous_completion(self):
        sim = self.run_sim(1)
        self.assertLessEqual(sim.peak["mailbox"], 1)

    def test_full_pool_keeps_bounded_ownership(self):
        sim = self.run_sim(1)
        m = sim.metrics()
        # 4 results, 1 in the pool, 3 held: each held result still owns its worker and logical slot
        self.assertEqual(m["results_in_pool"], 1)
        self.assertEqual(m["results_held_on_worker"], 3)
        self.assertEqual(m["workers_occupied_by_held_results"], 3)

    def test_consume_releases_once_and_close_frees_everything(self):
        sim = self.run_sim(1, accept_at=20)
        m = sim.metrics()
        self.assertEqual(m["results_in_pool"] + m["results_held_on_worker"], 0)
        self.assertEqual(m["result_releases"], 4)
        self.assertEqual(m["double_releases"], 0)
        sim2 = self.run_sim(1)
        sim2.close()
        m2 = sim2.metrics()
        self.assertEqual(m2["results_in_pool"] + m2["results_held_on_worker"], 0)
        self.assertEqual(m2["double_releases"], 0)

    def test_held_result_blocks_required_until_space(self):
        # pool capacity 0: all four results are held on their workers -> the required task waits for acceptance
        tasks = [S.Task(f"s{i}", "speculative", 5, 0) for i in range(4)] + [S.Task("r", "required", 3, 6)]
        sim = S.Sim(tasks, physical=4, mailbox=0)
        sim.run([(30, lambda s: s.accept_all("late_consumer"))])
        self.assertEqual(sim.tasks["r"].start, 30)
        # capacity 1: one result moves to the pool and frees one worker -> required starts at release
        tasks = [S.Task(f"s{i}", "speculative", 5, 0) for i in range(4)] + [S.Task("r", "required", 3, 6)]
        sim = S.Sim(tasks, physical=4, mailbox=1)
        sim.run([(30, lambda s: s.accept_all("late_consumer"))])
        self.assertEqual(sim.tasks["r"].start, 6)
        tasks = [S.Task(f"s{i}", "speculative", 5, 0) for i in range(4)] + [S.Task("r", "required", 3, 6)]
        sim = S.Sim(tasks, physical=4, mailbox=4)
        sim.run([(30, lambda s: s.accept_all("late_consumer"))])
        self.assertEqual(sim.tasks["r"].start, 6)


class MailboxFuzz(unittest.TestCase):
    """T04: random interleavings of completion, acceptance, cancel, failure, close and late exits."""

    def test_random_interleavings(self):
        import random
        rng = random.Random(4004)
        for case in range(600):
            n = rng.randint(1, 9)
            cap = rng.choice([None, 0, 1, 2, 3])
            tasks = []
            for i in range(n):
                role = rng.choice(["required", "speculative", "speculative", "optional"])
                t = S.Task(f"t{i}", role, rng.randint(1, 8), rng.randint(0, 6), bytes_upper=rng.choice([0, 1 << 20]),
                           obj=rng.choice(["", "a", "b"]))
                t.failed = rng.random() < 0.1
                if rng.random() < 0.4:
                    t.consumers.add(rng.choice(["c1", "c2"]))
                tasks.append(t)
            stall = {c: rng.randint(0, 20) for c in ("c1", "c2") if rng.random() < 0.6}
            sim = S.Sim(tasks, physical=rng.randint(1, 4), mailbox=cap, stall_until=stall,
                        pool_policy=rng.choice(["fifo", "required_first", "unit_first"]),
                        pool_reserved_required=rng.choice([0, 0, 1]), drop_on_full=rng.random() < 0.3)
            acts = []
            for _ in range(rng.randint(0, 4)):
                at = rng.randint(0, 25)
                kind = rng.choice(["accept", "cancel", "accept_all"])
                tid = f"t{rng.randrange(n)}"
                if kind == "accept":
                    acts.append((at, lambda s, tid=tid: s.accept(tid, "late")))
                elif kind == "cancel":
                    acts.append((at, lambda s, tid=tid: s.cancel(tid)))
                else:
                    acts.append((at, lambda s: s.accept_all("late")))
            close_at = rng.choice([None, rng.randint(0, 30)])
            if close_at is not None:
                acts.append((close_at, lambda s: s.close()))
            sim.run(acts)
            m = sim.metrics()
            self.assertEqual(sim.violations, [], (case, sim.violations[:3]))
            self.assertEqual(m["double_releases"], 0, case)
            self.assertLessEqual(max(sim.release_calls.values(), default=0), 1, case)
            self.assertEqual(m["unexited"], [], case)
            self.assertEqual(m["bytes_outstanding"], 0, case)        # every reservation settled at its real exit
            if close_at is not None:
                self.assertEqual(m["results_in_pool"] + m["results_held_on_worker"], 0, case)
            placed = [t for t in sim.tasks.values() if t.done or t.released]
            for t in placed:  # a result is released at most once and only if it was produced
                self.assertTrue(t.released <= (t.end is not None))
            # every produced result is either still resident or released exactly once
            resident = set(sim.mailbox) | set(sim.held)
            for t in sim.tasks.values():
                if t.end is not None and not t.cancelled and not t.failed and (sim.closed_at is None or t.end <= sim.closed_at) and t.state != "exited" or t.id in resident:
                    self.assertTrue((t.id in resident) != t.released, (case, t.id, t.state, t.released))


class MailboxMutants(unittest.TestCase):
    """The fuzz/capacity tests must catch the defect classes they claim to guard (mutation check, committed)."""

    def _fails(self, patch):
        import importlib
        orig = {k: getattr(S.Sim, k) for k in patch}
        for k, v in patch.items():
            setattr(S.Sim, k, v)
        try:
            suite = unittest.TestSuite()
            for cls in (MailboxCapacity, MailboxFuzz):
                suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
            res = unittest.TestResult()
            suite.run(res)
            return len(res.failures) + len(res.errors)
        finally:
            for k, v in orig.items():
                setattr(S.Sim, k, v)

    def test_pool_never_full_is_caught(self):
        self.assertGreater(self._fails({"pool_has_space": lambda self, t: True}), 0)

    def test_double_release_on_close_is_caught(self):
        orig_close = S.Sim.close

        def bad_close(self):
            orig_close(self)
            for t in self.tasks.values():
                if t.state == "delivered":
                    self._release_result(t, "closed_again")
        self.assertGreater(self._fails({"close": bad_close}), 0)

    def test_held_not_occupying_worker_is_caught(self):
        def bad_running(self, roles=None):
            return [t for t in self.tasks.values() if t.state == "running" and (roles is None or t.role in roles)]
        self.assertGreater(self._fails({"running": bad_running}), 0)


class ResidencyDedupe(unittest.TestCase):
    """Shared underlying objects are counted once in result residency (T04)."""

    def test_shared_object_counted_once(self):
        tasks = [S.Task(f"s{i}", "speculative", 5 + i, 0, obj="shared") for i in range(3)]
        sim = S.Sim(tasks, physical=4, mailbox=None).run()
        self.assertEqual(sim.peak["resident_results"], 1)
        tasks = [S.Task(f"s{i}", "speculative", 5 + i, 0, obj=f"o{i}") for i in range(3)]
        sim = S.Sim(tasks, physical=4, mailbox=None).run()
        self.assertEqual(sim.peak["resident_results"], 3)


if __name__ == "__main__":
    unittest.main()
