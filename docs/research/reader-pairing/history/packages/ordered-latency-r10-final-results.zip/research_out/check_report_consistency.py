"""Check that every Q/C id listed in REPORT.md section 4 sits under the category its coverage.csv decision says."""
import csv
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
rows = {r["id"]: r for r in csv.DictReader(open(OUT / "coverage.csv", encoding="utf-8"))}
text = (OUT / "REPORT.md").read_text(encoding="utf-8")
sec = text.split("## 4. 分类清单")[1].split("## 5.")[0]
cats = {"可进入小型工程试验": "engineering_trial", "只需补观测": "probe_first", "只有条件理论": "conditional_theory", "停止": "stop", "未完成": None}


def expand(s):
    ids = set()
    for m in re.finditer(r"Q(\d{3})–Q?(\d{3})", s):
        ids |= {f"Q{k:03d}" for k in range(int(m.group(1)), int(m.group(2)) + 1)}
    s2 = re.sub(r"Q\d{3}–Q?\d{3}", "", s)
    ids |= set(re.findall(r"Q\d{3}|C\d{2}(?!\d)", s2))
    return ids


def all_ids(sec):
    return expand(sec)


problems, seen = [], {}
for line in sec.splitlines():
    for name, dec in cats.items():
        if line.strip().startswith(f"- **{name}"):
            cur = (name, dec)
            break
    else:
        # sub-items of a category ("  - ...") belong to the current category. Closing-round self-found fix SF-5: the
        # previous test used line.strip().startswith("  -"), which is never true, so the indented 'stop' sub-lists
        # were never checked (C30 stayed listed under 'stop' after its decision changed).
        if not line.startswith("  -"):
            continue
    ids = expand(line)
    name, dec = cur
    for i in ids:
        if dec is None:
            if rows[i]["status"] != "incomplete":
                problems.append((i, "listed as incomplete but status", rows[i]["status"]))
            continue
        if "header" in line and i in ("Q034", "Q107"):
            continue
        seen.setdefault(i, set()).add(dec)
        if rows[i]["decision"] != dec:
            problems.append((i, f"listed under {dec}", rows[i]["decision"]))
dups = {k: v for k, v in seen.items() if len(v) > 1}
print("problems:", problems, "duplicates:", dups, "not_mentioned:", sorted(set(rows) - all_ids(sec)))


# ---------------------------------------------------------------- R10 revision: key numbers in REPORT.md vs raw results
import json  # noqa: E402

RAW = OUT / "raw"


def J(rel):
    return json.load(open(RAW / rel, encoding="utf-8"))


def cell(cid, inp, c):
    return J(f"joint/{cid}.json")["inputs"][inp]["cells"][c]


NUM = [  # (description, value from raw, expected value, string that must appear in REPORT.md)
    ("Q053 earlier", J("gamma/q053.json")["G4_compare"]["earlier_first"], 32, "32"),
    ("Q053 extra sums", (J("gamma/q053.json")["G4_compare"]["extra_C09"]["sum"], J("gamma/q053.json")["G4_compare"]["extra_pruned"]["sum"]), (491, 459), "491→459"),
    ("Q053 witnesses", J("gamma/q053.json")["G4_compare"]["witness_positions"], 459, "459"),
    ("Q053 partial", (J("gamma/q053.json")["partial_soundness"]["pruned_certified"], J("gamma/q053.json")["partial_soundness"]["unsound_pruned"]), (991, 0), "991"),
    ("T01 P", (J("pass1/obsworlds.json")["T01"]["counterexample"]["P_phase_locked"]["old_median_U_minus_C_ms"],
               J("pass1/obsworlds.json")["T01"]["counterexample"]["P_phase_locked"]["candidate_median_ms"]), (125.19685, 4.0), "125.19685"),
    ("SF-1", J("gamma/certificates.json")["domains"][1]["remaining_oracle_domain_narrower"], 8, "8 个"),
    ("T03 3/6 LRU pf", J("cache/cache.json")["histories"]["forward|pf=True|lru|3/6"]["ordinary_transforms"] -
     J("cache/cache.json")["histories"]["forward|pf=True|lru|3/6"]["strong_transforms"], 0, "**0**"),
    ("Q028 sweep", (J("sched/mailbox.json")["Q028"]["pool_capacity_sweep_independent_burst"]["2"]["r_start"],
                    J("sched/mailbox.json")["Q028"]["pool_capacity_sweep_independent_burst"]["3"]["r_start"]), (40, 10), "容量 ≥ 3"),
    ("C05 pool2", (cell("C05", "independent_burst_first@pool2", "AB_I")["cost"]["r_start"], cell("C05", "independent_burst_first@pool2", "AB_II")["cost"]["r_start"]), (40, 56), "56"),
    ("C02", (cell("C02", "C1_never_abandons", "AB_I")["m"], cell("C02", "C1_never_abandons", "AB_II")["m"]), (35, 15), "35→15"),
    ("C04", (cell("C04", "all_orders_of_upgrade_close_deadline_exit", "AB_I")["m"], cell("C04", "all_orders_of_upgrade_close_deadline_exit", "AB_II")["m"]), (0, 8), "24 种顺序 0 违例"),
    ("C15", (cell("C15", "fast_stream_6", "0")["m"], cell("C15", "fast_stream_6", "AB_I")["m"]), (45, 11), "45→11"),
    ("C03", (cell("C03", "single_burst", "0")["m"], cell("C03", "double_burst", "AB_I")["m"]), (55, 10), "55→0"),
    ("C08", (cell("C08", "forward", "0")["m"], cell("C08", "forward", "AB_I")["m"]), (1688, 849), "1688→849"),
    ("C09", (cell("C09", "early_change_far_target", "0")["m"], cell("C09", "early_change_far_target", "AB_II")["m"]), (581, 34), "581→34"),
    ("C18", (cell("C18", "M1", "A_I")["m"], cell("C18", "frequent_replacement", "AB_I")["m"]), (1736, 5761), "5761"),
    ("C11", (cell("C11", "long_chain", "0")["m"], cell("C11", "long_chain", "A_I")["m"], cell("C11", "sided", "A_I")["m"]), (41.0, 30.0, 30.0), "41→30"),
    ("C10", cell("C10", "stamp_overflow_k2", "A_I")["m"], 8, "8 次陈旧命中"),
    ("C12", cell("C12", "bad_metadata", "A_I")["m"], 7, "7 次翻转"),
    ("C26", cell("C26", "near_threshold_grey", "A_I")["m"], 41, "41 次"),
    ("C19", cell("C19", "far_jumps", "A_I")["m"], 273, "省 2 个物化"),
    # closing round (F1-F3)
    ("C30 D1 verdict", J("joint/C30.json")["notes"]["classifier_on_package"]["D1_main_gate"]["verdict"], "unknown", "证据不足"),
    ("C30 H2/H3 lower medians", (J("joint/C30.json")["notes"]["classifier_on_package"]["D1p_partner_only"]["lower_median_ns"],
                                 J("joint/C30.json")["notes"]["classifier_on_package"]["D1s_start_reopen_only"]["lower_median_ns"]),
     (124399450, 91716250), "124.4 ms 与 91.7 ms"),
    ("C30 decision", rows["C30"]["decision"], "probe_first", "stop → probe_first"),
    ("C09 V1 multi-update wrong worlds", J("regressions/c09_fix.json")["multi_no_query"]["V1"]["worlds_with_wrong"], 195, "195"),
    ("C09 single-update cost", (J("regressions/c09_fix.json")["single_any_pos"]["V1"]["steps"],
                                J("regressions/c09_fix.json")["single_any_pos"]["fixed"]["steps"]), (1314, 1413), "7.5%"),
    ("C09 published numbers unchanged", J("regressions/closing_round_before_after.json")["F2_C09"]["published_single_update_inputs"]["metric_values_identical"],
     True, "修复前后步数逐个相同"),
    ("F3 example", J("regressions/closing_round_before_after.json")["F3_consumer_done"]["reported_example"]["after"]["consumer_done"], 42, "7 → 42"),
]
bad_num = []
for desc, got, want, s in NUM:
    if got != want:
        bad_num.append((desc, "raw", got, "expected", want))
    if s not in text:
        bad_num.append((desc, "missing in REPORT.md", s))
print("numbers checked:", len(NUM), "problems:", bad_num)
if problems or dups or bad_num or (set(rows) - all_ids(sec)):
    raise SystemExit(1)
