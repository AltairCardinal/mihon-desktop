"""Integrity checks for the R10 package and the research outputs.

  python3 -B research_out/check_integrity.py            # verify originals vs MANIFEST.json, then REWRITE SHA256SUMS.txt
  python3 -B research_out/check_integrity.py --verify   # verify originals AND research outputs vs SHA256SUMS.txt (no writes)

All paths are compared as package-relative POSIX strings ("research_out/lab/x.py"), on every OS (T07 fix: the
previous version compared os-native strings, so on Windows every file looked unlisted). Any real problem -- hash
mismatch, size mismatch, missing listed file, unlisted original file, malformed or absolute or '..' path -- makes the
script exit with status 1. Unit tests: research_out/tests/test_revision.py::Integrity.
"""
import hashlib
import json
import os
import sys
from pathlib import Path, PurePosixPath, PureWindowsPath

OUT_NAME = "research_out"
IGNORED_DIRS = {"__pycache__"}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def norm_rel(s):
    """Normalise a manifest/checksum path to a package-relative POSIX string; raise ValueError if unsafe."""
    s = s.replace("\\", "/")
    if PureWindowsPath(s).drive or s.startswith("/"):
        raise ValueError(f"absolute path not allowed: {s!r}")
    raw = s.split("/")
    if not s or any(p in ("..", "") for p in raw):
        raise ValueError(f"unsafe relative path: {s!r}")
    parts = PurePosixPath(s).parts
    if not parts:
        raise ValueError(f"unsafe relative path: {s!r}")
    return PurePosixPath(*[p for p in parts if p != "."]).as_posix()


def walk_rel(root, sub=None):
    """Package-relative POSIX paths of all files under root (or root/sub), skipping cache directories."""
    root = Path(root)
    base = root / sub if sub else root
    out = []
    for r, ds, fs in os.walk(base):
        ds[:] = sorted(d for d in ds if d not in IGNORED_DIRS)
        for x in sorted(fs):
            out.append(Path(r, x).relative_to(root).as_posix())
    return out


def verify_manifest(pkg):
    pkg = Path(pkg)
    errors = []
    m = json.loads((pkg / "MANIFEST.json").read_text(encoding="utf-8"))
    listed = {"MANIFEST.json"}
    mismatch, missing = [], []
    for f in m["files"]:
        try:
            rel = norm_rel(f["path"])
        except ValueError as e:
            errors.append(str(e))
            continue
        listed.add(rel)
        p = pkg / rel
        if not p.is_file():
            missing.append(rel)
        elif p.stat().st_size != f["bytes"] or sha(p) != f["sha256"]:
            mismatch.append(rel)
    present = {r for r in walk_rel(pkg) if not r.startswith(OUT_NAME + "/")}
    unlisted = sorted(present - listed)
    res = {"manifest_files": len(m["files"]), "hash_or_size_mismatch": sorted(mismatch), "missing_listed_files": sorted(missing),
           "unlisted_original_files": unlisted, "path_errors": errors}
    res["ok"] = not (mismatch or missing or unlisted or errors)
    return res


def checksum_lines(pkg):
    pkg = Path(pkg)
    return [f"{sha(pkg / r)}  {r}" for r in walk_rel(pkg, OUT_NAME) if not r.endswith("/SHA256SUMS.txt")
            and r != f"{OUT_NAME}/SHA256SUMS.txt"]


def verify_checksums(pkg, sums_text):
    pkg = Path(pkg)
    bad, missing, errors, listed = [], [], [], set()
    for ln in sums_text.splitlines():
        if not ln.strip():
            continue
        try:
            h, rel = ln.split("  ", 1)
            rel = norm_rel(rel)
        except ValueError as e:
            errors.append(f"malformed line {ln!r}: {e}")
            continue
        if rel in listed:
            errors.append(f"duplicate entry {rel!r}")
        listed.add(rel)
        p = pkg / rel
        if not p.is_file():
            missing.append(rel)
        elif sha(p) != h:
            bad.append(rel)
    actual = {r for r in walk_rel(pkg, OUT_NAME) if r != f"{OUT_NAME}/SHA256SUMS.txt"}
    unlisted = sorted(actual - listed)
    return {"hash_mismatch": bad, "missing": missing, "unlisted": unlisted, "errors": errors,
            "ok": not (bad or missing or unlisted or errors)}


def main(argv):
    pkg = Path(__file__).resolve().parent.parent
    out = pkg / OUT_NAME
    res = verify_manifest(pkg)
    if "--verify" in argv:
        sums = verify_checksums(pkg, (out / "SHA256SUMS.txt").read_text(encoding="utf-8"))
        print(json.dumps({"manifest": res, "research_checksums": sums}))
        return 0 if (res["ok"] and sums["ok"]) else 1
    (out / "summary").mkdir(exist_ok=True)
    (out / "summary/package_integrity.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
    lines = checksum_lines(pkg)
    (out / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(res), len(lines), "research files hashed")
    return 0 if res["ok"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
