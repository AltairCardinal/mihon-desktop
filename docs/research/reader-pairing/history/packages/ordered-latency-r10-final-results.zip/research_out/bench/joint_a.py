"""Joint-design studies C01-C05 (R10 revision, T06). See joint_core.py for the protocol."""
import itertools
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import exp_mailbox as MB
import sched as S
from joint_core import study


# ================================================================================================ C01
def c01():
    """Unit {m1,m2} + k evidence-only neighbours to the LEFT. Materialisation 10, analysis 2 (needs the materialised
    object), certificate 1 (needs every analysis), consumption 3 (needs certificate + materialised members).
    A = one physical materialisation per object with two consumer edges (else separate visible and evidence mats);
    B = the visible pipeline does not wait for the certificate (else visible mats start after it).
    I : consumer-led priority (visible/member work required, neighbour evidence speculative).
    II: neutral materialisation service, FIFO in object order, per-consumer leases on the shared node."""
    def run(inp, d, a, b):
        workers, k = inp
        objs = [f"n{j}" for j in range(k)] + ["m1", "m2"]
        pos = {o: i for i, o in enumerate(objs)}
        tasks = []

        def role(o, visible):
            if d == "I":
                return "required" if (visible or o.startswith("m")) else "speculative"
            return "required"

        def tid(kind, o):
            return f"{pos[o]:02d}_{kind}_{o}"
        for o in objs:
            tasks.append(S.Task(tid("matE", o), role(o, False), 10, 0, obj=o))
            tasks.append(S.Task(tid("an", o), role(o, False), 2, 0, deps=(tid("matE", o),), obj=o))
        tasks.append(S.Task("99_cert", "required", 1, 0, deps=tuple(tid("an", o) for o in objs)))
        if a:
            vis = (tid("matE", "m1"), tid("matE", "m2"))
        else:
            vd = () if b else ("99_cert",)
            tasks += [S.Task(tid("matV", m), role(m, True), 10, 0, deps=vd, obj=m) for m in ("m1", "m2")]
            vis = (tid("matV", "m1"), tid("matV", "m2"))
        sim = S.Sim(tasks, physical=workers, policy=("fifo" if d in (None, "II") else "priority"),
                    consume={"unit": (set(vis) | {"99_cert"}, 3)}).run()
        m = sim.metrics()
        leases = (2 * 2 + k) if (a and d == "II") else 0
        return {"m": m["consumer_done"]["unit"],
                "cost": {"physical_work": m["physical_work"], "cert_done": sim.tasks["99_cert"].end,
                         "visible_ready": max(sim.tasks[v].end for v in vis), "materialisations": sum(1 for t in tasks if "mat" in t.id),
                         "consumer_leases": leases}, "ok": not sim.violations}
    inputs = {f"w{w}_k{k}": (w, k) for w in (1, 2, 4) for k in (1, 3)}
    return study("C01", "complete-unit ack time (model units)", "lower", inputs, run,
                 {"I": "consumer-led: members/visible required, neighbour evidence speculative",
                  "II": "neutral materialisation service: FIFO by object position, leases per consumer"},
                 "priority by consumer (I) vs consumer-blind service order with lease delivery (II)")


# ================================================================================================ C02
def c02():
    """One worker. busy(spec,10)@0, s1(spec,20)@0, x(spec,5)@1 for C1. C2 needs x's result from t=2 (required).
    C1 abandons x at time c (input). A = deduplicate (C2 attaches to x) else C2 starts its own x2.
    I : A_I = attach with a reference count; B_I = physical cancel only when the count reaches 0.
    II: A_II = attach to a demand set with priority inheritance (x takes the max demander priority);
        B_II = on abandonment, explicit ownership transfer to a remaining demander (else cancel)."""
    def run(inp, d, a, b):
        c_at = inp
        tasks = [S.Task("busy", "speculative", 10, 0), S.Task("s1", "speculative", 20, 0), S.Task("x", "speculative", 5, 1)]
        tasks[2].consumers.add("C1")
        sim = S.Sim(tasks, physical=1)
        state = {"wrong": 0, "c2_task": None}

        def join(s):
            if a and s.tasks["x"].state in ("pending", "queued", "running"):   # attach only to a live job
                s.tasks["x"].consumers.add("C2")
                state["c2_task"] = "x"
                if d == "II" and s.tasks["x"].state in ("pending", "queued", "running"):
                    s.tasks["x"].role = "required"          # priority inheritance
            else:
                t2 = S.Task("x2", "required", 5, s.now)
                t2.state = "queued"
                t2.consumers.add("C2")
                s.tasks["x2"] = t2
                state["c2_task"] = "x2"

        def abandon(s):
            x = s.tasks["x"]
            x.consumers.discard("C1")
            others = bool(x.consumers)
            if not b:
                s.cancel("x")                               # naive: kill regardless of other demand
                if others:
                    state["wrong"] = 1                      # C2 lost its result -> restart
                    t3 = S.Task("x3", "required", 5, s.now)
                    t3.state = "queued"
                    s.tasks["x3"] = t3
                    state["c2_task"] = "x3"
            elif not others:
                s.cancel("x")
            elif d == "II":
                x.role = "required"                          # ownership moves to C2 (its priority)
        acts = [(2, join)]
        if c_at is not None:
            acts.append((c_at, abandon))
        sim.run(acts)
        tid = state["c2_task"]
        done = sim.tasks[tid].end
        m = sim.metrics()
        return {"m": done, "cost": {"wrong_restart": state["wrong"], "physical_work": m["physical_work"],
                                    "wasted_work": m["wasted_work"]}, "ok": not sim.violations}
    inputs = {"C1_never_abandons": None, "abandon_before_join_t1": 1, "abandon_queued_t3": 3, "abandon_t12": 12}
    return study("C02", "C2 result time (model units)", "lower", inputs, run,
                 {"I": "reference-counted lease; physical cancel only when no live demand",
                  "II": "demand set with priority inheritance; explicit ownership transfer on abandonment"},
                 "I keeps the creator's priority and only protects against cancellation; II changes the job's priority "
                 "to the strongest live demander at join and at transfer")


# ================================================================================================ C03
def c03():
    """4 workers shared by all roles. A protects foreground capacity, B governs optional admission.
    I : A_I = hard physical reserve (non-required work never takes the last free worker);
        B_I = optional is strictly lowest and uses at most one logical optional slot.
    II: A_II = service-bound gate for speculative work (admit only if service <= blocking budget 10);
        B_II = the same gate for optional work."""
    BUDGET, H = 10, 70

    def mk(spec):
        return [S.Task(i, r, s, rel) for i, r, s, rel in spec]
    inputs = {
        "single_burst": [("o0", "optional", 60, 0), ("o1", "optional", 60, 0), ("s0", "speculative", 60, 0),
                         ("s1", "speculative", 60, 0), ("r", "required", 10, 5)],
        "double_burst": [("o0", "optional", 60, 0), ("o1", "optional", 60, 0), ("s0", "speculative", 60, 0),
                         ("s1", "speculative", 60, 0), ("r", "required", 10, 5), ("r2", "required", 10, 5)],
        "short_background": [("s0", "speculative", 4, 0), ("s1", "speculative", 4, 0), ("s2", "speculative", 4, 0),
                             ("o0", "optional", 4, 0), ("o1", "optional", 4, 0), ("r", "required", 10, 5), ("r2", "required", 10, 6)],
        "no_required": [("o0", "optional", 60, 0), ("o1", "optional", 60, 0), ("s0", "speculative", 60, 0),
                        ("s1", "speculative", 8, 0), ("s2", "speculative", 8, 0)],
    }

    def run(inp, d, a, b):
        tasks = mk(inp)
        kw = {}
        gate_roles = set()
        if d == "I":
            if a:
                kw["reserve_physical"] = 1
            if b:
                kw["opt_slots"] = 1
        if d == "II":
            if a:
                gate_roles.add("speculative")
            if b:
                gate_roles.add("optional")
        if gate_roles:
            kw["gate"] = lambda s, t: t.role not in gate_roles or t.service <= BUDGET
        sim = S.Sim(tasks, physical=4, **kw).run(until=10 ** 6)
        req = [t for t in sim.tasks.values() if t.role == "required"]
        blocking = max((t.start - t.release for t in req), default=0)
        bg = sum(max(0, min(t.end, H) - t.start) for t in sim.tasks.values() if t.role != "required" and t.start is not None)
        never = sum(1 for t in sim.tasks.values() if t.start is None)
        return {"m": blocking, "cost": {"background_work_by_70": bg, "background_tasks_never_admitted": never},
                "ok": not sim.violations}
    return study("C03", "max blocking of required work (start - release, model units)", "lower", inputs, run,
                 {"I": "hard physical reserve + optional only in the remainder",
                  "II": "service-bound admission gate (speculative, optional)"},
                 "I reserves capacity regardless of service time; II admits by declared service bound and needs that bound")


# ================================================================================================ C04
def c04():
    """Ledger interpreter for one read T of U=8 MiB, 5 MiB read when the interleaving starts. Events (all orders):
    upgrade (consumer C2 in context Y needs T), close_X (creator context X closes), deadline (permit renewal by its
    holder), exit (T's real end; it always reads all U). A = in-place upgrade (else cancel-and-restart T'),
    I : A_I = keep T and its permit, only raise the consumer priority; B_I = single-owner settlement at the real exit
        (a context close never refunds a permit whose task is still running).
    II: A_II = transfer task ownership to Y on upgrade; B_II = atomic migration of the reservation with the owner."""
    U, R = 8, 5
    events = ["upgrade", "close_X", "deadline", "exit"]
    orders = list(itertools.permutations(events))

    def run_order(order, d, a, b):
        led = {"rereads": 0, "refunds": 0, "double_refund": 0, "hole": 0, "deadline_fail": 0, "peak": U}
        permits = {"T": {"holder": "X", "amount": U, "live": True}}
        task_owner = {"T": "X"}
        running = {"T": True}
        closed = set()
        upgraded = False

        def reserved():
            return sum(p["amount"] for p in permits.values() if p["live"])

        def refund(pid):
            p = permits[pid]
            if not p["live"]:
                led["double_refund"] += 1
                return
            p["live"] = False
            led["refunds"] += 1
        for e in order:
            if e == "upgrade" and not upgraded:
                upgraded = True
                if not a:                                         # cancel-and-restart
                    led["rereads"] += R if running["T"] else 0
                    running["T2"] = True
                    task_owner["T2"] = "Y"
                    if d == "II" and b:                           # migrate T's reservation to T2 (T keeps reading)
                        permits["T2"] = {"holder": "Y", "amount": permits["T"]["amount"], "live": permits["T"]["live"]}
                        permits["T"]["live"] = False
                        if running["T"]:
                            led["hole"] = 1                       # T still reads without reservation
                    else:
                        permits["T2"] = {"holder": "Y", "amount": U, "live": True}
                elif d == "II":
                    task_owner["T"] = "Y"
                    if b:
                        permits["T"]["holder"] = "Y"              # atomic migration with the owner
                # d == "I" with a: priority only, nothing else changes
            elif e == "close_X":
                closed.add("X")
                for pid, p in permits.items():
                    if p["holder"] == "X" and p["live"]:
                        if d == "I" and b and running.get(pid, False):
                            p["holder_closed"] = True             # settled later at the real exit
                        else:
                            refund(pid)
                            if running.get(pid, False):
                                led["hole"] = 1                   # bytes still being read with no reservation
            elif e == "deadline":
                for pid, p in permits.items():
                    if p["live"] and running.get(pid, False) and p["holder"] in closed and not p.get("holder_closed"):
                        led["deadline_fail"] = 1                  # nobody alive to renew the permit
                    if running.get(pid, False) and not p["live"] and task_owner.get(pid) not in closed:
                        led["deadline_fail"] = 1                  # live consumer, lapsed permit
            elif e == "exit":
                running["T"] = False
                if permits["T"]["live"]:
                    refund("T")
                elif not (d == "II" and b and not a):
                    pass
            led["peak"] = max(led["peak"], reserved())
        # T2 (if any) finishes after the window; settle once
        if "T2" in permits and permits["T2"]["live"]:
            refund("T2")
            led["rereads"] += 0
        return led

    def run(inp, d, a, b):
        tot = {"rereads": 0, "double_refund": 0, "hole": 0, "deadline_fail": 0, "peak_max": 0, "orders": len(orders)}
        bad = 0
        for o in orders:
            led = run_order(o, d, a, b)
            tot["rereads"] += led["rereads"]
            tot["double_refund"] += led["double_refund"]
            tot["hole"] += led["hole"]
            tot["deadline_fail"] += led["deadline_fail"]
            tot["peak_max"] = max(tot["peak_max"], led["peak"])
            bad += bool(led["double_refund"] or led["hole"] or led["deadline_fail"])
        return {"m": bad, "cost": tot, "ok": True}
    return study("C04", "interleavings (of 24) with a ledger violation (hole, double refund, unrenewable permit)", "lower",
                 {"all_orders_of_upgrade_close_deadline_exit": None}, run,
                 {"I": "keep task and permit; raise consumer priority; settle once at the real exit",
                  "II": "transfer ownership to the new context and migrate the reservation atomically"},
                 "I leaves the permit with the creator and forbids refund-before-exit; II moves the permit to the new owner")


# ================================================================================================ C05
def c05():
    """Executable model from exp_mailbox (same Sim, same pool capacity for both designs)."""
    inputs = {k: (v, None) for k, v in MB.inputs().items()}
    inputs["independent_burst_first@pool2"] = (MB.inputs()["independent_burst_first"], 2)   # tight capacity, both designs

    def run(inp, d, a, b):
        pool = d if a else "none"
        batch = d if b else "none"
        r = MB.run_cell(inp[0], pool, batch, cap=inp[1])
        return {"m": r["unit_ack"], "cost": {k: r[k] for k in ("r_start", "independent_commit_max", "peak_resident_results",
                                                              "held_worker_time", "double_releases", "violations")},
                "ok": r["violations"] == 0 and r["double_releases"] == 0}
    return study("C05", "complete-unit ack time (model units); r_start = required task start", "lower", inputs, run,
                 {"I": "bounded pool, freed places go first to held members of the awaited unit; only independent results batched",
                  "II": "same pool with 2 places reserved for the complete unit; one batch per deadline, split on time-out"},
                 "drain order (I) vs ahead-of-time space reservation + common deadline (II), equal pool capacity")
