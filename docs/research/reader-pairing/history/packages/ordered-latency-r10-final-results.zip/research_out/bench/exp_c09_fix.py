"""Closing round, fix F2: before/after comparison of the C09 design-II structure.

  ChunkedLazyV1  (retracted)  earliest-suspect pointer + 'first convergence => everything later valid'
  ChunkedLazy    (fixed)      exact read-set dirtiness (direct) + entry/exit convergence (propagated only)

Oracle: gamma.plan of the CURRENT case (complete left-to-right recomputation, same step semantics).
Families (all with the C09 query pattern: a target and the next 3 units):
  c09_inputs        the four C09 inputs (5 worlds each, n=176, chunk 8, RTL/automatic) -- the single-update domain
                    on which the published C09 numbers were measured
  single_any_pos    one change at a uniformly random position (n=176, chunk 8, C09 settings), 200 worlds
  single_manual     one change, settings with a contiguous manual-start run (long dependency), 200 worlds
  multi_no_query    2-4 changes before the first query (the reported defect class), 200 worlds
Output: raw/regressions/c09_fix.json
"""
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import evidence as E
import gamma as G
import joint_b as JB
from common import RAW, env, write_json

ST = JB.ST


def targets_for(plan, t, n):
    out = [t]
    nxt = max(o for o, _ in G.unit_of(plan, t)["slots"]) + 1
    for _ in range(3):
        if nxt >= n:
            break
        out.append(nxt)
        nxt = max(o for o, _ in G.unit_of(plan, nxt)["slots"]) + 1
    return out


def one(cls, states, sides, scores, st, changes, t, chunk=8):
    case = G.make_case(list(states), sides, scores, dict(st))
    s = cls(case, chunk, lazy=True)
    s.ensure(s.nk - 1)
    s.ops = 0
    cur = list(states)
    for pos in changes:
        cur[pos] = "SHAPE_Y" if cur[pos] == "SHAPE_X" else "SHAPE_X"
        case = G.make_case(list(cur), sides, scores, dict(st))
        s.update(case, pos)
    plan = G.plan(case)
    tg = targets_for(plan, t, len(cur))
    wrong = 0
    for x in tg:
        try:
            wrong += s.unit(x) != G.unit_of(plan, x)
        except AssertionError:
            wrong += 1
    return {"steps": s.ops, "wrong_units": wrong, "checks": getattr(s, "checks", None),
            "diff_compares": getattr(s, "diff_compares", None)}


def family(name, gen, count):
    tot = {"V1": {"steps": 0, "wrong_units": 0, "worlds_with_wrong": 0},
           "fixed": {"steps": 0, "wrong_units": 0, "worlds_with_wrong": 0, "checks": 0, "diff_compares": 0}}
    for k in range(count):
        args = gen(k)
        for label, cls in (("V1", JB.ChunkedLazyV1), ("fixed", JB.ChunkedLazy)):
            r = one(cls, *args)
            tot[label]["steps"] += r["steps"]
            tot[label]["wrong_units"] += r["wrong_units"]
            tot[label]["worlds_with_wrong"] += r["wrong_units"] > 0
            if label == "fixed":
                tot[label]["checks"] += r["checks"]
                tot[label]["diff_compares"] += r["diff_compares"]
    tot["worlds"] = count
    return tot


def main():
    out = {"env": env(), "oracle": "gamma.plan of the current case", "units": "scan steps (model units)"}
    c09 = {}
    for name, (kind, pos, t) in {"early_change_far_target": ("sparse", 3, 120), "change_near_target": ("sparse", 115, 120),
                                 "long_chain_early_change": ("long_chain", 3, 120), "no_change": ("sparse", None, 120)}.items():
        def gen(k, kind=kind, pos=pos, t=t):
            rng = random.Random(900 + k)
            if kind == "long_chain":
                w = E.random_world(176, rng, p_y=0.0, p_side=0.0, p_null=0.0, smax=40)
            else:
                w = E.random_world(176, rng)
            return (w[0], w[1], w[2], ST, [] if pos is None else [pos], t)
        c09[name] = family(name, gen, 5)
    out["c09_inputs"] = c09

    def g_single(k):
        rng = random.Random(5000 + k)
        w = E.random_world(176, rng)
        pos = rng.randrange(176)
        return (w[0], w[1], w[2], ST, [pos], min(175, pos + rng.randint(0, 20)))
    out["single_any_pos"] = family("single_any_pos", g_single, 200)

    def g_manual(k):
        rng = random.Random(6000 + k)
        w = E.random_world(176, rng)
        a = rng.randrange(150)
        st = dict(ST, manual=list(range(a, a + rng.randint(5, 26))))
        pos = rng.randrange(a, min(176, a + 10))
        return (w[0], w[1], w[2], st, [pos], min(175, pos + rng.randint(0, 30)))
    out["single_manual"] = family("single_manual", g_manual, 200)

    def g_multi(k):
        rng = random.Random(7000 + k)
        w = E.random_world(176, rng)
        ch = [rng.randrange(176) for _ in range(rng.randint(2, 4))]
        return (w[0], w[1], w[2], ST, ch, min(175, max(ch)))
    out["multi_no_query"] = family("multi_no_query", g_multi, 200)
    write_json(RAW / "regressions/c09_fix.json", out)
    return out


if __name__ == "__main__":
    import json
    o = main()
    print(json.dumps({k: v for k, v in o.items() if k != "env"}, indent=1))
