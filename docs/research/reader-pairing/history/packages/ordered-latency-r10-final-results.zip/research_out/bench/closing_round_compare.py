"""Closing round: before/after comparison of the four targeted fixes and their impact scan.
Inputs : history/before_closing_round/** (copies of the raw files as delivered before this round),
         the current raw/ tree, raw/regressions/c09_fix.json, the fixed implementations.
Output : raw/regressions/closing_round_before_after.json
Run    : python3 -B research_out/bench/closing_round_compare.py   (after exp_joint.py, exp_combos.py, exp_c09_fix.py)
"""
import json
import re
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / "lab"))
sys.path.insert(0, str(OUT / "bench"))
import sched as S  # noqa: E402
from common import RAW, write_json  # noqa: E402

BEFORE = Path(__file__).resolve().parents[1] / "history/before_closing_round"
VOLATILE = {"env", "pid", "seconds", "rerun_env", "utc_start", "utc_end", "median_ns", "min_ns", "max_ns"}


def strip(o):
    if isinstance(o, dict):
        return {k: strip(v) for k, v in o.items() if k not in VOLATILE}
    if isinstance(o, list):
        return [strip(v) for v in o]
    return o


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def sim_calls(src):
    """AST scan (acceptance finding: the earlier regex could not cross nested parentheses). Counts Sim(...) calls,
    calls passing both consume= and stall_until= explicitly, and calls with **kwargs (dynamic: reported, then
    inspected by hand in ACCEPTANCE.md)."""
    import ast
    out = {"calls": 0, "combined": 0, "with_consume": 0, "with_stall_until": 0, "dynamic_kwargs": 0}
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, ast.Call) and getattr(node.func, "attr", getattr(node.func, "id", None)) == "Sim":
            kws = {k.arg for k in node.keywords}
            out["calls"] += 1
            out["with_consume"] += "consume" in kws
            out["with_stall_until"] += "stall_until" in kws
            out["combined"] += {"consume", "stall_until"} <= kws
            out["dynamic_kwargs"] += None in kws
    return out


def metric_table(d):
    return {name: {c: r["m"] for c, r in v["cells"].items()} for name, v in d["inputs"].items()}


def main():
    out = {"note": "model units / package artefacts only; no product timing"}
    # ---------------------------------------------------------------- F1 C30
    b30, a30 = load(BEFORE / "joint/C30.json"), load(RAW / "joint/C30.json")
    out["F1_C30"] = {
        "before": {"metric": b30["metric"], "cells": metric_table(b30),
                   "D1_action_in_AB": "stop (excluded by min_total_reduction_ns > 0)"},
        "after": {"metric": a30["metric"], "cells": metric_table(a30),
                  "actions_AB_II": {k: v["cells"]["AB_II"]["cost"]["actions"] for k, v in a30["inputs"].items()},
                  "classifier_on_package": {k: v["verdict"] for k, v in a30["notes"]["classifier_on_package"].items()}},
        "retracted_rule": a30["notes"]["retracted_rule"],
        "coverage_decision": {"before": "stop", "after": "probe_first"}}
    bc, ac = load(BEFORE / "combos/combos.json"), load(RAW / "combos/combos.json")
    out["F1_C30"]["v1_combos_pointer"] = {"before": bc["C30"]["cells"], "after": ac["C30"]["cells"],
                                          "other_combos_unchanged": all(strip(bc[k]) == strip(ac[k]) for k in bc if k != "C30" and k not in VOLATILE)}
    # ---------------------------------------------------------------- F2 C09
    b9, a9 = load(BEFORE / "joint/C09.json"), load(RAW / "joint/C09.json")
    out["F2_C09"] = {"published_single_update_inputs": {"before": metric_table(b9), "after": metric_table(a9),
                                                        "metric_values_identical": metric_table(b9) == metric_table(a9)},
                     "design_II_costs_after": {k: v["cells"]["AB_II"]["cost"] for k, v in a9["inputs"].items()},
                     "domain_experiment": {k: v for k, v in load(RAW / "regressions/c09_fix.json").items() if k != "env"}}
    # ---------------------------------------------------------------- F3 consumer_done
    t = S.Task("x", "required", 5, 0, consumers={"ui"})
    sim = S.Sim([t], physical=1, consume={"ui": ({"x"}, 2)}, stall_until={"ui": 40}).run()
    scan = {}
    for p in sorted((OUT / "bench").glob("*.py")) + sorted((OUT / "lab").glob("*.py")):
        if p.name in ("closing_round_compare.py", "sched.py"):
            continue
        r = sim_calls(p.read_text(encoding="utf-8"))
        if r["calls"]:
            scan[p.name] = r
    probe = sim_calls('S.Sim([t], physical=1, consume={"ui": ({"x"}, 2)}, stall_until={"ui": 40}).run()')
    assert probe["combined"] == 1, probe          # sensitivity check: the scan must flag the reported example's call
    out["F3_consumer_done"] = {
        "reported_example": {"before": {"accepted_at": 40, "consumer_done": 7,
                                        "source": "raw/regressions/before_fix_final.txt (ConsumerDone.test_reported_counterexample)"},
                             "after": {"accepted_at": sim.tasks["x"].accepted_at, "consumer_done": sim.metrics()["consumer_done"]["ui"]}},
        "static_scan_of_experiments": scan,
        "static_scan_sensitivity_check": probe,
        "rerun_raw_identical_to_delivered": {
            f: strip(load(BEFORE / f)) == strip(load(RAW / f))
            for f in ["sched/sched.json", "sched/mailbox.json", "misc/misc.json", "workloads/workloads.json"]
            + [f"joint/C{k:02d}.json" for k in range(1, 31) if k not in (9, 30)]},
        "note": "no experiment combines consume= with stall_until in one Sim; C05/Q028 read accepted_at, which this fix does not "
                "change for single-consumer tasks. Every scheduler-based raw output was regenerated with the fixed sched.py "
                "and compared with the delivered copy (volatile fields ignored)."}
    # ---------------------------------------------------------------- F4 fixture
    out["F4_windows_fixture"] = {"before": "write_text fixture + hard-coded LF lengths (a.py 9, B.md 2): under Windows text mode "
                                           "the files are 10 and 3 bytes and the checker rejects them (correctly)",
                                 "after": "write_bytes fixture; lengths/hashes from bytes on disk; LF, CRLF and backslash manifests "
                                          "tested; wrong length / wrong hash / LF-listed-but-CRLF-file still fail",
                                 "native_windows": "NOT_RUN (no Windows host); Windows text mode EMULATED in "
                                                   "tests/test_final_fixes.py::WindowsFixture"}
    write_json(RAW / "regressions/closing_round_before_after.json", out)
    return out


if __name__ == "__main__":
    o = main()
    print(json.dumps({k: (v if k != "F2_C09" else {kk: vv for kk, vv in v.items() if kk != "domain_experiment"}) for k, v in o.items()},
                     ensure_ascii=False, indent=1)[:4000])
