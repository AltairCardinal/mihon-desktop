"""Harness for the R10-revision joint-design studies (T06).

Every combination is studied with TWO joint designs whose mechanisms differ (not parameter variants). Each design d
is split into its own two components A_d and B_d and evaluated as a full ablation 0 / A_d / B_d / AB_d on the SAME
inputs, oracle, resources and ledger (the '0' cell is shared). Every cell is produced by running the model; nothing
is copied from another table. Interaction per design: I_d = f(AB_d) - f(A_d) - f(B_d) + f(0) on the declared scalar.
Designs are 'distinguished' only when some input gives different metric or cost vectors for AB_I and AB_II; if no
input does, the study says so and the designs are reported as merged.
"""

CELLS = ("0", "A_I", "B_I", "AB_I", "A_II", "B_II", "AB_II")


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def study(cid, metric, better, inputs, run, designs, mechanism_difference, verdict_fn=None, notes=None):
    """run(inp, design, a_on, b_on) -> {"m": scalar-or-None, "cost": dict, "ok": bool}."""
    out = {"id": cid, "metric": metric, "better": better, "designs": designs,
           "mechanism_difference": mechanism_difference, "inputs": {}}
    dist = {}
    oracle_failures = []
    for name, inp in inputs.items():
        cells = {"0": run(inp, None, False, False)}
        for d in ("I", "II"):
            cells[f"A_{d}"] = run(inp, d, True, False)
            cells[f"B_{d}"] = run(inp, d, False, True)
            cells[f"AB_{d}"] = run(inp, d, True, True)
        inter = {}
        for d in ("I", "II"):
            v = [cells[c]["m"] for c in ("0", f"A_{d}", f"B_{d}", f"AB_{d}")]
            inter[d] = (v[3] - v[1] - v[2] + v[0]) if all(_num(x) for x in v) else None
        out["inputs"][name] = {"cells": cells, "interaction": inter}
        a, b = cells["AB_I"], cells["AB_II"]
        diffs = {}
        if a["m"] != b["m"]:
            diffs["metric"] = {"AB_I": a["m"], "AB_II": b["m"]}
        for k in sorted(set(a.get("cost", {})) | set(b.get("cost", {}))):
            if a.get("cost", {}).get(k) != b.get("cost", {}).get(k):
                diffs[k] = {"AB_I": a.get("cost", {}).get(k), "AB_II": b.get("cost", {}).get(k)}
        if diffs:
            dist[name] = diffs
        for c, r in cells.items():
            if not r.get("ok", True):
                oracle_failures.append((name, c))
    out["distinguishing_inputs"] = dist
    out["designs_distinguished"] = bool(dist)
    out["oracle_failures"] = oracle_failures
    if notes:
        out["notes"] = notes
    if verdict_fn:
        out["verdict"] = verdict_fn(out)
    return out


def table(out, keys=("m",)):
    """Compact view: input -> cell -> metric."""
    return {name: {c: r["m"] for c, r in v["cells"].items()} for name, v in out["inputs"].items()}
