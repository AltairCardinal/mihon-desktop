"""Timing of Q053 route B' (pruned entries) vs C09 in the Python model: 3 independent SERIAL processes.
Usage:  python3 -B bench/bench_prune.py drive      (spawns 3 child processes one after another)
        python3 -B bench/bench_prune.py child <run_id>
Writes raw/bench/prune_<run_id>.json. Python timing of a research model; never converted to product milliseconds."""
import json
import os
import random
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import evidence as E
import gamma as G
from common import RAW, write_json

ST = {"direction": "RTL", "automatic": True}


def child(run_id):
    rng = random.Random(41)
    cases = []
    for _ in range(60):
        w = E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40)
        cases.append((G.make_case(*w, ST), rng.randrange(25, 55)))
    out = {"run": run_id, "pid": os.getpid(), "python": sys.version.split()[0], "cases": len(cases)}
    for name, kw in (("C09", {}), ("pruned", {"prune": True})):
        t0 = time.perf_counter_ns()
        for c, t in cases:
            G.certify(c, t, **kw)
        out[f"{name}_ns"] = time.perf_counter_ns() - t0
    out["ratio"] = out["pruned_ns"] / out["C09_ns"]
    write_json(RAW / f"bench/prune_{run_id}.json", out)
    print(json.dumps(out))


def drive():
    for k in range(3):
        subprocess.run([sys.executable, "-B", __file__, "child", f"r{k}"], check=True)
    rs = [json.load(open(RAW / f"bench/prune_r{k}.json")) for k in range(3)]
    summ = {"runs": [{k: r[k] for k in ("run", "pid", "C09_ns", "pruned_ns", "ratio")} for r in rs],
            "ratio_range": [min(r["ratio"] for r in rs), max(r["ratio"] for r in rs)],
            "note": "60 G4-style worlds; pruning runs only where C09 fails at a window; serial processes, no other heavy job"}
    write_json(RAW / "bench/prune_summary.json", summ)
    print(json.dumps(summ["ratio_range"]))


if __name__ == "__main__":
    if sys.argv[1] == "child":
        child(sys.argv[2])
    else:
        drive()
