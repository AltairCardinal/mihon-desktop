"""Q053 (R10 revision): second exact-entry route implemented and checked.

Route B' = gamma.certify(..., prune=True): drop C08 entries that no predecessor configuration can reach given the
known facts at >= first (local backward reachability over all left-side assignments). Checks:
  1. G4 worlds (same generator/seed as exp_gamma2.g4_entries): soundness vs the full plan, backward extent, support.
  2. Information boundary: at every position p in (first_pruned, t-2] look for a witness pair (two complete worlds
     equal on all facts >= p, different target units). A witness at a position where B' certified = unsoundness.
  3. Partial knowledge soundness against Ω(K) by completion (60-object worlds are too big for Ω; we use n=10 worlds
     with <= 3 unknown facts, Ω enumerated over the realizable value domains of those facts).
Output raw/gamma/q053.json
"""
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import entry_witness as W
import evidence as E
import gamma as G
from common import RAW, env, write_json

ST = {"direction": "RTL", "automatic": True}


def g4_compare(k=300):
    rng = random.Random(41)
    ws = [E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40) for _ in range(k)]
    out = {"worlds": k, "unsound_pruned": 0, "earlier_first": 0, "same_first": 0, "later_first": 0,
           "extra_C09": [], "extra_pruned": [], "support_C09": [], "support_pruned": [], "witness_positions": 0,
           "witness_at_pruned_certified_position": 0, "undetermined_positions": 0, "seconds_C09": 0.0, "seconds_pruned": 0.0}
    wrng = random.Random(5302)
    examples = []
    for w in ws:
        case = G.make_case(*w, ST)
        t = rng.randrange(25, 55)
        t0 = time.perf_counter()
        a = G.certify(case, t)
        t1 = time.perf_counter()
        b = G.certify(case, t, prune=True)
        t2 = time.perf_counter()
        out["seconds_C09"] += t1 - t0
        out["seconds_pruned"] += t2 - t1
        truth = G.unit_of(G.plan(case), t)
        assert a["unit"] == truth
        out["unsound_pruned"] += b["status"] != "Certified" or b["unit"] != truth
        out["extra_C09"].append(max(0, t - 2 - a["first"]))
        out["extra_pruned"].append(max(0, t - 2 - b["first"]))
        out["support_C09"].append(len(a["dependent_objects"]))
        out["support_pruned"].append(len(b["dependent_objects"]))
        if b["first"] > a["first"]:
            out["earlier_first"] += 1
            if len(examples) < 3:
                examples.append({"t": t, "first_C09": a["first"], "first_pruned": b["first"],
                                 "support_C09": a["dependent_objects"], "support_pruned": b["dependent_objects"]})
        elif b["first"] == a["first"]:
            out["same_first"] += 1
        else:
            out["later_first"] += 1
        # information boundary above the pruned certificate
        for p in range(b["first"] + 1, max(0, t - 2) + 1):
            wit = None
            for win in (3, 6):
                wit = W.find_witness(w, ST, t, p, wrng, 200, window=win)
                if wit:
                    break
            if wit:
                out["witness_positions"] += 1
            else:
                out["undetermined_positions"] += 1
        # sanity: a witness at a position >= b.first+? would contradict soundness only if b certified there;
        # b certified at b["first"]; check that position b["first"] itself has no witness when b certified there
        wit_at = W.find_witness(w, ST, t, b["first"], wrng, 200, window=3) if b["first"] >= 4 and b["first"] < t - 2 + 1 else None
        if wit_at and b["first"] > a["first"]:
            out["witness_at_pruned_certified_position"] += 1
    for key in ("extra_C09", "extra_pruned", "support_C09", "support_pruned"):
        v = sorted(out[key])
        out[key] = {"median": v[len(v) // 2], "p90": v[int(0.9 * len(v))], "max": v[-1], "sum": sum(v)}
    out["examples_earlier"] = examples
    return out


def partial_soundness(n_worlds=400, n=10):
    import itertools
    rng = random.Random(5303)
    stats = {"checked": 0, "pruned_certified": 0, "C09_certified": 0, "unsound_pruned": 0, "pruned_only": 0}
    for _ in range(n_worlds):
        w = E.random_world(n, rng, p_y=0.1, p_side=0.2, p_null=0.2, smax=4)
        states, sides, scores = w
        unknown_obj = rng.sample(range(n), rng.choice([0, 1, 2]))
        unknown_edge = rng.sample(range(n - 1), rng.choice([0, 1]))
        known = set(range(n)) - set(unknown_obj)
        ek = set(range(n - 1)) - set(unknown_edge)
        case = G.make_case(*w, ST, known=known, edge_known=ek)
        for t in range(6, n):
            stats["checked"] += 1
            b = G.certify(case, t, prune=True)
            a = G.certify(case, t)
            stats["C09_certified"] += a["status"] == "Certified"
            if b["status"] != "Certified":
                continue
            stats["pruned_certified"] += 1
            stats["pruned_only"] += a["status"] != "Certified"
            # Ω(K): every completion of the unknown facts over realizable domains
            projs = set()
            obj_dom = [(s, d) for s in ("SHAPE_X", "SHAPE_Y") for d in (G.LEFT, G.RIGHT, G.UNK)]
            edge_dom = [None, 0, 1, 2, 3, 4, 5]
            for oc in itertools.product(obj_dom, repeat=len(unknown_obj)):
                for ec in itertools.product(edge_dom, repeat=len(unknown_edge)):
                    s2, d2, e2 = list(states), list(sides), dict(scores)
                    for o, (s_, d_) in zip(unknown_obj, oc):
                        s2[o], d2[o] = s_, d_
                    for e_, v in zip(unknown_edge, ec):
                        e2[e_] = v
                    u = G.unit_of(G.plan(G.make_case(s2, d2, e2, ST)), t)
                    projs.add((u["slots"], u["certain"], u["reason"]))
            if projs != {(b["unit"]["slots"], b["unit"]["certain"], b["unit"]["reason"])}:
                stats["unsound_pruned"] += 1
    return stats


def main():
    t0 = time.time()
    out = {"env": env(), "G4_compare": g4_compare(), "partial_soundness": partial_soundness()}
    out["seconds"] = round(time.time() - t0, 1)
    write_json(RAW / "gamma/q053.json", out)
    print({k: (v if not isinstance(v, dict) else {kk: vv for kk, vv in v.items() if not isinstance(vv, list)}) for k, v in out.items() if k != "env"})


if __name__ == "__main__":
    main()
