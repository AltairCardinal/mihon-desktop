"""Driver for the R10-revision joint-design studies (T06). Usage: python3 -B exp_joint.py [C01 C02 ...]
Writes raw/joint/<Cxx>.json per study (so partial reruns do not clobber others) and raw/joint/index.json."""
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import RAW, env, write_json

MODULES = {}


def register():
    import joint_a, joint_b
    for m in (joint_a, joint_b):
        for k in range(1, 31):
            f = getattr(m, f"c{k:02d}", None)
            if f:
                MODULES[f"C{k:02d}"] = f
    import importlib
    for name in ("joint_c", "joint_d"):
        try:
            m = importlib.import_module(name)
        except ImportError:
            continue
        for k in range(1, 31):
            f = getattr(m, f"c{k:02d}", None)
            if f:
                MODULES[f"C{k:02d}"] = f


def main():
    register()
    sel = sys.argv[1:] or sorted(MODULES)
    for cid in sel:
        t0 = time.time()
        try:
            out = MODULES[cid]()
            out["seconds"] = round(time.time() - t0, 1)
            out["env"] = env()
        except Exception as ex:   # recorded, never hidden
            import traceback
            out = {"id": cid, "error": repr(ex), "trace": traceback.format_exc()}
        write_json(RAW / f"joint/{cid}.json", out)
        print(cid, out.get("seconds"), "distinguished=", out.get("designs_distinguished"), "error=", out.get("error"), flush=True)
    idx = {}
    for p in sorted((RAW / "joint").glob("C*.json")):
        d = json.load(open(p, encoding="utf-8"))
        idx[d["id"]] = {"designs_distinguished": d.get("designs_distinguished"), "error": d.get("error"),
                        "oracle_failures": len(d.get("oracle_failures", [])), "seconds": d.get("seconds")}
    write_json(RAW / "joint/index.json", idx)


if __name__ == "__main__":
    main()
