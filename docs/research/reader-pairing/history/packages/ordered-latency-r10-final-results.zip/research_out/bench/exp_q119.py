"""Q119 (R10 revision): executable domain-gating experiment for a Γ-preserving alternative (enter / exit / failure / close).

Current path  : gamma.certify (C01-C11).
Candidate     : gamma.certify(prune=True) (Q053 route B'), applicable only in its closed domain (no manual starts /
                forced positions near the target, first >= 4); outside, the candidate itself declines (prunes nothing).
Fault         : a mutant candidate that returns the neighbouring unit when the target sits at a score tie (rare,
                in-domain) - used to test containment, never as a claim about any real implementation.
Routes:
  A_shadow    : current path authoritative; candidate computed in shadow and compared (mismatches logged, bounded log).
  B_gated     : candidate authoritative inside a provably closed domain, exact fallback outside; a circuit breaker
                trips on a detected mismatch (spot check rate r) and keeps the gate OFF for a cooldown.
  AB          : shadow until N agreeing queries, then gated enable with spot checks.
Stream events : queries, settings changes (domain exit/entry), content updates, context close (state must reset).
Output raw/gamma/q119.json
"""
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import evidence as E
import gamma as G
from common import RAW, env, write_json

ST0 = {"direction": "RTL", "automatic": True}


def in_domain(settings, t):
    near = set(range(max(0, t - 6), t + 4))
    return not (set(settings.get("manual", [])) & near) and not (set(settings.get("forced", [])) & near) and t >= 8


def candidate(case, t, faulty=False):
    c = G.certify(case, t, prune=True)
    if faulty and c["status"] == "Certified":
        sc = G.Case(case).edge(t, t + 1)
        if sc.get("status") == "Computed" and sc.get("score") is not None and sc["score"] % 7 == 0 and t + 1 < len(case["items"]):
            u = G.unit_of(G.plan(case), t + 1)        # wrong unit (the neighbour's) - injected fault
            c = dict(c, unit=u)
    return c


def stream(seed, n_events=400):
    rng = random.Random(seed)
    w = E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40)
    settings = dict(ST0)
    ev = []
    for k in range(n_events):
        r = rng.random()
        if r < 0.06:
            settings = dict(settings, manual=[] if settings.get("manual") else sorted(rng.sample(range(10, 50), 3)))
            ev.append(("settings", dict(settings)))
        elif r < 0.12:
            ev.append(("update", rng.randrange(60)))
        elif r < 0.14:
            ev.append(("close", None))
        else:
            ev.append(("query", rng.randrange(10, 56)))
    return w, ev


def run_route(route, seed, faulty, spot=0.1, shadow_n=20, cooldown=30):
    w, ev = stream(seed)
    states, sides, scores = list(w[0]), list(w[1]), dict(w[2])
    settings = dict(ST0)
    rng = random.Random(seed + 1)
    gate = "OFF"
    agree, breaker_until, k = 0, -1, 0
    log, log_max = [], 0
    out = {"queries": 0, "exposed_wrong": 0, "work_steps": 0, "enter": 0, "exit": 0, "breaker_trips": 0,
           "mismatches_seen": 0, "first_detect_query": None, "state_entries_max": 0, "state_after_close": 0,
           "served_by_candidate": 0}
    for kind, x in ev:
        k += 1
        if kind == "settings":
            settings = dict(settings, **x)
            continue
        if kind == "update":
            states[x] = "SHAPE_Y" if states[x] == "SHAPE_X" else "SHAPE_X"
            continue
        if kind == "close":
            gate, agree = "OFF", 0          # gate and shadow state belong to the closed context
            log.clear()                     # (the circuit breaker is NOT reset: a candidate fault is not context state)
            # structural check: nothing of the closed context survives (gate OFF, no agreement credit, empty log)
            out["state_after_close"] = max(out["state_after_close"], len(log) + (gate != "OFF") + agree)
            continue
        t = x
        out["queries"] += 1
        case = G.make_case(states, sides, scores, settings)
        truth = G.unit_of(G.plan(case), t)
        dom = in_domain(settings, t)
        use_candidate = False
        if route in ("B", "AB") and dom and k >= breaker_until and (route == "B" or agree >= shadow_n):
            if gate == "OFF":
                out["enter"] += 1
            gate = "ON"
            use_candidate = True
        elif gate == "ON":
            gate = "OFF"
            out["exit"] += 1
        if use_candidate:
            c = candidate(case, t, faulty)
            out["work_steps"] += c["steps"]
            out["served_by_candidate"] += 1
            if rng.random() < spot:                        # spot check against the current path
                ref = G.certify(case, t)
                out["work_steps"] += ref["steps"]
                if ref["unit"] != c["unit"]:
                    out["mismatches_seen"] += 1
                    out["first_detect_query"] = out["first_detect_query"] or out["queries"]
                    out["breaker_trips"] += 1
                    breaker_until, gate, agree = k + cooldown, "OFF", 0
                    out["exit"] += 1
                    c = ref                                # the detected query is served by the current path
            served = c["unit"]
        else:
            ref = G.certify(case, t)
            out["work_steps"] += ref["steps"]
            served = ref["unit"]
            if route in ("A", "AB") and dom:
                cs = candidate(case, t, faulty)
                out["work_steps"] += cs["steps"]
                if cs["unit"] != ref["unit"]:
                    out["mismatches_seen"] += 1
                    out["first_detect_query"] = out["first_detect_query"] or out["queries"]
                    agree = 0
                    log.append((t, "mismatch"))
                else:
                    agree += 1
                log = log[-16:]                            # bounded shadow log
                out["state_entries_max"] = max(out["state_entries_max"], len(log))
        out["exposed_wrong"] += served != truth
    return out


def main():
    t0 = time.time()
    res = {}
    for faulty in (False, True):
        for route in ("current_only", "A", "B", "AB"):
            agg, per_seed_first_detect = {}, []
            for seed in range(6):
                r = run_route(route if route != "current_only" else "none", 1190 + seed, faulty)
                per_seed_first_detect.append(r.pop("first_detect_query"))
                for kk, v in r.items():
                    if kk in ("state_entries_max", "state_after_close"):
                        agg[kk] = max(agg.get(kk, 0), v)        # maxima over seeds, not sums
                    else:
                        agg[kk] = agg.get(kk, 0) + v
            agg["first_detect_query_per_seed"] = per_seed_first_detect
            res[f"{'faulty' if faulty else 'correct'}_candidate|{route}"] = agg
    out = {"env": env(), "results": res, "seconds": round(time.time() - t0, 1),
           "notes": "Routes on identical streams (6 seeds x 400 events: queries, settings changes, content updates, closes)."}
    write_json(RAW / "gamma/q119.json", out)
    for k, v in res.items():
        print(k, v)


if __name__ == "__main__":
    main()
