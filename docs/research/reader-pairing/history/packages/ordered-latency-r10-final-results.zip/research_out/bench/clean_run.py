"""T08 driver: final clean offline reproduction in an INDEPENDENT directory.

Usage:  python3 -B research_out/bench/clean_run.py <destination_dir>
Copies the package (original files + research_out without raw/) to <destination_dir>/ordered-latency-r10, then runs,
step by step, the package tests and every line of research_out/run_all.sh with R9_REFERENCE pointing to a
non-existent path (the historical cross-check must report NOT_RUN, not fail). Records PASS / FAIL / SKIP / NOT_RUN per
step with durations, compares every raw JSON with the source tree (volatile fields ignored) and writes
<dest>/clean_run.json (copied by the caller to research_out/summary/clean_run.json).
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

SRC_PKG = Path(__file__).resolve().parents[2]
VOLATILE = {"env", "pid", "seconds", "rerun_env", "utc_start", "utc_end", "median_ns", "min_ns", "max_ns", "seconds_C09",
            "seconds_pruned", "C09_ns", "pruned_ns", "ratio", "ratio_range", "runs"}


def strip(o):
    if isinstance(o, dict):
        return {k: strip(v) for k, v in o.items() if k not in VOLATILE}
    if isinstance(o, list):
        return [strip(v) for v in o]
    return o


def main(dest):
    dest = Path(dest).resolve()
    pkg = dest / "ordered-latency-r10"
    if pkg.exists():
        shutil.rmtree(pkg)
    shutil.copytree(SRC_PKG, pkg, ignore=shutil.ignore_patterns("__pycache__", "raw"))
    env = dict(os.environ, R9_REFERENCE=str(dest / "no_such_reference.py"), PYTHONDONTWRITEBYTECODE="1")
    steps = [["python3", "-X", "utf8", "-B", "tests/test_lab.py"]]
    for line in (pkg / "research_out/run_all.sh").read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("$P "):
            args = line[3:].replace("> /dev/null", "").split()
            steps.append(["python3", "-B"] + args)
    results = []
    t_all = time.time()
    for cmd in steps:
        t0 = time.time()
        r = subprocess.run(cmd, cwd=pkg, env=env, capture_output=True, text=True)
        tail = (r.stdout + r.stderr)[-600:]
        status = "PASS" if r.returncode == 0 else "FAIL"
        if "gamma_xcheck.py" in " ".join(cmd):
            status = "NOT_RUN" if (pkg / "research_out/raw/gamma/xcheck_r9_status.json").exists() else status
        results.append({"cmd": " ".join(cmd[2:]), "status": status, "returncode": r.returncode,
                        "seconds": round(time.time() - t0, 1), "tail": tail})
        print(results[-1]["status"], results[-1]["seconds"], results[-1]["cmd"], flush=True)
    # compare raw JSON with the source tree
    a, b = SRC_PKG / "research_out/raw", pkg / "research_out/raw"
    same, diff, only_src, only_clean = [], [], [], []
    for p in sorted(a.rglob("*.json")):
        rel = p.relative_to(a).as_posix()
        q = b / rel
        if not q.exists():
            only_src.append(rel)
            continue
        (same if strip(json.load(open(p, encoding="utf-8"))) == strip(json.load(open(q, encoding="utf-8"))) else diff).append(rel)
    for q in sorted(b.rglob("*.json")):
        rel = q.relative_to(b).as_posix()
        if not (a / rel).exists():
            only_clean.append(rel)
    out = {"destination": str(pkg), "python": sys.version.split()[0], "total_seconds": round(time.time() - t_all, 1),
           "R9_REFERENCE": env["R9_REFERENCE"],
           "counts": {s: sum(1 for r in results if r["status"] == s) for s in ("PASS", "FAIL", "SKIP", "NOT_RUN")},
           "steps": results,
           "raw_compare": {"identical_ignoring_volatile": same, "different": diff, "only_in_source": only_src, "only_in_clean": only_clean}}
    (dest / "clean_run.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(out["counts"]), "different:", diff, "only_in_source:", only_src, "only_in_clean:", only_clean)


if __name__ == "__main__":
    main(sys.argv[1])
