"""Joint-design studies C11, C13-C20 (R10 revision, T06). See joint_core.py for the protocol."""
import copy
import itertools
import random
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cachemodel as CM
import certify_plus as CP
import evidence as E
import gamma as G
import lifecycle as L
import sched as S
import summarytree as STR
from joint_core import study

ST = {"direction": "RTL", "automatic": True}
SVC = {"ORIGINAL_ANALYSIS": 10, "EDGE_SAMPLES": 3, "DIMENSIONS": 1}


def _key(nd):
    return (nd["kind"], nd["object"], nd.get("second"))


# ================================================================================================ C11
def acquire(w, t, mode, gallop=False, short_first=False, lookahead=False, workers=4):
    """mode 'rounds': barrier rounds (all needs of a round in parallel, LPT on `workers` lanes);
    short_first (I's B): inside a round issue short actions first and re-certify before issuing the long ones;
    gallop (I's A): add a doubling speculative backward extension to every round;
    mode 'event' (II's A): no barrier, re-certify at every completion, drop queued needs that are no longer needed;
    lookahead (II's B): an idle worker may take ONE speculative analysis of first-1 (bounded reserve: never when
    needs are queued). Returns (completion time, facts acquired, speculative facts)."""
    K = E.Knowledge(w, ST)
    acquired, spec = 0, 0
    if mode == "rounds":
        now, step = 0, 1
        while True:
            c = G.certify(K.case(), t)
            if c["status"] == "Certified":
                return now, acquired, spec
            needs = list(c["needs"])
            phases = [needs]
            if short_first:
                short = [n for n in needs if SVC[n["kind"]] <= 3]
                long_ = [n for n in needs if SVC[n["kind"]] > 3]
                phases = [short, long_] if short and long_ else [needs]
            extra = []
            if gallop:
                lo = min([n["object"] for n in needs] + [c["first"]])
                extra = [{"kind": "ORIGINAL_ANALYSIS", "object": o} for o in range(lo - 1, max(-1, lo - 1 - step), -1)]
                step = min(step * 2, 32)
            for pi, ph in enumerate(phases):
                if pi == 1:   # re-certify after the short phase; drop long needs no longer requested
                    c2 = G.certify(K.case(), t)
                    if c2["status"] == "Certified":
                        return now, acquired, spec
                    still = {_key(n) for n in c2["needs"]}
                    ph = [n for n in ph if _key(n) in still]
                jobs = [SVC[n["kind"]] for n in ph] + ([10] * len(extra) if pi == len(phases) - 1 else [])
                lanes = [0] * workers
                for dur in sorted(jobs, reverse=True):
                    i = lanes.index(min(lanes))
                    lanes[i] += dur
                now += max(lanes) if jobs else 0
                for n in ph:
                    K.apply(n, True)
                    acquired += 1
                if pi == len(phases) - 1:
                    for x in extra:
                        if x["object"] not in K.an:
                            K.an.add(x["object"]); K.dim.add(x["object"])
                            if x["object"] + 1 < K.n:
                                K.edge.add(x["object"])
                            if x["object"] - 1 >= 0:
                                K.edge.add(x["object"] - 1)
                            acquired += 1
                            spec += 1
                    extra = []
    # event-driven
    now, queue, running = 0, [], {}
    seen = set()

    def refresh():
        c = G.certify(K.case(), t)
        if c["status"] == "Certified":
            return c, True
        wanted = [n for n in c["needs"]]
        keys = {_key(n) for n in wanted}
        for n in queue:
            if _key(n) not in keys:
                seen.discard(_key(n))                               # may be requested again later
        queue[:] = [n for n in queue if _key(n) in keys]           # drop stale queued needs
        for n in wanted:
            k = _key(n)
            if k not in seen:
                seen.add(k)
                queue.append(n)
        return c, False
    c, done = refresh()
    if done:
        return 0, 0, 0
    while True:
        while len(running) < workers and queue:
            n = queue.pop(0)
            running[_key(n)] = (now + SVC[n["kind"]], n, False)
        if lookahead and len(running) < workers and not queue:
            o = c["first"] - 1
            k = ("ORIGINAL_ANALYSIS", o, None)
            if o >= 0 and o not in K.an and k not in seen and not any(v[2] for v in running.values()):
                seen.add(k)
                running[k] = (now + 10, {"kind": "ORIGINAL_ANALYSIS", "object": o}, True)
        if not running:
            raise AssertionError("stalled")
        k, (end, n, is_spec) = min(running.items(), key=lambda kv: kv[1][0])
        now = end
        del running[k]
        K.apply(n, True)
        acquired += 1
        spec += is_spec
        c, done = refresh()
        if done:
            return now, acquired, spec


def c11():
    def worlds(kind, k=40, seed=1111):
        rng = random.Random(seed)
        if kind == "long_chain":
            return [(E.random_world(60, rng, p_y=0.0, p_side=0.0, p_null=0.0, smax=40), rng.randrange(25, 55)) for _ in range(k)]
        if kind == "sided":
            return [(E.random_world(40, rng, p_y=0.05, p_side=0.3, p_null=0.2, smax=10), rng.randrange(10, 35)) for _ in range(k)]
        return [(E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40), rng.randrange(25, 55)) for _ in range(k)]
    W = {k: worlds(k) for k in ("long_chain", "sided", "sparse")}

    def run(inp, d, a, b):
        res = []
        for w, t in W[inp]:
            if d == "I":
                res.append(acquire(w, t, "rounds", gallop=a, short_first=b))
            elif d == "II":
                res.append(acquire(w, t, "event" if a else "rounds", lookahead=b and a, short_first=False,
                                   gallop=False) if a or not b else acquire_lookahead_rounds(w, t))
            else:
                res.append(acquire(w, t, "rounds"))
        times = sorted(r[0] for r in res)
        return {"m": statistics.median(times), "cost": {"max_time": times[-1], "facts": sum(r[1] for r in res),
                                                        "speculative_facts": sum(r[2] for r in res)}, "ok": True}
    return study("C11", "median certification completion (model units; analysis 10, edge 3, header 1; 4 workers)", "lower",
                 {"long_chain": "long_chain", "sided": "sided", "sparse": "sparse"}, run,
                 {"I": "barrier rounds + galloping backward speculation + short-actions-first with re-certification",
                  "II": "event-driven re-certification at every completion (no barrier) + one bounded speculative lookahead"},
                 "I keeps rounds and speculates aggressively; II removes the barrier and speculates at most one step")


def acquire_lookahead_rounds(w, t):
    """II's B without II's A: barrier rounds, plus one speculative analysis of first-1 per round when a lane is idle."""
    K = E.Knowledge(w, ST)
    now, acquired, spec = 0, 0, 0
    while True:
        c = G.certify(K.case(), t)
        if c["status"] == "Certified":
            return now, acquired, spec
        needs = list(c["needs"])
        jobs = [SVC[n["kind"]] for n in needs]
        o = c["first"] - 1
        add = len(jobs) < 4 and o >= 0 and o not in K.an
        if add:
            jobs.append(10)
        lanes = [0] * 4
        for dur in sorted(jobs, reverse=True):
            i = lanes.index(min(lanes))
            lanes[i] += dur
        now += max(lanes)
        for n in needs:
            K.apply(n, True)
            acquired += 1
        if add:
            K.apply({"kind": "ORIGINAL_ANALYSIS", "object": o}, True)
            acquired += 1
            spec += 1


# ================================================================================================ C13
def c13():
    """Certificate vs member resources vs frames; optional content replacement of member b after the certificate.
    A = resources may be prepared in parallel with the proof (else only after the certificate).
    B = commit discipline. I: plan kept unexposable, ONE authorisation when plan and all resources are ready
        (a replacement re-plans). II: exact layout snapshot committed at certification, member resources bound
        progressively, display only at a final complete-ack barrier (a replacement invalidates the snapshot).
    0 = expose each member as soon as it and the certificate are ready (partial exposure)."""
    base = ["cert", "res_a", "res_b", "frame1", "frame2", "frame3"]
    before = {("frame1", "frame2"), ("frame2", "frame3")}
    orders_plain = L.linear_extensions(base, before)
    orders_repl = [o for o in L.linear_extensions(base + ["replace_b"], before | {("cert", "replace_b")})][:600]
    orders_one_side = L.linear_extensions(["cert", "res_a", "frame1", "frame2", "frame3"], before)

    def run_order(o, d, a, b):
        have, exposed, snapshot, held = set(), set(), None, 0
        pending, frames_since_cert = set(), None
        wrong, ack = 0, None
        for e in o:
            if e == "cert":
                have.add("cert")
                frames_since_cert = 0
                if d == "II" and b:
                    snapshot = ("a", "b")
            elif e.startswith("res_"):
                if not a and "cert" not in have:
                    pending.add(e)       # without parallel preparation: started only after the certificate
                else:
                    have.add(e)
            elif e == "replace_b":
                have.discard("res_b")    # old content is not current any more; a new resource is prepared
                pending.add("res_b")
                if d == "II" and b and snapshot is not None:
                    held += 1            # snapshot rebuilt
            elif e.startswith("frame"):
                if frames_since_cert is not None:
                    frames_since_cert += 1
                    if frames_since_cert >= 2 and pending:   # deferred preparation completes one frame later
                        have |= pending
                        pending = set()
                full = {"cert", "res_a", "res_b"} <= have
                if not b:
                    if "cert" in have:
                        for m in ("a", "b"):
                            if f"res_{m}" in have:
                                exposed.add(m)
                        if exposed and not full:
                            wrong = 1
                        if full and ack is None:
                            ack = int(e[-1])
                elif full and ack is None:
                    ack = int(e[-1])
                if d == "II" and b and snapshot is not None and ack is None:
                    held += 1
        return wrong, ack, held

    def run(inp, d, a, b):
        orders = {"plain": orders_plain, "replacement_after_cert": orders_repl, "only_one_side_available": orders_one_side}[inp]
        w = acks = held = 0
        n_ack = 0
        for o in orders:
            wr, ack, h = run_order(o, d, a, b)
            w += wr
            held += h
            if ack is not None:
                acks += ack
                n_ack += 1
        return {"m": w, "cost": {"orders": len(orders), "mean_complete_ack_frame": round(acks / n_ack, 3) if n_ack else None,
                                 "acked_orders": n_ack, "snapshot_held_frame_steps": held}, "ok": True}
    return study("C13", "orderings exposing a partial unit (no complete-unit ack in that frame)", "lower",
                 {"plain": "plain", "replacement_after_cert": "replacement_after_cert", "only_one_side_available": "only_one_side_available"},
                 run,
                 {"I": "unexposable plan, single authorisation when plan + all resources are ready",
                  "II": "layout snapshot at certification, progressive binding, complete-ack barrier"},
                 "I materialises the layout at authorisation; II pins it at certification and pays snapshot residency "
                 "and rebuilds on replacement")


# ================================================================================================ C14
def c14():
    """Unit U1=(a,b) exposed (a drawn) at frame f; then a background fact splits/merges the layout (U1'=(a),(b,c));
    then the user navigates 'next' and/or a gesture is cancelled; then b is drawn; finally the old frame retires.
    Checks: exposed content not moved/blanked (contract), navigation lands on the item after the exposed unit,
    old resources released after the old frame retires (bounded residency)."""
    events = ["new_layout", "draw_b", "navigate_next", "retire_old_frame"]
    orders = list(itertools.permutations(events))
    orders = [o for o in orders if o.index("retire_old_frame") > o.index("draw_b") or o.index("retire_old_frame") > o.index("navigate_next")]
    variants = {"split": {"old": [("a", "b"), ("c", "d")], "new": [("a",), ("b", "c"), ("d",)]},
                "merge": {"old": [("a",), ("b",), ("c", "d")], "new": [("a", "b"), ("c", "d")]},
                "long_suffix_shift": {"old": [("a", "b"), ("c", "d"), ("e", "f")], "new": [("a",), ("b", "c"), ("d", "e"), ("f",)]}}

    def run_order(o, var, d, a, b):
        old, new = var["old"], var["new"]
        exposed = old[0]
        layout = old
        lease = True
        wrong_expo = wrong_nav = 0
        resident, peak = 1, 1
        for e in o:
            if e == "new_layout":
                if a:
                    if d == "II":
                        resident += 1      # multi-version snapshot keeps the old layout
                    # I: frame lease keeps only the exposed ticket
                else:
                    lease = False          # naive: new certificate revokes the exposed ticket
                layout = new
            elif e == "draw_b":
                if not lease and layout is new and tuple(exposed) not in [tuple(u) for u in new]:
                    wrong_expo = 1         # the drawn member moved/blanked
            elif e == "navigate_next":
                last = exposed[-1]
                if b:
                    if d == "I":           # item identity anchor: next unit after the last exposed ITEM in the current layout
                        items = [x for u in layout for x in u]
                        nxt_item = items[items.index(last) + 1] if items.index(last) + 1 < len(items) else None
                        target = next((u for u in layout if nxt_item in u), None)
                    else:                  # versioned unit bridge: map the old exposed unit's successor via the bridge
                        items = [x for u in old for x in u]
                        nxt_item = items[items.index(last) + 1]
                        target = next((u for u in layout if nxt_item in u), None)
                else:                      # unit index: next index in the CURRENT layout
                    idx = 1
                    target = layout[idx] if idx < len(layout) else None
                truth_item = [x for u in old for x in u][[x for u in old for x in u].index(last) + 1]
                truth = next(u for u in layout if truth_item in u)
                if target != truth:
                    wrong_nav = 1
            elif e == "retire_old_frame":
                if d == "II" and a and resident > 1:
                    resident -= 1
            peak = max(peak, resident)
        return wrong_expo, wrong_nav, peak

    def run(inp, d, a, b):
        var = variants[inp]
        we = wn = 0
        peak = 0
        for o in orders:
            x, y, p = run_order(o, var, d, a, b)
            we += x
            wn += y
            peak = max(peak, p)
        return {"m": we + wn, "cost": {"exposure_moved": we, "wrong_navigation": wn, "layout_versions_resident_max": peak,
                                       "orders": len(orders)}, "ok": True}
    return study("C14", "wrong orderings (exposure moved/blanked + wrong navigation)", "lower",
                 {k: k for k in variants}, run,
                 {"I": "frame lease on the exposed ticket + navigation by source-item identity in the current layout",
                  "II": "multi-version layout snapshots + versioned unit bridge from the old layout"},
                 "I keeps only the exposed capability; II keeps whole old layout versions and maps through them")


# ================================================================================================ C15
def c15():
    """One worker; intents arrive every `gap` < service 10. A = intent handling, B = old-job reclaim.
    I : A_I = latest-valid queue (queued stale intents dropped); B_I = cooperative exit of a stale running job at the
        next segment boundary (5 segments).
    II: A_II = lazy intent log (work for the newest intent starts after a quiet period q=3 without a newer intent);
        B_II = rebinding: a running job whose object is targeted again by a newer intent is re-bound to it (no restart)."""
    def run(inp, d, a, b):
        targets, gap = inp
        n = len(targets)
        lazy = d == "II" and a
        tasks = [S.Task(f"i{k}", "required", 10, (10 ** 9 if lazy else gap * k), obj=targets[k]) for k in range(n)]
        for t in tasks:
            t.segments = 5
            t.consumers.add("ui")
        sim = S.Sim(tasks, physical=1, segment_exit=(d == "I" and b))
        acts, bound = [], {}
        final = f"i{n - 1}"

        def try_bind(s, t):
            run_ = [x for x in s.tasks.values() if x.state == "running" and x.obj == t.obj and x.id != t.id and not x.cancelled]
            if run_:
                if t.state in ("pending", "queued"):
                    s.cancel(t.id)
                bound[t.id] = run_[0].id
                return True
            return False
        if lazy:
            def decide(s, k):
                latest = max(j for j in range(n) if gap * j <= s.now)
                if latest != k:
                    s.cancel(f"i{k}")           # superseded during the quiet period: never started
                    return
                for j in range(k):
                    if s.tasks[f"i{j}"].state == "pending":
                        s.cancel(f"i{j}")
                t = s.tasks[f"i{k}"]
                if b and try_bind(s, t):
                    return
                t.state, t.release = "queued", s.now
            for k in range(n):
                acts.append((gap * k + 3, lambda s, k=k: decide(s, k)))
        else:
            for k in range(1, n):
                def arrive(s, k=k):
                    if a:                        # I's A: latest-valid queue
                        for j in range(k):
                            t = s.tasks[f"i{j}"]
                            if t.state in ("pending", "queued"):
                                s.cancel(t.id)
                            elif b and d == "I" and t.state == "running":
                                s.cancel(t.id)   # I's B: cooperative exit at the next segment boundary
                    if b and d == "II":
                        try_bind(s, s.tasks[f"i{k}"])
                acts.append((gap * k, arrive))
        sim.run(acts)
        end = sim.tasks[bound[final]].end if final in bound else sim.tasks[final].end
        m = sim.metrics()
        return {"m": end - gap * (n - 1), "cost": {"physical_work": m["physical_work"], "wasted_work": m["wasted_work"]},
                "ok": not sim.violations}
    inputs = {"fast_stream_6": (["o0", "o1", "o2", "o3", "o4", "o5"], 3), "reverse_duplicates": (["a", "b", "a", "b", "a"], 3),
              "single_intent": (["o0"], 3), "slow_stream": (["o0", "o1", "o2"], 12)}
    return study("C15", "latency of the final intent (model units)", "lower", inputs, run,
                 {"I": "latest-valid queue + cooperative exit of stale running work",
                  "II": "lazy intent log with quiet period + rebinding of running work to a newer intent on the same object"},
                 "I acts on every intent immediately and reclaims; II defers decisions and reuses running work")


# ================================================================================================ C16
def c16():
    """Reopen scenarios over one item: data result D(content) and authority (certificate) per context.
    A = cross-context data reuse; B = authority rebuilt for the current context.
    I : A_I = content-addressed data cache (key = content digest + settings/algorithm version);
        B_I = full re-certification in the new context, new capability.
    II: A_II = version-keyed layered cache (key = path + content_version) whose hits verify the actual read set
        against the current content; B_II = proof-carrying result: verify the carried support (C12) and re-issue."""
    scen = {"same_content_same_path": dict(path_same=True, content_same=True, version_bumped=False),
            "replaced_same_path": dict(path_same=True, content_same=False, version_bumped=True),
            "same_content_moved": dict(path_same=False, content_same=True, version_bumped=False),
            "same_value_new_version": dict(path_same=True, content_same=True, version_bumped=True),
            "late_old_ack": dict(path_same=True, content_same=True, version_bumped=False, late_ack=True)}
    COLD, VERIFY, CERT = 20, 3, 6

    def run(inp, d, a, b):
        s = scen[inp]
        unsafe = work = 0
        data_hit = False
        if a:
            if d == "I":
                data_hit = s["content_same"]                       # digest equal iff content equal
            else:
                data_hit = s["path_same"] and not s["version_bumped"]
                if data_hit:
                    work += VERIFY                                  # verify the read set against current content
        else:
            data_hit = False
        work += 0 if data_hit else COLD
        if b:
            work += CERT if d in ("I", None) else VERIFY
            authority_reused = False
        else:
            authority_reused = data_hit                             # reuse the old certificate along with the data
        if authority_reused and (s.get("late_ack") or s["version_bumped"] or not s["path_same"]):
            unsafe += 1                                             # old authority accepted in a new context/content
        if data_hit and not s["content_same"]:
            unsafe += 1
        return {"m": unsafe, "cost": {"work": work, "data_hit": data_hit}, "ok": True}
    return study("C16", "unsafe reuses (stale data or old authority accepted)", "lower", {k: k for k in scen}, run,
                 {"I": "content-addressed data + full re-certification in the new context",
                  "II": "version-keyed layered cache with read-set verification + proof-carrying re-issue"},
                 "I keys by content and recomputes authority; II keys by version, verifies supports, and re-issues by "
                 "checking a carried proof")


# ================================================================================================ C17
def c17():
    """Shared 12 MiB buffer B used by job J for consumers C1 and C2. Events (all orders): close_C1, exit_J,
    close_C2, reopen_C1 (C1 asks for B again). Ledger: true resident bytes vs accounted bytes; quota per consumer.
    A = local close / hand-over protocol; B = shared memory accounting.
    I : A_I = consumer lease closed but the owner releases only at the job's real exit;
        B_I = single owner account (the job owns B, consumers hold leases: B counted once).
    II: A_II = explicit capability transfer at close (lease moves to the remaining consumer);
        B_II = layered ledger: per-consumer views + explicit dedupe of the shared resident object."""
    ev = ["close_C1", "exit_J", "close_C2", "reopen_C1"]
    orders = list(itertools.permutations(ev))

    def run_order(o, d, a, b):
        resident = 12
        running = True
        holders = {"C1", "C2"}
        accounted_max = 0
        bad = 0
        close_wait = 0
        for e in o:
            if e == "close_C1" and "C1" in holders:
                if a and d == "II" and "C2" in holders:
                    holders.discard("C1")                         # transfer to C2
                elif a and d == "I":
                    holders.discard("C1")                         # lease dropped; owner keeps B until real exit
                    close_wait += running
                else:
                    holders.discard("C1")
                    if running and not holders:
                        resident = 12                             # still physically resident
            elif e == "close_C2" and "C2" in holders:
                holders.discard("C2")
                if a and d == "I":
                    close_wait += running
            elif e == "reopen_C1":
                holders.add("C1")
            elif e == "exit_J":
                running = False
            # accounting
            if b:
                accounted = 12 if (holders or running) else 0     # counted once (owner / dedupe)
            else:
                accounted = 12 * len(holders)                     # naive sum: double counts shared B
            true = 12 if (holders or running) else 0
            if accounted != true:
                bad = 1
            if not a and running and not holders and accounted == 0:
                bad = 1                                           # hidden cost: running job, no live owner, unaccounted
            accounted_max = max(accounted_max, accounted)
        return bad, close_wait, accounted_max

    def run(inp, d, a, b):
        tot = cw = 0
        mx = 0
        for o in orders:
            x, y, z = run_order(o, d, a, b)
            tot += x
            cw += y
            mx = max(mx, z)
        return {"m": tot, "cost": {"orders": len(orders), "close_waits": cw, "accounted_peak_MiB": mx}, "ok": True}
    return study("C17", "orderings with a ledger mismatch (double count / hidden cost)", "lower", {"all_orders": None}, run,
                 {"I": "unique owner account; consumer leases released at the job's real exit",
                  "II": "layered ledger with explicit dedupe; capability transfer at close"},
                 "I makes the job the owner and waits at close; II keeps per-consumer views and moves capabilities")


# ================================================================================================ C18
def c18():
    """Queries over one 176-object world. A = an extra index; B = adaptive enabling/demotion.
    I : A_I = summary tree; B_I = build only at the second demand for the same region and drop it after an update storm.
    II: A_II = sparse checkpoints (every 16); B_II = short lease with a reuse threshold (build when >= 3 queries are
        expected within the lease, revoke on update/close)."""
    rng = random.Random(18)
    w = E.random_world(176, rng)

    def flip(case, pos):
        st = [it["analysis"]["fact"]["state"] for it in case["items"]]
        st[pos] = "SHAPE_Y" if st[pos] == "SHAPE_X" else "SHAPE_X"
        return G.make_case(st, w[1], w[2], ST)
    pats = {"M1": [("q", 100)], "revisit10": [("q", 100)] * 10, "scan20": [("q", t) for t in range(40, 60)],
            "frequent_replacement": [x for t in range(40, 60, 2) for x in (("q", t), ("u", t - 5))]}

    def run(inp, d, a, b):
        case = G.make_case(*w, ST)
        steps = 0
        idx = None
        uses = 0
        updates_since = 0
        expected = len([x for x in pats[inp] if x[0] == "q"])
        for op, t in pats[inp]:
            if op == "u":
                case = flip(case, t)
                updates_since += 1
                if idx is not None:
                    if d == "II" and b:
                        idx = None                                  # lease revoked on update
                    elif d == "I" and b and updates_since >= 2:
                        idx = None                                  # demote after an update storm
                        uses = 0                                    # promotion needs fresh reuse evidence
                    else:
                        if isinstance(idx, STR.SummaryTree):
                            idx.ops = {"leaf_steps": 0, "compositions": 0}
                            idx.update(case, t)
                            steps += idx.ops["leaf_steps"] + idx.ops["compositions"]
                        else:
                            idx.update(case, t)
                continue
            uses += 1
            want = a and (not b or (d == "I" and uses >= 2) or (d == "II" and expected >= 3))
            if want and idx is None:
                if d == "I":
                    idx = STR.SummaryTree(case, 8)
                    steps += idx.ops["leaf_steps"] + idx.ops["compositions"]
                else:
                    idx = STR.Checkpoints(case, 16)
                updates_since = 0
            if idx is not None:
                if isinstance(idx, STR.SummaryTree):
                    idx.ops = {"leaf_steps": 0, "compositions": 0}
                    u = idx.unit(t)
                    steps += idx.ops["leaf_steps"] + idx.ops["compositions"]
                else:
                    s0 = idx.ops["steps"]
                    u = idx.unit(t)
                    steps += idx.ops["steps"] - s0
            else:
                c = G.certify(case, t)
                u = c["unit"]
                steps += c["steps"]
            assert u == G.unit_of(G.plan(case), t)
        return {"m": steps, "cost": {}, "ok": True}
    return study("C18", "total scan steps (index build + maintenance + queries)", "lower", {k: k for k in pats}, run,
                 {"I": "summary tree promoted at the second demand, demoted after an update storm",
                  "II": "checkpoint lease with reuse threshold, revoked on update"},
                 "I builds a full relation index lazily; II builds cheap prefix checkpoints on predicted reuse")


# ================================================================================================ C19
def c19():
    """Prefetch OFF (C19 explicitly). A = stronger (branch) certificate; B = when it may run.
    I : A_I = strong proof tried before acquisitions each round; B_I = only when the round's needs include a fact that
        requires a NEW materialisation (trigger gate).
    II: A_II = strong proof raced with the round's acquisitions (acquisitions are issued anyway; a win only skips
        later rounds); B_II = zero-tax guard: only when a lane is idle in that round (fewer needs than lanes)."""
    rng = random.Random(19)
    ws = [E.random_world(16, rng) for _ in range(20)]

    def hist(w, kind):
        s = CM.unit_starts(w, ST)
        return s if kind == "forward" else s[: len(s) // 2] + [s[-1], s[1]]

    def nav_run(w, h, d, a, b):
        nav = CM.Nav(w, ST, prefetch=False)
        proof_calls = adopted = 0
        latency = 0

        def certify(t):
            nonlocal proof_calls, adopted, latency
            while True:
                case = nav.K.case()
                c = G.certify(case, t)
                if c["status"] == "Certified":
                    return c["unit"]
                needs = c["needs"]
                new_mat = any(nd["kind"] != "DIMENSIONS" and not nav.mat.has(nd["object"]) for nd in needs)
                allow = a and (not b or (d == "I" and new_mat) or (d == "II" and len(needs) < 4))
                if allow and d == "I":
                    proof_calls += 1
                    bc = CP.branch_certify(case, t)
                    latency += 1
                    if bc["status"] == "Certified":
                        adopted += 1
                        return bc["unit"]
                bc_win = None
                if allow and d == "II":
                    proof_calls += 1
                    bc_win = CP.branch_certify(case, t)
                nav.rounds += 1
                latency += 10
                for nd in needs:
                    k, o = nd["kind"], nd["object"]
                    if k == "DIMENSIONS":
                        nav.K.dim.add(o)
                    elif k == "ORIGINAL_ANALYSIS":
                        nav.materialise(o); nav.K.an.add(o); nav.K.dim.add(o)
                    else:
                        nav.samples(o); nav.samples(nd["second"]); nav.K.edge.add(o)
                if bc_win is not None and bc_win["status"] == "Certified":
                    adopted += 1
                    return bc_win["unit"]
        prev = None
        for t in h:
            unit = certify(t)
            assert unit["slots"] == G.unit_of(nav.plan, t)["slots"]
            for o, _ in unit["slots"]:
                nav.materialise(o)
            prev = t
        return nav.transforms, proof_calls, adopted, latency

    def run(inp, d, a, b):
        tr = pc = ad = lat = 0
        for w in ws:
            x = nav_run(w, hist(w, inp), d, a, b)
            tr += x[0]; pc += x[1]; ad += x[2]; lat += x[3]
        return {"m": tr, "cost": {"proof_calls": pc, "adopted": ad, "latency_units": lat}, "ok": True}
    return study("C19", "materialisations over 20 worlds (prefetch OFF)", "lower", {"forward": "forward", "far_jumps": "far_jumps"}, run,
                 {"I": "strong proof before acquisitions, gated by a new-materialisation trigger",
                  "II": "strong proof raced with acquisitions, zero-tax guard (idle lane only)"},
                 "I spends proof time on the critical path to save materialisations; II never delays acquisitions "
                 "and saves only later rounds")


# ================================================================================================ C20
def c20():
    """A = local fixed window (truncate at t-3). B = provable reset / cross-boundary summary.
    I : A_I = fixed window; B_I = Γ's own reset certificate (C08/C09: extend left until entries merge).
        AB_I = truncate only where the certificate proves the merge, else extend left.
    II: A_II = fixed window; B_II = exact transfer summary over the whole prefix (summary tree state at the window).
        AB_II = scan the window starting from the summary state at its left boundary."""
    def worlds(kind, k=120, seed=2020):
        rng = random.Random(seed)
        if kind == "no_reset_long_chain":
            return [E.random_world(60, rng, p_y=0.0, p_side=0.0, p_null=0.0, smax=40) for _ in range(k)], rng
        if kind == "frequent_true_reset":
            return [E.random_world(60, rng, p_y=0.25, p_side=0.1, p_null=0.2, smax=40) for _ in range(k)], rng
        return [E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40) for _ in range(k)], rng

    def run(inp, d, a, b):
        ws, rng = worlds(inp)
        wrong = reads = maint = 0
        for w in ws:
            case = G.make_case(*w, ST)
            t = rng.randrange(25, 55)
            truth = G.unit_of(G.plan(case), t)
            if a and not b:
                u = E.truncated_window(w, ST, t, 3)
                reads += 6
            elif b and not a:
                if d == "I":
                    c = G.certify(case, t)
                    u = c["unit"]
                    reads += len(c["dependent_objects"])
                else:
                    tr = STR.SummaryTree(case, 8)
                    maint += tr.ops["leaf_steps"] + tr.ops["compositions"]
                    tr.ops = {"leaf_steps": 0, "compositions": 0}
                    u = tr.unit(t)
                    reads += 60
            elif a and b:
                if d == "I":
                    c = G.certify(case, t)
                    u = c["unit"]
                    reads += len(c["dependent_objects"])
                else:
                    tr = STR.SummaryTree(case, 8)
                    maint += tr.ops["leaf_steps"] + tr.ops["compositions"]
                    tr.ops = {"leaf_steps": 0, "compositions": 0}
                    u = tr.unit(t)
                    reads += (t % 8) + 6
            else:
                u = truth
                reads += 60          # full rescan from the origin
            wrong += u != truth
        return {"m": wrong, "cost": {"reads": reads, "summary_maintenance_steps": maint}, "ok": True}
    return study("C20", "wrong target units (of 120)", "lower",
                 {"no_reset_long_chain": "no_reset_long_chain", "sparse_sides": "sparse", "frequent_true_reset": "frequent_true_reset"},
                 run,
                 {"I": "truncate only where Γ's reset certificate proves the merge; otherwise extend left",
                  "II": "exact transfer summary across the prefix; the target keeps the full boundary state"},
                 "I reads locally and extends on demand; II pays prefix summarisation (maintenance) for a constant window")
