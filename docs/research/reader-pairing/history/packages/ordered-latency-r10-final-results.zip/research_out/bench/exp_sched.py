"""F03/F04/F05/F07/F16(Q092)/F19 experiments on the synthetic resource model (lab/sched.py).

All durations are hypothesis units (not ns). Every comparison runs both mechanisms on identical inputs.
Output raw/sched/sched.json
"""
import itertools
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import sched as S
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import PKG, RAW, env, write_json
from causal import bounds


def T(*a, **k):
    return S.Task(*a, **k)


# ---------------------------------------------------------------- S1 Q013/Q017 order is not dependency
def s1_order_vs_dependency():
    # World D: true dependency a->b on 2 workers. World R: no dependency, 1 worker (resource serialisation).
    wd = S.Sim([T("a", "required", 5), T("b", "required", 3, deps=("a",))], physical=2, trace=True).run()
    wr = S.Sim([T("a", "required", 5), T("b", "required", 3)], physical=1, trace=True).run()
    trace_d = [(t.id, t.start, t.end) for t in wd.tasks.values()]
    trace_r = [(t.id, t.start, t.end) for t in wr.tasks.values()]
    # intervention: add one worker
    cd = S.Sim([T("a", "required", 5), T("b", "required", 3, deps=("a",))], physical=3).run()
    cr = S.Sim([T("a", "required", 5), T("b", "required", 3)], physical=2).run()
    # real data: maximal observed concurrency of transform calls in N0 (lower bound on parallel lanes)
    d = json.load(open(PKG / "data/negative_route.json", encoding="utf-8"))
    conc = {}
    for arm in d["arms"]:
        st = {(x["stage"], x["object"], x["purpose"]): x["at_ns"] for x in arm["transform_starts"]}
        iv = [(st[(c["stage"], c["object"], c["purpose"])], c["at_ns"]) for c in arm["transform_completions"]]
        pts = sorted([(a, 1) for a, b in iv] + [(b, -1) for a, b in iv], key=lambda x: (x[0], x[1]))
        cur = mx = 0
        for _, dlt in pts:
            cur += dlt
            mx = max(mx, cur)
        conc[arm["arm"]] = mx
    return {"identical_observed_trace": trace_d == trace_r, "trace": trace_d,
            "after_adding_worker": {"D_b_end": cd.tasks["b"].end, "R_b_end": cr.tasks["b"].end},
            "N0_max_concurrent_transforms": conc,
            "conclusion": "start/end order alone cannot separate a data dependency from a resource serialisation; "
                          "they react differently to an added worker. N0 shows >= the listed concurrency (a lower bound on lanes only)."}


# ---------------------------------------------------------------- S2 Q014/Q019/Q020 Graham-type anomaly
def s2_anomaly(trials=20000, seed=3):
    rng = random.Random(seed)
    for k in range(trials):
        n = rng.randint(4, 6)
        svc = [rng.randint(1, 9) for _ in range(n)]
        deps = {i: tuple(j for j in range(i) if rng.random() < 0.3) for i in range(n)}
        prio = list(range(n))
        rng.shuffle(prio)
        def run(sv):
            tasks = [T(f"t{i}", "required", sv[i], deps=tuple(f"t{j}" for j in deps[i])) for i in range(n)]
            # list scheduling with a fixed priority order (Graham), 2 non-preemptive workers
            sim = S.Sim(tasks, physical=2, policy="fifo")
            sim.order = lambda c, pr=prio: sorted(c, key=lambda t: pr[int(t.id[1:])])
            sim.run()
            return max(t.end for t in sim.tasks.values())
        base = run(svc)
        for i in range(n):
            if svc[i] > 1:
                sv2 = list(svc)
                sv2[i] -= 1
                after = run(sv2)
                if after > base:
                    # fixed-DAG longest-path prediction (no resources) for comparison
                    tk = [{"id": f"t{j}", "lower_ns": sv2[j], "upper_ns": sv2[j], "resource": None} for j in range(n)]
                    ed = [(f"t{a}", f"t{b}") for b in range(n) for a in deps[b]]
                    cp_after = bounds(tk, ed)["upper_ns"]
                    tk0 = [{"id": f"t{j}", "lower_ns": svc[j], "upper_ns": svc[j], "resource": None} for j in range(n)]
                    cp_before = bounds(tk0, ed)["upper_ns"]
                    return {"found": True, "trial": k, "services": svc, "shortened": f"t{i}", "deps": {f"t{a}": [f"t{x}" for x in v] for a, v in deps.items()},
                            "priority": prio, "makespan_before": base, "makespan_after_shortening": after,
                            "critical_path_before": cp_before, "critical_path_after": cp_after}
    return {"found": False, "trials": trials}


# ---------------------------------------------------------------- S5 Q021 multi-bottleneck envelope
def s5_envelope():
    # two parallel paths into consume: path1 = fetch(40)->proof(20), path2 = partner(35); consume 10
    rows = []
    for cut in range(0, 61, 5):
        p1 = max(0, 60 - cut)
        tasks = [{"id": "p1", "lower_ns": p1, "upper_ns": p1, "resource": None},
                 {"id": "p2", "lower_ns": 35, "upper_ns": 35, "resource": None},
                 {"id": "c", "lower_ns": 10, "upper_ns": 10, "resource": None}]
        L = bounds(tasks, [("p1", "c"), ("p2", "c")])["upper_ns"]
        rows.append({"cut_on_path1": cut, "latency": L, "gain": 70 - L})
    return {"rows": rows, "saturation_cut": 25, "max_gain": 25,
            "rule": "gain(x) = min(x, L1 - L2) for two paths; beyond the crossover the second path is the bottleneck"}


# ---------------------------------------------------------------- S6 Q022 logical vs physical vs endpoint (real N0)
def s6_logical_physical():
    d = json.load(open(PKG / "data/negative_route.json", encoding="utf-8"))
    rows = {}
    for arm in d["arms"]:
        last = [s for s in arm["snapshots"] if s["kind"] == "unit_ack"][0]
        intent = [s for s in arm["snapshots"] if s["kind"] == "intent_boundary"][0]
        rows[arm["arm"]] = {"source_open_attempts": last["source_open_attempts"], "transform_calls": last["transform_calls"],
                            "intent_to_actual_draw_ns": arm["actual_draw_at_ns"] - intent["at_ns"]}
    return {"N0": rows, "conclusion": "one fewer logical source-open (55->54) with identical transform calls (54->54); the "
                                      "single-sample window is not shorter (no claim either way: one route, non-interleaved)."}


# ---------------------------------------------------------------- S7 Q025/Q092 policies vs exact optimum
def s7_policy_vs_optimum(trials=300, seed=5):
    rng = random.Random(seed)
    rows = {"priority": [], "reserve1": [], "lower_bound_gap": []}
    worst = None
    for k in range(trials):
        tasks = []
        # background speculative work already released, target chain arrives later
        for i in range(rng.randint(2, 4)):
            tasks.append(T(f"s{i}", "speculative", rng.randint(3, 12), 0))
        rel = rng.randint(0, 4)
        tasks.append(T("r0", "required", rng.randint(1, 5), rel))
        tasks.append(T("r1", "required", rng.randint(1, 5), rel, deps=("r0",)))
        phys = 2
        opt = S.optimal_target_completion([S.Task(t.id, t.role, t.service, t.release, t.deps) for t in tasks], phys, "r1")
        def sim(**kw):
            s = S.Sim([S.Task(t.id, t.role, t.service, t.release, t.deps) for t in tasks], physical=phys, **kw).run()
            return s.tasks["r1"].end
        p = sim()
        r1 = sim(reserve_required=1, rs_slots=2)
        # lower bound: release + chain + blocking if all workers busy at release with non-preemptive work
        chain = tasks[-2].service + tasks[-1].service
        lb = rel + chain
        rows["priority"].append(p - opt)
        rows["reserve1"].append(r1 - opt)
        rows["lower_bound_gap"].append(opt - lb)
        if worst is None or p - opt > worst["regret"]:
            worst = {"regret": p - opt, "tasks": [(t.id, t.role, t.service, t.release, t.deps) for t in tasks], "opt": opt, "priority": p, "reserve1": r1}
    def summ(v):
        return {"mean": sum(v) / len(v), "max": max(v), "zero": sum(x == 0 for x in v), "n": len(v)}
    return {"regret_priority": summ(rows["priority"]), "regret_reserve1": summ(rows["reserve1"]),
            "opt_minus_simple_lb": summ(rows["lower_bound_gap"]), "worst_priority_instance": worst,
            "note": "exact optimum by exhaustive non-preemptive search (idle insertion allowed); priority = required-first list scheduling"}


# ---------------------------------------------------------------- S8 Q026/C03/W08 non-preemptive blocking
def s8_blocking():
    out = []
    for spec_service in (20, 100, 400):
        for seg in (1, 4, 20):
            for reserve in (0, 1):
                tasks = [T(f"s{i}", "speculative", spec_service, 0, segments=seg) for i in range(4)] + [T("r", "required", 10, 10)]
                acts = [(10, lambda s: s.cancel("s0"))] if seg > 1 else []
                sim = S.Sim(tasks, physical=4, reserve_required=reserve, segment_exit=seg > 1).run(acts)
                idle_tax = reserve * 10  # a reserved slot idles from 0 until the required task arrives at t=10
                out.append({"spec_service": spec_service, "segments": seg, "reserve": reserve, "required_end": sim.tasks["r"].end,
                            "blocking": sim.tasks["r"].start - 10, "physical_work": sim.work, "reserved_idle_units": idle_tax})
    return {"rows": out, "bound": "blocking <= min remaining service of running tasks when saturated (no reservation); "
                                  "<= segment length with cooperative exits; 0 with a reserved slot at the price of idle capacity"}


# ---------------------------------------------------------------- S9 Q027/C04 upgrade in place vs restart
def s9_upgrade():
    res = {}
    for mode in ("in_place", "restart"):
        tasks = [T("x", "speculative", 30, 0, obj="o")]
        sim = S.Sim(tasks, physical=2, upgrade=mode, consume={"c": ({"x"}, 5)})
        acts = [(12, lambda s: s.consume.update({"c": ({s.upgrade_task("x", "c")}, 5)}))]
        sim.run(acts)
        res[mode] = {"consumer_done": sim.metrics()["consumer_done"].get("c"), "physical_work": sim.work,
                     "tasks": [(t.id, t.role, t.start, t.end, t.cancelled) for t in sim.tasks.values()]}
    return res


# ---------------------------------------------------------------- S9b Q029 priority inheritance on a queued shared job
def s9b_inheritance():
    res = {}
    for scheme in ("refcount_no_inheritance", "demand_set_inheritance"):
        tasks = [S.Task("busy", "speculative", 10, 0), S.Task("s1", "speculative", 20, 0), S.Task("x", "speculative", 5, 1)]
        sim = S.Sim(tasks, physical=1, consume={"c": ({"x"}, 1)})
        def join(s, scheme=scheme):
            s.tasks["x"].consumers.add("c")
            if scheme == "demand_set_inheritance":
                s.tasks["x"].role = "required"
        sim.run([(2, join)])
        res[scheme] = {"consumer_done": sim.metrics()["consumer_done"].get("c"), "x_start": sim.tasks["x"].start}
    return res


# ---------------------------------------------------------------- S10 Q028/C05/W10 mailbox
def s10_mailbox(stall=50):
    """R10 revision (T04): the v1 version was standalone arithmetic. Now delegated to the executable scheduler model
    (bench/exp_mailbox.py: non-preemptive workers, bounded result pool, HELD results keep worker + slot, per-event
    capacity invariants). Results finish while the consumer is stalled; a required task arrives at 10."""
    import exp_mailbox as MB
    out = {}
    specs, _, _ = MB.inputs()["stall_resume"]
    for scheme, pool, cap in (("A_slot_held", "none", None), ("B_pool_m1", "fifo2", 1), ("B_pool_m2", "fifo2", 2)):
        inp = (specs, stall, None)
        if cap == 1:
            tasks = MB.build(specs)
            sim = S.Sim(tasks, physical=4, mailbox=1, stall_until={"ui": stall}).run()
            r = {"r_start": sim.tasks["r"].start, "peak_held_on_worker": sim.peak["held"], "peak_results_in_pool": sim.peak["mailbox"],
                 "violations": len(sim.violations)}
        else:
            c = MB.run_cell(inp, pool, "none", cap=cap)
            r = {k: c[k] for k in ("r_start", "peak_held_on_worker", "peak_results_in_pool", "violations")}
        out[scheme] = r
    out["note"] = "executable model (sched.Sim); see raw/sched/mailbox.json for the full Q028/C05 study"
    return out


# ---------------------------------------------------------------- S11 Q030/W12 fast intents
def s11_fast_intents(service=10, gap=3, intents=8):
    """Intents to targets 0..k arrive every `gap` < service. latest-valid: drop queued stale intents (running
    ones continue to their real exit). fifo: serve all."""
    res = {}
    for policy in ("fifo_all", "latest_valid", "latest_valid_cancel_running"):
        tasks = [T(f"i{k}", "required", service, k * gap) for k in range(intents)]
        sim = S.Sim(tasks, physical=1)
        acts = []
        if policy != "fifo_all":
            for k in range(1, intents):
                def drop(s, k=k):
                    for j in range(k):
                        t = s.tasks[f"i{j}"]
                        if t.state in ("pending", "queued") or (policy == "latest_valid_cancel_running" and t.state == "running"):
                            s.cancel(t.id)
                acts.append((k * gap, drop))
        sim.run(acts)
        last = sim.tasks[f"i{intents-1}"]
        res[policy] = {"final_target_end": last.end, "final_latency": last.end - last.release, "physical_work": sim.work}
    return res


# ---------------------------------------------------------------- S12 Q038 4/2 slot coupling on shared physical workers
def s12_coupling():
    out = {}
    for scheme in ("shared_physical_no_reserve", "reserve_physical_for_rs", "borrow_with_service_bound"):
        tasks = [T("o0", "optional", 60, 0), T("o1", "optional", 60, 0), T("s0", "speculative", 60, 0), T("s1", "speculative", 60, 0),
                 T("r", "required", 10, 5)]
        if scheme == "shared_physical_no_reserve":
            sim = S.Sim(tasks, physical=4).run()
        elif scheme == "reserve_physical_for_rs":
            sim = S.Sim(tasks, physical=4, opt_slots=1).run()  # optional limited so one physical worker stays for R/S
        else:
            # optional may borrow only if its service <= the earliest expected required arrival slack (here 5): none start
            sim = S.Sim([t for t in tasks if t.role != "optional"] + [T("o0", "optional", 4, 0)], physical=4).run()
        out[scheme] = {"required_end": sim.tasks["r"].end, "physical_work": sim.work}
    return out


# ---------------------------------------------------------------- S13 Q039 optional cap scope
def s13_optional_cap():
    sys.path.insert(0, str(PKG / "code"))
    from protocol import Identity, Protocol
    p = Protocol(Identity(1, 1, 1), [(0, "FULL")], workers=4)
    admitted = 0
    for k in range(40):
        if k % 5 == 0 and k:
            p.rebind(Identity(1, 1 + k, 1 + k))
        a = p.admit(100 + k, "optional", k)
        if a:
            admitted += 1
            p.start(a)
            p.exit(a, k)
    # alternative reading: cap per identity scope (attempt set and counter reset on rebind)
    per_scope = sum(min(5, 16) for _ in range(8))
    return {"package_protocol_optional_admitted_over_40_requests_with_7_rebinds": admitted,
            "reading_per_identity_scope_would_admit": per_scope,
            "note": "package model keeps optional_total across rebind (window-scoped cap); a per-identity reading admits more "
                    "work under rapid rebinds (W12) - the scope must be fixed by the contract owner, not by the optimiser"}


# ---------------------------------------------------------------- S14 Q040/W11 bytes & deadline with the package protocol
def s14_bytes():
    sys.path.insert(0, str(PKG / "code"))
    from protocol import Identity, Protocol
    rows = {}
    p = Protocol(Identity(1, 1, 1), [(0, "FULL")], workers=4)
    a = p.admit(0, "required", 0)
    p.start(a)
    g1 = p.reserve_bytes(a, 20 * 1024 * 1024, 1)
    b = p.admit(1, "required", 2)
    p.start(b)
    g2 = p.reserve_bytes(b, 20 * 1024 * 1024, 3)   # only 12 MiB left
    p.cancel(a)
    p.return_unread(a, 5 * 1024 * 1024)             # read 15 of 20 MiB before cancel
    late = p.reserve_bytes(b, 1, 15_000_000_001)    # past the 15 s window
    acc = p.exit(a, 15_000_000_002)
    rows["grants"] = [g1, g2, late]
    rows["used_bytes_after"] = p.used_bytes
    rows["cancelled_exit_accepted"] = acc
    rows["occupied_after_a_exit"] = p.occupied
    rows["observation"] = ("package model: reservation persists after exit (bytes count as used for the window), refund only via "
                           "return_unread; cancelled task cannot be accepted; late reservation past 15 s returns 0")
    return rows


# ---------------------------------------------------------------- S17 Q092 exact optimum vs combined lower bounds
def s17_bounds(trials=300, seed=9):
    rng = random.Random(seed)
    tight = 0
    gaps = []
    ex = None
    for k in range(trials):
        n = rng.randint(3, 6)
        lanes = rng.choice([1, 2, 3])
        tasks = []
        for i in range(n):
            deps = tuple(f"t{j}" for j in range(i) if rng.random() < 0.35)
            tasks.append(T(f"t{i}", "required", rng.randint(1, 8), rng.choice([0, 0, 2]), deps=deps))
        tasks.append(T("goal", "required", 1, 0, deps=tuple(t.id for t in tasks)))
        opt = S.optimal_target_completion(tasks, lanes, "goal")
        work = sum(t.service for t in tasks)
        lb_work = -(-work // lanes)
        tk = [{"id": t.id, "lower_ns": t.service, "upper_ns": t.service, "resource": None} for t in tasks]
        ed = [(d, t.id) for t in tasks for d in t.deps]
        cp = bounds(tk, ed)["upper_ns"]
        lb = max(lb_work, cp)
        gaps.append(opt - lb)
        tight += opt == lb
        if ex is None and opt > lb:
            ex = {"tasks": [(t.id, t.service, t.release, t.deps) for t in tasks], "lanes": lanes, "opt": opt, "lb_work": lb_work, "lb_cp": cp}
    return {"trials": trials, "tight": tight, "max_gap": max(gaps), "mean_gap": sum(gaps) / len(gaps), "first_non_tight": ex,
            "note": "max(work/lanes, critical path) ignores releases and non-preemptive packing; exact search shows the residual"}


# ---------------------------------------------------------------- S18 Q109/C06 cache+schedule joint
def s18_joint(cap=2):
    """Requests over objects with rebuild costs; a high-hit-rate policy (LRU) vs a value policy (keep expensive
    objects). Latency = sum of rebuild costs on the critical request sequence."""
    seq = ["x", "a", "b", "a", "b", "a", "b", "x"]
    cost = {"a": 1, "b": 1, "x": 20}
    def run(policy):
        cache, hits, lat = [], 0, 0
        for o in seq:
            if o in cache:
                hits += 1
                cache.remove(o)
                cache.append(o)
                continue
            lat += cost[o]
            cache.append(o)
            if len(cache) > cap:
                if policy == "lru":
                    cache.pop(0)
                else:
                    victim = min(cache[:-1], key=lambda z: (cost[z], cache.index(z)))
                    cache.remove(victim)
        return {"hits": hits, "latency_units": lat}
    return {"seq": seq, "cost": cost, "lru": run("lru"), "value": run("value")}


# ---------------------------------------------------------------- S19 Q110/C27 speculation safety
def s19_speculation():
    out = []
    for spec_service in (5, 50, 500):
        for scheme in ("unbounded", "budget2", "gate_short_only"):
            n_spec = 4
            tasks = [T(f"s{i}", "speculative", spec_service, 0) for i in range(n_spec)] + [T("r", "required", 10, 3)]
            if scheme == "budget2":
                sim = S.Sim(tasks, physical=4, spec_budget=2).run()
            elif scheme == "gate_short_only":
                tasks = [t for t in tasks if t.role == "required" or t.service <= 10]
                sim = S.Sim(tasks, physical=4).run()
            else:
                sim = S.Sim(tasks, physical=4).run()
            out.append({"spec_service": spec_service, "scheme": scheme, "required_blocking": sim.tasks["r"].start - 3})
    return {"rows": out, "theorem": "without a service upper bound on admitted speculative work and with all workers "
                                     "speculative, the required blocking is unbounded (equals min remaining service); a "
                                     "budget b < workers bounds it to 0 for the first workers-b required tasks"}


# ---------------------------------------------------------------- S21 Q112 dual budget double counting
def s21_dual_budget():
    # a 12 MiB decoded object shared by the materialisation cache and the sample cache
    shared = 12
    per_resource = {"materialisation_cache": shared, "sample_cache": shared}
    naive_total = sum(per_resource.values())
    owner_ledger_total = shared
    return {"naive_sum_MiB": naive_total, "single_owner_ledger_MiB": owner_ledger_total,
            "admission_32MiB_naive_blocks_second_object": naive_total + 12 > 32,
            "admission_32MiB_owner_ledger_blocks_second_object": owner_ledger_total + 12 > 32,
            "rule": "deduplication is legal only with one owner per physical buffer; virtual quotas are not residency"}


def main():
    out = {"env": env(), "units": "hypothesis units, not ns"}
    for name, fn in [("S1_order_vs_dependency", s1_order_vs_dependency), ("S2_anomaly", s2_anomaly), ("S5_envelope", s5_envelope),
                     ("S6_logical_physical", s6_logical_physical), ("S7_policy_vs_optimum", s7_policy_vs_optimum),
                     ("S8_blocking", s8_blocking), ("S9_upgrade", s9_upgrade), ("S9b_inheritance", s9b_inheritance), ("S10_mailbox", s10_mailbox),
                     ("S11_fast_intents", s11_fast_intents), ("S12_coupling", s12_coupling), ("S13_optional_cap", s13_optional_cap),
                     ("S14_bytes", s14_bytes), ("S17_bounds", s17_bounds), ("S18_joint", s18_joint), ("S19_speculation", s19_speculation),
                     ("S21_dual_budget", s21_dual_budget)]:
        out[name] = fn()
        print(name, json.dumps(out[name], default=str)[:400], flush=True)
    write_json(RAW / "sched/sched.json", out)


if __name__ == "__main__":
    main()
