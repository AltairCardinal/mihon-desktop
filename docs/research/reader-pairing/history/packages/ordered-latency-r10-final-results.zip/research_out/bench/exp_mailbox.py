"""T04 rebuild of Q028 and C05 on the executable scheduler (lab/sched.py) instead of standalone arithmetic.

Every number below comes from Sim runs with competition (4 non-preemptive workers shared by all roles),
completion, backpressure (bounded result pool; a result that finds the pool full is HELD on its worker and keeps
its logical slot), consumption (acceptance by a consumer), reclaim (cancel / context close / failure) and the
per-event capacity invariants of Sim._invariants. Units are model time units, not ns.
Output raw/sched/mailbox.json
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import sched as S
from common import RAW, env, write_json

INF = 10 ** 9
D = 16          # batch boundary / deadline (one frame period)
UNIT = ("u1", "u2")


# ------------------------------------------------------------------------------------------------ inputs
def inputs():
    """name -> (task specs, stall, close_at). spec = (id, role, service, release, consumer)."""
    base_r = ("r", "required", 3, 10, "nav")
    return {
        "stall_resume": ([("u1", "speculative", 5, 0, "ui"), ("u2", "speculative", 6, 0, "ui"),
                          ("p1", "speculative", 7, 0, "ui"), ("p2", "speculative", 8, 0, "ui"), base_r], 40, None),
        "slow_member": ([("u1", "speculative", 5, 0, "ui"), ("u2", "speculative", 30, 0, "ui"),
                         ("p1", "speculative", 7, 0, "ui"), ("p2", "speculative", 8, 0, "ui"), base_r], 12, None),
        "close_conflict": ([("u1", "speculative", 5, 0, "ui"), ("u2", "speculative", 6, 0, "ui"),
                            ("p1", "speculative", 7, 0, "ui"), ("p2", "speculative", 8, 0, "ui"), base_r], 40, 20),
        "independent_burst_first": ([("p1", "speculative", 2, 0, "ui"), ("p2", "speculative", 3, 0, "ui"),
                                     ("p3", "speculative", 4, 0, "ui"), ("p4", "speculative", 5, 0, "ui"),
                                     ("u1", "speculative", 8, 0, "ui"), ("u2", "speculative", 9, 0, "ui"), base_r], 40, None),
    }


def build(specs):
    tasks = []
    for tid, role, svc, rel, cons in specs:
        t = S.Task(tid, role, svc, rel, bytes_upper=8 << 20, obj=tid)
        t.consumers.add(cons)
        tasks.append(t)
    return tasks


def is_unit(t):
    return "U" if t.id in UNIT else None


# ------------------------------------------------------------------------------------------------ consumer policies
def batch_policy(kind, stall, horizon=200):
    """Consumer acceptance policy for 'ui' as (after_event hook, wake-up actions). Exact event timing.
    none : no batching (Sim delivers directly once the consumer is live; stall_end accepts the backlog)
    I    : unit members committed immediately once live; independent results only at boundaries k*D >= stall
    II   : one batch of all ui results; commit when the whole batch is ready, else at deadline stall+k*D commit the
           ready subset (split on time-out)"""
    if kind == "none":
        return None, []
    wake = [(k * D, lambda s: None) for k in range(1, horizon // D + 1)] + [(stall, lambda s: None)]
    if kind == "I":
        def hook(s):
            if s.now < stall:
                return
            for x in list(s.mailbox) + list(s.held):
                t = s.tasks[x]
                if "ui" in t.consumers and (x in UNIT or s.now % D == 0):
                    s.accept(x, "ui")
        return hook, wake
    state = {"next_deadline": stall + D}

    def hook2(s):
        if s.now < stall:
            return
        ui = [t for t in s.tasks.values() if "ui" in t.consumers and not t.cancelled and t.state != "exited"]
        pending = [t for t in ui if not t.accepted]
        ready = [t for t in pending if t.state in ("pooled", "held")]
        if pending and (len(ready) == len(pending) or s.now >= state["next_deadline"]):
            for t in ready:
                s.accept(t.id, "ui")
        if s.now >= state["next_deadline"]:
            state["next_deadline"] = stall + D * ((s.now - stall) // D + 1)
    wake2 = [(stall + k * D, lambda s: None) for k in range(0, horizon // D + 1)]
    return hook2, wake2


POOL = 3        # the SAME pool capacity for both joint designs (mechanisms differ, capacity does not)


def run_cell(inp, pool, batch, close_at_override=None, cap=None):
    cap = POOL if cap is None else cap
    specs, stall, close_at = inp
    tasks = build(specs)
    kw = dict(physical=4, unit_of=is_unit)
    if pool == "none":
        kw.update(mailbox=0)
    elif pool == "fifo2":
        kw.update(mailbox=2)
    elif pool == "I":          # bounded pool, complete-unit results admitted/drained first
        kw.update(mailbox=cap, pool_policy="unit_first")
    elif pool == "II":         # same bounded pool with 2 places reserved for the complete unit
        kw.update(mailbox=cap, pool_reserved_unit=2)
    elif pool == "unbounded":
        kw.update(mailbox=None)
    if batch == "none":
        kw["stall_until"] = {"ui": stall}
    else:                       # acceptance only through the batch policy hook
        kw["stall_until"] = {"ui": INF}
    hook, acts = batch_policy(batch, stall)
    sim = S.Sim(tasks, after_event=hook, **kw)
    ca = close_at if close_at_override is None else close_at_override
    if ca is not None:
        def close_ui(s):
            for t in list(s.tasks.values()):
                if "ui" in t.consumers:
                    s.cancel(t.id)
        acts.append((ca, close_ui))
    sim.run(acts)
    m = sim.metrics()
    acc = {t.id: t.accepted_at for t in sim.tasks.values()}
    unit_ack = None if any(acc.get(u) is None for u in UNIT) else max(acc[u] for u in UNIT)
    ind = [acc[t] for t in acc if t.startswith("p")]
    return {"unit_ack": unit_ack, "r_start": sim.tasks["r"].start,
            "independent_commit_max": None if (not ind or None in ind) else max(ind),
            "peak_results_in_pool": m["peak"]["mailbox"], "peak_held_on_worker": m["peak"]["held"],
            "peak_resident_results": m["peak"]["resident_results"], "held_worker_time": m["held_worker_time"],
            "violations": len(sim.violations), "double_releases": m["double_releases"],
            "resident_after_run": m["results_in_pool"] + m["results_held_on_worker"],
            "release_calls_max": max(sim.release_calls.values(), default=0)}


# ------------------------------------------------------------------------------------------------ Q028
def q028():
    out = {}
    for name, inp in inputs().items():
        out[name] = {"A_slot_held_until_consumed": run_cell(inp, "none", "none"),
                     "B_pool_m2": run_cell(inp, "fifo2", "none"),
                     "B_pool_unbounded": run_cell(inp, "unbounded", "none")}
    # pool size sweep on the stall input: where does the required task stop being blocked?
    sweep = {}
    for m in range(0, 6):
        specs, stall, _ = inputs()["independent_burst_first"]
        tasks = build(specs)
        sim = S.Sim(tasks, physical=4, mailbox=m, stall_until={"ui": stall}).run()
        sweep[m] = {"r_start": sim.tasks["r"].start, "peak_held": sim.peak["held"], "violations": len(sim.violations)}
    out["pool_capacity_sweep_independent_burst"] = sweep
    return out


# ------------------------------------------------------------------------------------------------ C05
def c05():
    cells = {"0": ("none", "none"), "A_I": ("I", "none"), "B_I": ("none", "I"), "AB_I": ("I", "I"),
             "A_II": ("II", "none"), "B_II": ("none", "II"), "AB_II": ("II", "II")}
    res = {}
    for name, inp in inputs().items():
        res[name] = {c: run_cell(inp, *pb) for c, pb in cells.items()}
    # distinguishing evidence between the two joint designs
    diff = {}
    for name, r in res.items():
        a, b = r["AB_I"], r["AB_II"]
        keys = [k for k in ("unit_ack", "r_start", "independent_commit_max", "peak_resident_results", "held_worker_time") if a[k] != b[k]]
        diff[name] = {k: {"AB_I": a[k], "AB_II": b[k]} for k in keys}
    sens = {}
    for capv in (2, 3, 4, 5):
        sens[capv] = {name: {d: (lambda r: (r["unit_ack"], r["r_start"], r["held_worker_time"]))(run_cell(inp, d, d, cap=capv))
                             for d in ("I", "II")} for name, inp in inputs().items()}
    inter = {}
    for name, r in res.items():
        inter[name] = {}
        for d in ("I", "II"):
            for k in ("unit_ack", "r_start"):
                v = [r["0"][k], r[f"A_{d}"][k], r[f"B_{d}"][k], r[f"AB_{d}"][k]]
                inter[name][f"{k}_{d}"] = None if None in v else v[3] - v[1] - v[2] + v[0]
    return {"pool_capacity_both_designs": POOL, "cells": res, "AB_I_vs_AB_II": diff, "interaction": inter,
            "capacity_sensitivity_AB_(unit_ack,r_start,held_worker_time)": sens,
            "designs": {"I": "A_I = bounded pool (capacity POOL) whose freed places go first to held members of the awaited unit; "
                             "B_I = independent results batched at frame boundaries, unit members never batched",
                        "II": "A_II = the same pool (capacity POOL) with 2 places reserved for the awaited complete unit; "
                              "B_II = one batch per deadline, split on time-out (commit the ready subset)"},
            "mechanism_difference": "I orders WHO gets freed pool space and never delays unit members; II reserves space "
                                    "ahead of time and delays everything to a common deadline unless the batch is complete"}


def main():
    out = {"env": env(), "units": "model time units", "Q028": q028(), "C05": c05()}
    write_json(RAW / "sched/mailbox.json", out)
    import json
    print(json.dumps(out["C05"]["AB_I_vs_AB_II"], indent=0))
    print(json.dumps({k: {c: (v["unit_ack"], v["r_start"]) for c, v in r.items()} for k, r in out["C05"]["cells"].items()}))
    print(json.dumps(out["Q028"]["pool_capacity_sweep_independent_burst"]))


if __name__ == "__main__":
    main()
