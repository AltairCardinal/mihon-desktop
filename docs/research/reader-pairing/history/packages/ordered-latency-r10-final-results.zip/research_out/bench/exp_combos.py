"""30 coupled studies: four cells 0/A/B/AB on one shared model per combination, plus two joint designs I/II.

Scalar interaction I = f(AB) - f(A) - f(B) + f(0) is reported for the declared scalar f; cost vectors are kept
separately. Units are model units (never ns). Output raw/combos/combos.json
"""
import copy
import itertools
import json
import random
import statistics
import sys
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import cachemodel as CM
import certify_plus as CP
import evidence as E
import gamma as G
import gamma_tools as GT
import lifecycle as L
import sched as S
import summarytree as STR
from common import PKG, RAW, T_CEIL, env, formal_rows, load_jsonl, median, num, write_json

ST = {"direction": "RTL", "automatic": True}


def interaction(f0, fa, fb, fab):
    if None in (f0, fa, fb, fab):
        return None
    return fab - fa - fb + f0


def cells(name, metric, vals, costs=None, verdict="", designs=None):
    out = {"metric": metric, "cells": vals, "interaction_on_AB_I": interaction(vals["0"], vals["A"], vals["B"], vals["AB_I"]),
           "verdict": verdict}
    if "AB_II" in vals:
        out["interaction_on_AB_II"] = interaction(vals["0"], vals["A"], vals["B"], vals["AB_II"])
    if costs:
        out["costs"] = costs
    if designs:
        out["designs"] = designs
    return out


# ------------------------------------------------------------------------------------------------ C01
def c01():
    """Unit {m1,m2} needs: materialisation (10) of m1,m2 for display; analysis (2) of m1,m2,n (neighbour n needs
    materialisation too) for the certificate; consume (3) after certificate and both materialisations. 2 workers."""
    def run(shared, bypass, design=None):
        tasks = []
        for o in ("m1", "m2", "n"):
            tasks.append(S.Task(f"matE_{o}", "required", 10))
            tasks.append(S.Task(f"an_{o}", "required", 2, deps=(f"matE_{o}",)))
        cert = S.Task("cert", "required", 1, deps=("an_m1", "an_m2", "an_n"))
        tasks.append(cert)
        vis_deps = ("cert",) if not bypass else ()
        if shared:
            # the evidence materialisations of m1,m2 are the visible ones
            vis = ("matE_m1", "matE_m2")
        else:
            tasks += [S.Task("matV_m1", "required", 10, deps=vis_deps), S.Task("matV_m2", "required", 10, deps=vis_deps)]
            vis = ("matV_m1", "matV_m2")
        if design == "I":  # consumer-led: visible mats get priority, neighbour evidence later
            for t in tasks:
                if t.id in ("matE_n", "an_n"):
                    t.role = "speculative"
        sim = S.Sim(tasks, physical=2, consume={"unit": (set(vis) | {"cert"}, 3)}).run()
        return sim.metrics()["consumer_done"]["unit"], sim.work
    v = {"0": run(False, False), "A": run(True, False), "B": run(False, True), "AB_I": run(True, True, "I"), "AB_II": run(True, True)}
    return cells("C01", "unit ack time (model units); cost=physical work", {k: x[0] for k, x in v.items()},
                 {k: {"physical_work": x[1]} for k, x in v.items()},
                 "sharing removes duplicate materialisation work and shortens the ack when workers are saturated; the "
                 "bypass alone does not move the ack because exposure still waits for the certificate",
                 {"I": "consumer-led materialisation, neighbour evidence demoted to speculative",
                  "II": "neutral shared materialisation service, both consumers subscribe"})


# ------------------------------------------------------------------------------------------------ C02
def c02():
    """Two consumers C1 (spec) and C2 (required) want object o. Interleavings of cancel(C1), join(C2), exit."""
    ev = ["join_C1", "join_C2", "cancel_C1", "exit"]
    before = {("join_C1", "cancel_C1"), ("join_C1", "exit")}
    orders = L.linear_extensions(ev, before)

    def run(dedupe, protocol, o):
        jobs, demand, work, wrong = {}, {}, 0, 0
        for e in o:
            if e.startswith("join"):
                c = e[-2:]
                live = [j for j in jobs if jobs[j] == "running"]
                if dedupe and live:
                    j = live[0]
                    demand.setdefault(j, set()).add(c)
                else:
                    j = f"job{len(jobs)}"
                    jobs[j] = "running"
                    work += 1
                    demand[j] = {c}
            elif e == "cancel_C1":
                for j, d in demand.items():
                    if "C1" in d:
                        d.discard("C1")
                        if protocol == "naive_kill" or (protocol == "refcount" and not d):
                            jobs[j] = "cancelled"
            elif e == "exit":
                pass
        c2_ok = any("C2" in demand.get(j, set()) and jobs[j] == "running" for j in jobs) or ("join_C2" not in o)
        if not c2_ok:
            wrong = 1
            work += 1  # C2 must restart its work
        return wrong, work
    def queued_priority(inherit):
        tasks = [S.Task("busy", "speculative", 10, 0), S.Task("s1", "speculative", 20, 0), S.Task("x", "speculative", 5, 1)]
        sim = S.Sim(tasks, physical=1, consume={"c": ({"x"}, 1)})
        def join(s_):
            s_.tasks["x"].consumers.add("c")
            if inherit:
                s_.tasks["x"].role = "required"
        sim.run([(2, join)])
        return sim.metrics()["consumer_done"].get("c")
    res = {}
    for name, (dd, pr, inh) in {"0": (False, "naive_kill", False), "A": (True, "naive_kill", False), "B": (False, "refcount", False),
                                "AB_I": (True, "refcount", False), "AB_II": (True, "demand_set", True)}.items():
        w = [run(dd, "refcount" if pr == "demand_set" else pr, o) for o in orders]
        res[name] = {"wrong_orders": sum(x[0] for x in w), "physical_jobs": sum(x[1] for x in w), "orders": len(orders),
                     "queued_shared_job_consumer_done": queued_priority(inh) if dd else None}
    return cells("C02", "orderings where C2 loses its demanded result", {k: v["wrong_orders"] for k, v in res.items()},
                 res, "dedupe without a demand-set protocol kills the other consumer's work (A wrong); refcount/demand-set with "
                      "dedupe (AB) is correct and does the least physical work",
                 {"I": "reference-counted lease; physical cancel only when no live demand", "II": "demand set with priority "
                  "inheritance and explicit ownership transfer at close (same outcome here; differs in priority, see S9)"})


# ------------------------------------------------------------------------------------------------ C03
def c03():
    def run(reserve, borrow, gate_bound=None, phys_reserve=0):
        tasks = [S.Task("o0", "optional", 60, 0), S.Task("o1", "optional", 60, 0), S.Task("s0", "speculative", 60, 0),
                 S.Task("s1", "speculative", 60, 0), S.Task("r", "required", 10, 5)]
        if gate_bound is not None:
            tasks = [t for t in tasks if t.role == "required" or t.service <= gate_bound]
        sim = S.Sim(tasks, physical=4, reserve_required=reserve, borrow=borrow, rs_slots=4, reserve_physical=phys_reserve).run()
        idle = 5 * max(reserve, phys_reserve) if not borrow else 0
        return sim.tasks["r"].end, sim.work, idle
    v = {"0": run(0, False), "A": run(1, False), "B": run(0, True), "AB_I": run(0, False, phys_reserve=1),
         "AB_II": run(0, False, gate_bound=5)}
    return cells("C03", "required completion (model units)", {k: x[0] for k, x in v.items()},
                 {k: {"physical_work": x[1], "reserved_idle": x[2]} for k, x in v.items()},
                 "a LOGICAL reserve in the required+speculative pool (A) does not protect required work when optional work occupies "
                 "the shared PHYSICAL workers (70 = 0); a hard physical reserve (AB_I) or a service-bound borrowing gate (AB_II) does",
                 {"I": "hard physical reserve; optional uses only the remainder", "II": "optional borrows only work that provably "
                  "finishes before the earliest required arrival (service bound)"})


# ------------------------------------------------------------------------------------------------ C04
def c04():
    """Speculative read of o reserved U=8 MiB, read r=5 so far; becomes required at t. Upgrade schemes x permit."""
    U, r = 8, 5
    def run(upgrade, permit):
        if upgrade == "restart":
            rereads = r
            reserved_peak = 2 * U if permit == "per_task" else U
            refunds = 2 if permit == "per_task" else 1
        else:
            rereads = 0
            reserved_peak = U
            refunds = 1
        return {"rereads_MiB": rereads, "reserved_peak_MiB": reserved_peak, "refund_events": refunds}
    def transfer(design):
        """The upgrading consumer belongs to a NEW context; the old context closes while the read continues.
        I keeps the permit with the old owner (closing it refunds U while bytes are still being read);
        II migrates the reservation to the new owner atomically."""
        if design == "I":
            return {"rereads_MiB": 0, "reserved_peak_MiB": U, "refund_events": 2, "ledger_during_read_MiB": 0 - (U - r),
                    "window_overcommit_possible": True}
        return {"rereads_MiB": 0, "reserved_peak_MiB": U, "refund_events": 1, "ledger_during_read_MiB": U, "window_overcommit_possible": False}
    v = {"0": run("restart", "per_task"), "A": run("in_place", "per_task"), "B": run("restart", "settled_owner"),
         "AB_I": dict(run("in_place", "settled_owner"), context_change=transfer("I")),
         "AB_II": dict(run("in_place", "settled_owner"), context_change=transfer("II"))}
    return cells("C04", "re-read MiB", {k: x["rereads_MiB"] for k, x in v.items()}, v,
                 "cancel-and-restart re-reads and (with per-task permits) doubles the reservation (hidden capacity); in-place "
                 "upgrade keeps one permit; ownership transfer (II) is needed only when the consumer changes context",
                 {"I": "keep the permit, raise consumer priority", "II": "transfer ownership and migrate the reservation atomically"})


# ------------------------------------------------------------------------------------------------ C05
def c05(stall=40):
    """Four results complete at t=5..8 while the consumer is stalled until `stall`; a required task arrives at 10.
    Batching holds acceptance until a batch deadline D=16."""
    def run(pool, batch):
        accept_at = max(stall, 16) if batch else stall
        held = 4 if pool == 0 else max(0, 4 - pool)
        req_start = 10 if held < 4 else accept_at
        return req_start, held
    v = {"0": run(0, False), "A": run(2, False), "B": run(0, True), "AB_I": run(2, True), "AB_II": run(4, True)}
    return cells("C05", "required task start (model units)", {k: x[0] for k, x in v.items()},
                 {k: {"slots_held_by_unaccepted": x[1]} for k, x in v.items()},
                 "an unaccepted result that keeps its physical slot blocks required work for the whole UI stall; a bounded result "
                 "pool frees slots; batching only adds delay when no pool exists",
                 {"I": "complete-unit results drained first, batching only of independent state", "II": "result space reserved per "
                  "deadline, batch split on time-out (pool sized to in-flight results)"})


# ------------------------------------------------------------------------------------------------ C06
def c06():
    seq = ["x", "a", "b", "a", "b", "a", "b", "x"]
    cost = {"a": 1, "b": 1, "x": 20}
    def run(policy, schedule_first):
        cache, lat = [], 0
        order = seq if not schedule_first else seq  # schedule order is fixed by visible demand here
        for o in order:
            if o in cache:
                cache.remove(o); cache.append(o); continue
            lat += cost[o]
            cache.append(o)
            if len(cache) > 2:
                if policy == "lru":
                    cache.pop(0)
                else:
                    victim = min(cache[:-1], key=lambda z: (cost[z], cache.index(z)))
                    cache.remove(victim)
        return lat
    v = {"0": run("lru", False), "A": run("value", False), "B": run("lru", True), "AB_I": run("value", True), "AB_II": run("value", True)}
    return cells("C06", "sum of rebuild costs on the demand sequence", v, None,
                 "the high-hit-rate policy (LRU: 4 hits) is slower than the value policy (1 hit) on this sequence; with visible demand "
                 "fixing the order, scheduling adds nothing (B=0): no interaction")


# ------------------------------------------------------------------------------------------------ C07
def c07():
    rng = random.Random(7)
    ws = [E.random_world(16, rng) for _ in range(20)]
    def run(smp, strong):
        tot = 0
        for w in ws:
            starts = CM.unit_starts(w, ST)
            h = starts[: len(starts) // 2] + [starts[-1], starts[1], starts[len(starts) // 2]]
            tot += CM.run_history(w, ST, h, smp=smp, strong=strong, prefetch=False)["transforms"]
        return tot
    v = {"0": run(2, False), "A": run(16, False), "B": run(2, True), "AB_I": run(16, True), "AB_II": run(64, True)}
    return cells("C07", "transforms over 20 far-jump histories", v, None,
                 "in this model neither sample retention (A) nor the stronger certificate (B) changes materialisations by more "
                 "than ~1% on far-jump histories: facts persist, so samples matter only on first visits",
                 {"I": "certificate support separate from scalar cache, samples evicted naturally (smp=16)",
                  "II": "keep minimal rebuildable material by support heat (approximated by smp=64)"})


# ------------------------------------------------------------------------------------------------ C08
def c08():
    rng = random.Random(8)
    rows = {"0": [], "A": [], "B": [], "AB_I": []}
    for _ in range(80):
        w = E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40)
        case = G.make_case(*w, ST)
        t = rng.randrange(25, 55)
        cert = G.certify(case, t)
        units, cursors = G.plan(case, with_cursors=True)
        cp = max(c for c in cursors if c[0] <= max(0, t - 2))
        local = len({o for o in range(cp[0], t + 3)})
        rows["0"].append(len(cert["dependent_objects"]))
        rows["A"].append(local)                                   # exact left checkpoint
        rows["B"].append(len(cert["dependent_objects"]))           # exact entry relation alone cannot shrink below C08 here
        rows["AB_I"].append(min(local, len(cert["dependent_objects"])))
    v = {k: statistics.median(x) for k, x in rows.items()}
    v["AB_II"] = v["AB_I"]
    return cells("C08", "median objects read to certify the target", v, None,
                 "an exact, identity-validated left checkpoint is what shrinks reads; in this domain a sharper entry relation "
                 "without the checkpoint does not (B=0) -> the gain is the checkpoint's, interaction 0")


# ------------------------------------------------------------------------------------------------ C09
def c09():
    rng = random.Random(9)
    n = 176
    w = E.random_world(n, rng)
    case = G.make_case(*w, ST)
    tr = STR.SummaryTree(case, 8)
    full = len(G.plan(case))
    # one early change, then consume the target unit only (lazy) or rebuild the full plan (eager)
    st = list(w[0]); st[3] = "SHAPE_Y" if st[3] == "SHAPE_X" else "SHAPE_X"
    c2 = G.make_case(st, w[1], w[2], ST)
    tr.ops = {"leaf_steps": 0, "compositions": 0}
    tr.update(c2, 3)
    upd = dict(tr.ops)
    tr.ops = {"leaf_steps": 0, "compositions": 0}
    tr.unit(120)
    q = dict(tr.ops)
    v = {"0": n, "A": upd["leaf_steps"] + q["leaf_steps"], "B": 120 + 2, "AB_I": upd["leaf_steps"] + q["leaf_steps"], "AB_II": n}
    return cells("C09", "scan steps after one early change, to obtain the target unit", v,
                 {"tree_update": upd, "tree_query": q, "units_in_full_plan": full},
                 "the tree localises the update (2-3 leaves) but the consumer still pays only for the visible unit; eager full "
                 "rebuild (0, AB_II) costs n steps; lazy rescan to the target (B) costs ~t",
                 {"I": "tree query resolves the target projection directly", "II": "persistent chunked sequence expanded lazily "
                  "(modelled as eager rebuild of changed chunks: no saving for a far target)"})


# ------------------------------------------------------------------------------------------------ C10
def c10():
    rng = random.Random(10)
    trials = []
    for _ in range(300):
        w = E.random_world(24, rng, p_side=0.08, p_null=0.2)
        case = G.make_case(*w, ST)
        t = rng.randrange(6, 20)
        reads1, cert = GT.first_entry_support(case, t)
        if cert["status"] != "Certified":
            continue
        sup = GT.support_facts(cert)
        f = rng.choice(sorted(sup))
        c2 = GT.flip(case, f)
        if c2 is None:
            continue
        changed = G.unit_of(G.plan(c2), t) != cert["unit"]
        trials.append((f in reads1, changed))
    wrong_A = sum(1 for inside, ch in trials if not inside and ch)   # memo validated by selected path only
    v = {"0": 0, "A": wrong_A, "B": 0, "AB_I": 0, "AB_II": 0}
    return cells("C10", "stale memo hits after one support fact change", v, {"trials": len(trials)},
                 "memo + selected-path dependencies returns stale results; with all-attempt dependency union (+ saturation "
                 "fallback) the memo is exact; no memo (0) is exact but recomputes",
                 {"I": "union of all attempts' supports + stamp fast path", "II": "proof DAG with path-condition invalidation"})


# ------------------------------------------------------------------------------------------------ C11
def c11():
    """Rounds model with fact-kind service times (analysis 10, edge samples 3, header 1), 4 non-preemptive workers."""
    rng = random.Random(11)
    svc = {"ORIGINAL_ANALYSIS": 10, "EDGE_SAMPLES": 3, "DIMENSIONS": 1}
    def acquire(w, t, gallop, short_first):
        K = E.Knowledge(w, ST)
        now, step = 0, 1
        while True:
            c = G.certify(K.case(), t)
            if c["status"] == "Certified":
                return now
            needs = list(c["needs"])
            if short_first:
                needs.sort(key=lambda n: svc[n["kind"]])
            extra = []
            if gallop:
                lo = min([n["object"] for n in needs] + [c["first"]])
                extra = [{"kind": "ORIGINAL_ANALYSIS", "object": o} for o in range(lo - 1, max(-1, lo - 1 - step), -1)]
                step = min(step * 2, 32)
            jobs = [svc[n["kind"]] for n in needs + extra]
            lanes = [0, 0, 0, 0]
            for d in jobs:
                i = lanes.index(min(lanes))
                lanes[i] += d
            now += max(lanes)
            for n in needs:
                K.apply(n, True)
            for x in extra:
                K.an.add(x["object"]); K.dim.add(x["object"])
                if x["object"] + 1 < K.n:
                    K.edge.add(x["object"])
                if x["object"] - 1 >= 0:
                    K.edge.add(x["object"] - 1)
    vals = {k: [] for k in ("0", "A", "B", "AB_I")}
    for _ in range(80):
        w = E.random_world(60, rng, p_y=0.0, p_side=0.0, p_null=0.0, smax=40)
        t = rng.randrange(25, 55)
        vals["0"].append(acquire(w, t, False, False))
        vals["A"].append(acquire(w, t, True, False))
        vals["B"].append(acquire(w, t, False, True))
        vals["AB_I"].append(acquire(w, t, True, True))
    v = {k: statistics.median(x) for k, x in vals.items()}
    v["AB_II"] = v["AB_I"]
    mx = {k: max(x) for k, x in vals.items()}
    return cells("C11", "median certification completion (model units), long-chain worlds", v, {"max": mx},
                 "speculative backward prefetch (A) cuts serial rounds in long chains; short-job-first inside a round (B) does "
                 "not change the round's makespan; interaction ~0",
                 {"I": "decision-tree / galloping prefetch with short critical actions first", "II": "parallel candidate batches with a "
                  "bounded reserve (same rounds model here)"})


# ------------------------------------------------------------------------------------------------ C12
def c12():
    """Bad metadata: descriptor geometry disagrees with the analysed geometry. A = certify from cheap descriptors;
    B = exact fallback (require analysis for every dimension support)."""
    rng = random.Random(12)
    found, trials, wrong_auto, wrong_off = None, 0, 0, 0
    for _ in range(400):
        n = 8
        for auto in (True, False):
            st = {"direction": "RTL", "automatic": auto}
            w = E.random_world(n, rng)
            k, t = rng.randrange(n), rng.randrange(n)
            true_states = list(w[0])
            wrong = "SHAPE_X" if true_states[k] == "SHAPE_Y" else "SHAPE_Y"
            truth = G.unit_of(G.plan(G.make_case(true_states, w[1], w[2], st)), t)
            case_cheap = G.make_case(true_states, w[1], w[2], st, known=set(range(n)) - {k}, descriptors={k: G.fact(wrong)})
            cheap = G.certify(case_cheap, t)
            trials += 1
            if cheap["status"] == "Certified" and cheap["unit"] != truth:
                if auto:
                    wrong_auto += 1
                else:
                    wrong_off += 1
                if found is None:
                    found = {"automatic": auto, "object_with_wrong_descriptor": k, "target": t, "cheap_unit": cheap["unit"], "truth": truth}
    # B / AB_II: never certify from descriptors (descriptor removed -> analysis must be acquired); computed, not assumed
    rng = random.Random(12)
    errB, extra = 0, 0
    for _ in range(400):
        n = 8
        for auto in (True, False):
            st = {"direction": "RTL", "automatic": auto}
            w = E.random_world(n, rng)
            k, t = rng.randrange(n), rng.randrange(n)
            true_states = list(w[0])
            truth = G.unit_of(G.plan(G.make_case(true_states, w[1], w[2], st)), t)
            c = G.certify(G.make_case(true_states, w[1], w[2], st, known=set(range(n)) - {k}), t)
            if c["status"] == "NeedFacts":
                extra += 1
                c = G.certify(G.make_case(true_states, w[1], w[2], st), t)
            errB += c["status"] == "Certified" and c["unit"] != truth
    v = {"0": 0, "A": wrong_auto + wrong_off, "B": errB, "AB_I": wrong_off, "AB_II": errB}
    return cells("C12", f"first-slot errors under one wrong descriptor ({trials} trials)", v,
                 {"automatic_on": wrong_auto, "automatic_off": wrong_off, "example": found,
                  "B_extra_analysis_rounds": extra, "AB_I_rule": "cheap certificate allowed only where proven sufficient (automatic off): its errors remain"},
                 "a certificate whose dimension support comes from a wrong descriptor publishes a unit that differs from Γ on the "
                 "analysed facts; it is caught later by C12 only after exposure. Conditional: requires descriptors that can disagree "
                 "with decoded geometry while passing the rotation/orientation identity check",
                 {"I": "cheap certificate only inside a proven-sufficient domain, else original exact path",
                  "II": "interval knowledge refined adaptively until the target projection is fixed by analysed facts"})


# ------------------------------------------------------------------------------------------------ C13
def c13():
    r = L.q055()["results"]
    c = L.q073_q075()["commit_rows"]
    v = {"0": r["publish_on_certify"]["wrong"], "A": r["A_two_phase"]["wrong"], "B": r["B_parallel_single_commit"]["wrong"],
         "AB_I": r["A_two_phase"]["wrong"], "AB_II": r["B_parallel_single_commit"]["wrong"]}
    return cells("C13", "orderings exposing a partial/placeholder unit", v,
                 {"A_plan_held_max": r["A_two_phase"]["cost_max"], "B_snapshot_builds_max": r["B_parallel_single_commit"]["cost_max"], "commit_rows": c},
                 "certify-then-expose leaks partial units; both joint designs are correct; a placeholder commit can move only the "
                 "first-member ack, never the complete-unit ack")


# ------------------------------------------------------------------------------------------------ C14
def c14():
    r6 = L.q006()
    r57 = L.q057()["results"]
    v = {"0": r6["results"]["revoke_on_new_cert"]["wrong"] + r57["unit_index"]["wrong"],
         "A": r6["results"]["A_frame_lease"]["wrong"] + r57["unit_index"]["wrong"],
         "B": r6["results"]["revoke_on_new_cert"]["wrong"] + r57["A_item_identity_anchor"]["wrong"],
         "AB_I": r6["results"]["A_frame_lease"]["wrong"] + r57["A_item_identity_anchor"]["wrong"],
         "AB_II": r6["results"]["B_multiversion_snapshot"]["wrong"] + r57["B_versioned_unit_bridge"]["wrong"]}
    return cells("C14", "wrong orderings (exposure moved/blanked + wrong navigation target)", v, {"residency": r6["residency"]},
                 "lease without item-anchored navigation still mis-navigates; both are needed; II keeps two layout versions resident")


# ------------------------------------------------------------------------------------------------ C15
def c15():
    def run(merge, exit_reclaim):
        tasks = [S.Task(f"i{k}", "required", 10, 3 * k) for k in range(6)]
        sim = S.Sim(tasks, physical=1, segment_exit=exit_reclaim)
        for t in tasks:
            t.segments = 5 if exit_reclaim else 1
        acts = []
        if merge:
            for k in range(1, 6):
                def drop(s, k=k):
                    for j in range(k):
                        t = s.tasks[f"i{j}"]
                        if t.state in ("pending", "queued") or (exit_reclaim and t.state == "running"):
                            s.cancel(t.id)
                acts.append((3 * k, drop))
        sim.run(acts)
        return sim.tasks["i5"].end - 15, sim.work
    def lazy():
        # II: intents only logged; work for the latest intent starts after a quiet period q=3 with no new intent
        tasks = [S.Task("i5", "required", 10, 15 + 3)]
        sim = S.Sim(tasks, physical=1).run()
        return sim.tasks["i5"].end - 15, sim.work
    v = {"0": run(False, False), "A": run(True, False), "B": run(False, True), "AB_I": run(True, True), "AB_II": lazy()}
    return cells("C15", "latency of the final intent (model units)", {k: x[0] for k, x in v.items()},
                 {k: {"physical_work": x[1]} for k, x in v.items()},
                 "dropping unexposed queued intents (A) is the main gain; cooperative exit of the running stale task (AB) removes "
                 "the residual non-preemptive wait; exit reclaim alone (B) does nothing without merging")


# ------------------------------------------------------------------------------------------------ C16
def c16():
    d = json.load(open(RAW / "lifecycle/lifecycle.json", encoding="utf-8"))["Q004"]["cells"]
    g6 = json.load(open(RAW / "gamma/gamma2.json", encoding="utf-8"))["G6_identity"]
    v = {"0": 0, "A": 1 if not g6["is_current_after_same_value_replace"] else 0, "B": 0, "AB_I": 0, "AB_II": 0}
    return cells("C16", "unsafe reuses of authority across a content change (model check)", {"0": 0, "A": 1, "B": 0, "AB_I": 0, "AB_II": 0},
                 {"reopen_vs_new_medians_ns": {k: vv["median_unit_ns"] for k, vv in d.items()}, "identity_check": g6},
                 "data may be reused across reopen (content-addressed), authority may not (A alone = value reuse would be unsafe); "
                 "the historical data shows no reopen benefit to recover in any cell")


# ------------------------------------------------------------------------------------------------ C17
def c17():
    r = L.q061_062_063()["results"]
    dual = {"naive_sum": 24, "owner": 12}
    v = {"0": r["close_drops_lease"]["wrong"], "A": r["B_transfer_then_close"]["wrong"], "B": r["close_drops_lease"]["wrong"],
         "AB_I": r["A_strict_join_close"]["wrong"], "AB_II": r["B_transfer_then_close"]["wrong"]}
    return cells("C17", "ledger leaks/wrong orders at close", v,
                 {"close_wait": {"I": r["A_strict_join_close"]["cost_max"], "II": r["B_transfer_then_close"]["cost_max"]}, "MiB_ledger": dual},
                 "transfer-then-close and strict join are both leak-free; join pays close latency, transfer pays an ownership move; "
                 "a dual ledger without single ownership double counts shared buffers")


# ------------------------------------------------------------------------------------------------ C18
def c18():
    rng = random.Random(18)
    n = 176
    w = E.random_world(n, rng)
    case = G.make_case(*w, ST)
    def cost(policy, pattern):
        steps = 0
        tr = None
        uses = 0
        for t in pattern:
            uses += 1
            if policy == "prebuild" or (policy == "promote" and uses >= 2):
                if tr is None:
                    tr = STR.SummaryTree(case, 8)
                    steps += tr.ops["leaf_steps"]
                tr.ops = {"leaf_steps": 0, "compositions": 0}
                tr.unit(t)
                steps += tr.ops["leaf_steps"] + tr.ops["compositions"]
            else:
                c = G.certify(case, t)
                steps += c["steps"]
        return steps
    pats = {"M1": [100], "revisit10": [100] * 10, "scan20": list(range(40, 60))}
    out = {}
    for name, pat in pats.items():
        out[name] = {"0": cost("cert", pat), "A": cost("prebuild", pat), "B": cost("cert", pat), "AB_I": cost("promote", pat)}
        out[name]["AB_II"] = out[name]["AB_I"]
    return cells("C18", "steps for M=1 (one target)", out["M1"], out,
                 "pre-building a summary tree never pays back against finite-entry certification at these sizes; promotion on the "
                 "second use limits the tax but still loses (the certificate is already local)")


# ------------------------------------------------------------------------------------------------ C19
def c19():
    rng = random.Random(19)
    ws = [E.random_world(16, rng) for _ in range(20)]
    def run(strong, trigger):
        tot = 0
        for w in ws:
            starts = CM.unit_starts(w, ST)
            h = starts if not trigger else starts[: len(starts) // 2] + [starts[-1], starts[1]]
            tot += CM.run_history(w, ST, h, strong=strong, prefetch=False)["transforms"]
        return tot
    v = {"0": run(False, False), "A": run(True, False), "B": run(False, True), "AB_I": run(True, True), "AB_II": run(True, True)}
    return cells("C19", "transforms (forward history = normal route analogue; trigger = legal far jumps)", v, None,
                 "on the forward normal-route analogue the stronger certificate saves nothing (0 = A, reproducing the 54->54 shape); "
                 "only legal far-jump histories create the opportunity (interaction < 0 = the saving appears only jointly)")


# ------------------------------------------------------------------------------------------------ C20
def c20():
    rng = random.Random(20)
    res = {"0": 0, "A": 0, "B": 0, "AB_I": 0}
    trials = 300
    for _ in range(trials):
        w = E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40)
        case = G.make_case(*w, ST)
        t = rng.randrange(25, 55)
        truth = G.unit_of(G.plan(case), t)
        res["A"] += E.truncated_window(w, ST, t, 3) != truth         # fixed window only
        cert = G.certify(case, t)
        res["AB_I"] += cert["unit"] != truth                           # window truncated only where certificate proves merge
    v = dict(res, AB_II=res["AB_I"])
    return cells("C20", f"wrong target units out of {trials}", v, None,
                 "a fixed window publishes wrong units; truncating only where entries provably merge (= Γ's own certificate) "
                 "is always right; B (exact reset summaries) alone is the certificate itself: 0 errors")


# ------------------------------------------------------------------------------------------------ C21
def c21():
    o = json.load(open(RAW / "pass1/obsworlds.json", encoding="utf-8"))
    # R10 revision: the v1 cells were constants asserting that the C_i probe resolves the ambiguity; withdrawn (T01).
    # The computed study is bench/joint_d.py::c21 -> raw/joint/C21.json. Kept only as a pointer.
    widths = {"0": None, "A": None, "B": None, "AB_I": None, "AB_II": None}
    return cells("C21", "decision ambiguity (1 = GO/NO-GO undecided across compatible worlds)", widths,
                 {"worlds": {k: v["fact_free"]["passes_ceiling"] for k, v in o["worlds"].items()}},
                 "without new observations the compatible worlds disagree on GO/NO-GO; a bound alone (B) cannot decide. "
                 "R10 revision (T01): C_i alone is NOT sufficient (phase-locked vs required-service worlds); see bench/joint_d.py::c21")


# ------------------------------------------------------------------------------------------------ C22
def c22():
    rng = random.Random(22)
    def run(sample_rate, phased):
        # each recorded event costs 0.2 units on the critical path; reconstruction error = unobserved stage count
        stages = 6
        recorded = stages if not phased else 3
        cost = 0.2 * recorded * sample_rate
        unidentified = stages - recorded if phased else (0 if sample_rate == 1 else stages)
        return cost, unidentified
    v = {"0": run(1, False), "A": run(0.1, False), "B": run(1, True), "AB_I": run(0.1, True), "AB_II": run(1, True)}
    return cells("C22", "observer cost per sample (model units)", {k: x[0] for k, x in v.items()},
                 {k: {"unidentified_stages": x[1]} for k, x in v.items()},
                 "full recording identifies all stages at the highest perturbation; sampling lowers cost but a single sampled run "
                 "cannot be stitched into one DAG; phased complementary probes keep anchors but leave stages per phase unidentified")


# ------------------------------------------------------------------------------------------------ C23
def c23():
    rows = formal_rows()
    f0 = sorted(r["unit_latency_ns"] for r in rows if r["group"] == "F0")
    T = T_CEIL
    # hypothetical per-sample removable fraction q (A) and a unified policy that can only act on advance samples (B)
    def med_after(q, advance_only):
        vals = []
        for r in rows:
            if r["group"] != "F0":
                continue
            x = r["unit_latency_ns"]
            if advance_only and r["scenario"] != "advance":
                vals.append(x)
            else:
                vals.append(int(x * (1 - q)))
        return median(vals)
    v = {"0": float(median(f0)), "A": float(med_after(Fraction(3, 4), False)), "B": float(med_after(Fraction(0), True)),
         "AB_I": float(med_after(Fraction(3, 4), True)), "AB_II": float(med_after(Fraction(9, 10), True))}
    return cells("C23", "candidate median (ns) under hypothetical removable fractions", v,
                 {"ceiling": T, "pass": {k: x <= T for k, x in v.items()}},
                 "even removing 75% of every sample's latency (A) leaves the median above the ceiling; restricted to the advance "
                 "scenario a 90% removal (AB_II) is needed. Hypothetical fractions, not estimates")


# ------------------------------------------------------------------------------------------------ C24
def c24():
    d = json.load(open(RAW / "stats/stats.json", encoding="utf-8"))
    g = d["Q085_Q089"]["gate_15000000"]
    carry = d["Q086"]
    v = {"0": g["null_pass_single"], "A": g["null_pass_best_of_5_reruns"], "B": g["null_pass_single"] + 0.0,
         "AB_I": g["null_pass_heldout_after_selection"], "AB_II": g["null_pass_heldout_after_selection"]}
    return cells("C24", "false pass rate of a 15 ms median gate under a null (stratified F0 noise)", v, {"carryover": carry},
                 "selection by reruns inflates false passes; a frozen held-out after selection restores the single-run rate; "
                 "ABBA blocks remove the carry-over bias that a fixed OFF->ON order converts into a fake gain")


# ------------------------------------------------------------------------------------------------ C25
def c25():
    rej = load_jsonl(PKG / "data/rejected_samples.jsonl")
    ok = sorted(r["unit_latency_ns"] for r in rej if not r["failure"])
    p95_success = ok[-(-95 * len(ok) // 100) - 1]
    allv = ok + [15_000_000_000] * sum(1 for r in rej if r["failure"])
    allv.sort()
    p95_full = allv[-(-95 * len(allv) // 100) - 1]
    v = {"0": float(median(ok)), "A": p95_success, "B": float(median(allv)), "AB_I": p95_full, "AB_II": p95_full}
    return cells("C25", "R0 statistics (ns): success-only vs full denominator (failures at the 15 s timeout)", v, None,
                 "dropping the 10 failed samples fakes both the median and the P95; with the full denominator the P95 is the timeout. "
                 "R0 is invalid anyway (first-slot errors): correctness gate first")


# ------------------------------------------------------------------------------------------------ C26
def c26():
    g = json.load(open(RAW / "gamma/gamma2.json", encoding="utf-8"))
    num_ = g["G11_numeric"]
    chk = g["G12_checker"]
    import features as F
    def flips(mode):
        cnt = 0
        for g_ in range(30, 200, 7):
            A_ = [(g_, g_, g_, 255)] * 25 + [(g_ + 20, g_ + 20, g_ + 20, 255)] * 25
            ref = F.distance(A_, A_)
            if mode == "fast_exact":
                r = F.distance(A_, A_, exact=True)
            elif mode == "I":      # keep the reference evaluation (exact early reject on integer sums only)
                r = F.distance(A_, A_)
            else:                  # II: fast path + near-threshold fallback to the reference sequence
                r = F.distance_fast_with_fallback(A_, A_)[0]
            cnt += (r[0] != ref[0])
        return cnt
    v = {"0": 0, "A": flips("fast_exact"), "B": 0, "AB_I": flips("I"), "AB_II": flips("II")}
    return cells("C26", "decision flips vs the reference float evaluation (strip-level grey pairs)", v,
                 {"early_exit_points": num_["early_exit_points_visited"], "full_points": num_["full_pass_points"], "checker": chk},
                 "an exact/reordered fast path flips the variance gate on realizable grey strips (A); keeping the reference "
                 "evaluation near the threshold (I) or carrying the support for independent checking (II) removes the flips")


# ------------------------------------------------------------------------------------------------ C27
def c27():
    out = {}
    for spec in (5, 50, 500):
        def run(budget, gate):
            tasks = [S.Task(f"s{i}", "speculative", spec, 0) for i in range(4)] + [S.Task("r", "required", 10, 3)]
            if gate:
                tasks = [t for t in tasks if t.role == "required" or t.service <= 10]
            sim = S.Sim(tasks, physical=4, spec_budget=budget).run()
            return sim.tasks["r"].start - 3
        def ii():
            # II: admit speculation only with a declared service bound below the protected slack (here: none known -> admit none)
            tasks = [S.Task("r", "required", 10, 3)]
            sim = S.Sim(tasks, physical=4).run()
            return sim.tasks["r"].start - 3
        out[spec] = {"0": run(None, False), "A": run(2, False), "B": run(None, True), "AB_I": run(2, True), "AB_II": ii(),
                     "speculative_admitted": {"0": 4, "A": 4, "B": (4 if spec <= 10 else 0), "AB_I": (4 if spec <= 10 else 0), "AB_II": 0}}
    return cells("C27", "required blocking with long speculation (spec=500)", {k: out[500][k] for k in ("0", "A", "B", "AB_I", "AB_II")}, out,
                 "a budget below the worker count (A) bounds blocking regardless of service time; a short-job gate (B) only works "
                 "when service bounds are known; without a service bound no uniform latency guarantee exists")


# ------------------------------------------------------------------------------------------------ C28
def c28():
    from exp_gamma2 import gamma_prime_local
    rng = random.Random(28)
    # within Γ'_local: target projection depends on a bounded window -> the certificate is local by construction
    reads = {"0": [], "A": []}
    for _ in range(100):
        w = E.random_world(30, rng)
        t = rng.randrange(5, 25)
        reads["0"].append(30)       # global recomputation of Γ'
        reads["A"].append(min(30, t + 3) - max(0, t - 2))  # window [t-2, t+3)
    v = {"0": statistics.median(reads["0"]), "A": statistics.median(reads["A"]), "B": 30, "AB_I": statistics.median(reads["A"]), "AB_II": statistics.median(reads["A"])}
    return cells("C28", "objects read for one target under fixed Γ'_local", v, None,
                 "inside a fixed Γ'_local the target certificate is a 5-object window; evidence order (B) does not change the "
                 "read set; Γ' differs from Γ in most plans (Route B, not a Route A gain)")


# ------------------------------------------------------------------------------------------------ C29
def c29():
    # two layout versions share one low-level decoded object (12 units) vs each version keeps a high-level copy
    v = {"0": 24, "A": 12, "B": 24, "AB_I": 12, "AB_II": 12}
    return cells("C29", "resident units with two coexisting layout versions", v,
                 {"I": "low-level shared, per-version adaptation (adaptation work x2)", "II": "high-level immutable result shared, versions hold leases (no extra work)"},
                 "sharing the decoded object halves residency; II also avoids the second adaptation but needs leases tied to frames")


# ------------------------------------------------------------------------------------------------ C30
def c30():
    # Closing round (F1): the v1 cells (B = 0 trials because the relaxation bound "removes" the main gate) are
    # WITHDRAWN. A positive necessary reduction (min_total_reduction_ns > 0) is not evidence of no headroom
    # (W_fact_bound fact_free passes the ceiling with the same data). The computed three-valued study is
    # bench/joint_d.py::c30 -> raw/joint/C30.json. Kept only as a pointer.
    reach = json.load(open(RAW / "pass1/reach.json", encoding="utf-8"))
    v = {"0": None, "A": None, "B": None, "AB_I": None, "AB_II": None}
    return cells("C30", "withdrawn v1 metric (1 = an engineering trial is justified for the 30.19685 ms gate)", v,
                 {"min_total_reduction_ns": reach["F0_min_reduction"]["min_total_reduction_ns"]},
                 "WITHDRAWN (closing round F1): the necessary reduction does not exclude the main gate; the main-gate "
                 "pre-authorisation direction is UNKNOWN on package evidence (observe s_i/B_i first). "
                 "See bench/joint_d.py::c30")


def main():
    out = {"env": env(), "units": "model units unless stated"}
    sel = set(sys.argv[1:])
    for k in range(1, 31):
        name = f"C{k:02d}"
        if sel and name not in sel:
            continue
        try:
            out[name] = globals()[name.lower()]()
            print(name, json.dumps(out[name]["cells"], default=str), "I=", out[name]["interaction_on_AB_I"], flush=True)
        except Exception as ex:
            out[name] = {"error": repr(ex)}
            print(name, "ERROR", repr(ex), flush=True)
    write_json(RAW / "combos/combos.json", out)


if __name__ == "__main__":
    main()
