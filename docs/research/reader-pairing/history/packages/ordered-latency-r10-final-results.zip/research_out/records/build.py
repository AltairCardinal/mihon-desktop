"""Render the per-question records into: coverage.csv (template columns, 150 rows), coverage_detail.csv,
sections/QUESTIONS_DETAIL.md, sections/COMBINATIONS_DETAIL.md, summary/coverage_counts.json.
Usage: python3 -B research_out/records/build.py
"""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
PKG = OUT.parent
sys.path.insert(0, str(HERE))
from rec_f01_f05 import R as R1
from rec_f06_f10 import R as R2
from rec_f11_f15 import R as R3
from rec_f16_f20 import R as R4
from rec_joint import R as RC
from patches import P as PATCHES
from revision import R as REVISION, WITHDRAWN

STATUS = {"not_started", "incomplete", "completed"}
DECISION = {"engineering_trial", "probe_first", "conditional_theory", "stop", "unresolved"}


def short_mech(s):
    s = s.strip()
    for pre in ("A：", "B：", "A:", "B:"):        # 'A：<mechanism>' -> '<mechanism>'
        if s.startswith(pre):
            s = s[len(pre):]
    return s.split("：")[0].split(":")[0].strip()[:60]


PLACEHOLDER = ("无。", "无", "见上。", "见上", "见数值。", "见表。", "见缺口关闭。", "见四格", "见原始记录costs字段", "0格")


def main():
    recs = {r["id"]: r for r in R1 + R2 + R3 + R4 + RC}
    for k, v in PATCHES.items():
        if k.startswith("Q"):          # v1 combination patches are superseded by rec_joint (R10 revision)
            recs[k].update(v)
    for r in recs.values():            # withdrawn wording (INPUT_ERRATA E1/E2) is replaced in the OLD texts only;
        for f, val in list(r.items()):  # revision texts quote withdrawn claims deliberately and are applied afterwards
            if isinstance(val, str):
                for old, new in WITHDRAWN:
                    val = val.replace(old, new)
                r[f] = val
    for k, v in REVISION.items():
        recs[k].update(v)
    for r in RC:                       # combination domain = the inputs actually run
        if not r.get("domain"):
            j = json.load(open(OUT / f"raw/joint/{r['id']}.json", encoding="utf-8"))
            r["domain"] = "输入：" + "、".join(j["inputs"])
    template = list(csv.DictReader(open(PKG / "coverage-template.csv", encoding="utf-8")))
    assert len(template) == 150
    missing = [t["id"] for t in template if t["id"] not in recs]
    extra = [k for k in recs if k not in {t["id"] for t in template}]
    assert not extra, extra
    for r in recs.values():
        assert r["status"] in STATUS and r["decision"] in DECISION, r["id"]
        if r["status"] == "completed":
            # T05: every completed record needs all fields, either concrete or '不适用：<reason>'
            for k in ("domain", "A", "B", "new", "disc", "pos", "deg", "cex",
                      "cost", "fail", "obs"):
                v = (r.get(k) or "").strip()
                assert v and v not in ("—", "-") and v not in PLACEHOLDER and v != "不适用：", (r["id"], k, v)
                assert len(v) >= 4 or k in ("A", "B"), (r["id"], k, "too short to be evidence", v)
                assert not (v.startswith("见") and len(v) <= 12), (r["id"], k, "pure cross-reference placeholder", v)
    rows, detail = [], []
    for t in template:
        r = recs.get(t["id"])
        if r is None:
            rows.append(t)
            continue
        row = dict(t)
        row["status"] = r["status"]
        row["route_a"] = short_mech(r["A"])
        row["route_b"] = short_mech(r["B"])
        row["evidence"] = r["disc"]
        row["decision"] = r["decision"]
        lim = r.get("limit", "")
        lim = "" if lim.strip() in ("—", "-") else lim
        row["limit"] = (r.get("level", "") + "；" + lim).strip("；")
        rows.append(row)
        detail.append({**row, "new_conclusion": r["new"], "positive": r.get("pos", ""), "degenerate": r.get("deg", ""),
                       "min_counterexample": r.get("cex", ""), "cost": r.get("cost", ""), "failure_boundary": r.get("fail", ""),
                       "needed_observation": r.get("obs", ""), "resume": r.get("resume", "")})
    with open(OUT / "coverage.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(template[0].keys()), quoting=csv.QUOTE_ALL)
        w.writeheader()
        w.writerows(rows)
    with open(OUT / "coverage_detail.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(detail[0].keys()), quoting=csv.QUOTE_ALL)
        w.writeheader()
        w.writerows(detail)
    counts = {}
    for typ in ("primary", "combination"):
        sub = [r for r in rows if r["type"] == typ]
        counts[typ] = {"rows": len(sub), **{s: sum(r["status"] == s for r in sub) for s in sorted(STATUS)},
                       "decision": {d: sum(r["decision"] == d for r in sub) for d in sorted(DECISION)}}
    counts["missing_records"] = missing
    (OUT / "summary").mkdir(exist_ok=True)
    (OUT / "summary/coverage_counts.json").write_text(json.dumps(counts, ensure_ascii=False, indent=1), encoding="utf-8")

    qi = json.load(open(OUT / "summary/questions_index.json", encoding="utf-8"))
    fam = {}
    for t in template:
        if t["type"] == "primary":
            fam.setdefault(t["family"], []).append(t["id"])
    lines = ["# 逐题详细记录（120主课题）", "",
             "每题：域、两条机制路线、新增结论、可执行判别/推导（代码→原始结果）、正例/退化例/最小反例、成本、失败边界、所需新增观测、裁定。",
             "证据等级与适用域见每题末行。状态与裁定与 `coverage.csv` 一致（由同一记录生成）。", ""]
    for f_, ids in fam.items():
        lines.append(f"## {f_}")
        lines.append("")
        for q in ids:
            r = recs[q]
            lines += [f"### {q} {qi[q]['title']}", "",
                      f"- 状态/裁定：**{r['status']} / {r['decision']}**",
                      f"- 域：{r['domain']}",
                      f"- 路线A：{r['A']}",
                      f"- 路线B：{r['B']}",
                      f"- 新增结论：{r['new']}",
                      f"- 判别（代码→原始结果）：`{r['disc']}`",
                      f"- 正例：{r['pos']}；退化例：{r['deg']}；最小反例：{r['cex']}",
                      f"- 成本：{r['cost']}；失败边界：{r['fail']}",
                      f"- 所需新增观测：{r['obs']}",
                      f"- 证据等级/适用域：{r.get('level','')}；{r.get('limit','')}"]
            if r.get("resume"):
                lines.append(f"- 未完成，恢复：{r['resume']}")
            lines.append("")
    (OUT / "sections").mkdir(exist_ok=True)
    (OUT / "sections/QUESTIONS_DETAIL.md").write_text("\n".join(lines), encoding="utf-8")

    cl = ["# 30个耦合课题：两种联合设计，各自0/A/B/AB消融（R10修订）", "",
          "每个组合有两种机制不同的联合设计I、II；每个设计拆成自己的两个组件A_d、B_d，在同一输入、oracle、资源与账本上",
          "运行0 / A_d / B_d / AB_d四格（0格共享）。交互项 I_d = f(AB_d) − f(A_d) − f(B_d) + f(0)。数值全部来自",
          "`raw/joint/Cxx.json`（由 `bench/exp_joint.py` 运行模型得到，不拼表）。v1的四格研究保留在 `raw/combos/combos.json` 作历史。", ""]
    for r in RC:
        j = json.load(open(OUT / f"raw/joint/{r['id']}.json", encoding="utf-8"))
        cl += [f"## {r['id']} {r['title']}", "",
               f"- 状态/裁定：**{r['status']} / {r['decision']}**；证据：{r['level']}（{r['limit']}）",
               f"- 干预：{r['A']}", f"- 联合设计：{r['B']}",
               f"- 设计I：{j['designs']['I']}", f"- 设计II：{j['designs']['II']}",
               f"- 机制差异：{j['mechanism_difference']}",
               f"- 标量f：{j['metric']}（{'越低越好' if j['better'] == 'lower' else '越高越好'}）", "",
               "| 输入 | 0 | A_I | B_I | AB_I | A_II | B_II | AB_II | 交互I | 交互II |", "|---|---|---|---|---|---|---|---|---|---|"]
        for name, v in j["inputs"].items():
            c = v["cells"]
            cl.append(f"| {name} | " + " | ".join(str(c[k]["m"]) for k in ("0", "A_I", "B_I", "AB_I", "A_II", "B_II", "AB_II")) +
                      f" | {v['interaction']['I']} | {v['interaction']['II']} |")
        cl.append("")
        if j["distinguishing_inputs"]:
            cl.append("- 区分AB_I与AB_II的输入：" + "；".join(
                f"{k}: " + ", ".join(f"{m}={d['AB_I']}/{d['AB_II']}" for m, d in v.items()) for k, v in j["distinguishing_inputs"].items()))
        else:
            cl.append("- 没有任何输入区分AB_I与AB_II：两设计在本模型中如实合并。")
        if j.get("oracle_failures"):
            cl.append(f"- 违反正确性oracle的格（这些格的标量不可比）：{j['oracle_failures']}")
        cl += [f"- 结论：{r['new']}", f"- 正例：{r['pos']}；退化例：{r['deg']}；最小反例：{r['cex']}",
               f"- 成本：{r['cost']}；失败边界：{r['fail']}；所需观测：{r['obs']}",
               f"- 代码/原始：`{r['disc']}`", ""]
    (OUT / "sections/COMBINATIONS_DETAIL.md").write_text("\n".join(cl), encoding="utf-8")
    print(json.dumps(counts, ensure_ascii=False))


if __name__ == "__main__":
    main()
