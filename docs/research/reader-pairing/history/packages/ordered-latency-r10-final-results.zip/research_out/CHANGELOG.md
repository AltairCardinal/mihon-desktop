# CHANGELOG：R10 一次性修订（2026-10-27）

输入只用原始匿名 R10 研究包与上次返回包。原包 38 个文件未改（`check_integrity.py --verify` 退出码 0）。
每行：旧问题 → 修改 → 复验（可执行证据） → 结论是否变化。验收矩阵见 `ACCEPTANCE.md`。

## T01 授权时刻判据

| 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|
| “补 C_i，若 median(U_i−C_i)>T，则只缩短授权前工作的机制一律不可能” | 撤回为一般命题。实现反例：世界 P（消费只在 4 ms 或 130.19685 ms 的机会发生；C=5→U=130.19685；C→3→U=4）与世界 S（同 C、U，授权后有 125.19685 ms 不可移除服务） | `lab/obsworlds.py::t01_counterexample/t01_check` → `raw/pass1/obsworlds.json#T01`；`tests/test_revision.py::T01`（4 项） | **是**：旧规则 50 条 U−C 中位 125.19685>T 判 NO-GO，P 中候选中位 4 ms 过门槛；S 中同样干预不过 |
| 加 C_i 后仍不可识别什么没有说 | 写明：U_i−C_i 中“必需服务”与“等待机会/排队”的划分不可识别；分离观测 = B_i（授权后服务开始）或机会时刻表 | 同上 `still_unidentified_with_C_i`、`separating_observation` | 新增 |
| 测得等待与必需服务下界混用 | 修订充分 NO-GO：median_i(s_i)>T，s_i = 已确立的授权后不可移除服务下界；旧规则只在尾部不变性 TI 下有效，并给出 TI 成立条件与检验（受控授权延迟 δ、按机会周期取模的相关） | `revised_rule` 在 P、S 两世界上与真实结果一致（`test_revised_rule_not_refuted_by_either_world`）；`test_revised_rule_monotone_bound` 只验证支撑引理（L'_i≥s_i ⇒ 中位单调），不是规则本身的证明 | 收紧 |
| “全部相容分解”的区间路线未声明模型类 | 区间路线只在模型类 M_TI 内成立（代码与记录都标注） | `interval_route` 输出 `model_class: M_TI only` | 收紧 |
| H2（伙伴）、H3（跳转）写成“无条件不可能” | 改为在冻结前提下：H2 = 首成员 ack 不变；H3 = 推进样本不变 | 记录 Q095、报告 §1 | 收紧 |
| 同步 | Q007、Q010、Q023、Q090、Q095、Q096、C21、C30、报告、`exp_misc` 自适应计划、`exp_combos` 的 C21/C30 文字 | `records/revision.py`；`build.py` 全局替换撤回措辞 | — |

## T02 N0 / R0 / 23 个支持对象 / 摘要树措辞

| 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|
| N0 `proof_work=0` 被读成“全部证明工作为 0” | `proof_work` 只计额外强证明（strongWork）；字段改名 `strong_proof_work_*`，普通认证工作 = UNKNOWN | `lab/n0_structure.py` → `raw/pass1/n0_structure.json`；`INPUT_ERRATA.md` E1 | **是**：撤回“窗口内证明工作 0” |
| 成员已物化 ≠ unit 已授权；N0 没有 C_i | 字段 `authorisation_time_C: UNKNOWN`；撤回“H1 被真实路线验证”“N0 是 H1 同类实例” | 同上；E2 | **是** |
| R0 归因为“固定窗口截断” | 已知原因：canonical 与完整认证正确，发布/历史层在 Certified 之前锁定猜测。R0 错误保留为失败证据，固定窗口归因撤回；固定窗口不精确只靠抽象构造（链族、300 目标错误计数） | `lab/reach.py` 注释与输出；E3；记录 Q094、Q011 | **是**（归因） |
| “23 个支持对象 → 至少 6 轮” | 23 个支持对象 ≠ 23 个未知任务；“至少 ⌈m_miss/4⌉ 轮”需要 m_miss、任务粒度、轮次定义三个前提；4 路并发 ≠ 每轮 4 个事实 | E4；记录 Q091；报告 §2 | **是**（降为条件陈述） |
| “摘要树任何规模都不胜出” | 改为已测实现/规模/负载（Python、叶 8、检查点间隔 16、n=48/176/1024、20 查询或 20 翻转+查询、完整知识、3 进程） | E5；记录 Q088、Q099 | 收紧 |

## T03 预取上界

| 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|
| `Nav.go` 把下一对象下标与 `len(plan)`（unit 数）比较 | 改为对象数 `self.K.n` | 先写失败测试：`tests/test_regressions.py::PrefetchBound`（4 项：题给例 4×SHAPE_X、自动关、计划 [0],[1,2],[3]，go(1) 须预取 3；向后/尾部；unit 数≪对象数；混合 unit 大小）。`raw/regressions/before_fix.txt`（最终 13 项测试文件对 v1 代码）中其中 3 项 FAIL（向后/尾部一项在 v1 上恰好通过），修复后 `after_fix.txt` 全部通过 | — |
| 受影响实验（prefetch=True） | 重算 `exp_cache`、`exp_workloads`；逐项对照见 `raw/regressions/t03_cache_before_after.txt` | 7/16 与 64/64 的前进/往返：0 收益，**不变**；3/6 预取开 LRU：省 9 → **0**（总数 719/710 → 649/649）；距离：省 16 不变（总数 1312→1449）；远跳：总数 +2..+4，节省不变；最短正收益历史：每条省 1–4 → **1–5**（[10,0,8] 4→5，[14,12] 2→1，[3,10,4] 3→1）；W20 分支证书 3/6 预取开 LRU 9→0 | Q043、Q047、Q054、Q072、Q120/W20 数字改；**定性结论不变**（冻结容量下 0 收益；机会在跳转首访） |
| prefetch=False 的结果 | 未作废：C07、C19 在 `exp_combos` 与新联合研究中都显式 `prefetch=False`；`raw/combos/combos.json` 重算后与修复前逐项相同 | `bench/compare_runs.py` 等价比较：combos、sched 完全相同 | 不变 |

## T04 结果邮箱/结果池

| 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|
| 容量 1 的邮箱装了 4 个结果 | `lab/sched.py`：池满时结果 HELD 在工人上，保留工人、逻辑槽与结果内存；区分物理工人、逻辑准入槽、结果占用；消费/关闭/取消/晚完成/异常（新增 `failed`）各释放一次；常驻按共享对象去重；每事件不变量检查 | 失败测试先行 `MailboxCapacity`（4 项；在 v1 上只有 `test_capacity_one_simultaneous_completion` 是行为失败（峰值 4>1），另 3 项因 v1 缺少新 API 而报错）；`MailboxFuzz`：600 个随机交错（完成、接纳、取消、失败、关闭、晚退出、三种池策略、丢弃策略）0 违例、0 双重释放、关闭后 0 残留、字节 0 未结；`MailboxMutants`（已提交）：池永不满、关闭重复释放、HELD 不占工人三种变异都被抓住；`ResidencyDedupe`：共享对象只计一次（key=id 的变异被抓住） | — |
| Q028/C05 的 “40→10” 是独立算术 | 在可执行调度器上重建（`bench/exp_mailbox.py`，`exp_sched.s10_mailbox` 改为调用同一模型） | `raw/sched/mailbox.json`；池容量扫描：独立结果先完成时容量 0/1/2 都等到 40，≥3 才 10 | **数字改**：所需池容量取决于停顿中完成的结果数 |
| C05 两种联合设计只是池容量 2 与 4 | I = 腾出位置先给完整 unit 成员 + 只合并独立结果；II = 为完整 unit 预留位置 + 截止拆批；两设计同一容量 3 | `raw/joint/C05.json`：容量 3 时完整 ack 与必需开始相同，区别在独立提交与 HELD 工人时间；容量 2 时 II 让必需任务等到 56（I 为 40） | 新增区分证据 |
| mailbox=None 的实验 | 未变 | `raw/sched/sched.json` 除 S10 外与修复前逐项相同 | 不变 |

## T05 记录字段

| 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|
| 117 个完成记录中成本 41、失败边界 71、所需观测 59 个为“—” | 逐项填写；不适用的写“不适用：具体原因”；优先项 Q027/Q030（成本）、Q029/Q068/Q110（失败边界）、Q029/Q030/Q068/Q110/Q116（观测）都已填 | `records/revision.py::F5`；`build.py` 现在拒绝任何完成记录的 域/路线/结论/判别/正例/退化例/反例/成本/失败边界/观测 为空或“—” | 无降级（复核后没有证据不足的完成项需要降级；见 ACCEPTANCE） |

## T06 未完成项

| 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|
| Q053 路线 B 未实现 | `gamma.certify(prune=True)`：局部后向可达性剪除 C08 入口，用到的已知事实进入支持；`lab/entry_witness.py` 信息边界见证搜索 | `raw/gamma/q053.json`：300 世界 0 不可靠、32 个提前出证、回溯总和 491→459；部分知识 991 次出证 0 不可靠；剪枝后 459 个回溯位置全部有见证对 | 完成；裁定 conditional_theory |
| Q119 没有可执行门控实验 | `bench/exp_q119.py`：进入/退出域、注入故障、关闭、shadow / 域门控 / 先 shadow 后门控 | `raw/gamma/q119.json` | 完成；裁定 probe_first |
| Q012/C22 | 合成服务模型上的观测等价世界、探针选择、开销、失效语义；真实运行 NOT_RUN | `raw/joint/C22.json` | 完成（模型层）；真实观察器 NOT_RUN |
| 19 个组合只有四格或参数变体 | 全部 30 个组合按新协议重做：两种机制不同的设计，各自 0/A/B/AB，同一输入/oracle/资源/账本，交互项与区分输入由脚本产生 | `bench/joint_core.py` + `joint_a/b/c/d.py` → `raw/joint/C01..C30.json`；30/30 有区分输入 | 状态 19 个 incomplete → completed；裁定变化：C09 stop→conditional_theory，C22 unresolved→probe_first，C26 engineering_trial→conditional_theory，C27 engineering_trial→probe_first |

## T07 完整性检查

| 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|
| Windows 路径：以系统分隔符比较，Windows 上所有文件都会“未登记” | 统一为包相对 POSIX 路径；拒绝绝对路径与 `..`；哈希/长度不符、缺失、未登记都使退出码为 1；新增 `--verify` 模式校验研究输出清单 | `tests/test_revision.py::Integrity`（11 项负例/路径规则/在包副本上篡改一个字节后退出码 1） | 路径规则单元测试在 Linux 上运行；**原生 Windows 未运行**（没有 Windows 主机） |
| 20 000 例差分依赖 R9_REFERENCE | 标为历史证据；无参照时写 `xcheck_r9_status.json` = NOT_RUN 且保留历史结果；新增自带中性检查 `lab/gamma_ref2.py`（不导入 gamma.py，AST 检查）+ 5 个手算黄金例（1 个自动开启）+ 2000 例差分 | `tests/test_revision.py::NeutralPlanChecker`；差分 0 不一致 | 收紧（证据等级） |

## T08 干净复现

见 `REPRODUCE.md` 与 `summary/clean_run.json`（独立目录全量重跑、PASS/FAIL/SKIP/NOT_RUN 分列）。

## 自查发现（本轮新增）

| 编号 | 问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|---|
| SF-1 | Q049/Q101 “剩余 8 个缺口来自 C08 入口过近似” | 复核：oracle Ω 的分数域 {None,1,2} 比分支证书使用的可实现分数域窄；在可实现域中这 8 个目标 π_t 不唯一，不是缺口 | `exp_certificates.py` 新分类 `remaining_oracle_domain_narrower=8, remaining_true_gap=0` | **是**：撤回该归因 |
| SF-2 | `omega.proj_table` 以 `id(dom)` 为缓存键；释放的 Domain 的 id 可被新 Domain 复用，读到别的设置的投影表 | 改为稳定签名 `dom_signature` | 首次复现时正好碰撞（n=6 第 4 域 unsound 2648）；修复后重跑与上一版逐项相同（上一版未受影响） | 不变（潜在缺陷） |
| SF-3 | 新增事实存储上限时的活锁 | `cachemodel` 加活锁守卫；C07 记录容量 20 时 4/60 条历史活锁 | `raw/joint/C07.json#notes` | 新增失败边界 |
| SF-4 | `exp_combos` 的 C21/C30 文字仍重复被撤回的说法，C21 的格子是写死的常量（声称 C_i 探针即可裁定） | 文字改正；C21 格子改为 None（撤回），计算版本在 `raw/joint/C21.json` | 干净重跑后 `raw/combos/combos.json` 重新生成（见 clean_run） | — |
| SF-5 | `summary/WORKLOADS.md` W09 仍写 5/12（上一轮只改了记录） | 改为 5/8 | — | — |
| SF-6 | v1 的组合记录允许成本/失败/观测为“—” | 组合记录改由 `records/rec_joint.py` 生成并受同一严格检查 | `build.py` | — |
| SF-7 | `exp_sched.S10` 与 `exp_workloads` W10 指向算术版本 | 指向可执行模型 | `raw/sched/sched.json#S10_mailbox` | 数字改（r_start 50/10/10） |

## 独立验收后的改正（第二轮）

只读验收代理（结果见 `ACCEPTANCE.md`）发现的问题与处理：

| 问题 | 处理 |
|---|---|
| 三个原始文件仍是 v1 输出、含已撤回说法（misc Q010 自适应计划、combos C21 判词、sched S10 算术）；多份源码改动晚于其原始输出 | 全部原始结果在独立目录干净重跑后整体替换（`summary/clean_run.json`），不再有“源码新于输出”的文件 |
| `ACCEPTANCE.md` 与干净重跑记录被引用但不存在 | 已生成 |
| SF-1 撤回的归因仍在 Q049 失败边界、Q101 反例中；自动域可靠性只在窄分数域检验 | 两处改正；`exp_certificates` 新增第 6 域：可实现分数格点 {None,0,1,2,3} 上的 n=3 可靠性复核 |
| obsworlds 文档串、注释与 JSON 键仍按“一项 C_i 即可裁定”命名；Q010 引用的计算没有 B_i；v1 c21 写死“C_i 探针即裁定” | 文档串/注释改写；键改名 `route_A_interval_model_class_M_TI`；Q010 改引 `raw/joint/C21.json`，misc q010 标明只覆盖 v1 三世界；v1 c21 格子撤回 |
| 全局撤回替换误伤 Q095、Q090 的撤回句 | 替换只作用于旧文本，修订文本在其后应用 |
| Q091 正例“m=23：下界6轮”无条件 | 改为条件陈述 |
| C22 抽样随调用顺序变化造成伪交互、识别数写死；Q012 声称的观测等价世界未实现 | 固定种子按设计抽样；识别数由数据计算；观测等价世界与阈值扫描已计算（每帧事件数 ≤4 时等价） |
| C23 的 A_II 在 Q093 输入上实际调用了设计 I | 改正；A_II 在 Q093 上不可行（None） |
| C21 推界组件从不触发 | 新增混合 U 世界族：先推界跳过已能裁定的世界（AB_II 探针成本 4，A_II 8） |
| C09 的“G7 链族不收敛”反例未构造；C19 延迟数取自 A_I 格 | 写明“未构造”；改用 AB_I 值 2559 |
| 报告把 C02 写成“C2 结果 35→15” | 改为相对引用计数设计 35→15、相对不去重时延不变且物理工作 40→35；C05 “饿死”改为“推迟” |
| 变异测试未提交；常驻去重未测；before/after 用了旧测试文件 | 提交 `MailboxMutants` 与 `ResidencyDedupe`；before/after 用最终文件重新生成并标明哪些是行为证据 |
| 字段占位（“无。”“见上。”“见表。”等）、limit 列“；—”、route 列被截成“A/B”、与新组合结果矛盾的记录（Q027 转移、Q036 数字）、引用 v1 combos 的记录 | 全部改写；`build.py` 拒绝占位词与过短字段，修正 route 截断与 limit 列；Q015/Q027/Q029/Q036/Q038/Q107/Q110 改引 `raw/joint` |
| xcheck_r9.json 无历史标注；中性检查黄金例都在自动关闭域 | 加历史标注字段（结果值不变）；新增一个自动开启的手算黄金例 |
| REPRODUCE 漏列 bench_prune | 已列 |
| 其余小项（Q043 括注、FAILURES §E 的旧判据、引理测试表述、Windows 分隔符断言不可能失败、SHA256SUMS 重复行不检测） | 全部改正；重复行现在使 `--verify` 失败 |

## 收口轮：最后一次定点修复（2026-10-28）

范围只有下面四项及其受影响的结果。没有新增研究题目，没有运行真实产品，原包 38 个文件未改。每项都先写调用真实实现的失败回归，再修复。修复前输出：`raw/regressions/before_fix_final.txt`（当时的 42 项中 33 项失败或报错，原因与报告一致；新接口尚不存在的 12 项以 AttributeError/KeyError 报错）。

| 项 | 旧问题 | 修改 | 复验 | 结论变化 |
|---|---|---|---|---|
| F1 | `joint_d.c30` 用 `headroom_possible = min_total_reduction_ns <= 0` 判断主门槛有没有头寸，把“尚需削减”当成“无法削减”；指标“主门槛试验数（应为 0）”预设了答案 | 新增三值裁定 `c30_classify`：NO-GO 只认逐样本下界向量（s_i，或时延减已证可移除上界）的中位 > T；GO 只认真实系统上界中位 ≤ T；矛盾单独报告；其余证据不足 → 先补观测，不批准试验。C30 改成“不安全动作数”，以包内相容世界（obsworlds 的 W_*、T01 P/S，reach.py 的可行性函数）为 oracle；4 个输入（包内、合成必需服务、合成真实上界、缺数据）× 5 个域 | `tests/test_final_fixes.py::C30Decision`（13 项）；`raw/joint/C30.json`；修复前后对照 `raw/regressions/closing_round_before_after.json#F1_C30` | **是**：C30 stop → probe_first；主门槛授权前方向 = 证据不足；伙伴类、只作用于新开/重开 = 有前提的 NO-GO（124.4 / 91.7 ms）；旧规则与旧指标撤回，旧原始输出保留在 `history/before_closing_round/joint/C30.json` |
| F1 同步 | v1 组合文件 `exp_combos.c30` 的常量格子与“松弛界去掉主门槛试验”文字 | 格子改为 None（撤回），只作指针 | `raw/combos/combos.json` 只有 C30 变化，其余组合逐项相同 | — |
| F2 | `ChunkedLazy` 只记最早可疑块，第一次出口收敛后把右侧全部当作有效：两次更新之间不查询时漏掉右侧的直接改动；单次更新跨块或经手工链长依赖时也漏 | 每块记录实际读集（对象与边）；`update()` 精确比对新旧输入，读集含改动的块为直接脏，前块出口变化为传播脏，收敛只清传播脏；设置/长度变化全量回退并计数；新增成本字段 `entry_checks`、`diff_compares`、`fallbacks`。旧实现保留为 `ChunkedLazyV1`，只作对照 | `tests/test_final_fixes.py::ChunkedLazyUpdates`（13 项，含报告反例、顺序反转、同位多次、同块/异块、查询在中间或之后、手工链、边界、300 个随机序列）；`bench/exp_c09_fix.py` → `raw/regressions/c09_fix.json` | C09 四个单次更新输入数值不变（34/29/33/0，0 错误）；适用域与成本改写（多次更新时旧实现 195/200 个世界出错；修复后随机单次更新 +7.5% 步数，每次更新 O(n) 比对） |
| F3 | `Sim._check_consumers` 在所需任务完成时就开始消费，不看消费者是否停顿、是否已接纳（服务 5、消费 2、停顿到 40：accepted_at=40 而 consumer_done=7） | 逐消费者记录接纳（`Task.accepted_by`）；消费者恢复后才接纳所需结果，全部接纳后才开始消费；完成事件带 token，关闭、所需任务被取消、需求集合改变（旧事件）时丢弃并记入 `consumption_discarded`；已交付给另一消费者的结果不再换手生产侧资源 | `tests/test_final_fixes.py::ConsumerDone`（14 项，含报告例子 → 42、无停顿、停顿早于/晚于完成、多依赖、多消费者、关闭/取消/旧事件、500 例随机）；原有 `MailboxFuzz`、`MailboxMutants` 通过 | 否：没有实验在同一调度实例里同时用消费服务与停顿；重跑全部调度实验与 30 个组合，原始结果与交付时相同 |
| F4 | `test_windows_separators_in_manifest_are_normalised` 用 `write_text` 写夹具、清单硬编码 LF 长度；Windows 文本模式下 a.py 10 字节、B.md 3 字节，检查器正确地拒绝了 | 夹具全部 `write_bytes`；清单长度与哈希取自磁盘实际字节；新增 LF、CRLF、反斜线清单的正例，以及错误长度、错误哈希、“清单按 LF 但文件是 CRLF”的负例；检查器未改 | `tests/test_revision.py::Integrity`（14 项）；`tests/test_final_fixes.py::WindowsFixture` 在仿真的 Windows 文本模式下运行 Integrity 全部用例（这项仿真只能证明夹具不再依赖文本模式换行：它使旧夹具失败；新夹具不再调用 `write_text`，所以在新夹具上与普通运行等价，不额外覆盖 CRLF——CRLF 由 `test_lf_crlf_and_backslash_manifests` 直接写入字节覆盖） | 否。原生 Windows：NOT_RUN |
| SF-5（自查） | `check_report_consistency.py` 用 `line.strip().startswith("  -")` 判断子项，永远为假：“停止”下的缩进子列表从未被检查，所以 C30 改裁定后仍留在停止列表也通过了 | 改为 `line.startswith("  -")`；新增 7 个收口轮关键数字的核对 | `tests/test_final_fixes.py::ReportCheckerCatchesSubListMisplacement`（把 C02 放进停止子列表，必须报错） | 报告 §4 的 C30 移到“只需补观测” |
| 验收补充 | 多次更新是否还有遗漏失效 | 对另外两个增量结构（`SummaryTree`、`Checkpoints`）加随机多次更新检验 | `tests/test_final_fixes.py::OtherIncrementalStructuresMultiUpdate`（150 例，0 错误） | 否 |
| 同步 | 记录 C09、C30、Q100；报告文首“收口轮”、§3、§4、§5；`HANDOFF.md`（新）；`REPRODUCE.md`；`run_all.sh`；`ACCEPTANCE.md` 收口轮一节 | `records/build.py`、`check_report_consistency.py` 通过 | — |

### 收口轮：独立验收后的改正

只读验收代理（独立上下文，只拿到本轮要求与文件路径）在副本中重跑全部命令，并分别对四项构造反例。四个报告中的反例都不再复现；它另外指出以下问题，全部在本轮内改正：

| 验收发现 | 改正 | 复验 |
|---|---|---|
| C30 把结果池（D2）判为“证据不足 → 先补观测”，而 C05/Q028 仍是工程小试，HANDOFF 又要求每个候选先过 `c30_classify`——推荐与新规则不一致 | 写明适用范围：三值裁定只回答“能否过主门槛”；工程小试针对尾部与资源安全，凭各自证据与停止条件，不能写成主门槛收益。D2/D3 的前提改为“作为主门槛机制”。同步 `raw/joint/C30.json#notes.scope`、记录 C30、报告文首、`HANDOFF.md` 开头 | `C30Decision.test_scope_is_main_gate_only` |
| C30 指标只算不安全动作，始终“先补观测”的分类器也得 0；复核又发现：只看有无界、不看数值的规则，以及把模型上界当真实的规则，也与真分类器同分 | 指标改为错误动作 = 不安全 + 证据已能裁定却仍延后；另加两个“证据存在但不决定”的输入（下界中位 ≤ T；仅模型上界 ≤ T）。AB_II 得分：始终先补观测 2/1/1/0/0/0、始终停止 3/1/2/2/2/2、始终试验 5/2/1/2/2/2、只看有无界 0/0/0/1/1/0、模型当真实 0/0/0/0/1/0、三值分类器 0/0/0/0/0/0 | `C30Decision.test_simplistic_rules_are_penalised_by_the_study_metric`（6 种规则） |
| `c30_classify` 无输入校验：负的可移除上界判 NO-GO；下界超过观测时延不报矛盾；（复核）NaN、上下界长度不一、模型上界与下界冲突 | 负值、非数值、NaN、长度不一报错；下界 > 同样本观测时延 → inconsistent；被下界否定的模型上界在输出中标 `conflict_with_model_upper_bound` | `C30Decision.test_invalid_or_contradictory_bounds` |
| D1p/D1s 的 oracle 与分类器是同一个界 | 写明：只检验一致性，H2/H3 前提本身是假设（`notes.domain_premises`、记录 C30） | — |
| ChunkedLazy：调用方原地修改 case 再调用 `update(case, pos)` 时比对不到改动，返回旧 unit（V1 反而正确） | 构造与每次 `update()` 都保存私有深拷贝快照；成本记为每次更新一次 O(n) 复制 | `ChunkedLazyUpdates.test_in_place_mutation_then_update_is_detected`（含原地改设置 → 全量回退） |
| consumer_done：完成后需求集合改变，旧完成仍留在 `consumer_done` | 需求集合改变时把旧完成移到 `consumption_superseded`；关闭之后的改变不影响关闭前的完成 | `ConsumerDone.test_completion_superseded_by_later_need_change`；随机检验加入运行中改需求 |
| consumer_done：运行开始后修改 `stall_until` 不会触发接纳；延长停顿后旧的 stall_end 仍会接纳；（复核）由 after_event 钩子修改时要到下一事件才生效 | 每个事件后、以及钩子之后，为改变的停顿重新排 stall_end；stall_end 只在消费者确实恢复时接纳。关闭之后消费状态冻结（写入 sched.py 文档） | `test_stall_set_after_run_started`、`test_stall_extended_makes_old_stall_end_outdated`、`test_stall_changed_by_hook_is_applied_at_once`；随机检验加入运行中改停顿 |
| （复核发现的旧缺陷，早于本轮）同一任务第二次 `upgrade_task(restart)` 覆盖正在运行的替身 `x'`，字节预留泄漏、工人账失真 | 替身 id 不再重复（`x''`…） | `test_double_restart_upgrade_keeps_ledger`；唯一调用者 exp_sched S9 只升级一次，结果不变 |
| F3 的静态扫描用正则，跨不过嵌套括号，结论空洞 | 改为 AST 扫描（统计 Sim 调用、同时显式传 consume 与 stall_until 的调用、`**kwargs` 动态调用），并对报告例子做灵敏度自检（必须检出 1 个）；3 处动态调用人工核对（见 ACCEPTANCE“收口轮最终验证”） | `raw/regressions/closing_round_before_after.json#F3_consumer_done.static_scan_*` |
| 报告“57 个原始结果文件与交付时完全相同”没有依据（只有 36 个有修复前副本、32 个被比较） | 改为：重跑的实验产生 36 个文件，32 个相同、4 个不同；另 25 个文件所属实验未重跑 | `check_report_consistency.py` 与 `closing_round_before_after.json` |
| WindowsFixture 的仿真在新夹具上与普通运行等价，CHANGELOG 夸大 | 改写措辞（见 F4 行） | — |

以上改正之后，再次重跑全部受影响实验（30 个组合与调度实验）；结果见 ACCEPTANCE“收口轮最终验证”。
