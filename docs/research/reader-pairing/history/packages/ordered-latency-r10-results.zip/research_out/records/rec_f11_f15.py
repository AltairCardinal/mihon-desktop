"""Per-question records F11-F15 (Q061-Q090)."""

R = []


def rec(**k):
    R.append(k)


# ---------------------------------------------------------------- F11 取消、物理退出与回收
rec(id="Q061", status="completed", decision="stop",
    domain="共享物理作业T：C1取消并关闭，T晚退出，C2仍需结果。6种交错；另有包内Protocol与调度模型。",
    A="逻辑状态与physical-running状态独立，exit时唯一释放",
    B="物理作业能力对象拥有配额，逻辑请求只持租约",
    new="取消即释放槽在6/6交错中让新工作与仍在运行的T同时占用同一物理资源；取消即杀共享作业在6/6中让C2失去结果。A、B都0错。调度模型中“取消不等退出”的代价：取消后非抢占作业继续占用直到真实退出（S8：阻塞=剩余服务）。",
    disc="lab/lifecycle.py::q061_062_063; bench/exp_sched.py::s8_blocking → raw/lifecycle/lifecycle.json#Q061_Q063, raw/sched/sched.json#S8",
    pos="—", deg="作业已退出后取消：无差。", cex="cancel_releases_slot：所有交错。", cost="B：能力对象。", fail="—", obs="物理退出回执。",
    level="合成协议穷举+调度模型", limit="—")

rec(id="Q062", status="completed", decision="stop",
    domain="旧context作业在切换后晚完成，新context作业并行。4种交错。",
    A="双门：身份拒接纳但物理exit照常回收",
    B="独立reaper回收通道，逻辑结果不投递但释放证明交付",
    new="按对象接纳在3/4交错中接纳旧结果；切换时删除旧任务记录在3/4中让旧作业的退出无法释放槽（泄漏）。A（接纳身份门+退出照常释放）与B（切换时把旧作业移入只释放不投递的reaper通道）都0错；B多1次移交。旧作业在切换前真实退出的交错中应被接纳（oracle已区分）。与R9关闭排空缺陷同型。",
    disc="lab/lifecycle.py::q062 → raw/lifecycle/lifecycle.json#Q062", pos="—", deg="旧作业先于切换退出。",
    cex="start_old, switch_ctx, start_new, exit_old：删除旧记录后泄漏。", cost="B：reaper通道。", fail="—", obs="—", level="合成协议穷举", limit="—")

rec(id="Q063", status="completed", decision="stop",
    domain="同Q061：C1关闭时共享作业T仍在运行且C2需要。",
    A="等待该context所有真实资源退出的严格join",
    B="显式转移到仍活跃消费者/共享owner，再关闭局部所有权",
    new="两者都无泄漏、C2不失结果；A在作业晚于关闭退出的交错中让关闭多等1个事件步（过宽），B关闭等0但需1次所有权转移。直接丢租约在1/6交错中泄漏账本。",
    disc="lab/lifecycle.py::q061_062_063 → raw/lifecycle/lifecycle.json#Q061_Q063；组合C17", pos="—", deg="T先退出：A=B。",
    cex="close_drops_lease。", cost="A：关闭延迟；B：转移。", fail="无活消费者时B退化为A。", obs="—", level="合成协议穷举", limit="—")

rec(id="Q064", status="completed", decision="stop",
    domain="上界U=8 MiB、实读r、窗口W；读取中取消。",
    A="先预留上界、逐次实耗、退出退未用预留",
    B="分段读取能力，每段先授权",
    new="A峰值8、退出后账本0；B峰值4、请求次数⌈r/4⌉。取消时与退出时各退一次的实现让账本变负（−r..−U）。两者都不允许第二个8 MiB任务在读取期间进入10 MiB窗口。",
    disc="lab/lifecycle.py::q064; bench/exp_sched.py::s14_bytes → raw/lifecycle/lifecycle.json#Q064", pos="—", deg="r=U。",
    cex="双重退款。", cost="B：授权往返。", fail="—", obs="—", level="推导+包内协议", limit="—")

rec(id="Q065", status="completed", decision="conditional_theory",
    domain="任务持有{工人、字节、结果缓冲}，依赖分别在退出、最后一次读取、消费者接纳时结束。",
    A="真实依赖消失时分资源提前释放",
    B="完成时集中转移资源所有权",
    new="A在最后一次读取时释放字节窗口，等待字节的任务提前max(退出,接纳)−最后读取（示例中6–7单位）；B实现简单但统一延迟。只有在字节窗口是瓶颈时有意义（本包没有窗口饱和证据）。",
    disc="lab/lifecycle.py::q065 → raw/lifecycle/lifecycle.json#Q065", pos="r<exit：A提前。", deg="r=exit=accept：相同。",
    cex="—", cost="A：多个释放点。", fail="—", obs="字节窗口占用时间序列。", level="推导", limit="—")

rec(id="Q066", status="completed", decision="probe_first",
    domain="关闭时三个运行作业（服务40/12/100），合同服务上界50。",
    A="加入单个物理exit确认，计算资源阻塞界",
    B="利用有界服务契约推导关闭上界",
    new="合同界推出关闭≤48，实际排空98：第三个作业违反声明界。有exit回执才能发现违约；没有服务上界时关闭上界只能保持符号。",
    disc="lab/lifecycle.py::q066 → raw/lifecycle/lifecycle.json#Q066", pos="服务都≤50：界成立。", deg="—", cex="服务100的作业。",
    cost="每作业一个exit回执。", fail="—", obs="物理exit回执。", level="推导", limit="—")

# ---------------------------------------------------------------- F12 合法轨迹、方向与可达性
rec(id="Q067", status="completed", decision="stop",
    domain="150个12对象世界；全部事实以随机顺序到达，每次到达后认证目标。",
    A="输入/知识/授权三层的偏序归约（证书只依赖知识，不依赖到达顺序）",
    B="参考状态机的轨迹等价类检查（重放）",
    new="1034次Certified结果全部等于完整计划的目标unit，0次首次正确性违例；有界穷举（certificates）0次不可靠。不同导航/到达顺序只影响何时能出证，不影响证书内容。",
    disc="bench/exp_gamma2.py::g5_commutativity; bench/exp_certificates.py → raw/gamma/gamma2.json#G5, raw/gamma/certificates.json",
    pos="—", deg="全部事实先到：首轮即出证。", cex="未找到（有界）。", cost="—", fail="有界域外不保证。", obs="—", level="重建Γ", limit="n=12")

rec(id="Q068", status="completed", decision="engineering_trial",
    domain="意图i1已曝光后i2、i3到达。",
    A="只合并尚未授权/未曝光的意图",
    B="保留事件日志惰性执行，在消费边界压缩",
    new="全部合并在1/4交错中丢掉已曝光意图的进度；A、B 0错（B多保留日志）。与S11结合：丢弃未开始的旧意图把快意图流的末意图时延从59降到19。",
    disc="lab/lifecycle.py::q068; bench/exp_sched.py::s11_fast_intents → raw/lifecycle/lifecycle.json#Q068", pos="—", deg="i1未曝光：可丢。",
    cex="i1, expose_i1, i2：merge_everything丢掉i1进度。", cost="B：日志长度。", fail="—", obs="—", level="合成协议穷举", limit="—")

rec(id="Q069", status="completed", decision="stop",
    domain="合成导航历史生成器（cachemodel.Nav）：每步认证→可见物化→预取，断言首槽等于完整计划。",
    A="调用中性语义状态机的用户级操作并自然完成任务",
    B="约束求解合法操作序列（这里：BFS枚举），再用同一状态机重放验证",
    new="40个世界×多种历史（前进、往返、远跳；容量7/16、3/6、64/64；LRU/距离；预取开关；强证书开关）全部通过首槽断言；BFS枚举的最短正收益历史都可由生成器重放。生成器不注入事实、不清缓存。",
    disc="lab/cachemodel.py::Nav.go（断言）; bench/exp_cache.py → raw/cache/cache.json", pos="—", deg="长度1历史。",
    cex="生成器若注入事实（禁止）会制造人工机会：本实现没有注入接口。", cost="—", fail="不是实现的导航语义。", obs="—", level="合成+重建Γ", limit="—")

rec(id="Q070", status="completed", decision="stop",
    domain="同位置内容替换（值相同）。",
    A="内容能力完全隔离，位置只用于导航",
    B="内容地址化跨context共享，授权仍按新输入签发",
    new="同值替换后证书不再current，计划不变：A与B都要求重新签发授权；B允许复用数据。Q002的值相等接纳在20/24交错中错误。",
    disc="bench/exp_gamma2.py::g6_identity; lab/lifecycle.py::q002 → raw/gamma/gamma2.json#G6", pos="—", deg="—", cex="value_equal。",
    cost="B：内容摘要。", fail="—", obs="—", level="重建Γ+协议", limit="—")

rec(id="Q071", status="completed", decision="stop",
    domain="rebind（generation+1）后旧证书与数据。",
    A="保留数据租约但重新证明/签发当前授权",
    B="证明携带的不可变结果，rebind只做精确支持验证并签发当前能力",
    new="rebind后is_current为False；独立检查器（只用支持事实重放）300/300接受真证书、300/300拒绝伪造unit，成本与构建相当（Python模型：检查约94–116 ms vs 构建79–99 ms/60证书）；完整重证与B的检查成本同量级，B没有明显计算优势，只有可审计性。",
    disc="bench/exp_gamma2.py::g6_identity,g12_checker; bench/bench_micro.py (W_d) → raw/gamma/gamma2.json, raw/bench/micro_*.jsonl",
    pos="—", deg="—", cex="伪造unit：检查器拒绝；版本戳快路会接受（不检查unit）。", cost="见上。", fail="—", obs="—", level="重建Γ+微基准", limit="Python计时")

rec(id="Q072", status="completed", decision="probe_first",
    domain="最短正收益轨迹与自然频率。",
    A="最短反例/正例搜索，按路径长度和新增工作最小化",
    B="对未知负载分布做机会区间/保守阈值分析",
    new="最短正收益轨迹长度1–3（跳转首访），每条省1个物化；但包内没有自然跳转频率，期望收益只能写成 p_jump × E[省下的物化] × (物化服务时长)，三个因子都未知。不得把枚举出的轨迹比例当频率。",
    disc="bench/exp_cache.py → raw/cache/cache.json", pos="—", deg="p_jump=0：收益0。", cex="—", cost="—", fail="—",
    obs="真实会话的跳转首访比例与物化服务时长。", level="合成+推导", limit="—")

# ---------------------------------------------------------------- F13 可见消费、帧等待与批处理
rec(id="Q073", status="completed", decision="stop",
    domain="成员资源就绪时刻ra、rb，帧周期16；一次提交 vs 占位提交+内容提交。",
    A="资源分段准备，完整unit在同一提交点授权",
    B="提前提交精确占位布局，资源到达再消费",
    new="第二次（占位）提交只能提前首成员ack（例如ra=3,rb=20：首成员16，完整ack仍32），从不提前完整unit ack。正式数据：伙伴间隙（完整ack−首成员ack）中位F0仅5.8 ms。",
    disc="lab/lifecycle.py::q073_q075; lab/reach.py::partner_gap → raw/lifecycle/lifecycle.json#Q073_Q075, raw/pass1/reach.json",
    pos="—", deg="ra、rb同帧：相同。", cex="—", cost="B：多一次提交。", fail="—", obs="—", level="推导+复算", limit="—")

rec(id="Q074", status="completed", decision="probe_first",
    domain="两个世界：状态晚接纳、下一帧提交 vs 状态早接纳、等帧。帧周期16。",
    A="增加状态接纳与实际消费两端因果戳",
    B="受控提交相位扰动估帧等待区间",
    new="两世界完整ack都为32；把提交相位平移8后，状态等待世界变40，帧等待世界变24——相位扰动能区分，原数据不能。最小新增：状态接纳时刻（A）；B需要受控扰动实验。",
    disc="bench/exp_misc.py::q074 → raw/misc/misc.json#Q074", pos="—", deg="接纳恰在帧边界。", cex="同ack的两世界。",
    cost="A：一个时间戳；B：一次扰动实验。", fail="—", obs="状态接纳时刻。", level="推导", limit="—")

rec(id="Q075", status="completed", decision="stop",
    domain="批截止D∈{0,8,16,32}，帧周期16，资源就绪5。",
    A="按最早合法完整unit立即提交",
    B="有界microbatch，截止前合并无共享依赖的更新",
    new="批税=⌈(ready+D)/P⌉P−⌈ready/P⌉P：D=16税16，D=32税32；只省提交次数。",
    disc="lab/lifecycle.py::q073_q075 → raw/lifecycle/lifecycle.json#Q073_Q075", pos="D=0/8：无税。", deg="—", cex="D=16。", cost="—",
    fail="—", obs="—", level="推导", limit="—")

rec(id="Q076", status="completed", decision="stop",
    domain="手势逐步露出右邻unit；邻居证书就绪c、预览阈值g、提交m。",
    A="只为可能曝光集合保守提前认证并保留能力",
    B="曝光许可与手势阶段联动，未认证位置不授权曝光",
    new="朴素预览在c>g时露出未认证内容（3/4组）；A、B都不露出，预览推迟max(0,c−g)；A认证3个unit，B认证1–2个。这是正确性约束，不是提速。",
    disc="lab/lifecycle.py::q076 → raw/lifecycle/lifecycle.json#Q076", pos="c≤g：无推迟。", deg="—", cex="c=10,g=5：朴素露出未认证邻居。",
    cost="A多认证。", fail="—", obs="—", level="推导（算术模型）", limit="薄")

rec(id="Q077", status="completed", decision="stop",
    domain="布局差量更新（拆分/合并unit）时旧ticket与导航。",
    A="稳定原始item键+持久unit映射，最小差量提交",
    B="不可变布局快照，消费ticket固定快照并桥接导航",
    new="组合C14：只有租约没有item锚定仍导航错（1错）；租约+item锚定（I）或多版本快照+桥接（II）都0错；II常驻两个版本。消费按(ticket,unit)键时差量不导致重复消费。",
    disc="bench/exp_combos.py::c14; lab/lifecycle.py::q006,q057 → raw/combos/combos.json#C14", pos="—", deg="无布局变化。",
    cex="C14 A格。", cost="II：两个快照。", fail="—", obs="—", level="合成协议穷举", limit="—")

rec(id="Q078", status="completed", decision="probe_first",
    domain="完整ack是绘制回执，不是光学呈现。",
    A="保持当前消费端点，另给显示延迟的未知区间",
    B="外部显示观测方案，与内部ack受控关联",
    new="两世界（呈现延迟0 vs 一个刷新周期+合成器延迟）产生相同的ack数据，显示差距在包内不可识别，区间[0, 刷新周期+合成延迟]。端点不应改；外部观测只作附加描述。",
    disc="bench/exp_misc.py::q076_q078（推导）", pos="—", deg="—", cex="—", cost="外部采集设备（委托方）。", fail="—",
    obs="外部高速采集与ack时间戳的关联（提案）。", level="推导", limit="不改主端点")

# ---------------------------------------------------------------- F14 统计估计量、门槛与完整分母
rec(id="Q079", status="completed", decision="stop",
    domain="正式F0/F1同50个ID；构造反例。",
    A="冻结的整体中位差",
    B="同ID差研究异质性，不替换主估计量",
    new="整体中位差15.012 ms，同ID差中位12.597 ms，均值差34.65 ms，38/50同ID改善；构造例ref=[1,2,3,10,11]、cand=[0,1,4,9,12]：中位差−1（候选更慢）而配对差中位+1（候选更快），两估计量异号。主估计量不变。",
    disc="bench/exp_stats.py::q079 → raw/stats/stats.json#Q079", pos="—", deg="所有差相同：两者相等。", cex="constructed counterexample。",
    cost="—", fail="—", obs="—", level="历史复算+构造", limit="—")

rec(id="Q080", status="completed", decision="stop",
    domain="n=50偶数中位，门槛T=30196850 ns。",
    A="排序约束x(25)+x(26)≤2T及组配额",
    B="逐样本可改善范围上的整数优化，求可达中位界",
    new="引理R1：中位≤T ⇔ x(25)+x(26)≤2T（在偶数n≤8、值0..6全部54145种情形穷举验证），推论至少25个样本≤T。F0没有任何样本≤T（最小84.3 ms）。最小总削减（只降不升）=26个最小样本各降到T，总计1.859 s，逐样本54.1–105.7 ms；F1基线下1.642 s。冻结推进样本不动时，即使20个跳转全降为0也不可能过门槛（只有20个<25）。",
    disc="lab/reach.py → raw/pass1/reach.json（lemma_r1, F0_min_reduction, F0_restricted）", pos="—", deg="—",
    cex="冻结推进组：不可行（restricted）。", cost="—", fail="—", obs="—", level="推导+有界穷举+复算", limit="—")

rec(id="Q081", status="completed", decision="stop",
    domain="16 ms组中位护栏与单条退化。",
    A="保留原目标/动作组中位门禁，单条另列",
    B="研究性风险向量/条件分布报告，不改门槛",
    new="历史组护栏通过（最大组退化15.447 ms），但同ID单条退化超过16 ms的有4条（q001 +66.0 ms、q003 +30.6、q002 +19.4、q024 +16.9）。护栏是组中位规则，不是逐样本界。",
    disc="bench/exp_stats.py::q081 → raw/stats/stats.json#Q081", pos="—", deg="—", cex="构造：组中位+10、单条+100。", cost="—", fail="—", obs="—",
    level="历史复算", limit="—")

rec(id="Q082", status="completed", decision="stop",
    domain="n=50的nearest-rank P95（第48个次序统计量）。",
    A="有限样本描述+分布无关次序统计置信界",
    B="明确分布/相关性假设下的敏感性",
    new="P(X(j)≥q95)：j=48为0.459，j=50（最大值）为0.923。即样本最大值也只是约92%的q95上置信界；P95点估计有54%概率低于总体95分位。不得作统一尾界。",
    disc="bench/exp_stats.py::q082 → raw/stats/stats.json#Q082", pos="—", deg="—", cex="—", cost="—", fail="—", obs="—", level="推导", limit="iid假设")

rec(id="Q083", status="completed", decision="stop",
    domain="R0（10失败）。",
    A="先正确性/有效性硬门禁",
    B="删失/区间分析保留失败成本",
    new="成功子集中位106.3 ms，失败按0或15 s赋值时中位区间[97.2,118.5] ms，P95从274 ms变为15 s（组合C25）。R0有首槽错误，先判无效。",
    disc="bench/exp_stats.py::q083; bench/exp_combos.py::c25 → raw/stats/stats.json#Q083, raw/combos/combos.json#C25", pos="—", deg="—",
    cex="成功子集P95 274 ms vs 全分母15 s。", cost="—", fail="—", obs="—", level="历史复算", limit="—")

rec(id="Q084", status="completed", decision="probe_first",
    domain="非相邻F0/F1历史对照；分层重采样的零效应模拟。",
    A="环境漂移敏感性界与负控制",
    B="同scope区组/随机交错设计及所需规模",
    new="任何≥15.012 ms的共同漂移都能完全解释历史差（观测等价）。以F0形状噪声（按场景分层重采样）做零效应模拟，单次运行出现≥15 ms中位改善的概率约20%：历史差在本设计的噪声范围内。推进组同格内SD约12.8 ms；配对设计检出15 ms均值移位约需12对（正态近似）。",
    disc="bench/exp_stats.py::q084,q085_q089 → raw/stats/stats.json#Q084,Q085_Q089", pos="—", deg="—", cex="漂移世界。", cost="ABBA设计一次。",
    fail="重采样假设样本独立同分布。", obs="同session ABBA区组。", level="复算+模拟", limit="噪声模型为假设")

# ---------------------------------------------------------------- F15 实验选择、冻结与观察成本
rec(id="Q085", status="completed", decision="stop",
    domain="零效应下，以F0分层噪声模拟“≥δ中位改善”闸门。",
    A="预声明候选+固定heldout，探索只用于参数选择",
    B="顺序检验/多重比较预算",
    new="δ=15 ms：单次误通过率20%，重跑到绿（最多5次）68%，探索选优后在新heldout上一次裁定22%（回到单次水平）。冻结100 ms主规则在零效应下从不被噪声通过（0/2000）。",
    disc="bench/exp_stats.py::q085_q089 → raw/stats/stats.json#Q085_Q089；组合C24", pos="—", deg="—", cex="best_of_5_reruns。", cost="heldout一次运行。",
    fail="—", obs="—", level="模拟", limit="噪声模型为假设")

rec(id="Q086", status="completed", decision="stop",
    domain="零真实效应，后跑的臂获得8 ms预热收益。",
    A="按冷热scope区组随机化",
    B="平衡交叉（ABBA）建模顺序/携带效应",
    new="固定OFF→ON估计出7.9 ms虚假改善；ABBA估计0.09 ms。",
    disc="bench/exp_stats.py::q086 → raw/stats/stats.json#Q086", pos="—", deg="无携带效应：两者都≈0。", cex="固定顺序。", cost="—",
    fail="强制清缓存不等于自然冷（不可用作对照）。", obs="—", level="模拟", limit="携带效应为假设")

rec(id="Q087", status="completed", decision="probe_first",
    domain="候选探针与它们分开的世界对。",
    A="为候选区分设计稀疏探针，按信息价值排序",
    B="阶段性启用互补探针，保留同端点/身份锚",
    new="最小成本探针集={授权时刻C_i，逐轮need/接纳时间戳}；已记录的rounds与support分不开任何世界对。阶段化计划：第一阶段只加C_i（成本1）；第二阶段仅当C_i未判NO-GO时加逐轮时间戳。",
    disc="bench/exp_misc.py::q010 → raw/misc/misc.json#Q010_Q087", pos="—", deg="—", cex="仅帧提交时刻：分不开事实主导世界。",
    cost="见Q010。", fail="—", obs="C_i。", level="精确集合覆盖", limit="5世界")

rec(id="Q088", status="completed", decision="stop",
    domain="3个独立串行进程的Python微基准：查询策略（n=48/176/1024）、证书、距离、检查器。",
    A="按当前短路径实际规模建立工作模型（步数/读数）",
    B="独立进程微基准覆盖建立/查询/更新/退出并寻交叉规模",
    new="n=176、20次查询：重扫270–306 ms，有限入口认证43 ms，检查点35–38 ms，摘要树建+查询162–166 ms，树的20次更新+查询292–318 ms；n=1024时认证64–78 ms仍最快或并列。分支证书比C09慢约100倍（5.6–6.0 s vs 55–58 ms/60例）。没有任何规模下摘要树胜出。所有数字为Python模型，不能换算产品毫秒。",
    disc="bench/bench_micro.py → raw/bench/micro_20261027T145403Z.jsonl, *_meta.json（PID 786/797/801）", pos="—", deg="n=48：检查点≈认证。",
    cex="树在频繁更新下最慢。", cost="—", fail="Python与原生常数不同。", obs="—", level="模型微基准", limit="Python")

rec(id="Q089", status="completed", decision="stop",
    domain="零效应重跑到绿。",
    A="预先固定一次裁定与失败保留规则",
    B="预声明顺序设计及信息增加条件",
    new="同Q085：重跑5次把15 ms闸门误通过率从20%升到68%；一次冻结裁定保持20%。主门槛100 ms不受噪声影响，但会受“改端点/删失败/挑样本”影响，这些都已被包内compare拒绝（W18）。",
    disc="bench/exp_stats.py::q085_q089 → raw/stats/stats.json#Q085_Q089", pos="—", deg="—", cex="重跑。", cost="—", fail="—", obs="—", level="模拟", limit="—")

rec(id="Q090", status="completed", decision="stop",
    domain="本轮自身的研究优先级。",
    A="价值信息/决策树：先排除不可识别与无头寸路线",
    B="多臂资源分配/稳健前沿",
    new="决策树：(1) 冻结设计中位由推进样本决定（x25、x26都是推进）→ 只作用于跳转的机制对主门槛无头寸（restricted不可行）；(2) 伙伴类机制上界5.8 ms → 停止；(3) 事实侧能否过门槛不可识别 → 只值得补C_i；(4) N0中事实/证明在窗口内为0而窗口仍约145 ms → 条件不可能。B（稳健前沿）给出相同排序：先停伙伴/跳转/批处理方向，再做零风险的资源保护，其余补观测。两法一致，研究资源据此分配（见报告第4节）。",
    disc="lab/reach.py; lab/n0_structure.py; lab/obsworlds.py → raw/pass1/*.json", pos="—", deg="—", cex="—", cost="—", fail="—", obs="C_i。",
    level="推导", limit="—")
