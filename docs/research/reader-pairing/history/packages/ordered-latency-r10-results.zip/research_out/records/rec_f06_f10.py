"""Per-question records F06-F10 (Q031-Q060)."""

R = []


def rec(**k):
    R.append(k)


# ---------------------------------------------------------------- F06 物化链路与全生命周期成本
rec(id="Q031", status="completed", decision="probe_first",
    domain="N0两臂的分层计数（source-open尝试、变换调用、计算对象）；物理IO不可见。",
    A="逐层命名事件与守恒账本",
    B="受控冷热干预+区间界，只识别可区分部分",
    new="三层计数在N0中不同步变化：打开尝试55→54，变换54→54，计算对象40→40（关闭后0）。逻辑打开≠物理读取≠变换；本包没有操作系统层读取，任何“少读一次”都不能落到物理IO。",
    disc="bench/exp_misc.py::q031_q036 → raw/misc/misc.json#Q031_Q036.Q031", pos="变换调用与开始/完成配对完整（54/54）。",
    deg="冷热不变时B无信息。", cex="打开少1次但变换相同。", cost="账本：每层一个计数器。", fail="缺OS层观测。",
    obs="字节完成/读取结束事件（Q008）。", level="N0复算", limit="单路线")

rec(id="Q032", status="completed", decision="conditional_theory",
    domain="成本模型c(v)=a+b·v，3个请求v=4，a=6，b=1（假设参数）。",
    A="合并物化（一次固定成本）",
    B="细粒度请求但流水化建立/复用上下文",
    new="分开30单位工作，合并18（省(k−1)a），流水化关键路径10但不省工作。哪种缩短端点取决于固定成本是否在关键路径上——数据中没有a、b的分解（不可识别）。",
    disc="bench/exp_misc.py::q031_q036 → raw/misc/misc.json#Q031_Q036.Q032", pos="a≫b·v：合并收益大。",
    deg="a=0：两者等价。", cex="关键路径只含一个请求时合并无收益。", cost="合并需等待所有请求到齐（等待税）。", fail="—",
    obs="单请求固定/按量服务分解（同一请求的开始/首字节/完成）。", level="推导", limit="参数为假设")

rec(id="Q033", status="completed", decision="probe_first",
    domain="证书需要的分析/边样本与可见物化共享同一物化（evidence.py轮次模型，300世界×3族）。",
    A="普通物化流水旁路产出证据",
    B="中性共享物化服务，两个消费者各自取派生结果",
    new="共享物化在长链族把中位物化数从9降到7（稀疏边族7→6，书页族5→5）；轮次数不变。组合C01（2工人）中共享把完整ack从38降到28、物理工作减少，旁路单独无效（曝光仍等证书）。",
    disc="bench/exp_evidence.py → raw/gamma/evidence.json（need4 vs need4_unshared）；bench/exp_combos.py::c01",
    pos="长链：共享省2个物化。", deg="书页族：无差别。", cex="只做旁路不共享：ack 35（C01 B格）。", cost="共享需引用租约（C02）。",
    fail="证据与可见使用的物化分辨率不同则不能共享（未建模）。", obs="可见物化与证据物化是否同一底层材料。", level="合成模型", limit="—")

rec(id="Q034", status="completed", decision="conditional_theory",
    domain="header（≤512 KiB）只给几何；完整物化给方向分析与边样本。",
    A="header/稀疏块按需取用并带精确身份",
    B="完整取用一次多路复用",
    new="自动模式关闭时，只有几何就能为300/300目标出证；自动模式开启时只有29/300。新风险：若header几何可与解码几何不一致，以header几何出证会发布错误首槽（C12：800次中238次）。",
    disc="bench/exp_gamma2.py::g10_cheap; bench/exp_combos.py::c12 → raw/gamma/gamma2.json#G10, raw/combos/combos.json#C12",
    pos="自动关闭：header足够。", deg="—", cex="C12示例：错误header让目标3成单独BEFORE_SHAPE_Y，真值为(3,4)对。", cost="header探测上限512 KiB。",
    fail="header不可信时只能作过滤（Q107）。", obs="header几何与解码几何不一致的次数（逐对象一个字段）。", level="重建Γ+合成", limit="—")

rec(id="Q035", status="completed", decision="stop",
    domain="关闭时仍有运行作业。",
    A="请求级强制join与即时回收",
    B="有界后台回收，显式归属并在下次竞争中计入",
    new="强制join的关闭最多等1个事件步（作业晚于关闭退出的交错）；后台回收关闭等0，但未退出作业会与下一次打开的首批工作争用，必须记入下一次打开的成本，不能藏进后台。",
    disc="lab/lifecycle.py::q061_062_063; bench/exp_misc.py::q031_q036 → raw/lifecycle/lifecycle.json#Q061_Q063",
    pos="作业先于关闭退出：两者无差。", deg="—", cex="close_drops_lease：账本泄漏（1/6交错）。", cost="见上。", fail="—",
    obs="关闭后物理退出时刻。", level="合成协议穷举", limit="—")

rec(id="Q036", status="completed", decision="conditional_theory",
    domain="两个布局版本共享解码对象（12单位）的常驻与适配工作。",
    A="缓存共同低层表示，各消费独立转换",
    B="共享高层不可变结果，用租约/视图适配",
    new="不共享24单位常驻；低层共享12单位常驻但两次适配；高层共享12单位一次适配，但要求结果与帧租约绑定。没有数据说明转换在关键路径上的比例。",
    disc="bench/exp_misc.py::q031_q036; bench/exp_combos.py::c29 → raw/misc/misc.json, raw/combos/combos.json#C29",
    pos="两版本并存时共享节省一半常驻。", deg="单版本：无差。", cex="—", cost="见上。", fail="适配依赖版本参数时高层不可共享。",
    obs="转换服务时长。", level="算术模型", limit="薄：只有常驻/次数")

# ---------------------------------------------------------------- F07 required、speculative与optional准入
rec(id="Q037", status="completed", decision="conditional_theory",
    domain="自动域n=3，60个随机世界：C09需求闭包取到的事实数 vs 精确最小证据。",
    A="按证书未满足读集生成需求闭包",
    B="由反例世界的区分动作生成最小必需集合",
    new="需求闭包平均2.4个事实，精确最小1.83；41/60世界相等，最大多4个。多出的部分正是“分类为required却非必要”的工作；可由分支证书回收（Q049/Q054）。",
    disc="bench/exp_misc.py::q037 → raw/misc/misc.json#Q037", pos="41/60：闭包即最小。", deg="—",
    cex="最大超出4个事实的世界（见原始记录）。", cost="精确最小需枚举Ω，只能小域。", fail="—", obs="—", level="重建Γ有界穷举", limit="n=3")

rec(id="Q038", status="completed", decision="engineering_trial",
    domain="2个optional+2个speculative（各60）占满4个共享物理工人，必需任务t=5到达。",
    A="物理资源前统一优先队列，逻辑池只做准入界",
    B="保留物理容量+有界借用（服务上界门控）",
    new="逻辑池中的预留（required+speculative池保留1槽）不能保护必需工作：optional占满物理工人，必需完成70（与无保护相同）。物理预留1个工人或按服务上界门控借用，完成15。",
    disc="bench/exp_sched.py::s12_coupling; bench/exp_combos.py::c03 → raw/sched/sched.json#S12, raw/combos/combos.json#C03",
    pos="物理预留：15。", deg="optional不在运行：逻辑预留足够。", cex="C03 A格：逻辑预留下70。", cost="物理预留：空闲容量。",
    fail="服务上界未知时借用门控不可用。", obs="optional与必需工作是否共享同一物理工人池（合同澄清）。", level="合成模型", limit="—")

rec(id="Q039", status="completed", decision="probe_first",
    domain="包内Protocol：40个optional请求、每5个后rebind一次。",
    A="单作用域单调attempt集合，物理退出与计数分开",
    B="能力配额令牌，跨位置显式转移或撤销",
    new="包内模型在rebind后清空attempt集合但保留累计计数，40个请求只准入16个（窗口作用域）；若把“作用域”读成身份作用域，同样输入会准入40个。作用域的定义决定快速rebind下的工作上界，必须由合同确定，不能由优化者选择。",
    disc="bench/exp_sched.py::s13_optional_cap（调用code/protocol.py）→ raw/sched/sched.json#S13", pos="窗口作用域：上限16守恒。",
    deg="无rebind：两种读法相同。", cex="每5个请求一次rebind：身份作用域读法准入40个。", cost="—", fail="—",
    obs="合同澄清：optionalAttempted的作用域。", level="包内协议模型", limit="—")

rec(id="Q040", status="completed", decision="stop",
    domain="包内Protocol：两个必需任务各申请20 MiB；取消后退回未读5 MiB；15 s后再申请。",
    A="准入时预留上界，按permit实耗结算，停止新工作",
    B="分块许可加硬上限",
    new="包内模型：第二个申请只得12 MiB（窗口剩余），取消任务的完成不被接纳，退出不退款（字节计为窗口已用），15 s后申请返回0。B（4 MiB分块）峰值4 MiB，但每块一次授权；两者都不允许第二个8 MiB任务在读取期间进入10 MiB窗口。",
    disc="bench/exp_sched.py::s14_bytes; lab/lifecycle.py::q064 → raw/sched/sched.json#S14, raw/lifecycle/lifecycle.json#Q064",
    pos="未知体积按上界预留：不越权。", deg="体积已知且小：两者相同。", cex="取消时与退出时各退一次：账本为负（双重退款，q064）。", cost="B：更多授权往返。",
    fail="低报体积时A需要停止读取。", obs="实际读取字节与预留上界之差。", level="包内协议+推导", limit="—")

rec(id="Q041", status="completed", decision="probe_first",
    domain="optional因字节窗口暂停；暂停期间rebind；随后退款。12种交错。",
    A="显式Paused(reason, context)队列",
    B="无保留请求的幂等再推导",
    new="4/12交错中context在暂停期间改变：若Paused项不带context就会恢复陈旧工作；B从最新需求重推导，永不陈旧，代价是每次恢复机会一次推导（12次）。",
    disc="bench/exp_misc.py::q041 → raw/misc/misc.json#Q041", pos="context不变：两者都恢复。", deg="—",
    cex="pause, rebind, refund, resume_check：无context的Paused恢复陈旧请求。", cost="A：每项存context；B：重推导计算。", fail="—", obs="—",
    level="穷举（小）", limit="—")

rec(id="Q042", status="completed", decision="probe_first",
    domain="窗口扩张：三族合成世界(各300)，比较证明驱动(need)与机会扩张(回跳倍增预取)。",
    A="证明驱动扩张，只加当前歧义的支持候选",
    B="预期信息价值驱动的机会扩张，受误预测成本门控",
    new="长链族：B把轮次中位5→3、最大27→13，239/300世界更少轮次、0世界更多，中位物化7→7、浪费中位2；书页族：轮次中位3→3、最大14→8，浪费中位2。B只在长依赖链上有收益；历史“加宽窗口”无收益与此一致（正式数据中只有跳到169有长链，且跳转不影响中位）。",
    disc="bench/exp_evidence.py → raw/gamma/evidence.json", pos="长链：轮次减半。", deg="短支持：无收益只有浪费。",
    cex="书页族中浪费356个物化/200世界（W20）。", cost="浪费物化。", fail="轮次本身若不耗时（F1自然实验暗示）则无收益。",
    obs="逐轮need发出与事实接纳时刻（目标169样本）。", level="重建Γ+合成", limit="轮次无时间单位")

# ---------------------------------------------------------------- F08 缓存、自然重访与可达机会
rec(id="Q043", status="completed", decision="conditional_theory",
    domain="16对象合成世界、物化缓存7/样本16、事实持久；枚举长度≤3的合法导航历史。",
    A="枚举合法导航状态求最短正收益历史",
    B="可达性搜索证明特定域无机会",
    new="顺序阅读（前进）在全部40个世界中强证书节省0个物化（复现“正常路线54→54”形状）；最短正收益历史长度1–3，都是跳转（例如先到10再回跳到9），每次省1个物化。往返历史也节省0。",
    disc="bench/exp_cache.py → raw/cache/cache.json（histories、shortest_gain_*）", pos="跳转历史：省1。",
    deg="前进/往返：0。", cex="前进历史：B证明无机会（在模型域内穷举）。", cost="强证书计算（Python模型约100倍，bench W_b）。",
    fail="真实缓存策略未知。", obs="真实导航中跳转首访的比例。", level="重建Γ+合成缓存", limit="不是实现的缓存策略")

rec(id="Q044", status="completed", decision="stop",
    domain="同值异身份：内容版本改变但事实值相同；rebind。",
    A="内容身份+设置/算法版本的复合键",
    B="按真实派生依赖的可验证内容摘要，分层键+支持检查",
    new="同值替换后证书is_current为False（正确），计划相同；可复用的是数据（内容寻址），不是授权。按值键复用在Q002中20/24交错错误。",
    disc="bench/exp_gamma2.py::g6_identity; lab/lifecycle.py::q002 → raw/gamma/gamma2.json#G6", pos="身份不变：命中。",
    deg="—", cex="value_equal方案。", cost="B：摘要计算。", fail="—", obs="—", level="重建Γ+协议", limit="—")

rec(id="Q045", status="completed", decision="stop",
    domain="样本容量2/16/64 × 强证书开关，20个远跳历史。",
    A="标量事实与重建能力分离，按需恢复样本",
    B="保留有充分支持的派生边/局部摘要",
    new="在事实持久的模型中，样本容量从2到64、强证书开关，远跳历史的物化数只在319–321之间变化（<1%）。样本只在首访时有用。",
    disc="bench/exp_combos.py::c07 → raw/combos/combos.json#C07", pos="—", deg="事实全已知：样本无用。",
    cex="A格（16）比0格（2）多1个物化（路径依赖）。", cost="样本常驻。", fail="若事实不持久（被淘汰）结论会变。", obs="标量事实的真实保留策略。", level="合成模型", limit="—")

rec(id="Q046", status="completed", decision="stop",
    domain="176对象：单次目标、同一目标10次、扫描20个目标；预建摘要树 vs 有限入口认证 vs 第二次晋升。",
    A="显式冷建索引，按复用次数与失效率求阈值",
    B="延迟到第二次需求才晋升",
    new="单次目标：认证20步，预建树1715步；第二次晋升仍不回本，因为有限入口认证本身已经是局部的。微基准（3个独立进程）：n=176时20次查询，树建+查询约162 ms，认证约43 ms，检查点约35–38 ms（Python模型）。",
    disc="bench/exp_combos.py::c18; bench/bench_micro.py → raw/combos/combos.json#C18, raw/bench/micro_*.jsonl", pos="—",
    deg="M=1。", cex="revisit10：树仍更贵。", cost="树建步数。", fail="若认证需要回溯很远（长链）且同目标多次访问，检查点（不是树）可回本。", obs="同目标重访频率。",
    level="模型+微基准", limit="Python计时非产品")

rec(id="Q047", status="completed", decision="conditional_theory",
    domain="LRU vs 按距离淘汰（容量7/16），前进/往返/远跳历史。",
    A="按证书边际消歧价值与恢复成本保留",
    B="物化/样本双层联合优化，可见需求硬优先",
    new="距离策略在往返历史把物化从1396降到1360（-2.6%），远跳727→684；强证书机会在两种策略下都很少（节省≤11/641）。淘汰策略改变工作量多于改变证书机会。",
    disc="bench/exp_cache.py → raw/cache/cache.json", pos="往返：距离策略省36。", deg="前进：两者相同(640)。",
    cex="S18：命中率高的LRU（4次）比价值策略（1次）总重建成本高（42 vs 26）。", cost="—", fail="—", obs="真实重访分布。", level="合成模型", limit="—")

rec(id="Q048", status="completed", decision="conditional_theory",
    domain="负例（正常路线0采用）如何指导搜索。",
    A="对未覆盖状态边界做可达性覆盖搜索",
    B="以收益条件为约束反向合成最短历史",
    new="模型中负例的原因可分解：前进阅读时邻居总会被可见物化/预取物化，强证书省下的“事实”不对应物化。反向合成得到的最短正例全是跳转首访（Q043）。真实路线若跳转少，机会就少；需要自然跳转频率（不可从包内得到）。",
    disc="bench/exp_cache.py::shortest → raw/cache/cache.json", pos="跳转首访。", deg="前进阅读。", cex="—", cost="—", fail="—",
    obs="真实导航中跳转首访占比。", level="合成", limit="—")

# ---------------------------------------------------------------- F09 证书支持、失效与memo
rec(id="Q049", status="completed", decision="probe_first",
    domain="自动域n=3（600世界全部知识状态）、n=4（300世界×120状态）、形状域n=6/7。",
    A="精确动态读集（与原执行等价）",
    B="逻辑最小充分支持（允许与原执行不同的证明）：分支证书",
    new="C09认证在全部域0次不可靠（Certified即π_t单值）；但有不完备缺口：π_t已唯一而C09仍要事实。n=3: 6352/119264个需事实结果是缺口，分支证书关闭100%；n=4: 4316个缺口关闭4308个，剩8个来自入口过近似（C08）。另：300张证书中69张的分析支持里至少有一个可删事实（检查器仍出证）。",
    disc="bench/exp_certificates.py → raw/gamma/certificates.json（及run1日志）；bench/exp_gamma2.py::g12_checker",
    pos="单项短路：已知侧向否决时不必要邻居几何。", deg="缺口的成员几何部分=0（gap_member_only=0）。",
    cex="world (X,X),(L,L),RTL, 目标0：C09要对象1几何，但单元已定（certificates示例）。", cost="分支证书叶数平均2.8–3.2（模型）。",
    fail="入口过近似缺口分支证书关不掉（8/4316）。", obs="—", level="重建Γ有界穷举", limit="小域")

rec(id="Q050", status="completed", decision="stop",
    domain="400个24对象世界的证书；翻转支持事实并检查目标unit。",
    A="全部尝试依赖的并集+精确验证",
    B="选择过程的证明DAG，按路径条件验证（对照：只验证选中路径）",
    new="只用选中（第一入口）路径的依赖做失效检查，在673次支持外翻转中漏掉29次真实变化（4.3%）；全支持并集0漏。支持外事实翻转4000次从不改变目标unit（支持充分）。",
    disc="bench/exp_gamma2.py::g1_dependencies → raw/gamma/gamma2.json#G1；组合C10", pos="全并集验证。",
    deg="单入口：两者相同。", cex="example_miss：目标17，翻转edge(17,18)，选中路径未读到。", cost="并集更大，验证多读几项。", fail="—", obs="—",
    level="重建Γ", limit="—")

rec(id="Q051", status="completed", decision="stop",
    domain="NeedFacts结果的memo；缺失事实到达。",
    A="区分存在性/值/驻留的版本戳，按读类别订阅",
    B="显式依赖谓词，在新事实满足/破坏谓词时精确更新",
    new="只按正向支持失效的memo永远看不到缺失事实到达：结果停在NeedFacts，而实际已可Certified（活性缺陷）。必须订阅Absent读。",
    disc="bench/exp_gamma2.py::g2_negative → raw/gamma/gamma2.json#G2", pos="订阅Absent键：到达即失效。", deg="无缺失读：两者相同。",
    cex="G2：正向支持不变，缺失分析到达。", cost="订阅表。", fail="—", obs="—", level="重建Γ", limit="—")

rec(id="Q052", status="completed", decision="stop",
    domain="k位修订戳。",
    A="饱和后禁快命中，回到完整支持验证",
    B="代际重新编号/epoch切换，重建活跃依赖",
    new="回绕计数器在恰好2^k次更新后与缓存戳相等（k=4时16次）→假命中；饱和计数器+回退或epoch切换消除假命中，代价分别为全量验证与活跃依赖重建。",
    disc="bench/exp_gamma2.py::g3_stamps → raw/gamma/gamma2.json#G3", pos="<2^k次更新：快路正确。", deg="—",
    cex="16次更新后的回绕假命中。", cost="见上。", fail="—", obs="—", level="推导+穷举", limit="—")

rec(id="Q053", status="completed", decision="probe_first",
    domain="300个60对象稀疏侧向世界；C08入口过近似导致的额外回溯。",
    A="左侧精确checkpoint限制入口集合",
    B="后向约束传播求可达入口关系",
    new="入口过近似使认证在t−2之外再回溯中位1、P90 5、最大14个对象。精确且经身份校验的左侧游标checkpoint把读取限制在局部窗口（C08中位6→5个对象）；单靠更精确的入口关系（无checkpoint）在本域不缩小（C08 B格=0）。正式数据目标169支持150–172（23个对象），重开样本仍20–29轮——没有证据显示实现复用了跨会话checkpoint。",
    disc="bench/exp_gamma2.py::g4_entries; bench/exp_combos.py::c08 → raw/gamma/gamma2.json#G4, raw/combos/combos.json#C08",
    pos="重访/重开时checkpoint有效。", deg="首访：无checkpoint可用。", cex="checkpoint左侧任一对象内容身份改变即失效（W20）。", cost="checkpoint存储+前缀身份校验。",
    fail="频繁替换。", obs="重开跳转169样本的逐轮时刻，判断轮次是否耗时。", level="重建Γ", limit="—")

rec(id="Q054", status="completed", decision="conditional_theory",
    domain="合成导航+缓存模型中“普通证明不够、强证明够”的最短合法状态。",
    A="搜索普通证书不够但强证书足够的最短状态",
    B="重排取证/证明阶段，在不加普通路径税时候选竞争",
    new="最短状态长度1–3步的跳转历史；前进阅读中强证书被采纳31次却省0个物化（它省的是本来就会被可见路径物化的邻居事实）。强证书在轮次上还会因路径依赖多1轮（475 vs 474）。",
    disc="bench/exp_cache.py → raw/cache/cache.json", pos="跳转首访省1个物化。", deg="前进：0。", cex="前进历史：采纳31次，节省0。",
    cost="强证书计算。", fail="—", obs="—", level="合成", limit="—")

# ---------------------------------------------------------------- F10 计划发布、授权与首次正确性
rec(id="Q055", status="completed", decision="stop",
    domain="证书与两个成员资源以任意顺序就绪，两个帧边界。60种交错。",
    A="先发不可曝光计划，资源齐备后原子授权",
    B="资源与证明并行，最终对一致快照单次提交",
    new="证书即曝光在22/60交错中露出部分unit；A、B 0错。A持有计划最多5个事件步，B每帧建一次快照（最多2次）。占位/部分Ready不能当完整ack收益。",
    disc="lab/lifecycle.py::q055 → raw/lifecycle/lifecycle.json#Q055", pos="—", deg="资源先于证书：三者相同。",
    cex="cert, frame1(只有res_a)：部分曝光。", cost="见上。", fail="—", obs="—", level="合成协议穷举", limit="—")

rec(id="Q056", status="completed", decision="stop",
    domain="成员与slot分两次写入时的渲染交错。",
    A="不可分unit描述符（成员/slot/原因/确定性）一次替换",
    B="按来源索引的布局事务，版本校验后一次替换映射",
    new="分字段写在2/6交错中渲染出撕裂unit；A（一次替换不可分描述符）与B（暂存事务、两字段齐后版本提交，渲染只读已提交版本）都0错；B多一个暂存区与1次提交。",
    disc="lab/lifecycle.py::q056 → raw/lifecycle/lifecycle.json#Q056", pos="—", deg="—", cex="upd_members, render, upd_slots。",
    cost="—", fail="—", obs="—", level="合成协议穷举", limit="小")

rec(id="Q057", status="completed", decision="stop",
    domain="用户在对象2时布局从[(0,1),(2,3),(4,5)]变为[(0),(1),(2,3),(4,5)]，然后“下一页”。",
    A="永远以原始item身份发意图，动态映射到当前unit",
    B="持久unit序列+版本桥接重定位",
    new="保持unit下标的导航在布局变化后停留在当前unit(2,3)（应为(4,5)）；A、B都正确。",
    disc="lab/lifecycle.py::q057 → raw/lifecycle/lifecycle.json#Q057", pos="无布局变化：三者一致。", deg="—",
    cex="relayout, nav_next：下标导航得到(2,3)。", cost="B：桥接表。", fail="—", obs="—", level="合成协议穷举", limit="小")

rec(id="Q058", status="completed", decision="stop",
    domain="已曝光unit、后台事实改变计划、用户改设置、渲染。12种交错。",
    A="明确用户意图事务产生新context并撤销旧授权",
    B="版本化输入事件溯源，仅显式语义输入可改布局身份",
    new="任何变化都重排的方案在2/12交错中因后台事实移动已曝光内容；A、B 0错。",
    disc="lab/lifecycle.py::q058 → raw/lifecycle/lifecycle.json#Q058", pos="—", deg="—", cex="bg_fact_changes_plan, render。", cost="A：一次撤销；B：日志。",
    fail="—", obs="—", level="合成协议穷举", limit="—")

rec(id="Q059", status="completed", decision="stop",
    domain="授权后、消费前支持事实或无关事实变化。12种交错。",
    A="提交时验证不可变能力，帧中只消费租约",
    B="按全局修订号快路，失配走完整重新授权",
    new="不验证在4/12交错中消费过期授权；A、B 0错。B在无关变化时也触发完整重查（最多1次），A只验证一次。",
    disc="lab/lifecycle.py::q059 → raw/lifecycle/lifecycle.json#Q059", pos="—", deg="无变化：都直接消费。", cex="authorize, change_support, consume。",
    cost="B：无关变化引起的重查。", fail="—", obs="—", level="合成协议穷举", limit="—")

rec(id="Q060", status="completed", decision="stop",
    domain="预取完成、消费ack、停稳、取消导航的交错。",
    A="消费证明与停稳事件交集后提交进度",
    B="独立幂等进度事务，只接受有效ticket下的用户事件",
    new="预取即记进度在8/12交错中虚报；A、B 0错。",
    disc="lab/lifecycle.py::q060 → raw/lifecycle/lifecycle.json#Q060", pos="—", deg="—", cex="cancel_nav先于settle：仍记进度。", cost="—",
    fail="—", obs="—", level="合成协议穷举", limit="—")
