"""Per-question records F16-F20 (Q091-Q120)."""

R = []


def rec(**k):
    R.append(k)


# ---------------------------------------------------------------- F16 可达时延下界与停止条件
rec(id="Q091", status="completed", decision="probe_first",
    domain="长无reset链：目标的unit依赖链上每个对象；4个在途事实槽。正式目标169：支持150–172（23个对象）。",
    A="不可区分世界证明决策树深度/查询成本下界",
    B="从实际依赖与非抢占服务构造最短可行端点下界",
    new="对手论证：链上任一对象几何翻转都会改变目标unit（G7：m=8/32/128时Θ(m)个unit改变），所以至少需要m个事实；4槽并行下至少⌈m/4⌉轮。C10逐个回退的搜索用m轮。目标169：下界⌈23/4⌉=6轮，观测F0为20–23轮、F1为25–29轮——串行结构与重建模型一致；这些轮次是否耗时不可识别（F1中轮次与时延在跳到29的格子里呈相反关系，例如72轮257.6 ms vs 7轮269.4 ms）。",
    disc="bench/exp_misc.py::q091; bench/exp_gamma2.py::g7_long_output; lab/reach.py::rounds_vs_latency → raw/misc/misc.json#Q091, raw/gamma/gamma2.json#G7, raw/pass1/reach.json",
    pos="m=23：下界6轮。", deg="有真实reset紧邻目标：m小。", cex="把逻辑顺序当物理依赖：并行获取可打破逐个回退（回跳预取把长链最大轮次27→13）。",
    cost="—", fail="服务时长未知时只给轮次下界，不给毫秒。", obs="目标169样本的逐轮need发出/接纳时刻。", level="推导+重建Γ+复算", limit="—")

rec(id="Q092", status="completed", decision="stop",
    domain="300个随机小DAG（1–3通道、释放时刻0/2）的精确最优完工 vs 组合下界。",
    A="工作量/关键链/非抢占阻塞的组合下界",
    B="小域精确调度求解器（允许插入空闲）",
    new="max(总工作/通道, 关键路径)在191/300实例紧，最大差5、平均0.68；不紧时原因是释放时刻与非抢占装箱。另一族（投机+必需链）精确最优=释放+链长，必需优先列表调度后悔最大12。资源天花板只能在合成模型内给出；对真实系统缺服务时长，不能给毫秒天花板。",
    disc="bench/exp_sched.py::s17_bounds,s7_policy_vs_optimum; lab/sched.py::optimal_target_completion → raw/sched/sched.json#S17,S7",
    pos="191个紧实例。", deg="单通道无释放：下界=工作和。", cex="first_non_tight：opt 14 vs 下界12。", cost="精确求解指数级（≤7任务）。",
    fail="—", obs="服务时长分布。", level="合成模型+精确搜索", limit="小实例")

rec(id="Q093", status="completed", decision="stop",
    domain="逐样本下界与整体中位；共同策略约束。",
    A="排序逐样本下界，用次序统计单调性",
    B="联立跨样本共同策略求可行中位",
    new="引理R1（偶数中位公式，已穷举验证）把逐样本下界变成中位下界，但只在一个共同可部署策略同时达到这些下界时有效。构造：两个策略各让24个样本到20 ms，逐样本取最好时中位20 ms（过门槛），任一共同策略中位120 ms（不过）。",
    disc="bench/exp_stats.py::q093; lab/reach.py::lemma_r1_bruteforce → raw/stats/stats.json#Q093, raw/pass1/reach.json", pos="—", deg="单策略：两法一致。",
    cex="上面的P1/P2构造。", cost="—", fail="—", obs="—", level="推导+构造", limit="—")

rec(id="Q094", status="completed", decision="stop",
    domain="合成世界与重建Γ；正式数据中被替代候选R0。",
    A="构造相位传播链族，证明固定窗口不能精确",
    B="寻找真正reset状态，证明域内依赖长度有限",
    new="(1) 链族[X,(Y|X),X×m]：对象1决定整条链的配对相位，m=4..256全部改变末对象unit——任何固定窗口都有反例。(2) 固定回看窗口（单一入口）在长链族300个目标中错误：回看2/3/5/8/16分别错74/55/30/10/4次。(3) 真实对照：R0在目标169上5条新会话跳转发布了[169,170]（正确[168,169]），正是深支持目标（支持150–172）上的首槽错误。(4) reset：强制单独对象与SHAPE_Y都不是完全reset（opening位跨越单步保留），伪reset在形状域392/196例中占92/46例。",
    disc="lab/transducer.py; bench/exp_evidence.py; lab/reach.py::rejected_first_slot → raw/gamma/q097.json, raw/gamma/evidence.json, raw/pass1/reach.json#rejected_R0",
    pos="真reset（前面已有确定双对象unit+边界）：截断安全。", deg="m=0。", cex="opening伪reset：world A（前缀全SHAPE_Y）给(7,LEFT) OPENING，world B给(7,RIGHT) BEFORE_SHAPE_Y。",
    cost="—", fail="—", obs="—", level="重建Γ+历史复算", limit="—")

rec(id="Q095", status="completed", decision="stop",
    domain="主门槛的条件不可达证书。",
    A="从不可移除工作与中位结构推充分不可达条件",
    B="保持语义/资源的最优松弛：若松弛也不达标则证否",
    new="条件NO-GO（每个假设都可观测）：(H1) 若≥25个推进样本的“授权→完整ack”区间>30.2 ms，则任何只改变授权之前工作（事实、证明、调度、缓存）的机制都不能过门槛（引理R1+决策规则）。(H2) 伙伴类机制无条件不可能（残差中位124.4 ms）。(H3) 只作用于跳转的机制无条件不可能（推进组冻结时不可行）。N0给出H1的一个真实同类实例：事实/证明/成员变换在窗口内均为0，完整绘制仍需145.5/154.3 ms——但N0是不同材料与路线，只能支持“H1在已测路线上成立”，不能推广到正式人群。",
    disc="lab/reach.py; lab/n0_structure.py; lab/obsworlds.py → raw/pass1/reach.json, n0_structure.json, obsworlds.json", pos="—", deg="—",
    cex="撤销H1（W_fact_bound世界）：事实侧去除后中位13.4 ms，结论反转。", cost="—", fail="H1未在正式路线上观测。", obs="C_i（授权时刻）。",
    level="推导+复算", limit="条件证书，不是全系统不可能")

rec(id="Q096", status="completed", decision="probe_first",
    domain="多个世界给相反决策时下一步观测的价值。",
    A="使GO/NO-GO固定的最少分辨测试",
    B="按观测成本与最坏决策后悔的稳健下一步",
    new="只有C_i一项能改变主门槛决策：若median(U_i−C_i)>T，停止全部事实侧方向；否则事实侧不可排除，下一步才是逐轮时间戳。逐轮时间戳单独永远不改变主门槛决策（只影响跳转尾部）——它的主门槛价值为0；帧/状态时间戳只在H1被否定后才有用。最佳动作包括停止。",
    disc="bench/exp_misc.py::q010（集合覆盖）; lab/obsworlds.py → raw/misc/misc.json#Q010_Q087", pos="—", deg="—", cex="—", cost="探针成本为相对值。",
    fail="—", obs="C_i。", level="推导", limit="不虚构先验")

# ---------------------------------------------------------------- F17 根本算法：有序精确组合与摘要
rec(id="Q097", status="completed", decision="conditional_theory",
    domain="边界状态(free,opening,reserved)×4 + consumed；形状域n=6、自动域n=4/5穷举。",
    A="按未来输出可区分性求状态等价类",
    B="关系式抽象解释保留必要历史，反例精化（组合测试）",
    new="自动域n=5（有laterWins空间）中5个边界状态两两可区分——游标状态是最小的；但在n=4或自动关闭的域里reservation位不可区分（3类）：有限枚举的域太小会错误地删掉reservation。另需第6个分量：手工起点链的奇偶（S02 previousAccepted）——不带它的区间组合在1500次随机分割中失败114/91次，最小反例n=3；带上后0失败。",
    disc="bench/exp_q097.py, exp_q097b.py; lab/transducer.py → raw/gamma/q097.json, q097b.json", pos="n=5：5类。", deg="n=4：reservation合并。",
    cex="[Y,X,X], manual {1,2}, FIRST_DOUBLE, 在1处分割：不带奇偶的组合把(1,2)对拆开。", cost="状态6分量。", fail="有限枚举不是全域证明。", obs="—",
    level="重建Γ有界穷举", limit="n≤6")

rec(id="Q098", status="completed", decision="conditional_theory",
    domain="区间摘要=入口边界状态→(出口状态, unit)，右侧2对象halo。",
    A="精确转移关系+halo",
    B="闭合区间+延迟边界决策的组合代数",
    new="带(游标状态, 手工奇偶)与2对象halo的区间摘要可结合：形状域与自动域各1500次随机分割（含单对象段、强制单独、手工起点）0失败；摘要树实现与完整计划在2106+240次查询（含更新）中逐个相同。不带奇偶时有最小三段反例（n=3）。",
    disc="lab/transducer.py::composition_test; lab/summarytree.py; bench/exp_summarytree.py → raw/gamma/q097.json（composition_*）, raw/gamma/summarytree_exactness.json", pos="—", deg="单段。",
    cex="见Q097反例。", cost="每叶表10–15项。", fail="—", obs="—", level="重建Γ有界", limit="—")

rec(id="Q099", status="completed", decision="stop",
    domain="平衡摘要树 vs 稀疏检查点 vs 有限入口认证 vs 重扫，n=48/176/1024，3个独立进程。",
    A="平衡摘要树按变更路径更新、目标查询",
    B="稀疏自适应checkpoint/分块memo",
    new="任何规模下树都不胜出：n=176时20次查询树162–166 ms，检查点35–38 ms，认证43 ms；20次更新+查询树292–318 ms，检查点86–101 ms；n=1024认证64–78 ms，检查点87–113 ms，树1238–1355 ms。认证本身已局部；树只在“同一目标反复查询且回溯很长”时有理论意义，而那时检查点更便宜。",
    disc="bench/bench_micro.py → raw/bench/micro_20261027T145403Z.jsonl；bench/exp_combos.py::c18", pos="—", deg="—", cex="—", cost="树建表。",
    fail="Python常数≠原生。", obs="—", level="模型微基准", limit="Python")

rec(id="Q100", status="completed", decision="stop",
    domain="早期一个事实翻转影响长后缀。",
    A="惰性转导，只按目标投影解析",
    B="持久结构共享未变片段，按消费区间增量展开",
    new="翻转对象1改变后续Θ(m)个unit（m=128时129个），目标若在翻转之后，惰性投影仍需Θ(m)事实；省下的只是不消费的unit的构造。组合C09：树把一次早期更新局部到2–3叶（88步含查询）vs 全量重建176步，但消费者只看一个unit，增量展开不缩短可见路径。",
    disc="bench/exp_gamma2.py::g7_long_output; bench/exp_combos.py::c09 → raw/gamma/gamma2.json#G7, raw/combos/combos.json#C09",
    pos="目标在翻转之前：0工作。", deg="—", cex="目标在翻转之后：Θ(m)。", cost="—", fail="—", obs="—", level="重建Γ", limit="—")

rec(id="Q101", status="completed", decision="conditional_theory",
    domain="目标投影查询能否绕过全局计划。",
    A="双向边界约束传播（这里：全部入口+分支）",
    B="局部证明搜索+全局一致性摘要（分支证书）",
    new="分支证书（对未知事实做情形分析、保持C08入口）关闭了全部“顺序/短路”缺口（n=3全部6352个、n=4中4308/4316），剩余8个缺口来自入口过近似，只有左侧精确checkpoint能关。全局分区不同而目标相同的世界大量存在（这就是缺口的来源）。计算代价：Python模型中比C09慢约100倍。",
    disc="lab/certify_plus.py; bench/exp_certificates.py; bench/bench_micro.py(W_b) → raw/gamma/certificates.json, raw/bench/micro_*.jsonl",
    pos="见缺口关闭。", deg="—", cex="入口过近似的8例。", cost="叶数平均≈3。", fail="—", obs="—", level="重建Γ有界穷举", limit="小域")

rec(id="Q102", status="completed", decision="conditional_theory",
    domain="Route B替代规则Γ′，300个30对象世界。",
    A="Γ′_DP：受Γ允许谓词约束的最大配对数，词典序同分",
    B="Γ′_local：局部极大强度配对（左优先），可证有界依赖",
    new="Γ′_local与Γ在292/300个计划中不同，配对数2326 vs 2968；对象1翻转影响的最远unit：Γ′_local 3、Γ 7、Γ′_DP 11（DP更长依赖）。Γ′_local的局部可认证性是唯一被证明的性质；没有品质标注，不能说任何Γ′更好。全部待裁定，不能当Route A收益。",
    disc="bench/exp_gamma2.py::g8_alternatives → raw/gamma/gamma2.json#G8", pos="—", deg="全SHAPE_Y：三者相同。", cex="Γ′_DP依赖长度11>Γ。",
    cost="—", fail="—", obs="品质标注（委托方）。", level="重建Γ+替代规则", limit="Route B")

# ---------------------------------------------------------------- F18 最少取证、可能世界与信息下界
rec(id="Q103", status="completed", decision="conditional_theory",
    domain="D04方向分析与D05距离的可执行重述+声明的条带采样布局。",
    A="由同一底层材料生成相容世界（构造性见证）",
    B="已证必要关系约束（值域/格点）作保守关系域",
    new="在声明布局下，(方向前, 方向后, 有/无分数)全部36种组合都有构造性见证——边际组合层面不存在“独立乱填”造成的伪歧义。真正的物理约束在值域：分数=s/50，0≤s<1500（所以<30且非负）、空值有三种来源；分支证书用的分数域就是这个格点。3000个随机生成世界漏掉了3种可实现组合——随机生成不能当可实现性证明。",
    disc="lab/features.py::witness, realizable_pairs → （测试 tests/test_r10.py::Features）", pos="36/36见证。", deg="—",
    cex="随机生成器从未产生(LEFT,LEFT,score)，但构造见证存在。", cost="—", fail="布局是声明假设。", obs="真实采样布局（不在包内）。",
    level="可执行重述", limit="布局假设")

rec(id="Q104", status="completed", decision="conditional_theory",
    domain="自动域n=3（1944世界），目标1，相对成本：header 1、边样本3、分析5。",
    A="世界对上的加权hitting-set（固定集合）",
    B="目标输出等价类上的自适应决策树",
    new="自适应最优最坏成本13（5次查询）；非自适应最小固定集合6个事实、成本18。自适应节省5/18。共享物化（一个物化产出多个事实）在Q033中另省物化。",
    disc="bench/exp_gamma2.py::g9_minimax → raw/gamma/gamma2.json#G9", pos="—", deg="—", cex="—", cost="精确求解只限小域。", fail="—",
    obs="—", level="重建Γ穷举", limit="n=3")

rec(id="Q105", status="completed", decision="conditional_theory",
    domain="同Q104。",
    A="成本归一信息增益/分裂贪心（明确均匀先验）",
    B="直接优化单输出证书的最坏完成成本",
    new="对目标投影的熵贪心在该域与最优相同（13）；对整个世界的熵贪心（不看目标）最坏成本24、8次查询，比最优差85%。高熵但与目标无关的事实会误导“总熵”贪心。",
    disc="bench/exp_gamma2.py::g9_minimax → raw/gamma/gamma2.json#G9", pos="目标熵贪心=最优。", deg="—", cex="总熵贪心24 vs 13。",
    cost="—", fail="更大域中目标熵贪心也可能失败（未测）。", obs="—", level="重建Γ穷举", limit="n=3")

rec(id="Q106", status="completed", decision="probe_first",
    domain="三族合成世界×300：逐轮自适应（4槽、1槽）vs 有界批量回跳预取。",
    A="逐步消歧后补位的自适应查询",
    B="有界并行批次/流水查询",
    new="4槽对1槽：中位轮次5 vs 8（长链）。批量回跳预取：长链最大轮次27→13，239/300世界更少轮次、0更多；书页族浪费中位2个物化。批中慢且无关的任务不能设整批屏障（轮次模型中轮=批内最慢）。",
    disc="bench/exp_evidence.py; bench/exp_combos.py::c11 → raw/gamma/evidence.json, raw/combos/combos.json#C11", pos="长链。", deg="短支持。",
    cex="书页族：只有浪费（W20）。", cost="浪费物化。", fail="轮次不耗时则无收益。", obs="逐轮时刻。", level="重建Γ+合成", limit="—")

rec(id="Q107", status="completed", decision="conditional_theory",
    domain="便宜信息（header几何）能否替代昂贵事实（分析/边样本）。",
    A="证明便宜特征对目标充分并发证书",
    B="两阶段：便宜特征只过滤，残余歧义取精确信息",
    new="自动关闭时充分（300/300）；自动开启时只29/300。反例：几何全同、一个对象的方向不同就改变目标unit。新风险：若header几何能与解码几何不一致而通过身份检查，A会发布错误首槽（C12：238/800）；B（只过滤）没有这个风险。",
    disc="bench/exp_gamma2.py::g10_cheap; bench/exp_combos.py::c12 → raw/gamma/gamma2.json#G10, raw/combos/combos.json#C12", pos="自动关闭域。",
    deg="—", cex="same_dims_different_unit。", cost="—", fail="坏metadata。", obs="header/解码几何不一致计数。", level="重建Γ", limit="—")

rec(id="Q108", status="completed", decision="conditional_theory",
    domain="证书复用（C12当前性检查）vs 数据复用（重建证书）。",
    A="证明携带稳定支持，命中后只取消费资源",
    B="保留中间材料重建证书",
    new="三域：(1) 支持未变：当前性检查约4.6–5.1 ms/60证书 vs 重建79–99 ms（Python）——证明复用占优；(2) 内容身份变但值同：授权必须重签，数据可复用——材料复用占优；(3) 内容变：两者都无益。",
    disc="bench/bench_micro.py(W_d); bench/exp_gamma2.py::g6_identity → raw/bench/micro_*.jsonl, raw/gamma/gamma2.json#G6", pos="—", deg="—",
    cex="旧证明直接给新ticket：被身份检查拒绝。", cost="—", fail="—", obs="—", level="重建Γ+微基准", limit="Python")

# ---------------------------------------------------------------- F19 在线联合策略与稳健优化
rec(id="Q109", status="completed", decision="conditional_theory",
    domain="容量2，请求序列x,a,b,a,b,a,b,x，重建成本x=20、a=b=1。",
    A="有限域精确联合策略（价值保留）",
    B="分层在线：可见需求硬优先，按重建成本保留",
    new="命中率最大的LRU（4次命中）总重建成本42，价值策略（1次命中）26：命中率与完整时延冲突。可见需求固定顺序时调度不再加值（C06交互0）。",
    disc="bench/exp_sched.py::s18_joint; bench/exp_combos.py::c06 → raw/sched/sched.json#S18", pos="—", deg="成本相同：LRU最优。",
    cex="上面序列。", cost="—", fail="—", obs="重建成本分布。", level="合成", limit="—")

rec(id="Q110", status="completed", decision="engineering_trial",
    domain="4个投机作业（5/50/500）占满工人，必需任务t=3到达。",
    A="隔离投机预算（预算2<工人4）",
    B="门控：只准入可撤回/短服务投机",
    new="无保护阻塞2/47/497；预算2在三种服务下阻塞都为0；短作业门控在服务5时阻塞2（门槛10内的短作业仍会占满）、50/500时0。没有服务上界就不存在统一有限阻塞保证；预算是与服务时长无关的保护。",
    disc="bench/exp_sched.py::s19_speculation; bench/exp_combos.py::c27 → raw/sched/sched.json#S19", pos="预算。", deg="投机少于工人。",
    cex="无保护+服务500：阻塞497。", cost="预算降低投机吞吐。", fail="—", obs="—", level="合成", limit="—")

rec(id="Q111", status="completed", decision="conditional_theory",
    domain="方向预测预取（每步1个额外物化）在稳定/交替/漂移序列。",
    A="分布无关竞争/对抗分析",
    B="歧义分布集合上的稳健优化与在线校准",
    new="稳定：20命中0浪费；每步反向：1命中19浪费；10步后漂移：19命中1浪费。对自适应对手任何预测策略浪费率可达1；预算只能封住绝对浪费。",
    disc="bench/exp_misc.py::q111 → raw/misc/misc.json#Q111", pos="—", deg="—", cex="交替序列。", cost="—", fail="—", obs="真实方向反转频率。",
    level="推导+模拟", limit="—")

rec(id="Q112", status="completed", decision="stop",
    domain="12 MiB解码对象同时被物化缓存与样本缓存引用，32 MiB窗口。",
    A="多资源影子价格/预算优化",
    B="分区保留+借用，单一所有权守恒账",
    new="朴素逐资源求和记24 MiB，挡住第二个12 MiB对象；单一所有者账本记12 MiB，可以准入。去重只有在唯一物理所有者下才合法；虚拟配额不是常驻。",
    disc="bench/exp_sched.py::s21_dual_budget; bench/exp_combos.py::c17 → raw/sched/sched.json#S21", pos="—", deg="不共享：两法相同。",
    cex="双重计数挡住准入。", cost="所有权表。", fail="—", obs="—", level="推导", limit="—")

rec(id="Q113", status="completed", decision="conditional_theory",
    domain="在线学习投机命中率（真值0.3）。",
    A="只学习调度/缓存价值，Γ与授权不受影响",
    B="影子策略先观察反事实，有界门控启用",
    new="随机准入下估计0.301；反馈准入（只在上次命中后准入）估计0.395——学习器被自己的准入偏置。语义安全不等于估计无偏；B的反事实只在影子中可观测。",
    disc="bench/exp_misc.py::q113_q114 → raw/misc/misc.json#Q113_Q114", pos="随机准入。", deg="—", cex="反馈准入。", cost="影子计算。", fail="—", obs="—",
    level="模拟", limit="—")

rec(id="Q114", status="completed", decision="conditional_theory",
    domain="门控：连赢2次开启、输1次关闭；结果序列赢赢输重复，40步。",
    A="按可证前提与资源状态启用，前提不满足立即回现行路径",
    B="短期租约/熔断门控，独立成本账与幂等恢复",
    new="该序列下门控切换26次（每3步约2次）；每次切换的建立/拆除都要计成本。需要迟滞（k次赢开、m次输关）。",
    disc="bench/exp_misc.py::q113_q114 → raw/misc/misc.json#Q113_Q114", pos="—", deg="稳定结果：切换0。", cex="赢赢输序列。", cost="切换税。", fail="—",
    obs="—", level="模拟", limit="—")

# ---------------------------------------------------------------- F20 表示、数值、证明工程与迁移
rec(id="Q115", status="completed", decision="stop",
    domain="D05距离：标量早拒 vs 全量批算；3000对随机条带；3进程微基准。",
    A="保留精确公式的标量早拒",
    B="证明等价的批量/向量化计算",
    new="早拒访问55978点，全量150000点（37%）；结果在3000对上完全一致。Python中早拒11–16 ms、全量求和10.6–13.6 ms/200对——表示开销淹没了点数节省；精确有理数慢约2倍。没有稳定的完整路径头寸（与历史“查表/批量无稳定净益”一致）。",
    disc="bench/exp_gamma2.py::g11_numeric; bench/bench_micro.py(W_c) → raw/gamma/gamma2.json#G11, raw/bench/micro_*.jsonl", pos="—", deg="—",
    cex="—", cost="—", fail="—", obs="—", level="可执行重述+微基准", limit="Python")

rec(id="Q116", status="completed", decision="engineering_trial",
    domain="D05方差门（两侧方差<100→无分数）在浮点与精确求值下。",
    A="保持整数/有界精确算术及固定求值序列",
    B="误差区间快路，靠近阈值回退到参考求值",
    new="可实现的灰阶条带（两个灰度相差20、各25点）精确方差恰为100：精确求值给分数，参考浮点求值（.299/.587/.114，均方−均值²）得99.99999999999909而判“无分数”；25个灰度中9个翻转。翻转改变Γ输出：同一世界中目标1由单独MATCH_BOUNDARY变成(1,2)对。因为契约就是参考浮点求值，A的“精确算术”反而会改变结果；安全做法是B：只在离阈值足够远时用快路，近阈值时回到参考浮点序列。",
    disc="lab/features.py::distance, search_float_flip; bench/exp_gamma2.py::g11_numeric → raw/gamma/gamma2.json#G11", pos="随机3000对：一致。",
    deg="远离阈值。", cex="灰度37/51/107/114/128/149…的两灰阶条带。", cost="近阈值回退的额外计算。", fail="跨后端（SIMD/float32/重排求和）都可能翻转。",
    obs="—", level="可执行重述+构造", limit="—")

rec(id="Q117", status="completed", decision="conditional_theory",
    domain="证书携带证明（独立检查器只用支持事实重放C07–C10）vs 受信构建+版本戳快路。",
    A="小证明对象+独立检查器",
    B="受信构建+版本戳快路，失效时完整重算",
    new="检查器300/300接受真证书、300/300拒绝伪造unit、231/300拒绝删去一个分析支持的证书（其余69张说明支持有冗余）；版本戳快路不检查unit，伪造在戳未变时被接受。检查成本≈构建成本（Python 94–116 vs 79–99 ms/60）：证明不比重算便宜，价值在可审计性。",
    disc="bench/exp_gamma2.py::g12_checker; bench/bench_micro.py(W_d) → raw/gamma/gamma2.json#G12", pos="—", deg="—", cex="伪造unit。", cost="—",
    fail="检查器本身要语义正确。", obs="—", level="重建Γ+微基准", limit="—")

rec(id="Q118", status="completed", decision="probe_first",
    domain="从模型到真实消费者的精化义务。",
    A="逐层精化：Γ→证书→资源→授权→完整ack",
    B="关系式差分重放：同输入比较现行与候选的可见历史与账本",
    new="已覆盖：Γ重建与上一包参照差分20000例0差异；证书可靠性有界穷举0例；协议层每个朴素实现都被测试抓住（tests/test_r10.py中的“故意破坏接线”断言）。未覆盖（必须由工程补）：真实采样布局、物化/解码、帧提交、回执归属、header与解码几何一致性、实际缓存策略、计时。最小工程验证清单见报告第6节。",
    disc="tests/test_r10.py; lab/gamma_xcheck.py → raw/gamma/xcheck_r9.json", pos="—", deg="—", cex="frame_id_only等朴素接线：测试失败（预期）。", cost="—",
    fail="—", obs="见清单。", level="测试+推导", limit="—")

rec(id="Q119", status="completed", decision="engineering_trial",
    domain="保持Γ的结构重写如何小范围试验。",
    A="旁路shadow计算，比较结果，当前路径仍唯一授权",
    B="按可证封闭输入域启用，域外精确回退",
    new="shadow的税可量化：分支证书在Python模型中约100倍于C09；B的封闭域必须排除坏metadata（C12）且有明确进出条件（门控迟滞，Q114）。推荐：对资源侧候选（物理预留、结果池）用B（配置开关，语义不变）；对证书侧候选只做shadow，不授权。",
    disc="bench/bench_micro.py(W_b); bench/exp_combos.py::c12; bench/exp_misc.py::q113_q114", pos="—", deg="—", cex="shadow比较一致≠全域等价（有界）。",
    cost="shadow计算税。", fail="—", obs="—", level="推导+微基准", limit="—")

rec(id="Q120", status="completed", decision="stop",
    domain="前沿候选的去重与自我攻击。",
    A="按可观察干预/新增可达状态/成本项建立机制等价类",
    B="对抗搜索选最能推翻候选的输入",
    new="去重：回跳倍增预取与历史“加宽取证/重试窗口”属于同一等价类（都是提前取左侧事实），新意只在倍增与4槽上限——降为“先补观测”；分支证书与“更强起点/入口证明”同类（避免部分事实获取），模型重现正常路线0收益——降为条件理论；身份校验游标checkpoint部分被“精确支持/修订戳快命中”覆盖（需前缀身份），新增在跨会话复用——先补观测。对抗：预取在书页族只有浪费；checkpoint在频繁替换下命中0；物理预留在短会话中空闲25%；分支证书前进阅读省0。没有候选触及主门槛。",
    disc="bench/exp_workloads.py::w20_frontier_attack → raw/workloads/workloads.json#W20_frontier_attack", pos="—", deg="—", cex="见W20。", cost="—",
    fail="—", obs="—", level="汇总", limit="—")
