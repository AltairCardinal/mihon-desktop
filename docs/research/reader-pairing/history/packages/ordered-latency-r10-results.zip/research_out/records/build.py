"""Render the per-question records into: coverage.csv (template columns, 150 rows), coverage_detail.csv,
sections/QUESTIONS_DETAIL.md, sections/COMBINATIONS_DETAIL.md, summary/coverage_counts.json.
Usage: python3 -B research_out/records/build.py
"""
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
PKG = OUT.parent
sys.path.insert(0, str(HERE))
from rec_f01_f05 import R as R1
from rec_f06_f10 import R as R2
from rec_f11_f15 import R as R3
from rec_f16_f20 import R as R4
from rec_combos import R as RC
from patches import P as PATCHES

STATUS = {"not_started", "incomplete", "completed"}
DECISION = {"engineering_trial", "probe_first", "conditional_theory", "stop", "unresolved"}


def short_mech(s):
    return s.split("：")[0].split(":")[0].strip()[:60]


def main():
    recs = {r["id"]: r for r in R1 + R2 + R3 + R4 + RC}
    for k, v in PATCHES.items():
        recs[k].update(v)
    for r in RC:
        r.update(PATCHES.get(r["id"], {}))
    template = list(csv.DictReader(open(PKG / "coverage-template.csv", encoding="utf-8")))
    assert len(template) == 150
    missing = [t["id"] for t in template if t["id"] not in recs]
    extra = [k for k in recs if k not in {t["id"] for t in template}]
    assert not extra, extra
    for r in recs.values():
        assert r["status"] in STATUS and r["decision"] in DECISION, r["id"]
        if r["status"] == "completed":
            for k in ("A", "B", "new", "disc", "pos", "deg", "cex"):
                assert r.get(k) and r[k].strip() not in ("—", "-"), (r["id"], k)
    rows, detail = [], []
    for t in template:
        r = recs.get(t["id"])
        if r is None:
            rows.append(t)
            continue
        row = dict(t)
        row["status"] = r["status"]
        row["route_a"] = short_mech(r["A"])
        row["route_b"] = short_mech(r["B"])
        row["evidence"] = r["disc"]
        row["decision"] = r["decision"]
        row["limit"] = (r.get("level", "") + "；" + r.get("limit", "")).strip("；")
        rows.append(row)
        detail.append({**row, "new_conclusion": r["new"], "positive": r.get("pos", ""), "degenerate": r.get("deg", ""),
                       "min_counterexample": r.get("cex", ""), "cost": r.get("cost", ""), "failure_boundary": r.get("fail", ""),
                       "needed_observation": r.get("obs", ""), "resume": r.get("resume", "")})
    with open(OUT / "coverage.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(template[0].keys()), quoting=csv.QUOTE_ALL)
        w.writeheader()
        w.writerows(rows)
    with open(OUT / "coverage_detail.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(detail[0].keys()), quoting=csv.QUOTE_ALL)
        w.writeheader()
        w.writerows(detail)
    counts = {}
    for typ in ("primary", "combination"):
        sub = [r for r in rows if r["type"] == typ]
        counts[typ] = {"rows": len(sub), **{s: sum(r["status"] == s for r in sub) for s in sorted(STATUS)},
                       "decision": {d: sum(r["decision"] == d for r in sub) for d in sorted(DECISION)}}
    counts["missing_records"] = missing
    (OUT / "summary").mkdir(exist_ok=True)
    (OUT / "summary/coverage_counts.json").write_text(json.dumps(counts, ensure_ascii=False, indent=1), encoding="utf-8")

    qi = json.load(open(OUT / "summary/questions_index.json", encoding="utf-8"))
    fam = {}
    for t in template:
        if t["type"] == "primary":
            fam.setdefault(t["family"], []).append(t["id"])
    lines = ["# 逐题详细记录（120主课题）", "",
             "每题：域、两条机制路线、新增结论、可执行判别/推导（代码→原始结果）、正例/退化例/最小反例、成本、失败边界、所需新增观测、裁定。",
             "证据等级与适用域见每题末行。状态与裁定与 `coverage.csv` 一致（由同一记录生成）。", ""]
    for f_, ids in fam.items():
        lines.append(f"## {f_}")
        lines.append("")
        for q in ids:
            r = recs[q]
            lines += [f"### {q} {qi[q]['title']}", "",
                      f"- 状态/裁定：**{r['status']} / {r['decision']}**",
                      f"- 域：{r['domain']}",
                      f"- 路线A：{r['A']}",
                      f"- 路线B：{r['B']}",
                      f"- 新增结论：{r['new']}",
                      f"- 判别（代码→原始结果）：`{r['disc']}`",
                      f"- 正例：{r['pos']}；退化例：{r['deg']}；最小反例：{r['cex']}",
                      f"- 成本：{r['cost']}；失败边界：{r['fail']}",
                      f"- 所需新增观测：{r['obs']}",
                      f"- 证据等级/适用域：{r.get('level','')}；{r.get('limit','')}"]
            if r.get("resume"):
                lines.append(f"- 未完成，恢复：{r['resume']}")
            lines.append("")
    (OUT / "sections").mkdir(exist_ok=True)
    (OUT / "sections/QUESTIONS_DETAIL.md").write_text("\n".join(lines), encoding="utf-8")

    combos = json.load(open(OUT / "raw/combos/combos.json", encoding="utf-8"))
    cl = ["# 30个耦合课题：同一模型四格（0/A/B/AB）与两种联合设计", "",
          "AB_I、AB_II是两种实质不同的联合架构；交互项 I = f(AB) − f(A) − f(B) + f(0)，f为每行声明的标量。单位见每行。", ""]
    for r in RC:
        c = combos.get(r["id"], {})
        cells = c.get("cells", {})
        cl += [f"## {r['id']} {r['title']}", "",
               f"- 状态/裁定：**{r['status']} / {r['decision']}**；证据：{r['level']}（{r['limit']}）",
               f"- 干预：{r['A']}", f"- 联合设计：{r['B']}",
               f"- 标量f：{c.get('metric','')}",
               "", "| 0 | A | B | AB_I | AB_II | 交互(AB_I) | 交互(AB_II) |", "|---|---|---|---|---|---|---|",
               "| " + " | ".join(str(cells.get(k, "")) for k in ("0", "A", "B", "AB_I", "AB_II")) +
               f" | {c.get('interaction_on_AB_I','')} | {c.get('interaction_on_AB_II','')} |", "",
               f"- 结论：{r['new']}",
               f"- 代码/原始：`{r['disc']}`"] + ([f"- 未完成：{r['resume']}"] if r.get("resume") else []) + [""]
    (OUT / "sections/COMBINATIONS_DETAIL.md").write_text("\n".join(cl), encoding="utf-8")
    print(json.dumps(counts, ensure_ascii=False))


if __name__ == "__main__":
    main()
