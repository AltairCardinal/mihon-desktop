"""Per-question records F01-F05 (Q001-Q030). Rendered by records/build.py. Every pointer is a file under research_out/."""

R = []


def rec(**k):
    R.append(k)


# ---------------------------------------------------------------- F01 端点与身份
rec(id="Q001", status="completed", decision="stop",
    domain="一个unit{a,b}在ticket k1下授权；旧ticket k0复用帧号F1也绘制a、b；回执可重复。全部90种合法交错。",
    A="A_ticket_member_barrier：授权时固定必要成员集合，按(ticket,frame)收齐才算完成",
    B="B_commit_carries_unit：帧提交携带unit承诺(ticket,members)，一次验证",
    new="仅看帧号会在44/90种交错中误判完成，按回执计数在30/90中误判；两条路线都0误判。完整确认的最小充分判据是(ticket,成员集合,同一提交帧)三者，缺任何一项都有反例。",
    disc="lab/lifecycle.py::q001 → raw/lifecycle/lifecycle.json#Q001（有界穷举：90个线性扩展）",
    pos="k1的a、b在F2各绘制一次：两路线在第二个回执处判完成。",
    deg="没有旧ticket、没有重复回执时，四种判据结果相同（退化域）。",
    cex="顺序 draw_a_k0_F1, draw_b_k0_F1 先到：frame_id_only在旧ticket上判完成（最小反例，见first_counterexample）。",
    cost="A：每ticket一个成员集合与每帧位图；B：提交对象多带一份成员承诺，验证一次。两者都不增加物理工作。",
    fail="若渲染器不能把回执归属到ticket（只给帧号），A、B都无法实现；需要合同保证回执携带ticket。",
    obs="真实回执是否携带ticket与帧号（正式数据有target_ticket/unit_ticket/frame字段，说明可得）。",
    level="合成协议有界穷举", limit="单unit两成员；未覆盖跨窗口多显示器")

rec(id="Q002", status="completed", decision="stop",
    domain="完成结果接纳：同值内容替换、rebind、两次尝试；另一场景为同内容同代际下的重试。",
    A="A_capability_token：层级不可变令牌(content,generation,attempt)",
    B="B_version_vector_readset：读集版本向量(content,generation)+提交时校验",
    new="按值相等接纳在替换场景20/24、重试场景3/4种交错中接纳错误结果。路线B（读集版本向量）在替换场景0错，但在同内容同代际的重试场景3/4错——尝试号不是读集的一部分；B补上尝试令牌后0错，此时与A等价。最小身份代数=(content,generation,attempt)；与R9零耗时证明缺陷同型：时间或读集不能代替尝试身份。",
    disc="lab/lifecycle.py::q002（两个场景）→ raw/lifecycle/lifecycle.json#Q002",
    pos="尝试2在替换后开始并完成：只有尝试2被接纳。", deg="无替换无重试：所有方案一致。",
    cex="start1, retry, start2, done1：content+gen方案接纳了过期的尝试1。",
    cost="每结果多携带一个单调尝试序号；校验O(1)。", fail="尝试序号若可回绕或跨rebind重置，需改为(epoch,serial)。",
    obs="无需新增观测；需核对实现中重试是否分配新尝试号。", level="合成协议有界穷举", limit="单对象")

rec(id="Q003", status="completed", decision="stop",
    domain="不同clock_scope之间的时间关联；正式F0/F1各自平移的时钟；双时钟加消息往返的合成模型。",
    A="同进程单调时钟+显式因果关联（只在同scope相减）",
    B="独立时钟的区间约束：往返消息给出偏移区间[lo,hi]，只推偏序与可识别范围",
    new="正式数据中同ID的F1-F0意图时刻差从-1.80 s到+0.73 s，跨scope相减无意义（已被包内elapsed拒绝）。区间法在200次合成试验中全部包含真实偏移；单程相减误差等于偏移(7.3 ms)。结论：不要追求跨scope拼接，任何跨进程比较只用同ID各自时长。",
    disc="bench/exp_lifecycle.py::q003 → raw/lifecycle/lifecycle.json#Q003；code/causal.py::elapsed",
    pos="同scope内intent→ack相减（正式数据全部如此）。", deg="偏移为0且往返对称时两法相同。",
    cex="同ID q001：F1.intent−F0.intent为负数秒级，显然不是时延。", cost="区间法需要每个跨时钟边一个往返消息。",
    fail="往返不对称时区间变宽，最坏宽度=RTT。", obs="无（停止该方向）。", level="历史复算+合成模型", limit="不研究时钟漂移的长期估计")

rec(id="Q004", status="completed", decision="stop",
    domain="新runtime跳转与同进程重开（含1.24–1.89 s预热）在正式数据中的完整时延；预建成本的M次摊销。",
    A="意图触发的惰性建立并全程计费",
    B="显式持久预建，按首次与M次分别记账",
    new="四个格子（F0/F1 × 目标29/169）中，重开的完整unit中位时延都不比新runtime快（例如F0目标29：300.2 vs 253.9 ms；F1目标169：593.0 vs 583.1 ms），而重开另付1.28–1.80 s预热。没有可摊销的收益：盈亏点M*=P/s在s≤0时不存在。",
    disc="bench/exp_lifecycle.py::q004 → raw/lifecycle/lifecycle.json#Q004（正式数据重算）",
    pos="若某格重开快s>0，M*=P/s次后回本（公式）。", deg="P=0时两路线等价。",
    cex="F0/169：重开744.9 ms > 新runtime 692.0 ms，预热1.80 s。", cost="预热时间与常驻；本数据中只有成本无收益。",
    fail="历史两臂非随机交错，差异含环境漂移；结论只到“看不到收益”。", obs="若要复核：同session内ABBA交错重开/新开。",
    level="匿名历史复算", limit="10条/格")

rec(id="Q005", status="completed", decision="stop",
    domain="证书需要对象A、B同一版本的事实；A的内容在中途被替换（v1→v2）。20种交错。",
    A="A_two_phase_commit_check：事实并行准备，提交点原子校验当前版本",
    B="B_snapshot_cut_inherit：不可变快照cut，替换产生新cut并继承未变对象的事实",
    new="逐事实接纳在3/20种交错中发布撕裂证书；A、B都0错。新发现：朴素快照（替换时开空cut）不会出错但在2/20种交错中丢掉仍有效的B事实，造成多余重取（活性/时延损失，非安全问题）。",
    disc="lab/lifecycle.py::q005 → raw/lifecycle/lifecycle.json#Q005",
    pos="无替换：都在certify时发布。", deg="替换发生在所有事实之前：所有方案等价。",
    cex="factA_v1, factB_v1, replaceA, factA_v2, certify：朴素空cut方案等待，正确答案为发布。", cost="A：提交时一次版本比较；B：每次替换一次cut复制（10次/20交错）。",
    fail="若事实接纳本身不带版本，两路线都不可行。", obs="无。", level="合成协议有界穷举", limit="两对象")

rec(id="Q006", status="completed", decision="stop",
    domain="旧unit U1已露出成员a；后台事实变化产生U2新证书；b稍后绘制或用户离开。8种交错。",
    A="A_frame_lease：帧级租约保持旧消费能力，新ticket独立",
    B="B_multiversion_snapshot：多版本布局快照+源item导航映射",
    new="新证书即撤销旧ticket在1/8交错中把已露出的unit留成半边/移动；A、B 0错。代价不同：A只保持一个旧租约到离开（最多3个事件步），B常驻两个布局版本。",
    disc="lab/lifecycle.py::q006 → raw/lifecycle/lifecycle.json#Q006；组合C14",
    pos="b在离开前绘制：U1完整。", deg="离开先于新证书：无冲突。", cex="draw_a, new_cert, draw_b：撤销方案得到blank_b/moved。",
    cost="A：旧ticket租约在新证书后最多再存活2个事件步；B：最多2个布局快照常驻。", fail="若帧消费能力不能与ticket解耦则A不可行。", obs="无。", level="合成协议有界穷举", limit="单unit")

# ---------------------------------------------------------------- F02 稀疏事件与可识别性
rec(id="Q007", status="completed", decision="probe_first",
    domain="正式F0全部50条：已记录意图、首成员ack、完整ack、rounds、support；缺队列/读取/事实/证书/提交时刻。",
    A="枚举相容DAG（显式合成世界，用包内causal.bounds），求同一干预的结果区间",
    B="结构因果模型式构造：观测等价的三个世界（事实主导/消费主导/中间）",
    new="三个世界逐条复现全部已记录字段，但对“事实侧工作全部消除”这一干预给出候选中位13.4 ms（过门槛）、127.6 ms与65.1 ms（不过）。因此“事实侧能否达标”在正式数据上不可识别。唯一能固定该决策的新增字段是每样本的授权时刻C_i（同scope、同ticket）：若median(U_i−C_i)>30196850 ns，则事实/证明/调度侧机制一律不可能过门槛。",
    disc="lab/obsworlds.py → raw/pass1/obsworlds.json", pos="W_fact_bound：去除事实工作后中位13.4 ms。",
    deg="事实占比0时所有事实侧干预无效。", cex="W_consume_bound与W_fact_bound观测完全相同，干预结论相反。",
    cost="无运行成本；观测提案：每样本一个时间戳。", fail="若授权时刻本身不可在同scope观测，则只能保留不可识别。",
    obs="C_i：确切unit被授权（证书可用于提交）的单调时刻，带ticket关联。", level="推导+显式合成世界", limit="世界时长是假设参数，非拟合")

rec(id="Q008", status="completed", decision="conditional_theory",
    domain="N0目标窗口中只有起点的source_open标记（对象13、14），后续有变换开始与首成员ack。",
    A="差分约束（STN）闭包：服务区间∈[0, 下一依赖事件−起点]",
    B="加资源互斥（单通道读取）的析取约束，求更紧排程",
    new="STN给出两个打开的服务上界分别为592.6 µs与579.5 µs；若假设单通道读取，第一个打开的上界收紧到41.6 µs。后者依赖未观测的资源假设，只能作条件结论；未观测≠0。",
    disc="bench/exp_misc.py::q008 → raw/misc/misc.json#Q008", pos="有终点的变换调用：区间精确。",
    deg="只有一个打开时两法相同。", cex="若读取实际双通道，单通道上界41.6 µs是错误的（两个打开相距41.6 µs）。",
    cost="无。", fail="资源假设不成立时B错误。", obs="source读取结束标记或字节完成事件。", level="匿名历史复算（N0）", limit="N0为不同材料")

rec(id="Q009", status="completed", decision="probe_first",
    domain="同一(stage,object,purpose)键的k个开始与k个完成，无尝试身份。",
    A="带基数与因果(start≤end)约束的二分匹配，列出全部相容匹配",
    B="为每个物理工作发因果令牌（尝试号），消费侧引用而非猜接",
    new="3开始/3完成的例子有6种相容匹配，第一尝试的服务时长可为6、8或9，FIFO与LIFO给出不同时长；区间并集不变。包内join_operations正确地把重复键标为ambiguous。B消除歧义，代价是每工作一个令牌。",
    disc="bench/exp_misc.py::q009；bench/exp_workloads.py::w18_sparse_wrong → raw/misc/misc.json#Q009, raw/workloads/workloads.json",
    pos="键唯一：一种匹配。", deg="k=1。", cex="starts [0,5], ends [7,9]：FIFO得[7,4]，LIFO得[9,2]。",
    cost="B：每次物理工作多一个ID字段。", fail="只有区间并集可用于“服务覆盖”，不可用于逐尝试时长。", obs="尝试ID写入start/complete标记。",
    level="推导+穷举", limit="小k")

rec(id="Q010", status="completed", decision="probe_first",
    domain="候选世界：事实主导/消费主导/中间（GO/NO-GO分歧）+轮次串行/并行（批量化问题）。",
    A="加权集合覆盖：选最少成本探针分开所有需分开的世界对",
    B="自适应：先测C_i，仅当上下界跨门槛才加逐轮时间戳",
    new="已记录字段（rounds、support）分不开任何一对。最小成本集合={授权时刻C_i, 逐轮need发出/事实接纳时间戳}（成本3）。自适应计划在C_i已判NO-GO时可停在成本1。",
    disc="bench/exp_misc.py::q010 → raw/misc/misc.json#Q010_Q087", pos="C_i一项即分开事实主导与其他。",
    deg="若只关心GO/NO-GO，逐轮时间戳不必要。", cex="仅加帧提交时刻：只能分开消费主导与中间，分不开事实主导。",
    cost="探针成本为相对值（假设）。", fail="世界集合不完备时覆盖不保证。", obs="见Q007。", level="推导+精确集合覆盖", limit="5个世界")

rec(id="Q011", status="completed", decision="stop",
    domain="R0被替代候选：50条中10条失败、时延缺失；正式两臂无缺失。",
    A="显式缺失机制下的部分识别界",
    B="对缺失赋值做对抗最坏排序",
    new="R0成功子集中位106.3 ms；10个缺失任意赋值时中位只能界定在[97.2, 118.5] ms。更关键：R0存在首槽错误，任何时延统计都无效。正式两臂没有缺失，主估计量已识别，无需缺失模型。",
    disc="bench/exp_misc.py::q011, bench/exp_stats.py::q083 → raw/misc/misc.json#Q011, raw/stats/stats.json#Q083",
    pos="正式数据：缺失0。", deg="缺失为0时两法一致。", cex="把失败按0或+∞赋值，中位从97.2变到118.5 ms。",
    cost="无。", fail="—", obs="无。", level="匿名历史复算", limit="R0不可用于收益")

rec(id="Q012", status="incomplete", decision="unresolved",
    domain="观察器对被测系统的扰动。",
    A="影子缓冲记录，冻结事件面后开关两臂比较",
    B="稀疏采样/分段采样估扰动上界与重建误差",
    new="只有一个算术模型（组合C22）：全记录每事件0.2单位成本，采样降低成本但单次采样运行不能拼成一张DAG。没有可执行的被测系统扰动实验，不能给出可用的扰动界。",
    disc="bench/exp_combos.py::c22 → raw/combos/combos.json#C22（算术模型，非实验）",
    pos="—", deg="—", cex="不同运行的分段观测拼接成单DAG：被禁止（C22）。", cost="—", fail="缺真实观察器成本。",
    obs="同一路线开关观察器各≥3次独立进程的完整端点（委托方执行）。", level="算术模型", limit="未完成",
    resume="设计开/关观察器ABBA实验；在本包内无真实观察器，无法完成")

# ---------------------------------------------------------------- F03 异步因果图与资源依赖
rec(id="Q013", status="completed", decision="conditional_theory",
    domain="两任务a(5)、b(3)：世界D为真数据依赖(2工人)，世界R为无依赖但单工人串行。",
    A="依据显式await/令牌建立因果图",
    B="用协议与时刻约束生成全部相容DAG并取共同边",
    new="D与R的起止轨迹完全相同（a[0,5], b[5,8]），加一个工人后D中b仍在8结束而R中b在3结束。仅凭时间先后不能区分依赖与资源串行；N0的变换调用最大并发为2，只能说明至少2通道。",
    disc="bench/exp_sched.py::s1_order_vs_dependency → raw/sched/sched.json#S1", pos="有显式令牌时A直接给出依赖。",
    deg="资源充足时两世界轨迹不同（可区分）。", cex="上面的D/R对。", cost="A需要令牌；B需要协议知识。",
    fail="未观测的工人数使B的共同边集合可能为空。", obs="资源获取/释放事件或令牌。", level="合成模型+N0复算", limit="2任务")

rec(id="Q014", status="completed", decision="conditional_theory",
    domain="6任务DAG、2个非抢占工人、固定优先级列表调度。",
    A="事件图最长路径与join支配",
    B="资源约束离散事件重放",
    new="找到Graham型反常：把t1从8缩短到7，固定DAG关键路径不变(14)，但重放后完工从16变17。最长路径分析会预测“缩短无害或有益”，资源重放显示变慢。",
    disc="bench/exp_sched.py::s2_anomaly → raw/sched/sched.json#S2（seeded随机搜索，trial 226）",
    pos="无资源竞争时两法一致。", deg="单工人。", cex="services [8,8,1,6,2,5], 依赖见原始记录，缩短t1→完工+1。",
    cost="B需完整资源与优先级规则。", fail="真实调度规则未知时B只能给区间。", obs="调度器优先级规则。", level="合成模型", limit="小实例")

rec(id="Q015", status="completed", decision="engineering_trial",
    domain="同一物理工作被两个消费者需要（C1投机、C2必需）；取消与加入交错。",
    A="单物理节点+多消费边+引用租约",
    B="多消费者任务图，合并/拆分作为显式决策并计转换成本",
    new="去重而不配需求集合协议时，C1取消会杀掉C2需要的工作（5/12种交错错误）；配引用计数/需求集合后0错且物理作业最少。原地升级比取消重启少一半物理工作、消费完成早12单位（S9）。",
    disc="bench/exp_combos.py::c02, bench/exp_sched.py::s9_upgrade → raw/combos/combos.json#C02, raw/sched/sched.json#S9",
    pos="C2先加入再C1取消：租约保留工作。", deg="单消费者。", cex="join_C1, join_C2, cancel_C1：朴素去重取消杀掉共享作业。",
    cost="需求集合维护；B的拆分需付转换成本。", fail="消费者优先级不同而未继承时出现优先级反转。", obs="无。", level="合成模型有界穷举", limit="两消费者")

rec(id="Q016", status="completed", decision="stop",
    domain="帧周期16单位；资源就绪后立即提交 vs 截止D的批提交。",
    A="按消费者依赖就绪即时提交",
    B="按有界截止/完整unit聚合批提交",
    new="批截止D=16时完整ack多一帧(+16)，D=32多两帧；D小于剩余帧相位时无税。批处理只减少提交次数，不缩短完整ack。",
    disc="lab/lifecycle.py::q073_q075 → raw/lifecycle/lifecycle.json#Q073_Q075", pos="D=0/8：无税。",
    deg="资源恰在帧边界就绪。", cex="ready=5, D=16：即时16，批32。", cost="即时：每unit一次提交。", fail="—",
    obs="状态接纳与提交时刻（Q074）。", level="推导+合成", limit="单帧周期")

rec(id="Q017", status="completed", decision="conditional_theory",
    domain="从运行区间与容量推断隐式资源边；N0变换调用。",
    A="真实资源令牌生成获取/释放边",
    B="由容量与运行区间求必需排序及不可识别集合",
    new="在已知容量k时，任意时刻已有k个运行，新开始必须等待一个结束——这是可推出的必需边；容量未知时只能从观测并发给下界（N0为2）。Q013的D/R对说明同一轨迹下资源边与数据边不可区分。",
    disc="bench/exp_sched.py::s1_order_vs_dependency → raw/sched/sched.json#S1", pos="容量已知且饱和：边可推出。",
    deg="从不饱和：无可推边。", cex="Q013的D/R对。", cost="令牌：每次获取/释放一条记录。", fail="容量随时间变化。", obs="资源令牌事件。", level="合成+复算", limit="—")

rec(id="Q018", status="completed", decision="stop",
    domain="观测端点与重建图不一致时的处理。",
    A="保留未解释节点，上下界[0,L]",
    B="对端点/关联/时钟/缺资源边做最小修正诊断",
    new="正式100条全部通过包内有效性检查；人为把target_ack放到unit_ack之后被判ack_order。最小修正候选有三种（重关联、判跨scope、拒绝并保留分母），三者都不可自动选择；规则是不插补、保留分母。",
    disc="bench/exp_misc.py::q018, bench/exp_workloads.py::w18_sparse_wrong → raw/misc/misc.json#Q018",
    pos="一致样本：残差=0。", deg="—", cex="target_after_unit：sparse_graph拒绝。", cost="诊断只在离线分析。", fail="—", obs="无。",
    level="匿名历史复算", limit="—")

# ---------------------------------------------------------------- F04 反事实收益与瓶颈迁移
rec(id="Q019", status="completed", decision="conditional_theory",
    domain="固定DAG灵敏度 vs 资源重排后的反事实。",
    A="固定DAG路径灵敏度与关键路径割集",
    B="共享资源释放后重新排程（工作守恒反事实）",
    new="(1) 非关键路径上的工作减少收益为0（S5包络）；(2) 资源重排可让缩短变慢（Q014反常，+1）；(3) N0中逻辑source-open少1次而变换数54→54，窗口未变短。减少工作≠缩短端点，必须重放。",
    disc="bench/exp_sched.py::s2_anomaly,s5_envelope,s6_logical_physical → raw/sched/sched.json", pos="单路径：减少即缩短。",
    deg="资源充足：两法一致。", cex="S2反常实例。", cost="—", fail="—", obs="—", level="合成+N0复算", limit="—")

rec(id="Q020", status="completed", decision="conditional_theory",
    domain="服务加速后的排队反馈。",
    A="固定优先规则的确定性事件重放",
    B="未知服务时长区间的最好/最坏排程界",
    new="确定性重放显示加速一个任务可推迟目标（S2）；对区间服务时长，最好/最坏界在本实例中跨越加速前的值，因此不能单点断言收益。",
    disc="bench/exp_sched.py::s2_anomaly, lab/sched.py::optimal_target_completion → raw/sched/sched.json#S2,S17",
    pos="单工人FIFO：加速单调有益。", deg="—", cex="S2。", cost="—", fail="—", obs="调度规则与服务分布。", level="合成模型", limit="小实例")

rec(id="Q021", status="completed", decision="stop",
    domain="两条并行路径汇入消费：路径1=60，路径2=35，消费10。",
    A="多路径最大值包络与分段收益曲线",
    B="按瓶颈迁移自适应分配（联合预算）",
    new="收益g(x)=min(x, L1−L2)：在路径1上削减25单位后收益饱和为25，之后第二路径成瓶颈。对正式数据：伙伴等待（unit_ack−target_ack）是一条可观测的并行支路，其中位只有5.8 ms（F0），因此只加速伙伴的机制最多改善中位5.8 ms。",
    disc="bench/exp_sched.py::s5_envelope; lab/reach.py::first_member_bound → raw/sched/sched.json#S5, raw/pass1/reach.json",
    pos="x<25：收益=x。", deg="L1=L2：任何单路径削减收益0。", cex="削减30只得25。", cost="—", fail="—", obs="—", level="推导+复算", limit="—")

rec(id="Q022", status="completed", decision="stop",
    domain="逻辑请求下降能否兑现为物理与端点下降。",
    A="逻辑→物理→消费的守恒账",
    B="同状态下禁用一次请求并追踪替代工作（边际重放）",
    new="N0真实计数：source-open 55→54，变换54→54，计算对象40→40；单样本窗口145.5→154.3 ms（不作结论）。逻辑下降没有对应物理下降。",
    disc="bench/exp_sched.py::s6_logical_physical, bench/exp_misc.py::q031_q036 → raw/sched/sched.json#S6, raw/misc/misc.json#Q031_Q036",
    pos="被禁用请求无替代：物理同步下降（模型）。", deg="—", cex="N0：少一次打开，物理调用不变。", cost="—", fail="—", obs="—", level="N0复算", limit="单路线")

rec(id="Q023", status="completed", decision="conditional_theory",
    domain="某类机制可削减量的上界；逐样本到中位。",
    A="在所有相容DAG中求该机制最大削减",
    B="逐样本不可移除下界→顺序统计",
    new="作用于首成员ack之后的机制：残差中位≥124.4 ms（target_latency中位），不可能过门槛。作用于首成员ack之前的机制：数据不给下界（残差中位可低至1.2 ms），只能靠新观测C_i界定。",
    disc="bench/exp_misc.py::q023_q024; lab/reach.py → raw/misc/misc.json#Q023_Q024, raw/pass1/reach.json",
    pos="伙伴类机制：上界=伙伴间隙。", deg="—", cex="—", cost="—", fail="—", obs="C_i（Q007）。", level="推导+复算", limit="—")

rec(id="Q024", status="completed", decision="probe_first",
    domain="候选机制的多目标前沿（时延、工作、常驻、撤回成本）。",
    A="硬约束下的Pareto前沿与支配删除",
    B="区间收益的minimax选择+撤回成本",
    new="六个候选（回跳预取、分支证书、身份校验游标checkpoint、物理预留、结果池、陈旧意图丢弃+协作退出）没有一个能触及主门槛；在各自适用域（长链跳转、UI停顿、快意图、非抢占阻塞）有模型内收益。minimax选择：先做零语义风险、可配置撤回的物理预留与结果池；其余先补观测。",
    disc="bench/exp_misc.py::q023_q024；组合C03/C05/C11/C15 → raw/misc/misc.json, raw/combos/combos.json",
    pos="见各候选组合格。", deg="—", cex="每项的最短否证见W20。", cost="见前沿表。", fail="—", obs="—", level="模型汇总", limit="收益均为模型单位")

# ---------------------------------------------------------------- F05 队列、共享物理工作与非抢占
rec(id="Q025", status="completed", decision="engineering_trial",
    domain="300个随机小实例：2–4个已释放的投机任务+两步必需链，2工人，精确最优（允许插入空闲）。",
    A="依据真实依赖的最早可证完成优先（必需优先列表调度）",
    B="保留关键资源的机会成本策略（预留1个槽）",
    new="必需优先列表调度的平均后悔4.17、最大12（最优4，列表调度16）；预留1槽在该族上300/300达到最优。前台优先之外的调度空间正是“不要让非抢占投机占满工人”。",
    disc="bench/exp_sched.py::s7_policy_vs_optimum → raw/sched/sched.json#S7", pos="预留策略=最优。",
    deg="必需链在投机前释放：两者都最优（17/300实例后悔0）。", cex="worst_priority_instance（regret 12）。",
    cost="预留槽在无必需工作时空闲。", fail="必需工作需要多于预留槽时退化。", obs="必需工作到达时的槽占用。", level="合成模型+精确最优", limit="小实例")

rec(id="Q026", status="completed", decision="engineering_trial",
    domain="4个工人全被投机作业占满后必需任务在t=10到达；服务20/100/400，分段1/4/20，预留0/1。",
    A="保留槽位/有界准入保护",
    B="服务分段，在合法边界协作退出",
    new="无保护时阻塞=最小剩余服务（10/90/390）；预留1槽阻塞0但空闲10单位；分段4时阻塞降为0/15/90，分段20时0/0/10且总物理工作下降。界：阻塞≤min(剩余服务)（无保护）、≤段长（协作退出）、0（预留）。",
    disc="bench/exp_sched.py::s8_blocking → raw/sched/sched.json#S8", pos="见表。", deg="投机短于等待：无阻塞。",
    cex="服务400、无分段：阻塞390。", cost="预留：空闲；分段：每段边界检查。", fail="不合作作业不能分段。", obs="作业剩余服务或段边界。", level="合成模型", limit="单必需任务")

rec(id="Q027", status="completed", decision="engineering_trial",
    domain="投机任务x(30)在t=12被必需消费者需要。",
    A="原位提升优先级并绑定新消费者",
    B="取消旧逻辑请求并重启（对照），或转移物理租约",
    new="原位升级：消费完成35，物理工作30；取消重启：47，工作60（重读）。转移租约等价于原位升级，但需要原子迁移字节预留（C04）。",
    disc="bench/exp_sched.py::s9_upgrade; bench/exp_combos.py::c04 → raw/sched/sched.json#S9, raw/combos/combos.json#C04",
    pos="原位升级。", deg="升级前任务已结束：两者相同。", cex="重启方案重读5 MiB并在per-task许可下预留峰值翻倍。", cost="—",
    fail="消费者换context时原位升级须做身份检查。", obs="无。", level="合成模型", limit="—")

rec(id="Q028", status="completed", decision="engineering_trial",
    domain="4个结果在t=5..8完成，消费者UI停顿到t=40；必需任务t=10到达。",
    A="完成邮箱占槽直到消费，按真实依赖优先drain",
    B="有界所有权转移到独立结果池，槽与结果字节分别结算",
    new="占槽方案中必需任务等到停顿结束（40）；容量≥1的结果池让它在10开始。结果池把阻塞换成有界内存。",
    disc="bench/exp_sched.py::s10_mailbox; bench/exp_combos.py::c05 → raw/sched/sched.json#S10, raw/combos/combos.json#C05",
    pos="无停顿：两者相同。", deg="池容量0=占槽方案。", cex="A_slot_held：required_start=40。", cost="池内存=结果大小×容量。",
    fail="池满后背压回到占槽。", obs="完成到接纳的间隔分布。", level="合成模型（手算事件）", limit="单停顿")

rec(id="Q029", status="completed", decision="engineering_trial",
    domain="同C02：两消费者共享一个物理作业，取消/加入交错。",
    A="引用计数租约，无活消费者才请求物理取消",
    B="需求集合+优先级继承，弱消费者放弃不影响强者",
    new="二者在取消/加入交错集中都0错（C02）；差异在优先级：共享作业仍在队列中时必需者加入，A不提升优先级，作业排在另一投机作业之后，消费完成36；B继承必需优先级，完成16（S9b）。",
    disc="bench/exp_combos.py::c02; bench/exp_sched.py::s9b_inheritance → raw/combos/combos.json#C02, raw/sched/sched.json#S9b", pos="B：x在10开始。", deg="共享作业已在运行：非抢占下优先级无影响。",
    cex="朴素杀作业：5/12交错错误。", cost="需求集合维护。", fail="—", obs="—", level="合成模型", limit="—")

rec(id="Q030", status="completed", decision="engineering_trial",
    domain="意图每3单位到达一次，服务10，单工人，8个意图。",
    A="有界代际保留/撤销，latest-valid-intent优先",
    B="截止/ageing混合队列（这里以全部FIFO为对照）",
    new="FIFO最后意图时延59、物理工作80；只丢弃未开始的旧意图：19、40；取消运行中旧意图的变体同为19（运行作业仍要到真实退出）。不承诺任意快意图流中每个意图及时完成。",
    disc="bench/exp_sched.py::s11_fast_intents; 组合C15 → raw/sched/sched.json#S11", pos="见数值。",
    deg="意图间隔≥服务：三者相同。", cex="FIFO在快流下时延随意图数线性增长。", cost="—", fail="已曝光意图不得丢弃（Q068）。", obs="—", level="合成模型", limit="—")
