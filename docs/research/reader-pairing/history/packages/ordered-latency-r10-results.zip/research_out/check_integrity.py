"""Verify the original package files against MANIFEST.json and list research outputs with SHA-256.
Writes research_out/summary/package_integrity.json and research_out/SHA256SUMS.txt"""
import hashlib
import json
import os
from pathlib import Path

OUT = Path(__file__).resolve().parent
PKG = OUT.parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


m = json.load(open(PKG / "MANIFEST.json", encoding="utf-8"))
bad = [f["path"] for f in m["files"] if sha(PKG / f["path"]) != f["sha256"] or (PKG / f["path"]).stat().st_size != f["bytes"]]
listed = {f["path"] for f in m["files"]} | {"MANIFEST.json"}
present = {str(Path(r, x).relative_to(PKG)) for r, _, fs in os.walk(PKG) for x in fs if not str(Path(r)).startswith(str(OUT))
           and "__pycache__" not in r}
res = {"manifest_files": len(m["files"]), "hash_or_size_mismatch": bad, "unlisted_original_files": sorted(present - listed),
       "modified_original_files": bad, "note": "research outputs live only under research_out/"}
(OUT / "summary").mkdir(exist_ok=True)
(OUT / "summary/package_integrity.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
lines = []
for r, _, fs in sorted(os.walk(OUT)):
    if "__pycache__" in r:
        continue
    for x in sorted(fs):
        p = Path(r, x)
        if p.name == "SHA256SUMS.txt":
            continue
        lines.append(f"{sha(p)}  {p.relative_to(PKG)}")
(OUT / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps(res), len(lines), "research files hashed")
