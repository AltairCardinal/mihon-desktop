"""Q098/Q099/C08/C09: exact composable summaries of Γ's scan in a balanced tree, vs sparse checkpoints, vs rescan.

Boundary state at b = (cursor kind, opening, reserved_here, manual parity of b-1); leaf tables are computed
with Γ's own step (gamma.Scan) on complete facts (halo of 2 objects to the right is read by the step).
Correctness is checked against gamma.plan on every query in the tests/benchmarks.
"""
import gamma as G
from transducer import ALL_STATES

PARITIES = (None, True, False)


def _scan(case):
    c = G.Case(case)
    return G.Scan(len(c.items), c.settings, *G.snapshot_queries(c)), len(c.items)


def _start_cursor(b, s):
    return (b + 1, False, -1) if s[0] == "consumed" else (b, s[1], b if s[2] else -1)


def _to_state(cur, b):
    i, o, r = cur
    if i == b:
        return ("free", o, r == b)
    assert i == b + 1 and not o, (cur, b)
    return ("consumed",)


class SummaryTree:
    def __init__(self, case, leaf=8):
        self.case, self.leaf = case, leaf
        self.n = len(case["items"])
        self.nleaves = max(1, -(-self.n // leaf))
        size = 1
        while size < self.nleaves:
            size *= 2
        self.size = size
        self.tab = [None] * (2 * size)
        self.ops = {"leaf_steps": 0, "compositions": 0}
        for k in range(self.nleaves):
            self.tab[size + k] = self._leaf(k)
        for k in range(self.nleaves, size):
            self.tab[size + k] = "identity"
        for v in range(size - 1, 0, -1):
            self.tab[v] = self._compose(self.tab[2 * v], self.tab[2 * v + 1])

    def _leaf(self, k):
        a, b = k * self.leaf, min(self.n, (k + 1) * self.leaf)
        table = {}
        for s in ALL_STATES:
            for p in PARITIES:
                sc, n = _scan(self.case)
                if p is not None and a > 0:
                    sc.manual_cache[a - 1] = p
                cur = _start_cursor(a, s)
                if s[0] == "consumed" and a + 1 > b:
                    # consumed state entering an object beyond this leaf: pass through
                    table[(s, p)] = (s, p if b - 1 < a else None)
                    continue
                while cur[0] < b:
                    _, cur = sc.step(cur, include_single=False, include_double=False)
                    self.ops["leaf_steps"] += 1
                exit_state = _to_state(cur, b) if b < n else ("end",)
                exit_par = sc.manual(b - 1) if (b - 1) in sc.starts else None
                table[(s, p)] = (exit_state, exit_par)
        return table

    def _compose(self, t1, t2):
        if t1 == "identity":
            return t2
        if t2 == "identity":
            return t1
        self.ops["compositions"] += 1
        out = {}
        for key, (s1, p1) in t1.items():
            out[key] = t2.get((s1, p1), (s1, p1)) if s1 != ("end",) else (s1, p1)
        return out

    def state_at_leaf(self, k):
        """Boundary state entering leaf k: compose all leaves left of k from the initial state."""
        state = (("free", True, False), None)
        # walk the tree: collect maximal nodes covering [0, k)
        nodes = []
        lo, hi = self.size, self.size + k
        left, right = [], []
        while lo < hi:
            if lo & 1:
                left.append(lo); lo += 1
            if hi & 1:
                hi -= 1; right.append(hi)
            lo //= 2; hi //= 2
        nodes = left + right[::-1]
        for v in nodes:
            t = self.tab[v]
            if t != "identity":
                state = t[state]
                self.ops["compositions"] += 1
        return state

    def unit(self, t):
        k = t // self.leaf
        (s, p) = self.state_at_leaf(k)
        a = k * self.leaf
        sc, n = _scan(self.case)
        if p is not None and a > 0:
            sc.manual_cache[a - 1] = p
        cur = _start_cursor(a, s)
        if s[0] == "consumed" and a == t:
            # t was consumed by the pair (t-1, t) formed in the previous leaf (S06 unit, built directly)
            return {"slots": ((t - 1, sc.leading), (t, sc.trailing)), "certain": sc.known(t - 1) and sc.known(t), "reason": None}
        while cur[0] <= t:
            u, cur = sc.step(cur)
            self.ops["leaf_steps"] += 1
            if any(o == t for o, _ in u["slots"]):
                return u
        raise AssertionError("unit not found")

    def update(self, case, pos):
        """Facts of object `pos` changed: recompute leaves whose window (incl. 2-object halo) contains pos."""
        self.case = case
        ks = {pos // self.leaf}
        if pos - 2 >= 0:
            ks.add((pos - 2) // self.leaf)
        if pos - 1 >= 0:
            ks.add((pos - 1) // self.leaf)
        for k in ks:
            self.tab[self.size + k] = self._leaf(k)
            v = (self.size + k) // 2
            while v:
                self.tab[v] = self._compose(self.tab[2 * v], self.tab[2 * v + 1])
                v //= 2


class Checkpoints:
    """Sparse exact cursor checkpoints every `every` objects, invalidated to the right of an update."""

    def __init__(self, case, every=16):
        self.case, self.every = case, every
        self.cp = {0: ((0, True, -1), {})}
        self.ops = {"steps": 0}

    def unit(self, t):
        base = max(k for k in self.cp if k <= t)
        cur, mc = self.cp[base]
        sc, n = _scan(self.case)
        sc.manual_cache.update(mc)
        while True:
            if cur[0] % self.every == 0 and cur[0] not in self.cp:
                self.cp[cur[0]] = (cur, dict(sc.manual_cache))
            u, cur = sc.step(cur)
            self.ops["steps"] += 1
            if any(o == t for o, _ in u["slots"]):
                return u

    def update(self, case, pos):
        self.case = case
        for k in [k for k in self.cp if k > max(0, pos - 2)]:
            del self.cp[k]
