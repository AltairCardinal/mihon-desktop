"""F18/F16: evidence acquisition policies around Γ's certification (bounded synthetic worlds).

A 'round' = one certify -> needs -> acquire cycle (serial dependency depth). Fact kinds:
  DIMENSIONS        descriptor/header probe (cheap metadata)
  ORIGINAL_ANALYSIS needs the object's pixels  -> one materialisation of the object
  EDGE_SAMPLES(a,b) needs facing samples of a and b -> materialisations of a and b
Materialisations are counted per object (shared: one materialisation serves analysis and both edges).
Slot model: at most `slots` materialisations in flight per round (frozen 4 required+speculative).
No time is attached to a round; results are rounds/materialisations/waste only.
"""
import math
import random

import gamma as G


def random_world(n, rng, p_y=0.08, p_side=0.15, p_null=0.3, smax=20):
    states = ["SHAPE_Y" if rng.random() < p_y else "SHAPE_X" for _ in range(n)]
    sides = [G.LEFT if u < p_side else G.RIGHT if u < 2 * p_side else G.UNK for u in (rng.random() for _ in range(n))]
    scores = {i: (None if rng.random() < p_null else rng.randint(0, smax)) for i in range(n - 1)}
    return states, sides, scores


class Knowledge:
    def __init__(self, world, settings):
        self.states, self.sides, self.scores = world
        self.n = len(self.states)
        self.settings = settings
        self.dim, self.an, self.edge = set(), set(), set()
        self.materialised = set()

    def case(self):
        items = []
        for i in range(self.n):
            it = {"id": f"o{i}", "content_version": 0, "rotation": 0, "orientation": 1}
            if i in self.an:
                it["analysis"] = G.computed(self.states[i], self.sides[i])
            else:
                it["analysis"] = {"status": "NotAnalyzed"}
                if i in self.dim:
                    it["descriptor"] = G.fact(self.states[i])
            items.append(it)
        edges = {(i, i + 1): {"status": "Computed", "score": self.scores[i], "version": 1} for i in self.edge}
        return {"items": items, "edges": edges, "settings": self.settings}

    def apply(self, need, shared):
        """Acquire one need; return the set of objects that had to be materialised for it."""
        k, o = need["kind"], need["object"]
        if k == "DIMENSIONS":
            self.dim.add(o)
            return set()
        if k == "ORIGINAL_ANALYSIS":
            self.an.add(o)
            self.dim.add(o)
            return {o}
        b = need["second"]
        self.edge.add(o)
        return {o, b}


def acquire_loop(world, settings, t, policy="need", slots=4, shared=True, gallop=False, max_rounds=400):
    """Run certification with an acquisition policy. Returns rounds, materialisations, waste, final support."""
    K = Knowledge(world, settings)
    rounds, mats, spec = 0, 0, set()
    step = 1
    while True:
        c = G.certify(K.case(), t)
        if c["status"] == "Certified":
            support = set(c["dependent_objects"])
            used = set(K.an) | {x for e in K.edge for x in (e, e + 1)}
            return {"rounds": rounds, "materialisations": mats, "support": len(support), "first": c["first"],
                    "unit": c["unit"], "speculative": len(spec), "waste": len(spec - support),
                    "facts": len(K.dim) + len(K.an) + len(K.edge)}
        if c["status"] == "RetryableBlocked":
            return {"blocked": True}
        needs = list(c["needs"])
        # objects that need a materialisation this round
        want_mat = set()
        for nd in needs:
            if nd["kind"] == "ORIGINAL_ANALYSIS":
                want_mat.add(nd["object"])
            elif nd["kind"] == "EDGE_SAMPLES":
                want_mat |= {nd["object"], nd["second"]}
        if gallop:
            # speculative backward prefetch: objects left of the current certificate start, doubling each round
            lo = min([nd["object"] for nd in needs] + [c["first"]])
            extra = [o for o in range(lo - 1, max(-1, lo - 1 - step), -1)]
            step = min(step * 2, 64)
            for o in extra:
                if o not in K.an:
                    spec.add(o)
                    want_mat.add(o)
        new_mat = {o for o in want_mat if o not in K.materialised} if shared else want_mat
        waves = max(1, math.ceil(len(new_mat) / slots)) if new_mat else 1
        rounds += waves
        mats += len(new_mat)
        if shared:
            K.materialised |= new_mat
        for nd in needs:
            K.apply(nd, shared)
        if gallop:
            for o in extra:
                if 0 <= o < K.n:
                    K.an.add(o)
                    K.dim.add(o)
                    if o + 1 < K.n:
                        K.edge.add(o)
                    if o - 1 >= 0 and o - 1 in K.an:
                        K.edge.add(o - 1)
        if rounds > max_rounds:
            raise AssertionError("no convergence")


def truncated_window(world, settings, t, lookbehind):
    """R0-like shortcut: scan a fixed window [t-lookbehind, ...] from ONE assumed entry (t-lookbehind, True, -1)
    with complete facts, never extending left. Returns the unit it would publish."""
    c = G.Case(_full_case(world, settings))
    sc = G.Scan(len(c.items), c.settings, *G.snapshot_queries(c))
    cur = (max(0, t - lookbehind), True, -1)
    while cur[0] <= t:
        u, cur = sc.step(cur)
        if any(o == t for o, _ in u["slots"]):
            return u
    return None


def _full_case(world, settings):
    states, sides, scores = world
    return G.make_case(states, sides, scores, settings)
