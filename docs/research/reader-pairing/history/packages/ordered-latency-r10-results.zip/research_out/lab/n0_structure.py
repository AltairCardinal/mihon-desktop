"""Pass 1: structure of the separate N0 normal-consumption route (different 40-object synthetic material).

Evidence level: anonymous historical recomputation inside one clock scope per arm. Not the formal population.
History-ack snapshots are observation times that may lag the real receipt; the harness command time for each
history step is NOT recorded, so ack-to-ack durations include unknown harness reaction time. We therefore only
compare step classes inside the same arm (same harness), and never call a residual CPU, queue or frame wait.
Output: raw/pass1/n0_structure.json
"""
from collections import defaultdict

from common import PKG, RAW, jsonable, median, write_json
from causal import interval_union
import json


def unit_objects(s):
    return tuple(x["object"] for x in s["unit"]["slots"]) if s.get("unit") else None


def analyse_arm(arm):
    st = {(x["stage"], x["object"], x["purpose"]): x for x in arm["transform_starts"]}
    tr = []
    for c in arm["transform_completions"]:
        k = (c["stage"], c["object"], c["purpose"])
        s = st[k]
        assert s["clock_scope"] == c["clock_scope"] == arm["clock_scope"]
        tr.append({"stage": c["stage"], "object": c["object"], "start": s["at_ns"], "end": c["at_ns"]})
    snaps = arm["snapshots"]
    steps = []
    last_done = {}  # object -> last transform completion before a time
    for prev, s in zip(snaps, snaps[1:]):
        if s["kind"] not in ("history_ack", "first_ack"):
            continue
        a, b = prev["at_ns"], s["at_ns"]
        inside = [t for t in tr if a <= t["start"] < b]
        members = unit_objects(s)
        before = {o: max([t["end"] for t in tr if t["object"] == o and t["end"] <= a], default=None) for o in members}
        steps.append({"stage": s["stage"], "kind": s["kind"], "dt_ns": b - a,
                      "unit_change": unit_objects(prev) != members, "members": list(members),
                      "members_transformed_before_step": all(v is not None for v in before.values()),
                      "member_transforms_inside_step": sum(1 for t in inside if t["object"] in members),
                      "transforms_inside": len(inside),
                      "transform_union_ns": interval_union([(t["start"], min(t["end"], b)) for t in inside]),
                      "transform_calls_delta": s["transform_calls"] - prev["transform_calls"],
                      "computed_objects_delta": s["computed_objects"] - prev["computed_objects"],
                      "proof_work_delta": s["proof_work"] - prev["proof_work"]})
    intent = next(x for x in snaps if x["kind"] == "intent_boundary")
    first = next(x for x in snaps if x["kind"] == "first_ack")
    unit = next(x for x in snaps if x["kind"] == "unit_ack")
    members = [x["object"] for x in arm["actual_unit"]["slots"]]
    win = [t for t in tr if intent["at_ns"] <= t["start"] < arm["actual_draw_at_ns"]]
    target = {"intent_to_first_ack_obs_ns": first["at_ns"] - intent["at_ns"],
              "intent_to_unit_ack_obs_ns": unit["at_ns"] - intent["at_ns"],
              "intent_to_actual_draw_ns": arm["actual_draw_at_ns"] - intent["at_ns"],
              "members": members,
              "member_last_transform_before_intent_ns": {o: max([t["end"] for t in tr if t["object"] == o and t["end"] <= intent["at_ns"]], default=None) - intent["at_ns"]
                                                          if any(t["object"] == o and t["end"] <= intent["at_ns"] for t in tr) else None for o in members},
              "member_transforms_in_window": sum(1 for t in win if t["object"] in members),
              "non_member_transforms_in_window": [t["object"] for t in win if t["object"] not in members],
              "transform_union_in_window_ns": interval_union([(t["start"], t["end"]) for t in win]),
              "proof_work_at_intent": intent["proof_work"], "proof_work_at_unit": unit["proof_work"],
              "cached_evidence_at_intent": intent["cached_evidence"],
              "source_open_offsets_ns": [m["at_ns"] - intent["at_ns"] for m in arm["source_markers"] if m["stage"] == "target"]}
    cls = defaultdict(list)
    for s in steps:
        if s["kind"] != "history_ack":
            continue
        key = ("unit_change" if s["unit_change"] else "same_unit") + ("/members_prefetched" if s["members_transformed_before_step"] else "/members_not_prefetched")
        cls[key].append(s["dt_ns"])
    classes = {k: {"n": len(v), "min": min(v), "median": median(v), "max": max(v)} for k, v in sorted(cls.items())}
    return {"arm": arm["arm"], "steps": steps, "step_classes": classes, "target": target,
            "transform_durations_ns": {"n": len(tr), "median": median([t["end"] - t["start"] for t in tr]),
                                       "max": max(t["end"] - t["start"] for t in tr)}}


def main():
    with open(PKG / "data/negative_route.json", encoding="utf-8") as f:
        d = json.load(f)
    out = {"evidence_level": "historical recomputation, separate synthetic-material route (not formal population)",
           "caveats": ["ack snapshots may lag real receipts", "history-step command time not recorded",
                       "no queue/fact/state timestamps", "interval union is not CPU and not a critical path"],
           "arms": [analyse_arm(a) for a in d["arms"]]}
    write_json(RAW / "pass1/n0_structure.json", out)
    return out


if __name__ == "__main__":
    o = main()
    for a in o["arms"]:
        print(a["arm"], json.dumps(jsonable(a["step_classes"])), json.dumps(jsonable(a["target"])), jsonable(a["transform_durations_ns"]))
