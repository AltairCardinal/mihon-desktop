"""Synthetic resource/lifecycle discrete-event model for F03/F05/F06/F07/F11/F19 and the combinations.

Hypothesis model, integer time units (NOT ns, NOT calibrated). Frozen structural rules implemented:
  * required+speculative share LOGICAL_RS = 4 admission slots; optional has LOGICAL_OPT = 2 separate slots
  * all fact-side work runs on `physical` non-preemptive workers (shared by all roles; default 4)
  * optional attempts per scope <= 16 (required is NOT capped at 16)
  * byte window: reserve on start (declared upper bound), settle actual on exit, refund unused; window 32 MiB
  * cancel != exit: a cancelled running task keeps its worker and its admission slot until its real exit
  * completion mailbox: a finished result occupies `mailbox` capacity until accepted by a live consumer
  * visible consumption runs on its own path (consume lane(s)), not limited by the fact-side slots
  * close: request -> logical close (reject new work, cancel all) -> physical drain (last real exit) -> release
Policies are plain functions so that two mechanisms can be compared on identical inputs and ledgers.
"""
import heapq
import itertools
from dataclasses import dataclass, field

LOGICAL_RS, LOGICAL_OPT, OPT_CAP = 4, 2, 16
WINDOW_BYTES = 32 * 1024 * 1024


@dataclass
class Task:
    id: str
    role: str                    # required | speculative | optional
    service: int                 # physical service units once started
    release: int = 0
    deps: tuple = ()
    consumers: set = field(default_factory=set)
    bytes_upper: int = 0
    bytes_actual: int = 0
    segments: int = 1            # cooperative exit points: can stop at k*service/segments boundaries
    obj: str = ""
    # runtime
    state: str = "pending"       # pending|queued|running|exited
    start: int = None
    end: int = None
    cancelled: bool = False
    upgraded_at: int = None
    accepted: bool = False


class Sim:
    def __init__(self, tasks, physical=4, mailbox=None, policy="priority", reserve_required=0,
                 spec_budget=None, borrow=False, upgrade="in_place", segment_exit=False, opt_slots=LOGICAL_OPT,
                 rs_slots=LOGICAL_RS, window=WINDOW_BYTES, consume=None, trace=False, reserve_physical=0):
        self.tasks = {t.id: t for t in tasks}
        self.physical, self.mailbox_cap = physical, mailbox
        self.policy, self.reserve_required = policy, reserve_required
        self.spec_budget, self.borrow, self.upgrade, self.segment_exit = spec_budget, borrow, upgrade, segment_exit
        self.opt_slots, self.rs_slots, self.window = opt_slots, rs_slots, window
        self.reserve_physical = reserve_physical  # physical workers kept free for required work
        self.consume = consume or {}       # consumer -> (set of task ids it needs, consume service)
        self.now = 0
        self.events = []
        self.seq = itertools.count()
        self.used_bytes = 0
        self.opt_attempted = 0
        self.mailbox = []
        self.log = [] if trace else None
        self.consumer_done = {}
        self.work = 0
        self.closed_at = None
        self.peak = {"running": 0, "mailbox": 0, "bytes": 0}
        for t in tasks:
            self._push(t.release, "release", t.id)

    # -------------------------------------------------------------- helpers
    def _push(self, at, kind, ref):
        heapq.heappush(self.events, (at, next(self.seq), kind, ref))

    def _note(self, *a):
        if self.log is not None:
            self.log.append((self.now,) + a)

    def running(self, roles=None):
        return [t for t in self.tasks.values() if t.state == "running" and (roles is None or t.role in roles)]

    def queued(self):
        return [t for t in self.tasks.values() if t.state == "queued"]

    def deps_done(self, t):
        return all(self.tasks[d].state == "exited" and not self.tasks[d].cancelled for d in t.deps)

    def logical_ok(self, t):
        rs = len([x for x in self.running(("required", "speculative"))])
        op = len(self.running(("optional",)))
        if t.role in ("required", "speculative"):
            if rs >= self.rs_slots:
                return False
            if t.role == "speculative":
                if self.spec_budget is not None and len(self.running(("speculative",))) >= self.spec_budget:
                    return False
                # keep `reserve_required` slots free for required work unless borrowing is allowed and no
                # required work is visible
                free_after = self.rs_slots - rs - 1
                if free_after < self.reserve_required and not (self.borrow and not self._visible_required()):
                    return False
            return True
        if op >= self.opt_slots or self.opt_attempted >= OPT_CAP:
            return False
        return True

    def _visible_required(self):
        return any(t.role == "required" and t.state in ("queued", "pending") and t.release <= self.now and not t.cancelled
                   for t in self.tasks.values())

    def physical_free(self):
        return self.physical - len(self.running())

    def mailbox_ok(self):
        return self.mailbox_cap is None or len(self.mailbox) < self.mailbox_cap

    def order(self, cands):
        if self.policy == "fifo":
            return sorted(cands, key=lambda t: (t.release, t.id))
        rank = {"required": 0, "speculative": 1, "optional": 2}
        return sorted(cands, key=lambda t: (rank[t.role], t.release, t.id))

    # -------------------------------------------------------------- dispatcher
    def dispatch(self):
        if self.closed_at is not None:
            return
        progress = True
        while progress:
            progress = False
            for t in self.order([x for x in self.queued() if self.deps_done(x) and not x.cancelled]):
                if self.physical_free() <= 0 or not self.mailbox_ok():
                    return
                if not self.logical_ok(t):
                    continue
                if t.role != "required" and self.physical_free() <= self.reserve_physical:
                    continue
                if self.used_bytes + t.bytes_upper > self.window:
                    continue
                t.state, t.start = "running", self.now
                self.used_bytes += t.bytes_upper
                if t.role == "optional":
                    self.opt_attempted += 1
                self._push(self.now + t.service, "exit", t.id)
                self._note("start", t.id, t.role)
                self.peak["running"] = max(self.peak["running"], len(self.running()))
                self.peak["bytes"] = max(self.peak["bytes"], self.used_bytes)
                progress = True
                break

    # -------------------------------------------------------------- external actions
    def cancel(self, tid):
        t = self.tasks[tid]
        t.cancelled = True
        if t.state in ("pending", "queued"):
            t.state = "exited"
            t.end = self.now
            self._note("cancel_queued", tid)
        elif t.state == "running" and self.segment_exit and t.segments > 1:
            seg = t.service // t.segments
            done = self.now - t.start
            nxt = t.start + ((done + seg - 1) // seg) * seg if seg else self.now
            self._push(max(nxt, self.now), "exit", tid)   # cooperative exit at next segment boundary
            self._note("cancel_running_segment", tid, nxt)
        else:
            self._note("cancel_running_noop", tid)

    def upgrade_task(self, tid, consumer):
        t = self.tasks[tid]
        if self.upgrade == "in_place":
            if t.role == "speculative":
                t.role = "required"
            t.upgraded_at = self.now
            t.consumers.add(consumer)
            self._note("upgrade_in_place", tid)
            return tid
        # cancel-and-restart (anti-pattern used as a control): new physical work for the same object
        self.cancel(tid)
        nid = tid + "'"
        nt = Task(nid, "required", t.service, self.now, t.deps, {consumer}, t.bytes_upper, t.bytes_actual, t.segments, t.obj)
        nt.state = "queued"
        self.tasks[nid] = nt
        self._note("upgrade_restart", tid, nid)
        return nid

    def close(self):
        self.closed_at = self.now
        for t in self.tasks.values():
            if t.state in ("pending", "queued", "running"):
                self.cancel(t.id)
        self.mailbox.clear()
        self._note("close_logical")

    # -------------------------------------------------------------- main loop
    def run(self, actions=(), until=None):
        """actions: list of (time, callable(sim)) external events."""
        for at, fn in actions:
            self._push(at, "action", fn)
        while self.events:
            at, _, kind, ref = heapq.heappop(self.events)
            if until is not None and at > until:
                break
            self.now = at
            if kind == "release":
                t = self.tasks[ref]
                if t.state == "pending" and not t.cancelled:
                    if self.closed_at is not None:
                        t.state, t.end = "exited", self.now
                    else:
                        t.state = "queued"
            elif kind == "exit":
                t = self.tasks[ref]
                if t.state != "running":
                    continue
                t.state, t.end = "exited", self.now
                self.work += t.end - t.start
                self.used_bytes -= t.bytes_upper
                self.used_bytes += 0  # settled: actual bytes were within the reservation, unused refunded
                if not t.cancelled and self.closed_at is None:
                    self.mailbox.append(t.id)
                    self.peak["mailbox"] = max(self.peak["mailbox"], len(self.mailbox))
                    self._accept()
                self._note("exit", ref, "cancelled" if t.cancelled else "ok")
            elif kind == "action":
                ref(self)
            elif kind == "consume_done":
                self.consumer_done[ref] = self.now
            self._check_consumers()
            self.dispatch()
        return self

    def _accept(self):
        # a result is accepted (leaves the mailbox) when a live consumer needs it; others stay owned
        keep = []
        for tid in self.mailbox:
            t = self.tasks[tid]
            if t.consumers:
                t.accepted = True
            else:
                keep.append(tid)
        self.mailbox = keep

    def _check_consumers(self):
        for c, (need, svc) in self.consume.items():
            if c in self.consumer_done or ("_sched_" + c) in self.consumer_done:
                continue
            if all(self.tasks[x].state == "exited" and not self.tasks[x].cancelled for x in need):
                self.consumer_done["_sched_" + c] = self.now
                self._push(self.now + svc, "consume_done", c)

    # -------------------------------------------------------------- metrics
    def metrics(self):
        return {"consumer_done": {k: v for k, v in self.consumer_done.items() if not k.startswith("_sched_")},
                "physical_work": self.work,
                "wasted_work": sum(t.end - t.start for t in self.tasks.values() if t.start is not None and t.end is not None
                                   and (t.cancelled or not (t.accepted or t.consumers))),
                "peak": dict(self.peak), "drain_end": max([t.end for t in self.tasks.values() if t.end is not None], default=0),
                "unexited": [t.id for t in self.tasks.values() if t.state == "running"]}


# ---------------------------------------------------------------------- exact optimum for small instances
def optimal_target_completion(tasks, physical, target, rs_slots=LOGICAL_RS):
    """Exact minimum completion time of `target` over all non-preemptive schedules (idle insertion allowed),
    deterministic services/releases, admission <= rs_slots for required+speculative. Exhaustive DFS over decision
    points (small instances only). Tasks that are already running at time 0 (release<0 trick) are fixed."""
    T = {t.id: t for t in tasks}
    best = [None]
    fixed = {t.id: (t.start, t.start + t.service) for t in tasks if t.start is not None}

    def dfs(now, done, running, started):
        # running: dict id->end
        if target in done:
            c = done[target]
            if best[0] is None or c < best[0]:
                best[0] = c
            return
        if best[0] is not None and now >= best[0]:
            return
        ready = [x for x in T if x not in started and T[x].release <= now and all(d in done for d in T[x].deps)]
        free = physical - len(running)
        # option A: start any subset of ready tasks (size <= free) now
        if ready and free > 0:
            for k in range(min(free, len(ready)), 0, -1):
                for sub in itertools.combinations(ready, k):
                    if len(running) + k > rs_slots:
                        continue
                    r2 = dict(running)
                    for x in sub:
                        r2[x] = now + T[x].service
                    nxt = min(list(r2.values()) + [T[x].release for x in T if x not in started and T[x].release > now], default=None)
                    advance(nxt, done, r2, started | set(sub))
        # option B: start nothing now; wait for next event
        nxt = min(list(running.values()) + [T[x].release for x in T if x not in started and T[x].release > now], default=None)
        if nxt is not None and nxt > now:
            advance(nxt, done, running, started)

    def advance(t, done, running, started):
        if t is None:
            return
        d2 = dict(done)
        r2 = {}
        for x, e in running.items():
            if e <= t:
                d2[x] = e
            else:
                r2[x] = e
        dfs(t, d2, r2, started)

    running0 = {x: e for x, (s, e) in fixed.items()}
    dfs(0, {}, running0, set(fixed))
    return best[0]
