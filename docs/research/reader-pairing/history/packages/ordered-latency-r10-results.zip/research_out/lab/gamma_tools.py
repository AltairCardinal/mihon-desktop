"""Instrumented helpers around gamma.py for F09/F12/F17/F18/F20 experiments."""
import copy

import gamma as G


def first_entry_support(case, t, lookbehind=2):
    """Facts read by the scan from the FIRST C08 entry only, at the first window where certify succeeded.
    Used to model a 'final/selected path only' dependency set (the anti-pattern of Q050)."""
    full = G.certify(case, t, lookbehind)
    if full["status"] != "Certified":
        return None, full
    c = G.Case(case)
    reads = set()

    def dim(i):
        reads.add(("dim", i))
        return c.effective(i)

    def side(i):
        reads.add(("an", i))
        a = c.analysis(i)
        return a["fact"]["side"] if a["status"] == "Computed" else G.UNK

    def resolved(i):
        reads.add(("an", i))
        a = c.analysis(i)
        return a["fact"]["side"] if a["status"] == "Computed" else None

    def dist(a, b):
        reads.add(("edge", a))
        e = c.edge(a, b)
        return e["score"] if e["status"] == "Computed" else None
    sc = G.Scan(len(c.items), c.settings, dim, side, resolved, dist)
    first = full["first"]
    cur = (first, True, -1)
    while cur[0] <= t:
        u, cur = sc.step(cur)
        if u is not None and any(o == t for o, _ in u["slots"]):
            break
    return reads, full


def support_facts(cert):
    s = set()
    for i in cert["support"]["dimension"]:
        s.add(("dim", int(i)))
    for i in cert["support"]["analysis"]:
        s.add(("an", int(i)))
    for k in cert["support"]["edge"]:
        s.add(("edge", int(k.split(":")[0])))
    return s


def flip(case, fact, rng=None):
    """Return a copy of the case with one fact changed to a different legal value (state/side/score)."""
    c = copy.deepcopy(case)
    kind, i = fact
    if kind in ("dim", "an"):
        it = c["items"][i]
        a = it["analysis"]
        if a["status"] == "Computed":
            f = a["fact"]
            if kind == "dim":
                ns = "SHAPE_Y" if f["state"] == "SHAPE_X" else "SHAPE_X"
                it["analysis"] = G.computed(ns, f["side"])
            else:
                order = [G.LEFT, G.RIGHT, G.UNK]
                ns = order[(order.index(f["side"]) + 1) % 3]
                it["analysis"] = G.computed(f["state"], ns)
        elif it.get("descriptor"):
            d = it["descriptor"]
            it["descriptor"] = G.fact("SHAPE_Y" if d["state"] == "SHAPE_X" else "SHAPE_X")
        else:
            return None
    else:
        e = c["edges"].get((i, i + 1))
        if not e or e["status"] != "Computed":
            return None
        sc = e["score"]
        c["edges"][(i, i + 1)] = dict(e, score=(5 if sc is None else (None if sc >= 5 else sc + 7)))
    return c
