"""F17/W01/W02: minimal boundary state, composable interval summaries, long dependencies and (pseudo-)resets.

All results are bounded exhaustion / constructive families on gamma.py (researcher reconstruction of Γ).
"""
import itertools
import random

import gamma as G
from omega import Domain

# Boundary state between object b-1 and b, as seen by the scan arriving at b:
#   ('free', opening, reserved_here)  cursor = (b, opening, b if reserved_here else -1)
#   ('consumed',)                     the pair (b-1, b) was taken; cursor = (b+1, False, -1)
FREE_STATES = [("free", o, r) for o in (True, False) for r in (False, True)]
ALL_STATES = FREE_STATES + [("consumed",)]


def scan_for(case):
    c = G.Case(case)
    return G.Scan(len(c.items), c.settings, *G.snapshot_queries(c)), len(c.items)


def run_from(case, b, state, stop=None, manual_seed=None):
    """Run Γ's step from boundary b with the given boundary state until index >= stop (default n)."""
    sc, n = scan_for(case)
    if manual_seed:
        sc.manual_cache.update(manual_seed)
    if state[0] == "consumed":
        cur = (b + 1, False, -1)
    else:
        cur = (b, state[1], b if state[2] else -1)
    stop = n if stop is None else stop
    units = []
    while cur[0] < min(stop, n):
        u, cur = sc.step(cur)
        units.append(u)
    return units, cur


def cursor_to_state(cur, b):
    i, o, r = cur
    if i == b:
        return ("free", o, r == b)
    if i == b + 1:
        return ("consumed",) if not o else ("consumed_open",)
    return ("beyond", i - b, o, r)


# ------------------------------------------------------------------ Q097 distinguishability of boundary states
def distinguishability(dom, b):
    """For boundary b in domain dom: which pairs of boundary states are distinguishable by the suffix output?"""
    sig = {s: set() for s in ALL_STATES}
    for w in dom.worlds:
        case = dom.case(w)
        for s in ALL_STATES:
            if s[0] == "consumed" and b + 1 > dom.n:
                continue
            units, _ = run_from(case, b, s)
            out = tuple((u["slots"], u["reason"], u["certain"]) for u in units if any(o >= b + (1 if s[0] == "consumed" else 0) for o, _ in u["slots"]))
            sig[s].add((w, out))
    # two states are equivalent iff they produce identical outputs on every world
    def table(s):
        return {w: out for w, out in sig[s]}
    tabs = {s: table(s) for s in ALL_STATES}
    classes = []
    for s in ALL_STATES:
        for cl in classes:
            if tabs[cl[0]] == tabs[s]:
                cl.append(s)
                break
        else:
            classes.append([s])
    witnesses = {}
    for a, c in itertools.combinations(ALL_STATES, 2):
        for w in dom.worlds:
            if tabs[a].get(w) != tabs[c].get(w):
                witnesses[f"{a}|{c}"] = {"world": w, "out_a": tabs[a].get(w), "out_b": tabs[c].get(w)}
                break
    return {"classes": classes, "n_classes": len(classes), "witness_count": len(witnesses), "witnesses": witnesses}


# ------------------------------------------------------------------ Q098 interval summaries and composition
def summary(case, a, b, with_manual_parity):
    """Exact summary of segment [a,b): for each entry boundary state -> (exit state at b, units).
    The scan may read facts in [a, b+2) (halo). If with_manual_parity, the manual-start cache value of a-1
    (S02 previousAccepted parity) is part of the entry state; otherwise the segment recomputes it from facts
    *inside the segment only* (which is what an isolated summary would do)."""
    out = {}
    parities = (None, True, False) if with_manual_parity else (None,)
    for s in ALL_STATES:
        for par in parities:
            seed = {} if par is None else {a - 1: par}
            sub = restrict_left(case, a) if not with_manual_parity else case
            units, cur = run_from(sub, a, s, stop=b, manual_seed=seed)
            out[(s, par)] = (cursor_to_state(cur, b), units)
    return out


def restrict_left(case, a):
    """An isolated segment summary cannot see facts left of a: mask them (NotAnalyzed, no descriptor)."""
    c = {"items": [dict(it) for it in case["items"]], "edges": dict(case["edges"]), "settings": case["settings"]}
    for i in range(a):
        c["items"][i] = {"id": c["items"][i]["id"], "content_version": 0, "rotation": 0, "orientation": 1,
                         "analysis": {"status": "NotAnalyzed"}}
    return c


def compose_plan(case, cuts, with_manual_parity):
    n = len(case["items"])
    bounds = [0] + sorted(cuts) + [n]
    state, units = ("free", True, False), []
    sc, _ = scan_for(case)
    for a, b in zip(bounds, bounds[1:]):
        if a >= b:
            continue
        par = None
        if with_manual_parity and a > 0:
            par = sc.manual(a - 1)  # exact parity carried from the previous segment's facts
        summ = summary(case, a, b, with_manual_parity)
        if state[0] == "beyond":
            # the previous segment's last step consumed past b: skip objects already covered
            skip = state[1]
            state = ("consumed",) if skip == 1 else None
            if state is None:
                return None, "overrun>1"
        if state[0] == "consumed_open":
            return None, "consumed with opening=True cannot occur"
        nxt, us = summ[(state, par)] if (state, par) in summ else summ[(state, None)]
        units += us
        state = nxt
    return units, "ok"


def composition_test(trials=3000, nmax=8, seed=1, with_manual_parity=False, automatic=False):
    rng = random.Random(seed)
    bad = []
    for t in range(trials):
        n = rng.randint(2, nmax)
        st = {"direction": rng.choice(["LTR", "RTL"]), "automatic": automatic,
              "forced": rng.sample(range(n), k=min(n, rng.choice([0, 0, 1]))),
              "manual": rng.sample(range(n), k=min(n, rng.choice([0, 1, 2, 3]))),
              "opening": rng.choice(["AUTO", "FIRST_DOUBLE"])}
        states = [rng.choice(["SHAPE_X", "SHAPE_X", "SHAPE_Y"]) for _ in range(n)]
        sides = [rng.choice([G.LEFT, G.RIGHT, G.UNK]) for _ in range(n)] if automatic else None
        scores = {i: rng.choice([None, 1, 2, 3]) for i in range(n - 1)} if automatic else None
        case = G.make_case(states, sides, scores, st)
        cuts = sorted(rng.sample(range(1, n), k=rng.randint(1, n - 1)))
        whole = G.plan(case)
        comp, why = compose_plan(case, cuts, with_manual_parity)
        if comp != whole:
            bad.append({"n": n, "states": states, "settings": st, "cuts": cuts, "why": why,
                        "whole": [u["slots"] for u in whole], "composed": None if comp is None else [u["slots"] for u in comp]})
    bad.sort(key=lambda b: (b["n"], len(b["cuts"])))
    return {"trials": trials, "failures": len(bad), "minimal": bad[:3]}


# ------------------------------------------------------------------ Q094 / W01 / W02 long dependency and pseudo-resets
def parity_chain(m, first_y, direction="RTL"):
    """[X, (Y|X), X*m], automatic off: object 1 decides the pairing phase of the whole chain.
    Returns the unit of the last object."""
    states = ["SHAPE_X"] + (["SHAPE_Y"] if first_y else ["SHAPE_X"]) + ["SHAPE_X"] * m
    case = G.make_case(states, settings={"direction": direction, "automatic": False})
    return G.unit_of(G.plan(case), len(states) - 1)


def long_dependency_family(ms=(4, 8, 16, 32, 64, 128, 256)):
    rows = []
    for m in ms:
        a, b = parity_chain(m, True), parity_chain(m, False)
        rows.append({"chain": m, "unit_last_if_first_Y": a["slots"], "unit_last_if_first_X": b["slots"], "differ": a != b})
    return rows


def opening_pseudo_reset(prefix_len=6, direction="RTL"):
    """Forced object r is NOT a full reset: the opening bit survives single steps.
    World A: prefix all SHAPE_Y (no double yet -> opening True). World B: prefix starts with a double.
    Then r forced, r+1 SHAPE_X, r+2 SHAPE_Y: the unit of r+1 has reason OPENING (A) vs BEFORE_SHAPE_Y (B)."""
    r = prefix_len
    pa = ["SHAPE_Y"] * r
    pb = ["SHAPE_X", "SHAPE_X", "SHAPE_X"] + ["SHAPE_Y"] * (r - 3)
    tail = ["SHAPE_X", "SHAPE_X", "SHAPE_Y", "SHAPE_X"]
    st = {"direction": direction, "automatic": False, "forced": [r]}
    ua = G.unit_of(G.plan(G.make_case(pa + tail, settings=st)), r + 1)
    ub = G.unit_of(G.plan(G.make_case(pb + tail, settings=st)), r + 1)
    # how far back does certification read in world A?
    ca = G.certify(G.make_case(pa + tail, settings=st), r + 1)
    cb = G.certify(G.make_case(pb + tail, settings=st), r + 1)
    return {"r": r, "unit_A": ua, "unit_B": ub, "differ": ua != ub,
            "cert_A_first": ca["first"], "cert_A_support": ca["dependent_objects"],
            "cert_B_first": cb["first"], "cert_B_support": cb["dependent_objects"]}


def reset_classes(nmax=7, direction="RTL"):
    """For each candidate reset kind at boundary r (forced r, SHAPE_Y r), check on the shape domain whether all
    boundary states entering r give the same output from r on ('full reset')."""
    res = {}
    for kind in ("forced", "shape_y"):
        merged, total, wit = 0, 0, None
        for n in range(3, nmax + 1):
            for r in range(1, n - 1):
                st = {"direction": direction, "automatic": False, "forced": [r] if kind == "forced" else []}
                dom = Domain(n, False, st)
                for w in dom.worlds:
                    if kind == "shape_y" and w[0][r] != "SHAPE_Y":
                        continue
                    case = dom.case(w)
                    outs = set()
                    for s in FREE_STATES:
                        units, _ = run_from(case, r, s)
                        outs.add(tuple((u["slots"], u["reason"]) for u in units))
                    total += 1
                    if len(outs) == 1:
                        merged += 1
                    elif wit is None:
                        wit = {"n": n, "r": r, "world": w[0], "outputs": sorted([list(o) for o in outs], key=str)}
        res[kind] = {"cases": total, "full_reset": merged, "pseudo_reset": total - merged, "witness": wit}
    return res
