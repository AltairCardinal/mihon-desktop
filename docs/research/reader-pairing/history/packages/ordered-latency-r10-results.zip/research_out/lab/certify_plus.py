"""Two Route-A-preserving certificate strengthenings, both reusing Γ's step exactly (gamma.py):

BRANCH  (case analysis over unknown facts): when C09 returns NeedFacts, branch on the first need over its full
        declared value domain and re-run C07-C10 under each assignment. If every leaf is Certified with the same
        complete unit, the target projection is fixed by the known facts alone (relative to the declared value
        domains: state {X,Y}; side {L,R,U}; score {None} U an ordering-complete set of non-negative lattice
        points). Sound by construction: every completion of the unknown facts falls under some leaf.
        It cannot close gaps caused by C08's entry over-approximation (it keeps the same entries).
EXACT   (oracle-exact projection on a bounded domain, omega.projections_fast): the ground truth used to classify
        the remaining gaps.

Physical-realizability input from D05: distances are s/50 with integer 0 <= s < 1500, so a score is never
negative; branching uses only such values.
"""
from copy import deepcopy

import gamma as G

STATES = ("SHAPE_X", "SHAPE_Y")
SIDES = (G.LEFT, G.RIGHT, G.UNK)


def score_domain(case, a):
    known = [e["score"] for e in case["edges"].values() if e.get("status") == "Computed" and e.get("score") is not None]
    vals = {None, 0, 1, 2, 3}
    for k in known:
        vals |= {k - 1, k, k + 1}
    return sorted((v for v in vals if v is None or v >= 0), key=lambda v: (-1 if v is None else v))


def assign(case, need, value):
    c = deepcopy(case)
    o = need["object"]
    it = c["items"][o]
    if need["kind"] == "DIMENSIONS":
        # descriptor-level knowledge of the state (side stays unresolved unless analysis known)
        if it["analysis"]["status"] == "Computed":
            raise AssertionError("dimension need with computed analysis")
        it["descriptor"] = G.fact(value)
        it["analysis"] = {"status": "NotAnalyzed"}
    elif need["kind"] == "ORIGINAL_ANALYSIS":
        state = None
        if it.get("descriptor"):
            state = it["descriptor"]["state"]
        st, side = value
        if state is not None and st != state:
            return None  # inconsistent with known descriptor
        it["analysis"] = G.computed(st, side)
    elif need["kind"] == "EDGE_SAMPLES":
        c["edges"][(o, need["second"])] = {"status": "Computed", "score": value, "version": 1}
    return c


def domain_for(case, need):
    if need["kind"] == "DIMENSIONS":
        return list(STATES)
    if need["kind"] == "ORIGINAL_ANALYSIS":
        return [(s, d) for s in STATES for d in SIDES]
    return score_domain(case, need["object"])


def branch_certify(case, t, leaf_cap=4096):
    """Returns {'status': 'Certified'|'NeedFacts'|'RetryableBlocked'|'Capped', 'unit', 'leaves', 'base'}."""
    base = G.certify(case, t)
    if base["status"] != "NeedFacts":
        return {"status": base["status"], "unit": base["unit"], "leaves": 1, "base": base, "branched": False}
    leaves = [0]
    units = set()

    def key(u):
        return (u["slots"], u["certain"], u["reason"])

    def dfs(c):
        r = G.certify(c, t)
        if r["status"] == "Certified":
            leaves[0] += 1
            units.add(key(r["unit"]))
            return len(units) == 1
        if r["status"] == "RetryableBlocked":
            return False
        need = r["needs"][0]
        for v in domain_for(c, need):
            c2 = assign(c, need, v)
            if c2 is None:
                continue
            if not dfs(c2):
                return False
            if leaves[0] > leaf_cap:
                raise OverflowError
        return True

    try:
        ok = dfs(deepcopy(case))
    except OverflowError:
        return {"status": "Capped", "unit": None, "leaves": leaves[0], "base": base, "branched": True}
    if ok and len(units) == 1:
        (slots, certain, reason), = units
        # 'certain' in a branch-certified unit is the value common to all leaves
        return {"status": "Certified", "unit": {"slots": slots, "certain": certain, "reason": reason},
                "leaves": leaves[0], "base": base, "branched": True}
    return {"status": "NeedFacts", "unit": None, "leaves": leaves[0], "base": base, "branched": True}
