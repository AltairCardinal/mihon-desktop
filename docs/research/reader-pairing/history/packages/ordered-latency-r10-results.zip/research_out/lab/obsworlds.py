"""Pass 1: observation-equivalent legal worlds for every formal sample (identifiability).

For each formal sample we build explicit synthetic DAG worlds (package API causal.bounds, fixed lanes) that
reproduce *every* recorded field we use: intent, target_ack, unit_ack, observed_rounds, support size, idle gap.
They differ only in unobserved stage durations. We then apply the SAME intervention in each world and show that
the candidate median lands on different sides of the 30196850 ns ceiling. This proves that "fact-side work can
reach the target" is not identifiable from the formal data, and pins down the single minimal extra field
(per-sample time the exact unit became authorised, C_i, same clock scope and identity) that fixes the decision.

All durations below are hypothesis parameters, NOT fitted observations. Output raw/pass1/obsworlds.json
"""
from fractions import Fraction

from common import RAW, T_CEIL, formal_rows, median, num, write_json
from causal import bounds


def world(row, fact_share, rounds_serial=True):
    """A legal synthetic world: fact rounds (serial, compute lane) -> authorise -> consume first -> consume partner.

    fact_share in [0,1]: fraction of target_latency spent in fact rounds before authorisation.
    The remaining (target_latency - fact) is a consumption path that starts only after authorisation.
    The partner wait (unit_ack - target_ack) is a separately observed interval after the first-member ack.
    """
    L1 = row["target_latency_ns"]
    gap = row["unit_ack_ns"] - row["target_ack_ns"]
    r = max(1, row["observed_rounds"])
    fact_total = int(Fraction(L1) * Fraction(fact_share).limit_denominator(1000))
    if rounds_serial:
        per = [fact_total // r] * r
        per[-1] += fact_total - sum(per)
    else:  # already-parallel rounds: each round spans the whole fact phase so the observation is identical
        per = [fact_total] * r
    tasks = [{"id": f"round{k}", "lower_ns": d, "upper_ns": d, "resource": "fact", "observed_service": True, "kind": "fact"}
             for k, d in enumerate(per)]
    tasks.append({"id": "consume_first", "lower_ns": L1 - fact_total, "upper_ns": L1 - fact_total, "resource": "frame",
                  "observed_service": True, "kind": "consume"})
    tasks.append({"id": "consume_partner", "lower_ns": gap, "upper_ns": gap, "resource": "frame", "observed_service": True,
                  "kind": "consume"})
    edges = [(f"round{k}", f"round{k+1}") for k in range(r - 1)] + [(f"round{r-1}", "consume_first")]
    lanes = {"fact": [[f"round{k}" for k in range(r)]] if rounds_serial else [[f"round{k}"] for k in range(r)],
             "frame": [["consume_first", "consume_partner"]]}
    if not rounds_serial:
        edges = [(f"round{k}", "consume_first") for k in range(r)]
    return tasks, edges, lanes


def evaluate(row, fact_share, intervention, rounds_serial=True):
    tasks, edges, lanes = world(row, fact_share, rounds_serial)
    base = bounds(tasks, edges, lanes)
    assert base["lower_ns"] == base["upper_ns"] == row["unit_latency_ns"], (row["sample"], base)
    first_done = base["finishes"]["consume_first"][0]
    assert first_done == row["target_latency_ns"]
    C = max([base["finishes"][t["id"]][0] for t in tasks if t["kind"] == "fact"], default=0)
    if intervention == "fact_free":
        shorten = {t["id"]: 0 for t in tasks if t["kind"] == "fact"}
    elif intervention == "fact_half":
        shorten = {t["id"]: t["upper_ns"] // 2 for t in tasks if t["kind"] == "fact"}
    elif intervention == "parallelise_rounds":
        shorten = {}
        if rounds_serial:  # re-run the scheduler with one lane per round and all rounds feeding authorisation
            r = sum(1 for t in tasks if t["kind"] == "fact")
            chains = [[f"round{k}" for k in range(r) if k % 4 == j] for j in range(min(4, r))]
            lanes = dict(lanes, fact=chains)  # frozen 4 logical required+speculative slots
            edges = [(f"round{k}", "consume_first") for k in range(r)]
    else:
        raise ValueError(intervention)
    cf = bounds(tasks, edges, lanes, shorten)
    return {"observed_L": base["upper_ns"], "C_authorised_offset": C, "counterfactual_L": cf["upper_ns"]}


def interval_route(rows):
    """Route A (enumeration of ALL compatible decompositions, not three chosen worlds): for an intervention that
    removes all work strictly before authorisation, authorisation lies somewhere in [intent, first-member ack], so
    the per-sample residual lies in [U_i - target_ack_i, U_i]; medians of the bounds give the identified interval."""
    lo = [r["unit_ack_ns"] - r["target_ack_ns"] for r in rows]
    hi = [r["unit_latency_ns"] for r in rows]
    return {"candidate_median_interval_ns": [median(lo), median(hi)], "ceiling_ns": T_CEIL,
            "decision_identified": not (median(lo) <= T_CEIL <= median(hi)),
            "note": "the interval straddles the ceiling -> the GO/NO-GO decision for pre-authorisation mechanisms is not identified"}


def main():
    rows = [r for r in formal_rows() if r["group"] == "F0"]
    out = {"evidence_level": "derivation with explicit synthetic worlds; durations are hypotheses",
           "observed_fields_reproduced": ["intent_ns", "target_ack_ns", "unit_ack_ns", "observed_rounds (as round count)",
                                          "support_objects (unchanged)", "idle gaps (outside window, untouched)"],
           "worlds": {}}
    for name, share in [("W_fact_bound", Fraction(9, 10)), ("W_consume_bound", Fraction(1, 50)), ("W_mid", Fraction(1, 2))]:
        res = {}
        for iv in ["fact_free", "fact_half"]:
            per = [evaluate(r, share, iv) for r in rows]
            cf = [p["counterfactual_L"] for p in per]
            res[iv] = {"median_ns": median(cf), "passes_ceiling": median(cf) <= T_CEIL,
                       "observed_median_ns": median([p["observed_L"] for p in per])}
        res["median_unit_minus_C_ns"] = median([r["unit_latency_ns"] - evaluate(r, share, "fact_free")["C_authorised_offset"] for r in rows])
        out["worlds"][name] = {"fact_share_of_first_member_latency": share, **res}
    # The decision boundary in terms of the one extra field C_i (time authorised, same scope/identity):
    out["decision_rule"] = ("Any intervention that only removes work strictly before authorisation leaves L_i >= U_i - C_i. "
                            "Hence if median_i(U_i - C_i) > 30196850 ns, fact/proof-side work alone cannot pass (NO-GO); "
                            "if it is <= the ceiling the question stays open (necessary, not sufficient).")
    # Distinguishing power: all worlds agree on every recorded field but differ in C_i.
    out["worlds_agree_on_recorded_fields"] = True
    out["serial_vs_parallel_rounds"] = {}
    for name, ser in [("serial", True), ("parallel", False)]:
        per = [evaluate(r, Fraction(9, 10), "parallelise_rounds", ser) for r in rows]
        out["serial_vs_parallel_rounds"][name] = {"intervention": "parallelise fact rounds over the 4 shared logical slots",
                                                  "median_observed_ns": median([p["observed_L"] for p in per]),
                                                  "median_cf_ns": median([p["counterfactual_L"] for p in per]),
                                                  "passes_ceiling": median([p["counterfactual_L"] for p in per]) <= T_CEIL}
    out["route_A_interval_all_decompositions"] = interval_route(rows)
    write_json(RAW / "pass1/obsworlds.json", out)
    return out


if __name__ == "__main__":
    import json
    from common import jsonable
    print(json.dumps(jsonable(main()), indent=1))
