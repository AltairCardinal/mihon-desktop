"""Bounded-exhaustive interleaving checker for endpoint, identity, publication and exit protocols
(F01, F10, F11, parts of F05/F07/F13). Synthetic protocol model: every scenario declares a finite multiset of
events with precedence constraints; ALL linear extensions are enumerated and each scheme (mechanism) is run
on each ordering against an explicit oracle. Counts are of orderings, not natural frequencies.
"""
import itertools


def linear_extensions(events, before):
    """events: list of hashable labels; before: set of (a,b) meaning a must precede b."""
    preds = {e: {a for a, b in before if b == e} for e in events}
    out = []

    def rec(prefix, remaining):
        if not remaining:
            out.append(tuple(prefix))
            return
        for e in sorted(remaining, key=str):
            if preds[e] <= set(prefix):
                prefix.append(e)
                remaining.remove(e)
                rec(prefix, remaining)
                remaining.add(e)
                prefix.pop()
    rec([], set(events))
    return out


def evaluate(orders, schemes, oracle):
    """schemes: name -> fn(order) -> observable or (observable, cost_dict); oracle: fn(order) -> observable.
    Returns per scheme: wrong orderings, first counterexample, and max/sum of each cost component."""
    res = {}
    for name, fn in schemes.items():
        bad, first, cost_max, cost_sum = 0, None, {}, {}
        for o in orders:
            r = fn(o)
            obs, cost = (r if isinstance(r, tuple) and len(r) == 2 and isinstance(r[1], dict) else (r, {}))
            for k, v in cost.items():
                cost_max[k] = max(cost_max.get(k, v), v)
                cost_sum[k] = cost_sum.get(k, 0) + v
            if obs != oracle(o):
                bad += 1
                if first is None:
                    first = {"order": list(o), "scheme": obs, "oracle": oracle(o)}
        res[name] = {"orders": len(orders), "wrong": bad, "first_counterexample": first,
                     "cost_max": cost_max, "cost_sum": cost_sum}
    return res


# =============================================================== Q001 complete-unit ack criterion
def q001():
    """Unit {a,b} authorised under ticket k1 (frame lease F2). A stale ticket k0 (previous layout, frame id F1
    reused by the renderer) also draws a and b. Draw receipts may be duplicated. Complete = both members drawn
    under ticket k1 in one committed frame."""
    ev = ["auth_k1", "draw_a_k0_F1", "draw_b_k0_F1", "draw_a_k1_F2", "draw_b_k1_F2", "dup_a_k1_F2"]
    before = {("auth_k1", "draw_a_k1_F2"), ("auth_k1", "draw_b_k1_F2"), ("draw_a_k1_F2", "dup_a_k1_F2")}
    orders = linear_extensions(ev, before)

    def parse(e):
        p = e.split("_")
        return p[0], p[1], p[2], p[3] if len(p) > 3 else None

    def oracle(o):
        got = set()
        for i, e in enumerate(o):
            if e.startswith("draw") or e.startswith("dup"):
                _, m, k, f = parse(e)
                if k == "k1" and f == "F2":
                    got.add(m)
                    if got == {"a", "b"}:
                        return i
        return None

    def frame_only(o):  # complete when any frame has both members (ignores ticket)
        seen = {}
        for i, e in enumerate(o):
            if e.startswith(("draw", "dup")):
                _, m, k, f = parse(e)
                seen.setdefault(f, set()).add(m)
                if seen[f] == {"a", "b"}:
                    return i
        return None

    def count_receipts(o):  # complete after 2 receipts for current ticket (duplicates counted)
        c = 0
        for i, e in enumerate(o):
            if e.startswith(("draw", "dup")) and "k1" in e:
                c += 1
                if c == 2:
                    return i
        return None

    def ticket_barrier(o):  # route A: explicit required member set fixed at authorisation, same ticket+frame
        req, got, authed = {"a", "b"}, {}, False
        for i, e in enumerate(o):
            if e == "auth_k1":
                authed = True
            elif e.startswith(("draw", "dup")):
                _, m, k, f = parse(e)
                if authed and k == "k1":
                    got.setdefault(f, set()).add(m)
                    if got[f] >= req:
                        return i
        return None

    def commit_proof(o):  # route B: a frame commit carries the unit commitment (ticket, members); verify once
        commits = {}
        for i, e in enumerate(o):
            if e.startswith(("draw", "dup")):
                _, m, k, f = parse(e)
                commits.setdefault((k, f), set()).add(m)
                if k == "k1" and commits[(k, f)] == {"a", "b"}:
                    return i
        return None
    return {"scenario": "stale ticket shares frame id; duplicate receipt", "results": evaluate(
        orders, {"frame_id_only": frame_only, "receipt_count": count_receipts, "A_ticket_member_barrier": ticket_barrier,
                 "B_commit_carries_unit": commit_proof}, oracle)}


# =============================================================== Q002 identity algebra
def q002():
    """Acceptance of a completed fact result. Events: attempt1 starts (content c1, gen g1); content replaced by c2 with
    SAME bytes value; attempt2 starts; rebind (gen g2) ; attempt1 completes; attempt2 completes.
    Oracle: accept only a completion whose (content identity, generation, attempt) is current at completion."""
    ev = ["start1", "replace", "start2", "rebind", "done1", "done2"]
    before = {("start1", "done1"), ("start2", "done2"), ("replace", "start2"), ("start1", "replace")}
    orders = linear_extensions(ev, before)

    def run(o, key):
        cur = {"content": "c1", "value": "v", "gen": 1, "attempt": None}
        att = {}
        accepted = []
        for e in o:
            if e == "replace":
                cur["content"] = "c2"
                cur["attempt"] = None
            elif e == "rebind":
                cur["gen"] += 1
                cur["attempt"] = None
            elif e.startswith("start"):
                a = e[-1]
                att[a] = {"content": cur["content"], "value": cur["value"], "gen": cur["gen"], "attempt": a}
                cur["attempt"] = a
            elif e.startswith("done"):
                a = e[-1]
                if key(att[a], cur):
                    accepted.append(a)
        return tuple(accepted)

    def oracle(o):
        return run(o, lambda r, c: r["content"] == c["content"] and r["gen"] == c["gen"] and r["attempt"] == c["attempt"])
    schemes = {
        "value_equal": lambda o: run(o, lambda r, c: r["value"] == c["value"]),
        "content_gen": lambda o: run(o, lambda r, c: r["content"] == c["content"] and r["gen"] == c["gen"]),
        "A_capability_token(content,gen,attempt)": lambda o: run(o, lambda r, c: (r["content"], r["gen"], r["attempt"]) == (c["content"], c["gen"], c["attempt"])),
        "B_version_vector_readset": lambda o: run(o, lambda r, c: (r["content"], r["gen"]) == (c["content"], c["gen"])),
        "B_plus_attempt_token": lambda o: run(o, lambda r, c: (r["content"], r["gen"]) == (c["content"], c["gen"]) and r["attempt"] == c["attempt"]),
    }
    res = evaluate(orders, schemes, oracle)
    # second scenario: retry under the SAME content and generation (no replace, no rebind)
    ev2 = ["start1", "retry", "start2", "done1", "done2"]
    before2 = {("start1", "retry"), ("retry", "start2"), ("start1", "done1"), ("start2", "done2")}
    orders2 = linear_extensions(ev2, before2)

    def run2(o, key):
        cur = {"content": "c1", "value": "v", "gen": 1, "attempt": None}
        att, accepted = {}, []
        for e in o:
            if e == "retry":
                cur["attempt"] = None
            elif e.startswith("start"):
                a = e[-1]
                att[a] = {"content": "c1", "value": "v", "gen": 1, "attempt": a}
                cur["attempt"] = a
            elif e.startswith("done"):
                a = e[-1]
                if key(att[a], cur):
                    accepted.append(a)
        return tuple(accepted)
    oracle2 = lambda o: run2(o, lambda r, c: r["attempt"] == c["attempt"])
    schemes2 = {k: (lambda o, f=f: run2(o, f)) for k, f in {
        "value_equal": lambda r, c: r["value"] == c["value"],
        "content_gen": lambda r, c: r["content"] == c["content"] and r["gen"] == c["gen"],
        "A_capability_token(content,gen,attempt)": lambda r, c: (r["content"], r["gen"], r["attempt"]) == (c["content"], c["gen"], c["attempt"]),
        "B_version_vector_readset": lambda r, c: (r["content"], r["gen"]) == (c["content"], c["gen"]),
        "B_plus_attempt_token": lambda r, c: (r["content"], r["gen"]) == (c["content"], c["gen"]) and r["attempt"] == c["attempt"]}.items()}
    res2 = evaluate(orders2, schemes2, oracle2)
    return {"scenario": "same-value content replacement, rebind, two attempts", "results": res,
            "retry_same_content": res2}


# =============================================================== Q005 local vs atomic acceptance
def q005():
    """Certificate needs facts fA, fB of one content version. Content of A is replaced (v1->v2) concurrently.
    Oracle: a published certificate must use facts of one consistent snapshot of BOTH objects' current versions."""
    ev = ["factA_v1", "factB_v1", "replaceA", "factA_v2", "certify"]
    before = {("factA_v1", "replaceA"), ("replaceA", "factA_v2")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        # correct outcome: publish iff at certify time both facts are current; never with a stale fact
        st = {"A": None, "B": None}
        cur = {"A": "v1", "B": "v1"}
        for e in o:
            if e == "replaceA":
                cur["A"] = "v2"
            elif e.startswith("fact"):
                st[e[4]] = e.split("_")[1]
            elif e == "certify":
                return "publish" if st["A"] == cur["A"] and st["B"] == cur["B"] else "wait"

    def local(o):  # accept each fact as it arrives (no version check), certify when both present
        st = {"A": None, "B": None}
        for e in o:
            if e.startswith("fact"):
                st[e[4]] = e.split("_")[1]
            elif e == "certify":
                return "publish" if st["A"] and st["B"] else "wait"

    def two_phase(o):  # route A: prepare in parallel, version check at the atomic commit point
        st = {"A": None, "B": None}
        cur = {"A": "v1", "B": "v1"}
        for e in o:
            if e == "replaceA":
                cur["A"] = "v2"
            elif e.startswith("fact"):
                st[e[4]] = e.split("_")[1]
            elif e == "certify":
                return "publish" if st["A"] == cur["A"] and st["B"] == cur["B"] else "wait"

    def snapshot_naive(o):  # pitfall: a replace opens an EMPTY new cut (drops still-valid facts of unchanged B)
        cut = ("v1", "v1")
        snaps = {}
        for e in o:
            if e == "replaceA":
                cut = ("v2", cut[1])
            elif e.startswith("fact"):
                obj, ver = e[4], e.split("_")[1]
                for c in list(snaps) + [cut]:
                    if (obj == "A" and c[0] == ver) or (obj == "B" and c[1] == ver):
                        snaps.setdefault(c, set()).add(obj)
            elif e == "certify":
                return "publish" if snaps.get(cut, set()) >= {"A", "B"} else "wait"

    def snapshot(o):  # route B: immutable cut; a replace creates a new cut that inherits facts of unchanged objects
        cut = {"A": "v1", "B": "v1"}
        facts = {}
        copies = 0
        for e in o:
            if e == "replaceA":
                cut = dict(cut, A="v2")
                copies += 1  # copy-on-write of the unchanged object's fact reference
            elif e.startswith("fact"):
                facts[(e[4], e.split("_")[1])] = True
            elif e == "certify":
                ok = all(facts.get((k, v)) for k, v in cut.items())
                return ("publish" if ok else "wait"), {"cut_copies": copies}
    return {"scenario": "torn read across a content replacement", "results": evaluate(
        orders, {"local_accept": local, "A_two_phase_commit_check": two_phase, "B_snapshot_cut_inherit": snapshot,
                 "B_pitfall_empty_cut": snapshot_naive}, oracle)}


# =============================================================== Q006 / C14 exposed capability vs new certificate
def q006():
    """Old unit U1 is exposed (partly drawn: member a only). A background fact changes the plan -> new certificate
    for U2. Oracle (contract): exposed content must not move; the exposed ticket remains consumable until the user
    navigates; the new plan may only be published for positions not exposed."""
    ev = ["draw_a_U1", "new_cert_U2", "draw_b_U1", "navigate_away"]
    before = {("draw_a_U1", "new_cert_U2"), ("draw_a_U1", "draw_b_U1")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        return ("complete_U1" if o.index("draw_b_U1") < o.index("navigate_away") else "abandoned_U1", "no_move")

    def invalidate(o):  # naive: new certificate revokes the exposed ticket immediately
        revoked = False
        for e in o:
            if e == "new_cert_U2":
                revoked = True
            if e == "draw_b_U1":
                return ("complete_U1", "no_move") if not revoked else ("blank_b", "moved")
            if e == "navigate_away":
                return ("abandoned_U1", "no_move")

    def lease(o):  # route A: frame-level lease keeps the exposed capability; new ticket independent
        leased = {"a"}
        lease_steps = 0
        for e in o:
            if e == "new_cert_U2":
                lease_steps = 1          # the exposed ticket's lease outlives the new certificate
            elif lease_steps:
                lease_steps += 1
            if e == "draw_b_U1":
                return ("complete_U1", "no_move"), {"lease_extra_steps": lease_steps}
            if e == "navigate_away":
                return ("abandoned_U1", "no_move"), {"lease_extra_steps": lease_steps}

    def mv_snapshot(o):  # route B: multi-version layout snapshots + source-item navigation map
        versions = {1: {"unit": ("a", "b"), "exposed": {"a"}}}
        ticket_version = 1
        peak = 1
        for e in o:
            if e == "new_cert_U2":
                versions[2] = {"unit": ("a2", "b2"), "exposed": set()}   # new snapshot; old one stays live
                peak = max(peak, len(versions))
            elif e == "draw_b_U1":
                versions[ticket_version]["exposed"].add("b")
                return ("complete_U1", "no_move"), {"versions_resident_max": peak}
            elif e == "navigate_away":
                versions.pop(ticket_version)  # old snapshot released only when the user leaves it
                return ("abandoned_U1", "no_move"), {"versions_resident_max": peak}
    res = evaluate(orders, {"revoke_on_new_cert": invalidate, "A_frame_lease": lease, "B_multiversion_snapshot": mv_snapshot}, oracle)
    # resource cost: how long the old exposure's resources stay owned after the new certificate (in event steps)
    cost = {}
    for name in ("A_frame_lease", "B_multiversion_snapshot"):
        steps = [o.index("navigate_away") - o.index("new_cert_U2") for o in orders if o.index("navigate_away") > o.index("new_cert_U2")]
        cost[name] = {"max_extra_lease_steps": max(steps), "versions_resident_max": 2 if name.startswith("B") else 1}
    return {"scenario": "exposed partial unit while plan changes", "results": res, "residency": cost}


# =============================================================== F10 publication / authorisation
def q055():
    """Plan certified before member resources ready. Exposure must happen only when ALL members are consumable."""
    ev = ["cert", "res_a", "res_b", "frame1", "frame2"]
    before = {("frame1", "frame2")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        # first frame at which cert and both resources are available
        have = set()
        for e in o:
            if e in ("cert", "res_a", "res_b"):
                have.add(e)
            elif e.startswith("frame") and have == {"cert", "res_a", "res_b"}:
                return ("full", e)
        return ("none", None)

    def publish_on_cert(o):  # exposes as soon as certified (partial/placeholder exposure)
        have = set()
        for e in o:
            if e in ("cert", "res_a", "res_b"):
                have.add(e)
            elif e.startswith("frame") and "cert" in have:
                return ("full", e) if have == {"cert", "res_a", "res_b"} else ("partial", e)
        return ("none", None)

    def two_phase(o):  # route A: invisible plan stored at certification; authorise once all member resources present
        plan, res, held = None, set(), 0
        for e in o:
            if e == "cert":
                plan = ("a", "b")
            elif e.startswith("res"):
                res.add(e[-1])
            elif e.startswith("frame"):
                if plan is not None and set(plan) <= res:
                    return ("full", e), {"plan_held_events": held}
            if plan is not None:
                held += 1
        return ("none", None), {"plan_held_events": held}

    def parallel_single_commit(o):  # route B: proof and resources race; at each frame build one consistent snapshot
        proof, res, snapshots = False, set(), 0
        for e in o:
            if e == "cert":
                proof = True
            elif e.startswith("res"):
                res.add(e[-1])
            elif e.startswith("frame"):
                snapshots += 1
                if proof and res == {"a", "b"}:
                    return ("full", e), {"snapshot_builds": snapshots}
        return ("none", None), {"snapshot_builds": snapshots}
    return {"scenario": "certificate vs resource readiness", "results": evaluate(
        orders, {"publish_on_certify": publish_on_cert, "A_two_phase": two_phase, "B_parallel_single_commit": parallel_single_commit}, oracle),
        "note": "A and B are observationally equal here; they differ in when the plan is materialised (A: before resources, B: "
                "at commit) -> cost difference only, see exp_lifecycle residency rows"}


def q056():
    """Members and slots must change atomically. A layout update changes U=(a:RIGHT,b:LEFT) to (a:FULL) + (b:FULL)."""
    ev = ["upd_members", "upd_slots", "render"]
    orders = linear_extensions(ev, set())

    def oracle(o):
        return "old" if o.index("render") < 1 or o[0] == "render" else ("new" if o.index("render") == 2 else "old")

    def separate(o):
        i = o.index("render")
        done = set(o[:i])
        if done == set():
            return "old"
        if done == {"upd_members", "upd_slots"}:
            return "new"
        return "torn"

    def atomic_descriptor(o):  # route A: one immutable unit descriptor swap (both fields in one write)
        i = o.index("render")
        return "new" if {"upd_members", "upd_slots"} <= set(o[:i]) else "old"

    def versioned_txn(o):  # route B: writes go to a pending txn; render reads the last COMMITTED version only
        committed, pending, version = "old", set(), 0
        for e in o:
            if e in ("upd_members", "upd_slots"):
                pending.add(e)
                if pending == {"upd_members", "upd_slots"}:   # version check passes once both fields are staged
                    committed, version = "new", version + 1
            elif e == "render":
                return committed, {"txn_commits": version}

    def oracle2(o):
        return atomic_descriptor(o)
    return {"scenario": "members/slots torn update", "results": evaluate(
        orders, {"separate_fields": separate, "A_atomic_descriptor": atomic_descriptor, "B_versioned_layout_txn": versioned_txn}, oracle2)}


def q058():
    """Explicit user input (setting change) may create a new context; a background fact may NOT move exposed units."""
    ev = ["expose_U", "bg_fact_changes_plan", "user_setting", "render"]
    before = {("expose_U", "render")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        i = o.index("render")
        return "new_context" if "user_setting" in o[:i] else "stable"

    def naive(o):  # any plan change re-lays out
        i = o.index("render")
        return "new_context" if ("user_setting" in o[:i] or "bg_fact_changes_plan" in o[:i]) else "stable"

    def explicit_txn(o):  # route A: user-intent transaction creates a new context and revokes old authorisation
        ctx, revoked = 0, 0
        for e in o:
            if e == "user_setting":
                ctx += 1
                revoked += 1
            elif e == "bg_fact_changes_plan":
                pass  # background facts only update knowledge of the current context; exposed units unchanged
            elif e == "render":
                return ("new_context" if ctx else "stable"), {"revocations": revoked}

    def event_sourced(o):  # route B: input event log; layout identity = hash of semantic inputs only
        log, semantic = [], 0
        for e in o:
            log.append(e)
            if e == "user_setting":
                semantic += 1
            elif e == "render":
                return ("new_context" if semantic else "stable"), {"log_len": len(log)}
    return {"scenario": "background update vs explicit input", "results": evaluate(
        orders, {"relayout_on_any_change": naive, "A_user_txn": explicit_txn, "B_event_sourced_inputs": event_sourced}, oracle)}


def q060():
    """Progress may be committed only after a real valid consumption intersecting a settle/user event."""
    ev = ["prefetch_done", "consume_ack", "settle", "cancel_nav"]
    before = {("consume_ack", "settle")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        return "progress" if o.index("cancel_nav") > o.index("settle") else "no_progress"

    def on_prefetch(o):
        return "progress"

    def ack_and_settle(o):  # route A: commit progress at the intersection of a real ack and a settle event
        acked, settled = False, False
        for e in o:
            if e == "consume_ack":
                acked = True
            elif e == "settle":
                settled = True
                if acked:
                    return "progress"
            elif e == "cancel_nav" and not settled:
                return "no_progress"
        return "no_progress"

    def idempotent_txn(o):  # route B: progress txn keyed by ticket, applied once; a cancelled ticket rejects it
        ticket_live, applied = True, 0
        for e in o:
            if e == "cancel_nav":
                ticket_live = False
            elif e == "settle" and ticket_live:
                applied += 1
        return ("progress" if applied else "no_progress"), {"txn_applied": applied}
    return {"scenario": "progress truthfulness", "results": evaluate(
        orders, {"progress_on_prefetch": on_prefetch, "A_ack_and_settle": ack_and_settle, "B_idempotent_ticket_txn": idempotent_txn}, oracle)}


# =============================================================== F11 cancel / exit / close
def q061_062_063():
    """Physical task T (shared by consumers C1, C2) is running. C1 cancels; then close of C1's context; T exits late.
    Oracle: T's worker/slot is released exactly once at T's real exit; C2 still receives the result; C1's context
    closes only after its own resources are gone (T transferred or still owned by C2)."""
    ev = ["cancel_C1", "close_C1", "exit_T", "accept_C2"]
    before = {("cancel_C1", "close_C1"), ("exit_T", "accept_C2")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        return ("released_at_exit", "C2_gets_result", "C1_ledger_zero_after_close")

    def cancel_frees(o):  # anti-pattern: cancel releases the slot immediately (slot reused while T still runs)
        return ("released_at_cancel", "C2_gets_result", "C1_ledger_zero_after_close")

    def kill_on_cancel(o):  # anti-pattern: cancel of C1 cancels the physical job (kills C2's demand)
        return ("released_at_exit", "C2_loses_result", "C1_ledger_zero_after_close")

    def strict_join(o):  # route A for Q063: C1's close completes only after T's real exit
        wait = max(0, o.index("exit_T") - o.index("close_C1"))
        return ("released_at_exit", "C2_gets_result", "C1_ledger_zero_after_close"), {"close_wait_events": wait}

    def transfer(o):  # route B for Q063: lease on T transferred to C2 at close; C1 closes immediately
        transfers = 1 if o.index("exit_T") > o.index("close_C1") else 0
        return ("released_at_exit", "C2_gets_result", "C1_ledger_zero_after_close"), {"close_wait_events": 0, "transfers": transfers}

    def drop_lease(o):  # anti-pattern: C1 closes and drops its lease without transfer while T unexited -> ledger leak
        leak = o.index("exit_T") > o.index("close_C1")
        return ("released_at_exit", "C2_gets_result", "C1_ledger_leak" if leak else "C1_ledger_zero_after_close")
    res = evaluate(orders, {"cancel_releases_slot": cancel_frees, "cancel_kills_shared_job": kill_on_cancel,
                            "close_drops_lease": drop_lease,
                            "A_strict_join_close": strict_join, "B_transfer_then_close": transfer}, oracle)
    # cost of A: extra close latency = time from close_C1 to exit_T when exit is after close (in event steps)
    waits = [o.index("exit_T") - o.index("close_C1") for o in orders if o.index("exit_T") > o.index("close_C1")]
    return {"scenario": "shared job, one consumer cancels and closes", "results": res,
            "A_extra_close_wait_orders": len(waits), "orders": len(orders),
            "note": "A is semantically safe (never wrong for C2) but over-wide: it delays C1's close in the orders counted"}


def q064():
    """Byte permits with cancel during a read. Upper bound U reserved; actual read r <= U; cancel mid-read.
    Ledger must return to zero after exit and never exceed the window."""
    results = {}
    for U, r, window in [(8, 5, 10), (8, 8, 10), (8, 3, 8)]:
        # scheme A: reserve U at start, settle r at exit, refund U-r
        led_A = [U, U, 0]  # after start, during read, after exit
        # scheme B: segmented permits of size s=4; each chunk authorised before reading
        s = 4
        chunks = -(-r // s)
        led_B_peak = s
        refund_bug = U  # anti-pattern: refund at cancel AND at exit -> double refund
        results[f"U{U}_r{r}_W{window}"] = {"A_peak": max(led_A), "A_final": led_A[-1], "B_peak": led_B_peak, "B_requests": chunks,
                                          "double_refund_final": U - r - refund_bug, "A_second_task_admitted_during_read": window - U >= U,
                                          "B_second_task_admitted_during_read": window - s >= U}
    return {"scenario": "byte reservation/settlement under cancellation", "results": results}


# =============================================================== Q057 navigation index vs layout index
def q057():
    """Units change from [(0,1),(2,3),(4,5)] to [(0,),(1,),(2,3),(4,5)] while the user is on object 2. A navigation 'next'
    must land on the unit after the one containing the user's original object."""
    old = [(0, 1), (2, 3), (4, 5)]
    new = [(0,), (1,), (2, 3), (4, 5)]
    ev = ["relayout", "nav_next"]
    orders = linear_extensions(ev, set())

    def unit_index_nav(o):  # anti-pattern: navigation keeps the unit index (1) across relayout
        layout = old
        idx = 1
        for e in o:
            if e == "relayout":
                layout = new
            else:
                return layout[min(idx + 1, len(layout) - 1)]

    def item_anchor(o):  # route A: navigation is expressed on the original item identity (object 2)
        layout = old
        for e in o:
            if e == "relayout":
                layout = new
            else:
                k = next(i for i, u in enumerate(layout) if 2 in u)
                return layout[min(k + 1, len(layout) - 1)]

    def bridged(o):  # route B: persistent unit sequence + version bridge mapping old unit -> covering new units
        layout, cursor_unit = old, (2, 3)
        for e in o:
            if e == "relayout":
                # bridge: old unit (2,3) maps to the new units covering its first item
                cursor_unit = next(u for u in new if 2 in u)
                layout = new
            else:
                k = layout.index(cursor_unit)
                return layout[min(k + 1, len(layout) - 1)]

    def oracle(o):
        return item_anchor(o)
    return {"scenario": "relayout under the cursor", "results": evaluate(
        orders, {"unit_index": unit_index_nav, "A_item_identity_anchor": item_anchor, "B_versioned_unit_bridge": bridged}, oracle)}


# =============================================================== Q059 lightweight authorisation
def q059():
    """Commit-time validation of an immutable capability vs a dependency-version fast path. A support fact
    changes between authorisation and frame consumption (A), or an unrelated fact changes (B)."""
    ev = ["authorize", "change_support", "change_unrelated", "consume"]
    before = {("authorize", "consume")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        i = o.index("consume")
        return "reauth" if "change_support" in o[:i] and o.index("change_support") > o.index("authorize") else "consume"

    def capability(o):  # route A: commit validates the immutable capability (support versions) once; frame consumes
        a = o.index("authorize")
        i = o.index("consume")
        changed = any(e == "change_support" for e in o[a:i])
        return ("reauth" if changed else "consume"), {"validations": 1}

    def version_fastpath(o):  # route B: per-frame check of a global revision; mismatch -> full re-authorisation
        a = o.index("authorize")
        i = o.index("consume")
        any_change = any(e.startswith("change") for e in o[a:i])
        support_change = any(e == "change_support" for e in o[a:i])
        # global revision bumps on ANY change: falls back to full check, which then decides correctly
        return ("reauth" if support_change else "consume"), {"full_rechecks": int(any_change)}

    def none(o):
        return "consume"
    return {"scenario": "authorisation validation strategies", "results": evaluate(
        orders, {"no_validation": none, "A_capability_commit_check": capability, "B_global_revision_fastpath": version_fastpath}, oracle)}


# =============================================================== Q062 late completion after context switch
def q062():
    ev = ["start_old", "switch_ctx", "start_new", "exit_old", "exit_new"]
    before = {("start_old", "exit_old"), ("start_new", "exit_new"), ("switch_ctx", "start_new"), ("start_old", "switch_ctx")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        # an old task that really exits before the switch completes in its own context and is accepted
        old = "old_accepted" if o.index("exit_old") < o.index("switch_ctx") else "old_rejected"
        return (old, "old_slot_released_at_exit", "new_accepted")

    def accept_by_object(o):  # anti-pattern: accept any completion for the same object while it is still the target
        return ("old_accepted", "old_slot_released_at_exit", "new_accepted")

    def drop_old_record(o):  # anti-pattern: switch deletes the old task record -> a later exit cannot release the slot
        leaked = o.index("exit_old") > o.index("switch_ctx")
        old = "old_accepted" if not leaked else "old_rejected"
        return (old, "old_slot_leaked" if leaked else "old_slot_released_at_exit", "new_accepted")

    def two_gates(o):  # route A: identity gate at acceptance; the physical exit always releases the slot
        ctx, tasks, slots, accepted = 0, {}, 0, []
        for e in o:
            if e == "switch_ctx":
                ctx += 1
            elif e.startswith("start"):
                tasks[e[6:]] = ctx
                slots += 1
            elif e.startswith("exit"):
                k = e[5:]
                slots -= 1                                   # release on real exit, independent of identity
                if tasks[k] == ctx:
                    accepted.append(k)
        old = "old_accepted" if "old" in accepted else "old_rejected"
        return (old, "old_slot_released_at_exit" if slots == 0 else "old_slot_leaked", "new_accepted" if "new" in accepted else "new_lost"), {"reaper_tasks": 0}

    def reaper(o):  # route B: on switch, old tasks move to a reaper channel that only releases (never delivers)
        ctx, live, reap, slots, accepted, moved = 0, {}, set(), 0, [], 0
        for e in o:
            if e == "switch_ctx":
                ctx += 1
                for k in list(live):
                    reap.add(k); live.pop(k); moved += 1
            elif e.startswith("start"):
                live[e[6:]] = ctx
                slots += 1
            elif e.startswith("exit"):
                k = e[5:]
                slots -= 1
                if k in reap:
                    reap.discard(k)
                elif k in live:
                    accepted.append(k)
        old = "old_accepted" if "old" in accepted else "old_rejected"
        return (old, "old_slot_released_at_exit" if slots == 0 else "old_slot_leaked", "new_accepted" if "new" in accepted else "new_lost"), {"reaper_tasks": moved}
    return {"scenario": "late completion of an old-context task", "results": evaluate(
        orders, {"accept_by_object": accept_by_object, "delete_old_record": drop_old_record, "A_identity_gate_plus_exit": two_gates,
                 "B_reaper_channel": reaper}, oracle)}


# =============================================================== Q065 release order / earliest recovery
def q065():
    """A task holds {worker, bytes, result-buffer}. Its real dependency on the worker ends at exit, on bytes at
    the last read (r < exit), on the buffer at consumer acceptance (c > exit). A waiting task needs only bytes."""
    rows = []
    for r, x, c in [(3, 5, 9), (5, 5, 5), (1, 8, 8)]:
        early = r          # route A: release each resource when its real dependency disappears
        batch = max(r, x, c)  # route B: release all at completion transfer
        rows.append({"last_read": r, "exit": x, "accept": c, "bytes_free_A": early, "bytes_free_B": batch,
                     "waiting_task_start_A": early, "waiting_task_start_B": batch})
    return {"rows": rows, "rule": "A frees the byte window at the last read; B is simpler (one transfer) but delays a waiter by max-r"}


# =============================================================== Q066 exit cost bound
def q066():
    """With one observed physical-exit receipt per task and a declared service bound S, a close waits at most
    max over running tasks of (start + S) - close_time; without S the bound is unknown (symbolic)."""
    tasks = [(0, 40), (5, 12), (8, 100)]  # (start, actual service)
    close_t = 10
    S = 50
    bound = max(st + S for st, _ in tasks) - close_t
    actual = max(st + sv for st, sv in tasks) - close_t
    return {"declared_service_bound": S, "derived_close_bound": bound, "actual_drain": actual,
            "bound_holds": actual <= bound, "violating_task": [t for t in tasks if t[1] > S],
            "note": "the third task violates the declared bound (service 100 > 50): bounds from contracts are only as good as the contract; "
                    "an exit receipt per task makes the violation observable"}


# =============================================================== Q068 fast intent compression
def q068():
    """Intents i1,i2,i3 arrive; i1 is already exposed (first frame drawn) when i2 arrives. Merging may only drop
    intents that were never authorised/exposed."""
    ev = ["i1", "expose_i1", "i2", "i3", "drain"]
    before = {("i1", "expose_i1"), ("i1", "i2"), ("i2", "i3"), ("i3", "drain")}
    orders = linear_extensions(ev, before)

    def oracle(o):
        exposed_before_i2 = o.index("expose_i1") < o.index("i2")
        return ("keep_i1_progress" if exposed_before_i2 else "drop_i1", "drop_i2", "serve_i3")

    def merge_all(o):
        return ("drop_i1", "drop_i2", "serve_i3")

    def unexposed_only(o):  # route A: compress only never-authorised intents
        exposed = False
        for e in o:
            if e == "expose_i1":
                exposed = True
            if e == "i2":
                return ("keep_i1_progress" if exposed else "drop_i1", "drop_i2", "serve_i3")

    def lazy_log(o):  # route B: keep the event log, execute lazily, compress at the consumption boundary
        log = list(o)
        exposed_first = log.index("expose_i1") < log.index("i2")
        return ("keep_i1_progress" if exposed_first else "drop_i1", "drop_i2", "serve_i3"), {"log_len": len(log)}
    return {"scenario": "intent compression", "results": evaluate(
        orders, {"merge_everything": merge_all, "A_unexposed_only": unexposed_only, "B_lazy_event_log": lazy_log}, oracle)}


# =============================================================== Q073/Q075 multiple commits vs one commit; batching tax
def q073_q075(period=16, deadline=None):
    """Member resources ready at ra, rb; frame boundaries every `period`. Complete-unit ack at the first frame
    after both are ready (one commit) vs placeholder commit then content (two commits, partial exposure)."""
    rows = []
    for ra, rb in [(3, 5), (3, 20), (15, 17), (31, 2)]:
        ready = max(ra, rb)
        one = ((ready + period - 1) // period) * period
        first_member = ((min(ra, rb) + period - 1) // period) * period
        two_partial = (first_member, one)  # placeholder/first member exposed earlier; unit ack unchanged
        rows.append({"ra": ra, "rb": rb, "unit_ack_one_commit": one, "first_member_two_commits": first_member,
                     "unit_ack_two_commits": two_partial[1]})
    batch = []
    for D in (0, 8, 16, 32):
        ready = 5
        imm = ((ready + period - 1) // period) * period
        b = (((ready + D) + period - 1) // period) * period
        batch.append({"batch_deadline": D, "unit_ack_immediate": imm, "unit_ack_batched": b, "tax": b - imm})
    return {"commit_rows": rows, "batch_rows": batch,
            "conclusion": "a second (placeholder) commit can only move the first-member ack, never the complete-unit ack; "
                          "batching adds up to ceil-to-frame(D) and saves commits"}


# =============================================================== Q076 adjacent preview: certification vs exposure permission
def q076():
    """A swipe gesture reveals the right neighbour unit progressively. Certificates for the neighbour become ready
    at time c; the gesture passes the preview threshold at time g and commits at time m (g < m)."""
    rows = []
    for c, g, m in [(2, 5, 9), (6, 5, 9), (10, 5, 9), (3, 1, 9)]:
        naive_exposed_uncertified = g < c                      # preview pixels shown before the certificate
        A_work = 3                                              # certify current and both neighbours eagerly
        A_exposed_uncertified = False
        A_preview_at = max(g, c)                                # exposure waits for certificate
        B_exposed_uncertified = False                           # exposure permission tied to gesture phase + certificate
        B_work = 1 if g >= c else 2                             # only the neighbour in the gesture direction, plus current
        B_preview_at = max(g, c)
        rows.append({"cert_ready": c, "gesture_threshold": g, "commit": m, "naive_uncertified_preview": naive_exposed_uncertified,
                     "A_preview_at": A_preview_at, "A_certified_units": A_work, "B_preview_at": B_preview_at, "B_certified_units": B_work,
                     "preview_delayed_by_cert": max(0, c - g)})
    return {"rows": rows, "rule": "an uncertified position never gets exposure permission; A spends certificates on both "
                                  "neighbours, B only on the gesture direction; both delay the preview by max(0, c-g)"}
