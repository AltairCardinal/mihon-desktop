"""Executable reading of D04 (side analysis) and D05 (adjacent distance) plus a declared synthetic material
generator, used to build PHYSICALLY REALIZABLE worlds (Q103) and to study numeric equivalence (Q116).

Declared layout assumption (the package says sampling layout is not part of the reference): each object side
is a column profile of 144 rows (c1,c2,c3,w). Side analysis uses the 144 rows as 3 bands x 48. Distance uses 50
rows taken at positions floor(k*144/50), k=0..49, of the facing side. Any realizability statement below is
relative to this generator and is labelled as such.
"""
import itertools
import random
from fractions import Fraction

ROWS, BANDS, BAND = 144, 3, 48
DIST_POS = [k * ROWS // 50 for k in range(50)]


# ------------------------------------------------------------------ D04 side analysis
def indicator(p):
    c1, c2, c3, w = p
    return w >= 240 and c1 >= 242 and c2 >= 242 and c3 >= 242


def band_ratios(profile):
    return [Fraction(sum(indicator(p) for p in profile[b * BAND:(b + 1) * BAND]), BAND) for b in range(BANDS)]


def side_of(left_profile, right_profile):
    """Returns LEFT/RIGHT/UNKNOWN. 'Indicator-dominant side LEFT -> object at RIGHT, and vice versa.'
    (w in the indicator is the per-point weight/alpha component, as in D05's normalisation.)"""
    L, R = band_ratios(left_profile), band_ratios(right_profile)
    def dom(a, b):
        return all(x >= Fraction(9, 10) for x in a) and all(y <= Fraction(3, 4) for y in b) and all(x - y >= Fraction(1, 4) for x, y in zip(a, b))
    if dom(L, R):
        return "RIGHT"
    if dom(R, L):
        return "LEFT"
    return "UNKNOWN"


# ------------------------------------------------------------------ D05 distance
def normalize(p):
    c1, c2, c3, w = p
    return tuple((c * w + 255 * (255 - w) + 127) // 255 for c in (c1, c2, c3))


def luma_float(c):
    return .299 * c[0] + .587 * c[1] + .114 * c[2]


def luma_exact(c):
    return Fraction(299, 1000) * c[0] + Fraction(587, 1000) * c[1] + Fraction(114, 1000) * c[2]


def variance(values, exact):
    n = len(values)
    if exact:
        m = sum(values, Fraction(0)) / n
        return sum((v * v for v in values), Fraction(0)) / n - m * m
    m = sum(values) / n
    return sum(v * v for v in values) / n - m * m


def distance(a_pts, b_pts, exact=False, order="forward"):
    """a_pts: 50 raw points of the earlier object's facing side; b_pts: 50 of the later object's facing side.
    Returns ('null', reason) or ('score', value). value is Fraction when exact else float."""
    A = [normalize(p) for p in a_pts]
    B = [normalize(p) for p in b_pts]
    idx = list(range(50)) if order == "forward" else list(range(49, -1, -1))
    s = 0
    for k in idx:
        s += sum(abs(x - y) for x, y in zip(A[k], B[k]))
        if s >= 30 * 50:
            return ("null", "early_sum")
    d = Fraction(s, 50) if exact else s / 50
    def frac(P, pred):
        return sum(pred(c) for c in P) >= Fraction(4, 5) * len(P)
    if (frac(A, lambda c: min(c) > 220) and frac(B, lambda c: min(c) > 220)) or \
       (frac(A, lambda c: max(c) < 50) and frac(B, lambda c: max(c) < 50)):
        return ("null", "flat_extreme")
    la = [luma_exact(c) if exact else luma_float(c) for c in A]
    lb = [luma_exact(c) if exact else luma_float(c) for c in B]
    if order != "forward":
        la, lb = la[::-1], lb[::-1]
    if variance(la, exact) < 100 and variance(lb, exact) < 100:
        return ("null", "low_variance")
    return ("score", d)


# ------------------------------------------------------------------ generator
def profile(kind, rng, level=None):
    """kind: 'white' margin, 'dark' margin, 'textured' (art reaching edge), 'grey'."""
    rows = []
    for r in range(ROWS):
        if kind == "white":
            v = 250 if rng.random() < 0.97 else rng.randint(100, 240)
            rows.append((v, v, v, 255))
        elif kind == "dark":
            v = 10 if rng.random() < 0.97 else rng.randint(20, 120)
            rows.append((v, v, v, 255))
        elif kind == "grey":
            v = level if level is not None else 128
            rows.append((v, v, v, 255))
        else:  # textured: smooth band pattern with noise, shared seed -> continuity across the seam
            base = level if level is not None else 120
            v = max(0, min(255, base + int(60 * ((r // 12) % 2) - 30 + rng.randint(-8, 8))))
            rows.append((v, max(0, v - 10), min(255, v + 10), 255))
    return rows


def make_object(rng, left_kind, right_kind, level=None):
    return {"left": profile(left_kind, rng, level), "right": profile(right_kind, rng, level)}


def facing(obj, side):
    return [obj[side][k] for k in DIST_POS]


def object_facts(obj):
    return side_of(obj["left"], obj["right"])


def edge_score(earlier, later, direction="RTL", exact=True):
    if direction == "RTL":
        return distance(facing(earlier, "left"), facing(later, "right"), exact)
    return distance(facing(earlier, "right"), facing(later, "left"), exact)


def realizable_pairs(trials=4000, seed=3, direction="RTL"):
    """Enumerate (side_earlier, side_later, score_kind) combinations reachable from the generator."""
    rng = random.Random(seed)
    kinds = ["white", "dark", "textured", "grey"]
    seen = {}
    for _ in range(trials):
        lvl = rng.randint(30, 220)
        a = make_object(rng, rng.choice(kinds), rng.choice(kinds), lvl)
        b = make_object(rng, rng.choice(kinds), rng.choice(kinds), lvl + rng.randint(-10, 10))
        sa, sb = object_facts(a), object_facts(b)
        r = edge_score(a, b, direction)
        key = (sa, sb, r[0] if r[0] == "null" else "score")
        seen[key] = seen.get(key, 0) + 1
    return seen


def search_float_flip(trials=200000, seed=7):
    """Q116: search points where float and exact evaluation of the variance gate disagree (near 100)."""
    rng = random.Random(seed)
    flips = []
    for t in range(trials):
        # construct a luma sample set whose exact variance is within 1e-9 of 100
        base = rng.randint(60, 190)
        vals = [(base, base, base)] * 25 + [(base + 20, base + 20, base + 20)] * 25  # variance exactly 100 in luma
        if rng.random() < 0.5:
            # perturb one colour channel so luma changes by small rational amounts
            k = rng.randrange(50)
            c = list(vals[k])
            c[rng.randrange(3)] += rng.choice([-1, 1])
            vals = vals[:k] + [tuple(c)] + vals[k + 1:]
        le = [luma_exact(c) for c in vals]
        lf = [luma_float(c) for c in vals]
        ve, vf = variance(le, True), variance(lf, False)
        if (ve < 100) != (vf < 100):
            flips.append({"trial": t, "exact": str(ve), "float": vf, "values": vals[:3] + ["..."]})
            if len(flips) >= 5:
                break
    return flips


# ------------------------------------------------------------------ constructive realizability witnesses
def strip(white_rows, nonwhite_value=128):
    """A 144-row strip: rows in white_rows are (250,250,250,255), others grey nonwhite_value."""
    return [(250, 250, 250, 255) if r in white_rows else (nonwhite_value,) * 3 + (255,) for r in range(ROWS)]


def white_dominant_rows(sampled_nonwhite=True, per_band_nonwhite=4):
    """>=90% white in every band (44/48); the non-white rows are put ON sampled distance positions if asked."""
    rows = set(range(ROWS))
    for b in range(BANDS):
        band = range(b * BAND, (b + 1) * BAND)
        pool = [r for r in band if (r in DIST_POS) == sampled_nonwhite]
        for r in pool[:per_band_nonwhite]:
            rows.discard(r)
    return rows


def low_white_rows(white_on_sampled=True, count=36):
    """<=count/48 white per band while keeping sampled positions white where possible."""
    rows = set()
    for b in range(BANDS):
        band = list(range(b * BAND, (b + 1) * BAND))
        pref = [r for r in band if (r in DIST_POS) == white_on_sampled] + [r for r in band if (r in DIST_POS) != white_on_sampled]
        rows |= set(pref[:count])
    return rows


def witness(side_e, side_l, want, direction="RTL"):
    """Try to construct earlier/later objects with given sides and edge result kind ('score'/'null')."""
    textures = {
        "dom": [white_dominant_rows(True), white_dominant_rows(False), set(range(ROWS))],
        "low": [low_white_rows(True, 32), low_white_rows(True, 36), low_white_rows(False, 32), set()],
    }
    # earlier facing strip = left in RTL, later facing strip = right in RTL
    fe, oe = ("left", "right") if direction == "RTL" else ("right", "left")
    fl, ol = ("right", "left") if direction == "RTL" else ("left", "right")
    def need(side, facing_name):
        # which strip must be white-dominant for the requested side (LEFT-dominant -> object RIGHT)
        if side == "RIGHT":
            return {"left": "dom", "right": "low"}[facing_name]
        if side == "LEFT":
            return {"left": "low", "right": "dom"}[facing_name]
        return "any"
    textures["any"] = textures["dom"] + textures["low"]
    for fe_rows in textures[need(side_e, fe)]:
        for oe_rows in textures[need(side_e, oe)]:
            for fl_rows in textures[need(side_l, fl)] + [fe_rows]:
                for ol_rows in textures[need(side_l, ol)]:
                    for gv in (128, 200, 210, 215, 218, 236):
                        E = {fe: strip(fe_rows, gv), oe: strip(oe_rows, gv)}
                        Lo = {fl: strip(fl_rows, gv), ol: strip(ol_rows, gv)}
                        if object_facts(E) != side_e or object_facts(Lo) != side_l:
                            continue
                        r = edge_score(E, Lo, direction)
                        if (r[0] == "null") == (want == "null"):
                            return {"found": True, "edge": [r[0], str(r[1])], "grey": gv}
    return {"found": False}


# ------------------------------------------------------------------ Q116 route B: fast path with near-threshold fallback
def distance_fast_with_fallback(a_pts, b_pts, eps=1e-6, fast="exact"):
    """Fast path computes the variance gate with a different backend (exact rationals or reversed float order);
    if either side's variance is within eps of the 100 threshold, recompute with the REFERENCE float sequence.
    Returns (result, used_fallback)."""
    A = [normalize(p) for p in a_pts]
    B = [normalize(p) for p in b_pts]
    s = 0
    for k in range(50):
        s += sum(abs(x - y) for x, y in zip(A[k], B[k]))
        if s >= 1500:
            return ("null", "early_sum"), False
    def frac(P, pred):
        return sum(pred(c) for c in P) >= Fraction(4, 5) * len(P)
    if (frac(A, lambda c: min(c) > 220) and frac(B, lambda c: min(c) > 220)) or \
       (frac(A, lambda c: max(c) < 50) and frac(B, lambda c: max(c) < 50)):
        return ("null", "flat_extreme"), False
    if fast == "exact":
        va, vb = variance([luma_exact(c) for c in A], True), variance([luma_exact(c) for c in B], True)
    else:
        va, vb = variance([luma_float(c) for c in A][::-1], False), variance([luma_float(c) for c in B][::-1], False)
    if abs(float(va) - 100) < eps or abs(float(vb) - 100) < eps:
        return distance(a_pts, b_pts, exact=False), True
    if va < 100 and vb < 100:
        return ("null", "low_variance"), False
    return ("score", s / 50), False
