"""F08 / W05-W07 / C07 / C19: synthetic navigation + dual-capacity cache model on top of gamma.py.

NOT a reconstruction of the private implementation's cache (no attempt is made to infer its policy from N0).
Resources (frozen numbers of the separate negative route, used here as model parameters):
  materialisation cache MAT=7 decoded objects, sample cache SMP=16 facing-strip samples, scalar facts persist.
Per navigation step to target t:
  1. certify t with known scalar facts; each round acquire needs:
       DIMENSIONS(o)        descriptor probe (no transform)
       ORIGINAL_ANALYSIS(o) needs o materialised (transform if not cached); yields o's samples
       EDGE_SAMPLES(a,b)    needs samples of a and b (from sample cache, else materialise)
     strong=True: before acquiring, try the BRANCH certificate (certify_plus); if it certifies, stop.
  2. visible consumption: every unit member must be materialised.
  3. optional prefetch of the next unit in the navigation direction.
Counts: transforms (materialisations), descriptor probes, certification rounds. No time.
"""
import itertools
from collections import OrderedDict

import certify_plus as CP
import evidence as E
import gamma as G


class Cache:
    def __init__(self, cap, policy="lru"):
        self.cap, self.policy, self.d = cap, policy, OrderedDict()

    def has(self, k):
        if k in self.d:
            self.d.move_to_end(k)
            return True
        return False

    def put(self, k, pos=None):
        self.d[k] = True
        self.d.move_to_end(k)
        while len(self.d) > self.cap:
            if self.policy == "lru" or pos is None:
                self.d.popitem(last=False)
            else:  # distance policy: evict the object farthest from the current position
                far = max(self.d, key=lambda x: (abs(x - pos), x))
                del self.d[far]


class Nav:
    def __init__(self, world, settings, mat=7, smp=16, policy="lru", prefetch=True, strong=False):
        self.world, self.settings = world, settings
        self.K = E.Knowledge(world, settings)
        self.mat, self.smp = Cache(mat, policy), Cache(smp, policy)
        self.prefetch, self.strong = prefetch, strong
        self.transforms, self.probes, self.rounds, self.strong_used = 0, 0, 0, 0
        self.plan = G.plan(G.make_case(*world, settings))
        self.pos = 0

    def materialise(self, o):
        if not self.mat.has(o):
            self.transforms += 1
            self.mat.put(o, self.pos)
        self.smp.put(o, self.pos)

    def samples(self, o):
        if not self.smp.has(o):
            self.materialise(o)

    def certify(self, t):
        while True:
            case = self.K.case()
            c = G.certify(case, t)
            if c["status"] == "Certified":
                return c["unit"]
            if self.strong:
                b = CP.branch_certify(case, t)
                if b["status"] == "Certified":
                    self.strong_used += 1
                    return b["unit"]
            self.rounds += 1
            for nd in c["needs"]:
                k, o = nd["kind"], nd["object"]
                if k == "DIMENSIONS":
                    if o not in self.K.dim:
                        self.probes += 1
                        self.K.dim.add(o)
                elif k == "ORIGINAL_ANALYSIS":
                    self.materialise(o)
                    self.K.an.add(o)
                    self.K.dim.add(o)
                else:
                    self.samples(o)
                    self.samples(nd["second"])
                    self.K.edge.add(o)

    def go(self, t, direction=+1):
        self.pos = t
        unit = self.certify(t)
        truth = G.unit_of(self.plan, t)
        assert unit["slots"] == truth["slots"], ("first-slot error", t)
        for o, _ in unit["slots"]:
            self.materialise(o)
        if self.prefetch:
            members = [o for o, _ in unit["slots"]]
            nxt = (max(members) + 1) if direction > 0 else (min(members) - 1)
            if 0 <= nxt < len(self.plan) + 0 and nxt < self.K.n:
                for o, _ in G.unit_of(self.plan, nxt)["slots"]:
                    self.materialise(o)
        return unit


def run_history(world, settings, history, **kw):
    nav = Nav(world, settings, **kw)
    prev = None
    for t in history:
        nav.go(t, +1 if prev is None or t >= prev else -1)
        prev = t
    return {"transforms": nav.transforms, "probes": nav.probes, "rounds": nav.rounds, "strong_used": nav.strong_used}


def unit_starts(world, settings):
    return [u["slots"][0][0] for u in G.plan(G.make_case(*world, settings))]


def shortest_gain_history(world, settings, max_len=4, kw=None):
    """BFS over histories of unit-start targets (any jump allowed) of length <= max_len, start anywhere.
    Returns the first (shortest) history where strong proofs save >= 1 transform, plus counts."""
    kw = kw or {}
    starts = unit_starts(world, settings)
    tried = 0
    for L in range(1, max_len + 1):
        for h in itertools.product(starts, repeat=L):
            if any(a == b for a, b in zip(h, h[1:])):
                continue
            tried += 1
            a = run_history(world, settings, h, strong=False, **kw)
            b = run_history(world, settings, h, strong=True, **kw)
            if b["transforms"] < a["transforms"]:
                return {"history": h, "length": L, "ordinary": a, "strong": b, "histories_tried": tried}
    return {"history": None, "histories_tried": tried}
