"""Shared helpers for the R10 research lab (standard library only).

All files written by the lab go under research_out/raw or research_out/summary.
Nothing in the original package is modified.
"""
import json
import os
import platform
import sys
from fractions import Fraction
from pathlib import Path

LAB = Path(__file__).resolve().parent
OUT = LAB.parent
PKG = OUT.parent
RAW = OUT / "raw"
SUMMARY = OUT / "summary"
T_CEIL = 30196850          # frozen candidate median ceiling (ns)
REF_MEDIAN = 130196850     # frozen historical reference median (ns)
GUARD = 16000000           # group-median regression guard (ns)

sys.path.insert(0, str(PKG / "code"))


def load_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


def formal_rows():
    return load_jsonl(PKG / "data/formal_samples.jsonl")


def median(values):
    v = sorted(values)
    n = len(v)
    if not n:
        return None
    return Fraction(v[n // 2]) if n % 2 else Fraction(v[n // 2 - 1] + v[n // 2], 2)


def num(x):
    if isinstance(x, Fraction):
        return x.numerator if x.denominator == 1 else float(x)
    return x


def jsonable(o):
    if isinstance(o, Fraction):
        return num(o)
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, set):
        return sorted(jsonable(v) for v in o)
    return o


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(jsonable(obj), f, ensure_ascii=False, indent=1, sort_keys=False)
        f.write("\n")
    return path


def env():
    return {"python": sys.version.split()[0], "implementation": platform.python_implementation(),
            "platform": platform.platform(), "pid": os.getpid()}
