"""Check that every Q/C id listed in REPORT.md section 4 sits under the category its coverage.csv decision says."""
import csv
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
rows = {r["id"]: r for r in csv.DictReader(open(OUT / "coverage.csv", encoding="utf-8"))}
text = (OUT / "REPORT.md").read_text(encoding="utf-8")
sec = text.split("## 4. 分类清单")[1].split("## 5.")[0]
cats = {"可进入小型工程试验": "engineering_trial", "只需补观测": "probe_first", "只有条件理论": "conditional_theory", "停止": "stop", "未完成": None}


def expand(s):
    ids = set()
    for m in re.finditer(r"Q(\d{3})–Q?(\d{3})", s):
        ids |= {f"Q{k:03d}" for k in range(int(m.group(1)), int(m.group(2)) + 1)}
    s2 = re.sub(r"Q\d{3}–Q?\d{3}", "", s)
    ids |= set(re.findall(r"Q\d{3}|C\d{2}(?!\d)", s2))
    return ids


def all_ids(sec):
    return expand(sec)


problems, seen = [], {}
for line in sec.splitlines():
    for name, dec in cats.items():
        if line.strip().startswith(f"- **{name}"):
            cur = (name, dec)
            break
    else:
        if not line.strip().startswith("  -"):
            continue
    ids = expand(line)
    name, dec = cur
    for i in ids:
        if dec is None:
            if rows[i]["status"] != "incomplete":
                problems.append((i, "listed as incomplete but status", rows[i]["status"]))
            continue
        if "header" in line and i in ("Q034", "Q107"):
            continue
        seen.setdefault(i, set()).add(dec)
        if rows[i]["decision"] != dec:
            problems.append((i, f"listed under {dec}", rows[i]["decision"]))
dups = {k: v for k, v in seen.items() if len(v) > 1}
print("problems:", problems, "duplicates:", dups, "not_mentioned:", sorted(set(rows) - all_ids(sec)))
