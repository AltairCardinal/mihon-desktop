#!/bin/sh
# Re-run every R10 experiment from the package root. Order matters (combos read earlier outputs).
set -e
cd "$(dirname "$0")/.."
P="python3 -B"
$P research_out/lab/reach.py > /dev/null
$P research_out/lab/n0_structure.py > /dev/null
$P research_out/lab/obsworlds.py > /dev/null
$P research_out/lab/gamma_xcheck.py 20000
$P research_out/bench/exp_certificates.py
$P research_out/bench/exp_evidence.py
$P research_out/bench/exp_gamma2.py > /dev/null
$P research_out/bench/exp_q097.py > /dev/null
$P research_out/bench/exp_q097b.py > /dev/null
$P research_out/bench/exp_summarytree.py > /dev/null
$P research_out/bench/exp_cache.py > /dev/null
$P research_out/bench/exp_sched.py > /dev/null
$P research_out/bench/exp_lifecycle.py > /dev/null
$P research_out/bench/exp_stats.py > /dev/null
$P research_out/bench/exp_misc.py > /dev/null
$P research_out/bench/exp_combos.py > /dev/null
$P research_out/bench/exp_workloads.py > /dev/null
$P research_out/bench/bench_micro.py drive
$P research_out/records/build.py
$P research_out/tests/test_r10.py
echo "done"
