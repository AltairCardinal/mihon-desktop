"""Q098/Q099: exactness of the summary tree and checkpoints against gamma.plan (incl. updates).
Output raw/gamma/summarytree_exactness.json"""
import random
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import evidence as E
import gamma as G
import summarytree as STR
from common import RAW, env, write_json

out = {"env": env()}
rng = random.Random(2)
bad = tot = 0
for trial in range(40):
    n = rng.randint(10, 60)
    w = E.random_world(n, rng)
    stg = {"direction": rng.choice(["LTR", "RTL"]), "automatic": True, "manual": rng.sample(range(n), k=rng.randint(0, 6)),
           "forced": rng.sample(range(n), k=rng.randint(0, 2)), "opening": rng.choice(["AUTO", "FIRST_DOUBLE"])}
    case = G.make_case(*w, stg)
    tr = STR.SummaryTree(case, leaf=rng.choice([4, 8]))
    ck = STR.Checkpoints(case, 8)
    for _ in range(6):
        t = rng.randrange(n)
        tot += 1
        truth = G.unit_of(G.plan(case), t)
        bad += (tr.unit(t) != truth) or (ck.unit(t) != truth)
        p = rng.randrange(n)
        st = list(w[0]); st[p] = "SHAPE_Y" if st[p] == "SHAPE_X" else "SHAPE_X"; w = (st, w[1], w[2])
        case = G.make_case(*w, stg); tr.update(case, p); ck.update(case, p)
out["with_updates"] = {"queries": tot, "mismatches": bad}
rng = random.Random(4)
bad = tot = 0
for trial in range(60):
    n = rng.randint(10, 60)
    w = E.random_world(n, rng)
    stg = {"direction": rng.choice(["LTR", "RTL"]), "automatic": True, "manual": rng.sample(range(n), k=rng.randint(0, 6)),
           "forced": rng.sample(range(n), k=rng.randint(0, 2)), "opening": rng.choice(["AUTO", "FIRST_DOUBLE"])}
    case = G.make_case(*w, stg)
    tr = STR.SummaryTree(case, leaf=rng.choice([2, 4, 8]))
    plan = G.plan(case)
    for t in range(n):
        tot += 1
        bad += tr.unit(t) != G.unit_of(plan, t)
out["all_targets"] = {"queries": tot, "mismatches": bad}
write_json(RAW / "gamma/summarytree_exactness.json", out)
print(out)
