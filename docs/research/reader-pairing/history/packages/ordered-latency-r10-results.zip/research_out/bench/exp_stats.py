"""F14/F15 statistics and experiment-design checks (historical recomputation + seeded simulation).

Simulations resample the anonymous F0 latencies only as a NOISE SHAPE for null-effect designs; they are not
predictions of any new run. Output raw/stats/stats.json
"""
import math
import random
import sys
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
from common import GUARD, PKG, RAW, T_CEIL, env, formal_rows, load_jsonl, median, num, write_json

ROWS = formal_rows()
F0 = {r["sample"]: r for r in ROWS if r["group"] == "F0"}
F1 = {r["sample"]: r for r in ROWS if r["group"] == "F1"}


def passes(ref, cand):
    """Frozen main rule on two lists of 50 (all valid): median(ref)-median(cand) >= max(15% ref median, 100 ms)."""
    mr, mc = median(ref), median(cand)
    return mr - mc >= max(mr * Fraction(3, 20), 100000000)


# ------------------------------------------------------------- Q079 estimators
def q079():
    ids = sorted(F0)
    diffs = [F0[i]["unit_latency_ns"] - F1[i]["unit_latency_ns"] for i in ids]
    dom = median([F0[i]["unit_latency_ns"] for i in ids]) - median([F1[i]["unit_latency_ns"] for i in ids])
    # constructed counterexample: opposite signs
    a = [1, 2, 3, 10, 11]
    b = [0, 1, 4, 9, 12]   # paired by index: median(a)-median(b) = -1 while the median paired difference is +1
    return {"formal_difference_of_medians": dom, "formal_median_of_same_id_differences": median(diffs),
            "formal_mean_difference": Fraction(sum(diffs), len(diffs)),
            "share_same_id_improved": sum(d > 0 for d in diffs), "n": len(diffs),
            "counterexample": {"ref": a, "cand": b, "difference_of_medians": median(a) - median(b),
                               "median_of_paired_differences": median([x - y for x, y in zip(a, b)])},
            "note": "difference of medians is the frozen estimand; paired-difference median is auxiliary and can have the opposite sign"}


# ------------------------------------------------------------- Q081 group guard vs single-sample regressions
def q081():
    ids = sorted(F0)
    reg = sorted(((F1[i]["unit_latency_ns"] - F0[i]["unit_latency_ns"], i, F0[i]["scenario"], F0[i]["target_object"]) for i in ids), reverse=True)
    over = [x for x in reg if x[0] > GUARD]
    # constructed: group of 3 passes the median guard while one member regresses by 100 ms
    g0 = [100, 100, 100]
    g1 = [90, 110, 200]
    return {"same_id_regressions_over_16ms": [(num(Fraction(d)), i, s, t) for d, i, s, t in over], "count": len(over),
            "max_same_id_regression_ns": reg[0][0],
            "constructed": {"ref": g0, "cand": g1, "group_median_regression": median(g1) - median(g0), "max_single": max(b - a for a, b in zip(g0, g1))},
            "note": "historical group guards passed (max group regression 15447301 ns) although several same-ID samples regressed by more than 16 ms; the guard is a group-median rule, not a per-sample bound"}


# ------------------------------------------------------------- Q082 nearest-rank P95 and distribution-free bounds
def q082(n=50, p=Fraction(95, 100)):
    k = math.ceil(0.95 * n)
    def cdf_ge(j):  # P(X_(j) >= q_p) = P(Bin(n,p) < j)
        return sum(math.comb(n, i) * float(p) ** i * (1 - float(p)) ** (n - i) for i in range(j))
    cover = {j: cdf_ge(j) for j in range(44, n + 1)}
    return {"n": n, "nearest_rank_index": k, "P(X_(j) >= q95)": cover,
            "max_as_upper_bound_confidence": cover[n], "x48_as_upper_bound_confidence": cover[48],
            "note": "with n=50 even the sample maximum is only a ~92.3% upper confidence bound for the population 95th percentile; "
                    "nearest-rank P95 (x_(48)) is a point estimate with ~46% chance of being below q95"}


# ------------------------------------------------------------- Q083 failures and censoring (R0)
def q083():
    rej = load_jsonl(PKG / "data/rejected_samples.jsonl")
    ok = [r["unit_latency_ns"] for r in rej if not r["failure"] and r["unit_latency_ns"] is not None]
    nfail = sum(1 for r in rej if r["failure"])
    lo = ok + [0] * nfail
    hi = ok + [15_000_000_000] * nfail
    return {"planned": len(rej), "failures": nfail, "success_only_median": median(ok),
            "bounds_if_failures_were_timings": [median(lo), median(hi)],
            "success_only_n": len(ok),
            "note": "a success-only median is not an estimate of the planned arm; R0 also had first-slot errors, so it is invalid "
                    "regardless of timing (correctness gate first)"}


# ------------------------------------------------------------- Q084 drift sensitivity and design size
def q084():
    # within-cell spread of F0 (same scenario/target), as a noise scale for a future blocked design
    cells = defaultdict(list)
    for r in F0.values():
        cells[(r["scenario"], r["target_object"])].append(r["unit_latency_ns"])
    adv = [v for (s, t), v in cells.items() if s == "advance"]
    pooled = []
    for v in adv:
        m = sum(v) / len(v)
        pooled += [(x - m) ** 2 for x in v]
    sd = math.sqrt(sum(pooled) / (len(pooled) - len(adv)))
    # paired same-ID design: n needed so that a 15 ms mean shift has 2-sided 5%/80% power (normal approx)
    n_needed = math.ceil(((1.96 + 0.84) * sd * math.sqrt(2) / 15e6) ** 2)
    return {"advance_within_cell_sd_ns": sd, "n_pairs_for_15ms_mean_shift": n_needed,
            "drift_that_explains_all": "any common additive drift of >= 15.012 ms between the non-adjacent F0 and F1 sessions "
                                       "reproduces the historical difference with zero code effect (observationally equivalent)",
            "design": "ABBA blocks within one session, each block = the 50-sample design, interleaved per runtime; report both arms' full denominators"}


# ------------------------------------------------------------- Q085/Q089 rerun-to-green and selection under a null
def q085_q089(sims=4000, seed=17):
    rng = random.Random(seed)
    strata = defaultdict(list)
    for r in F0.values():
        strata[r["scenario"]].append(r["unit_latency_ns"])
    def arm():  # stratified resample keeps the frozen design (30 advance, 10 new_start, 10 reopen)
        return [rng.choice(v) for k, v in strata.items() for _ in range(len(v))]
    out = {}
    for delta in (5_000_000, 15_000_000):
        def gain():
            return median(arm()) - median(arm())
        single = sum(gain() >= delta for _ in range(sims)) / sims
        rerun5 = sum(any(gain() >= delta for _ in range(5)) for _ in range(sims // 5)) / (sims // 5)
        # select the best of 5 null 'candidates' on an exploration run, then judge once on a fresh held-out run
        held = 0
        for _ in range(sims // 5):
            ref = arm()
            best = max((arm() for _ in range(5)), key=lambda c: median(ref) - median(c))
            held += (median(arm()) - median(arm())) >= delta  # held-out: candidate code identical to reference
        out[f"gate_{delta}"] = {"null_pass_single": single, "null_pass_best_of_5_reruns": rerun5,
                                "null_pass_heldout_after_selection": held / (sims // 5)}
    out["frozen_main_rule_null_pass_single"] = sum(passes(arm(), arm()) for _ in range(2000)) / 2000
    out["note"] = ("noise shape = resampled F0; reruns until green inflate the false pass rate; a single pre-declared held-out "
                   "run after selection restores the single-run rate. The frozen 100 ms rule is essentially never passed by noise.")
    return out


# ------------------------------------------------------------- Q086 order / carryover
def q086(sims=2000, seed=19):
    rng = random.Random(seed)
    base = [r["unit_latency_ns"] for r in F0.values() if r["scenario"] == "advance"]
    warm = 8_000_000  # hypothetical warm-cache benefit for whichever arm runs second
    fixed, abba = [], []
    for _ in range(sims):
        off = [rng.choice(base) for _ in range(30)]
        on = [rng.choice(base) - warm for _ in range(30)]  # zero true effect; ON always second
        fixed.append(float(median(off) - median(on)))
        a1 = [rng.choice(base) for _ in range(15)]
        b1 = [rng.choice(base) - warm for _ in range(15)]
        b2 = [rng.choice(base) for _ in range(15)]
        a2 = [rng.choice(base) - warm for _ in range(15)]
        abba.append(float(median(a1 + a2) - median(b1 + b2)))
    return {"true_effect": 0, "hypothetical_carryover_ns": warm, "fixed_OFF_then_ON_mean_estimate": sum(fixed) / sims,
            "ABBA_mean_estimate": sum(abba) / sims}


# ------------------------------------------------------------- Q093 per-sample ideal vs one common policy
def q093():
    """50 samples, two admissible policies. Policy P1 brings samples 0..23 to 20 ms (others stay 120 ms); P2 brings
    samples 24..47 to 20 ms. Per-sample best-of-two puts 48 samples at 20 ms (median 20 ms, passes), but every
    common policy has only 24 samples <= T (median 120 ms, fails)."""
    T = T_CEIL
    base = [120_000_000] * 50
    p1 = [20_000_000 if i < 24 else 120_000_000 for i in range(50)]
    p2 = [20_000_000 if 24 <= i < 48 else 120_000_000 for i in range(50)]
    per_sample = [min(a, b) for a, b in zip(p1, p2)]
    return {"per_sample_best_median": median(per_sample), "per_sample_best_passes": median(per_sample) <= T,
            "P1_median": median(p1), "P2_median": median(p2), "common_policy_passes": max(median(p1), median(p2)) <= T,
            "lesson": "order statistics of per-sample lower bounds are valid only if one common deployable policy attains them"}


def main():
    out = {"env": env()}
    for name, fn in [("Q079", q079), ("Q081", q081), ("Q082", q082), ("Q083", q083), ("Q084", q084), ("Q085_Q089", q085_q089), ("Q086", q086), ("Q093", q093)]:
        out[name] = fn()
        print(name, str(out[name])[:300], flush=True)
    write_json(RAW / "stats/stats.json", out)


if __name__ == "__main__":
    main()
