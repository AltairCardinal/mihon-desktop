"""F16/F18 experiment: acquisition rounds, materialisations and waste for evidence policies; fixed-window error.

Seeded synthetic worlds on gamma.py; no time is attached to rounds. Output raw/gamma/evidence.json
"""
import random
import statistics as S
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import evidence as E
import gamma as G
from common import RAW, env, write_json

FAMILIES = {
    "booklike": dict(p_y=0.08, p_side=0.15, p_null=0.3, smax=20),
    "no_side_chain": dict(p_y=0.0, p_side=0.0, p_null=0.0, smax=40),
    "sparse_side": dict(p_y=0.02, p_side=0.03, p_null=0.1, smax=40),
}


def q(v):
    v = sorted(v)
    return {"n": len(v), "min": v[0], "median": S.median(v), "p90": v[int(0.9 * (len(v) - 1))], "max": v[-1]}


def main(trials=300, n=60, seed=11):
    out = {"env": env(), "trials": trials, "n": n, "seed": seed, "families": {}}
    for fam, kw in FAMILIES.items():
        rng = random.Random(seed)
        st = {"direction": "RTL", "automatic": True}
        rows = []
        for _ in range(trials):
            w = E.random_world(n, rng, **kw)
            t = rng.randrange(20, n - 3)
            full = G.unit_of(G.plan(G.make_case(*w, st)), t)
            r = {}
            for name, kw2 in [("need4", dict(slots=4)), ("need1", dict(slots=1)), ("need4_unshared", dict(slots=4, shared=False)),
                              ("gallop4", dict(slots=4, gallop=True))]:
                a = E.acquire_loop(w, st, t, **kw2)
                assert a["unit"] == full, (fam, name)
                r[name] = a
            r["trunc"] = {lb: E.truncated_window(w, st, t, lb) != full for lb in (2, 3, 5, 8, 16)}
            rows.append(r)
        fo = {}
        for name in ["need4", "need1", "need4_unshared", "gallop4"]:
            fo[name] = {"rounds": q([r[name]["rounds"] for r in rows]),
                        "materialisations": q([r[name]["materialisations"] for r in rows]),
                        "support": q([r[name]["support"] for r in rows]),
                        "waste": q([r[name]["waste"] for r in rows])}
        fo["fixed_window_wrong_unit"] = {lb: sum(r["trunc"][lb] for r in rows) for lb in (2, 3, 5, 8, 16)}
        fo["rounds_vs_support_pairs"] = [(r["need4"]["support"], r["need4"]["rounds"]) for r in rows]
        fo["gallop_saves_rounds"] = sum(r["gallop4"]["rounds"] < r["need4"]["rounds"] for r in rows)
        fo["gallop_costs_rounds"] = sum(r["gallop4"]["rounds"] > r["need4"]["rounds"] for r in rows)
        fo["params"] = kw
        out["families"][fam] = fo
        print(fam, {k: (v["rounds"]["median"], v["rounds"]["max"], v["materialisations"]["median"]) for k, v in fo.items() if isinstance(v, dict) and "rounds" in v},
              fo["fixed_window_wrong_unit"], fo["gallop_saves_rounds"], fo["gallop_costs_rounds"], flush=True)
    write_json(RAW / "gamma/evidence.json", out)


if __name__ == "__main__":
    main()
