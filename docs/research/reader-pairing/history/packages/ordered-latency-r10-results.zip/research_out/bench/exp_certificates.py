"""F09/F17/F18 experiment: certificate soundness, incompleteness gaps, and what closes them.

Bounded exhaustion / seeded sampling on gamma.py (researcher reconstruction). Output raw/gamma/certificates.json
Usage: python3 -B exp_certificates.py [quick]
"""
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import certify_plus as CP
import gamma as G
import omega as O
from common import RAW, env, write_json

QUICK = len(sys.argv) > 1 and sys.argv[1] == "quick"


def run_domain(n, auto, settings, n_worlds, n_know, seed):
    rng = random.Random(seed)
    d = O.Domain(n, auto, settings)
    ks = list(d.knowledge_space())
    worlds = d.worlds if n_worlds is None or n_worlds >= len(d.worlds) else rng.sample(d.worlds, n_worlds)
    st = {"checked": 0, "certified": 0, "unsound_C": 0, "need": 0, "blocked": 0, "gap": 0, "gap_member_only": 0,
          "branch_closed": 0, "branch_unsound": 0, "remaining_entry_overapprox": 0, "capped": 0,
          "branch_leaves_total": 0, "branch_calls": 0}
    ex_rem, ex_closed = [], []
    t0 = time.time()
    for w in worlds:
        kk = ks if n_know is None or n_know >= len(ks) else rng.sample(ks, n_know)
        for know in kk:
            for t in range(n):
                st["checked"] += 1
                case = d.case(w, know)
                c = G.certify(case, t)
                proj = O.projections_fast(d, w, know, t) if (n <= 3 or not auto) else O.projections_by_completion(d, w, know, t)
                if proj is None:
                    st["skipped_large_omega"] = st.get("skipped_large_omega", 0) + 1
                    continue
                if c["status"] == "Certified":
                    st["certified"] += 1
                    if proj != {O.Domain._key(c["unit"])}:
                        st["unsound_C"] += 1
                    continue
                if c["status"] == "RetryableBlocked":
                    st["blocked"] += 1
                    continue
                st["need"] += 1
                if len(proj) != 1:
                    continue
                st["gap"] += 1
                k2 = O.member_closure(d, w, know, t)
                if G.certify(d.case(w, k2), t)["status"] == "Certified":
                    st["gap_member_only"] += 1
                    continue
                b = CP.branch_certify(case, t)
                st["branch_calls"] += 1
                st["branch_leaves_total"] += b["leaves"]
                if b["status"] == "Certified":
                    if proj != {(b["unit"]["slots"], b["unit"]["certain"], b["unit"]["reason"])}:
                        st["branch_unsound"] += 1
                    st["branch_closed"] += 1
                    if len(ex_closed) < 3:
                        ex_closed.append({"world": w, "know": know, "t": t, "needs_C": c["needs"]})
                elif b["status"] == "Capped":
                    st["capped"] += 1
                else:
                    st["remaining_entry_overapprox"] += 1
                    if len(ex_rem) < 3:
                        ex_rem.append({"world": w, "know": know, "t": t, "needs_C": c["needs"]})
    st["seconds"] = round(time.time() - t0, 1)
    return {"n": n, "automatic": auto, "settings": settings, "worlds": len(worlds), "know_per_world": n_know,
            "seed": seed, **st, "examples_closed": ex_closed, "examples_remaining": ex_rem}


def main():
    plan = [(3, True, {"direction": "RTL"}, 120 if QUICK else 600, None, 1),
            (4, True, {"direction": "RTL"}, 40 if QUICK else 300, 40 if QUICK else 120, 2),
            (6, False, {"direction": "RTL"}, None, None, 3),
            (6, False, {"direction": "LTR", "forced": [3], "manual": [1]}, None, None, 4),
            (7, False, {"direction": "RTL", "opening": "FIRST_DOUBLE"}, None, 60 if QUICK else 128, 5)]
    out = {"env": env(), "quick": QUICK, "domains": []}
    for p in plan:
        r = run_domain(*p)
        out["domains"].append(r)
        print({k: v for k, v in r.items() if not k.startswith("examples")}, flush=True)
    write_json(RAW / ("gamma/certificates_quick.json" if QUICK else "gamma/certificates.json"), out)


if __name__ == "__main__":
    main()
