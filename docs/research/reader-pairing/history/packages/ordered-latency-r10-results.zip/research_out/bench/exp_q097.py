"""Q097: which boundary states are distinguishable by the suffix output (bounded exhaustion on gamma.py).
Output raw/gamma/q097.json"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import omega as O
import transducer as TR
from common import RAW, env, write_json

out = {"env": env(), "runs": []}
for n, b, auto, st in [(6, 3, False, {"direction": "RTL"}), (6, 3, False, {"direction": "RTL", "manual": [2, 3, 4]}),
                       (4, 2, True, {"direction": "RTL"}), (4, 2, True, {"direction": "LTR"})]:
    d = O.Domain(n, auto, st)
    r = TR.distinguishability(d, b)
    out["runs"].append({"n": n, "boundary": b, "automatic": auto, "settings": st, "n_classes": r["n_classes"], "classes": r["classes"],
                        "witness_examples": dict(list(r["witnesses"].items())[:4])})
    print(n, b, auto, st, r["n_classes"], r["classes"], flush=True)
out["note"] = ("manual parity is not a cursor field; it is studied by the composition test (transducer.composition_test): "
               "omitting it breaks associativity (n=3 counterexample), carrying it restores 0 failures")
for mp in (False, True):
    for auto in (False, True):
        x = TR.composition_test(1500, 8, 1, mp, auto)
        out[f"composition_manual_parity={mp}_auto={auto}"] = x
        print("composition", mp, auto, x["failures"], flush=True)
out["long_dependency"] = TR.long_dependency_family()
out["pseudo_reset"] = TR.opening_pseudo_reset()
out["reset_classes"] = TR.reset_classes(6)
write_json(RAW / "gamma/q097.json", out)
