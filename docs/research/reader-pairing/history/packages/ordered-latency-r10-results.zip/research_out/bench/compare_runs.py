"""Compare two research_out/raw trees, ignoring volatile fields (env, pid, seconds, timings, utc).
Usage: python3 -B compare_runs.py <raw_dir_a> <raw_dir_b>"""
import json
import sys
from pathlib import Path

VOLATILE = {"env", "pid", "seconds", "rerun_env", "utc_start", "utc_end", "median_ns", "min_ns", "max_ns"}


def strip(o):
    if isinstance(o, dict):
        return {k: strip(v) for k, v in o.items() if k not in VOLATILE}
    if isinstance(o, list):
        return [strip(v) for v in o]
    return o


a, b = Path(sys.argv[1]), Path(sys.argv[2])
same, diff, missing = [], [], []
for p in sorted(a.rglob("*.json")):
    rel = p.relative_to(a)
    q = b / rel
    if not q.exists():
        missing.append(str(rel))
        continue
    if strip(json.load(open(p))) == strip(json.load(open(q))):
        same.append(str(rel))
    else:
        diff.append(str(rel))
print(json.dumps({"identical": same, "different": diff, "missing_in_b": missing}, indent=1))
