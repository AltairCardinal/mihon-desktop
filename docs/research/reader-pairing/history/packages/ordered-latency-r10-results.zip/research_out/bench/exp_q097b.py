"""Q097 supplement: is the reservation bit distinguishable? auto domain n=5, sides {UNKNOWN}, scores {None,1,2}.
Output raw/gamma/q097b.json"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import omega as O
import transducer as TR
import gamma as G
from common import RAW, env, write_json
out = {"env": env(), "runs": []}
for b in (1, 2):
    d = O.Domain(5, True, {"direction": "RTL"}, sides=(G.UNK,), scores=(None, 1, 2))
    r = TR.distinguishability(d, b)
    out["runs"].append({"n": 5, "boundary": b, "classes": r["n_classes"], "class_members": r["classes"],
                        "witness_reserved_vs_not": {k: v for k, v in r["witnesses"].items() if "True, True" in k and "True, False" in k}})
    print(b, r["n_classes"], r["classes"], flush=True)
write_json(RAW / "gamma/q097b.json", out)
