"""Remaining executable discriminators: F02 (Q008-Q011, Q018), F04 (Q023/Q024), F06 (Q031-Q036), F07 (Q037, Q041),
F13 (Q074, Q076-Q078), F16 (Q091, Q096), F19 (Q111, Q113, Q114). Output raw/misc/misc.json
"""
import itertools
import json
import math
import random
import sys
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import evidence as E
import gamma as G
import omega as O
import sched as S
from common import PKG, RAW, T_CEIL, env, formal_rows, load_jsonl, median, num, write_json
from metrics import reasons

ST = {"direction": "RTL", "automatic": True}


# ------------------------------------------------------------------ Q008 single-ended intervals: STN closure vs disjunctive
def q008():
    """N0 target window (arm off, ns offsets from intent): source_open(13)=72689500, source_open(14)=72731100,
    transform 13 [73281... observed], first_ack=117538800, actual draw=145536100. A source-open has no end marker.
    Route A: difference constraints (STN) give its service interval as [0, next dependent event - start].
    Route B: add a single-lane non-overlap assumption for source reads -> tighter but assumption-dependent."""
    d = json.load(open(PKG / "data/negative_route.json", encoding="utf-8"))
    arm = d["arms"][0]
    intent = next(s for s in arm["snapshots"] if s["kind"] == "intent_boundary")["at_ns"]
    opens = [m for m in arm["source_markers"] if m["stage"] == "target" and m["kind"] == "source_open"]
    st = {(x["stage"], x["object"]): x["at_ns"] for x in arm["transform_starts"]}
    rows = []
    for m in opens:
        o = m["object"]
        t_start = st.get(("target", o))
        upper = (t_start - m["at_ns"]) if t_start else None
        rows.append({"object": o, "open_offset_ns": m["at_ns"] - intent, "service_upper_bound_ns_STN": upper})
    # disjunctive: if both opens share one lane, the second cannot start before the first ends
    a, b = sorted(rows, key=lambda r: r["open_offset_ns"])
    gap = b["open_offset_ns"] - a["open_offset_ns"]
    return {"rows": rows, "STN": "each open's service lies in [0, upper]",
            "single_lane_assumption": {"first_open_service_upper_ns": min(a["service_upper_bound_ns_STN"], gap)},
            "note": "the single-lane bound is tighter only under an unobserved resource assumption; unobserved != zero"}


# ------------------------------------------------------------------ Q009 association ambiguity
def q009():
    """k starts and k completions of the same (stage,object,purpose) key with no attempt identity: count the
    consistent matchings (start <= end) and the spread of the implied service of the first attempt."""
    starts, ends = [0, 3, 5], [6, 8, 9]
    match = []
    for perm in itertools.permutations(ends):
        if all(s <= e for s, e in zip(starts, perm)):
            match.append([e - s for s, e in zip(starts, perm)])
    first = sorted({m[0] for m in match})
    return {"starts": starts, "ends": ends, "consistent_matchings": len(match), "first_attempt_service_values": first,
            "interval_union_invariant": True,
            "route_B": "per-physical-work causal token (attempt id) at start and completion -> exactly one matching"}


# ------------------------------------------------------------------ Q010/Q087 minimal probe set (exact set cover)
def q010():
    """Candidate probes and which world pairs they separate (from pass1/obsworlds + serial/parallel worlds).
    Worlds: Wf (fact-bound), Wc (consume-bound), Wm (mid), Wser (serial rounds), Wpar (parallel rounds).
    Decision-relevant partition: GO-possible {Wf} vs NO-GO {Wc, Wm} for fact-side-only; serial vs parallel for batching."""
    worlds = ["Wf", "Wc", "Wm", "Wser", "Wpar"]
    probes = {"C_authorised_ts": {("Wf", "Wc"), ("Wf", "Wm"), ("Wc", "Wm")},
              "per_round_need_and_accept_ts": {("Wser", "Wpar")},
              "frame_commit_ts": {("Wc", "Wm")},
              "rounds_count": set(), "support_size": set()}
    cost = {"C_authorised_ts": 1, "per_round_need_and_accept_ts": 2, "frame_commit_ts": 1, "rounds_count": 0, "support_size": 0}
    need = {("Wf", "Wc"), ("Wf", "Wm"), ("Wser", "Wpar")}
    best = None
    for r in range(len(probes) + 1):
        for S_ in itertools.combinations(probes, r):
            cov = set().union(*[probes[p] for p in S_]) if S_ else set()
            if need <= cov:
                c = sum(cost[p] for p in S_)
                if best is None or c < best[0]:
                    best = (c, S_)
    return {"required_separations": sorted(need), "min_cost_probe_set": best[1], "cost": best[0],
            "already_recorded_fields_separate_nothing": ["rounds_count", "support_size"],
            "adaptive_plan": "probe C_i first; only if median(U_i - C_i) <= ceiling add per-round timestamps for the batching question"}


# ------------------------------------------------------------------ Q011 non-random missingness (partial identification)
def q011():
    rej = load_jsonl(PKG / "data/rejected_samples.jsonl")
    ok = [r["unit_latency_ns"] for r in rej if not r["failure"]]
    k = sum(1 for r in rej if r["failure"])
    lo = median(ok + [0] * k)
    hi = median(ok + [10**12] * k)
    contam = {}
    for frac in (Fraction(1, 10), Fraction(1, 5)):
        m = int(50 * frac)
        contam[str(frac)] = [median(ok[:50 - m] + [0] * m) if len(ok) >= 50 - m else None, None]
    return {"R0_missing": k, "median_bounds_any_missing_values": [lo, hi], "formal_missing": 0,
            "note": "formal arms have no missing endpoints (identified); R0's 10 missing values make its median only bounded"}


# ------------------------------------------------------------------ Q018 residual / minimal correction diagnosis
def q018():
    rows = formal_rows()
    bad = {k: 0 for k in ("ok",)}
    out = {"formal_all_valid": all(not reasons(r) for r in rows)}
    r = dict(rows[0])
    r["target_ack_ns"] = r["unit_ack_ns"] + 5
    r["target_latency_ns"] = r["target_ack_ns"] - r["intent_ns"]
    # minimal correction candidates: (1) swap acks (association error), (2) clock offset on target ack, (3) reject
    out["corrupted_reasons"] = reasons(r)
    out["minimal_corrections"] = [{"fix": "re-associate target ack to an earlier receipt", "edits": 1},
                                  {"fix": "treat target ack as cross-scope (reject subtraction)", "edits": 1},
                                  {"fix": "reject sample, keep in denominator", "edits": 0}]
    out["rule"] = "never impute; keep the unexplained node with [0, L] bounds and the sample in the denominator"
    return out


# ------------------------------------------------------------------ Q023/Q024 mechanism-removable upper bounds and frontier
def q023_q024():
    rows = [r for r in formal_rows() if r["group"] == "F0"]
    # Upper bound of any mechanism acting strictly before first-member ack: removes at most target_latency.
    # Mechanisms acting only after the first member: at most unit_ack - target_ack.
    pre = median([r["unit_latency_ns"] - r["target_latency_ns"] for r in rows])  # residual if all pre-ack work vanished
    post = median([r["target_latency_ns"] for r in rows])                        # residual if all post-ack work vanished
    frontier = [
        {"mechanism": "gallop backward prefetch", "latency_effect": "fewer serial rounds on long chains (jumps only)", "work": "+waste", "revert": "flag"},
        {"mechanism": "branch certificate", "latency_effect": "0 on forward reading; rare saved materialisation on jumps", "work": "compute x100 (model)", "revert": "flag"},
        {"mechanism": "identity-validated cursor checkpoint", "latency_effect": "local support on revisits/reopen", "work": "checkpoint store + validation", "revert": "flag"},
        {"mechanism": "hard physical reserve for required", "latency_effect": "removes non-preemptive blocking", "work": "idle capacity", "revert": "config"},
        {"mechanism": "bounded result pool (mailbox)", "latency_effect": "no slot blocking during UI stalls", "work": "result memory bound", "revert": "config"},
        {"mechanism": "drop unexposed stale intents + cooperative exit", "latency_effect": "fast-intent final target latency", "work": "less", "revert": "flag"},
    ]
    return {"median_residual_if_all_pre_first_ack_work_removed_ns": pre, "median_residual_if_all_post_first_ack_work_removed_ns": post,
            "ceiling_ns": T_CEIL, "frontier": frontier,
            "note": "bounds are per-sample tautologies turned into medians: they show the partner-only family cannot pass (residual 124.4 ms) "
                    "while the pre-ack family is not bounded by the data (residual can be ~0)"}


# ------------------------------------------------------------------ Q031-Q036 materialisation cost models
def q031_q036():
    out = {}
    # Q032 fixed + per-volume cost: c(v) = a + b v. Merge k requests: a + b*sum(v) vs k*a + b*sum(v); pipeline hides a
    a, b = 6, 1
    vols = [4, 4, 4]
    out["Q032"] = {"separate": sum(a + b * v for v in vols), "merged": a + b * sum(vols),
                   "pipelined_critical_path": a + b * max(vols) + 0, "note": "merge saves (k-1)a of work; pipelining hides a on the critical path but not the work"}
    # Q033 shared materialisation for evidence and visible use (from exp_evidence: shared vs unshared materialisations)
    ev = json.load(open(RAW / "gamma/evidence.json", encoding="utf-8"))
    out["Q033"] = {fam: {"shared_median": v["need4"]["materialisations"]["median"], "unshared_median": v["need4_unshared"]["materialisations"]["median"]}
                   for fam, v in ev["families"].items()}
    # Q034 partial (header <= 512 KiB) vs full fetch: dimensions from header avoid a full decode
    out["Q034"] = {"header_cap_KiB": 512, "dims_only_certified_auto_off": "300/300 (gamma2 G10)", "dims_only_certified_auto_on": "29/300",
                   "risk": "wrong descriptor -> wrong first unit (combos C12: 238/800 trials)"}
    # Q035 close inversion: forced join vs bounded background reclaim (counted in event steps)
    out["Q035"] = {"forced_join_close_wait_max_events": 1, "background_reclaim_close_wait": 0,
                   "background_reclaim_next_open_contention": "pending exits compete with the next open's first work (must be charged there)"}
    # Q036 duplicate conversions vs shared high-level result: residency vs adaptation work
    out["Q036"] = {"low_level_shared": {"resident": 12, "adaptations": 2}, "high_level_shared": {"resident": 12, "adaptations": 1, "requires": "frame-tied leases"},
                   "no_sharing": {"resident": 24, "adaptations": 2}}
    # Q031 layered ledger on N0 (real counts)
    d = json.load(open(PKG / "data/negative_route.json", encoding="utf-8"))
    out["Q031"] = {arm["arm"]: {"source_open_attempts": arm["snapshots"][-1]["source_open_attempts"], "transform_calls": arm["snapshots"][-1]["transform_calls"],
                                "computed_objects_before_close": [s for s in arm["snapshots"] if s["kind"] == "unit_ack"][0]["computed_objects"]} for arm in d["arms"]}
    return out


# ------------------------------------------------------------------ Q037 need closure vs minimal distinguishing set
def q037(n=3):
    dom = O.Domain(n, True, {"direction": "RTL"})
    rng = random.Random(37)
    rows = []
    for w in rng.sample(dom.worlds, 60):
        t = rng.randrange(n)
        loop = O.adaptive_loop(dom, w, t)
        me = O.minimal_evidence(dom, w, t)
        rows.append((loop["fetched"], me[0]))
    gap = [a - b for a, b in rows]
    return {"worlds": len(rows), "need_closure_facts_mean": sum(a for a, _ in rows) / len(rows), "minimal_facts_mean": sum(b for _, b in rows) / len(rows),
            "excess_max": max(gap), "excess_zero": sum(g == 0 for g in gap)}


# ------------------------------------------------------------------ Q041 optional pause/resume
def q041():
    """Optional request paused by the byte window; the context changes (rebind) while paused; window refunds."""
    events = ["pause", "rebind", "refund", "resume_check"]
    orders = [p for p in itertools.permutations(events) if p.index("pause") < p.index("resume_check")]
    stale_A = stale_B = 0
    work_B = 0
    for o in orders:
        paused, ctx, ok = None, 0, False
        for e in o:
            if e == "pause":
                paused = ctx
            elif e == "rebind":
                ctx += 1
            elif e == "refund":
                ok = True
            elif e == "resume_check":
                # A: explicit Paused(reason, context) queue -> resume only if context unchanged
                if paused is not None and paused != ctx:
                    pass  # discarded correctly
                # naive A without context check would resume a stale request:
                stale_A += int(paused is not None and paused != ctx)
                work_B += 1  # B: re-derive demand from the latest needs (always one derivation)
    return {"orders": len(orders), "orders_where_context_changed_while_paused": stale_A,
            "A_needs_context_in_paused_state": True, "B_rederivations": work_B,
            "note": "a Paused entry without its context resumes stale work in those orders; idempotent re-derivation never does, "
                    "at one derivation per resume opportunity"}


# ------------------------------------------------------------------ Q074 frame vs state wait identification
def q074(period=16):
    """Two worlds with the same intent and unit_ack: W_state (state accepted late, commits on next frame) and
    W_frame (state accepted early, waits for the frame). A controlled phase shift of the commit boundary by
    delta changes unit_ack only in W_frame."""
    out = []
    for name, accept in (("W_state", 31), ("W_frame", 17)):
        base = ((accept + period - 1) // period) * period
        shifted = ((accept + period - 1 - 8) // period) * period + 8
        out.append({"world": name, "state_accept": accept, "unit_ack": base, "unit_ack_with_phase_shift_8": shifted})
    return {"rows": out, "identifying_observation": "state-accept timestamp, or a controlled commit-phase perturbation"}


# ------------------------------------------------------------------ Q076-Q078 preview, delta layout, display gap
def q076_q078():
    return {
        "Q076": {"rule": "only units in the possible-exposure set (current +- gesture reach) get certificates; an uncertified position "
                         "is never granted exposure", "example": "gesture reach 1 unit: certify current and both neighbours (3 units), not the chapter"},
        "Q077": {"delta_layout": "stable item keys + persistent unit map: a split of (2,3) into (2),(3) changes 2 entries; tickets pinned to the "
                                 "old snapshot keep consuming the old unit", "duplicate_consumption": "0 when consumption is keyed by (ticket, unit) not by item"},
        "Q078": {"endpoint": "unit_ack is a draw receipt, not optical presentation", "display_gap": "unknown interval [0, refresh period + compositor latency]"
                 , "observation": "external photodiode/high-speed capture correlated to ack timestamps (proposal only)"},
    }


# ------------------------------------------------------------------ Q091 information chain lower bound
def q091():
    rows = []
    for m in (6, 12, 23, 48):
        info_rounds = math.ceil(m / 4) + 0
        serial_rounds = m
        gallop = sum(1 for _ in iter(lambda: None, 1)) if False else math.ceil(math.log2(m + 1)) + math.ceil(m / 4)
        rows.append({"chain_facts": m, "lower_bound_rounds_4_slots": info_rounds, "decrement_by_one_rounds": serial_rounds,
                     "gallop_rounds_upper": gallop})
    # route B: exact non-preemptive optimum (lab/sched) for m unit-service fact tasks on 4 lanes, needs known upfront
    # (independent) vs needs discovered one at a time (each fact depends on the previous decision)
    exact = []
    for m in range(1, 8):
        ind = [S.Task(f"f{j}", "required", 1, 0) for j in range(m)] + [S.Task("cert", "required", 1, 0, deps=tuple(f"f{j}" for j in range(m)))]
        chain = [S.Task(f"f{j}", "required", 1, 0, deps=((f"f{j-1}",) if j else ())) for j in range(m)] + [S.Task("cert", "required", 1, 0, deps=(f"f{m-1}",))]
        exact.append({"m": m, "optimal_known_needs": S.optimal_target_completion(ind, 4, "cert"),
                      "optimal_discovered_one_by_one": S.optimal_target_completion(chain, 4, "cert"),
                      "ceil_m_over_4_plus_1": math.ceil(m / 4) + 1})
    formal = {"support_169": 23, "observed_rounds_F0": [20, 23], "observed_rounds_F1": [25, 29], "lower_bound_4_slots": math.ceil(23 / 4)}
    return {"rows": rows, "route_B_exact_schedules": exact, "formal_jump169": formal,
            "derivation": "every fact between the last true reset and the target is necessary (adversary: flipping it changes the target "
                          "unit, gamma2 G7) -> >= m facts; with 4 in flight >= ceil(m/4) rounds; the C10 decrement-by-one search uses m rounds"}


# ------------------------------------------------------------------ Q111 adversarial drift / competitive ratio
def q111():
    """Direction-predicting prefetch of the next unit (budget 1 extra materialisation per step). Adversary reverses
    direction every step: every prefetch is wasted -> waste ratio 1; stable direction: waste 0."""
    def run(seq):
        waste = hits = 0
        pos, prev_dir = 0, +1
        for d in seq:
            pref = pos + prev_dir
            pos += d
            if pref == pos:
                hits += 1
            else:
                waste += 1
            prev_dir = d
        return {"hits": hits, "waste": waste}
    return {"stable": run([+1] * 20), "alternating": run([+1, -1] * 10), "drift_after_10": run([+1] * 10 + [-1] * 10),
            "bound": "no prediction policy has waste ratio < 1 against an adaptive adversary; a budget caps the absolute waste"}


# ------------------------------------------------------------------ Q113/Q114 learning bypass and gate flapping
def q113_q114():
    # Q113: selection bias: the learner only observes outcomes of admitted speculation
    rng = random.Random(113)
    true_hit = 0.3
    observed = []
    for _ in range(1000):
        admitted = rng.random() < 0.5
        hit = rng.random() < true_hit
        if admitted:
            observed.append(hit)
    # biased admission: admit only when the previous request was a hit (feedback loop)
    prev, obs2 = True, []
    for _ in range(1000):
        hit = rng.random() < true_hit
        if prev:
            obs2.append(hit)
        prev = hit if prev else (rng.random() < 0.05)
    # Q114: a gate that enables on 2 consecutive wins and disables on 1 loss; outcomes win,win,loss repeating
    flips, on, wins = 0, False, 0
    for k in range(40):
        win = k % 3 != 2
        if on and not win:
            on, flips = False, flips + 1
        elif not on:
            wins = wins + 1 if win else 0
            if wins >= 2:
                on, flips, wins = True, flips + 1, 0
    return {"Q113": {"true_hit": true_hit, "random_admission_estimate": sum(observed) / len(observed),
                     "feedback_admission_estimate": sum(obs2) / max(1, len(obs2)), "note": "learning only scheduling values is semantics-safe but its estimates can be biased by its own admission"},
            "Q114": {"win_win_loss_pattern_40_steps_gate_flips": flips, "rule": "require hysteresis (k wins on, m losses off) and charge each switch's setup/teardown"}}


def main():
    out = {"env": env()}
    for name, fn in [("Q008", q008), ("Q009", q009), ("Q010_Q087", q010), ("Q011", q011), ("Q018", q018), ("Q023_Q024", q023_q024),
                     ("Q031_Q036", q031_q036), ("Q037", q037), ("Q041", q041), ("Q074", q074), ("Q076_Q078", q076_q078),
                     ("Q091", q091), ("Q111", q111), ("Q113_Q114", q113_q114)]:
        out[name] = fn()
        print(name, json.dumps(out[name], default=str)[:300], flush=True)
    write_json(RAW / "misc/misc.json", out)


if __name__ == "__main__":
    main()
