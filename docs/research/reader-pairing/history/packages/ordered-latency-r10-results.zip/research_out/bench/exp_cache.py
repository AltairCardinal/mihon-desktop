"""F08/W05-W07/C07/C19: when can a stronger certificate avoid a materialisation on a legal navigation history?

Synthetic worlds (evidence.random_world), cachemodel.Nav. Output raw/cache/cache.json
"""
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import cachemodel as C
import evidence as E
from common import RAW, env, write_json

ST = {"direction": "RTL", "automatic": True}


def linear_and_roundtrip(worlds, n):
    rows = []
    for w in worlds:
        starts = C.unit_starts(w, ST)
        fwd = starts
        rt = starts + starts[::-1][1:] + starts[1:]           # forward, back, forward again (natural revisits)
        far = starts[: len(starts) // 2] + [starts[-1], starts[1], starts[len(starts) // 2]]  # far jumps
        r = {}
        for name, h in [("forward", fwd), ("roundtrip", rt), ("far_jumps", far)]:
            for pf in (True, False):
                for pol in ("lru", "distance"):
                    for mat, smp in ((7, 16), (3, 6), (64, 64)):
                        a = C.run_history(w, ST, h, prefetch=pf, policy=pol, mat=mat, smp=smp)
                        b = C.run_history(w, ST, h, prefetch=pf, policy=pol, mat=mat, smp=smp, strong=True)
                        r[f"{name}|pf={pf}|{pol}|{mat}/{smp}"] = (a["transforms"], b["transforms"], b["strong_used"], a["rounds"], b["rounds"])
        rows.append(r)
    agg = {}
    for k in rows[0]:
        agg[k] = {"ordinary_transforms": sum(r[k][0] for r in rows), "strong_transforms": sum(r[k][1] for r in rows),
                  "strong_adopted": sum(r[k][2] for r in rows), "worlds_with_saving": sum(r[k][1] < r[k][0] for r in rows),
                  "worlds_with_cost": sum(r[k][1] > r[k][0] for r in rows),
                  "ordinary_rounds": sum(r[k][3] for r in rows), "strong_rounds": sum(r[k][4] for r in rows)}
    return agg


def shortest(worlds, max_len, prefetch):
    out = []
    for w in worlds:
        r = C.shortest_gain_history(w, ST, max_len, dict(prefetch=prefetch))
        out.append({"history": r.get("history"), "length": r.get("length"), "tried": r["histories_tried"],
                    "ordinary": r.get("ordinary"), "strong": r.get("strong")})
    return out


def main():
    rng = random.Random(21)
    worlds = [E.random_world(16, rng) for _ in range(40)]
    out = {"env": env(), "n": 16, "worlds": 40, "settings": ST}
    out["histories"] = linear_and_roundtrip(worlds, 16)
    out["shortest_gain_prefetch_on"] = shortest(worlds[:12], 3, True)
    out["shortest_gain_prefetch_off"] = shortest(worlds[:12], 3, False)
    write_json(RAW / "cache/cache.json", out)
    for k, v in out["histories"].items():
        if "7/16" in k:
            print(k, v)
    print("shortest on", [(r["history"], r["length"]) for r in out["shortest_gain_prefetch_on"]])
    print("shortest off", [(r["history"], r["length"]) for r in out["shortest_gain_prefetch_off"]])


if __name__ == "__main__":
    main()
