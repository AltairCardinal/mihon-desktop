"""F01/F10/F11/F12(Q068)/F13(Q073,Q075) protocol checks + data-backed Q003/Q004.
Bounded exhaustive interleavings (lab/lifecycle.py). Output raw/lifecycle/lifecycle.json
"""
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import lifecycle as L
from common import RAW, env, formal_rows, median, write_json


def q003():
    rows = formal_rows()
    f0 = {r["sample"]: r for r in rows if r["group"] == "F0"}
    f1 = {r["sample"]: r for r in rows if r["group"] == "F1"}
    naive = [f1[k]["intent_ns"] - f0[k]["intent_ns"] for k in sorted(f0)]
    # synthetic two-clock model: true offset theta, message round trips give offset bounds
    rng = random.Random(3)
    theta, drift = 7_300_000, 0
    trials, contained, naive_err = 200, 0, []
    for _ in range(trials):
        a_send = rng.randint(0, 10**9)
        d1, d2 = rng.randint(100_000, 900_000), rng.randint(100_000, 900_000)
        b_recv_local = a_send + d1 + theta
        b_send_local = b_recv_local + rng.randint(0, 200_000)
        a_recv = b_send_local - theta + d2
        rtt = (a_recv - a_send) - (b_send_local - b_recv_local)
        lo, hi = b_recv_local - a_send - rtt, b_recv_local - a_send   # theta in [lo, hi]
        contained += lo <= theta <= hi
        naive_err.append(abs((b_recv_local - a_send) - d1))
    return {"formal_cross_scope_intent_differences_ns": {"min": min(naive), "median": median(naive), "max": max(naive)},
            "note_formal": "F0/F1 clocks were shifted independently: cross-scope differences are meaningless, only same-ID durations compare",
            "two_clock_model": {"trials": trials, "offset_interval_contains_truth": contained,
                                "naive_one_way_error_ns_max": max(naive_err)}}


def q004():
    rows = formal_rows()
    out = {}
    for g in ("F0", "F1"):
        for sc in ("new_start", "reopen"):
            for t in (29, 169):
                v = [r for r in rows if r["group"] == g and r["scenario"] == sc and r["target_object"] == t]
                out[f"{g}/{sc}/{t}"] = {"median_unit_ns": median([r["unit_latency_ns"] for r in v]),
                                        "median_setup_ns": median([r["setup_duration_ns"] for r in v]),
                                        "median_priming_ns": median([r["priming_duration_ns"] for r in v]) if v[0]["priming_duration_ns"] is not None else None}
    reopen_faster = {f"{g}/{t}": out[f"{g}/reopen/{t}"]["median_unit_ns"] < out[f"{g}/new_start/{t}"]["median_unit_ns"] for g in ("F0", "F1") for t in (29, 169)}
    return {"cells": out, "reopen_median_faster_than_new_start": reopen_faster,
            "break_even": "prebuild cost P amortises after M* = P / s uses; with observed s <= 0 for reopen in every cell there is no break-even in this data"}


def main():
    out = {"env": env()}
    for name, fn in [("Q001", L.q001), ("Q002", L.q002), ("Q005", L.q005), ("Q006", L.q006), ("Q055", L.q055), ("Q056", L.q056),
                     ("Q057", L.q057), ("Q058", L.q058), ("Q059", L.q059), ("Q060", L.q060), ("Q061_Q063", L.q061_062_063),
                     ("Q062", L.q062), ("Q064", L.q064), ("Q065", L.q065), ("Q066", L.q066), ("Q068", L.q068),
                     ("Q073_Q075", L.q073_q075), ("Q076", L.q076), ("Q003", q003), ("Q004", q004)]:
        out[name] = fn()
        print(name, str(out[name])[:260], flush=True)
    write_json(RAW / "lifecycle/lifecycle.json", out)


if __name__ == "__main__":
    main()
