"""Shared helper for benchmarks: the independent certificate checker (same as exp_gamma2.checker)."""
import copy
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import gamma as G
import gamma_tools as GT


def checker_like(cert, case, t):
    sup = GT.support_facts(cert)
    c = copy.deepcopy(case)
    for i, it in enumerate(c["items"]):
        if ("an", i) not in sup:
            if ("dim", i) in sup and it["analysis"]["status"] == "Computed":
                it["descriptor"] = dict(it["analysis"]["fact"], side=G.UNK)
            it["analysis"] = {"status": "NotAnalyzed"}
            if ("dim", i) not in sup:
                it.pop("descriptor", None)
    c["edges"] = {k: v for k, v in c["edges"].items() if ("edge", k[0]) in sup}
    r = G.certify(c, t)
    return r["status"] == "Certified" and r["unit"] == cert["unit"]
