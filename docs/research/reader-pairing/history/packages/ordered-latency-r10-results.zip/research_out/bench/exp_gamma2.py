"""F09/F12/F17/F18/F20 experiments on gamma.py (researcher reconstruction of Γ). Seeded, bounded.
Output raw/gamma/gamma2.json
"""
import copy
import functools
import itertools
import math
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import certify_plus as CP
import evidence as E
import features as F
import gamma as G
import gamma_tools as GT
import omega as O
import transducer as TR
from common import RAW, env, write_json

ST = {"direction": "RTL", "automatic": True}


def worlds(n, k, seed, **kw):
    rng = random.Random(seed)
    return [E.random_world(n, rng, **kw) for _ in range(k)], rng


# ------------------------------------------------------------------ Q049/Q050/W15 dependency sets
def g1_dependencies(k=400):
    ws, rng = worlds(24, k, 31, p_side=0.08, p_null=0.2)
    stats = {"certs": 0, "flip_outside_support_changed_unit": 0, "flip_outside_support_checked": 0,
             "first_path_only_misses": 0, "first_path_only_checked": 0, "example_miss": None}
    for w in ws:
        case = G.make_case(*w, ST)
        t = rng.randrange(6, 20)
        reads1, cert = GT.first_entry_support(case, t)
        if cert["status"] != "Certified":
            continue
        stats["certs"] += 1
        sup = GT.support_facts(cert)
        truth = G.unit_of(G.plan(case), t)
        allf = {("dim", i) for i in range(24)} | {("an", i) for i in range(24)} | {("edge", i) for i in range(23)}
        for f in rng.sample(sorted(allf - sup), min(10, len(allf - sup))):
            c2 = GT.flip(case, f)
            if c2 is None:
                continue
            stats["flip_outside_support_checked"] += 1
            if G.unit_of(G.plan(c2), t) != truth:
                stats["flip_outside_support_changed_unit"] += 1
        for f in sorted(sup - reads1):
            c2 = GT.flip(case, f)
            if c2 is None:
                continue
            stats["first_path_only_checked"] += 1
            if G.unit_of(G.plan(c2), t) != truth:
                stats["first_path_only_misses"] += 1
                if stats["example_miss"] is None:
                    stats["example_miss"] = {"t": t, "fact": f, "first": cert["first"], "first_path_reads": sorted(reads1)[:12]}
    return stats


# ------------------------------------------------------------------ Q051 negative/missing facts
def g2_negative():
    # NeedFacts result memoised by its positive support only; the missing analysis then arrives -> stale NeedFacts
    states = ["SHAPE_X"] * 6
    sides = [G.UNK] * 6
    case = G.make_case(states, sides, {i: 3 for i in range(5)}, ST, known={0, 1, 2, 4, 5})
    r1 = G.certify(case, 3)
    case2 = G.make_case(states, sides, {i: 3 for i in range(5)}, ST)
    r2 = G.certify(case2, 3)
    pos_support_unchanged = all(case["items"][i] == case2["items"][i] for i in (0, 1, 2, 4, 5))
    return {"memo_result": r1["status"], "needs": r1["needs"], "after_arrival": r2["status"],
            "positive_support_unchanged": pos_support_unchanged,
            "conclusion": "a memo invalidated only by changes of positive support never notices the arrival of the missing "
                          "fact (liveness bug); reads of Absent must subscribe by key/category"}


# ------------------------------------------------------------------ Q052 stamp saturation
def g3_stamps(bits=4):
    wrap = 2 ** bits
    naive_false_hits = 1   # after exactly 2^bits updates a wrapping counter equals the cached stamp
    return {"bits": bits, "updates_to_wrap": wrap, "wrapping_counter_false_hit_after": wrap,
            "saturating_counter": "stays at max; at max the fast path is disabled and full support verification runs",
            "epoch_renumbering": "on saturation start epoch+1, rebuild live dependencies; cost = live entries",
            "exhaustive_check": all(((s + wrap) % wrap) == s for s in range(wrap))}


# ------------------------------------------------------------------ Q053 entry over-approximation and checkpoints
def g4_entries(k=300):
    ws, rng = worlds(60, k, 41, p_y=0.03, p_side=0.04, p_null=0.1, smax=40)
    extra, ck = [], []
    for w in ws:
        case = G.make_case(*w, ST)
        t = rng.randrange(25, 55)
        cert = G.certify(case, t)
        units, cursors = G.plan(case, with_cursors=True)
        # exact checkpoint: the true scan cursor at the last unit start <= t-2
        cp = max(c for c in cursors if c[0] <= max(0, t - 2))
        sc = G.Scan(60, G.Case(case).settings, *G.snapshot_queries(G.Case(case)))
        cur, reads = cp, 0
        while cur[0] <= t:
            u, cur = sc.step(cur)
            reads += 1
        extra.append(max(0, (t - 2) - cert["first"]))
        ck.append(len(cert["dependent_objects"]))
    extra.sort()
    return {"worlds": k, "extra_backward_objects_due_to_entry_overapprox": {"median": extra[len(extra) // 2], "p90": extra[int(.9 * len(extra))], "max": extra[-1]},
            "support_objects": {"median": sorted(ck)[len(ck) // 2], "max": max(ck)},
            "checkpoint_route": "with an exact, identity-validated cursor checkpoint at <= t-2 the scan needs only the local window"}


# ------------------------------------------------------------------ Q067 order independence / first-correctness
def g5_commutativity(k=150):
    ws, rng = worlds(12, k, 51)
    viol, certs = 0, 0
    for w in ws:
        t = rng.randrange(2, 10)
        truth = G.unit_of(G.plan(G.make_case(*w, ST)), t)
        K = E.Knowledge(w, ST)
        facts = [("dim", i) for i in range(12)] + [("an", i) for i in range(12)] + [("edge", i) for i in range(11)]
        rng.shuffle(facts)
        first = None
        for f in facts:
            if f[0] == "dim":
                K.dim.add(f[1])
            elif f[0] == "an":
                K.an.add(f[1]); K.dim.add(f[1])
            else:
                K.edge.add(f[1])
            c = G.certify(K.case(), t)
            if c["status"] == "Certified":
                certs += 1
                if c["unit"] != truth:
                    viol += 1
                if first is None:
                    first = c["unit"]
    return {"worlds": k, "certifications_checked": certs, "violations_of_first_correctness": viol}


# ------------------------------------------------------------------ Q070/Q071 identity vs equal values
def g6_identity():
    w = (["SHAPE_X"] * 5, [G.UNK] * 5, {i: 2 for i in range(4)})
    case = G.make_case(*w, ST)
    cert = G.certify(case, 2)
    replaced = copy.deepcopy(case)
    replaced["items"][2]["content_version"] = 1  # same bytes/values, new content identity
    rebound = copy.deepcopy(case)
    rebound["generation"] = 1
    return {"certified": cert["status"], "is_current_original": G.is_current(cert, case),
            "is_current_after_same_value_replace": G.is_current(cert, replaced),
            "is_current_after_rebind": G.is_current(cert, rebound),
            "plan_equal_after_replace": G.plan(replaced) == G.plan(case),
            "conclusion": "equal values do not authorise reuse across a content identity change; the plan may be equal but the "
                          "certificate must be re-issued for the new identity (data may be reused, authority may not)"}


# ------------------------------------------------------------------ Q094/Q100 dependency length and output size
def g7_long_output(ms=(8, 32, 128)):
    rows = []
    for m in ms:
        a = G.make_case(["SHAPE_X", "SHAPE_Y"] + ["SHAPE_X"] * m, settings={"direction": "RTL", "automatic": False})
        b = G.make_case(["SHAPE_X", "SHAPE_X"] + ["SHAPE_X"] * m, settings={"direction": "RTL", "automatic": False})
        pa, pb = G.plan(a), G.plan(b)
        changed = sum(1 for o in range(m + 2) if G.unit_of(pa, o) != G.unit_of(pb, o))
        ca = G.certify(a, m + 1)
        rows.append({"m": m, "objects_whose_unit_changed": changed, "target_support_after_flip": len(ca["dependent_objects"]),
                     "target_first": ca["first"]})
    return {"rows": rows, "conclusion": "one early fact flips Θ(m) units; a lazy target projection still needs Θ(m) facts for a "
                                        "target beyond the flip, but nothing for targets before it or after a true reset"}


# ------------------------------------------------------------------ Q102 alternative rules Γ'
def gamma_prime_local(case):
    """Γ'_local: pair (i,i+1) iff allowed(i) and s_i > s_{i-1} and s_i >= s_{i+1} (s = Γ's strength, -1 if not
    allowed; ties broken to the left). Non-overlapping by construction; each decision reads a bounded window."""
    c = G.Case(case)
    n = len(c.items)
    sc = G.Scan(n, c.settings, *G.snapshot_queries(c))
    s = [sc.strength(i) if i < n - 1 else -1 for i in range(n)]
    pairs = set()
    for i in range(n - 1):
        if s[i] >= 0 and s[i] > (s[i - 1] if i > 0 else -2) and s[i] >= (s[i + 1] if i + 1 < n - 1 else -2):
            pairs.add(i)
    units, i = [], 0
    while i < n:
        if i in pairs:
            units.append(((i, sc.leading), (i + 1, sc.trailing)))
            i += 2
        else:
            units.append(((i,),))
            i += 1
    return units


def gamma_prime_maxpairs(case):
    """Γ'_DP: maximum number of allowed pairs (Γ's allowed predicate), ties -> lexicographically earliest pairs."""
    c = G.Case(case)
    n = len(c.items)
    sc = G.Scan(n, c.settings, *G.snapshot_queries(c))
    al = [sc.allowed(i) for i in range(n - 1)]

    @functools.lru_cache(None)
    def best(i):
        if i >= n - 1:
            return (0, ())
        skip = best(i + 1)
        if al[i]:
            take = best(i + 2)
            take = (take[0] + 1, (i,) + take[1])
            if take[0] >= skip[0]:
                return take
        return skip
    pairs = set(best(0)[1])
    units, i = [], 0
    while i < n:
        if i in pairs:
            units.append(((i, sc.leading), (i + 1, sc.trailing)))
            i += 2
        else:
            units.append(((i,),))
            i += 1
    return units


def g8_alternatives(k=300):
    ws, rng = worlds(30, k, 61)
    diff_local = diff_dp = 0
    total = 0
    pairs = {"gamma": 0, "local": 0, "dp": 0}
    dep = {"gamma": 0, "local": 0, "dp": 0}
    for w in ws:
        case = G.make_case(*w, ST)
        g = [tuple((o,) + ((p,) if len(u["slots"]) > 1 else ()) for o, p in u["slots"]) for u in G.plan(case)]
        gm = [tuple(o for o, _ in u["slots"]) for u in G.plan(case)]
        lo = [tuple(x[0] for x in u) for u in gamma_prime_local(case)]
        dp = [tuple(x[0] for x in u) for u in gamma_prime_maxpairs(case)]
        total += 1
        diff_local += lo != gm
        diff_dp += dp != gm
        pairs["gamma"] += sum(len(u) == 2 for u in gm)
        pairs["local"] += sum(len(u) == 2 for u in lo)
        pairs["dp"] += sum(len(u) == 2 for u in dp)
    # dependency length: flip object 1 state and see the farthest unit change (Γ vs local vs dp)
    far = {"gamma": 0, "local": 0, "dp": 0}
    for w in ws[:100]:
        a = G.make_case(*w, ST)
        st = list(w[0]); st[1] = "SHAPE_Y" if st[1] == "SHAPE_X" else "SHAPE_X"
        b = G.make_case(st, w[1], w[2], ST)
        for name, fn in [("gamma", lambda c: [tuple(o for o, _ in u["slots"]) for u in G.plan(c)]),
                         ("local", lambda c: [tuple(x[0] for x in u) for u in gamma_prime_local(c)]),
                         ("dp", lambda c: [tuple(x[0] for x in u) for u in gamma_prime_maxpairs(c)])]:
            ua, ub = fn(a), fn(b)
            ma = {o: u for u in ua for o in u}
            mb = {o: u for u in ub for o in u}
            ch = [o for o in range(30) if ma[o] != mb[o]]
            far[name] = max(far[name], max(ch) if ch else 0)
    return {"worlds": total, "plans_differing_from_gamma": {"local": diff_local, "dp": diff_dp},
            "pairs_formed": pairs, "farthest_unit_changed_by_object1_flip": far,
            "note": "Route B only: Γ' changes outputs; no quality ground truth exists; locality is the only proven property of Γ'_local"}


# ------------------------------------------------------------------ Q104/Q105 minimal evidence, adaptive depth, greedy entropy
def g9_minimax(n=3, t=1):
    dom = O.Domain(n, True, {"direction": "RTL"})
    facts = [("d", i) for i in range(n)] + [("s", i) for i in range(n)] + [("e", i) for i in range(n - 1)]
    cost = {"d": 1, "s": 5, "e": 3}  # declared relative costs: header probe < edge samples < full analysis

    def val(w, f):
        s, d, e = w
        return s[f[1]] if f[0] == "d" else d[f[1]] if f[0] == "s" else e[f[1]]
    W = dom.worlds
    U = {w: O.Domain._key(dom.unit(w, t)) for w in W}

    @functools.lru_cache(None)
    def minimax(known):  # known: frozenset of (fact, value); returns (worst-case cost, worst-case queries)
        cons = [w for w in W if all(val(w, f) == v for f, v in known)]
        if len({U[w] for w in cons}) <= 1:
            return (0, 0)
        best = None
        kf = {f for f, _ in known}
        for f in facts:
            if f in kf or (f[0] == "s" and ("d", f[1]) not in kf and False):
                continue
            outs = {val(w, f) for w in cons}
            if len(outs) <= 1:
                continue
            sub = [minimax(known | {(f, v)}) for v in outs]
            c = (cost[f[0]] + max(x[0] for x in sub), 1 + max(x[1] for x in sub))
            if best is None or c < best:
                best = c
        return best

    def entropy(cons):
        from collections import Counter
        cnt = Counter(U[w] for w in cons)
        tot = len(cons)
        return -sum(c / tot * math.log2(c / tot) for c in cnt.values())

    def greedy(w, score):
        known, spent, q = frozenset(), 0, 0
        while True:
            cons = [x for x in W if all(val(x, f) == v for f, v in known)]
            if len({U[x] for x in cons}) <= 1:
                return spent, q
            kf = {f for f, _ in known}
            best = None
            for f in facts:
                if f in kf:
                    continue
                parts = {}
                for x in cons:
                    parts.setdefault(val(x, f), []).append(x)
                if len(parts) <= 1:
                    continue
                exp_h = sum(len(p) / len(cons) * entropy(p) for p in parts.values())
                gain = entropy(cons) - exp_h
                sc = score(gain, f)
                if best is None or sc > best[0]:
                    best = (sc, f)
            f = best[1]
            known = known | {(f, val(w, f))}
            spent += cost[f[0]]
            q += 1
    def nworld_entropy_greedy(w):
        # 'total entropy' greedy: maximise the split of the WHOLE world set, ignoring the target projection
        known, spent, q = frozenset(), 0, 0
        while True:
            cons = [x for x in W if all(val(x, f) == v for f, v in known)]
            if len({U[x] for x in cons}) <= 1:
                return spent, q
            kf = {f for f, _ in known}
            best = None
            for f in facts:
                if f in kf:
                    continue
                parts = {}
                for x in cons:
                    parts.setdefault(val(x, f), 0)
                    parts[val(x, f)] += 1
                if len(parts) <= 1:
                    continue
                h = -sum(c / len(cons) * math.log2(c / len(cons)) for c in parts.values())
                if best is None or h > best[0]:
                    best = (h, f)
            f = best[1]
            known = known | {(f, val(w, f))}
            spent += cost[f[0]]
            q += 1
    opt = minimax(frozenset())
    worst_world_entropy = max(nworld_entropy_greedy(w) for w in W)
    worst_entropy = max(greedy(w, lambda g, f: g) for w in W)
    worst_ratio = max(greedy(w, lambda g, f: g / cost[f[0]]) for w in W)
    # fixed (non-adaptive) minimum set: smallest fact set fixing the unit in every world
    fixed = None
    for r in range(len(facts) + 1):
        for S in itertools.combinations(facts, r):
            groups = {}
            ok = True
            for w in W:
                k = tuple(val(w, f) for f in S)
                if groups.setdefault(k, U[w]) != U[w]:
                    ok = False
                    break
            if ok:
                fixed = (r, S, sum(cost[f[0]] for f in S))
                break
        if fixed:
            break
    return {"domain": f"auto n={n}, target={t}", "worlds": len(W), "costs": cost,
            "adaptive_optimal_worst_case": {"cost": opt[0], "queries": opt[1]},
            "greedy_entropy_worst_case": {"cost": worst_entropy[0], "queries": worst_entropy[1]},
            "greedy_total_world_entropy_worst_case": {"cost": worst_world_entropy[0], "queries": worst_world_entropy[1]},
            "greedy_cost_normalised_worst_case": {"cost": worst_ratio[0], "queries": worst_ratio[1]},
            "fixed_nonadaptive_min_set": {"size": fixed[0], "facts": fixed[1], "cost": fixed[2]}}


# ------------------------------------------------------------------ Q107 cheap information
def g10_cheap(k=300):
    ws, rng = worlds(16, k, 71)
    dims_only_ok = 0
    for w in ws:
        t = rng.randrange(3, 13)
        K = E.Knowledge(w, ST)
        K.dim = set(range(16))
        c = G.certify(K.case(), t)
        dims_only_ok += c["status"] == "Certified"
    off = 0
    for w in ws:
        t = rng.randrange(3, 13)
        st = {"direction": "RTL", "automatic": False}
        K = E.Knowledge(w, st)
        K.dim = set(range(16))
        off += G.certify(K.case(), t)["status"] == "Certified"
    # counterexample: same cheap features (all dims equal) but different target unit (side differs)
    a = G.make_case(["SHAPE_X"] * 4, [G.UNK, G.UNK, G.UNK, G.UNK], {0: 1, 1: 1, 2: 1}, ST)
    b = G.make_case(["SHAPE_X"] * 4, [G.UNK, G.LEFT, G.UNK, G.UNK], {0: 1, 1: 1, 2: 1}, ST)
    return {"automatic_on_dims_only_certified": dims_only_ok, "automatic_off_dims_only_certified": off, "of": k,
            "same_dims_different_unit": {"a": G.unit_of(G.plan(a), 1), "b": G.unit_of(G.plan(b), 1)}}


# ------------------------------------------------------------------ Q115/Q116 numeric equivalence and early exit
def g11_numeric(k=3000):
    rng = random.Random(81)
    agree = mism = 0
    work_early = work_full = 0
    for _ in range(k):
        lvl = rng.randint(30, 220)
        a = F.make_object(rng, rng.choice(["white", "textured", "grey", "dark"]), rng.choice(["white", "textured", "grey"]), lvl)
        b = F.make_object(rng, rng.choice(["white", "textured", "grey", "dark"]), rng.choice(["white", "textured", "grey"]), lvl + rng.randint(-6, 6))
        A, B = F.facing(a, "left"), F.facing(b, "right")
        r_exact = F.distance(A, B, exact=True)
        r_float = F.distance(A, B, exact=False)
        r_rev = F.distance(A, B, exact=False, order="reverse")
        same = (r_exact[0] == r_float[0] == r_rev[0]) and (r_exact[0] == "null" or float(r_exact[1]) == r_float[1])
        agree += same
        mism += not same
        # work: points visited by early exit vs a vectorised full pass (always 50)
        s, n = 0, 0
        NA = [F.normalize(p) for p in A]
        NB = [F.normalize(p) for p in B]
        for x, y in zip(NA, NB):
            n += 1
            s += sum(abs(u - v) for u, v in zip(x, y))
            if s >= 1500:
                break
        work_early += n
        work_full += 50
    flips = F.search_float_flip(20000)
    # Γ-level consequence of the variance-gate flip: later edge null (float) vs score (exact) changes laterWins
    base = (["SHAPE_X"] * 5, [G.UNK] * 5)
    exact_world = G.make_case(*base, {0: None, 1: None, 2: 3, 3: None}, ST)   # exact: edge (2,3) computed (score 3)
    float_world = G.make_case(*base, {0: None, 1: None, 2: None, 3: None}, ST)  # float: variance gate says null
    strip_level = {}
    for g in range(30, 200, 7):
        A = [(g, g, g, 255)] * 25 + [(g + 20, g + 20, g + 20, 255)] * 25
        strip_level[g] = [F.distance(A, A, exact=True)[0], F.distance(A, A, exact=False)[0]]
    fb = {"evaluations": 0, "fallbacks": 0, "disagreements_with_reference": 0}
    for g in range(20, 230):
        A = [(g, g, g, 255)] * 25 + [(g + 20, g + 20, g + 20, 255)] * 25
        for fast in ("exact", "reverse"):
            r, u = F.distance_fast_with_fallback(A, A, fast=fast)
            fb["evaluations"] += 1; fb["fallbacks"] += u; fb["disagreements_with_reference"] += r != F.distance(A, A)
    rng2 = random.Random(5)
    for _ in range(2000):
        lvl = rng2.randint(30, 220)
        a = F.make_object(rng2, rng2.choice(["white", "textured", "grey", "dark"]), rng2.choice(["white", "textured", "grey"]), lvl)
        b = F.make_object(rng2, rng2.choice(["white", "textured", "grey"]), rng2.choice(["white", "textured", "grey"]), lvl + rng2.randint(-6, 6))
        A, B = F.facing(a, "left"), F.facing(b, "right")
        for fast in ("exact", "reverse"):
            r, u = F.distance_fast_with_fallback(A, B, fast=fast)
            fb["evaluations"] += 1; fb["fallbacks"] += u; fb["disagreements_with_reference"] += r != F.distance(A, B)
    return {"route_B_fast_path_with_reference_fallback": fb,
            "strip_level_two_grey_levels_identical_facing_strips": strip_level,
            "strip_level_flip_count": sum(v[0] != v[1] for v in strip_level.values()),
            "random_pairs": k, "exact_float_reverse_agree": agree, "disagree": mism,
            "early_exit_points_visited": work_early, "full_pass_points": work_full,
            "variance_gate_flips_found": len(flips), "flip_example": flips[:1],
            "gamma_consequence": {"unit_of_1_exact": G.unit_of(G.plan(exact_world), 1), "unit_of_1_float": G.unit_of(G.plan(float_world), 1)},
            "note": "random inputs agree; adversarial near-threshold inputs (two grey levels 20 apart, equal counts: exact variance 100) "
                    "flip the '<100' gate between exact and float evaluation"}


# ------------------------------------------------------------------ Q117 proof-carrying checker
def checker(cert, case, t):
    """Independent re-verification: keep ONLY the certificate's support facts, re-run C07-C10, compare unit."""
    sup = GT.support_facts(cert)
    c = copy.deepcopy(case)
    for i, it in enumerate(c["items"]):
        if ("an", i) not in sup:
            if ("dim", i) in sup and it["analysis"]["status"] == "Computed":
                it["descriptor"] = dict(it["analysis"]["fact"], side=G.UNK)
            if ("an", i) not in sup:
                it["analysis"] = {"status": "NotAnalyzed"}
                if ("dim", i) not in sup:
                    it.pop("descriptor", None)
    c["edges"] = {k: v for k, v in c["edges"].items() if ("edge", k[0]) in sup}
    r = G.certify(c, t)
    return r["status"] == "Certified" and r["unit"] == cert["unit"], r["steps"]


def g12_checker(k=300):
    ws, rng = worlds(20, k, 91)
    ok = rej_drop = rej_unit = total = 0
    steps_c, steps_b = 0, 0
    for w in ws:
        case = G.make_case(*w, ST)
        t = rng.randrange(4, 16)
        cert = G.certify(case, t)
        if cert["status"] != "Certified":
            continue
        total += 1
        good, st = checker(cert, case, t)
        ok += good
        steps_c += st
        steps_b += cert["steps"]
        bad = copy.deepcopy(cert)
        sup = list(bad["support"]["analysis"].keys())
        if sup:
            del bad["support"]["analysis"][sup[0]]
            g2, _ = checker(bad, case, t)
            rej_drop += not g2
        bad2 = copy.deepcopy(cert)
        bad2["unit"] = {"slots": tuple((o, G.FULL) for o, _ in cert["unit"]["slots"]), "certain": True, "reason": "FORGED"}
        g3, _ = checker(bad2, case, t)
        rej_unit += not g3
    return {"certificates": total, "checker_accepts_genuine": ok, "checker_rejects_dropped_support": rej_drop,
            "checker_rejects_forged_unit": rej_unit, "checker_steps": steps_c, "builder_steps": steps_b,
            "stamp_fast_path": "a trusted-build + version-stamp fast path accepts a forged unit whenever stamps are unchanged "
                               "(it never inspects the unit); it is not an independent check"}


def main():
    sel = set(sys.argv[1:])
    out = {"env": env()}
    for name, fn in [("G1_dependencies", g1_dependencies), ("G2_negative", g2_negative), ("G3_stamps", g3_stamps),
                     ("G4_entries", g4_entries), ("G5_commutativity", g5_commutativity), ("G6_identity", g6_identity),
                     ("G7_long_output", g7_long_output), ("G8_alternatives", g8_alternatives), ("G9_minimax", g9_minimax),
                     ("G10_cheap", g10_cheap), ("G11_numeric", g11_numeric), ("G12_checker", g12_checker)]:
        if sel and name not in sel:
            continue
        out[name] = fn()
        print(name, str(out[name])[:500], flush=True)
    if sel:
        import json
        prev = json.load(open(RAW / "gamma/gamma2.json", encoding="utf-8"))
        prev.update({k: v for k, v in out.items() if k != "env"})
        prev.setdefault("rerun_env", []).append(out["env"])
        out = prev
    write_json(RAW / "gamma/gamma2.json", out)


if __name__ == "__main__":
    main()
