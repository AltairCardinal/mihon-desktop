"""W01-W20 adversarial workload index: runs the new constructions and links each class to the raw results that
exercise it. Layers: GAMMA = gamma.py reconstruction; LAB = synthetic resource/protocol model; DATA = anonymous
historical recomputation; COND = conditional theory. Output raw/workloads/workloads.json
"""
import copy
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
import evidence as E
import gamma as G
import transducer as TR
import sched as S_
from common import PKG, RAW, env, formal_rows, write_json
from metrics import reasons, summarize
from causal import join_operations, sparse_graph

ST = {"direction": "RTL", "automatic": True}


def w04_manual_overlap():
    """Overlapping manual starts {1,2,3}: S02 accepts the earliest legal request and alternates."""
    out = {}
    for starts in ([1, 2], [1, 2, 3], [2, 3, 4]):
        case = G.make_case(["SHAPE_X"] * 7, settings={"direction": "LTR", "automatic": False, "manual": starts})
        out[str(starts)] = [u["slots"] for u in G.plan(case)]
    # degenerate: a SHAPE_Y inside the chain invalidates the candidate and stops the backward walk
    case = G.make_case(["SHAPE_X", "SHAPE_X", "SHAPE_Y", "SHAPE_X", "SHAPE_X", "SHAPE_X"], settings={"direction": "LTR", "automatic": False, "manual": [0, 1, 3, 4]})
    out["with_Y_at_2"] = [u["slots"] for u in G.plan(case)]
    return out


def w13_one_side():
    """Partner late: first member resources ready, partner not; exposure of the first member alone is a partial unit."""
    from lifecycle import q055, q006
    a, b = q055()["results"], q006()["results"]
    return {"partial_exposure_orders": a["publish_on_certify"]["wrong"], "of": a["publish_on_certify"]["orders"],
            "two_phase_wrong": a["A_two_phase"]["wrong"], "exposed_unit_moved_by_revocation": b["revoke_on_new_cert"]["wrong"]}


def w18_sparse_wrong():
    rows = formal_rows()
    r = rows[0]
    cases = {
        "missing_end": dict(r, unit_ack_ns=None, unit_latency_ns=None),
        "wrong_scope": dict(r, clock_scope="F1"),
        "target_after_unit": dict(r, target_ack_ns=r["unit_ack_ns"] + 1, target_latency_ns=r["unit_latency_ns"] + 1),
        "latency_mismatch": dict(r, unit_latency_ns=r["unit_latency_ns"] - 1),
        "slot_swap": dict(r, actual_layout={"slots": [dict(s, position="LEFT" if s["position"] == "RIGHT" else "RIGHT") for s in r["actual_layout"]["slots"]], "certain": True, "reason": None}),
    }
    out = {k: reasons(v) for k, v in cases.items()}
    dup = rows[:50] + [rows[0]]
    try:
        from metrics import compare
        compare(dup + rows[50:], "F0", "F1")
        out["duplicate_id"] = "accepted (BUG)"
    except ValueError as ex:
        out["duplicate_id"] = f"rejected: {ex}"
    starts = [{"stage": "s", "object": 1, "purpose": "p", "at_ns": 0, "clock_scope": "X"}, {"stage": "s", "object": 1, "purpose": "p", "at_ns": 5, "clock_scope": "X"}]
    ends = [{"stage": "s", "object": 1, "purpose": "p", "at_ns": 7, "clock_scope": "X"}, {"stage": "s", "object": 1, "purpose": "p", "at_ns": 9, "clock_scope": "X"}]
    j = join_operations(starts, ends)
    out["same_key_twice"] = {"ambiguous": j["ambiguous"], "intervals": j["intervals"],
                             "fifo_guess_durations": [7, 4], "lifo_guess_durations": [9, 2]}
    try:
        sparse_graph(cases["target_after_unit"])
        out["sparse_graph_target_after_unit"] = "accepted (BUG)"
    except ValueError as ex:
        out["sparse_graph_target_after_unit"] = f"rejected: {ex}"
    return out


def w20_frontier_attack():
    """Put each frontier mechanism in its worst legal domain and report the shortest refuting setting."""
    res = {}
    rng = random.Random(20)
    # (a) galloping backward prefetch: short chains -> pure waste; booklike worlds
    waste, saved, cost = 0, 0, 0
    for _ in range(200):
        w = E.random_world(40, rng)
        t = rng.randrange(10, 36)
        a = E.acquire_loop(w, ST, t)
        b = E.acquire_loop(w, ST, t, gallop=True)
        waste += b["waste"]
        saved += b["rounds"] < a["rounds"]
        cost += b["rounds"] > a["rounds"]
    res["gallop_prefetch_booklike"] = {"worlds": 200, "rounds_saved_in": saved, "rounds_worse_in": cost, "wasted_materialisations": waste}
    # (b) identity-validated checkpoint under frequent replacement: replace one object left of the target per visit
    import summarytree as STR
    hits = visits = 0
    for _ in range(40):
        w = E.random_world(40, rng)
        case = G.make_case(*w, ST)
        ck = STR.Checkpoints(case, 8)
        for v in range(6):
            t = rng.randrange(20, 38)
            before = len(ck.cp)
            ck.unit(t)
            p = rng.randrange(1, t - 2)           # a content replacement left of the target
            ck.update(case, p)
            usable = [k for k in ck.cp if 0 < k <= t]
            hits += bool(usable)
            visits += 1
    res["checkpoint_under_replacement"] = {"visits": visits, "visits_with_a_usable_checkpoint_after_replacement": hits,
                                           "rule": "a checkpoint at p is valid only if every object < p keeps its content identity"}
    # (c) physical reserve in a short session with no required work: measured idle worker-time
    tasks = [S_.Task(f"s{i}", "speculative", 30, 0) for i in range(6)]
    sim = S_.Sim(tasks, physical=4, reserve_physical=1).run()
    span = max(t.end for t in sim.tasks.values())
    res["physical_reserve_short_session"] = {"worker_time": 4 * span, "busy": sim.work, "idle_fraction": 1 - sim.work / (4 * span),
                                             "makespan_with_reserve": span,
                                             "makespan_without_reserve": max(t.end for t in S_.Sim([S_.Task(f"s{i}", "speculative", 30, 0) for i in range(6)], physical=4).run().tasks.values())}
    # (d) branch certificate: savings read from the cache experiment (not hard-coded)
    cache = json.load(open(RAW / "cache/cache.json", encoding="utf-8"))["histories"]
    res["branch_certificate_savings"] = {k: v["ordinary_transforms"] - v["strong_transforms"] for k, v in cache.items() if k.startswith(("forward", "roundtrip"))}
    return res


def w03_realizability():
    import features as F
    seen = F.realizable_pairs(3000, seed=3, direction="RTL")
    combos = [(a, b, k) for a in (G.LEFT, G.RIGHT, G.UNK) for b in (G.LEFT, G.RIGHT, G.UNK) for k in ("score", "null")]
    random_missing = [c for c in combos if c not in seen]
    witnessed = {f"{c}": F.witness(c[0], c[1], c[2], "RTL")["found"] for c in combos}
    return {"random_generator_3000": {str(k): v for k, v in seen.items()}, "combinations_missing_from_random": [list(c) for c in random_missing],
            "constructive_witness_found": witnessed}


def main():
    links = {
        "W01": ["GAMMA", "raw/gamma/evidence.json (no_side_chain: rounds up to 27, fixed-window errors)", "transducer.long_dependency_family"],
        "W02": ["GAMMA", "transducer.reset_classes / opening_pseudo_reset"],
        "W03": ["GAMMA", "raw/gamma/gamma2.json G10 same_dims_different_unit; lab/features.py witnesses (all 36 side/score combos realizable)"],
        "W04": ["GAMMA", "this file w04_manual_overlap; certificates.json (manual [1] and [1,2,3] domains, 0 unsound)"],
        "W05": ["GAMMA+LAB", "raw/cache/cache.json forward rows: strong certificate saves 0 transforms (normal-route analogue)"],
        "W06": ["GAMMA+LAB", "raw/cache/cache.json shortest_gain_*: length-1..3 legal histories with 1 saved transform"],
        "W07": ["GAMMA+LAB", "raw/cache/cache.json roundtrip rows at 7/16, 3/6, 64/64"],
        "W08": ["LAB", "raw/sched/sched.json S8_blocking, S19_speculation; combos C27"],
        "W09": ["LAB", "raw/combos/combos.json C02; raw/lifecycle/lifecycle.json Q061_Q063"],
        "W10": ["LAB", "raw/sched/sched.json S10_mailbox; combos C05"],
        "W11": ["LAB", "raw/sched/sched.json S14_bytes (package protocol); lifecycle Q064"],
        "W12": ["LAB", "raw/sched/sched.json S11_fast_intents; combos C15; lifecycle Q068"],
        "W13": ["LAB", "this file w13_one_side"],
        "W14": ["GAMMA+LAB", "lifecycle Q002; gamma2 G6_identity; combos C12 (wrong descriptor -> wrong first unit)"],
        "W15": ["GAMMA", "gamma2 G1_dependencies (selected-path deps miss 29/673), G2_negative, G3_stamps; combos C10"],
        "W16": ["LAB", "lifecycle Q073_Q075 commit/batch rows"],
        "W17": ["LAB", "lifecycle Q061_Q063, Q062; package Protocol.close returns False with running work"],
        "W18": ["DATA", "this file w18_sparse_wrong"],
        "W19": ["DATA", "raw/pass1/reach.json lemma_r1 + F0_order (x25/x26 both advance); stats Q081, combos C25"],
        "W20": ["GAMMA+LAB", "this file w20_frontier_attack"],
    }
    out = {"env": env(), "links": links,
           "W04_manual_overlap": w04_manual_overlap(), "W13_one_side": w13_one_side(),
           "W18_sparse_wrong": w18_sparse_wrong(), "W03_realizability": w03_realizability(), "W20_frontier_attack": w20_frontier_attack(),
           "W02_pseudo_reset": TR.opening_pseudo_reset(), "W01_long_dependency": TR.long_dependency_family((4, 16, 64))}
    write_json(RAW / "workloads/workloads.json", out)
    for k in ("W04_manual_overlap", "W13_one_side", "W18_sparse_wrong", "W20_frontier_attack"):
        print(k, json.dumps(out[k], default=str)[:600])


if __name__ == "__main__":
    main()
