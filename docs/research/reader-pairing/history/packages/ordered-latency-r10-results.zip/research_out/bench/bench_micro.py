"""Model-level wall-clock comparisons (Python). >= 3 independent serial processes. NOT native/product timings.

Usage:  python3 -B bench/bench_micro.py drive   (spawns 3 serial child processes, writes raw/bench/micro_*.jsonl)
        python3 -B bench/bench_micro.py child <run_id>
"""
import datetime
import json
import os
import random
import statistics
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / "lab"))


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def timed(fn, reps):
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter_ns()
        fn()
        ts.append(time.perf_counter_ns() - t0)
    return {"median_ns": statistics.median(ts), "min_ns": min(ts), "max_ns": max(ts), "reps": reps}


def child(run_id):
    import certify_plus as CP
    import evidence as E
    import features as F
    import gamma as G
    import summarytree as STR
    from bench_helpers import checker_like
    rng = random.Random(1234)  # identical inputs in every process
    st = {"direction": "RTL", "automatic": True}
    out = []

    # ---------------- W_a: target query strategies (complete facts)
    for n in (48, 176, 1024):
        w = E.random_world(n, rng)
        case = G.make_case(*w, st)
        targets = [rng.randrange(n) for _ in range(20)]
        upd = [rng.randrange(n) for _ in range(20)]

        def rescan_q():
            for t in targets:
                G.unit_of(G.plan(case), t)

        def cert_q():
            for t in targets:
                G.certify(case, t)

        def ck_build_q():
            ck = STR.Checkpoints(case, 16)
            for t in targets:
                ck.unit(t)

        def tree_build_q():
            tr = STR.SummaryTree(case, 8)
            for t in targets:
                tr.unit(t)

        def tree_update_query():
            tr = STR.SummaryTree(case, 8)
            ww = (list(w[0]), w[1], w[2])
            c2 = case
            for p, t in zip(upd, targets):
                ww[0][p] = "SHAPE_Y" if ww[0][p] == "SHAPE_X" else "SHAPE_X"
                c2 = G.make_case(*ww, st)
                tr.update(c2, p)
                tr.unit(t)

        def ck_update_query():
            ck = STR.Checkpoints(case, 16)
            ww = (list(w[0]), w[1], w[2])
            for p, t in zip(upd, targets):
                ww[0][p] = "SHAPE_Y" if ww[0][p] == "SHAPE_X" else "SHAPE_X"
                c2 = G.make_case(*ww, st)
                ck.update(c2, p)
                ck.unit(t)

        reps = 5 if n < 1024 else 2
        for name, fn in [("rescan_20q", rescan_q), ("finite_entry_certify_20q", cert_q), ("checkpoint16_build+20q", ck_build_q),
                         ("tree8_build+20q", tree_build_q), ("tree8_20x(update+query)", tree_update_query),
                         ("checkpoint16_20x(update+query)", ck_update_query)]:
            r = timed(fn, reps)
            out.append({"workload": "W_a_target_query", "n": n, "variant": name, **r})

    # ---------------- W_b: ordinary vs branch certificate on partial knowledge
    cases = []
    for _ in range(60):
        w = E.random_world(40, rng)
        K = E.Knowledge(w, st)
        for i in range(40):
            u = rng.random()
            if u < 0.7:
                K.an.add(i); K.dim.add(i)
            elif u < 0.85:
                K.dim.add(i)
        K.edge = {i for i in range(39) if rng.random() < 0.7}
        cases.append((K.case(), rng.randrange(5, 35)))
    out.append({"workload": "W_b_certificate", "variant": "C09_certify_60cases", **timed(lambda: [G.certify(c, t) for c, t in cases], 5)})
    out.append({"workload": "W_b_certificate", "variant": "branch_certify_60cases", **timed(lambda: [CP.branch_certify(c, t) for c, t in cases], 3)})

    # ---------------- W_c: distance evaluation
    pairs = []
    for _ in range(200):
        lvl = rng.randint(30, 220)
        a = F.make_object(rng, rng.choice(["white", "textured", "grey", "dark"]), rng.choice(["white", "textured", "grey"]), lvl)
        b = F.make_object(rng, rng.choice(["white", "textured", "grey", "dark"]), rng.choice(["white", "textured", "grey"]), lvl + rng.randint(-6, 6))
        pairs.append((F.facing(a, "left"), F.facing(b, "right")))

    def full_pass():
        for A, B in pairs:
            NA = [F.normalize(p) for p in A]
            NB = [F.normalize(p) for p in B]
            s = sum(abs(u - v) for x, y in zip(NA, NB) for u, v in zip(x, y))
            _ = s >= 1500
    out.append({"workload": "W_c_distance", "variant": "early_exit_float_200pairs", **timed(lambda: [F.distance(A, B) for A, B in pairs], 5)})
    out.append({"workload": "W_c_distance", "variant": "exact_rational_200pairs", **timed(lambda: [F.distance(A, B, exact=True) for A, B in pairs], 3)})
    out.append({"workload": "W_c_distance", "variant": "full_pass_sum_only_200pairs", **timed(full_pass, 5)})

    # ---------------- W_d: independent checker vs builder
    cs = []
    for _ in range(60):
        w = E.random_world(30, rng)
        case = G.make_case(*w, st)
        t = rng.randrange(5, 25)
        cert = G.certify(case, t)
        if cert["status"] == "Certified":
            cs.append((cert, case, t))
    out.append({"workload": "W_d_checker", "variant": "builder_certify", **timed(lambda: [G.certify(c, t) for _, c, t in cs], 5)})
    out.append({"workload": "W_d_checker", "variant": "independent_checker", **timed(lambda: [checker_like(cert, c, t) for cert, c, t in cs], 5)})
    out.append({"workload": "W_d_checker", "variant": "is_current_C12", **timed(lambda: [G.is_current(cert, c) for cert, c, t in cs], 5)})
    for r in out:
        r.update({"run": run_id, "pid": os.getpid(), "python": sys.version.split()[0]})
    print(json.dumps(out))


def drive():
    raw = HERE.parents[1] / "raw" / "bench"
    raw.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = raw / f"micro_{stamp}.jsonl"
    meta = []
    with open(path, "w") as f:
        for k in range(3):
            t0 = utc()
            p = subprocess.run([sys.executable, "-B", str(HERE), "child", f"r{k}"], capture_output=True, text=True, cwd=str(HERE.parents[1]))
            t1 = utc()
            if p.returncode != 0:
                meta.append({"run": k, "error": p.stderr[-2000:], "start": t0, "end": t1})
                continue
            rows = json.loads(p.stdout)
            for r in rows:
                r.update({"utc_start": t0, "utc_end": t1})
                f.write(json.dumps(r) + "\n")
            meta.append({"run": k, "pid": rows[0]["pid"], "start": t0, "end": t1, "rows": len(rows)})
    (raw / f"micro_{stamp}_meta.json").write_text(json.dumps(meta, indent=1))
    print(path, meta)


if __name__ == "__main__":
    if sys.argv[1] == "drive":
        drive()
    else:
        sys.path.insert(0, str(HERE.parent))
        child(sys.argv[2])
