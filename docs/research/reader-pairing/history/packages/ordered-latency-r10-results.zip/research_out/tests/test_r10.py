"""R10 research tests (standard library unittest). Run from the package root:
    python3 -B research_out/tests/test_r10.py
Includes 'broken wiring' tests: every naive mechanism must be caught by its counterexample (Q118).
"""
import json
import random
import sys
import unittest
from fractions import Fraction
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / "lab"))
import common  # noqa: E402  (sets package code path)
import certify_plus as CP  # noqa: E402
import evidence as E  # noqa: E402
import features as F  # noqa: E402
import gamma as G  # noqa: E402
import lifecycle as L  # noqa: E402
import omega as O  # noqa: E402
import reach  # noqa: E402
import sched as S  # noqa: E402
import summarytree as STR  # noqa: E402
import transducer as TR  # noqa: E402
from metrics import compare  # noqa: E402

ST = {"direction": "RTL", "automatic": True}


class PackageBaseline(unittest.TestCase):
    def test_frozen_numbers_unchanged(self):
        rows = common.formal_rows()
        r = compare(rows, "F0", "F1")
        self.assertEqual(r["reference"]["median_ns"], 130196850)
        self.assertEqual(r["candidate"]["median_ns"], 115184850)
        self.assertEqual(r["difference_of_medians_ns"], 15012000)
        self.assertEqual(r["candidate_median_ceiling_ns"], 30196850)
        self.assertFalse(r["passed"])


class Reachability(unittest.TestCase):
    def test_lemma_r1(self):
        self.assertTrue(reach.lemma_r1_bruteforce(6, 5)["ok"])

    def test_min_reduction_and_restriction(self):
        rows = [r for r in common.formal_rows() if r["group"] == "F0"]
        base = [r["unit_latency_ns"] for r in rows]
        m = reach.min_total_reduction(base, common.T_CEIL)
        self.assertEqual(m["min_total_reduction_ns"], 1859290300)
        self.assertEqual(m["samples_that_must_change"], 26)
        self.assertFalse(reach.restricted_feasibility(rows, common.T_CEIL, {"advance"})["feasible_even_if_free_go_to_zero"])
        self.assertTrue(reach.restricted_feasibility(rows, common.T_CEIL, {"new_start", "reopen"})["feasible_even_if_free_go_to_zero"])

    def test_partner_only_bound(self):
        b = reach.first_member_bound(common.formal_rows(), common.T_CEIL)
        self.assertEqual(b["F0"]["median_target"], 124399450)
        self.assertFalse(b["F0"]["partner_only_can_reach_T"])


class GammaReconstruction(unittest.TestCase):
    def test_plan_examples(self):
        case = G.make_case(["SHAPE_X"] * 5, settings={"direction": "RTL", "automatic": False})
        self.assertEqual([u["slots"] for u in G.plan(case)],
                         [((0, "LEFT"),), ((1, "RIGHT"), (2, "LEFT")), ((3, "RIGHT"), (4, "LEFT"))])

    def test_soundness_small_exhaustive(self):
        for st in ({"direction": "RTL"}, {"direction": "LTR", "forced": [2], "manual": [1]}):
            d = O.Domain(5, False, st)
            r = O.soundness_completeness(d)
            self.assertEqual(r["unsound"], 0)

    def test_soundness_auto_n2(self):
        d = O.Domain(2, True, {"direction": "RTL"})
        ks = list(d.knowledge_space())
        r = O.check(d, d.worlds, lambda rng: ks)
        self.assertEqual(r["unsound"], 0)

    def test_branch_certificate_sound(self):
        d = O.Domain(3, True, {"direction": "RTL"})
        rng = random.Random(1)
        ks = list(d.knowledge_space())
        for w in rng.sample(d.worlds, 25):
            for know in rng.sample(ks, 15):
                for t in range(3):
                    b = CP.branch_certify(d.case(w, know), t)
                    if b["status"] == "Certified":
                        self.assertEqual(O.projections_fast(d, w, know, t), {(b["unit"]["slots"], b["unit"]["certain"], b["unit"]["reason"])})

    def test_currency_identity(self):
        case = G.make_case(["SHAPE_X"] * 5, [G.UNK] * 5, {i: 2 for i in range(4)}, ST)
        cert = G.certify(case, 2)
        self.assertTrue(G.is_current(cert, case))
        case2 = G.make_case(["SHAPE_X"] * 5, [G.UNK] * 5, {i: 2 for i in range(4)}, ST)
        case2["items"][2]["content_version"] = 1
        self.assertFalse(G.is_current(cert, case2))

    def test_long_dependency_breaks_fixed_windows(self):
        for row in TR.long_dependency_family((4, 64)):
            self.assertTrue(row["differ"])

    def test_opening_pseudo_reset(self):
        r = TR.opening_pseudo_reset()
        self.assertTrue(r["differ"])

    def test_composition_needs_manual_parity(self):
        self.assertGreater(TR.composition_test(400, 6, 1, False, False)["failures"], 0)
        self.assertEqual(TR.composition_test(400, 6, 1, True, False)["failures"], 0)
        self.assertEqual(TR.composition_test(400, 6, 2, True, True)["failures"], 0)

    def test_summary_tree_exact(self):
        rng = random.Random(9)
        for _ in range(10):
            n = rng.randint(8, 30)
            w = E.random_world(n, rng)
            st = {"direction": rng.choice(["LTR", "RTL"]), "automatic": True, "manual": rng.sample(range(n), 3), "opening": "FIRST_DOUBLE"}
            case = G.make_case(*w, st)
            tr = STR.SummaryTree(case, rng.choice([2, 4, 8]))
            plan = G.plan(case)
            for t in range(n):
                self.assertEqual(tr.unit(t), G.unit_of(plan, t))


class Features(unittest.TestCase):
    def test_all_side_score_combinations_realizable(self):
        for d in ("RTL", "LTR"):
            for a in (G.LEFT, G.RIGHT, G.UNK):
                for b in (G.LEFT, G.RIGHT, G.UNK):
                    for want in ("score", "null"):
                        self.assertTrue(F.witness(a, b, want, d)["found"], (d, a, b, want))

    def test_float_variance_gate_flip(self):
        A = [(78, 78, 78, 255)] * 25 + [(98, 98, 98, 255)] * 25
        self.assertEqual(F.distance(A, A, exact=True), ("score", Fraction(0)))
        self.assertEqual(F.distance(A, A, exact=False)[0], "null")

    def test_early_exit_rule(self):
        white = [(250, 250, 250, 255)] * 50
        dark = [(10, 10, 10, 255)] * 50
        self.assertEqual(F.distance(white, dark), ("null", "early_sum"))


class BrokenWiringIsCaught(unittest.TestCase):
    """Each naive scheme has >= 1 counterexample; each proposed route has 0 (bounded exhaustive)."""

    def check(self, res, naive, routes):
        for n in naive:
            self.assertGreater(res[n]["wrong"], 0, n)
        for r in routes:
            self.assertEqual(res[r]["wrong"], 0, r)

    def test_q001(self):
        self.check(L.q001()["results"], ["frame_id_only", "receipt_count"], ["A_ticket_member_barrier", "B_commit_carries_unit"])

    def test_q002(self):
        r = L.q002()
        self.check(r["results"], ["value_equal"], ["A_capability_token(content,gen,attempt)"])
        self.check(r["retry_same_content"], ["content_gen", "B_version_vector_readset"], ["A_capability_token(content,gen,attempt)", "B_plus_attempt_token"])

    def test_q005_q006_q055_q056(self):
        self.check(L.q005()["results"], ["local_accept", "B_pitfall_empty_cut"], ["A_two_phase_commit_check", "B_snapshot_cut_inherit"])
        self.check(L.q006()["results"], ["revoke_on_new_cert"], ["A_frame_lease", "B_multiversion_snapshot"])
        self.check(L.q055()["results"], ["publish_on_certify"], ["A_two_phase", "B_parallel_single_commit"])
        self.check(L.q056()["results"], ["separate_fields"], ["A_atomic_descriptor", "B_versioned_layout_txn"])

    def test_q057_to_q062(self):
        self.check(L.q057()["results"], ["unit_index"], ["A_item_identity_anchor", "B_versioned_unit_bridge"])
        self.check(L.q058()["results"], ["relayout_on_any_change"], ["A_user_txn", "B_event_sourced_inputs"])
        self.check(L.q059()["results"], ["no_validation"], ["A_capability_commit_check", "B_global_revision_fastpath"])
        self.check(L.q060()["results"], ["progress_on_prefetch"], ["A_ack_and_settle", "B_idempotent_ticket_txn"])
        self.check(L.q061_062_063()["results"], ["cancel_releases_slot", "cancel_kills_shared_job", "close_drops_lease"],
                   ["A_strict_join_close", "B_transfer_then_close"])
        self.check(L.q062()["results"], ["accept_by_object", "delete_old_record"], ["A_identity_gate_plus_exit", "B_reaper_channel"])
        self.check(L.q068()["results"], ["merge_everything"], ["A_unexposed_only", "B_lazy_event_log"])


class ResourceModel(unittest.TestCase):
    def test_nonpreemptive_blocking_and_reserve(self):
        def run(**kw):
            tasks = [S.Task(f"s{i}", "speculative", 100, 0) for i in range(4)] + [S.Task("r", "required", 10, 10)]
            return S.Sim(tasks, physical=4, **kw).run().tasks["r"].start - 10
        self.assertEqual(run(), 90)
        self.assertEqual(run(reserve_required=1), 0)

    def test_logical_reserve_does_not_protect_physical(self):
        tasks = [S.Task("o0", "optional", 60, 0), S.Task("o1", "optional", 60, 0), S.Task("s0", "speculative", 60, 0),
                 S.Task("s1", "speculative", 60, 0), S.Task("r", "required", 10, 5)]
        self.assertEqual(S.Sim([S.Task(t.id, t.role, t.service, t.release) for t in tasks], physical=4, reserve_required=1).run().tasks["r"].end, 70)
        self.assertEqual(S.Sim([S.Task(t.id, t.role, t.service, t.release) for t in tasks], physical=4, reserve_physical=1).run().tasks["r"].end, 15)

    def test_cancel_is_not_exit(self):
        tasks = [S.Task(f"s{i}", "speculative", 100, 0) for i in range(4)] + [S.Task("r", "required", 10, 10)]
        sim = S.Sim(tasks, physical=4).run([(10, lambda s: s.cancel("s0"))])
        self.assertEqual(sim.tasks["r"].start, 100)

    def test_exact_optimum_small(self):
        self.assertEqual(S.optimal_target_completion([S.Task("a", "required", 5, 0), S.Task("b", "required", 3, 0),
                                                       S.Task("t", "required", 2, 0, deps=("a", "b"))], 2, "t"), 7)


if __name__ == "__main__":
    unittest.main()
