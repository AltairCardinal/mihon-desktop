"""Regression tests for the unified strong-proof budget contract (BC-2).

Written BEFORE the fix (fix round after R9).  Every strong route that can
issue a certificate -- fresh tree, fresh exact, persistent tree, block
summaries, gated full-information index -- must:

  * charge every step evaluation it performs in the call (build, rebuild,
    dirty update, frontier/table fill, query exploration); nothing is free;
  * stop as soon as the charged count exceeds strong.budget and then issue
    nothing (fall back to the L0 verdict);
  * certify with budget == exactly the charged count and stop with one less;
  * roll back a stopped call: shared structures return to their pre-call
    state, so repeated small budgets never accumulate a proof (no slicing);
  * keep reuse of an already issued certificate (publish of a still-current
    handle) outside the budget.

Scenario scripts are replayed from scratch for every budget probe so each
probe sees exactly the same state.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import workloads as W  # noqa: E402
from strong import StrongSession  # noqa: E402
from wpA_lib import PersistentStrongSession  # noqa: E402
from wpB_coupled import BlockSession  # noqa: E402
from wpC_coupled import IndexedSession  # noqa: E402

BASE = dict(domain='nonneg', alpha=False, gate='raw')

# (route, fixture trace, target, mode)
ROUTES = {
    'fresh_tree': (lambda c, b: StrongSession(c, strong=dict(BASE, kind='tree', budget=b)), 'S'),
    'fresh_exact': (lambda c, b: StrongSession(c, strong=dict(BASE, kind='exact', budget=b)), 'S'),
    'persistent': (lambda c, b: PersistentStrongSession(c, strong=dict(BASE, kind='tree', budget=b)), 'S'),
    'block': (lambda c, b: BlockSession(c, strong=dict(BASE, kind='blocks', budget=b)), 'S'),
    'index': (lambda c, b: IndexedSession(c, strong=dict(BASE, kind='tree', budget=b)), 'I'),
}
STRONG_ROUTES = ('strong-', 'index')


def fixture(route):
    """(initial case, target) where the route certifies but L0 does not (index: gate passes)."""
    if route == 'index':
        return W.w05_raw_eviction(2)['initial'], 3
    return W.w01_phase_chain(0)['initial'], 12


def strong_issued(v):
    return v.get('status') == 'certified' and str(v.get('route', '')).startswith(STRONG_ROUTES)


def run(route, budgets, script=()):
    """Build a session with budget None, run `script` (list of ops), then one
    call per entry of `budgets` (each sets strong.budget before the call).
    Returns (session, [verdict...], [charged evaluations per final call])."""
    make, mode = ROUTES[route]
    case, target = fixture(route)
    s = make(case, None)
    for op in script:
        if op[0] == 'certify':
            s.strong['budget'] = None
            s.certify(op[1] if len(op) > 1 else target, mode=mode)
        elif op[0] == 'noop_apply':        # duplicate admission of an unchanged item
            p = op[1]
            s.owner.apply(item_updates={p: dict(s.owner._case['items'][p])})
        elif op[0] == 'edge':
            a, score = op[1], op[2]
            s.owner.apply(edge_updates={(a, a + 1): dict(status='computed', score=score, version=7)})
    out, ev = [], []
    for b in budgets:
        s.strong['budget'] = b
        before = s.metrics['strong_evaluations']
        out.append(s.certify(target, mode=mode))
        ev.append(s.metrics['strong_evaluations'] - before)
    return s, out, ev


def fingerprint(route, s):
    if route == 'persistent':
        t = s._tree
        return (id(t), tuple(t.tree) if t is not None else None,
                frozenset(s._dirty_items), frozenset(s._dirty_edges))
    if route == 'block':
        bs = s._bs
        if bs is None:
            return None
        return (id(bs), tuple(sorted((b, k) for b, tab in enumerate(bs.tables) for k in tab)),
                tuple(sorted(bs.frontier_at)), frozenset(s._dirty_items), frozenset(s._dirty_edges))
    if route == 'index':
        ix = s._index_obj
        if ix is None:
            return None
        return (id(ix), tuple(x is not None for x in ix.leaves), tuple(x is not None for x in ix.nodes))
    return None


class BudgetContract(unittest.TestCase):
    def _needed(self, route, script=()):
        s, (v,), (n,) = run(route, [None], script)
        self.assertTrue(strong_issued(v), (route, v.get('route'), v.get('status')))
        return n, v

    def test_fixture_requires_strong(self):
        for route in ('fresh_tree', 'fresh_exact', 'persistent', 'block'):
            case, t = fixture(route)
            self.assertEqual(StrongSession(case).certify(t, mode='L0')['status'], 'need_facts', route)

    def test_budget_zero_and_one_issue_nothing(self):
        for route in ROUTES:
            for b in (0, 1):
                s, (v,), (n,) = run(route, [b])
                self.assertFalse(strong_issued(v), (route, b, v.get('route')))
                self.assertGreaterEqual(n, 1, (route, b, 'stopped work must be charged, never 0'))
                self.assertGreater(n, b, (route, b))
                self.assertEqual(s.metrics['strong_stops'], 1, (route, b))
                self.assertNotIn('strong', str(v.get('route', '')), (route, b))

    def test_exactly_enough_and_one_short(self):
        for route in ROUTES:
            n, v = self._needed(route)
            self.assertGreater(n, 0, (route, 'a certificate needs at least one evaluation'))
            _, (ok,), (c1,) = run(route, [n])
            self.assertTrue(strong_issued(ok), (route, n))
            self.assertEqual(c1, n, route)
            self.assertEqual(ok['steps'], n, (route, 'verdict steps must equal charged evaluations'))
            self.assertEqual(ok['unit'], v['unit'], route)
            s, (bad,), (c2,) = run(route, [n - 1])
            self.assertFalse(strong_issued(bad), (route, n - 1))
            self.assertEqual(s.metrics['strong_certificates'], 0, route)
            if route != 'index':                 # index falls back to L0, which may certify on its own
                self.assertNotIn('certificate', bad, route)

    def test_persistent_first_call_charges_like_fresh_tree(self):
        nf, _ = self._needed('fresh_tree')
        npers, _ = self._needed('persistent')
        self.assertEqual(npers, nf, 'same tree build + same query => same charge')

    def test_cache_hit_query_is_charged_and_bounded(self):
        for route in ('persistent', 'block', 'index'):
            nbuild, _ = self._needed(route)
            q, v = self._needed(route, script=[('certify',)])
            self.assertGreaterEqual(q, 1, (route, 'query exploration is never free'))
            self.assertLess(q, nbuild, (route, 'cached structure must be reused'))
            _, (ok,), _ = run(route, [q], script=[('certify',)])
            self.assertTrue(strong_issued(ok), route)
            _, (bad,), _ = run(route, [q - 1], script=[('certify',)])
            self.assertFalse(strong_issued(bad), route)
            _, (zero,), (cz,) = run(route, [0], script=[('certify',)])
            self.assertFalse(strong_issued(zero), route)
            self.assertGreaterEqual(cz, 1, route)

    def test_update_recompute_is_charged(self):
        for route in ('persistent', 'block'):
            case, t = fixture(route)
            q, _ = self._needed(route, script=[('certify',)])
            script = [('certify',), ('noop_apply', t - 6)]
            u, v = self._needed(route, script=script)
            self.assertGreater(u, q, (route, 'dirty recomputation must be charged'))
            _, (ok,), _ = run(route, [u], script=script)
            self.assertTrue(strong_issued(ok), route)
            _, (bad,), _ = run(route, [q], script=script)
            self.assertFalse(strong_issued(bad), (route, 'query-only budget cannot pay for the update'))

    def test_midway_stop_rolls_back_and_never_accumulates(self):
        for route in ('persistent', 'block', 'index'):
            case, t = fixture(route)
            script = [('certify',), ('noop_apply', max(0, t - 6))] if route != 'index' else []
            u, v = self._needed(route, script=script)
            half = max(1, u // 2)
            make, mode = ROUTES[route]
            s, _, _ = run(route, [], script=script)
            fp0 = fingerprint(route, s)
            certs0 = s.metrics['strong_certificates']
            for _ in range(5):                       # budget slicing attempt
                s.strong['budget'] = half
                vv = s.certify(t, mode=mode)
                self.assertFalse(strong_issued(vv), route)
                self.assertEqual(fingerprint(route, s), fp0, (route, 'stopped call must leave no structure'))
                self.assertEqual(s.metrics['strong_certificates'], certs0, route)
            s.strong['budget'] = None
            before = s.metrics['strong_evaluations']
            final = s.certify(t, mode=mode)
            self.assertTrue(strong_issued(final), route)
            self.assertEqual(s.metrics['strong_evaluations'] - before, u, (route, 'no progress carried over'))
            self.assertEqual(final['unit'], v['unit'], route)

    def test_stopped_call_cannot_authorise_publication(self):
        for route in ROUTES:
            s, (v,), _ = run(route, [1])
            self.assertEqual(s.metrics['strong_certificates'], 0, route)
            self.assertFalse(strong_issued(v), route)
            if route != 'index':
                self.assertNotIn('certificate', v, route)
                self.assertEqual(s.publish(fixture(route)[1], s._next_certificate + 1), 'unsigned', route)
                self.assertEqual(s.published, {}, route)
            else:                                   # the only certificate is the L0 fallback's
                self.assertEqual(s.certificate_count, 1 if 'certificate' in v else 0, route)
                self.assertNotEqual(v.get('route'), 'index', route)

    def test_certificate_reuse_is_outside_budget(self):
        for route in ROUTES:
            s, (v,), _ = run(route, [None])
            t = fixture(route)[1]
            s.strong['budget'] = 0
            self.assertEqual(s.publish(t, v['certificate']), 'published', route)
            self.assertEqual(s.confirm(t), 'confirmed', route)

    def test_call_level_budget_bounds_l0_plus_strong(self):
        for route in ('fresh_tree', 'persistent', 'block'):
            make, mode = ROUTES[route]
            case, t = fixture(route)
            n, _ = self._needed(route)
            s = make(case, None)
            before = s.metrics['certification_steps']
            l0 = s.certify(t, mode='L0')
            l0_steps = s.metrics['certification_steps'] - before
            s2 = make(case, None)
            v = s2.certify(t, mode='S', budget=l0_steps + n - 1)
            self.assertFalse(strong_issued(v), route)
            s3 = make(case, None)
            v = s3.certify(t, mode='S', budget=l0_steps + n)
            self.assertTrue(strong_issued(v), route)


if __name__ == '__main__':
    unittest.main()
