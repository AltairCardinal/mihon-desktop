"""Fix round (LC): lifecycle D4 harness and public-observation classification."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import fixLC_groups as G  # noqa: E402
import fixLC_shadow as S  # noqa: E402
import fixLC_observe as O  # noqa: E402
from fixLC_lifecycle import naive_close_crash  # noqa: E402
from wpB_coupled import BlockSession  # noqa: E402


class _Released(BlockSession):
    def _txn_commit(self, snap):
        super()._txn_commit(snap); self._cur_snap = None

    def _txn_rollback(self, snap):
        super()._txn_rollback(snap); self._cur_snap = None

    def close(self):
        super().close(); self._cur_snap = None


class Lifecycle(unittest.TestCase):
    def test_package_has_no_safe_close(self):
        self.assertTrue(naive_close_crash()['crashed'])

    def test_mechanisms_pass_all_groups_with_bound_confirmation(self):
        for m in ('persistent_tree', 'gated_index_I', 'inc_revoke', 'migrate_resign', 'value_cache', 'reissue_eager',
                  'derive_first'):
            for r in G.run_mechanism(m, bound=True):
                self.assertTrue(r['ok'], (m, r['group'], r['failed']))

    def test_unbound_confirmation_fails_only_late_callback(self):
        for r in G.run_mechanism('fresh_strong', bound=False):
            if r['group'].startswith('E4_rebind') and r['group'] != 'E4_rebind_differential':
                self.assertEqual(r['failed'], ['old_callback_rejected_after_republish'], r['group'])
            else:
                self.assertTrue(r['ok'], (r['group'], r['failed']))

    def test_block_session_residual_and_proposed_release(self):
        r = G.E5(G.spec('block_session', True))
        other = [c for c in r['checks'] if c['name'] != 'no_hidden_residual_reachable']
        self.assertTrue(all(c['ok'] for c in other), r['failed'])
        G.MECHANISMS['_block_released'] = dict(G.MECHANISMS['block_session'], cls=_Released)
        try:
            self.assertTrue(G.E5(G.spec('_block_released', True))['ok'])
        finally:
            del G.MECHANISMS['_block_released']

    def test_mutants_are_caught(self):
        rows = G.mutants()
        self.assertEqual(len(rows), 5)
        for r in rows:
            self.assertFalse(r['ok'], r['mutant'])

    def test_rc1_liveness_package_vs_derive_first(self):
        self.assertFalse(G.LV(G.spec('package_session', True), raw_capacity=1, n_targets=4)['ok'])
        self.assertTrue(G.LV(G.spec('derive_first', True), raw_capacity=1, n_targets=4)['ok'])


class ShadowRunnerLifecycle(unittest.TestCase):
    def test_r9_runner_fails_e4_proof_identity_and_e6(self):
        r, rows = S.run_shadow('gated_shadow', 'touched', True, rebind_item=31)
        failed = {c['group'] + ':' + c['name'] for c in S.evaluate(r, rows, 'touched') if not c['ok']}
        self.assertIn('E4:old_epoch_proof_event_not_delivered', failed)
        self.assertIn('E6:reobtained_after_invalidation', failed)
        self.assertEqual(r.wrong, 0)

    def test_fixed_runner_with_bound_confirmation_passes(self):
        for var in ('touched', 'untouched'):
            for rb in (13, 31):
                r, rows = S.run_shadow('gated_shadow', var, True, rebind_item=rb, fixed=True)
                failed = [c['name'] for c in S.evaluate(r, rows, var) if not c['ok']]
                self.assertEqual(failed, [], (var, rb))


class Observations(unittest.TestCase):
    def test_control_identical(self):
        self.assertEqual(O.compare_pair('control', traces=16, length=40)['traces_with_difference'], 0)

    def test_inc_revoke_identical_small(self):
        for focus in ('mixed', 'expiry'):
            self.assertEqual(O.compare_pair('inc_revoke', traces=24, length=50, focus=focus)['traces_with_difference'], 0)

    def test_derive_first_changes_observe(self):
        r = O.compare_pair('derive_first', traces=40, length=60, rc_fixed=1)
        self.assertGreater(r['differences'].get('observation:observe', 0), 0)

    def test_bound_confirm_rejects_stale_callback_package_accepts(self):
        r = O.compare_pair('bound_confirm', traces=40, length=60, focus='expiry')
        self.assertGreater(r['return_pairs'].get('confirm/stale:confirmed->stale_callback', 0), 0)


if __name__ == '__main__':
    unittest.main()
