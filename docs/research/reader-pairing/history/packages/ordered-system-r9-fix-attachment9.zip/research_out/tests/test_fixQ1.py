"""Fix round Q1 tests: A04 protocols, B01 ZDD summaries, B05 MITM, D04 interval memo, D05 width."""
import copy
import itertools
import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: E402,F401
from common import random_case, roundtrip, base_case, fact  # noqa: E402
import omega as O  # noqa: E402
import transducer as T  # noqa: E402
from corrected_owner import Owner  # noqa: E402
from current_baseline import typed  # noqa: E402
import wpB_sigmemo as SG  # noqa: E402
import fixQ1_a04 as A4  # noqa: E402
import fixQ1_b01 as B1  # noqa: E402
import fixQ1_b05 as B5  # noqa: E402
import fixQ1_d04 as D4  # noqa: E402
import fixQ1_d05 as D5  # noqa: E402
import wpA_interleave as I  # noqa: E402
import wpA_lib as A  # noqa: E402


def uset(r):
    return set(r[1]) if r[0] == 'ambiguous' else ({T._key(r[1])} if r[0] == 'certified' else set())


class A04(unittest.TestCase):
    def test_both_protocols_safe_on_sampled_orders(self):
        sc = I.small_case()
        for proto in ('FL', 'FP'):
            for fb in ('ok', 'unavailable', 'failed'):
                for k, order in enumerate(itertools.permutations(A4.EVENTS)):
                    if k % 997:
                        continue
                    self.assertEqual(A4.run_order(sc, order, proto, fb)['violations'], [], (proto, fb, order))

    def test_mutants_killed(self):
        sc = I.small_case()
        hits = {m: 0 for m in ('commit_no_revalidate', 'close_frees_running', 'close_keeps_publications')}
        for k, order in enumerate(itertools.permutations(A4.EVENTS)):
            if k % 211:
                continue
            for m in ('close_frees_running', 'close_keeps_publications'):
                hits[m] += bool(A4.run_order(sc, order, 'FP', 'ok', mutant=m)['violations'])
        for k, order in enumerate(itertools.permutations(A4.EVENTS_NO_CLOSE)):
            if k % 97:
                continue
            hits['commit_no_revalidate'] += bool(A4.run_order(sc, order, 'FP', 'ok', mutant='commit_no_revalidate')['violations'])
        for m, h in hits.items():
            self.assertGreater(h, 0, m)

    def test_double_publication_guard_matters(self):
        sc = I.small_case()
        # duplicate delivery of the same proof completion
        bad = A4.run_order(sc, ('P', 'P', 'C'), 'FL', 'ok', mutant='no_first_wins_guard')
        good = A4.run_order(sc, ('P', 'P', 'C'), 'FL', 'ok')
        self.assertTrue(any('I8' in v for v in bad['violations']))
        self.assertEqual(good['violations'], [])

    def test_fixed_phase_never_earlier_than_first_legal(self):
        tr = A.tuning_traces()[1]
        rows = A4.compare_runners([tr], 4, 1)
        self.assertGreaterEqual(rows[0]['FP']['total_latency_u'], rows[0]['FL']['total_latency_u'])
        self.assertEqual(rows[0]['FP']['wrong'], 0)


class B01(unittest.TestCase):
    def test_zdd_equals_exact_dp(self):
        rng = random.Random(21)
        for _ in range(40):
            n = rng.randrange(1, 18)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.4))
            z = B1.ZDDSummary(copy.deepcopy(c), 'ext', False, block=rng.choice((1, 2, 4)))
            for t in range(n):
                e, r = O.certify_exact(c, t, 'ext', False), z.certify(t)
                self.assertEqual(e[0] == 'certified', r[0] == 'certified')
                if e[0] == 'certified':
                    self.assertEqual(e[1], r[1])

    def test_zdd_canonical_sharing_and_compaction(self):
        z = B1.ZDD()
        a = z.union(z.from_set([('in', ('S', 1)), ('out', ('S', 2))]), z.from_set([('in', ('S', 1)), ('out', ('S', 3))]))
        b = z.union(z.from_set([('in', ('S', 1)), ('out', ('S', 3))]), z.from_set([('in', ('S', 1)), ('out', ('S', 2))]))
        self.assertEqual(a, b)                                     # canonical
        img = z.image(z.from_set([('in', ('S', 1))]), a)
        self.assertEqual(sorted(z.sets(img)), [(('out', ('S', 2)),), (('out', ('S', 3)),)])
        rng = random.Random(3)
        c = roundtrip(random_case(rng, 24, p_unknown=0.4, p_edge_unknown=0.5))
        zs = B1.ZDDSummary(copy.deepcopy(c), 'ext', False, block=4)
        before = [zs.certify(t) for t in range(24)]
        zs.compact()
        zs.frontier_at = {0: zs.frontier_at[0]}
        self.assertEqual([r[0] for r in before], [zs.certify(t)[0] for t in range(24)])

    def test_cursor_window_state_is_necessary_manual_bit_is_not(self):
        rng = random.Random(202)
        st_changed = mb_changed = 0
        for _ in range(150):
            n = rng.randrange(4, 12)
            c = roundtrip(random_case(rng, n, p_unknown=0.6, p_edge_unknown=0.2))
            t = rng.randrange(n)
            ref = uset(O.certify_exact(c, t, 'ext', False))
            st_changed += B1.certify_ablated(c, t, 'st_b') != ref
            mb_changed += B1.certify_ablated(c, t, 'manual_bit') != ref
        self.assertGreater(st_changed, 0)
        self.assertEqual(mb_changed, 0)


class B05(unittest.TestCase):
    def test_mitm_exact_and_never_deletes(self):
        rng = random.Random(7)
        for _ in range(40):
            n = rng.randrange(2, 12)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.5))
            t = rng.randrange(n)
            e = uset(O.certify_exact(c, t, 'ext', False))
            for d in (1, 3):
                self.assertEqual(uset(B5.mitm(c, t, 'ext', False, d=d)), e)

    def test_forward_cache_matches_exact_under_updates(self):
        import workloads as W
        tr = W.random_partial(901, n=24)
        case = copy.deepcopy(tr['initial'])
        fc = B5.ForwardCache(case, 'nonneg', False)
        for t in range(24):
            fc.certify(t)
        p = next(i for i, it in enumerate(case['items']) if it['analysis'].get('status') != 'computed')
        case['items'][p]['analysis'] = copy.deepcopy(tr['world'][p]['analysis'])
        fc.update(item=p)
        for t in range(24):
            self.assertEqual(uset(fc.certify(t)), uset(O.certify_exact(case, t, 'nonneg', False)))


class D04(unittest.TestCase):
    def _chain(self, scores):
        c = base_case(len(scores) + 1, automatic=True)
        for it in c['items']:
            it['analysis'] = dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1)
        for e, s in zip(c['edges'], scores):
            e['score'] = s
        return roundtrip(c)

    def test_interval_exact_and_accepts_more_than_sig(self):
        rng = random.Random(5)
        only = 0
        for seed in range(4):
            c = self._chain([float(rng.choice((1, 2, 3))) for _ in range(31)])
            io, so = D4.IntervalOwner(c), SG.SigOwner(c)
            cur = copy.deepcopy(c)
            hot = [rng.randrange(32) for _ in range(4)]
            for step in range(20):
                for t in hot:
                    fresh = Owner(cur).request(t)
                    self.assertEqual(typed(io.request(t)), typed(fresh))
                    self.assertEqual(typed(so.request(t)), typed(fresh))
                upd = {}
                for e in cur['edges']:
                    if rng.random() < 0.3:
                        e['score'] += 0.5; e['version'] += 1
                        upd[(e['first'], e['second'])] = dict(e)
                io.apply(edge_updates=copy.deepcopy(upd)); so.apply(edge_updates=copy.deepcopy(upd))
            only += io.metrics['interval_only_hits']
        self.assertGreater(only, 0)

    def test_minimal_examples(self):
        # tie a==b at edges (1,2): lowering b keeps b<a? no -- delta from 0 to -0.5 flips; the recorded
        # example lowers edge 1 (the earlier edge) so delta goes 0 -> +0.5: interval keeps it, SIG rejects
        c = self._chain([1.0, 1.0, 1.0])
        o = Owner(c); before = o.request(1); sup = dict(o._memo[1]['support'])
        c2 = copy.deepcopy(c); c2['edges'][1]['score'] -= 0.5
        o2 = Owner(c2); after = o2.request(1); idx = o2._index()
        cur = {k: o2._read(idx, k) for k in sup}
        self.assertEqual(typed(before), typed(after))
        self.assertTrue(D4.interval_equal(sup, cur))
        self.assertFalse(SG.signature_equal(sup, cur))
        c = self._chain([1.0, 1.0, 1.0, 1.0])
        before = Owner(c).request(3)
        c2 = copy.deepcopy(c); c2['edges'][2]['score'] += 0.5
        after = Owner(c2).request(3)
        self.assertEqual(D4.classify_change(before, after), 'unit_only')
        self.assertNotEqual(before['dependent_items'], after['dependent_items'])


class D05(unittest.TestCase):
    def test_routes_exact_and_component_bound(self):
        rng = random.Random(3)
        for _ in range(60):
            n = rng.randrange(2, 14)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.6))
            t = rng.randrange(n)
            e = uset(O.certify_exact(c, t, 'ext', False))
            st = {}
            r1 = D5.pathdec(c, t, 'ext', False, st)
            r2 = D5.csp(c, t, 'ext', False, early=False)
            self.assertEqual(set(r1[1]), e)
            self.assertEqual(set(r2[1]), e)
            self.assertLessEqual(st['max_lt_constraints'], 2)
            if st['max_lt_edges_at'] not in (None, 0, 1):
                self.assertLessEqual(st['max_lt_edges'], 2)


if __name__ == '__main__':
    unittest.main()
