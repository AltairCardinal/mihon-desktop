"""Fix round Q2: T04 proof-carrying certificates, X05 frontier x support DAG, X30 migration x residual gain."""
import random
import re
import sys
import unittest
from copy import deepcopy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import omega as O  # noqa: E402
import transducer as T  # noqa: E402
import workloads as W  # noqa: E402
import fixQ2_pcc as P  # noqa: E402
import fixQ2_pcc_checker as C  # noqa: E402
import fixQ2_x05 as X5  # noqa: E402
import fixQ2_x30 as X3  # noqa: E402
from common import random_case, roundtrip  # noqa: E402


class T04ProofCarrying(unittest.TestCase):
    def test_checker_is_independent_of_issuer_machinery(self):
        src = (Path(C.__file__)).read_text()
        imports = set(re.findall(r'^\s*(?:import|from)\s+(\w+)', src, re.M))
        self.assertTrue(imports <= {'json', 'reference', 'compact_core'}, imports)

    def test_honest_accepted_and_mutants_rejected(self):
        tr = W.w01_phase_chain(0)
        cert, ev = P.issue(tr['initial'], 12)
        self.assertGreater(ev, 0)
        self.assertEqual(C.check(tr['initial'], cert), (True, 'ok'))
        rng = random.Random(0)
        for name, m in P.mutants(cert, rng):
            ok, _ = C.check(tr['initial'], m)
            if name in ('wrong_unit', 'wrong_reason', 'dropped_frontier_element'):
                self.assertFalse(ok, name)
            if ok:
                self.assertTrue(P.truth(tr['initial'], m), name)

    def test_soundness_against_world_oracle_small(self):
        rng = random.Random(11)
        checked = 0
        for _ in range(40):
            n = rng.randrange(3, 6)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.4, domain='nonneg'))
            for t in range(n):
                cert, _ = P.issue(c, t)
                if cert is None:
                    continue
                for name, m in [('honest', cert)] + P.mutants(cert, rng):
                    if m['domain'] == 'G0':
                        continue
                    ok, _ = C.check(c, m)
                    if not ok:
                        continue
                    try:
                        U = O.oracle_units(P.mask(c, m['pos_hi'], m['edge_hi']), t, m['domain'], m['alpha'], cap=20000)
                    except OverflowError:
                        continue
                    checked += 1
                    self.assertEqual(set(U), {T._key(m['unit'])}, name)
        self.assertGreater(checked, 20)

    def test_domain_violation_rejected(self):
        tr = W.w01_phase_chain(0)
        cert, _ = P.issue(tr['initial'], 12)
        cert['domain'] = 'G0'                      # known ranks are integers > 29.98 -> ill-formed claim
        self.assertEqual(C.check(tr['initial'], cert), (False, 'domain_violation'))


class X05FrontierSupport(unittest.TestCase):
    def test_correct_arms_never_stale_and_mutant_unsafe(self):
        st = X5.stream('W01', 0, pattern='hot')
        prep = X5.prepare(st)
        res = {a: X5.run(st, a, prep) for a in X5.ARMS}
        for a in ('0', 'A', 'B', 'AB1', 'AB2'):
            self.assertEqual(res[a]['stale_reuses'], 0, a)
            self.assertEqual(res[a]['wrong_fresh'], 0, a)
            self.assertEqual(res[a].get('unsafe_reuses', 0), 0, a)
        self.assertGreater(res['A_miss']['unsafe_reuses'], 0)
        self.assertGreater(res['AB2_miss']['unsafe_reuses'], 0)
        self.assertLessEqual(res['AB1']['evaluations'], res['A']['evaluations'])
        self.assertLess(res['AB1']['validation_reads'], res['0']['validation_reads'])

    def test_noop_write_detected_before_in_place_update(self):
        st = X5.stream('W01', 0, pattern='hot')
        prep = X5.prepare(st)
        churn = [p for p in prep if p[0] == 'd' and p[1][0] == 'edge' and p[2]]
        self.assertTrue(churn)                      # real churn is reported as a change


class X30Migration(unittest.TestCase):
    def test_sub_case_matches_seg_cut_plan(self):
        import reference as ref
        import wpS_rules as S
        from coupled_runner import world_case
        tr = W.random_partial(1, n=40)
        w = world_case(tr['initial'], tr['world'])
        plan = []
        for lo in range(0, 40, X3.SEG):
            for u in ref.complete_plan(X3.sub_case(w, lo, min(40, lo + X3.SEG))):
                plan.append(X3._shift_unit(u, lo))
        self.assertEqual(plan, S.seg_cut_plan(w, X3.SEG))

    def test_groups_sound_and_authority_not_migrated(self):
        tr = X3.with_migration(W.w05_raw_eviction(0, n=48, holes=6, count=24), 120)
        for g in X3.GROUPS:
            r = X3.run_group(tr, g)
            self.assertEqual(r['wrong'], 0, g)
            self.assertEqual(r['published'], r['intents'], g)
            self.assertEqual(r['pending_republish'], 0, g)
        s = X3.L2Session(deepcopy(W.w05_raw_eviction(0, n=48)['initial']))
        v = s.certify(3, mode='L0')
        self.assertEqual(s.publish(3, v['certificate']), 'published')
        h = v['certificate']
        s.rule = 'cut16'
        s.reset_authority()
        self.assertEqual(s.publish(3, h), 'unsigned')            # old handle is gone
        v2 = s.certify(3, mode='L0')
        self.assertEqual(s.publish(3, v2['certificate']), 'published')


if __name__ == '__main__':
    unittest.main()
