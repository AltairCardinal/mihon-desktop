"""Fix round (main session): fixed shadow runner, BlockSession release, counter fix."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'bench'))
import paths  # noqa: F401,E402
import fix_main_shadow as FS  # noqa: E402
import fixLC_groups as G  # noqa: E402
import fixLC_shadow as LS  # noqa: E402


class FixedShadow(unittest.TestCase):
    def test_lemma_s1_preserved_and_latency_not_worse(self):
        import bench_wpA as BA
        for sc in BA.SCENARIOS[::7] + BA.SCENARIOS[-2:]:
            tr = BA._trace(sc)
            kw = dict(service_u=sc['service_u'], q_u=sc['q_u'], capacity=sc['capacity'])
            inc = FS.make_fixed_runner(tr, 'incumbent', **kw).run(max_steps=40000)
            gs = FS.make_fixed_runner(tr, 'gated_shadow', **kw).run(max_steps=40000)
            self.assertEqual(inc['physical_admissions'], gs['physical_admissions'], sc['name'])
            self.assertEqual(gs['wrong'], 0, sc['name'])
            self.assertEqual(gs['published'], gs['intents'], sc['name'])
            for k, v in gs['latency_u'].items():
                self.assertLessEqual(v, inc['latency_u'][k], (sc['name'], k))

    def test_lifecycle_groups_pass_with_bound_confirmation(self):
        cls = FS.life_fixed_runner_class()
        for persistent in (False, True):
            for var in ('touched', 'untouched'):
                for rb in (13, 31):
                    r, rows = LS.run_shadow(variant=var, bound=True, rebind_item=rb, persistent=persistent,
                                            runner_cls=cls)
                    fails = [(c['group'], c['name']) for c in LS.evaluate(r, rows, var) if not c['ok']]
                    self.assertEqual(fails, [], (persistent, var, rb))
                    self.assertEqual(len(r.l0_cert) + len(r._last_l0), 0, 'mirror released at close (post-freeze fix)')

    def test_r9_runner_defects_reproduced(self):
        r, rows = LS.run_shadow(variant='touched', bound=True, rebind_item=13)
        fails = {(c['group'], c['name']) for c in LS.evaluate(r, rows, 'touched') if not c['ok']}
        self.assertIn(('E6', 'reobtained_after_invalidation'), fails)


class BlockRelease(unittest.TestCase):
    def test_block_session_passes_all_groups_after_release_fix(self):
        for r in G.run_mechanism('block_session', bound=True):
            self.assertTrue(r['ok'], (r['group'], r['failed']))
        s = G.spec('block_session', True)
        self.assertTrue(G.E5(s)['ok'])


class CounterFix(unittest.TestCase):
    def test_projection_path_counts_certification_steps(self):
        import workloads as W
        from wpG_session import GSession
        from wpG_owner import GOwner
        tr = W.w01_phase_chain(0)
        s = GSession(tr['initial'], owner_factory=lambda c: GOwner(c, support='proj'))
        s.certify(5, mode='L0')
        self.assertGreater(s.metrics['certification_steps'], 0)


if __name__ == '__main__':
    unittest.main()
