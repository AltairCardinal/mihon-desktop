"""Fix round PH: N01/N06 constructions, S02 maximality, 18 workload classes."""
import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import fixPH_bounds as B  # noqa: E402
import fixPH_workloads as PW  # noqa: E402
import fixPH_minimal as M  # noqa: E402


class N06Family(unittest.TestCase):
    def test_lemma_P_and_unbounded_radius(self):
        for V in B.VALUE_SETS.values():
            for n in list(range(6, 30)) + [47, 64, 101]:
                r = B.n06_check(n, V)
                self.assertTrue(r['lemma_ok'], (V, n))
                self.assertTrue(r['all_positions_1_to_n_minus_3_changed'], (V, n))
                self.assertGreaterEqual(r['radius_lower_bound'], n - 5)

    def test_front_insertion_relabels_all_but_one(self):
        for n in (8, 20, 41):
            self.assertEqual(B.front_insertion(n, B.VALUE_SETS['ext'])['old_items_relabelled'], n - 1)

    def test_append_changes_only_last_three(self):
        from common import random_case, roundtrip
        rng = random.Random(7)
        for _ in range(200):
            n = rng.randrange(4, 18)
            c = roundtrip(random_case(rng, n))
            self.assertTrue(all(p >= n - 3 for p in B.append_stability(c)))

    def test_reference_is_not_mirror_equivariant(self):
        self.assertFalse(B.mirror_equivariant(B.periodic_chain(10)))


class N01Family(unittest.TestCase):
    def test_exact_minimal_certificate(self):
        for t in list(range(1, 16)) + [25]:
            r = B.n01_row(t)
            self.assertTrue(r['matches_prediction'], t)
            self.assertTrue(r['sensitive_set_is_certificate'], t)
            self.assertTrue(r['each_removal_breaks'], t)
            self.assertEqual(r['sensitive'], 2 * ((t - 1) // 3) + 2)

    def test_other_domains(self):
        for label, dom in (('G0', 'G0'), ('nonneg', 'nonneg'), ('adapter_int', 'ext')):
            r = B.n01_row(10, B.VALUE_SETS[label], dom)
            self.assertTrue(r['matches_prediction'] and r['sensitive_set_is_certificate'], label)

    def test_depth_equals_worst_certificate_small(self):
        for t in (1, 2, 3, 4):
            r = B.exhaustive_cd(t)
            self.assertEqual(r['adaptive_depth_D'], r['max_certificate'], t)
            self.assertEqual(r['certificate_at_periodic'], r['formula_at_periodic'], t)


class S02Maximal(unittest.TestCase):
    def test_reference_maximal_on_random_cases(self):
        from common import random_case, roundtrip
        rng = random.Random(11)
        for _ in range(300):
            c = roundtrip(random_case(rng, rng.randrange(2, 20)))
            self.assertTrue(B.is_maximal(c))


class Workloads(unittest.TestCase):
    def test_every_class_has_a_deterministic_generator(self):
        self.assertEqual(sorted(PW.GENERATORS), [f'W{k:02d}' for k in range(1, 19)])
        for cls, g in PW.GENERATORS.items():
            self.assertEqual(PW.fingerprint(g(3)), PW.fingerprint(g(3)), cls)

    def test_minimal_instances_hold(self):
        for f in M.ALL:
            if f is M.m04:
                continue                    # covered by test_hybrid_minimal (slower)
            r = f()
            self.assertTrue(r['holds'], (r['cls'], r['details']))

    def test_hybrid_minimal(self):
        self.assertTrue(M.m04()['holds'])

    def test_heldout_guard(self):
        with self.assertRaises(ValueError):
            PW.heldout_suite(10)
        with self.assertRaises(ValueError):
            PW.w01_phase_flip_chain(10 ** 6)
        s = PW.heldout_suite(10 ** 6 + 17, per_class=1, classes=['W01', 'W18'])
        self.assertEqual(len(s['W18']), 1)
        self.assertFalse(getattr(PW.w18_composite, '_heldout', False))

    def test_for_runner_reports_dropped_ops(self):
        tr = PW.w18_composite(0, n=12, horizon=200)
        core = PW.for_runner(tr, 'ARunner')
        self.assertGreater(sum(core['dropped_ops'].values()), 0)
        self.assertTrue(all(e['op'] in PW.CORE_OPS['ARunner'] for e in core['events']))


if __name__ == '__main__':
    unittest.main()
