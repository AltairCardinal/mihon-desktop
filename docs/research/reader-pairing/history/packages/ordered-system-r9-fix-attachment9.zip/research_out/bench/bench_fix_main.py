"""Fix round (main session) formal-timing registration: lifecycle-complete shadow runners on the
R9 A grid (same 98 scenarios and traces as bench_wpA).  CANDIDATES[0] = incumbent_fixed
(ARunner incumbent + F1/F2).  gated_shadow_r9 is the unfixed R9 runner, kept as a reference;
gated_shadow_exact_fixed uses the fresh exact DP route (strong baseline for the persistent tree)."""
import hashlib, json, time
import paths  # noqa: F401
import bench_wpA as BA
import wpA_lib as A
import fix_main_shadow as FS

SCENARIOS = BA.SCENARIOS
CANDIDATES = ['incumbent_fixed', 'gated_shadow_fixed', 'persistent_gated_shadow_fixed', 'gated_shadow_exact_fixed',
              'gated_shadow_r9']
WORK_KEYS = BA.WORK_KEYS + ('reintents', 'reintents_served', 'stale_proof_events_dropped', 'current_at_end',
                            'republish_latency_u', 'reintent_l0_republish')


def _runner(tr, cand, kw):
    if cand == 'incumbent_fixed':
        return FS.make_fixed_runner(tr, 'incumbent', **kw)
    if cand == 'gated_shadow_fixed':
        return FS.make_fixed_runner(tr, 'gated_shadow', **kw)
    if cand == 'persistent_gated_shadow_fixed':
        return FS.make_fixed_runner(tr, 'gated_shadow', persistent=True, **kw)
    if cand == 'gated_shadow_exact_fixed':          # strongest fresh route (exact DP) = baseline for persistent tree
        return FS.make_fixed_runner(tr, 'gated_shadow', strong=dict(kind='exact'), **kw)
    if cand == 'gated_shadow_r9':
        return A.make_runner(tr, 'gated_shadow', **kw)
    raise ValueError(cand)


def run_one(sc, cand, rep=0):
    tr = BA._trace(sc)
    kw = dict(service_u=sc['service_u'], q_u=sc['q_u'], capacity=sc['capacity'])
    runner = _runner(tr, cand, kw)
    t0 = time.perf_counter_ns()
    r = runner.run(max_steps=40000)
    wall = time.perf_counter_ns() - t0
    pubs = sorted((int(k), repr(v)) for k, v in runner.session.published.items())
    sha = hashlib.sha256(json.dumps(dict(pubs=pubs, first=sorted(runner.first_pub)), sort_keys=True).encode()).hexdigest()
    ok = r['wrong'] == 0 and r['published'] == r['intents'] and not r['livelock']
    work = {k: r.get(k, 0) for k in WORK_KEYS}
    work['strong_ns_local'] = r.get('strong_ns', 0)
    return dict(wall_ns=wall, verdict_sha256=sha, ok=ok, work=work, wrong=r['wrong'], published=r['published'],
                intents=r['intents'], livelock=r['livelock'], latency_u=r['latency_u'])
