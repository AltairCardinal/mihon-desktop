"""T04 two routes on one corpus -> results/raw/fix/Q2/t04.json
route 1 = re-derivation checker (wpT_checker: exact DP + worlds n<=7) on the claimed-support view
(honest certificates: DP + worlds; mutants: DP part only, since the worlds part can only add rejections);
route 2 = proof-carrying frontier certificate + independent local checker (fixQ2_pcc_checker).
Mutants are labelled valid/invalid by certify_exact on the claimed-support view; for n<=7 every
route-2 acceptance is also compared with the possible-world oracle."""
import collections, copy, json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates')); import paths  # noqa
import workloads as W, omega as O, transducer as T
import fixQ2_pcc as P, fixQ2_pcc_checker as C
from common import random_case, roundtrip

_orig_oracle = O.oracle_units
_memo = {}


def _oracle(case, target, domain='ext', alpha=True, cap=200000):
    """Memoised world oracle (shared by route 1 and the labelling; same function, same answers)."""
    k = (json.dumps(case, sort_keys=True, default=str), target, domain, alpha)
    if k not in _memo:
        try:
            _memo[k] = ('ok', _orig_oracle(case, target, domain, alpha, cap))
        except OverflowError as e:
            _memo[k] = ('overflow', e)
    tag, v = _memo[k]
    if tag == 'overflow':
        raise OverflowError(str(v))
    return v


O.oracle_units = _oracle


def corpus():
    rng = random.Random(404)
    out = []
    for k in range(100):                                   # small: world oracle available
        n = rng.randrange(3, 6)
        c = roundtrip(random_case(rng, n, p_unknown=rng.choice((0.2, 0.4)), p_edge_unknown=rng.choice((0.2, 0.5)),
                                  domain='nonneg'))
        dom = rng.choice(('nonneg', 'ext', 'nonneg'))
        alpha = rng.random() < 0.3
        out.append(('small', c, dom, alpha))
    found, tries = 0, 0                                     # targeted: certified under nonneg, not under ext
    while found < 15 and tries < 1500:
        tries += 1
        n = rng.randrange(3, 6)
        c = roundtrip(random_case(rng, n, p_unknown=0.2, p_edge_unknown=0.6, domain='nonneg'))
        for t in range(n):
            if O.certify_exact(c, t, 'nonneg', False)[0] == 'certified' and O.certify_exact(c, t, 'ext', False)[0] != 'certified':
                out.append(('nonneg_dependent', c, 'nonneg', False)); found += 1
                break
    for fam in ('W01', 'W05', 'W06', 'RP', 'W02'):
        for s in range(3):
            out.append((fam, W.FAMILIES[fam](s)['initial'], 'nonneg', False))
    return out


def refined(case, rng):
    c = copy.deepcopy(case)
    unk = [i for i, it in enumerate(c['items']) if it.get('analysis', {}).get('status') != 'computed']
    if unk:
        i = rng.choice(unk)
        c['items'][i]['analysis'] = dict(status='computed', version=1,
                                         fact=dict(state=rng.choice(('NARROW', 'WIDE')), width=100, height=200,
                                                   rotation=c['items'][i].get('rotation', 0),
                                                   orientation=c['items'][i].get('orientation', 1),
                                                   side=rng.choice(('A', 'B', 'UNKNOWN'))))
        if c['items'][i]['analysis']['fact']['state'] == 'WIDE':
            c['items'][i]['analysis']['fact']['width'] = 200
        if c['items'][i]['analysis']['fact']['rotation'] in (90, 270):
            f = c['items'][i]['analysis']['fact']; f['width'], f['height'] = f['height'], f['width']
        return c
    return None


def main():
    rng = random.Random(7)
    honest = collections.Counter(); mut = collections.defaultdict(collections.Counter)
    times = collections.defaultdict(list); sizes = []; oracle = collections.Counter(); reasons = collections.Counter()
    examples = []
    for src, case, dom, alpha in corpus():
        n = len(case['items'])
        for t in range(n):
            st, u = O.certify_exact(case, t, dom, alpha)
            if st != 'certified':
                continue
            cert, ev = P.issue(case, t, dom, alpha)
            if cert is None:
                honest['issuer_none'] += 1
                continue
            honest['certificates'] += 1
            sz = C.size(cert); sz.update(src=src, n=n, target=t, issuer_evaluations=ev); sizes.append(sz)
            t0 = time.perf_counter_ns(); ok2, why2 = C.check(case, cert); d2 = time.perf_counter_ns() - t0
            t0 = time.perf_counter_ns(); ok1, why1 = P.route1_check(case, cert); d1 = time.perf_counter_ns() - t0
            g = 'small' if n <= 5 else 'family'
            times['route2_ns'].append(d2); times['route1_ns'].append(d1)
            times['route2_ns_' + g].append(d2); times['route1_ns_' + g].append(d1)
            honest['route2_accept'] += ok2; honest['route1_accept'] += ok1
            if not ok2:
                reasons[why2] += 1
                if len(examples) < 5:
                    examples.append(dict(src=src, n=n, target=t, why=why2))
            small = n <= 7
            muts = P.mutants(cert, rng)
            rc = refined(case, rng)
            if rc is not None:
                c2, _ = P.issue(rc, t, dom, alpha)
                if c2 is not None:
                    muts.append(('forged_from_refined_case', c2))
            for name, m in muts:
                valid = P.truth(case, m)
                a2, _w = C.check(case, m)
                a1, _w1 = P.route1_check(case, m, brute_max_n=0)   # DP part; worlds only add rejections
                k = mut[name]
                k['n'] += 1; k['invalid_claims'] += not valid
                k['route2_accept_invalid'] += a2 and not valid; k['route1_accept_invalid'] += a1 and not valid
                k['route2_reject_valid'] += (not a2) and valid; k['route1_reject_valid'] += (not a1) and valid
                k['route2_reject_any'] += not a2; k['route1_reject_any'] += not a1
                if small and a2 and m['domain'] != 'G0':
                    try:
                        U = O.oracle_units(P.mask(case, m['pos_hi'], m['edge_hi']), t, m['domain'], m['alpha'], cap=20000)
                        oracle['route2_accepted_checked'] += 1
                        oracle['route2_accepted_oracle_disagrees'] += set(U) != {T._key(m['unit'])}
                    except OverflowError:
                        oracle['overflow'] += 1
            if small and ok2:
                try:
                    U = O.oracle_units(case, t, dom, alpha, cap=20000)
                    oracle['honest_checked'] += 1
                    oracle['honest_oracle_disagrees'] += set(U) != {T._key(cert['unit'])}
                except OverflowError:
                    oracle['overflow'] += 1
    src = (OUT / 'candidates/fixQ2_pcc_checker.py').read_text().splitlines()
    code_lines = sum(1 for l in src if l.strip() and not l.strip().startswith('#'))
    med = lambda v: sorted(v)[len(v) // 2] if v else None
    res = dict(honest=dict(honest), route2_reject_reasons=dict(reasons), reject_examples=examples,
               mutants={k: dict(v) for k, v in mut.items()}, oracle=dict(oracle),
               size=dict(bytes_median=med([s['bytes'] for s in sizes]), bytes_max=max(s['bytes'] for s in sizes),
                         elements_median=med([s['elements'] for s in sizes]), elements_max=max(s['elements'] for s in sizes),
                         entries_max=max(s['assignment_entries'] for s in sizes),
                         by_src={k: dict(bytes_max=max(s['bytes'] for s in sizes if s['src'] == k),
                                         certs=sum(1 for s in sizes if s['src'] == k)) for k in sorted({s['src'] for s in sizes})}),
               local_ns=dict(route1_median=med(times['route1_ns']), route2_median=med(times['route2_ns']),
                             route1_median_small_dp_plus_worlds=med(times['route1_ns_small']),
                             route2_median_small=med(times['route2_ns_small']),
                             route1_median_family_dp_only=med(times['route1_ns_family']),
                             route2_median_family=med(times['route2_ns_family']),
                             route1_total=sum(times['route1_ns']), route2_total=sum(times['route2_ns']),
                             note='local_measured, exploratory (fork, shared CPU); not formal timing'),
               checker_code_lines=code_lines, checker_file='candidates/fixQ2_pcc_checker.py',
               python=sys.version.split()[0])
    (OUT / 'results/raw/fix/Q2/t04.json').write_text(json.dumps(dict(res, sizes=sizes), indent=1, default=str))
    print(json.dumps(res, indent=1, default=str))


if __name__ == '__main__':
    main()
