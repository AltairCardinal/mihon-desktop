"""Fix round, item 4: structure-entry residency for mechanisms whose formal bench cell does not expose it.
D04 memos: replay every bench_fixQ1 d04 scenario (same construction as bench_fixQ1.run_d04) and count, at
the end, memo entries, stored support keys and extra per-entry fields beyond the corrected owner's
(signature / interval state).  -> results/raw/fix/main/residency_d04.json"""
import copy, json, random, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'bench')); sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import bench_fixQ1 as BQ
from corrected_owner import Owner
import wpB_sigmemo as SG, fixQ1_d04 as D4

BASE_KEYS = {'guard', 'stamp', 'result', 'support'}
rows = []
for sc in BQ.SCENARIOS:
    if sc['family'] != 'd04':
        continue
    for cand, cls in (('owner', Owner), ('sig', SG.SigOwner), ('interval', D4.IntervalOwner)):
        c, rng = BQ._d04_case(sc)
        ow = cls(c)
        cur = copy.deepcopy(c)
        hot = [rng.randrange(sc['n']) for _ in range(4)]
        for step in range(40):
            for t in hot:
                ow.request(t)
            upd = {}
            for e in cur['edges']:
                if e.get('status') != 'computed' or e.get('score') is None:
                    continue
                if sc['mode'] == 'chain_lift':
                    if rng.random() > 0.3: continue
                    e['score'] += 0.5
                elif sc['mode'] == 'chain_shuffle':
                    if rng.random() > 0.3: continue
                    e['score'] = float(rng.choice((1, 2, 3)))
                else:
                    e['score'] = rng.randrange(0, 1500) / 50
                e['version'] = e.get('version', 1) + 1
                upd[(e['first'], e['second'])] = dict(e)
            ow.apply(edge_updates=copy.deepcopy(upd))
        entries = list(ow._memo.values())
        extra_fields = sorted({k for e in entries for k in e if k not in BASE_KEYS})
        extra_values = sum(len(e[k]) if hasattr(e[k], '__len__') else 1 for e in entries for k in e if k not in BASE_KEYS)
        rows.append(dict(scenario=sc['name'], candidate=cand, memo_entries=len(entries),
                         support_keys=sum(len(e['support']) for e in entries), extra_fields=extra_fields,
                         extra_field_values=extra_values, attrs_beyond_owner=sorted(set(vars(ow)) - set(vars(Owner(c))))))
(OUT / 'results/raw/fix/main/residency_d04.json').write_text(json.dumps(rows, indent=1))
for r in rows: print(r)
