"""Compare differential_before.json / differential_after.json -> results/summary/fix/differential.json"""
import json, collections
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
a = json.load(open(OUT / 'results/raw/fix/differential_before.json')); b = json.load(open(OUT / 'results/raw/fix/differential_after.json'))
ka = {(r['module'], r['scenario'], r['candidate']): r for r in a}
diff = collections.Counter(); ex = {}; tot = collections.defaultdict(lambda: collections.Counter())
for r in b:
    k = (r['module'], r['scenario'], r['candidate']); o = ka[k]
    for f, x, y in [('verdict_sha', o['sha'], r['sha']), ('ok', o['ok'], r['ok'])] + \
            [(f, o['work'].get(f), r['work'].get(f)) for f in sorted(set(o['work']) | set(r['work']))]:
        if x != y:
            diff[(k[0], k[2], f)] += 1
            ex.setdefault((k[0], k[2], f), dict(scenario=k[1], before=x, after=y))
            if isinstance(x, (int, float)) and isinstance(y, (int, float)):
                tot[(k[0], k[2], f)]['before'] += x; tot[(k[0], k[2], f)]['after'] += y
res = dict(cells=len(b), cells_identical=sum(1 for r in b if (lambda o: o['sha'] == r['sha'] and o['ok'] == r['ok'] and o['work'] == r['work'])(ka[(r['module'], r['scenario'], r['candidate'])])),
           differences=[dict(module=k[0], candidate=k[1], field=k[2], cells=v, example=ex[k], totals=dict(tot.get(k, {})))
                        for k, v in sorted(diff.items())])
(OUT / 'results/summary/fix').mkdir(parents=True, exist_ok=True)
(OUT / 'results/summary/fix/differential.json').write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
