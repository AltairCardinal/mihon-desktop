"""Fix round (LC) driver.  Usage: run_fixLC.py groups|shadow|mutants|observe|costs
Writes raw results to results/raw/fix/LC/ (never overwrites R9 data)."""
import json, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
RAW = OUT / 'results/raw/fix/LC'
RAW.mkdir(parents=True, exist_ok=True)


def dump(name, obj):
    (RAW / name).write_text(json.dumps(obj, indent=1, default=str))


def groups():
    import fixLC_groups as G
    from fixLC_lifecycle import naive_close_crash
    sink = RAW / 'events_session.jsonl'
    sink.write_text('')
    rows = []
    for m, sp in G.MECHANISMS.items():
        for b in (False, True):
            if sp.get('native_bound') and not b:
                continue
            for r in G.run_mechanism(m, bound=b, sink=sink):
                rows.append(r)
    dump('groups_session.json', dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), rows=rows))
    dump('naive_close.json', dict(package_session=naive_close_crash()))
    # proposed one-line fix for the BlockSession hidden residual (main session owns wpB_coupled.py)
    from wpB_coupled import BlockSession

    class BlockSessionReleased(BlockSession):
        def _txn_commit(self, snap):
            super()._txn_commit(snap); self._cur_snap = None

        def _txn_rollback(self, snap):
            super()._txn_rollback(snap); self._cur_snap = None

        def close(self):
            super().close(); self._cur_snap = None
    G.MECHANISMS['block_session_released(proposed)'] = dict(G.MECHANISMS['block_session'], cls=BlockSessionReleased)
    prop = [G.E5(G.spec('block_session_released(proposed)', True)),
            G.E4_differential(G.spec('block_session_released(proposed)'))]
    dump('block_residual_fix.json', prop)
    print('groups', len(rows), 'fail', sum(not r['ok'] for r in rows))


def shadow():
    import fixLC_shadow as S
    sink = RAW / 'events_shadow.jsonl'
    sink.write_text('')
    out = []
    configs = [('gated_shadow_r9', dict(policy='gated_shadow')), ('shadow_r9', dict(policy='shadow')),
               ('persistent_gated_shadow_r9', dict(policy='gated_shadow', persistent=True)),
               ('gated_shadow_fixed', dict(policy='gated_shadow', fixed=True)),
               ('shadow_fixed', dict(policy='shadow', fixed=True)),
               ('persistent_gated_shadow_fixed', dict(policy='gated_shadow', fixed=True, persistent=True)),
               ('incumbent_runner', dict(policy='incumbent', incumbent_drive=True))]
    for name, kw in configs:
        for var in ('touched', 'untouched'):
            for rb in (13, 31):
                for b in (False, True):
                    r, rows = S.run_shadow(variant=var, bound=b, rebind_item=rb, **kw)
                    chk = S.evaluate(r, rows, var)
                    out.append(dict(config=name, variant=var, rebind_item=rb, bound=b, ok=all(c['ok'] for c in chk),
                                    failed=[c['group'] + ':' + c['name'] for c in chk if not c['ok']], checks=chk,
                                    wrong=r.wrong, proof_wins=r.c.get('proof_wins', 0), gate_skips=r.c.get('gate_skips', 0),
                                    first_pub=r.first_pub))
                    with open(sink, 'a') as fh:
                        for x in rows:
                            fh.write(json.dumps(dict(x, config=name, variant=var, rebind_item=rb, bound=b), default=str) + '\n')
    dump('groups_shadow.json', out)
    print('shadow', len(out), 'fail', sum(not r['ok'] for r in out))


def mutants():
    import fixLC_groups as G
    rows = G.mutants(RAW / 'events_mutants.jsonl')
    dump('mutants.json', rows)
    print('mutants', [(r['mutant'], r['ok']) for r in rows])


def observe(pair, focus, traces, seed0):
    import fixLC_observe as O
    t0 = time.time()
    r = O.compare_pair(pair, traces=traces, length=60, focus=focus, seed0=seed0)
    r['seconds'] = round(time.time() - t0, 1)
    r['seed0'] = seed0
    dump(f'observe_{pair}_{focus}_s{seed0}.json', r)
    print(pair, focus, seed0, r['traces_with_difference'], r['differences'])


def costs():
    import fixLC_costs as C
    import fixLC_groups as G
    out = [C.measure(m) for m in G.MECHANISMS]
    out.append(C.measure('package_session', raw_capacity=1))
    out.append(C.measure('derive_first', raw_capacity=1))
    dump('costs.json', out)
    print('costs', len(out))


if __name__ == '__main__':
    what = sys.argv[1]
    if what == 'observe':          # observe <pair> <focus> <traces> <seed0>
        observe(sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]))
    elif what == 'observe_rc':     # derive_first by raw capacity
        import fixLC_observe as O
        out = []
        for rc in (1, 2, 3):
            for focus in ('mixed', 'expiry'):
                r = O.compare_pair('derive_first', traces=150, length=60, focus=focus, rc_fixed=rc)
                out.append(r); print(rc, focus, r['traces_with_difference'], r['differences'])
        dump('observe_derive_first_by_rc.json', out)
    else:
        globals()[what]()
