"""D04 study: owner / SIG / INTERVAL on value-churn traces; change classification.
Raw: results/raw/fix/Q1/d04_study.json"""
import copy, json, random, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
from common import random_case, roundtrip, base_case, fact
from corrected_owner import Owner
from current_baseline import typed
import wpB_sigmemo as SG, fixQ1_d04 as M

MODES = ('order', 'ties', 'tie_break', 'shuffle', 'local', 'chain_lift', 'chain_drop', 'chain_shuffle')


def chain_case(rng, n):
    c = base_case(n, automatic=True)
    for it in c['items']:
        it['analysis'] = dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1)
    for e in c['edges']:
        e['score'] = float(rng.choice((1, 2, 3)))
    return roundtrip(c)


def mutate(rng, cur, mode):
    upd = {}
    if mode.startswith('chain'):
        for e in cur['edges']:
            if rng.random() > 0.3:
                continue
            if mode == 'chain_lift':
                e['score'] = e['score'] + 0.5          # a later edge rising: ties -> a<b, never creates b<a from a tie
            elif mode == 'chain_drop':
                e['score'] = e['score'] - 0.5
            else:
                e['score'] = float(rng.choice((1, 2, 3)))
            e['version'] = e.get('version', 1) + 1
            upd[(e['first'], e['second'])] = dict(e)
        return upd
    for e in cur['edges']:
        if e.get('status') != 'computed' or e.get('score') is None:
            continue
        s = e['score']
        if mode == 'order':
            s = s * 1.01 + 0.001                         # order preserving rescale
        elif mode == 'ties':
            s = round(s)                                  # coarsen: creates/destroys ties
        elif mode == 'tie_break':
            s = s + rng.choice((0.0, 0.02))               # tiny lift: ties become strict
        elif mode == 'shuffle':
            s = rng.randrange(0, 1500) / 50
        elif mode == 'local':
            if rng.random() > 0.15:
                continue
            s = rng.randrange(0, 1500) / 50
        e['score'] = s; e['version'] = e.get('version', 1) + 1
        upd[(e['first'], e['second'])] = dict(e)
    return upd


rows = []; total = dict(wrong_sig=0, wrong_int=0, wrong_mut=0)
classes = {m: dict(full=0, unit_only=0, changed=0) for m in MODES}
for mode in MODES:
    for seed in range(8):
        rng = random.Random(1000 * MODES.index(mode) + seed)
        n = rng.choice((24, 48, 64))
        if mode.startswith('chain'):
            c = chain_case(rng, n)
        else:
            c = roundtrip(random_case(rng, n, p_unknown=0.15, p_edge_unknown=0.2, domain='G0', settings_mix=False))
            # G0 ranks on a coarse grid so ties are frequent in 'ties'/'tie_break'
            for e in c['edges']:
                if e.get('score') is not None:
                    e['score'] = round(e['score'] / 4)
        owners = dict(owner=Owner(c), sig=SG.SigOwner(c), interval=M.IntervalOwner(c), mutant=M.IntervalMutantBothSigns(c))
        cur = copy.deepcopy(c)
        hot = [rng.randrange(n) for _ in range(4)]
        prev = {}
        for step in range(30):
            for t in hot:
                fresh = Owner(cur).request(t)
                if t in prev:
                    classes[mode][M.classify_change(prev[t], fresh)] += 1
                prev[t] = fresh
                for name, ow in owners.items():
                    r = ow.request(t)
                    if typed(r) != typed(fresh):
                        total['wrong_' + {'sig': 'sig', 'interval': 'int', 'mutant': 'mut', 'owner': 'own'}[name]] = \
                            total.get('wrong_' + {'sig': 'sig', 'interval': 'int', 'mutant': 'mut', 'owner': 'own'}[name], 0) + 1
            upd = mutate(rng, cur, mode)
            for ow in owners.values():
                ow.apply(edge_updates=copy.deepcopy(upd))
        rows.append(dict(mode=mode, seed=seed, n=n, **{f'{k}_{m}': owners[k].metrics[m] for k in ('owner', 'sig', 'interval')
                     for m in ('engine_runs', 'memo_hits', 'typed_reads_checked', 'signature_hits', 'interval_hits',
                               'interval_only_hits', 'scan_steps')}))
summ = {}
for mode in MODES:
    rs = [r for r in rows if r['mode'] == mode]
    summ[mode] = {k: sum(r[k] for r in rs) for k in rs[0] if k.endswith(('engine_runs', 'scan_steps', 'interval_only_hits',
                                                                          'signature_hits', 'interval_hits'))}
out = dict(rows=rows, summary=summ, public_output_mismatches=total, change_classes=classes,
           note='requests: 4 hot targets x 30 steps per trace, 8 traces per mode; mismatch = public result != fresh corrected owner')
(OUT / 'results/raw/fix/Q1/d04_study.json').write_text(json.dumps(out, indent=1))
print(json.dumps(dict(summary=summ, mismatches=total, classes=classes), indent=1))
