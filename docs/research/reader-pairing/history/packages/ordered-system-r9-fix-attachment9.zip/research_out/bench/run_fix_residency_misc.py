"""Fix round, item 4: structure-entry residency for mechanisms whose formal cells do not report it.
Deterministic replays of the same formal scenarios (no timing).  -> results/raw/fix/main/residency_misc.json
  A policies   max over events of runner-held policy structures beyond the request queue:
               proof_inflight + proof_failed_at + stats (adaptive) + rent (ski) + republish
               + l0_pending/l0_cert (shadow runners); also the request queue for reference
  rope         leaf functions + chunk records held by RopePlan after the 30 edit ops (rebuild: 0)
  posrev       per-position revision ints + memo entries (GOwner barrier=posrev) vs incumbent memo entries
  bitset       memoised feasibility entries (feasible_bits LRU) vs symbolic (T.feasible LRU)
"""
import copy, json, random, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'bench')); sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
res = {}

# ---- A policies
import bench_wpA as BA, wpA_lib as A, fix_main_shadow as FS


def extra(r):
    return (len(r.proof_inflight) + len(r.proof_failed_at) + len(getattr(r, 'stats', {})) + len(getattr(r, 'rent', {}))
            + len(r.republish) + len(getattr(r, 'l0_pending', [])) + len(getattr(r, 'l0_cert', {})))


rows = []
for sc in BA.SCENARIOS:
    tr = BA._trace(sc)
    kw = dict(service_u=sc['service_u'], q_u=sc['q_u'], capacity=sc['capacity'])
    for cand, mk in (('incumbent', lambda: A.make_runner(tr, 'incumbent', **kw)),
                     ('gated_shadow_r9', lambda: A.make_runner(tr, 'gated_shadow', **kw)),
                     ('incumbent_fixed', lambda: FS.make_fixed_runner(tr, 'incumbent', **kw)),
                     ('gated_shadow_fixed', lambda: FS.make_fixed_runner(tr, 'gated_shadow', **kw)),
                     ('race_keep', lambda: A.make_runner(tr, 'race_keep', **kw)),
                     ('race_cancel', lambda: A.make_runner(tr, 'race', **kw)),
                     ('adaptive', lambda: A.make_runner(tr, 'adaptive', **kw)),
                     ('ski', lambda: A.make_runner(tr, 'ski', **kw)),
                     ('gated_proof_first', lambda: A.make_runner(tr, 'gated', **kw))):
        r = mk()
        peak = dict(extra=0, queue=0)
        orig = r.drive

        def drive(r=r, orig=orig, peak=peak):
            orig()
            peak['extra'] = max(peak['extra'], extra(r))
            peak['queue'] = max(peak['queue'], len(r.pending))
        r.drive = drive
        r.run(max_steps=40000)
        rows.append(dict(scenario=sc['name'], candidate=cand, extra_peak=peak['extra'], queue_peak=peak['queue'],
                         extra_end=extra(r)))
agg = {}
for c in sorted({r['candidate'] for r in rows}):
    rs = [r for r in rows if r['candidate'] == c]
    agg[c] = dict(extra_peak_max=max(r['extra_peak'] for r in rs), extra_peak_median=sorted(r['extra_peak'] for r in rs)[len(rs) // 2],
                  queue_peak_max=max(r['queue_peak'] for r in rs), extra_end_max=max(r['extra_end'] for r in rs))
res['A_policies'] = dict(summary=agg, rows=rows,
                         note='bench_wpA scenarios; candidate names: race_cancel = policy race, gated_proof_first = policy gated')

# ---- rope (same construction as bench_wpC._rope)
import wpC_structures as S
from common import random_case, roundtrip, fact
rr = []
for n in (1024, 256):
    rng = random.Random(n)
    case = roundtrip(random_case(rng, n, p_wide=0.12, domain='G0', settings_mix=False))
    ops = []
    for k in range(30):
        p = rng.randrange(1, n - 1)
        if k % 2 == 0:
            ops.append(('ins', p, dict(id=f'x{k}', header=fact(), analysis=dict(status='computed', fact=fact('NARROW', 'A'), version=1)),
                        dict(status='computed', score=3.0, version=1), dict(status='computed', score=4.0, version=1)))
        else:
            ops.append(('del', p, dict(status='computed', score=2.0, version=1)))
    r = S.RopePlan(case, B=32)
    peak = len(r.fns) + len(r.chunks)
    for op in ops:
        (r.insert(op[1], copy.deepcopy(op[2]), op[3], op[4]) if op[0] == 'ins' else r.delete(op[1], op[2]))
        peak = max(peak, len(r.fns) + len(r.chunks))
    rr.append(dict(n=n, leaf_fns=len(r.fns), chunks=len(r.chunks), entries_end=len(r.fns) + len(r.chunks), entries_peak=peak,
                   rebuild_entries=0))
res['rope'] = rr

# ---- posrev (same traces as bench_wpG owner family)
import bench_wpG as BG
import wpG_owner as GO
import wpG_traces as TR
pr = []
for sc in BG.SCENARIOS:
    if sc['family'] != 'owner':
        continue
    tr, _want = BG._owner_trace(sc)
    for cand in ('incumbent', 'posrev'):
        o = GO.make(cand, tr['initial'])
        TR.replay(tr, o)
        pr.append(dict(scenario=sc['name'], candidate=cand, memo_entries=len(o._memo),
                       posrev_ints=len(getattr(o, '_posrev', [])),
                       entry_positions=sum(len(e.get('positions', ())) for e in o._memo.values())))
res['posrev'] = pr

# ---- bitset vs symbolic feasibility caches (same constraint sets as bench_wpB feas family)
import bench_wpB as BB
import transducer as T
import wpB_domains as D
fb = []
for sc in BB.SCENARIOS:
    if sc['family'] != 'feas':
        continue
    for cand in ('symbolic', 'bitset'):
        BB.run_feas(sc, cand)
        fb.append(dict(scenario=sc['name'], candidate=cand, symbolic_cache=T.feasible.cache_info().currsize,
                       bitset_cache=D.feasible_bits.cache_info().currsize))
res['bitset'] = fb
(OUT / 'results/raw/fix/main/residency_misc.json').write_text(json.dumps(res, indent=1))
print(json.dumps({k: (v['summary'] if k == 'A_policies' else v) for k, v in res.items()}, indent=1)[:5000])
