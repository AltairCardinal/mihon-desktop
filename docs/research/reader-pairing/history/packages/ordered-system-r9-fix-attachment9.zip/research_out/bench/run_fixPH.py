"""Fix round PH: all executable evidence for items 6 and 7.
Writes results/raw/fix/PH/{n06,n01,s02_maximality,workloads,w18_stress}.json.
Usage: python3 research_out/bench/run_fixPH.py [n06|n01|s02|workloads|w18|all]"""
import json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import fixPH_bounds as B
RAW = OUT / 'results/raw/fix/PH'
RAW.mkdir(parents=True, exist_ok=True)


def save(name, obj):
    (RAW / f'{name}.json').write_text(json.dumps(obj, indent=1, default=str))


def n06():
    t0 = time.time()
    rows = []
    ns = list(range(6, 61)) + list(range(64, 301, 12))
    for label, V in B.VALUE_SETS.items():
        for n in ns:
            r = B.n06_check(n, V); r['values'] = label; rows.append(r)
    ins = [B.front_insertion(n, B.VALUE_SETS['ext']) for n in (8, 16, 32, 64, 128)]
    from common import random_case, roundtrip
    rng = random.Random(606)
    app_viol, app_max_back, app_cases = 0, 0, 0
    mir_non, mir_cases = 0, 0
    for k in range(1500):
        n = rng.randrange(4, 24)
        c = roundtrip(random_case(rng, n, domain=rng.choice(('ext', 'G0'))))
        ch = B.append_stability(c)
        app_cases += 1
        if ch:
            app_max_back = max(app_max_back, n - min(ch))
            app_viol += min(ch) < n - 3
        if k % 3 == 0:
            c2 = roundtrip(random_case(rng, n, settings_mix=False))
            mir_cases += 1
            mir_non += not B.mirror_equivariant(c2)
    res = dict(rows=rows, all_lemma_ok=all(r['lemma_ok'] for r in rows),
               all_positions_changed=all(r['all_positions_1_to_n_minus_3_changed'] for r in rows),
               min_radius_over_n_minus_5=min(r['radius_lower_bound'] - (r['n'] - 5) for r in rows),
               front_insertion=ins,
               append=dict(cases=app_cases, changes_before_n_minus_3=app_viol, max_distance_from_end=app_max_back),
               mirror=dict(cases=mir_cases, not_equivariant=mir_non, periodic10=B.mirror_equivariant(B.periodic_chain(10))),
               seconds=round(time.time() - t0, 1))
    save('n06', res)
    return {k: v for k, v in res.items() if k != 'rows'}


def n01():
    t0 = time.time()
    rows = [B.n01_row(t, check_minimal=t <= 40) for t in range(1, 61)]
    for label in ('G0', 'nonneg', 'adapter_int'):
        dom = 'ext' if label == 'adapter_int' else label
        for t in (5, 13, 29):
            rows.append(B.n01_row(t, B.VALUE_SETS[label], dom))
    cd = []
    for t in range(1, 7):
        s = time.time()
        r = B.exhaustive_cd(t); r['seconds'] = round(time.time() - s, 1); cd.append(r)
        if r['seconds'] > 120:
            break
    res = dict(rows=rows, all_match=all(r['matches_prediction'] and r['sensitive_set_is_certificate'] for r in rows),
               all_minimal_checked=all(r['each_removal_breaks'] for r in rows if r['each_removal_breaks'] is not None),
               exhaustive_certificate_vs_depth=cd, seconds=round(time.time() - t0, 1))
    save('n01', res)
    return {k: v for k, v in res.items() if k != 'rows'}


def s02():
    from common import random_case, roundtrip
    rng = random.Random(202)
    bad, cases = [], 0
    for k in range(3000):
        n = rng.randrange(2, 30)
        c = roundtrip(random_case(rng, n, domain=rng.choice(('ext', 'G0'))))
        cases += 1
        if not B.is_maximal(c):
            bad.append(c)
    res = dict(cases=cases, non_maximal=len(bad), first_counterexample=bad[0] if bad else None)
    save('s02_maximality', res)
    return {k: v for k, v in res.items() if k != 'first_counterexample'}


def workloads():
    import fixPH_workloads as PW
    import fixPH_minimal as M
    gen = {}
    for cls, g in PW.GENERATORS.items():
        fps = []
        for seed in (0, 1, 2):
            a, b = g(seed), g(seed)
            fa = PW.fingerprint(a); fb = PW.fingerprint(b)
            fps.append(dict(seed=seed, fingerprint=fa, deterministic=fa == fb,
                            kind=a.get('kind'), events=len(a.get('events', a.get('ops', a.get('arrivals', []))))))
        gen[cls] = fps
    minimal = []
    for f in M.ALL:
        s = time.time(); r = f(); r['seconds'] = round(time.time() - s, 2); minimal.append(r)
    try:
        PW.heldout_suite(5)
        guard = 'not enforced'
    except ValueError:
        guard = 'enforced'
    res = dict(generators=gen, minimal=minimal, all_hold=all(r['holds'] for r in minimal),
               all_deterministic=all(x['deterministic'] for v in gen.values() for x in v),
               heldout_seed_guard=guard, mapping=[dict(cls=a, generator=b, stresses=c, r9_evidence=d) for a, b, c, d in PW.MAPPING])
    save('workloads', res)
    return dict(all_hold=res['all_hold'], all_deterministic=res['all_deterministic'], guard=guard,
                failing=[r['cls'] for r in minimal if not r['holds']])


def w18_one(seed, pol, rc, horizon, n=192):
    import fixPH_workloads as PW
    import wpA_lib as A
    tr = PW.w18_composite(seed, n=n, horizon=horizon)
    core = PW.for_runner(tr, 'ARunner')
    s = time.time()
    runner = A.make_runner(core, pol, service_u=3, q_u=1, capacity=3, raw_capacity=rc)
    r = runner.run(max_steps=150000)
    return dict(seed=seed, policy=pol, raw_capacity=rc, n=n, horizon=horizon, events=len(core['events']),
                dropped_ops=core['dropped_ops'], fingerprint=tr['fingerprint'], wrong=r['wrong'], published=r['published'],
                intents=r['intents'], livelock=r['livelock'], admissions=r['physical_admissions'], rebinds=r['rebinds'],
                end_u=r['end_u'], max_occupied=r.get('max_occupied'), strong_evaluations=r['strong_evaluations'],
                local_seconds=round(time.time() - s, 1))


def w18():
    """Bounded long-lifetime W18 stress (development seeds); every config runs in its own
    process under a 280 s cap; a cap hit is recorded as a result row, never dropped."""
    import subprocess
    rows = []
    for seed in (0, 1):
        for pol in ('incumbent', 'gated_shadow'):
            for rc in (1, 3):
                cmd = [sys.executable, __file__, 'w18_one', str(seed), pol, str(rc), '3000']
                try:
                    r = subprocess.run(cmd, capture_output=True, text=True, timeout=280)
                    row = json.loads(r.stdout.strip().splitlines()[-1]) if r.returncode == 0 else \
                        dict(seed=seed, policy=pol, raw_capacity=rc, error=r.stderr[-500:])
                except subprocess.TimeoutExpired:
                    row = dict(seed=seed, policy=pol, raw_capacity=rc, n=192, horizon=3000, timeout_s=280, result='cap_hit')
                rows.append(row)
                save('w18_stress', dict(rows=rows, note='development seeds 0,1; n=192, horizon 3000 (300 targets, 411 core events + 11 extended); '
                                        'max_steps 150000 => livelock flag; 280 s process cap => cap_hit row'))
                print(json.dumps(row)[:400], flush=True)
    return rows


def w18small():
    """Reducible small W18 battery (development seeds 0..5, n=24, horizon 400). Step cap 6000 at raw capacity 3,
    500 at raw capacity 1 (enough to expose the evict-first livelock; steps there are ~20 ms each)."""
    import fixPH_workloads as PW
    import wpA_lib as A
    rows = []
    for seed in range(6):
        tr = PW.w18_composite(seed, n=24, horizon=400)
        core = PW.for_runner(tr, 'ARunner')
        for pol in ('incumbent', 'gated_shadow'):
            for rc in (1, 3):
                r = A.make_runner(core, pol, service_u=3, q_u=1, capacity=3, raw_capacity=rc).run(
                    max_steps=6000 if rc > 1 else 500)
                rows.append(dict(seed=seed, policy=pol, raw_capacity=rc, wrong=r['wrong'], published=r['published'],
                                 intents=r['intents'], livelock=r['livelock'], admissions=r['physical_admissions'],
                                 total_latency_u=r['total_latency_u'], fingerprint=tr['fingerprint'],
                                 step_cap=6000 if rc > 1 else 500))
    summ = {}
    for pol in ('incumbent', 'gated_shadow'):
        for rc in (1, 3):
            xs = [r for r in rows if r['policy'] == pol and r['raw_capacity'] == rc]
            summ[f'{pol}_rc{rc}'] = dict(runs=len(xs), wrong=sum(x['wrong'] for x in xs), livelocks=sum(x['livelock'] for x in xs),
                                        published=sum(x['published'] for x in xs), intents=sum(x['intents'] for x in xs),
                                        admissions=sum(x['admissions'] for x in xs))
    save('w18_small', dict(rows=rows, summary=summ, dropped_ops=core['dropped_ops']))
    return summ


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what == 'w18_one':
        print(json.dumps(w18_one(int(sys.argv[2]), sys.argv[3], int(sys.argv[4]), int(sys.argv[5]))))
        sys.exit(0)
    for name, fn in (('n06', n06), ('n01', n01), ('s02', s02), ('workloads', workloads), ('w18small', w18small), ('w18', w18)):
        if what in (name, 'all'):
            print(name, json.dumps(fn(), default=str)[:3000], flush=True)
