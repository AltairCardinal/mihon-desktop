"""Fix round, item 4: memory/release probe for every formal-bench cell (separate from timing).

Usage: run_fix_costprobe.py <bench_module> [--cands a,b] [--only substr]
For each (scenario, candidate): one untraced warm-up run_one (fills harness caches), then one
traced run_one in the same process:
  peak_bytes        tracemalloc peak during the run, minus the traced baseline before it
  retained_bytes    traced memory still held after the result is dropped and gc ran (exit release)
  result_bytes      traced memory held while the returned result is alive (output retention)
  blocks_delta      sys.getallocatedblocks() after - before (live blocks, not cumulative allocation)
Cumulative allocated bytes are NOT measurable with this Python layer (no allocation counter);
they are reported as unavailable, never estimated.  Structure entries are copied from the
cell's `work` when it reports residency-like keys.  tracemalloc slows code: never use these
runs for wall time.  Writes results/raw/fix/costprobe/<module>.jsonl.
"""
import argparse, gc, importlib, json, os, sys, time, tracemalloc
from pathlib import Path
HERE = Path(__file__).resolve()
OUT = HERE.parents[1]
sys.path.insert(0, str(HERE.parent)); sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa

RES_KEYS = ('residency', 'residency_peak', 'residency_final', 'peak_entries', 'entries', 'table_entries', 'structure',
            'resident', 'max_residency', 'memo_entries', 'peak_raw', 'max_occupied')

ap = argparse.ArgumentParser()
ap.add_argument('module'); ap.add_argument('--cands', default=''); ap.add_argument('--only', default='')
a = ap.parse_args()
m = importlib.import_module(a.module)
keep = set(a.cands.split(',')) if a.cands else None
(OUT / 'results/raw/fix/costprobe').mkdir(parents=True, exist_ok=True)
fh = open(OUT / f'results/raw/fix/costprobe/{a.module}.jsonl', 'w')
for sc in m.SCENARIOS:
    if a.only and a.only not in sc['name']:
        continue
    cands = list(m.FAMILY_CANDIDATES(sc)) if hasattr(m, 'FAMILY_CANDIDATES') else list(m.CANDIDATES)
    if keep:
        cands = [c for i, c in enumerate(cands) if i == 0 or c in keep]
    for c in cands:
        row = dict(module=a.module, scenario=sc['name'], candidate=c, pid=os.getpid(),
                   utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
        try:
            m.run_one(sc, c, 0)                       # warm-up (untraced)
            gc.collect()
            b0 = sys.getallocatedblocks()
            tracemalloc.start()
            base = tracemalloc.get_traced_memory()[0]
            tracemalloc.reset_peak()
            r = m.run_one(sc, c, 1)
            cur, peak = tracemalloc.get_traced_memory()
            row['result_bytes'] = cur - base
            row['peak_bytes'] = peak - base
            work = dict(r.get('work') or {})
            ok = r.get('ok')
            del r
            gc.collect()
            row['retained_bytes'] = tracemalloc.get_traced_memory()[0] - base
            tracemalloc.stop()
            row['blocks_delta'] = sys.getallocatedblocks() - b0
            row['ok'] = ok
            row['structure'] = {k: v for k, v in work.items() if any(k.startswith(x) or k.endswith(x) for x in RES_KEYS)}
            row['cumulative_alloc_bytes'] = None
        except Exception as e:  # noqa: BLE001
            if tracemalloc.is_tracing():
                tracemalloc.stop()
            row['error'] = repr(e)[:300]
        fh.write(json.dumps(row, default=str) + '\n'); fh.flush()
fh.close()
print('done', a.module)
