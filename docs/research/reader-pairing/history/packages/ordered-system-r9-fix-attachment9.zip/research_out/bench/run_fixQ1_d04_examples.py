"""Smallest value changes (D04) that keep (a) the full public observation while SIG rejects,
(b) only the canonical unit (steps/diagnostics change).  Raw: results/raw/fix/Q1/d04_examples.json"""
import copy, itertools, json, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
from common import base_case, fact, roundtrip
from corrected_owner import Owner
from current_baseline import typed
import wpB_sigmemo as SG, fixQ1_d04 as M

found = {}
checks = dict(changes=0, interval_accepted=0, sig_accepted=0, n_max=0)
for n in range(3, 7):
    for scores in itertools.product((1.0, 2.0, 3.0), repeat=n - 1):
        c = base_case(n, automatic=True)
        for it in c['items']:
            it['analysis'] = dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1)
        for e, s in zip(c['edges'], scores):
            e['score'] = s
        c = roundtrip(c)
        for t in range(n):
            o = Owner(c); before = o.request(t); sup = dict(o._memo[t]['support']) if t in o._memo else None
            if sup is None:
                continue
            for a in range(n - 1):
                for delta in (0.5, -0.5):
                    c2 = copy.deepcopy(c); c2['edges'][a]['score'] += delta
                    after = Owner(c2).request(t)
                    o2 = Owner(c2); o2.request(t)
                    idx = o2._index()
                    cur = {k: o2._read(idx, k) for k in sup}
                    cls = M.classify_change(before, after)
                    sig, itv = SG.signature_equal(sup, cur), M.interval_equal(sup, cur)
                    checks['changes'] += 1; checks['interval_accepted'] += itv; checks['sig_accepted'] += sig; checks['n_max'] = n
                    if itv and cls != 'full':
                        raise SystemExit('interval accepted a change of the public observation: %r' % ((c, t, a, delta),))
                    key = None
                    if cls == 'full' and itv and not sig:
                        key = 'interval_accepts_sig_rejects'
                    elif cls == 'unit_only':
                        key = 'unit_only_change'
                    if key and key not in found:
                        found[key] = dict(n=n, scores=list(scores), target=t, edge=a, delta=delta,
                                          before={k: before[k] for k in ('status', 'steps', 'needs', 'first', 'dependent_items')},
                                          after={k: after[k] for k in ('status', 'steps', 'needs', 'first', 'dependent_items')},
                                          unit=before.get('unit'), sig_equal=sig, interval_equal=itv)
    if len(found) == 2:
        break
found['exhaustive_checks'] = checks
(OUT / 'results/raw/fix/Q1/d04_examples.json').write_text(json.dumps(found, indent=1, default=str))
print(json.dumps(found, indent=1, default=str))
