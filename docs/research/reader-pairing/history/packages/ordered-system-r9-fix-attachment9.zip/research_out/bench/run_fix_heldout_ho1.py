"""HO-1 (predeclared, results/summary/fix/heldout_predeclared.md): fixed gated_shadow vs fixed
incumbent on the frozen held-out suite.  Writes results/raw/fix/heldout/ho1.jsonl (+ summary json)."""
import json, sys, time, traceback
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import fixPH_workloads as PW
import fix_main_shadow as FS

man = json.loads((OUT / 'results/summary/fix/freeze_manifest.json').read_text())
BASE = man['heldout_seed_base']
CELLS = [(4, 1), (3, 1), (2, 1), (2, 3)]
suite = PW.heldout_suite(BASE)
rows = []
fh = open(OUT / 'results/raw/fix/heldout/ho1.jsonl', 'w')
for cls, traces in suite.items():
    for k, tr in enumerate(traces):
        try:
            trr = PW.for_runner(tr, 'ARunner')
            if not trr.get('events') or 'world' not in trr or 'initial' not in trr:
                raise ValueError('not runner-compatible')
        except Exception as e:  # noqa: BLE001
            row = dict(cls=cls, seed=BASE + k, skipped=repr(e)[:200]); fh.write(json.dumps(row) + '\n'); rows.append(row)
            continue
        for su, q in CELLS:
            for cap in (3, 1):
                rec = dict(cls=cls, seed=BASE + k, name=tr.get('name'), service_u=su, q_u=q, capacity=cap,
                           dropped_ops=trr.get('dropped_ops'))
                try:
                    t0 = time.time()
                    inc = FS.make_fixed_runner(trr, 'incumbent', service_u=su, q_u=q, capacity=cap).run(max_steps=60000)
                    gs = FS.make_fixed_runner(trr, 'gated_shadow', service_u=su, q_u=q, capacity=cap).run(max_steps=60000)
                    worse = [t for t, v in gs['latency_u'].items() if v > inc['latency_u'].get(t, 10 ** 9)]
                    better = [t for t, v in gs['latency_u'].items() if v < inc['latency_u'].get(t, -1)]
                    rec.update(ok=True, secs=round(time.time() - t0, 2),
                               inc=dict((x, inc[x]) for x in ('total_latency_u', 'physical_admissions', 'wrong', 'published',
                                                              'intents', 'livelock', 'reintents', 'reintents_served')
                                        if x in inc),
                               gs=dict((x, gs.get(x)) for x in ('total_latency_u', 'physical_admissions', 'wrong', 'published',
                                                                'intents', 'livelock', 'reintents', 'reintents_served',
                                                                'proof_wins', 'gate_skips', 'strong_evaluations',
                                                                'stale_proof_events_dropped', 'lane_busy_u')),
                               s1_equal=inc['physical_admissions'] == gs['physical_admissions'],
                               targets_worse=len(worse), targets_better=len(better))
                except Exception as e:  # noqa: BLE001
                    rec.update(ok=False, error=traceback.format_exc()[-600:])
                fh.write(json.dumps(rec) + '\n'); fh.flush(); rows.append(rec)
fh.close()
ran = [r for r in rows if r.get('ok')]
summ = dict(seed_base=BASE, cells=len(ran), skipped=sorted({(r['cls'], r['skipped'][:60]) for r in rows if 'skipped' in r}),
            errors=sum(1 for r in rows if r.get('ok') is False),
            s1_violations=sum(1 for r in ran if not r['s1_equal']),
            wrong=sum(r['gs']['wrong'] + r['inc']['wrong'] for r in ran),
            livelock_cells=sum(1 for r in ran if r['gs']['livelock'] or r['inc']['livelock']),
            targets_worse=sum(r['targets_worse'] for r in ran),
            unpublished_cells=sum(1 for r in ran if r['gs']['published'] != r['gs']['intents']),
            by_cell={f'{su},{q}': dict(cells=sum(1 for r in ran if (r['service_u'], r['q_u']) == (su, q)),
                                         latency_inc=sum(r['inc']['total_latency_u'] for r in ran if (r['service_u'], r['q_u']) == (su, q)),
                                         latency_gs=sum(r['gs']['total_latency_u'] for r in ran if (r['service_u'], r['q_u']) == (su, q)),
                                         cells_improved=sum(1 for r in ran if (r['service_u'], r['q_u']) == (su, q) and r['targets_better'] > 0),
                                         admissions=sum(r['inc']['physical_admissions'] for r in ran if (r['service_u'], r['q_u']) == (su, q)))
                     for su, q in CELLS},
            by_class={c: dict(cells=sum(1 for r in ran if r['cls'] == c),
                              latency_inc=sum(r['inc']['total_latency_u'] for r in ran if r['cls'] == c),
                              latency_gs=sum(r['gs']['total_latency_u'] for r in ran if r['cls'] == c),
                              proof_wins=sum(r['gs'].get('proof_wins') or 0 for r in ran if r['cls'] == c),
                              livelock_cells=sum(1 for r in ran if r['cls'] == c and (r['gs']['livelock'] or r['inc']['livelock'])))
                      for c in sorted({r['cls'] for r in ran})})
(OUT / 'results/summary/fix/heldout').mkdir(parents=True, exist_ok=True)
(OUT / 'results/summary/fix/heldout/ho1.json').write_text(json.dumps(summ, indent=1, default=str))
print(json.dumps(summ, indent=1, default=str))
