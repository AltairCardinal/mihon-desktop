"""Write coverage_parts/fix_Q1.csv and adoption_parts/fix_Q1.csv from the Q1 raw files (numbers re-read here)."""
import csv, hashlib, json
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
R = OUT / 'results/raw/fix/Q1'


def fp(*names):
    return ';'.join(f'{n}:{hashlib.sha256((OUT / "candidates" / n).read_bytes()).hexdigest()[:12]}' for n in names)


J = lambda n: json.loads((R / n).read_text())
a = json.loads((OUT / 'results/summary/fix/Q1/a04.json').read_text())
cpl = J('a04_coupled.json')
viol = sum(c['violating_orders'] for c in a['configs'])
orders = sum(c['orders'] for c in a['configs'])
dup = a.get('duplicate_completion', [])
dup_base = sum(d['violating'] for d in dup if d['which'] == 'base'); dup_mut = sum(d['mutant_violating'] for d in dup if d['which'] == 'mutant')
ex = J('b01_exact.json'); sm = J('b01_small.json'); bl = J('b01_blowup.json'); ab = J('b01_ablation.json'); rk = J('b01_rk_lt_search.json')
g = J('b05_grid.json'); mt = J('b05_maintenance.json'); amb = J('b05_ambiguous.json')
d4 = J('d04_study.json'); d4e = J('d04_examples.json'); d5 = J('d05_study.json')
gt = {k: sum(r[k] for r in g['rows']) for k in ('exact', 'goal', 'mitm2', 'mitm4', 'mitm8')}
T = 'python3 -m unittest discover -s research_out/tests -t research_out -p test_fixQ1.py'
cov = [
 dict(question_id='A04', title='proof 与服务重复完成竞争。', family='A', route_a='first-legal-result-wins (FL)',
      route_b='fixed-phase two-phase commit at service-completion barrier (FP: fixQ1_a04.PhaseShadowRunner / run_order)',
      new_gap='close + late failure + duplicate completion interleavings; FL vs FP on common traces',
      status='implemented_verified', depth='D2',
      implementation='candidates/fixQ1_a04.py (ClosableStrongSession, run_order, PhaseShadowRunner)',
      proof_or_counterexample=f'{orders} exhaustive orders (incl. 8-event close set x3 Fb outcomes x2 protocols): {viol} I1-I8 violations; duplicate completion base {dup_base}, no-guard mutant {dup_mut} violating orders; mutants killed (commit_no_revalidate FP noclose 5040/5040)',
      test_command=T, raw_evidence='results/raw/fix/Q1/a04_*.json; results/summary/fix/Q1/a04.json; results/raw/fix/Q1/a04_coupled.json',
      source_fingerprint=fp('fixQ1_a04.py'), domain='n=6 chain case; wpA tuning+heldout2 traces', cost_layer='coupled (virtual u)',
      assumptions='single owner; harness close protocol (package Session has no close); nonpreemptible cancel',
      refutation_condition='an order violating I1-I8; FP earlier than FL on a cell',
      decision=f"keep FL; drop FP (latency {cpl['aggregate']['FP']['total_latency_u']}u vs FL {cpl['aggregate']['FL']['total_latency_u']}u over {cpl['cells']} cells, worse in {cpl['comparison']['FP_worse_than_FL']}, better in 0; equal admissions)",
      remaining='multi-owner / native concurrency; exhaustive only on one small case', work_package='fixQ1',
      audit_note='heldout2 traces were already seen in R9: development evidence only'),
 dict(question_id='B01', title='带边界赋值的精确区间摘要。', family='B', route_a='explicit finite relation tables (wpB_blocks.BlockSummary)',
      route_b='canonical ZDD summaries: relative literals, shared unique table, relational image composition (fixQ1_b01.ZDDSummary)',
      new_gap='canonical decision diagram vs tables; minimal cross-boundary variable set; blow-up region in entries/nodes/bytes',
      status='conditional', depth='D3 候选（待正式计时）',
      implementation='candidates/fixQ1_b01.py (parent: wpB_blocks.BlockSummary)',
      proof_or_counterexample=f"exact: {ex['checks']} random checks 0/0 mismatches; all n3 partial cases vs worlds {sm['n3']['checks']}/0; all n4 vs exact {sm['n4']['checks']}/0; ablation {ab['cases']} cases + {rk['cases']} rank-targeted: manual bit never needed, rk/lt needed {rk['changed']['rk_b']}/{rk['cases']}",
      test_command=T, raw_evidence='results/raw/fix/Q1/b01_exact.json; b01_small.json; b01_ablation.json; b01_rk_lt_search.json; b01_blowup.json',
      source_fingerprint=fp('fixQ1_b01.py'), domain='ext/nonneg', cost_layer='core + structure bytes (deep sizeof)',
      assumptions='Lemma B-1 interface; bytes = Python object bytes, not RSS',
      refutation_condition='ZDD composition differing from exact DP; ZDD larger in blow-up cells',
      decision=f"tables default; ZDD conditional for high-unknown-density long-resident summaries (compacted smaller in {sum(r['zdd']['structure_bytes_compacted'] < r['table']['structure_bytes'] for r in bl['rows'])}/{len(bl['rows'])} cells, 6-80x in blow-up cells; needs periodic compaction)",
      remaining='formal timing; side(b-1)/side(b+2) redundancy unproved', work_package='fixQ1', audit_note='bench/bench_fixQ1.py family b01 registered, not timed by the fork'),
 dict(question_id='B05', title='反向目标约束传播。', family='B', route_a='goal-pruned forward (wpB_layered.goal_pruned)',
      route_b='forward/backward meet-in-the-middle with backward constraint sets (fixQ1_b05.mitm)',
      new_gap='no deletion of legal completions; ambiguous after reaching start; reversal by support maintenance',
      status='refuted', depth='D2',
      implementation='candidates/fixQ1_b05.py (ForwardCache, backward_sets, mitm)',
      proof_or_counterexample=f"B05-1 both sound; MITM unit sets = exact on all {len(g['rows'])}x3 grid queries; evaluations exact {gt['exact']} goal {gt['goal']} mitm2/4/8 {gt['mitm2']}/{gt['mitm4']}/{gt['mitm8']}; W06 {amb['ambiguous_after_start']}/{amb['total']} ambiguous after backward reaches start",
      test_command=T, raw_evidence='results/raw/fix/Q1/b05_grid.json; b05_designed.json; b05_ambiguous.json; b05_maintenance.json',
      source_fingerprint=fp('fixQ1_b05.py'), domain='ext/nonneg', cost_layer='core (BC-2 evaluations)',
      assumptions='single queries and a 60-query update stream',
      refutation_condition='a backward route cheaper than exact forward DP',
      decision='reject both backward routes; keep target-independent forward frontier cache (maintenance stream 2530-5290 vs exact 12503-15361 evaluations)',
      remaining='none for these routes', work_package='fixQ1', audit_note=''),
 dict(question_id='D04', title='比较结果缓存与原值缓存。', family='D', route_a='exact adjacent-order signature memo (wpB_sigmemo.SigOwner)',
      route_b='carried difference-interval memo: delta=b-a in (-inf,0) or [0,inf) (fixQ1_d04.IntervalOwner)',
      new_gap='which value changes keep output but change diagnostics; result vs full public-observation reuse',
      status='implemented_verified', depth='D3 候选（待正式计时）',
      implementation='candidates/fixQ1_d04.py (parent: corrected_owner.Owner, wpB_sigmemo)',
      proof_or_counterexample=f"Theorem D04-1; exhaustive n3-5 chain changes {d4e['exhaustive_checks']['changes']}: interval accepts {d4e['exhaustive_checks']['interval_accepted']}, sig {d4e['exhaustive_checks']['sig_accepted']}, 0 accepted observation changes; study mismatches {d4['public_output_mismatches']}",
      test_command=T, raw_evidence='results/raw/fix/Q1/d04_study.json; results/raw/fix/Q1/d04_examples.json',
      source_fingerprint=fp('fixQ1_d04.py'), domain='G0 random + tie-heavy chains', cost_layer='owner',
      assumptions='frozen scan reads ranks only in later_wins', refutation_condition='an interval-accepted change altering any public field',
      decision='replace SIG by INTERVAL (engine runs chain_lift 392->245, chain_drop 393->241, chain_shuffle 515->399; equal on random G0)',
      remaining='formal timing; unit-only reuse layer not built', work_package='fixQ1', audit_note='bench/bench_fixQ1.py family d04 registered, not timed by the fork'),
 dict(question_id='D05', title='约束稀疏性的通用化。', family='D', route_a='path decomposition over comparison-graph width (exact frontier DP)',
      route_b='generic finite-domain backtracking solver with order-feasibility propagation and early stop (fixQ1_d05.csp)',
      new_gap='short-chain premise at opening, pinned links, boundaries, adversarial long chains; exact complexity dependency',
      status='limit_proved', depth='D2',
      implementation='candidates/fixQ1_d05.py',
      proof_or_counterexample=f"Lemma D05-1 (<=2 constraints at opening, 1 elsewhere); {len(d5['rows'])} cases: max {d5['lemma_check']['max_lt_constraints']} constraint / {d5['lemma_check']['max_lt_edges']} edges, frontier <= {d5['lemma_check']['max_frontier']}; disagreements {d5['disagreements']}",
      test_command=T, raw_evidence='results/raw/fix/Q1/d05_study.json', source_fingerprint=fp('fixQ1_d05.py'),
      domain='ext', cost_layer='core (step calls)', assumptions='automatic mode reserve rule of the frozen scan',
      refutation_condition='a live order component with >1 constraint away from the opening',
      decision='premise holds (proved); keep path decomposition; generic solver only as early ambiguity probe',
      remaining='hybrid probe-then-DP not implemented (incomplete)', work_package='fixQ1', audit_note=''),
]
cols = open(OUT / 'coverage.csv').readline().strip().split(',')
with open(OUT / 'coverage_parts/fix_Q1.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=cols); w.writeheader()
    for r in cov:
        r.setdefault('prior_anchor', 'PRIOR_EVIDENCE_MAP.md; R9 coverage.csv row')
        w.writerow({c: r.get(c, '') for c in cols})
adopt_cols = ['candidate', 'route(L0/L1/L2)', 'gate_observable', 'fallback', 'physical_work_saved', 'extra_cost', 'first_miss_penalty',
              'worst_case', 'parameter_range', 'reversal_point', 'min_calibration', 'interface_change', 'lifecycle_evidence', 'decision']
ad = [
 ['fixQ1_d04.IntervalOwner', 'L0', 'interval_only_hits per request (tie-heavy rank comparisons)', 'exact typed validation', '0 physical; engine runs -21..-38% vs SIG on tie-heavy chains',
  'none beyond SIG (same reads)', 'none (falls back to engine run)', 'equal to SIG when ranks are rarely compared', 'chains n32-64, G0 n24-64', 'none observed', 'formal timing', 'none (internal memo validity)', 'L0 public output checked every request (0 mismatches)', 'adopt as SIG replacement (pending formal timing)'],
 ['fixQ1_b01.ZDDSummary', 'L1 compute', 'table exit keys per block (blow-up)', 'BlockSummary tables', '0 physical; same evaluations', 'compaction pass + op memo; local wall 1.06-1.5x (smoke)',
  'none', 'tiny summaries slightly larger (<=1.3 KB)', 'n32-128, block 4-16, W01/W02/W06', 'exit keys < ~100', 'formal timing; RSS', 'none', 'not in coupled Session (no D4)', 'conditional: long-resident high-unknown summaries'],
 ['fixQ1_a04 FP (fixed-phase commit)', 'L1', '—', 'FL', '0', '0', 'delays every proof publication to the next service completion', 'FP = incumbent latency (1436u vs FL 1140u)', '192 cells', 'always', '—', 'staging slot', 'exhaustive interleavings 0 violations', 'reject'],
 ['fixQ1_b05.mitm / goal_pruned', 'L1 compute', '—', 'exact forward DP', '0', '1.3-20x evaluations', '—', 'maintenance stream up to 169321 vs 15361 evaluations', 'n16-64', 'always', '—', 'none', 'n/a', 'reject; keep ForwardCache'],
]
with open(OUT / 'adoption_parts/fix_Q1.csv', 'w', newline='') as fh:
    w = csv.writer(fh); w.writerow(adopt_cols); w.writerows(ad)
print('ok', len(cov), len(ad))
