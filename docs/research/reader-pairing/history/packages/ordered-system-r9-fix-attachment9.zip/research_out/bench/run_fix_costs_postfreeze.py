"""Re-measure LC session-level costs on the frozen code (BlockSession release fix, GSession
counter fix are included).  Same procedure as bench/run_fixLC.py costs (LC); new file
results/raw/fix/main/costs_postfreeze.json (the LC pre-freeze file is kept)."""
import json, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import fixLC_costs as C
import fixLC_groups as G
out = []
for m in G.MECHANISMS:
    out.append(C.measure(m, bound=(m == 'bound_confirm')))
    print(m, out[-1].get('residency_peak'), out[-1].get('retained_after_close_max'), flush=True)
(OUT / 'results/raw/fix/main/costs_postfreeze.json').write_text(json.dumps(out, indent=1, default=str))
