#!/bin/sh
# Fix round formal timing (main session only; nothing else may run concurrently).
# 3 independent processes x (1 warm-up + 3 measured reps), rotated candidate order.
# New raw data -> results/raw/formal_fix/ (R9 raw in results/raw/formal/ is never touched).
cd "$(dirname "$0")/.."
mkdir -p results/raw/formal_fix
D=results/raw/formal_fix
date -u +%FT%TZ > $D/started_utc.txt
python3 bench/drive_formal.py bench_wpA --out $D/bench_wpA.jsonl --cands gated_shadow,persistent_gated_shadow; date -u +%FT%TZ > $D/bench_wpA_done_utc.txt
python3 bench/drive_formal.py bench_wpB --out $D/bench_wpB.jsonl --only coupled; date -u +%FT%TZ > $D/bench_wpB_done_utc.txt
python3 bench/drive_formal.py bench_wpC --out $D/bench_wpC.jsonl --only coupled; date -u +%FT%TZ > $D/bench_wpC_done_utc.txt
python3 bench/drive_formal.py bench_wpG --out $D/bench_wpG.jsonl --only coupled; date -u +%FT%TZ > $D/bench_wpG_done_utc.txt
python3 bench/drive_formal.py bench_fix_main --out $D/bench_fix_main.jsonl; date -u +%FT%TZ > $D/bench_fix_main_done_utc.txt
python3 bench/drive_formal.py bench_fixQ1 --out $D/bench_fixQ1.jsonl; date -u +%FT%TZ > $D/bench_fixQ1_done_utc.txt
python3 bench/drive_formal.py bench_fixQ2 --out $D/bench_fixQ2.jsonl; date -u +%FT%TZ > $D/bench_fixQ2_done_utc.txt
python3 bench/drive_formal.py bench_fixLC --out $D/bench_fixLC.jsonl; date -u +%FT%TZ > $D/bench_fixLC_done_utc.txt
date -u +%FT%TZ > $D/finished_utc.txt
