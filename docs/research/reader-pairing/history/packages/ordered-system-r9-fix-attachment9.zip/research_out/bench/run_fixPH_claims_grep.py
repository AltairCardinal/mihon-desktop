"""Extract every line with a universal-claim marker from the R9 deliverables
(item 6c audit input).  -> results/raw/fix/PH/claims_grep.json"""
import json, re
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
PAT = re.compile(r'(一般成立|严格支配|不可能|永不|从不|所有|绝不|必然|充要|定理|never|always|strictly dominat|impossible|Theta|Θ|\biff\b)', re.I)
files = ['REPORT.md', 'NEXT_IMPLEMENTER.md', 'coverage.csv', 'ADOPTION_MATRIX.csv'] + \
        sorted(str(p.relative_to(OUT)) for p in (OUT / 'sections').glob('wp*.md')) + \
        sorted(str(p.relative_to(OUT)) for p in (OUT / 'proofs').glob('wp*.md'))
rows = []
for f in files:
    for no, line in enumerate((OUT / f).read_text().splitlines(), 1):
        for m in PAT.finditer(line):
            a = max(0, m.start() - 160); b = min(len(line), m.end() + 160)
            rows.append(dict(file=f, line=no, marker=m.group(0), context=line[a:b]))
(OUT / 'results/raw/fix/PH/claims_grep.json').write_text(json.dumps(rows, ensure_ascii=False, indent=0))
print(len(rows), 'matches in', len(files), 'files')
