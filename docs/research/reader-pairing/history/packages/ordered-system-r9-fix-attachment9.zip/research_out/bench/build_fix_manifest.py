"""Rewrite source-manifest.json for the fix round (R9 manifest kept as source-manifest_R9.json):
package manifest sha + verification, and sha256/bytes of every research_out file."""
import hashlib, json, shutil
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent
old = OUT / 'source-manifest.json'
if not (OUT / 'source-manifest_R9.json').exists():
    shutil.copy2(old, OUT / 'source-manifest_R9.json')
man = json.loads((ROOT / 'MANIFEST.json').read_text())
files = man['files']
items = files.items() if isinstance(files, dict) else [(f['path'], f.get('sha256')) for f in files]
ok = all((ROOT / k).exists() and hashlib.sha256((ROOT / k).read_bytes()).hexdigest() == (v if isinstance(v, str) else v.get('sha256'))
         for k, v in items)
res = {}
for p in sorted(OUT.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts and p.name != 'source-manifest.json':
        res[str(p.relative_to(OUT))] = dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(), bytes=p.stat().st_size)
(OUT / 'source-manifest.json').write_text(json.dumps(dict(schema='fix-round-1', package_manifest_sha256=hashlib.sha256((ROOT / 'MANIFEST.json').read_bytes()).hexdigest(),
                                                          package_files_verified=ok, package_files=len(list(items)), research_out_files=res), indent=1))
print(ok, len(res))
