"""HO-2 (predeclared): LC lifecycle groups (E1-E6 + liveness, bound confirmation) for every
session-level mechanism on frozen held-out W01 fixtures (n=48, 3 rank holes, seeds from the
freeze seed base).  Fixture rule (fixed before running): NEAR = a missing edge, T0 = NEAR-1 with
L0 need_facts and the strong tree certifying T0, FAR = a missing edge > T0+3.  Seeds are scanned
upward from the base until 4 fixtures qualify; every scanned seed is recorded."""
import json, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import workloads as W
import fixLC_groups as G
from strong import StrongSession

man = json.loads((OUT / 'results/summary/fix/freeze_manifest.json').read_text())
BASE = man['heldout_seed_base']
scan, fixtures = [], []
for seed in range(BASE, BASE + 60):
    tr = W.w01_phase_chain(seed, n=48, holes=3)
    holes = sorted(set(range(47)) - {e['first'] for e in tr['initial']['edges']})
    pick = None
    for near in holes:
        t0 = near - 1
        far = [a for a in holes if a > t0 + 3]
        if t0 < 1 or not far:
            continue
        l0 = StrongSession(tr['initial']).certify(t0, mode='L0')['status']
        st = StrongSession(tr['initial'], strong=dict(kind='tree', domain='nonneg', gate='raw')).certify(t0, mode='S')
        if l0 == 'need_facts' and str(st.get('route', '')).startswith('strong'):
            pick = (t0, near, far[0]); break
    scan.append(dict(seed=seed, holes=holes, pick=pick))
    if pick:
        fixtures.append((seed, tr, pick))
    if len(fixtures) == 4:
        break
rows = []
for seed, tr, (t0, near, far) in fixtures:
    G.fixture = (lambda tr=tr: tr)
    G.T0, G.NEAR, G.FAR = t0, near, far
    for m in G.MECHANISMS:
        t1 = time.time()
        try:
            res = G.run_mechanism(m, bound=True)
            for r in res:
                rows.append(dict(seed=seed, t0=t0, near=near, far=far, mechanism=m, group=r['group'], ok=r['ok'],
                                 failed=r['failed'], route=r.get('route'), final=r.get('final')))
        except Exception as e:  # noqa: BLE001
            rows.append(dict(seed=seed, t0=t0, near=near, far=far, mechanism=m, group='ERROR', ok=False, failed=[repr(e)[:300]]))
        print(seed, m, round(time.time() - t1, 1), flush=True)
(OUT / 'results/raw/fix/heldout/ho2.json').write_text(json.dumps(dict(seed_base=BASE, scan=scan, rows=rows), indent=0, default=str))
import collections
bym = collections.defaultdict(lambda: [0, 0, []])
for r in rows:
    b = bym[r['mechanism']]; b[0] += 1; b[1] += r['ok']
    if not r['ok']:
        b[2].append((r['seed'], r['group'], r['failed']))
summ = dict(seed_base=BASE, fixtures=[(s, p) for s, _t, p in fixtures], seeds_scanned=len(scan),
            per_mechanism={m: dict(groups=v[0], ok=v[1], failures=v[2]) for m, v in bym.items()})
(OUT / 'results/summary/fix/heldout/ho2.json').write_text(json.dumps(summ, indent=1, default=str))
print(json.dumps(summ, indent=1, default=str))
