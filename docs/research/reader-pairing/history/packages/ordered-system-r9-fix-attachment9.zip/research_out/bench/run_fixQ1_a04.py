"""A04 exhaustive interleavings, both protocols.  Usage:
  run_fixQ1_a04.py run <protocol FL|FP> <fb ok|unavailable|failed> <events close|noclose>
  run_fixQ1_a04.py mutants
  run_fixQ1_a04.py summary
Raw: results/raw/fix/Q1/a04_<protocol>_<fb>_<events>.json, a04_mutants.json; summary results/summary/fix/Q1/a04.json"""
import json, sys, statistics
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import fixQ1_a04 as Q
R = OUT / 'results/raw/fix/Q1'

if sys.argv[1] == 'run':
    p, fb, ev = sys.argv[2:5]
    r = Q.exhaustive(p, fb, events=Q.EVENTS if ev == 'close' else Q.EVENTS_NO_CLOSE)
    (R / f'a04_{p}_{fb}_{ev}.json').write_text(json.dumps(r))
    print(p, fb, ev, r['orders'], r['violating_orders'], r['violation_kinds'], r['completion'])
elif sys.argv[1] == 'dup':
    # duplicate proof completion: multiset {P,P,L,Fa,Fb,X,R,C}, every distinct order, no close
    import itertools
    p, which = sys.argv[2], sys.argv[3]
    sc = Q.I.small_case()
    orders = sorted(set(itertools.permutations(('P', 'P', 'L', 'Fa', 'Fb', 'X', 'R', 'C'))))
    res = dict(protocol=p, which=which, orders=len(orders), violating=0, kinds={}, mutant_violating=0, mutant_kinds={})
    for o in orders:
        for key, mut in ((('', None),) if which == 'base' else (('mutant_', 'no_first_wins_guard'),)):
            r = Q.run_order(sc, o, p, 'ok', mutant=mut)
            if r['violations']:
                res[key + 'violating'] += 1
                for v in r['violations']:
                    res[key + 'kinds'][v] = res[key + 'kinds'].get(v, 0) + 1
    (R / f'a04_dup_{p}_{which}.json').write_text(json.dumps(res))
    print(res)
elif sys.argv[1] == 'mutants':
    rows = []
    for m in sys.argv[2:]:
        for p in ('FL', 'FP'):
            for ev, evs in (('close', Q.EVENTS), ('noclose', Q.EVENTS_NO_CLOSE)):
                r = Q.exhaustive(p, 'ok', mutant=m, stride=7 if ev == 'close' else 1, events=evs)
                r.pop('outcomes'); r.pop('first_pub_steps')
                rows.append(r)
                print(m, p, ev, r['orders'], r['violating_orders'], r['violation_kinds'])
    (R / f'a04_mutants_{"_".join(sys.argv[2:])}.json').write_text(json.dumps(rows))
else:
    out = dict(configs=[], protocol_comparison=[])
    for fb in ('ok', 'unavailable', 'failed'):
        for ev in ('close', 'noclose'):
            d = {p: json.loads((R / f'a04_{p}_{fb}_{ev}.json').read_text()) for p in ('FL', 'FP')}
            for p, r in d.items():
                out['configs'].append(dict(protocol=p, fb=fb, events=r['events'], orders=r['orders'],
                                           violating_orders=r['violating_orders'], violation_kinds=r['violation_kinds'],
                                           completion=r['completion'], publications=r['publications'],
                                           completion_extra_rounds=r['completion_extra_rounds']))
            a, b = d['FL'], d['FP']
            fa, fp = a['first_pub_steps'], b['first_pub_steps']
            both = [(x, y) for x, y in zip(fa, fp) if x is not None and y is not None]
            out['protocol_comparison'].append(dict(
                fb=fb, events=a['events'], orders=len(fa),
                outcome_differs=sum(x != y for x, y in zip(a['outcomes'], b['outcomes'])),
                published_during_order_FL=sum(x is not None for x in fa), published_during_order_FP=sum(y is not None for y in fp),
                FP_later=sum(1 for x, y in both if y > x), FP_earlier=sum(1 for x, y in both if y < x),
                only_FL_published_in_order=sum(1 for x, y in zip(fa, fp) if x is not None and y is None),
                only_FP_published_in_order=sum(1 for x, y in zip(fa, fp) if y is not None and x is None),
                mean_first_pub_step_FL=round(statistics.mean(x for x, _ in both), 3) if both else None,
                mean_first_pub_step_FP=round(statistics.mean(y for _, y in both), 3) if both else None))
    out['duplicate_completion'] = [json.loads((R / f'a04_dup_{p}_{w}.json').read_text()) for p in ('FL', 'FP')
                                   for w in ('base', 'mutant')]
    out['mutants'] = [r for f in sorted(R.glob('a04_mutants_*.json')) for r in json.loads(f.read_text())]
    (OUT / 'results/summary/fix/Q1/a04.json').write_text(json.dumps(out, indent=1))
    print(json.dumps(out['protocol_comparison'], indent=1))
