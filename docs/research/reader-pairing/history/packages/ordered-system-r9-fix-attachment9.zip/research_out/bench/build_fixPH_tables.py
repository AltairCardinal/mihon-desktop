"""Render the 18-class workload table and W18 stress table (markdown) from
results/raw/fix/PH/{workloads,w18_stress}.json -> results/summary/fix/PH/workload_tables.md"""
import json
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
w = json.load(open(OUT / 'results/raw/fix/PH/workloads.json'))
mp = {m['cls']: m for m in w['mapping']}
mn = {m['cls']: m for m in w['minimal']}
L = ['| 类 | 生成器 | 产物 | 最小实例：对手性质（针对机制） | 成立 | 关键数值 | 主要压测对象 | R9 已有证据 |', '|---|---|---|---|---|---|---|---|']
for cls in sorted(mp):
    g = w['generators'][cls][0]
    m = mn[cls]
    det = json.dumps(m['details'], ensure_ascii=False)
    det = det if len(det) < 160 else det[:157] + '...'
    L.append(f"| {cls} | `{mp[cls]['generator']}` | {g['kind'] or 'session_trace'} | {m['property']}（{m['mechanism']}） | "
             f"{'是' if m['holds'] else '否'} | {det} | {mp[cls]['stresses']} | {mp[cls]['r9_evidence']} |")
L += ['', f"全部生成器确定性（同种子两次指纹相同）：{w['all_deterministic']}；全部最小实例成立：{w['all_hold']}；"
      f"留出种子守卫（<10^6 拒绝）：{w['heldout_seed_guard']}。", '']
p = OUT / 'results/raw/fix/PH/w18_stress.json'
if p.exists():
    s = json.load(open(p))
    L += ['| 种子 | 策略 | raw 容量 | 结果 | wrong | 发布/意图 | 活锁 | 物理接纳 | rebind | 结束 u | 本机 s |', '|---|---|---|---|---|---|---|---|---|---|---|']
    for r in s['rows']:
        if 'result' in r or 'error' in r:
            L.append(f"| {r['seed']} | {r['policy']} | {r['raw_capacity']} | {r.get('result', 'error')} | — | — | — | — | — | — | ≥{r.get('timeout_s', '')} |")
        else:
            L.append(f"| {r['seed']} | {r['policy']} | {r['raw_capacity']} | 完成 | {r['wrong']} | {r['published']}/{r['intents']} | {r['livelock']} | "
                     f"{r['admissions']} | {r['rebinds']} | {r['end_u']} | {r['local_seconds']} |")
    L += ['', s['note']]
q = OUT / 'results/raw/fix/PH/w18_small.json'
if q.exists():
    sm = json.load(open(q))
    L += ['', 'W18 可约简小例（种子 0–5，n=24，horizon 400；步数上限 raw 容量 3 为 6000、容量 1 为 500）：', '',
          '| 配置 | 运行 | wrong | 活锁 | 发布/意图 | 物理接纳 |', '|---|---|---|---|---|---|']
    for k, v in sm['summary'].items():
        L.append(f"| {k} | {v['runs']} | {v['wrong']} | {v['livelocks']} | {v['published']}/{v['intents']} | {v['admissions']} |")
    L += ['', f"核心 runner 显式丢弃的扩展事件：{sm['dropped_ops']}"]
(OUT / 'results/summary/fix/PH/workload_tables.md').write_text('\n'.join(L) + '\n')
print('\n'.join(L))
