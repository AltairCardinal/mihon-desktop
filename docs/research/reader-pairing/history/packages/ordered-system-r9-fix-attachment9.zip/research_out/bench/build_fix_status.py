"""Per-question real status after the fix round -> results/summary/fix/QUESTION_STATUS.md (from coverage.csv vs coverage_R9.csv)."""
import csv
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
new = list(csv.DictReader(open(OUT / 'coverage.csv')))
old = {r['question_id']: r for r in csv.DictReader(open(OUT / 'coverage_R9.csv'))}
L = ['# 逐题真实状态（修复轮后；由 bench/build_fix_status.py 从 coverage.csv 生成）', '',
     '深度规则见 coverage.csv 的 audit_note：D3/D4 必须由 `results/summary/fix/D3_INDEX.csv` 中达到相应深度的已登记机制支撑；'
     '修复轮重做的题目以其新片段为准。"变化"列只列与 R9 不同之处。', '',
     '| 题 | 标题 | 状态 | 深度 R9→修复 | 结论（摘要） | 来源 |', '|---|---|---|---|---|---|']
for r in new:
    q = r['question_id']
    if q.startswith('NH'):
        continue
    o = old.get(q, {})
    src = r['audit_note'].split(';')[0].replace('fix round: source=', '')
    dep = o.get('depth', '?') + ('→' + r['depth'] if o.get('depth') != r['depth'] else '')
    st = r['status'] + ('（R9 ' + o.get('status', '') + '）' if o.get('status') != r['status'] else '')
    dec = r['decision'].replace('|', '/')[:110]
    L.append(f"| {q} | {r['title'].rstrip('。')} | {st} | {dep} | {dec} | {src} |")
(OUT / 'results/summary/fix/QUESTION_STATUS.md').write_text('\n'.join(L) + '\n')
print(len(L) - 6)
