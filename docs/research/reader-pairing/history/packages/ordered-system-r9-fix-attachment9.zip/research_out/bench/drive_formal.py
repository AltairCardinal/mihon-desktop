"""Generic serial formal-timing driver (main session only).

Usage: python3 research_out/bench/drive_formal.py <module> --out raw.jsonl [--reps 3 --warmup 1 --procs 3 --only substr]
<module> is a bench module in research_out/bench exposing SCENARIOS (list of dicts with 'name'),
CANDIDATES (list; [0] = incumbent) and run_one(scenario, candidate, rep) -> dict with at least
wall_ns, verdict_sha256, ok, work.  Optional: FAMILY_CANDIDATES(scenario) -> list of candidates.
Each process is an independent interpreter; candidate order rotates per rep; warmups are kept in
the raw file with warmup=true.  PIDs and UTC are real.
"""
import argparse, importlib, json, os, subprocess, sys, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent)); sys.path.insert(0, str(HERE.parents[1] / 'candidates'))


def child(mod, reps, warmup, only, cands_filter=''):
    import paths  # noqa
    m = importlib.import_module(mod)
    pid = os.getpid()
    for sc in m.SCENARIOS:
        if only and only not in sc['name']:
            continue
        cands = list(m.FAMILY_CANDIDATES(sc)) if hasattr(m, 'FAMILY_CANDIDATES') else list(m.CANDIDATES)
        if cands_filter:                 # keep the scenario incumbent (cands[0]) for paired ratios
            keep = set(cands_filter.split(','))
            cands = [c for i, c in enumerate(cands) if i == 0 or c in keep]
            if len(cands) < 2:
                continue
        for rep in range(warmup + reps):
            cands = cands[1:] + cands[:1]
            for c in cands:
                t0 = time.time()
                try:
                    row = m.run_one(sc, c, rep)
                except Exception as e:      # failures are results, not dropped
                    row = dict(wall_ns=None, ok=False, error=repr(e)[:300], verdict_sha256=None, work={})
                row.update(module=mod, scenario=sc['name'], candidate=c, rep=rep, warmup=rep < warmup, pid=pid,
                           utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(t0)))
                print(json.dumps(row, default=str), flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('module'); ap.add_argument('--out'); ap.add_argument('--reps', type=int, default=3)
    ap.add_argument('--warmup', type=int, default=1); ap.add_argument('--procs', type=int, default=3)
    ap.add_argument('--only', default=''); ap.add_argument('--child', action='store_true')
    ap.add_argument('--cands', default='', help='comma list; incumbent always kept (fix round)')
    a = ap.parse_args()
    if a.child:
        child(a.module, a.reps, a.warmup, a.only, a.cands); sys.exit(0)
    with open(a.out, 'w') as fh:
        for p in range(a.procs):
            cmd = [sys.executable, str(HERE), a.module, '--child', '--reps', str(a.reps), '--warmup', str(a.warmup),
                   '--only', a.only, '--cands', a.cands]
            r = subprocess.run(cmd, capture_output=True, text=True)
            for line in r.stdout.splitlines():
                row = json.loads(line); row['process_index'] = p; fh.write(json.dumps(row) + '\n')
            if r.returncode != 0:
                fh.write(json.dumps(dict(module=a.module, process_index=p, child_error=r.stderr[-2000:])) + '\n')
