"""results/raw/fix/Q2/{t04,x05,x30}.json -> results/summary/fix/Q2/summary.json (numbers quoted in sections/fix_Q2.md)."""
import json
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
R = OUT / 'results/raw/fix/Q2'
t04 = json.loads((R / 't04.json').read_text())
x05 = json.loads((R / 'x05.json').read_text())
x30 = json.loads((R / 'x30.json').read_text())
res = dict(
    t04=dict(honest=t04['honest'], oracle=t04['oracle'], mutants=t04['mutants'], size={k: v for k, v in t04['size'].items()},
             local_ns=t04['local_ns'], checker_code_lines=t04['checker_code_lines']),
    x05=dict(streams=x05['streams'], ALL=x05['summary']['ALL'], by_family={k: v for k, v in x05['summary'].items() if k != 'ALL'}),
    x30={k: v for k, v in x30['summary'].items() if k.startswith('ALL')} | dict(
        per_family_M05={k: v for k, v in x30['summary'].items() if k.endswith('M0.5') and not k.startswith('ALL')},
        t05_oracle_reference=x30['t05_oracle_reference']))
(OUT / 'results/summary/fix/Q2').mkdir(parents=True, exist_ok=True)
(OUT / 'results/summary/fix/Q2/summary.json').write_text(json.dumps(res, indent=1))
print('ok')
