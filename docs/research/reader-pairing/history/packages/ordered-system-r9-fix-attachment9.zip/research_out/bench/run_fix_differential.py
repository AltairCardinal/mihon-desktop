"""Old (R9, candidates/_r9_prefix) vs fixed code on every formal cell that can
touch a strong route.  Usage: run_fix_differential.py <label> [--prefix]
--prefix puts candidates/_r9_prefix first on sys.path (pre-fix strong.py,
wpA_lib.py, wpB_coupled.py, wpC_coupled.py).  Records verdict hash, ok and
the deterministic work counters (local ns removed) per (module, scenario,
candidate) to results/raw/fix/differential_<label>.json."""
import json, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
if '--prefix' in sys.argv:
    sys.path.insert(0, str(OUT / 'candidates/_r9_prefix'))
sys.path.insert(1, str(OUT / 'candidates')); sys.path.insert(1, str(OUT / 'bench'))
import paths  # noqa
import importlib, importlib.util
if '--prefix' in sys.argv:            # bench modules re-insert candidates/ first: pin the old modules explicitly
    for name in ('strong', 'wpA_lib', 'wpB_coupled', 'wpC_coupled'):
        spec = importlib.util.spec_from_file_location(name, OUT / 'candidates/_r9_prefix' / f'{name}.py')
        mod = importlib.util.module_from_spec(spec); sys.modules[name] = mod; spec.loader.exec_module(mod)

NS = ('strong_ns_local', 'strong_ns', 'ns')
rows = []
for mod, sel in (('bench_wpA', lambda sc: True), ('bench_wpB', lambda sc: sc['family'] == 'coupled'),
                 ('bench_wpC', lambda sc: sc.get('fam') == 'coupled')):
    m = importlib.import_module(mod)
    for sc in m.SCENARIOS:
        if not sel(sc):
            continue
        cands = list(m.FAMILY_CANDIDATES(sc)) if hasattr(m, 'FAMILY_CANDIDATES') else list(m.CANDIDATES)
        for c in cands:
            r = m.run_one(sc, c, 0)
            work = {k: v for k, v in (r.get('work') or {}).items() if k not in NS}
            rows.append(dict(module=mod, scenario=sc['name'], candidate=c, sha=r['verdict_sha256'], ok=r['ok'], work=work))
label = sys.argv[1]
(OUT / f'results/raw/fix/differential_{label}.json').write_text(json.dumps(rows, indent=0, default=str))
print(label, len(rows), 'cells; modules:', [sys.modules[n].__file__ for n in ('strong', 'wpA_lib', 'wpB_coupled', 'wpC_coupled')])
