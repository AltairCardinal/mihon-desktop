"""Item 7a: semantic dedupe of the 30 R9 hypotheses against QUESTIONS.md / COMBINATIONS.md.
Writes hypotheses_parts/fix_PH.csv and results/summary/fix/PH/dedupe_counts.json.
Classes: duplicate (the hypothesis is the answer/route the question already asks for),
refinement (a sharper, specific claim inside an existing question's scope),
new (outside every question's scope)."""
import csv, json, collections
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
D = [  # nh, id, class, question(s), reason
 ('NH01', 'NH-A2', 'duplicate', 'A03', 'A03 asks to construct "more certificates, same or more physical tasks" counterexamples; race+cancel destroying reused evidence is exactly that counterexample'),
 ('NH02', 'NH-A3', 'refinement', 'I01', 'FIFO vs LIFO multi-target acquisition order is an admission-ordering result inside I01 (critical-path-aware admission); raw thrash is the mechanism'),
 ('NH03', 'NH-A4', 'refinement', 'A01', 'shadow principle (proof touches only the publication channel) is a third route inside A01 proof-first vs bounded race'),
 ('NH04', 'NH-A6', 'duplicate', 'A05', 'A05 asks for the minimal adoption parameter set; q_u < service_u break-even is its answer (and the "exact" gain formula is only grid-consistent, see claims audit C38)'),
 ('NH05', 'NH-A7', 'refinement', 'A04', 'finding from A04 exhaustive interleavings: certificate clearing on rebind is redundant with the binding guard'),
 ('NH06', 'HB1', 'duplicate', 'B03;B05', 'negative answer to B03/B05 (layering / backward pruning do not pay for single queries)'),
 ('NH07', 'HB2', 'duplicate', 'D04', 'D04 literally compares "exact adjacent-order signature" with carried difference intervals; signature-validated memo is D04 route A, not outside QUESTIONS'),
 ('NH08', 'HB3', 'refinement', 'E03;X10', 'Theorem X-10 (masks never change a single later_wins decision when null and 0 are realisable) is a precise result inside E03/X10'),
 ('NH09', 'HB4', 'duplicate', 'N05', 'N05 asks to design an independent oracle that catches shared default/alternative errors; common-mode blindness of shared choice enumeration is its answer'),
 ('NH10', 'HB5', 'duplicate', 'B01;N02', 'B01 asks for the minimal cross-boundary variables and N02 for state lower bounds including shared ranks; b-1 state necessity and 14 classes > 5 states answer both'),
 ('NH11', 'NH-C1', 'refinement', 'E06', 'early-null-aware prefix normalisation is a third design inside E06 (joint traversal vs deferred derivation, early nulls named in E06)'),
 ('NH12', 'NH-C2', 'refinement', 'O06', 'gated full-information index as a partial-information certificate source is a candidate answer to the O family question of creating a profitable consumer (O06 minimal wiring)'),
 ('NH13', 'NH-C3', 'duplicate', 'X06', 'X06 compares lazy/discard tree with long-lived layered index; never-demote = long-lived layered index'),
 ('NH14', 'NH-C4', 'refinement', 'O06 (via NH12)', 'open sub-conjecture on the gate radius of the NH12 index (r=2 sufficient); scope of the index candidate'),
 ('NH15', 'NH-C5', 'duplicate', 'O04', 'O04 literally compares bounded background build with sliced foreground repayment'),
 ('NH16', 'NH-G1', 'refinement', 'T01;K01', 'evict-before-derive in the frozen Session is one of the hidden premises T01 asks to find (classified abstract infidelity); retention effect is K01 scope'),
 ('NH17', 'NH-G2', 'refinement', 'G01;X20', 'R_policy/R_publish separation under projection support refines G01 (selection-stable certificate) and X20 (support replacement x commit); NATIVE_CONSTRAINTS 1 already separates memo support from public results'),
 ('NH18', 'NH-G3', 'duplicate', 'G01', 'G01 asks to build the minimal sufficient condition for the current selection; decision-relevant projection is that route'),
 ('NH19', 'NH-G4', 'duplicate', 'M06', 'M06 literally asks to construct traces with more legal wakeups but fewer services'),
 ('NH20', 'NH-G5', 'refinement', 'X26;K02', 'mechanistic explanation (cost/size ~ const cancels GDS signal) inside X26 equal-space eviction x cost estimation'),
 ('NH21', 'NH-G6', 'refinement', 'K01;X11', 'negative result inside K01 (dependency-closure joint eviction) at minimum capacity'),
 ('NH22', 'HH1', 'duplicate', 'H04', 'H04 requires that old callbacks can only release resources and never confirm a new context; the package violation is the H04 answer'),
 ('NH23', 'HH2', 'duplicate', 'H06;J06', 'H06 asks to avoid permanent rejection by cross-target guards (joint transaction starvation); J06 asks for a hotspot starving others; both counterexamples are the questions themselves'),
 ('NH24', 'HH3', 'refinement', 'X22', 'interaction sign of value reuse x re-sign depending on rebind kind is a result inside X22'),
 ('NH25', 'HH4', 'refinement', 'J02', 'phantom completion after cooperative exit is the late-result/in-place promotion race J02 names'),
 ('NH26', 'HH5', 'duplicate', 'I04', 'I04 asks for the phase diagram of split vs joint service; load-dependent split value is that diagram'),
 ('NH27', 'HH6', 'duplicate', 'X23', 'antagonism of reservation and speculation is the X23 interaction result'),
 ('NH28', 'NH-M1', 'duplicate', 'S04', 'S04 compares fixed-radius segmentation with bounded-influence rules; restart rules not bounding influence is its negative answer'),
 ('NH29', 'NH-M2', 'refinement', 'T05', 'predicts where residual gain lives (shared-variable families) inside T05'),
 ('NH30', 'NH-M3', 'refinement', 'T01;H03', 'refinement intolerance of exact typed support is a hidden premise (T01) and the "membership unchanged but reason/certainty/permission changed" case of H03; MODEL_API states there is no arbitrary evidence refinement'),
]
src = {r['nh']: r for r in csv.DictReader(open(OUT / 'hypotheses.csv'))}
rows = []
for nh, hid, cls, q, reason in D:
    assert src[nh]['id'] == hid, nh
    rows.append(dict(nh=nh, id=hid, r9_depth=src[nh]['depth'], r9_origin=src[nh]['origin'],
                     reclassification=cls, related_questions=q, reason=reason,
                     counts_as_new_direction='yes' if cls == 'new' else 'no'))
with open(OUT / 'hypotheses_parts/fix_PH.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
cnt = collections.Counter(r['reclassification'] for r in rows)
res = dict(total=len(rows), counts=dict(cnt), genuinely_new=cnt.get('new', 0),
           note='refinements carry specific new content inside an existing question; they are findings, not new directions')
(OUT / 'results/summary/fix/PH').mkdir(parents=True, exist_ok=True)
(OUT / 'results/summary/fix/PH/dedupe_counts.json').write_text(json.dumps(res, indent=1))
print(res)
