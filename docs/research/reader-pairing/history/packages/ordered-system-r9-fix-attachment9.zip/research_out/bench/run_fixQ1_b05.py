"""B05 studies.  Usage: run_fixQ1_b05.py grid|designed|ambiguous|maintenance
Raw: results/raw/fix/Q1/b05_<part>.json.  Evaluation unit = BC-2 (budget.Meter)."""
import copy, json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
from common import random_case, roundtrip, base_case, fact
import fixQ1_b05 as M, omega as O, transducer as T
import workloads as W
from budget import Meter
R = OUT / 'results/raw/fix/Q1'
part = sys.argv[1]


def uset(r):
    return set(r[1]) if r[0] == 'ambiguous' else ({T._key(r[1])} if r[0] == 'certified' else set())


def run3(c, t, dom='ext', alpha=False, ds=(2, 4, 8)):
    out = {}
    e = O.certify_exact(c, t, dom, alpha)
    eu = uset(e)
    ce = {}; M.exact(c, t, dom, alpha, counters=ce); out['exact'] = ce['evaluations']
    cg = {}; g = M.goal_pruned(c, t, dom, alpha, counters=cg); out['goal'] = cg['evaluations']
    out['goal_status_equal'] = (g[0] == 'certified') == (e[0] == 'certified')
    for d in ds:
        cm = {}; r = M.mitm(c, t, dom, alpha, d=d, counters=cm)
        out[f'mitm{d}'] = cm['evaluations']
        out[f'mitm{d}_unitset_equal'] = uset(r) == eu
        out[f'mitm{d}_deleted_legal'] = not eu <= uset(r)
        out[f'mitm{d}_bkeys'] = cm['backward_keys']; out[f'mitm{d}_fkeys'] = cm['forward_keys']
    out['exact_status'] = e[0]
    return out


def designed_case(n, known_tail):
    """Ambiguous prefix (all ranks missing, W06-like) followed by a fully known tail."""
    world = W._world(random.Random(n * 7 + known_tail), n, p_wide=0.0, side_mix=False)
    edges = [a for a in range(n - 1) if a >= n - known_tail]
    return W._initial(world, set(range(n)), edges)


if part == 'grid':
    rng = random.Random(505); rows = []
    for n in (16, 32, 64):
        for pu in (0.1, 0.3, 0.5):
            for k in range(6):
                c = roundtrip(random_case(rng, n, p_unknown=pu, p_edge_unknown=0.5, settings_mix=False))
                t = rng.randrange(n // 2, n)
                rows.append(dict(n=n, pu=pu, target=t, **run3(c, t)))
    out = dict(seed=505, rows=rows)
elif part == 'designed':
    rows = []
    for n in (16, 32, 48):
        for tail in (8, 12):
            c = designed_case(n, tail)
            for t in (n - 2, n - 4):
                rows.append(dict(n=n, known_tail=tail, target=t, **run3(c, t, 'nonneg', False, ds=(2, 4, 6))))
    out = dict(rows=rows, note='ambiguous W06-like prefix (ranks missing) + fully known tail; domain nonneg')
elif part == 'ambiguous':
    rows = []
    for s in range(4):
        c = W.w06_complete_analysis_ambiguous(s, n=12)['initial']
        for t in range(12):
            e = O.certify_exact(c, t, 'nonneg', False)
            cm = {}; r = M.mitm(c, t, 'nonneg', False, d=12, counters=cm)    # meet at 0: backward reaches the start
            cg = {}; g = M.goal_pruned(c, t, 'nonneg', False, counters=cg)
            rows.append(dict(seed=s, target=t, exact=e[0], exact_units=len(uset(e)), mitm_from_start=r[0],
                             mitm_units=len(uset(r)), goal=g[0], meet=cm['meet']))
    out = dict(rows=rows, ambiguous_after_start=sum(1 for r in rows if r['exact'] == 'ambiguous' and r['meet'] == 0),
               total=len(rows))
elif part == 'maintenance':
    rows = []
    for seed in range(3):
        tr = W.random_partial(900 + seed, n=48, pa=0.6, pe=0.6, pattern='jump', count=1)
        world = tr['world']
        rng = random.Random(seed)
        # stream: 60 queries; every 3rd step one revealed fact (item analysis or edge), sweeping right-to-left
        events = []
        unknown_items = [i for i, it in enumerate(tr['initial']['items']) if it['analysis'].get('status') != 'computed']
        known_edges = {e['first'] for e in tr['initial']['edges']}
        unknown_edges = [a for a in range(47) if a not in known_edges]
        for q in range(60):
            if q % 3 == 2 and (unknown_items or unknown_edges):
                if unknown_items and (rng.random() < .5 or not unknown_edges):
                    events.append(('item', unknown_items.pop(rng.randrange(len(unknown_items)))))
                else:
                    events.append(('edge', unknown_edges.pop(rng.randrange(len(unknown_edges)))))
            events.append(('q', rng.randrange(8, 48)))
        tot = dict(exact=0, goal=0, fcache=0, fcache_mitm4=0)
        agree = 0; nq = 0
        for route in tot:
            case = copy.deepcopy(tr['initial'])
            fc = M.ForwardCache(case, 'nonneg', False) if route.startswith('fcache') else None
            res = []
            for ev in events:
                if ev[0] == 'item':
                    case['items'][ev[1]]['analysis'] = copy.deepcopy(world[ev[1]]['analysis'])
                    if fc: fc.update(item=ev[1])
                    continue
                if ev[0] == 'edge':
                    a = ev[1]; ra, rb = world[a]['raw'], world[a + 1]['raw']
                    case['edges'].append(dict(first=a, second=a + 1, status='computed', score=abs(ra - rb), version=1))
                    if fc: fc.update(edge=a)
                    continue
                t = ev[1]
                if route == 'goal':                  # wpB_layered installs its own counter (same BC-2 unit)
                    cg = {}; r = M.L.goal_pruned(case, t, 'nonneg', False, counters=cg)
                    tot[route] += cg['evaluations']; res.append(r[0]); continue
                with Meter(None) as mt:
                    if route == 'exact':
                        r = O.certify_exact(case, t, 'nonneg', False)
                    elif route == 'goal':
                        r = M.L.goal_pruned(case, t, 'nonneg', False)
                    elif route == 'fcache':
                        r = fc.certify(t)
                    else:
                        r = fc.mitm(t, d=4)
                tot[route] += mt.n
                res.append(r[0])
            if route == 'exact':
                ref = res
            else:
                agree += sum(a == b for a, b in zip(ref, res)); nq += len(res)
        rows.append(dict(seed=seed, queries=sum(1 for e in events if e[0] == 'q'),
                         updates=sum(1 for e in events if e[0] != 'q'), evaluations=tot,
                         status_agreement=f'{agree}/{nq}'))
    out = dict(rows=rows, note='RP n48 pa0.6 pe0.6, nonneg, 60 queries, an update every 3rd step')
(R / f'b05_{part}.json').write_text(json.dumps(out, indent=1))
print(json.dumps(out)[:2500])
