"""Freeze the fix-round candidates: sha256 of every file under candidates/ and tests/ plus the
declared parameters; the held-out seed base is derived from the manifest hash AFTER freezing.
Writes results/summary/fix/freeze_manifest.json (never rewritten: refuses if it exists)."""
import hashlib, json, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
dest = OUT / 'results/summary/fix/freeze_manifest.json'
if dest.exists() and '--force' not in sys.argv:
    sys.exit('freeze manifest exists; refusing to overwrite')
files = {}
for root in ('candidates', 'tests'):
    for p in sorted((OUT / root).rglob('*.py')):
        if '__pycache__' in p.parts:
            continue
        files[str(p.relative_to(OUT))] = hashlib.sha256(p.read_bytes()).hexdigest()
PARAMS = dict(
    strong=dict(kind='tree', domain='nonneg', alpha=False, gate='raw', budget=None),
    shadow_gate='gate_rank_only (all needs RANK and analyses computed in [0,t+3])',
    shadow_fix='F1 attempt identity by due time; F2 re-intent with physical mirroring (fix_main_shadow)',
    confirm='bound (confirm(target, handle))',
    block_size=8, d04='interval memo (fixQ1_d04)', b01='table default, zdd conditional (fixQ1_b01)',
    x05='AB1 shared graph carrying support (fixQ2_x05)',
    heldout=dict(per_class=4, service_q_cells=[[4, 1], [3, 1], [2, 1], [2, 3]], capacity=[3, 1], raw_capacity=[3, 1]),
)
blob = json.dumps(dict(files=files, params=PARAMS), sort_keys=True).encode()
sha = hashlib.sha256(blob).hexdigest()
seed_base = 10 ** 6 + int(sha[:8], 16) % (9 * 10 ** 6)
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), manifest_sha256=sha,
                                heldout_seed_base=seed_base, n_files=len(files), params=PARAMS, files=files), indent=1))
print(sha, seed_base, len(files))
