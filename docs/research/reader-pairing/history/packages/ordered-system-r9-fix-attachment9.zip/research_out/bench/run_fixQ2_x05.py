"""X05 0/A/B/A+B (two organisations) + prefix-miss mutants on common streams
-> results/raw/fix/Q2/x05.json (per-stream rows) ; summary with interaction terms per metric."""
import collections, json, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates')); import paths  # noqa
import fixQ2_x05 as X

STREAMS = []
for fam in ('W01', 'RP', 'W05', 'W02'):
    for pattern in ('hot', 'sweep', 'jump'):
        for seed in range(3):
            STREAMS.append(dict(family=fam, seed=seed, pattern=pattern, front=False))
    for seed in range(3):
        STREAMS.append(dict(family=fam, seed=seed, pattern='hot', front=True))


def main():
    rows = []
    t0 = time.time()
    for spec in STREAMS:
        st = X.stream(spec['family'], spec['seed'], pattern=spec['pattern'], front=spec['front'])
        prep = X.prepare(st)
        for arm in X.ARMS:
            r = X.run(st, arm, prep)
            rows.append(dict(stream=st['name'], family=spec['family'], pattern=spec['pattern'] + ('_front' if spec['front'] else ''),
                             arm=arm, **{k: r.get(k, 0) for k in X.METRICS}, answered=r['answered'], ambiguous=r['ambiguous']))
    agg = collections.defaultdict(lambda: collections.Counter())
    for r in rows:
        for m in X.METRICS:
            agg[(r['family'], r['arm'])][m] += r[m]
            agg[('ALL', r['arm'])][m] += r[m]
    summary = {}
    for fam in ('W01', 'RP', 'W05', 'W02', 'ALL'):
        g = {a: dict(agg[(fam, a)]) for a in X.ARMS}
        summary[fam] = dict(arms=g, interaction_AB1=X.interaction(g['0'], g['A'], g['B'], g['AB1']),
                            interaction_AB2=X.interaction(g['0'], g['A'], g['B'], g['AB2']))
    # per-pattern view for the cache-hostile stream
    pat = collections.defaultdict(lambda: collections.Counter())
    for r in rows:
        for m in ('evaluations', 'validation_reads', 'release_work', 'delta_fanout', 'residency_peak'):
            pat[(r['pattern'], r['arm'])][m] += r[m]
    res = dict(streams=len(STREAMS), seconds=round(time.time() - t0, 1), summary=summary,
               by_pattern={f'{p}|{a}': dict(v) for (p, a), v in sorted(pat.items())}, rows=rows,
               note='counts only; evaluations = BC-2 meter unit; stale_reuses checked against certify_exact on the current case')
    (OUT / 'results/raw/fix/Q2/x05.json').write_text(json.dumps(res, indent=1))
    for fam in summary:
        print(fam)
        for a, v in summary[fam]['arms'].items():
            print('  ', a, {k: v.get(k, 0) for k in X.METRICS})
        print('   I_AB1', summary[fam]['interaction_AB1'])
        print('   I_AB2', summary[fam]['interaction_AB2'])
    print('seconds', res['seconds'])


if __name__ == '__main__':
    main()
