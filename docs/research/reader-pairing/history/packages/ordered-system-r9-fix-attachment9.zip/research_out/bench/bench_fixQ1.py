"""Q1 formal-timing registration (fix round).  NOT run by the fork: the main
session times it with drive_formal.py.

Families (FAMILY_CANDIDATES[0] = incumbent):
  d04   corrected Owner (value memo) | SigOwner (R9 SIG) | IntervalOwner (carried
        difference interval) on churn request traces (L0, public output checked
        against a fresh corrected owner every request -> ok).
  b01   BlockSummary explicit tables | ZDDSummary (+compaction) on blow-up
        scenarios; work = evaluations, structure entries/nodes and Python
        structure bytes (deep sizeof, not RSS).
"""
import copy, hashlib, json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
from common import random_case, roundtrip, base_case, fact
from corrected_owner import Owner
from current_baseline import typed
import wpB_sigmemo as SG, fixQ1_d04 as D4, fixQ1_b01 as B1, wpB_blocks as WB
import workloads as W

FAM = {'d04': ['owner', 'sig', 'interval'], 'b01': ['table', 'zdd']}
CANDIDATES = sorted({c for v in FAM.values() for c in v})
SCENARIOS = []
for mode in ('chain_lift', 'chain_shuffle', 'random_shuffle'):
    for n in (32, 64):
        SCENARIOS.append(dict(name=f'd04_{mode}_n{n}', family='d04', mode=mode, n=n, seed=n + len(mode)))
for (n, pu, pe, blk) in ((128, 0.5, 0.7, 8), (128, 0.5, 0.3, 4), (64, 0.2, 0.3, 8)):
    SCENARIOS.append(dict(name=f'b01_random_n{n}_pu{pu}_pe{pe}_b{blk}', family='b01', kind='random', n=n, pu=pu, pe=pe, block=blk, seed=303))
for blk in (4, 8):
    SCENARIOS.append(dict(name=f'b01_W02_n48_b{blk}', family='b01', kind='W02', n=48, block=blk, seed=0))


def FAMILY_CANDIDATES(sc):
    return FAM[sc['family']]


def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


def _d04_case(sc):
    rng = random.Random(sc['seed'])
    if sc['mode'].startswith('chain'):
        c = base_case(sc['n'], automatic=True)
        for it in c['items']:
            it['analysis'] = dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1)
        for e in c['edges']:
            e['score'] = float(rng.choice((1, 2, 3)))
        return roundtrip(c), rng
    return roundtrip(random_case(rng, sc['n'], p_unknown=0.15, p_edge_unknown=0.2, domain='G0', settings_mix=False)), rng


def run_d04(sc, cand):
    c, rng = _d04_case(sc)
    cls = dict(owner=Owner, sig=SG.SigOwner, interval=D4.IntervalOwner)[cand]
    ow = cls(c)
    cur = copy.deepcopy(c)
    hot = [rng.randrange(sc['n']) for _ in range(4)]
    updates = []
    for step in range(40):                      # pre-generate the churn (identical for every candidate)
        upd = {}
        for e in cur['edges']:
            if e.get('status') != 'computed' or e.get('score') is None:
                continue
            if sc['mode'] == 'chain_lift':
                if rng.random() > 0.3: continue
                e['score'] += 0.5
            elif sc['mode'] == 'chain_shuffle':
                if rng.random() > 0.3: continue
                e['score'] = float(rng.choice((1, 2, 3)))
            else:
                e['score'] = rng.randrange(0, 1500) / 50
            e['version'] = e.get('version', 1) + 1
            upd[(e['first'], e['second'])] = dict(e)
        updates.append(upd)
    out = []
    t0 = time.perf_counter_ns()
    for upd in updates:
        for t in hot:
            out.append(ow.request(t))
        ow.apply(edge_updates=copy.deepcopy(upd))
    wall = time.perf_counter_ns() - t0
    # correctness check outside the timed region: replay with fresh owners
    ref_owner_case = copy.deepcopy(c); k = 0; ok = True
    for upd in updates:
        for t in hot:
            ok &= typed(Owner(ref_owner_case).request(t)) == typed(out[k]); k += 1
        for (a, b), e in upd.items():
            for j, x in enumerate(ref_owner_case['edges']):
                if (x['first'], x['second']) == (a, b):
                    ref_owner_case['edges'][j] = copy.deepcopy(e)
    work = {m: ow.metrics[m] for m in ('engine_runs', 'memo_hits', 'support_validations', 'typed_reads_checked',
                                       'signature_hits', 'interval_hits', 'interval_only_hits', 'scan_steps')}
    return dict(wall_ns=wall, verdict_sha256=_sha([typed(x) for x in out]), ok=bool(ok), work=work)


def run_b01(sc, cand):
    if sc['kind'] == 'random':
        rng = random.Random(sc['seed'])
        c = roundtrip(random_case(rng, sc['n'], p_unknown=sc['pu'], p_edge_unknown=sc['pe'], settings_mix=False))
        dom = 'ext'
    else:
        c = W.w02_islands(sc['seed'], n=sc['n'])['initial']; dom = 'nonneg'
    n = len(c['items'])
    targets = list(range(0, n, max(1, n // 16)))
    t0 = time.perf_counter_ns()
    if cand == 'table':
        m = WB.BlockSummary(copy.deepcopy(c), dom, False, block=sc['block'])
        res = [m.certify(t) for t in targets]
        wall = time.perf_counter_ns() - t0
        work = dict(B1.table_size(m), evaluations=m.c['evaluations'], structure_bytes=B1.deep_bytes([m.tables, m.frontier_at]))
    else:
        m = B1.ZDDSummary(copy.deepcopy(c), dom, False, block=sc['block'])
        res = [m.certify(t) for t in targets]
        m.compact()
        wall = time.perf_counter_ns() - t0
        work = dict(m.size(), evaluations=m.c['evaluations'],
                    structure_bytes=B1.deep_bytes([m.z.nodes, m.z.unique, m.rel, m.frontier_at]))
    verdict = [(r[0], B1.T._key(r[1]) if r[0] == 'certified' else None) for r in res]
    return dict(wall_ns=wall, verdict_sha256=_sha(verdict), ok=True, work=work)


def run_one(sc, cand, rep=0):
    return (run_d04 if sc['family'] == 'd04' else run_b01)(sc, cand)


if __name__ == '__main__':          # smoke only (one rep); formal timing is the main session's job
    for sc in SCENARIOS:
        hs = set()
        for c in FAMILY_CANDIDATES(sc):
            r = run_one(sc, c)
            hs.add(r['verdict_sha256'])
            print(sc['name'], c, r['ok'], round(r['wall_ns'] / 1e6, 1), 'ms', {k: v for k, v in r['work'].items() if v})
        print('  same verdict across candidates:', len(hs) == 1)
