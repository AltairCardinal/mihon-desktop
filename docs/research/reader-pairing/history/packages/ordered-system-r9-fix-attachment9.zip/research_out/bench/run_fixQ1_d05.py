"""D05 study: bag width (path decomposition) vs generic backtracking solver on
openings, pinned connections, boundaries and adversarial long chains.
Raw: results/raw/fix/Q1/d05_study.json"""
import json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
from common import random_case, roundtrip, base_case, fact
import fixQ1_d05 as D, omega as O, transducer as T


def chain(n, opening='AUTO', direction='AB', pins=(), isolates=(), unknown_states=False):
    c = base_case(n, automatic=True, direction=direction, opening=opening, pins=list(pins), isolates=list(isolates))
    for it in c['items']:
        it['analysis'] = ({'status': 'unknown'} if unknown_states else
                          dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1))
    c['edges'] = []
    return roundtrip(c)


def measure(fam, c, t, dom='ext', cap=300_000):
    st = {}
    t0 = time.perf_counter()
    with D.StepCounter() as a:
        r1 = D.pathdec(c, t, dom, False, st)
    t1 = time.perf_counter()
    with D.StepCounter() as b:
        r2 = D.csp(c, t, dom, False, cap=cap, early=True)
    t2 = time.perf_counter()
    agree = r2[0] == 'limit' or (r1[0] == r2[0]) or (r1[0] == 'ambiguous' and r2[0] == 'ambiguous')
    return dict(family=fam, n=len(c['items']), target=t, status=r1[0], pathdec_steps=a.n, csp_steps=b.n,
                csp_status=r2[0], csp_nodes=r2[2], agree=agree, pathdec_s=round(t1 - t0, 4), csp_s=round(t2 - t1, 4), **st)


rows = []
rng = random.Random(606)
for k in range(120):                                   # random with openings / pins / isolates (settings_mix)
    n = rng.randrange(6, 30)
    c = roundtrip(random_case(rng, n, p_unknown=rng.choice((0.1, 0.3)), p_edge_unknown=rng.choice((0.3, 0.7))))
    rows.append(measure('random_mixed', c, rng.randrange(n)))
for n in (8, 12, 16, 20, 24, 32):                      # adversarial long all-unknown-rank chains
    for opening in ('AUTO', 'PAIR', 'SINGLE'):
        for direction in ('AB', 'BA'):
            c = chain(n, opening, direction)
            for t in (0, 1, 2, 3, n // 2, n - 2, n - 1):  # opening, middle, boundary
                rows.append(measure(f'long_chain_{opening}_{direction}', c, t, cap=200_000))
for n in (12, 24):                                     # pinned / isolated stretches
    for pins in ([0, 1, 2, 3], list(range(2, n - 2, 2)), list(range(0, n - 1))):
        c = chain(n, pins=pins)
        for t in (1, n // 2, n - 1):
            rows.append(measure('pinned', c, t, cap=200_000))
    c = chain(n, isolates=list(range(1, n, 3)))
    for t in (1, n // 2, n - 1):
        rows.append(measure('isolates', c, t, cap=200_000))
for n in (8, 12, 16):                                  # unknown states (no analyses at all)
    c = chain(n, unknown_states=True)
    for t in (1, n // 2, n - 1):
        rows.append(measure('unknown_states', c, t, cap=200_000))
out = dict(rows=rows, seed=606,
           lemma_check=dict(max_lt_constraints=max(r['max_lt_constraints'] for r in rows),
                            max_lt_edges=max(r['max_lt_edges'] for r in rows),
                            max_lt_edges_beyond_opening=max((r['max_lt_edges'] for r in rows
                                                             if r['max_lt_edges_at'] not in (None, 0, 1)), default=0),
                            max_bag_vars=max(r['max_bag_vars'] for r in rows),
                            max_frontier=max(r['max_frontier'] for r in rows)),
           disagreements=sum(1 for r in rows if not r['agree']))
(OUT / 'results/raw/fix/Q1/d05_study.json').write_text(json.dumps(out, indent=1))
import collections
agg = collections.defaultdict(lambda: collections.Counter())
for r in rows:
    f = r['family'].split('_')[0] + ('_' + r['family'].split('_')[1] if r['family'].startswith('long') else '')
    agg[f]['cases'] += 1; agg[f]['pathdec_steps'] += r['pathdec_steps']; agg[f]['csp_steps'] += r['csp_steps']
    agg[f]['csp_limit'] += r['csp_status'] == 'limit'; agg[f]['csp_cheaper'] += r['csp_steps'] < r['pathdec_steps']
    agg[f]['max_lt_edges'] = max(agg[f]['max_lt_edges'], r['max_lt_edges']); agg[f]['max_frontier'] = max(agg[f]['max_frontier'], r['max_frontier'])
out['by_family'] = {k: dict(v) for k, v in agg.items()}
(OUT / 'results/raw/fix/Q1/d05_study.json').write_text(json.dumps(out, indent=1))
print(json.dumps(dict(lemma=out['lemma_check'], disagreements=out['disagreements'], by_family=out['by_family']), indent=1))
