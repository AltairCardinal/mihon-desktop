"""HO-3..HO-7 (predeclared in results/summary/fix/heldout_predeclared.md) on the frozen held-out
seed base.  Usage: run_fix_heldout_rest.py ho3|ho4|ho5|ho6|ho7
Raw + summary: results/raw/fix/heldout/<part>.json"""
import copy, json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates')); sys.path.insert(0, str(OUT / 'tests'))
import paths  # noqa

man = json.loads((OUT / 'results/summary/fix/freeze_manifest.json').read_text())
BASE = man['heldout_seed_base']
R = OUT / 'results/raw/fix/heldout'
part = sys.argv[1]
t_start = time.time()


def save(obj):
    obj = dict(obj, seed_base=BASE, seconds=round(time.time() - t_start, 1), freeze_manifest=man['manifest_sha256'])
    (R / f'{part}.json').write_text(json.dumps(obj, indent=1, default=str))
    print(json.dumps({k: v for k, v in obj.items() if k != 'rows'}, indent=1, default=str)[:6000])


if part == 'ho3':
    import workloads as W
    import fixLC_observe as O
    # held-out traces: seeds BASE+k and sizes not used in development (n=20 / 12)
    O.FAMS = (lambda sd: W.w01_phase_chain(BASE + sd, n=20, count=8), lambda sd: W.w05_raw_eviction(BASE + sd, n=20),
              lambda sd: W.random_partial(BASE + sd, n=20), lambda sd: W.w06_complete_analysis_ambiguous(BASE + sd, n=12))
    res = []
    for pair, traces in (('control', 120), ('inc_revoke', 300), ('inc_revoke_strong', 150), ('derive_first', 150),
                         ('bound_confirm', 150)):
        for focus in ('mixed', 'expiry'):
            r = O.compare_pair(pair, traces=traces, length=60, seed0=BASE, focus=focus)
            res.append({k: r[k] for k in ('pair', 'focus', 'traces', 'events', 'traces_with_difference', 'differences',
                                           'coverage')})
            print(pair, focus, r['traces_with_difference'], flush=True)
    save(dict(rows=res, summary={f"{r['pair']}|{r['focus']}": dict(events=r['events'], traces_with_difference=r['traces_with_difference'],
                                                                     difference_classes=sorted(r['differences']))
                                 for r in res}))

elif part == 'ho4':
    from common import random_case, roundtrip, base_case, fact
    from corrected_owner import Owner
    from current_baseline import typed
    import wpB_sigmemo as SG, fixQ1_d04 as M
    MODES = ('order', 'ties', 'tie_break', 'shuffle', 'local', 'chain_lift', 'chain_drop', 'chain_shuffle')

    def chain_case(rng, n):                     # copied from bench/run_fixQ1_d04.py (frozen)
        c = base_case(n, automatic=True)
        for it in c['items']:
            it['analysis'] = dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1)
        for e in c['edges']:
            e['score'] = float(rng.choice((1, 2, 3)))
        return roundtrip(c)

    def mutate(rng, cur, mode):                 # copied from bench/run_fixQ1_d04.py (frozen)
        upd = {}
        if mode.startswith('chain'):
            for e in cur['edges']:
                if rng.random() > 0.3:
                    continue
                if mode == 'chain_lift':
                    e['score'] = e['score'] + 0.5
                elif mode == 'chain_drop':
                    e['score'] = e['score'] - 0.5
                else:
                    e['score'] = float(rng.choice((1, 2, 3)))
                e['version'] = e.get('version', 1) + 1
                upd[(e['first'], e['second'])] = dict(e)
            return upd
        for e in cur['edges']:
            if e.get('status') != 'computed' or e.get('score') is None:
                continue
            s = e['score']
            if mode == 'order':
                s = s * 1.01 + 0.001
            elif mode == 'ties':
                s = round(s)
            elif mode == 'tie_break':
                s = s + rng.choice((0.0, 0.02))
            elif mode == 'shuffle':
                s = rng.randrange(0, 1500) / 50
            elif mode == 'local':
                if rng.random() > 0.15:
                    continue
                s = rng.randrange(0, 1500) / 50
            e['score'] = s; e['version'] = e.get('version', 1) + 1
            upd[(e['first'], e['second'])] = dict(e)
        return upd

    rows = []; mism = dict(sig=0, interval=0, owner=0)
    for mode in MODES:
        for k in range(6):
            rng = random.Random(BASE * 7 + 1000 * MODES.index(mode) + k)
            n = rng.choice((32, 56, 80))
            if mode.startswith('chain'):
                c = chain_case(rng, n)
            else:
                c = roundtrip(random_case(rng, n, p_unknown=0.15, p_edge_unknown=0.2, domain='G0', settings_mix=False))
                for e in c['edges']:
                    if e.get('score') is not None:
                        e['score'] = round(e['score'] / 4)
            owners = dict(owner=Owner(c), sig=SG.SigOwner(c), interval=M.IntervalOwner(c))
            cur = copy.deepcopy(c)
            hot = [rng.randrange(n) for _ in range(4)]
            for step in range(30):
                for t in hot:
                    fresh = Owner(cur).request(t)
                    for name, ow in owners.items():
                        if typed(ow.request(t)) != typed(fresh):
                            mism[name] += 1
                upd = mutate(rng, cur, mode)
                for ow in owners.values():
                    ow.apply(edge_updates=copy.deepcopy(upd))
            rows.append(dict(mode=mode, k=k, n=n, **{f'{o}_engine_runs': owners[o].metrics['engine_runs'] for o in owners}))
    summ = {m: {o: sum(r[f'{o}_engine_runs'] for r in rows if r['mode'] == m) for o in ('owner', 'sig', 'interval')}
            for m in MODES}
    order_ok = all(v['interval'] <= v['sig'] <= v['owner'] for v in summ.values())
    save(dict(rows=rows, public_output_mismatches=mism, engine_runs_by_mode=summ,
              predicate_interval_le_sig_le_owner_all_modes=order_ok))

elif part == 'ho5':
    from common import random_case, roundtrip
    import fixQ1_b01 as B, omega as O
    rng = random.Random(BASE + 5); tot = bad_t = bad_z = 0; sizes = []
    for k in range(150):
        n = rng.randrange(1, 28)
        c = roundtrip(random_case(rng, n, p_unknown=rng.choice((0.1, 0.3, 0.5)), p_edge_unknown=rng.choice((0.2, 0.5)),
                                  p_fail=0.03))
        alpha = rng.random() < .5
        blk = rng.choice((1, 2, 3, 4, 8))
        bs = B.WB.BlockSummary(copy.deepcopy(c), 'ext', alpha, block=blk)
        zs = B.ZDDSummary(copy.deepcopy(c), 'ext', alpha, block=blk)
        for t in range(n):
            e = O.certify_exact(c, t, 'ext', alpha)
            tot += 1
            same = lambda a, b: (a[0] == 'certified') == (b[0] == 'certified') and (a[0] != 'certified' or a[1] == b[1])  # noqa
            bad_t += not same(e, bs.certify(t)); bad_z += not same(e, zs.certify(t))
    save(dict(cases=150, checks=tot, table_mismatch=bad_t, zdd_mismatch=bad_z))

elif part == 'ho6':
    import collections
    import fixQ2_x05 as X
    rows = []
    for fam in ('W01', 'RP', 'W05', 'W02'):
        for pattern in ('hot', 'sweep', 'jump'):
            for k in range(2):
                st = X.stream(fam, BASE + k, pattern=pattern, front=False)
                prep = X.prepare(st)
                for arm in X.ARMS:
                    r = X.run(st, arm, prep)
                    rows.append(dict(stream=st['name'], family=fam, pattern=pattern, arm=arm, **{m: r.get(m, 0) for m in X.METRICS}))
        print(fam, flush=True)
    agg = collections.defaultdict(collections.Counter)
    for r in rows:
        for m in X.METRICS:
            agg[r['arm']][m] += r[m]
    g = {a: dict(agg[a]) for a in X.ARMS}
    per_stream_ab1_le_ab2 = sum(1 for s in {r['stream'] for r in rows}
                                if [r for r in rows if r['stream'] == s and r['arm'] == 'AB1'][0]['evaluations']
                                <= [r for r in rows if r['stream'] == s and r['arm'] == 'AB2'][0]['evaluations'])
    save(dict(rows=rows, arms=g, interaction_AB1=X.interaction(g['0'], g['A'], g['B'], g['AB1']),
              interaction_AB2=X.interaction(g['0'], g['A'], g['B'], g['AB2']),
              streams=len({r['stream'] for r in rows}), streams_AB1_evals_le_AB2=per_stream_ab1_le_ab2,
              wrong=dict((a, g[a].get('wrong_fresh', 0) + g[a].get('stale_reuses', 0)) for a in g)))

elif part == 'ho7':
    import workloads as W
    import test_budget_contract as TB
    from strong import StrongSession
    rows = []
    for k in range(6):
        for gen in (lambda s: W.w01_phase_chain(s, n=40, holes=3), lambda s: W.w05_raw_eviction(s, n=28),
                    lambda s: W.random_partial(s, n=28)):
            tr = gen(BASE + k)
            case = tr['initial']
            n = len(case['items'])
            for t in range(n):
                if StrongSession(case).certify(t, mode='L0')['status'] != 'need_facts':
                    continue
                for route in ('fresh_tree', 'fresh_exact', 'persistent', 'block'):
                    make, mode = TB.ROUTES[route]
                    s = make(case, None)
                    b0 = s.metrics['strong_evaluations']
                    v = s.certify(t, mode=mode)
                    need = s.metrics['strong_evaluations'] - b0
                    if not TB.strong_issued(v):
                        continue
                    ok_exact = TB.strong_issued(make(case, need).certify(t, mode=mode))
                    s2 = make(case, need - 1)
                    fp0 = TB.fingerprint(route, s2)
                    short = s2.certify(t, mode=mode)
                    rows.append(dict(seed=BASE + k, n=n, target=t, route=route, need=need, exact_budget_certifies=ok_exact,
                                     one_short_issues=TB.strong_issued(short), certs_after_short=s2.metrics['strong_certificates'],
                                     fingerprint_restored=TB.fingerprint(route, s2) == fp0))
    viol = [r for r in rows if not r['exact_budget_certifies'] or r['one_short_issues'] or r['certs_after_short']
            or not r['fingerprint_restored']]
    save(dict(rows=rows, checks=len(rows), violations=len(viol), violation_examples=viol[:5],
              by_route={rt: sum(1 for r in rows if r['route'] == rt) for rt in ('fresh_tree', 'fresh_exact', 'persistent', 'block')}))
