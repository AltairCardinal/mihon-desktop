"""Item 6c: audit of universal claims in the R9 deliverables.
Input: results/raw/fix/PH/claims_grep.json (bench/run_fixPH_claims_grep.py, 146 marker hits).
Output: results/summary/fix/PH/claims_audit.csv (one row per distinct claim, with the grep
hits it covers) and claims_audit_counts.json.  Scope classes:
  proved_general        proof for all inputs under stated premises
  proved_family         proof for all sizes of a stated parametric family
  by_construction       follows from code/definition (no empirical content)
  exhaustive_bounded    exhaustive check up to a stated size only
  sampled               random/grid sample or fixed scenario set only
  existential           a counterexample/witness (an existential claim; valid as stated)
  convention            reporting rule, not a claim about the system
"""
import csv, json, collections
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
G = json.load(open(OUT / 'results/raw/fix/PH/claims_grep.json'))
A = [
 # id, hits, claim, premises, quantifier, scope, verdict, revised wording / note
 ('C01', [0, 30, 51, 60, 76, 130], 'derive_first is never worse (288 held-out rows)', 'coupled model, LRU raw, L0 policies', 'all traces (implied)', 'sampled', 'narrow',
  'Not worse in 288 measured rows (development evidence: those held-out rows were inspected repeatedly). Per-step superset of derived ranks is proved (L-K1 b); global admissions dominance is explicitly not a theorem. Classified as model-fidelity correction (LC fork), not a native gain.'),
 ('C02', [], 'evict-first livelocks at raw capacity 1 (L-K1 a)', 'frozen Session.consume order, raw_capacity=1, target needing a computed rank', 'every such trace', 'proved_general', 'keep',
  'Proof: after insertion |R|=2>1, the only other resident is evicted before derivation. Executable: fixPH_minimal.m05.'),
 ('C03', [1, 12, 52, 77, 129], 'compressed policy support must never be publication support', 'projection memo composed with Session publication', 'normative rule', 'existential', 'keep',
  'Normative rule justified by an existential defect (born-stale certificates, INVALID run kept). Not an impossibility theorem.'),
 ('C04', [2, 94], 'B03/B05 strictly dominated by exact DP (2-5x evaluations)', 'single queries, ext domain, n in {16,64,128}, pu grid', 'all inputs (implied by "strictly")', 'sampled', 'downgrade',
  '"Higher evaluation count than exact DP in the measured cells" (exact cheapest in 8/9 cells; tree-only cheaper at n64 pu0.6). Not a dominance theorem. B05 re-examined by fork Q1.'),
 ('C05', [3, 4, 65, 73, 95], 'u never converted to ms / ns never added to u', '-', '-', 'convention', 'keep', 'Reporting convention.'),
 ('C06', [5, 33, 70, 111], 'N01: certificate size Theta(t)', 'G0 chains, support-based certificates', 'claimed Theta(t) from t=6,9,14,21', 'sampled', 'narrow',
  'Replaced by Lemma P / Theorem N01-PH: on family P_n(V) for EVERY t, minimal rank-fact certificate = 2*floor((t-1)/3)+2 exactly (items known), Theta(t); adaptive decision-tree depth >= certificate size, so adaptivity cannot help on this family. Family-scoped, not for all inputs (some targets have O(1) certificates).'),
 ('C07', [5], 'N02: 14 Myhill-Nerode classes > 5 cursor states at some boundaries', 'sampled boundaries', 'there exist boundaries', 'existential', 'keep',
  'Existential lower bound at observed boundaries; no general state lower bound as a function of n is claimed.'),
 ('C08', [6], 'coupled metrics identical across all repetitions', 'deterministic virtual model', 'all formal rows', 'sampled', 'keep', 'Measured over every formal row (distinct verdict hashes = 1).'),
 ('C09', [7], 'all D4 are virtual-service evidence', '-', '-', 'convention', 'keep', 'Scope statement; the D4 count itself is re-audited by LC/main.'),
 ('C10', [8, 66], 'race_keep is never worse (refuted)', '-', 'existential counterexample K1', 'existential', 'keep', 'Refutation by explicit counterexample is valid.'),
 ('C11', [9], 'all exploration runs had a 300 s cap; no silently dropped samples', 'procedure', '-', 'convention', 'keep', 'Procedural statement; not re-verified by PH.'),
 ('C12', [11, 44, 91], 'certificates/publications/confirmations/location never migrate across incarnations', 'package Session.rebind', 'all rebinds', 'by_construction', 'keep',
  'Holds by code (rebind clears them). MigratingSession re-sign issues a NEW certificate after per-key support equality; wording: "authority objects never migrate; re-sign = new certificate".'),
 ('C13', [14, 15, 19], 'never cancel shared evidence (decision)', 'race+cancel data (98 scenarios)', 'decision rule', 'sampled', 'keep', 'Decision guidance backed by sampled evidence; not a theorem.'),
 ('C14', [16], 'domain switching only by provenance tag, never by numeric shape', 'D03 shape-guess counterexample', 'decision rule', 'existential', 'keep', 'Justified by a counterexample to shape guessing.'),
 ('C15', [17, 109], 'E03 structural impossibilities (WIDE endpoint => null rank, ...)', 'reference edge() definition; GENERATIVE_DOMAIN for lattice items', 'all inputs', 'by_construction', 'keep',
  'WIDE=>null follows from reference._Input.edge; lattice statements depend on the generative-domain document (premise).'),
 ('C16', [18], 'reuse normalised vectors, never ranks across directions', 'ranks directional (AB != BA)', 'decision', 'existential', 'keep', '-'),
 ('C17', [22, 61, 78], 'confirmation never carried on reissue', 'GSession reissue', 'all reissues', 'by_construction', 'keep', 'Code + test.'),
 ('C18', [23], 'H02 minimal revalidation set (no strictly smaller always-safe subset)', 'L2 argument', 'all write batches', 'proved_general', 'keep',
  'Minimality proof: for any k in S_h a write to k invalidates h.'),
 ('C19', [24, 137, 138], 'value cache safe iff producer contract (same identity+version => same content); authority never cached', 'producer contract', 'iff', 'proved_general', 'narrow',
  'Sufficiency proved; necessity is shown by the label-reuse counterexample (one direction existential). Wording: "safe if ...; unsafe in general without it".'),
 ('C20', [25, 26, 81, 82], 'I03 bypass never saves work; equals always_both at slow>=20', 'simulator, declared bounds', 'all configs', 'sampled', 'narrow',
  '"Never saves work" holds by construction (bypass only adds copies); the equalities at slow 5 / >=20 are measured grid points only.'),
 ('C21', [27, 28, 83, 141, 142], 'I04 split wins iff p<1 and rho_joint>=1.25', 'DES, 72 configs', 'iff', 'sampled', 'downgrade',
  'Work part (a+p*d < a+d iff p<1) is proved analytically. The latency "iff" is a fit to 72 grid configs; 1.25 is a grid point, not a derived threshold: "in all 72 measured configs split won exactly when p<1 and rho>=1.25 (tested values 0.75 / >=1.25)".'),
 ('C22', [29, 85], 'J06 global credit drained by an always-wrong hotspot', 'constructed adversary', 'existential', 'existential', 'keep', '-'),
 ('C23', [31], 'L06 instrument off => outputs identical', '4 configs', 'sampled', 'sampled', 'keep', 'Sampled; candidate refuted anyway.'),
 ('C24', [32], 'never drop censored samples', '-', '-', 'convention', 'keep', 'Method rule.'),
 ('C25', [34, 89], 'N06 triangle: exact + local + insertion-stable impossible', 'reference rule; one 64-chain', 'claimed general', 'sampled', 'narrow',
  'Replaced by Theorem N06-PH (proved_family): for EVERY R, P_n with n=R+6 and one rank edit changes a unit at distance >= n-5 > R, so no exact rule has a constant influence radius. Front insertion relabels n-1 of n old items on P_n (all n). Append (online) stability HOLDS with delay 3 (window lemma; 1500 random cases 0 violations). Mirror/order independence fails (169/500 random cases), but an exact rule must reproduce the reference, so it is not order-independent either. The triangle is therefore over-determined: exactness alone already excludes fixed radius and front-insertion stability.'),
 ('C26', [35, 112, 113], 'advice (P06) never touches answers', 'every selectable structure exact', 'all inputs', 'by_construction', 'keep', 'Follows from selecting among exact structures (tested).'),
 ('C27', [36, 37, 38, 40, 41, 42, 121], 'persistence branch never default', '-', '-', 'convention', 'keep', 'Policy statement.'),
 ('C28', [39, 75], 'Q03 cross-owner migration sound iff support and identity re-validate', 'L1-style commit check', 'iff', 'proved_general', 'narrow',
  'Sufficiency proved; necessity in general (an unvalidated migration can be wrong) by existence of a support-changing rebind. "iff" -> "if; and not without".'),
 ('C29', [43, 103, 104], 'empty completion set => never certified', 'certify_exact / BlockSummary code', 'all inputs', 'by_construction', 'keep', 'Code-level guarantee (contradiction / ambiguous).'),
 ('C30', [45, 50, 59, 115], 'SkiKeep never demotes; beats hybrid under alternation', 'X06 traces', 'design + sampled', 'sampled', 'keep', '"never demotes" is by construction; superiority is per measured trace (already scoped).'),
 ('C31', [46], 'X12: staged+progressive best when p<=0.5; progressive alone when rank always needed', 'uncalibrated u cost model, synthetic witnesses', 'model', 'sampled', 'narrow', 'Model statement under assumed open/element costs; not measured.'),
 ('C32', [47, 145], 'X23: 1-step reservation never binds (I=0)', 'simulator', 'measured configs', 'sampled', 'narrow', '"did not bind in the measured simulator configs".'),
 ('C33', [48, 86], 'caching transient failure as permanent never completes', 'permanent negative cache', 'all traces with a transient failure on the path', 'by_construction', 'keep', '-'),
 ('C34', [49], 'NH04: wins iff q_u<service_u, gain = wins*(service_u-q_u) exactly', 'shadow, independent lane', 'iff / exact', 'sampled', 'downgrade',
  'From Lemma S1 a proof can only win if it finishes before the incumbent publication, so q_u < remaining wait is necessary. The "iff q_u<service_u" and the gain formula are consistent on 28/28 grid cells x 48 traces (development data), not proved; the gain depends on how many service rounds a win removes.'),
 ('C35', [53], 'incumbent L0 path always running under gated_shadow', 'ShadowRunner code', 'all traces', 'by_construction', 'keep', '-'),
 ('C36', [54, 55, 56, 57], 'adoption-matrix "always" reversal/worst-case entries for dropped candidates', 'tuning/heldout2 traces', 'always', 'sampled', 'narrow', 'Read "on the measured traces" (race cancel, adaptive, budget doubling, portfolio).'),
 ('C37', [58], 'bitset domain never pays on G0', 'trial bench', 'never', 'sampled', 'narrow', '"3.7x slower on the measured G0 cases".'),
 ('C38', [62], 'long-lived views always stale after writes', 'OwnerView revision check', 'all writes', 'by_construction', 'keep', '-'),
 ('C39', [64], 'all requesters always wrong => 3 wasted specs each', 'credit 3/requester', 'by construction', 'by_construction', 'keep', '-'),
 ('C40', [67, 97, 102], 'package controller never re-issues a refused acquisition (cap 1)', 'package Controller code', 'existential trace', 'existential', 'keep', '-'),
 ('C41', [68, 72], 'edge/order boundary components never observed necessary (n<=8)', 'n<=8 samples', 'scoped', 'sampled', 'keep', 'Already scoped; not evidence of non-necessity in general.'),
 ('C42', [69, 110], 'Theorem X-10: masks never change a single later_wins feasibility', 'null and 0 realisable on every unknown edge', 'all inputs', 'proved_general', 'keep', 'Proof given; premise must be checked (masks_consistent).'),
 ('C43', [71], 'X02 lazy never worse than eager', '3 scenarios', 'never', 'sampled', 'narrow', '"equal or better on the 3 measured scenarios".'),
 ('C44', [74, 114], 'hybrid never the best fixed choice', 'measured mixes', 'never', 'sampled', 'narrow', 'Per measured mix.'),
 ('C45', [79, 135, 136], 'bound confirm never rejects the current handle', 'confirm(target, handle) code', 'all calls', 'by_construction', 'keep', 'Interface change handled by LC fork.'),
 ('C46', [80, 140], 'I02 dynamic borrowing iff declared bound <= B keeps required <= fixed + B', 'honest declared bounds', 'iff', 'proved_general', 'narrow', 'Sufficiency proved (L6) for honest bounds; "iff" -> "if".'),
 ('C47', [84], 'J01 never speculates on jumps', 'accuracy gate, measured patterns', 'measured', 'sampled', 'narrow', '"did not speculate on the measured jump pattern".'),
 ('C48', [87, 88], 'all S rules are legal partitions (804 inputs)', 'rule construction', 'all inputs', 'sampled', 'keep', 'Measured on 804 inputs; rules construct partitions by design.'),
 ('C49', [90], 'S02: reference/LMP/seg/anchor are maximal matchings => pairs >= 1/2 maximum', 'maximality', 'all inputs', 'sampled', 'narrow',
  'The 1/2 bound follows classically from maximality. Reference maximality: argued from the scan (a single at i with allowed(i) only via later_wins(i), which implies allowed(i+1) and pairs i+1) and checked on 3000 random cases with settings mix (0 non-maximal, PH s02_maximality.json). LMP/seg/anchor maximality only sampled.'),
 ('C50', [92], 'S05: 2 judgments separate all distinguishable rule pairs', '300 inputs, local-window preference assumption', 'scoped', 'sampled', 'keep', 'Already scoped "in sample".'),
 ('C51', [93], 'P6 is a necessary consequence of exact typed support', 'exact support contract', 'all certificates with unknown facts in support', 'by_construction', 'keep', '-'),
 ('C52', [96, 100, 101], 'Lemma G: gate necessary, zero missed proof wins', 'raw gate, nonneg tree', 'all states', 'sampled', 'narrow',
  'ANALYSIS part follows from the raw gate (no strong certificate without computed analyses in [0,t+3]); the DIMENSIONS-need part is argued informally; missed=0 measured on tuning/heldout/heldout2 only.'),
 ('C53', [98, 99], 'Lemma S1 (shadow): identical physical schedule; latency <= incumbent; publications superset', 'independent proof lane; S side-effect free on evidence/raw/tasks; single owner', 'every trace', 'proved_general', 'keep',
  'Induction proof holds under premises; the budget fix does not touch evidence/raw/task state (fix_budget differential: 980 A cells identical).'),
 ('C54', [105, 106], 'Lemma B-1 / D02 representatives: K=10/50 never certified beyond symbolic', 'window lemma', 'B-1 all inputs; D02 statement sampled', 'proved_general', 'keep', 'B-1 proved; the K=10/50 remark is sampled (scoped by itself).'),
 ('C55', [107, 108], 'D02 binary64 order-type completeness (iff m representatives per gap)', 'proof sketch', 'all inputs', 'proved_general', 'keep', 'Proof sketch + 250 dense cases; not re-proved by PH.'),
 ('C56', [117], 'C05 merged application never exposes v1', 'merge legality rule', 'by construction', 'by_construction', 'keep', '-'),
 ('C57', [118], 'O02-L: every front flip changes Theta(n) cover units (measured n=1024)', 'decreasing chain', 'all n (implied)', 'sampled', 'narrow',
  'Now proved for every n on P_n by Lemma P (all positions 1..n-3 change), so the Omega(n) diff-output lower bound holds on that family for all n.'),
 ('C58', [119, 120], 'O03 precompile never pays on indexed plans; E06 prefix never reads more than separate', 'cost argument', 'by construction', 'by_construction', 'keep', '-'),
 ('C59', [122, 123, 124, 125, 126, 127], 'L-G1 / L-G2 projection lemmas', 'frozen compact_core read structure', 'all states', 'proved_general', 'keep', '-'),
 ('C60', [128, 131, 132], 'exact support for certificates; dead-raw eviction safe; GC never stale success', 'definitions', 'all', 'proved_general', 'keep', 'GC liveness under ABA differs (stated honestly in R9).'),
 ('C61', [133, 134, 139], 'H01 commit-check acceptance iff guard/epoch/support equal; per-target commit iff no write hits S_j', 'definition of acceptance', 'all', 'by_construction', 'keep', '-'),
 ('C62', [143], 'J04 global window never quiet when unrelated period < w', 'definition', 'all', 'by_construction', 'keep', '-'),
 ('C63', [144], 'L9 saturation/incarnation invariant', 'monotone saturating counter', 'all traces', 'proved_general', 'keep', 'Induction proof; exhaustive small widths.'),
 ('C64', [10, 13, 20, 21, 63, 116], 'question text / route labels / implementation notes (not claims)', '-', '-', 'convention', 'keep', 'Marker hits that are not claims.'),
 ('C65', [], 'REPORT 1: derive_first / bound_confirm / inc_revoke "fully equivalent, adopt immediately"', '-', '-', 'sampled', 'downgrade',
  'Out of PH scope: re-classified by fork LC (model correction / interface hardening / separately verified optimisation).'),
 ('C66', [], 'REPORT 4: gated_shadow "0 scenarios worse"', 'Lemma S1 premises', 'every trace', 'proved_general', 'keep', 'Follows from S1 (not only from 98 scenarios); "gain only when q_u<service_u (28/28)" is sampled -> see C34.'),
 ('C67', [], 'REPORT 4/5: "12 D4 mechanisms", "D3 >= 30"', '-', '-', 'sampled', 'downgrade', 'Re-audited per mechanism by LC/main (fix round items 3-4).'),
]
covered = set()
rows = []
for cid, hits, claim, prem, quant, scope, verdict, note in A:
    covered.update(hits)
    locs = sorted({f"{G[h]['file']}:{G[h]['line']}" for h in hits})
    rows.append(dict(claim_id=cid, claim=claim, sources=' ; '.join(locs), premises=prem, quantifier=quant,
                     proof_scope=scope, verdict=verdict, revised_wording_or_note=note))
uncovered = [i for i in range(len(G)) if i not in covered]
(OUT / 'results/summary/fix/PH').mkdir(parents=True, exist_ok=True)
with open(OUT / 'results/summary/fix/PH/claims_audit.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
cnt = collections.Counter(r['verdict'] for r in rows)
sc = collections.Counter(r['proof_scope'] for r in rows)
res = dict(distinct_claims=len(rows), grep_hits=len(G), hits_covered=len(covered), hits_uncovered=uncovered,
           verdicts=dict(cnt), scopes=dict(sc))
(OUT / 'results/summary/fix/PH/claims_audit_counts.json').write_text(json.dumps(res, indent=1))
print(res)
