"""Fix round (LC): lifecycle workloads for formal timing (main session only).

Family 'life': the common lifecycle workload of candidates/fixLC_costs.py (every distinct
target of a fixed trace driven to first legal publication + confirmation by the generic
Life controller, then the harness close protocol).  CANDIDATES[0] = package_session.
Family 'shadow': the scripted runner-level lifecycle of candidates/fixLC_shadow.py
(variant 'touched', rebind of item 31, bound confirmation); [0] = incumbent runner.
run_one returns wall_ns of the whole lifecycle (build .. close), a verdict hash of the
first publications, ok = every target published truthfully AND everything released.
"""
import hashlib, json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import fixLC_groups as G
from fixLC_lifecycle import Life
from current_baseline import typed

LIFE_CANDS = ['package_session', 'fresh_strong', 'persistent_tree', 'block_session', 'gated_index_I',
              'gated_index_SEL', 'derive_first', 'proj_support', 'reissue_eager', 'reissue_lazy', 'migrate_resign',
              'inc_revoke', 'bound_confirm', 'value_cache', 'reserve1']
SHADOW_CANDS = ['incumbent_runner', 'gated_shadow_r9', 'gated_shadow_fixed', 'persistent_gated_shadow_fixed']
CANDIDATES = LIFE_CANDS
SCENARIOS = [dict(name='life_' + n, fam='life', trace=n) for n, _ in G.LV_TRACES] + \
            [dict(name='shadow_script_touched_rb31', fam='shadow')]


def FAMILY_CANDIDATES(sc):
    return LIFE_CANDS if sc['fam'] == 'life' else SHADOW_CANDS


def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


def run_one(sc, cand, rep=0):
    if sc['fam'] == 'shadow':
        import fixLC_shadow as S
        kw = dict(incumbent_runner=dict(policy='incumbent', incumbent_drive=True),
                  gated_shadow_r9=dict(policy='gated_shadow'),
                  gated_shadow_fixed=dict(policy='gated_shadow', fixed=True),
                  persistent_gated_shadow_fixed=dict(policy='gated_shadow', fixed=True, persistent=True))[cand]
        t0 = time.perf_counter_ns()
        r, rows = S.run_shadow(variant='touched', bound=True, rebind_item=31, **kw)
        wall = time.perf_counter_ns() - t0
        chk = S.evaluate(r, rows, 'touched')
        failed = sorted(c['group'] + ':' + c['name'] for c in chk if not c['ok'])
        return dict(wall_ns=wall, verdict_sha256=_sha(sorted(r.first_pub.items())), ok=r.wrong == 0,
                    work=dict(failed_checks=len(failed), proof_wins=r.c.get('proof_wins', 0),
                              admissions=r.session.metrics['physical_admissions'], events=len(rows)),
                    failed_checks=failed)
    tr = dict(G.LV_TRACES)[sc['trace']]()
    targets = []
    for ev in tr['events']:
        if ev['op'] == 'target' and ev['target'] not in targets:
            targets.append(ev['target'])
    t0 = time.perf_counter_ns()
    life = Life(G.spec(cand), tr)
    pubs, ok = [], True
    for t in targets:
        p, v = life.drive(t, limit=300, confirm=True)
        ok &= bool(p and typed(v['unit']) == typed(life.truth[t]))
        pubs.append((t, typed(v['unit']) if p else None))
    while life.due:
        life.advance()
    life.close()
    wall = time.perf_counter_ns() - t0
    s = life.s
    released = s.occupied == 0 and s.raw_size == 0 and s.certificate_count == 0 and life.residency() in (0, None)
    m = s.metrics
    return dict(wall_ns=wall, verdict_sha256=_sha(pubs), ok=ok and released,
                work=dict(admissions=m['physical_admissions'], certification_steps=m['certification_steps'],
                          strong_evaluations=m['strong_evaluations'], publication_read_checks=m['publication_read_checks'],
                          events=len(life.rows), released=released))


if __name__ == '__main__':
    for sc in SCENARIOS:
        for c in FAMILY_CANDIDATES(sc)[:2]:
            r = run_one(sc, c)
            print(sc['name'], c, r['ok'], r['work'])
