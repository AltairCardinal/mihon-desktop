"""Summarise results/raw/fix/LC/*.json -> results/summary/fix/LC/{d4_verdicts.json, observe.json, costs.json, TABLES.md}."""
import collections, glob, json
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
RAW = OUT / 'results/raw/fix/LC'
SUM = OUT / 'results/summary/fix/LC'
SUM.mkdir(parents=True, exist_ok=True)

ses = json.load(open(RAW / 'groups_session.json'))['rows']
sh = json.load(open(RAW / 'groups_shadow.json'))
mut = json.load(open(RAW / 'mutants.json'))
costs = json.load(open(RAW / 'costs.json'))
blockfix = json.load(open(RAW / 'block_residual_fix.json'))

# ---- session-level verdicts
per = collections.defaultdict(lambda: dict(groups=0, failed=[]))
for r in ses:
    k = (r['mechanism'], r['bound'])
    per[k]['groups'] += 1
    if not r['ok']:
        per[k]['failed'].append('%s:%s' % (r['group'], ','.join(r['failed'])))
    if r['group'] == 'E5_close':
        per[k]['memory'] = r.get('memory')
        per[k]['final_after_close'] = r.get('final')
    if r['group'].startswith('LV_liveness'):
        per[k].setdefault('liveness', []).append(dict(group=r['group'], traces=r.get('traces')))
    if r['group'] == 'E4_rebind_differential':
        per[k]['rebind_differential'] = dict(calls=r.get('calls'), mismatches=r.get('mismatches'))
session = [dict(mechanism=m, bound=b, **v) for (m, b), v in sorted(per.items())]

# ---- runner-level verdicts
shp = collections.defaultdict(lambda: dict(runs=0, failed=collections.Counter(), wrong=0))
for r in sh:
    k = (r['config'], r['bound'])
    shp[k]['runs'] += 1
    shp[k]['wrong'] += r['wrong']
    for f in r['failed']:
        shp[k]['failed'][f] += 1
runner = [dict(config=c, bound=b, runs=v['runs'], wrong=v['wrong'], failed=dict(v['failed'])) for (c, b), v in sorted(shp.items())]

d4 = dict(session=session, runner=runner, mutants=[dict(mutant=m['mutant'], caught=not m['ok'], failed=m['failed']) for m in mut],
          block_residual_proposed_fix=[dict(group=r['group'], ok=r['ok']) for r in blockfix],
          naive_close=json.load(open(RAW / 'naive_close.json')))
(SUM / 'd4_verdicts.json').write_text(json.dumps(d4, indent=1, default=str))

# ---- observations
obs = []
for f in sorted(glob.glob(str(RAW / 'observe_*_s*.json'))):
    r = json.load(open(f))
    obs.append(dict(pair=r['pair'], focus=r['focus'], traces=r['traces'], events=r['events'],
                    traces_with_difference=r['traces_with_difference'], differences=r['differences'],
                    return_pairs=r.get('return_pairs', {}), coverage=r.get('coverage', {}),
                    cost_counter_differences_traces=r['cost_counter_differences_traces'], file=Path(f).name))
byrc = json.load(open(RAW / 'observe_derive_first_by_rc.json'))
obs_rc = [dict(raw_capacity=r['raw_capacity'], focus=r['focus'], traces=r['traces'],
               traces_with_difference=r['traces_with_difference'], differences=r['differences']) for r in byrc]
(SUM / 'observe.json').write_text(json.dumps(dict(pairs=obs, derive_first_by_rc=obs_rc), indent=1))

# ---- costs
crow = []
for r in costs:
    rows = r['rows']
    crow.append(dict(mechanism=r['mechanism'], raw_capacity=r['raw_capacity'],
                     all_published_truthful=all(x['all_published_truthful'] for x in rows),
                     residency_peak=[x['residency_peak'] for x in rows], residency_after_close=[x['residency_after_close'] for x in rows],
                     traced_peak_max=max(x['traced_peak'] for x in rows),
                     retained_after_close_max=max(x['retained_after_close'] for x in rows),
                     positive_delta_sum_total=sum(x['positive_delta_sum'] for x in rows),
                     admissions=sum(x['admissions'] for x in rows), certification_steps=sum(x['certification_steps'] for x in rows),
                     strong_evaluations=sum(x['strong_evaluations'] for x in rows),
                     publication_read_checks=sum(x['publication_read_checks'] for x in rows),
                     wall_ms_exploratory=round(sum(x['wall_ns_exploratory'] for x in rows) / 1e6, 1)))
(SUM / 'costs.json').write_text(json.dumps(crow, indent=1))

# ---- markdown tables
L = ['# LC 汇总表（bench/summarize_fixLC.py 生成）', '', '## 会话层生命周期（每机制 E1–E6 + 两种 rebind + 随机 rebind 差分 + 活性）', '',
     '| 机制 | 确认 | 组数 | 失败组 | 关闭后可达字节 | rebind 差分 调用/不一致 |', '|---|---|---|---|---|---|']
for s in session:
    mem = s.get('memory') or {}
    rd = s.get('rebind_differential') or {}
    L.append('| %s | %s | %d | %s | %s | %s/%s |' % (s['mechanism'], 'bound' if s['bound'] else '包 confirm', s['groups'],
             '; '.join(s['failed']) or '—', mem.get('reachable_after_close_bytes'), rd.get('calls'), rd.get('mismatches')))
L += ['', '## 运行器层（ShadowRunner 脚本生命周期，每配置 4 个脚本变体：E2 touched/untouched × rebind 第 13 项/第 31 项）', '',
      '| 配置 | 确认 | 运行 | 错误发布 | 失败检查（次数） |', '|---|---|---|---|---|']
for r in runner:
    L.append('| %s | %s | %d | %d | %s |' % (r['config'], 'bound' if r['bound'] else '包 confirm', r['runs'], r['wrong'],
             '; '.join('%s×%d' % kv for kv in sorted(r['failed'].items())) or '—'))
L += ['', '## 变异体', '', '| 变异体 | 被捕获 | 失败检查 |', '|---|---|---|']
for m in d4['mutants']:
    L.append('| %s | %s | %s |' % (m['mutant'], m['caught'], ', '.join(m['failed'])))
L += ['', '## 公开观察差分', '', '| 对 | 流 | 轨迹 | 事件 | 有差异轨迹 | 差异（类别:次数） |', '|---|---|---|---|---|---|']
for o in obs:
    L.append('| %s | %s | %d | %d | %d | %s |' % (o['pair'], o['focus'], o['traces'], o['events'], o['traces_with_difference'],
             '; '.join('%s:%d' % kv for kv in o['differences'].items()) or '无'))
L += ['', 'derive_first 按 raw 容量：', '']
for o in obs_rc:
    L.append('- rc=%s %s：%d/%d 条轨迹有差异，%s' % (o['raw_capacity'], o['focus'], o['traces_with_difference'], o['traces'],
             '; '.join('%s:%d' % kv for kv in o['differences'].items())))
L += ['', '## 公共工作负载上的成本（W01 s0、W05 s2、RP s0 全部目标 + 关闭；层见 candidates/fixLC_costs.py）', '',
      '| 机制 | rc | 全部真值发布 | 结构条目峰值 | 关闭后条目 | tracemalloc 峰值 B | 关闭后保留 B | 正增量和 B（累计分配下界） | 获取 | 认证步 | 强评估 | 发布读校验 | 墙钟 ms（分支内探索性） |',
      '|---|---|---|---|---|---|---|---|---|---|---|---|---|']
for c in crow:
    L.append('| %s | %d | %s | %s | %s | %d | %d | %d | %d | %d | %d | %d | %s |' % (
        c['mechanism'], c['raw_capacity'], c['all_published_truthful'], c['residency_peak'], c['residency_after_close'],
        c['traced_peak_max'], c['retained_after_close_max'], c['positive_delta_sum_total'], c['admissions'],
        c['certification_steps'], c['strong_evaluations'], c['publication_read_checks'], c['wall_ms_exploratory']))
(SUM / 'TABLES.md').write_text('\n'.join(L) + '\n')
print('\n'.join(L))
