"""A04 coupled comparison FL vs FP on the R9 adoption traces (tuning + heldout2) x grid.
Raw: results/raw/fix/Q1/a04_coupled.json"""
import json, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import fixQ1_a04 as Q, wpA_lib as A
rows = []
traces = A.tuning_traces() + A.heldout2_traces()
for su in (2, 4, 8):
    for q in (1, 3):
        rows += Q.compare_runners(traces, su, q)
agg = {}
for name in ('incumbent', 'FL', 'FP'):
    agg[name] = {k: sum(r[name][k] for r in rows) for k in ('total_latency_u', 'physical_admissions', 'wrong', 'published',
                                                             'intents', 'proof_wins', 'staged', 'barrier_stale')}
    agg[name]['livelocks'] = sum(r[name]['livelock'] for r in rows)
cells = len(rows)
cmp_ = dict(FP_worse_than_FL=sum(r['FP']['total_latency_u'] > r['FL']['total_latency_u'] for r in rows),
            FP_better_than_FL=sum(r['FP']['total_latency_u'] < r['FL']['total_latency_u'] for r in rows),
            FP_worse_than_incumbent=sum(r['FP']['total_latency_u'] > r['incumbent']['total_latency_u'] for r in rows),
            FL_worse_than_incumbent=sum(r['FL']['total_latency_u'] > r['incumbent']['total_latency_u'] for r in rows))
out = dict(cells=cells, aggregate=agg, comparison=cmp_, rows=rows,
           note='traces: wpA tuning_traces (16) + heldout2_traces (16; already seen in R9 -> development evidence); su in {2,4,8}, q in {1,3}, capacity 3')
(OUT / 'results/raw/fix/Q1/a04_coupled.json').write_text(json.dumps(out, indent=1))
print(json.dumps(dict(cells=cells, aggregate=agg, comparison=cmp_), indent=1))
