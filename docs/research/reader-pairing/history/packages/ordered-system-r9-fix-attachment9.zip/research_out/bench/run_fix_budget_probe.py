"""Per-route budget probe (fix round). Usage: run_fix_budget_probe.py <label>
Writes results/raw/fix/budget_probe_<label>.json: for every strong route and
budget in {0, 1, None}: whether a strong certificate was issued and how many
evaluations were charged."""
import json, sys
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'tests')); sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
import test_budget_contract as TB

rows = []
for route in TB.ROUTES:
    for b in (0, 1, None):
        s, (v,), (n,) = TB.run(route, [b])
        rows.append(dict(route=route, budget=b, strong_certificate_issued=TB.strong_issued(v),
                         verdict_route=v.get('route'), charged_evaluations=n,
                         verdict_steps=v.get('steps'), strong_stops=s.metrics['strong_stops']))
label = sys.argv[1]
(OUT / 'results/raw/fix').mkdir(parents=True, exist_ok=True)
(OUT / f'results/raw/fix/budget_probe_{label}.json').write_text(json.dumps(rows, indent=1))
for r in rows: print(r)
