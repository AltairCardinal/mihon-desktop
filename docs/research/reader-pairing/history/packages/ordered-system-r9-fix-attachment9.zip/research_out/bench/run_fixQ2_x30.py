"""X30 0/A/B/A+B on common coupled traces (one migrate event per trace), two
migration organisations, migration-time sensitivity, adjudication counts and an
evaluator-only T05 oracle reference -> results/raw/fix/Q2/x30.json"""
import collections, json, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates')); import paths  # noqa
import workloads as W, wpA_lib as A, fixQ2_x30 as X, wpT_bounds as TB

GROUPS = list(X.GROUPS)


def traces():
    out = [('A_tuning', tr) for tr in A.tuning_traces()]
    for s in range(3):
        out.append(('W01', W.w01_phase_chain(s, n=48, count=24, holes=4)))
        out.append(('RP', W.random_partial(s, n=48, count=24)))
        out.append(('W05', W.w05_raw_eviction(s, n=48, holes=6, count=24)))
        out.append(('W06', W.w06_complete_analysis_ambiguous(s, n=16, count=16)))
    return out


def horizon(tr):
    return max(e['at'] for e in tr['events'])


def interaction(g, a, b, ab):
    return {k: ab[k] - a[k] - b[k] + g[k] for k in ab if isinstance(ab[k], (int, float)) and not isinstance(ab[k], bool)}


def main():
    t0 = time.time()
    rows = []
    for fam, tr in traces():
        adj = X.adjudications(tr)
        for frac in (0.25, 0.5, 0.75):
            M = int(horizon(tr) * frac)
            trm = X.with_migration(tr, M)
            for g in GROUPS:
                r = X.run_group(trm, g)
                r.update(adjudication_motif_classes=adj['motif_classes'] if g not in ('0', 'A') else 0,
                         l2_differing_items=adj['differing_items'] if g not in ('0', 'A') else 0)
                rows.append(dict(family=fam, trace=tr['name'], M_frac=frac, group=g, **r))
    agg = collections.defaultdict(collections.Counter)
    for r in rows:
        for k, v in r.items():
            if isinstance(v, (int, float)) and not isinstance(v, bool) and k != 'M_frac':
                agg[(r['family'], r['M_frac'], r['group'])][k] += v
                agg[('ALL', r['M_frac'], r['group'])][k] += v
    summary = {}
    for fam in ('A_tuning', 'W01', 'RP', 'W05', 'W06', 'ALL'):
        for frac in (0.25, 0.5, 0.75):
            g = {x: dict(agg[(fam, frac, x)]) for x in GROUPS}
            summary[f'{fam}|M{frac}'] = dict(groups=g,
                                             interaction_switch=interaction(g['0'], g['A'], g['B_switch'], g['AB_switch']),
                                             interaction_perunit=interaction(g['0'], g['A'], g['B_perunit'], g['AB_perunit']))
    # T05 evaluator-only reference (reads the hidden world; never a candidate), small traces only
    oracle = []
    for fam, tr in traces():
        if len(tr['initial']['items']) > 24:
            continue
        r = TB.OracleRunner(tr, service_u=4, max_set=2).run()
        oracle.append(dict(family=fam, trace=tr['name'], physical_admissions=r['physical_admissions'],
                           total_latency_u=r['total_latency_u'], published=r['published'], intents=r['intents']))
    res = dict(seconds=round(time.time() - t0, 1), groups=GROUPS, summary=summary, rows=rows, t05_oracle_reference=oracle,
               note='u = virtual service units (service_u=4, q_u=1); adjudications are COUNTS of distinct local '
                    'disagreement motif classes (no quality truth); oracle rows read the hidden world (evaluator only, '
                    'coupled_runner policy loop, no migration) and are never part of an interaction term')
    (OUT / 'results/raw/fix/Q2/x30.json').write_text(json.dumps(res, indent=1))
    keys = ('physical_admissions', 'total_latency_u', 'wrong', 'certification_steps', 'strong_evaluations', 'revoked',
            'resigned', 'visible_changes', 'republished', 'republish_latency_u', 'pending_republish', 'proof_wins',
            'adjudication_motif_classes')
    for k, v in summary.items():
        if not k.startswith('ALL'):
            continue
        print(k)
        for g, m in v['groups'].items():
            print('  %-10s' % g, [m.get(x, 0) for x in keys])
        print('  I_switch  ', [v['interaction_switch'].get(x, 0) for x in keys])
        print('  I_perunit ', [v['interaction_perunit'].get(x, 0) for x in keys])
    print('oracle', [(o['family'], o['physical_admissions'], o['total_latency_u']) for o in oracle][:10])
    print('seconds', res['seconds'])


if __name__ == '__main__':
    main()
