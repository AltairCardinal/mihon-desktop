"""Fix round Q2 bench module (drive_formal.py interface; formal timing is run by the main session only).

Families (FAMILY_CANDIDATES(sc)[0] = incumbent):
  t04_*   route1 (re-derivation checker, DP [+ worlds n<=7])  vs route2 (proof-carrying certificate checker);
          one run = check every honest certificate of the scenario's corpus (certificates issued once at
          import, issuance not timed).
  x05_*   '0' fresh flat support vs 'A', 'B', 'AB1', 'AB2' on one prepared common stream
          (preparation = ground truth + change detection, shared and not timed).
  x30_*   '0' incumbent vs 'A', 'B_switch', 'B_perunit', 'AB_switch', 'AB_perunit' on one trace with
          a migrate event at half the horizon.
"""
import hashlib
import json
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import omega as O  # noqa: E402
import workloads as W  # noqa: E402
import fixQ2_pcc as P  # noqa: E402
import fixQ2_pcc_checker as C  # noqa: E402
import fixQ2_x05 as X5  # noqa: E402
import fixQ2_x30 as X3  # noqa: E402
from common import random_case, roundtrip  # noqa: E402

SCENARIOS = []
for src in ('small', 'W05', 'RP', 'W02'):
    SCENARIOS.append(dict(name=f't04_{src}', fam='t04', src=src))
for fam in ('W01', 'RP', 'W05'):
    for pattern in ('hot', 'jump'):
        SCENARIOS.append(dict(name=f'x05_{fam}_{pattern}', fam='x05', wfam=fam, pattern=pattern, seed=0))
for fam in ('W01', 'RP', 'W05'):
    SCENARIOS.append(dict(name=f'x30_{fam}', fam='x30', wfam=fam, seed=0))

CANDIDATES = ['route1', 'route2']
_FAM = {'t04': ['route1', 'route2'], 'x05': ['0', 'A', 'B', 'AB1', 'AB2'],
        'x30': ['0', 'A', 'B_switch', 'B_perunit', 'AB_switch', 'AB_perunit']}
_CACHE = {}


def FAMILY_CANDIDATES(sc):
    return _FAM[sc['fam']]


def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


def _t04_corpus(src):
    if src in _CACHE:
        return _CACHE[src]
    cases = []
    if src == 'small':
        rng = random.Random(404)
        for _ in range(15):
            n = rng.randrange(3, 6)
            cases.append(roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.4, domain='nonneg')))
    else:
        cases = [W.FAMILIES[src](s)['initial'] for s in range(2)]
    certs = []
    for c in cases:
        for t in range(len(c['items'])):
            cert, _ = P.issue(c, t)
            if cert is not None:
                certs.append((c, cert))
    _CACHE[src] = certs
    return certs


def _x05(sc):
    key = ('x05', sc['wfam'], sc['pattern'], sc['seed'])
    if key not in _CACHE:
        st = X5.stream(sc['wfam'], sc['seed'], pattern=sc['pattern'])
        _CACHE[key] = (st, X5.prepare(st))
    return _CACHE[key]


def _x30(sc):
    key = ('x30', sc['wfam'], sc['seed'])
    if key not in _CACHE:
        gen = dict(W01=lambda s: W.w01_phase_chain(s, n=48, count=24, holes=4),
                   RP=lambda s: W.random_partial(s, n=48, count=24),
                   W05=lambda s: W.w05_raw_eviction(s, n=48, holes=6, count=24))[sc['wfam']]
        tr = gen(sc['seed'])
        _CACHE[key] = X3.with_migration(tr, max(e['at'] for e in tr['events']) // 2)
    return _CACHE[key]


def run_one(sc, cand, rep=0):
    if sc['fam'] == 't04':
        certs = _t04_corpus(sc['src'])
        t0 = time.perf_counter_ns()
        oks = [C.check(c, cert)[0] if cand == 'route2' else P.route1_check(c, cert)[0] for c, cert in certs]
        wall = time.perf_counter_ns() - t0
        return dict(wall_ns=wall, verdict_sha256=_sha(oks), ok=all(oks), work=dict(certificates=len(certs), accepted=sum(oks)))
    if sc['fam'] == 'x05':
        st, prep = _x05(sc)
        t0 = time.perf_counter_ns()
        r = X5.run(st, cand, prep)
        wall = time.perf_counter_ns() - t0
        ok = r['stale_reuses'] == 0 and r['wrong_fresh'] == 0
        return dict(wall_ns=wall, verdict_sha256=_sha([r['answered'], r['ambiguous']]), ok=ok,
                    work={k: r.get(k, 0) for k in X5.METRICS})
    tr = _x30(sc)
    t0 = time.perf_counter_ns()
    r = X3.run_group(tr, cand)
    wall = time.perf_counter_ns() - t0
    ok = r['wrong'] == 0 and r['published'] == r['intents'] and not r['livelock']
    return dict(wall_ns=wall, verdict_sha256=_sha([r['published'], r['intents'], r['wrong']]), ok=ok, work=r)


if __name__ == '__main__':                     # smoke only (one rep per cell), NOT formal timing
    for sc in SCENARIOS:
        for c in FAMILY_CANDIDATES(sc):
            r = run_one(sc, c)
            print(sc['name'], c, r['ok'], round(r['wall_ns'] / 1e6, 1), 'ms')
