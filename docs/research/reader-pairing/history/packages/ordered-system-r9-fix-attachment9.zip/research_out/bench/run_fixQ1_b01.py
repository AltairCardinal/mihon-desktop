"""B01 studies (table vs ZDD).  Usage: run_fixQ1_b01.py exact|small|ablation|blowup
Raw: results/raw/fix/Q1/b01_<part>.json"""
import copy, itertools, json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
from common import random_case, roundtrip, base_case, fact
import fixQ1_b01 as B, omega as O, transducer as T
import workloads as W
R = OUT / 'results/raw/fix/Q1'
part = sys.argv[1]


def same(a, b):
    return (a[0] == 'certified') == (b[0] == 'certified') and (a[0] != 'certified' or a[1] == b[1])


if part == 'exact':
    rng = random.Random(101); tot = bad_t = bad_z = 0; rows = []
    for k in range(150):
        n = rng.randrange(1, 24)
        c = roundtrip(random_case(rng, n, p_unknown=rng.choice((0.1, 0.3, 0.5)), p_edge_unknown=rng.choice((0.2, 0.5)),
                                  p_fail=0.03))
        alpha = rng.random() < .5
        blk = rng.choice((1, 2, 3, 4, 8))
        bs = B.WB.BlockSummary(copy.deepcopy(c), 'ext', alpha, block=blk)
        zs = B.ZDDSummary(copy.deepcopy(c), 'ext', alpha, block=blk)
        for t in range(n):
            e = O.certify_exact(c, t, 'ext', alpha)
            tot += 1
            bad_t += not same(e, bs.certify(t)); bad_z += not same(e, zs.certify(t))
    out = dict(cases=150, checks=tot, table_mismatch=bad_t, zdd_mismatch=bad_z, seed=101)
elif part == 'small':
    # every partial case over a restricted alphabet: n=3 vs world oracle, n=4 vs exact DP
    A = [{'status': 'unknown'}, dict(status='computed', fact=fact('NARROW', 'A'), version=1),
         dict(status='computed', fact=fact('NARROW', 'B'), version=1),
         dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1), dict(status='computed', fact=fact('WIDE'), version=1)]
    E = [None, 1.0, 2.0]
    out = {}
    for n, oracle in ((3, 'world'), (4, 'exact')):
        cases = checks = bad = skipped = 0
        t0 = time.time()
        for items in itertools.product(range(len(A)), repeat=n):
            for edges in itertools.product(range(len(E)), repeat=n - 1):
                c = base_case(n)
                for i, a in enumerate(items):
                    c['items'][i]['analysis'] = copy.deepcopy(A[a])
                c['edges'] = [dict(first=j, second=j + 1, status='computed', score=E[e], version=1)
                              for j, e in enumerate(edges) if E[e] is not None]
                c = roundtrip(c)
                cases += 1
                zs = B.ZDDSummary(copy.deepcopy(c), 'ext', False, block=2)
                for t in range(n):
                    r = zs.certify(t)
                    if oracle == 'world':
                        try:
                            U = O.oracle_units(c, t, 'ext', False, cap=20000)
                        except OverflowError:
                            skipped += 1; continue
                        ok = (r[0] == 'certified') == (len(U) == 1) and (r[0] != 'certified' or set(U) == {T._key(r[1])})
                    else:
                        ok = same(O.certify_exact(c, t, 'ext', False), r)
                    checks += 1; bad += not ok
        out[f'n{n}'] = dict(oracle=oracle, cases=cases, checks=checks, mismatches=bad, skipped=skipped,
                            seconds=round(time.time() - t0, 1))
elif part == 'ablation':
    profiles = dict(mixed=dict(p_unknown=0.35, p_edge_unknown=0.45),
                    rank_heavy=dict(p_unknown=0.05, p_edge_unknown=0.85, p_wide=0.0),
                    side_heavy=dict(p_unknown=0.6, p_edge_unknown=0.2))
    rng = random.Random(202); rows = {c: {pr: 0 for pr in profiles} for c in B.CLASSES}; checks = 0
    examples = {}
    t0 = time.time()
    for k in range(3000):
        prof = list(profiles)[k % 3]
        n = rng.randrange(4, 15)
        c = roundtrip(random_case(rng, n, **profiles[prof]))
        t = rng.randrange(n)
        e = O.certify_exact(c, t, 'ext', False)
        ref_units = set(e[1]) if e[0] == 'ambiguous' else ({T._key(e[1])} if e[0] == 'certified' else set())
        checks += 1
        for cls in B.CLASSES:
            got = B.certify_ablated(c, t, cls, block=1)
            if got != ref_units:
                rows[cls][prof] += 1
                if cls not in examples or len(json.dumps(c)) < len(json.dumps(examples[cls]['case'])):
                    examples[cls] = dict(case=c, target=t, exact=sorted(map(repr, ref_units)), ablated=sorted(map(repr, got)))
    out = dict(cases=checks, seed=202, block=1, changed_by_profile=rows, smallest_examples=examples,
               seconds=round(time.time() - t0, 1),
               note='changed = target unit set differs from exact DP when the class is forgotten at every boundary')
elif part == 'blowup':
    rows = []
    rng = random.Random(303)
    grid = [(n, pu, pe, blk) for n in (32, 64, 128) for pu in (0.2, 0.5) for pe in (0.3, 0.7) for blk in (4, 8, 16)]
    for (n, pu, pe, blk) in grid:
        c = roundtrip(random_case(rng, n, p_unknown=pu, p_edge_unknown=pe, settings_mix=False))
        t0 = time.time()
        m, r1, r2 = B.run_both(c, blk, targets=range(0, n, max(1, n // 16)))
        rows.append(dict(family='random', n=n, pu=pu, pe=pe, block=blk, seconds=round(time.time() - t0, 2), **m))
    for fam, mk in (('W01', lambda s: W.w01_phase_chain(s, n=96, holes=6)), ('W06', lambda s: W.w06_complete_analysis_ambiguous(s, n=16)),
                    ('W02', lambda s: W.w02_islands(s, n=48))):
        for blk in (4, 8, 16):
            c = mk(0)['initial']
            n = len(c['items'])
            m, r1, r2 = B.run_both(c, blk, domain='nonneg')
            rows.append(dict(family=fam, n=n, block=blk, **m))
    out = dict(rows=rows, seed=303)
(R / f'b01_{part}.json').write_text(json.dumps(out, indent=1))
print(json.dumps(out)[:1500])
