"""Targeted necessity search for the rank-choice and order-constraint boundary
variables (B01).  Raw: results/raw/fix/Q1/b01_rk_lt_search.json"""
import json, random, sys, time
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa
from common import random_case, roundtrip
import fixQ1_b01 as B, omega as O, transducer as T
rng = random.Random(404); t0 = time.time(); n_cases = 0; changed = {'rk_b': 0, 'lt': 0, 'rk_b+lt': 0}
while time.time() - t0 < 200:
    n = rng.randrange(3, 11)
    dom = rng.choice(('ext', 'nonneg'))
    c = roundtrip(random_case(rng, n, p_unknown=rng.choice((0.0, 0.1)), p_edge_unknown=rng.choice((0.6, 0.9, 1.0)),
                              p_wide=rng.choice((0.0, 0.1)), domain='ext'))
    t = rng.randrange(n)
    e = O.certify_exact(c, t, dom, False)
    ref = set(e[1]) if e[0] == 'ambiguous' else ({T._key(e[1])} if e[0] == 'certified' else set())
    n_cases += 1
    for cls in ('rk_b', 'lt'):
        if B.certify_ablated(c, t, cls, dom, False) != ref:
            changed[cls] += 1
out = dict(seed=404, cases=n_cases, changed=changed, seconds=round(time.time() - t0, 1),
           profile='n 3-10, p_edge_unknown 0.6-1.0, p_unknown 0-0.1, domains ext/nonneg, block=1')
out['changed'].pop('rk_b+lt')
(OUT / 'results/raw/fix/Q1/b01_rk_lt_search.json').write_text(json.dumps(out, indent=1))
print(out)
