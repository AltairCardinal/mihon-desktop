# 冻结后的改动记录（冻结清单 ac7dd03d…，留出种子基 5926461）

冻结之后只做了下列改动；每项都说明为什么不影响已经运行的留出结论。

| 文件 | 改动 | 对留出结论的影响 |
|---|---|---|
| candidates/fix_main_shadow.py | FixedShadowRunner 增加 `residency()`/`close()`；LifeFixedShadowRunner 的 `residency()` 计入 L0 证书镜像，`_close()` 先清空镜像。原因：D3 驻留测量发现镜像（每个已首发目标一个句柄）在关闭后仍保留，LC 的 residency 不计它（改前关闭后残留 7 项，`results/raw/fix/main/shadow_mirror_residual_before_release.json`）。 | 只在关闭时生效，关闭前的行为逐字不变；HO-1 不执行关闭；修改后运行器生命周期脚本全部组仍通过，关闭后残留 0（`results/raw/fix/main/shadow_mainfix_lifecycle_postfreeze_release.json`）。 |
| tests/test_fix_main.py | 增加"关闭后镜像为 0"的断言 | 测试，不影响结果 |
| bench/*（非冻结范围） | bench_fix_main 增加 fresh exact 强基线候选；summarize_formal 支持 --fix；新增 costprobe、residency、D3 索引、交付表构建脚本 | 测量与汇总脚本，不改变候选 |
