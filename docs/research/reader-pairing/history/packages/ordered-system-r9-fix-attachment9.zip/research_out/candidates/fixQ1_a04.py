"""A04 (fix round, Q1): proof vs service duplicate completion -- two protocols.

Route 1  FL  first-legal-result-wins: a strong proof result is committed
             (published) the moment it arrives, if it is still legal; any later
             result for a target that is currently published is discarded.
Route 2  FP  fixed-phase (two-phase) protocol: a proof result only PREPARES
             (stages its certificate); commits happen only at a phase barrier =
             the next service completion (finish+consume).  At the barrier every
             staged certificate is re-validated by Session.publish (stale =>
             dropped); close/rebind abort staged entries.

Both run on the real StrongSession API (coupling.Session subclass).  The event
alphabet extends R9's A04 harness (P L Fa Fb X R C) with K = close and with a
late-failure variant of Fb:
    fb='ok'          Fb returns the true witness
    fb='unavailable' Fb returns the analysis but no raw witness (rank never derived)
    fb='failed'      Fb returns a failed analysis (late failure overwrites the item)
Close K (harness-level; the package Session has none, see lifecycle notes):
    cancel all tasks (running stay occupied until their actual finish), clear
    certificates/publications/confirmations/raw, abort staged commits; after K
    certify/publish/confirm/acquire are refused.  Owner.close() is called once
    no running task remains (finish of a cancelled task never touches the owner).

Invariants (checked after every event, public Session state only):
  I1 a current publication of the target equals the truth of the current context
  I2 no certificate issued before R or K is published or confirmed afterwards
  I3 occupied == running tasks not yet finished (no early release; also after K)
  I4 'confirmed' only with a current valid publication; never after K
  I5 a cancelled/stale task never admits evidence
  I6 at most one distinct current unit per context
  I7 a certificate whose support no longer matches is never published
  I8 no double publication: publish() never returns 'published' while the target
     is already currently published in the same context
  I9 (completion, measured) after the order, unless closed, a bounded completion
     phase (finish running work, <=4 rounds of L0 / re-proof / acquisition, FP
     commits at every completion barrier) ends in one of: published,
     blocked_terminal (L0 reports blocked), stuck_no_legal_route (no certifier
     can certify on the evidence this service world can ever provide).  The two
     protocols are compared order by order; a protocol that leaves an order
     unresolved which the other publishes is a completion defect.
"""
import itertools
from copy import deepcopy

import paths  # noqa: F401
from coupling import Witness
from strong import StrongSession
from coupled_runner import truth_units
import wpA_interleave as I

EVENTS = ('P', 'L', 'Fa', 'Fb', 'X', 'R', 'K', 'C')
EVENTS_NO_CLOSE = ('P', 'L', 'Fa', 'Fb', 'X', 'R', 'C')


class ClosableStrongSession(StrongSession):
    """StrongSession + harness close protocol + optional first-legal-wins guard."""

    def __init__(self, case, **kw):
        super().__init__(case, **kw)
        self.closed = False

    def close_session(self):
        self.closed = True
        for tok in list(self._tasks):
            self.cancel(tok)
        self._raw.clear(); self._certs.clear()
        self._published.clear(); self._confirmed.clear(); self._published_handles.clear()
        self._maybe_close_owner()

    def _maybe_close_owner(self):
        if self.closed and not self._tasks and not self.owner._closed:
            self.owner.close()

    def finish(self, token, result):
        r = super().finish(token, result)
        self._maybe_close_owner()
        return r

    def consume(self, token):
        if self.closed:
            task = self._tasks.pop(token, None)
            self._maybe_close_owner()
            return 'closed' if task is not None else 'unavailable'
        return super().consume(token)

    def certify(self, target, **kw):
        if self.closed:
            return dict(status='closed', unit=None, needs=[], failures={})
        return super().certify(target, **kw)

    def publish(self, target, handle):
        if self.closed:
            return 'closed'
        return super().publish(target, handle)

    def confirm(self, target):
        if self.closed:
            return 'closed'
        return super().confirm(target)

    def acquire(self, i, *, required=True):
        if self.closed:
            return None
        return super().acquire(i, required=required)


def _fb_witness(world_item, fb):
    w = deepcopy(world_item)
    if fb == 'unavailable':
        w['available'] = False
    elif fb == 'failed':
        w['analysis'] = dict(status='failed', reason='service_failed', version=w['analysis'].get('version', 1))
    return w


def run_order(sc, order, protocol='FL', fb='ok', mutant=None, completion=True):
    """Returns dict(violations=[...], completed=bool|None, publications=int, extra_rounds=int, staged_commits=int)."""
    world, t, hole = deepcopy(sc['world']), sc['target'], sc['hole']
    world[hole + 1] = _fb_witness(world[hole + 1], fb)        # the hidden service outcome of Fb
    s = ClosableStrongSession(sc['initial'], capacity=3, strong=dict(kind='tree', domain='nonneg', gate='raw'))
    truth = truth_units(sc['initial'], world)
    if mutant == 'commit_no_revalidate':
        s._certificate_current = lambda cert: True
    if mutant == 'close_frees_running':
        orig_close = s.close_session

        def close_session():
            orig_close()
            for tok in [k for k, v in s._tasks.items() if v['phase'] == 'running']:
                del s._tasks[tok]
        s.close_session = close_session
    if mutant == 'close_keeps_publications':
        def close_session():
            s.closed = False                      # never refuses, keeps state
            for tok in list(s._tasks):
                s.cancel(tok)
        s.close_session = close_session
    guard = mutant != 'no_first_wins_guard'
    s.certify(t, mode='L0')
    ta, tb = s.acquire(hole), s.acquire(hole + 1)
    strong = s.certify(t, mode='S')
    proof_handle = strong.get('certificate')
    issued_before = set(s._certs)
    old_epoch_handles = set()
    staged = []
    rebound = closed = False
    units_seen, viol = set(), []
    finished = set()
    pubs = staged_commits = 0
    proof_arrived = False
    first_pub_step = None
    step = 0

    def do_publish(handle, origin):
        nonlocal pubs
        if handle is None:
            return None
        if guard and t in s.published:
            return 'discarded_duplicate'           # first legal result already current
        cert = s._certs.get(handle)
        fresh = None
        if cert is not None and not s.closed:
            idx = s.owner._index()
            fresh = all(s.owner._read(idx, k) == v for k, v in cert['support'].items())
        already = t in s.published
        r = s.publish(t, handle)
        if r == 'published':
            pubs += 1
            if handle in old_epoch_handles:
                viol.append('I2 old certificate published after rebind/close')
            if fresh is False:
                viol.append('I7 stale-support certificate published')
            if already:
                viol.append('I8 double publication')
        return r

    def barrier():
        nonlocal staged_commits
        for h in list(staged):
            staged.remove(h)
            if do_publish(h, 'proof') == 'published':
                staged_commits += 1

    def service(ev):
        tok = ta if ev == 'Fa' else tb
        item = hole if ev == 'Fa' else hole + 1
        if tok is not None and tok in s._tasks:
            was_cancelled = s._tasks[tok]['cancelled']
            s.finish(tok, Witness(**world[item]))
            r = s.consume(tok)
            if (was_cancelled or rebound) and r == 'accepted':
                viol.append('I5 cancelled/stale task admitted evidence')
        finished.add(ev)
        if protocol == 'FP' and not s.closed:
            barrier()

    for ev in order:
        step += 1
        if ev == 'P':
            proof_arrived = True
            if protocol == 'FL':
                do_publish(proof_handle, 'proof')
            elif proof_handle is not None and not s.closed:
                staged.append(proof_handle)
        elif ev == 'L':
            v = s.certify(t, mode='L0')
            if v['status'] == 'certified':
                do_publish(v['certificate'], 'L0')
        elif ev in ('Fa', 'Fb'):
            service(ev)
        elif ev == 'X':
            for tok in list(s._tasks):
                s.cancel(tok)
        elif ev == 'R':
            if s.closed:
                continue
            k = hole + 1
            world[k] = deepcopy(world[k]); world[k]['raw'] = (world[k]['raw'] or 0) + 997
            case = s.observe()
            case['items'][k]['content_version'] = case['items'][k].get('content_version', 0) + 1
            case['items'][k]['analysis'] = {'status': 'unknown'}
            case['edges'] = [e for e in case['edges'] if k not in (e['first'], e['second'])]
            old_epoch_handles |= set(s._certs)
            s.rebind(case)
            staged.clear()
            truth = truth_units(case, world)
            rebound = True
            units_seen = set()
        elif ev == 'K':
            old_epoch_handles |= set(s._certs) | issued_before
            s.close_session()
            staged.clear()
            closed = True
        elif ev == 'C':
            r = s.confirm(t)
            if r == 'confirmed':
                if closed:
                    viol.append('I4 confirmed after close')
                if t not in s.published:
                    viol.append('I4 confirmed without current publication')
                if s._published_handles.get(t) in old_epoch_handles:
                    viol.append('I2 old certificate confirmed after rebind/close')
        pub = s._published if s.closed else s.published
        if t in pub and first_pub_step is None:
            first_pub_step = step
        if t in pub:
            if pub[t] != truth.get(t):
                viol.append('I1 wrong current publication')
            units_seen.add(repr(pub[t]))
            if len(units_seen) > 1:
                viol.append('I6 two distinct current units in one context')
        running = sum(1 for task in s._tasks.values() if task['phase'] == 'running')
        expect = sum(1 for e, tk in (('Fa', ta), ('Fb', tb)) if tk is not None and e not in finished)
        if running != expect:
            viol.append('I3 occupancy mismatch (early release or leak)')
    # ---- completion phase (I9)
    completed, extra, outcome = None, 0, None
    if completion:
        for ev in ('Fa', 'Fb'):
            if ev not in finished:
                service(ev)
        if protocol == 'FP' and not s.closed:
            barrier()
        if s.closed:
            completed = None
            if s._tasks or not s.owner._closed:
                viol.append('I3 resources not released after close')
        else:
            outcome = None
            for _ in range(4):
                if t in s.published:
                    break
                extra += 1
                v = s.certify(t, mode='L0')
                if v['status'] == 'certified':
                    do_publish(v['certificate'], 'L0')
                    continue
                if v['status'] == 'blocked':
                    outcome = 'blocked_terminal'          # definitive negative verdict, reported
                    break
                if v['status'] == 'need_facts':
                    sv = s.certify(t, mode='S')           # re-proof on current evidence (both protocols)
                    if str(sv.get('route', '')).startswith('strong'):
                        if protocol == 'FL':
                            do_publish(sv['certificate'], 'proof')
                        else:
                            staged.append(sv['certificate'])
                    toks = []
                    for nd in v['needs']:
                        for i in [nd['item']] + ([nd['second']] if 'second' in nd else []):
                            tk = s.acquire(i)
                            if tk is not None:
                                toks.append((tk, i))
                    for tk, i in toks:
                        if tk in s._tasks and s._tasks[tk]['phase'] == 'running':
                            s.finish(tk, Witness(**world[i])); s.consume(tk)
                    if protocol == 'FP':
                        barrier()                          # the completions are phase barriers
            completed = t in s.published
            if outcome is None:
                outcome = 'published' if completed else 'stuck_no_legal_route'
            if t in s.published and s.published[t] != truth.get(t):
                viol.append('I1 wrong publication after completion')
    if s.closed:
        outcome = 'closed'
    return dict(violations=sorted(set(viol)), completed=completed, outcome=outcome if completion else None,
                publications=pubs, extra_rounds=extra, staged_commits=staged_commits, proof_arrived=proof_arrived,
                first_pub_step=first_pub_step)


def exhaustive(protocol, fb, mutant=None, stride=1, events=EVENTS):
    sc = I.small_case()
    total = bad = 0
    comp = {}
    outcomes = []
    fps = []
    pubs = extra = 0
    kinds, examples = {}, []
    for k, order in enumerate(itertools.permutations(events)):
        if k % stride:
            continue
        total += 1
        r = run_order(sc, order, protocol, fb, mutant)
        pubs += r['publications']; extra += r['extra_rounds']
        comp[r['outcome']] = comp.get(r['outcome'], 0) + 1
        fps.append(r['first_pub_step'])
        outcomes.append(r['outcome'])
        if r['violations']:
            bad += 1
            for v in r['violations']:
                kinds[v] = kinds.get(v, 0) + 1
            if len(examples) < 3:
                examples.append(dict(order=order, violations=r['violations']))
    return dict(protocol=protocol, fb=fb, mutant=mutant, stride=stride, events=''.join(events), case=dict(n=sc['n'], target=sc['target'],
                hole=sc['hole']), orders=total, violating_orders=bad, violation_kinds=kinds, examples=examples,
                completion=comp, publications=pubs, completion_extra_rounds=extra, outcomes=outcomes,
                first_pub_steps=fps)


# ----------------------------------------------------------------- coupled runner comparison (virtual u)
import wpA_lib as A  # noqa: E402


class PhaseShadowRunner(A.ShadowRunner):
    """Route 2 (fixed phase) on the coupled shadow runner: a proof result is staged
    and committed only at the next service completion (consume), re-validated by
    Session.publish there.  Physical behaviour is the incumbent's (as ShadowRunner)."""

    def __init__(self, trace, **kw):
        super().__init__(trace, **kw)
        self.staged = {}
        self.c['staged'] = self.c['barrier_commits'] = self.c['barrier_stale'] = 0
        orig = self.session.consume

        def consume(token):
            r = orig(token)
            self._barrier()
            return r
        self.session.consume = consume
        orig_rebind = self.session.rebind

        def rebind(case, **k):
            self.staged.clear()
            return orig_rebind(case, **k)
        self.session.rebind = rebind

    def _barrier(self):
        for t, v in list(self.staged.items()):
            del self.staged[t]
            if t in self.first_pub and t not in self.republish:
                continue
            if self._publish_proof(t, v) == 'published':
                self.c['barrier_commits'] += 1
                self.c['proof_wins'] += 1
            else:
                self.c['barrier_stale'] += 1
                self.proof_failed_at[t] = self.session.owner._revision

    def _finish_proof(self, t, cls, immediate=False, v=None, rev_at_start=None):
        self.proof_inflight.pop(t, None)
        self._proof_event = True
        ok = v is not None and v['status'] == 'certified' and str(v.get('route', '')).startswith('strong')
        if t in self.first_pub and t not in self.republish:
            if ok:
                self.c['wasted_proofs'] += 1
            return
        if ok:
            self.staged[t] = v
            self.c['staged'] += 1
            return
        self.proof_failed_at[t] = self.session.owner._revision


def compare_runners(traces, service_u, q_u, capacity=3):
    """Same trace, same parameters: incumbent / FL (gated_shadow) / FP (phase)."""
    out = []
    for tr in traces:
        row = dict(trace=tr['name'], service_u=service_u, q_u=q_u)
        for name, mk in (('incumbent', lambda: A.ARunner(tr, policy='incumbent', service_u=service_u, q_u=q_u, capacity=capacity)),
                         ('FL', lambda: A.ShadowRunner(tr, policy='gated_shadow', service_u=service_u, q_u=q_u, capacity=capacity)),
                         ('FP', lambda: PhaseShadowRunner(tr, policy='gated_shadow', service_u=service_u, q_u=q_u, capacity=capacity))):
            rn = mk()
            r = rn.run(max_steps=40000)
            row[name] = dict(total_latency_u=r['total_latency_u'], physical_admissions=r['physical_admissions'],
                             wrong=r['wrong'], published=r['published'], intents=r['intents'], livelock=r['livelock'],
                             proof_wins=r.get('proof_wins', 0), staged=rn.c.get('staged', 0),
                             barrier_stale=rn.c.get('barrier_stale', 0))
        out.append(row)
    return out
