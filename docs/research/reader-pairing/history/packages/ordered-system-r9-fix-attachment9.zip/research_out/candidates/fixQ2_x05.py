"""X05 = B04 (on-demand shared, target-independent assignment frontier) x G02
(support DAG of the proofs).  One driver, one cost accounting, five arms on the
same event stream (queries + owner deltas):

  '0'    fresh exact DP from position 0 per missing certificate; flat support
         snapshot (dict key -> value) per certificate.
  'A'    B04: frontier cache F_0..F_L (target independent, include=False),
         positional invalidation from the window lemma (item p -> keep F_<=p-3,
         edge a -> keep F_<=a-1); certificate support = flat COPY of the cached
         per-step read sets + the tail reads.
  'B'    G02: no frontier cache; supports are hash-consed DAG nodes (one node
         per step: parent, read set); validation memoises node validity per
         owner revision (shared prefixes validated once per revision).
  'AB1'  organisation 1 - shared state graph carrying support: the frontier
         cache entries ARE the support nodes; invalidation is support driven
         (a delta truncates the cache at the first step that actually READ a
         changed key, via a reverse index); certificates point at a cache node
         (generation-checked, O(1)) and validate only their tail reads.
  'AB2'  organisation 2 - independent snapshots with reference sharing:
         frontier cache as in A; each certificate keeps an immutable tuple of
         REFERENCES to the cached per-step read sets + its tail dict;
         validation reads every key through the references.
Mutants (must be caught): 'A_miss' / 'AB2_miss' build the certificate support
only from the steps computed in this query + the tail, i.e. they miss the
cached prefix reads.

Read keys: ('pos', p) -> (state, side) as loaded for omega semantics;
('rank', a) -> (status, score) of the edge record (a, a+1) or None.
Logged at the moment the transducer reads them (LogCtx), so a read set is the
exact set of facts a step consulted under every branch.
Costs (all counts, no blended score): evaluations (BC-2 meter unit),
validation_reads, prefix_reads_carried, support_entries_stored (unique),
delta_fanout (objects invalidated at delta time), lazy_invalidations,
release_work (entries/objects freed), residency (frontier elements + support
entries + nodes/references), stale_reuses (ground truth via certify_exact).
"""
import random
from collections import Counter
from copy import deepcopy

import paths  # noqa: F401
import transducer as T
import omega as O
from budget import Meter


# ------------------------------------------------------------------ read logging
class LogCtx(T.Ctx):
    def __init__(self, facts):
        self.log = set()
        super().__init__(facts)

    def _state(self, p):
        self.log.add(('pos', p))
        return super()._state(p)

    def _side(self, i):
        self.log.add(('pos', i))
        return super()._side(i)

    def _rank(self, a, b):
        if self._state(a) == 'WIDE' or self._state(b) == 'WIDE':
            return None
        self.log.add(('rank', a))
        return super()._rank(a, b)


def value(F, key):
    if key[0] == 'pos':
        return (F.state[key[1]], F.side[key[1]])
    e = F.records.get(key[1])
    return None if e is None else (e.get('status'), e.get('score'))


def _step_frontier(ctx, i, frontier, include, target=None):
    """One DP step over a frontier; returns (next_frontier, units, reads)."""
    ctx.log = set()
    nxt, units = set(), {}
    for s, asg in frontier:
        if target is not None and s >> 1 == T.SKIP and i == target:
            continue
        for (ns, unit), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(asg)):
            if target is not None and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                units[T._key(unit)] = unit
            elif target is None or i < target:
                nxt.add((ns, frozenset(O._prune(a, i).items())))
    return frozenset(nxt), units, frozenset(ctx.log)


START = frozenset({(T.S0, frozenset())})


# ------------------------------------------------------------------ arms
class Arm:
    def __init__(self, name, domain='nonneg', alpha=False):
        self.name, self.domain, self.alpha = name, domain, alpha
        self.c = Counter()
        self.certs = {}                         # target -> cert record
        self.revision = 0
        self.peak = 0

    # ---- helpers shared by arms
    def facts(self, case):
        return T.Facts(case, 'omega', self.domain, self.alpha)

    def _tail(self, F, ctx, t, frontier):
        """Steps t-1 (if t >= 1) and t from the frontier at boundary max(0, t-1)."""
        units, reads = {}, []
        start = max(0, t - 1)
        for i in range(start, t + 1):
            frontier, u, r = _step_frontier(ctx, i, frontier, True, target=t)
            units.update(u)
            reads.append((i, r))
        return units, reads

    def snapshot(self, F, keys):
        return {k: value(F, k) for k in keys}

    def residency(self):
        return 0

    def note_peak(self):
        self.peak = max(self.peak, self.residency())


class Fresh(Arm):
    """'0' (flat) and 'B' (DAG) share the fresh DP; they differ in support storage."""

    def __init__(self, name, dag=False, **kw):
        super().__init__(name, **kw)
        self.dag = dag
        self.nodes = {}                          # node key -> node dict (DAG arm)
        self.memo = {}                           # node id -> revision validated at

    def compute(self, F, ctx, t):
        frontier = START
        steps = []
        for i in range(max(0, t - 1)):
            frontier, _u, r = _step_frontier(ctx, i, frontier, False)
            steps.append((i, r))
        units, tail = self._tail(F, ctx, t, frontier)
        return units, steps + tail

    def make_support(self, F, steps):
        if not self.dag:
            keys = set().union(*[r for _i, r in steps]) if steps else set()
            sup = self.snapshot(F, keys)
            self.c['support_entries_created'] += len(sup)
            return ('flat', sup)
        parent = None
        for i, r in steps:
            vals = tuple(sorted(self.snapshot(F, r).items(), key=repr))
            key = (parent, i, vals)
            node = self.nodes.get(key)
            if node is None:
                self.node_seq = getattr(self, 'node_seq', 0) + 1
                node = dict(id=self.node_seq, parent=parent, reads=dict(vals), refs=0, key=key)
                self.nodes[key] = node
                self.c['support_entries_created'] += len(vals)
                self.c['nodes_created'] += 1
            node['refs'] += 1
            parent = key
        return ('dag', parent)

    def validate(self, F, sup):
        if sup[0] == 'flat':
            for k, v in sup[1].items():
                self.c['validation_reads'] += 1
                if value(F, k) != v:
                    return False
            return True
        key = sup[1]
        while key is not None:
            node = self.nodes.get(key)
            if node is None:
                return False
            if self.memo.get(node['id']) != self.revision:
                for k, v in node['reads'].items():
                    self.c['validation_reads'] += 1
                    if value(F, k) != v:
                        return False
                self.memo[node['id']] = self.revision
            key = node['parent']
        return True

    def release(self, sup):
        if sup[0] == 'flat':
            self.c['release_work'] += len(sup[1])
            return
        key = sup[1]
        while key is not None:
            node = self.nodes.get(key)
            if node is None:
                break
            node['refs'] -= 1
            parent = node['parent']
            if node['refs'] <= 0:
                self.c['release_work'] += 1 + len(node['reads'])
                self.memo.pop(node['id'], None)
                del self.nodes[key]
            key = parent

    def on_delta(self, changed, positional):
        self.revision += 1                       # lazy arms do nothing else at delta time

    def residency(self):
        if self.dag:
            return sum(1 + len(n['reads']) for n in self.nodes.values())
        return sum(len(c['support'][1]) for c in self.certs.values())

    def query(self, F, t):
        cert = self.certs.get(t)
        if cert is not None:
            if self.validate(F, cert['support']):
                self.c['reuses'] += 1
                return cert['unit'], True
            self.c['lazy_invalidations'] += 1
            self.release(cert['support'])
            del self.certs[t]
        ctx = LogCtx(F)
        with Meter(None) as m:
            units, steps = self.compute(F, ctx, t)
        self.c['evaluations'] += m.n
        if len(units) != 1:
            return None, False
        unit = next(iter(units.values()))
        self.certs[t] = dict(unit=unit, support=self.make_support(F, steps))
        return unit, False


class Cached(Arm):
    """'A', 'AB1', 'AB2' and the mutants: target-independent frontier cache."""

    def __init__(self, name, org='A', miss_prefix=False, **kw):
        super().__init__(name, **kw)
        self.org, self.miss = org, miss_prefix
        self.fr = [START]                         # fr[i] = frontier at boundary i (valid prefix)
        self.reads = []                           # reads[i] = (frozen read dict object) of step i
        self.gen = [0]                            # generation of boundary i (AB1 pointer check)
        self.next_gen = 1
        self.rev = {}                             # AB1: key -> set of steps that read it

    # ---- cache maintenance
    def _truncate(self, L):
        L = max(0, L)
        if L + 1 >= len(self.fr):
            return 0
        dropped_fr = self.fr[L + 1:]
        dropped_rd = self.reads[L:]
        work = sum(len(f) for f in dropped_fr) + sum(len(r) for r in dropped_rd)
        self.c['release_work'] += work
        self.c['delta_fanout'] += len(dropped_fr)
        if self.org == 'AB1':
            for i, r in enumerate(dropped_rd, start=L):
                for k in r:
                    s = self.rev.get(k)
                    if s is not None:
                        s.discard(i)
                        if not s:
                            del self.rev[k]
            # eager certificate invalidation through the graph (certificates pointing beyond L)
            for t, c in list(self.certs.items()):
                if c['support']['boundary'] > L:
                    self.c['delta_fanout'] += 1
                    self.c['release_work'] += len(c['support']['tail'])
                    del self.certs[t]
        del self.fr[L + 1:]
        del self.reads[L:]
        del self.gen[L + 1:]
        return work

    def on_delta(self, changed, positional):
        self.revision += 1
        if self.org == 'AB1':
            steps = [i for k in changed for i in self.rev.get(k, ())]
            if steps:
                self._truncate(min(steps))        # F_{i+1} depends on step i -> keep F_0..F_i
            return
        self._truncate(positional)

    def _extend(self, F, ctx, upto):
        while len(self.fr) - 1 < upto:
            i = len(self.fr) - 1
            nxt, _u, r = _step_frontier(ctx, i, self.fr[i], False)
            rd = self.snapshot(F, r)
            self.fr.append(nxt)
            self.reads.append(rd)
            self.gen.append(self.next_gen); self.next_gen += 1
            self.c['support_entries_created'] += len(rd)
            if self.org == 'AB1':
                for k in rd:
                    self.rev.setdefault(k, set()).add(i)

    def validate(self, F, sup):
        if self.org == 'AB1':
            b = sup['boundary']
            if b >= len(self.gen) or self.gen[b] != sup['gen']:
                return False                       # O(1): the cache node it points at is gone
            for k, v in sup['tail'].items():
                self.c['validation_reads'] += 1
                if value(F, k) != v:
                    return False
            return True
        for part in sup['parts']:
            for k, v in part.items():
                self.c['validation_reads'] += 1
                if value(F, k) != v:
                    return False
        return True

    def residency(self):
        res = sum(len(f) for f in self.fr) + sum(len(r) for r in self.reads)
        if self.org == 'AB1':
            res += sum(len(c['support']['tail']) + 1 for c in self.certs.values())
            res += sum(len(s) for s in self.rev.values())
        elif self.org == 'AB2':
            cached_ids = {id(r) for r in self.reads}
            extra = {}
            for c in self.certs.values():
                res += len(c['support']['parts'])           # references
                for p in c['support']['parts']:
                    if id(p) not in cached_ids:
                        extra[id(p)] = len(p)
            res += sum(extra.values())
        else:
            res += sum(sum(len(p) for p in c['support']['parts']) for c in self.certs.values())
        return res

    def query(self, F, t):
        cert = self.certs.get(t)
        if cert is not None:
            if self.validate(F, cert['support']):
                self.c['reuses'] += 1
                # harness-only audit (never used for decisions): did a read of the cached
                # prefix that the proof depended on change since the certificate was made?
                if any(value(F, k) != v for k, v in cert['audit'].items()):
                    self.c['unsafe_reuses'] += 1
                return cert['unit'], True
            self.c['lazy_invalidations'] += 1
            sup = cert['support']
            self.c['release_work'] += len(sup['tail']) if self.org == 'AB1' else \
                sum(len(p) for p in sup['parts']) if self.org == 'A' else len(sup['parts'])
            del self.certs[t]
        ctx = LogCtx(F)
        b = max(0, t - 1)
        before = len(self.fr) - 1
        with Meter(None) as m:
            self._extend(F, ctx, b)
            units, tail = self._tail(F, ctx, t, self.fr[b])
        self.c['evaluations'] += m.n
        if len(units) != 1:
            return None, False
        unit = next(iter(units.values()))
        tail_keys = set().union(*[r for _i, r in tail]) if tail else set()
        tail_dict = self.snapshot(F, tail_keys)
        self.c['support_entries_created'] += len(tail_dict)
        if self.org == 'AB1':
            sup = dict(boundary=b, gen=self.gen[b], tail=tail_dict)
        else:
            first = before if self.miss else 0       # mutant: only steps computed in THIS query
            prefix = self.reads[min(first, b):b]
            if not self.miss:
                self.c['prefix_reads_carried'] += sum(len(p) for p in prefix)
            if self.org == 'A':
                parts = [dict(p) for p in prefix] + [tail_dict]        # flat copies
                self.c['support_entries_created'] += sum(len(p) for p in prefix)
            else:
                parts = list(prefix) + [tail_dict]                     # references
            sup = dict(parts=parts)
        audit = {}
        for r in self.reads[:b]:
            audit.update(r)
        self.certs[t] = dict(unit=unit, support=sup, audit=audit)
        return unit, False


ARMS = {
    '0': lambda: Fresh('0'),
    'A': lambda: Cached('A', org='A'),
    'B': lambda: Fresh('B', dag=True),
    'AB1': lambda: Cached('AB1', org='AB1'),
    'AB2': lambda: Cached('AB2', org='AB2'),
    'A_miss': lambda: Cached('A_miss', org='A', miss_prefix=True),
    'AB2_miss': lambda: Cached('AB2_miss', org='AB2', miss_prefix=True),
}


# ------------------------------------------------------------------ common input streams
def stream(family, seed, n=40, events=120, q_rate=0.5, pattern='hot', churn=0.3, front=False):
    import workloads as W
    gen = dict(W01=lambda s: W.w01_phase_chain(s, n=n, holes=4),
               RP=lambda s: W.random_partial(s, n=n, pa=0.6, pe=0.6),
               W05=lambda s: W.w05_raw_eviction(s, n=n, holes=6),
               W02=lambda s: W.w02_islands(s, n=n))[family]
    tr = gen(seed)
    rng = random.Random(1000 + seed)
    world = tr['world']
    case = deepcopy(tr['initial'])
    evs = []
    hot = rng.randrange(n)
    for k in range(events):
        if rng.random() < q_rate:
            if pattern == 'hot':
                t = max(0, min(n - 1, hot + rng.randrange(-3, 4)))
            elif pattern == 'sweep':
                t = k % n
            else:
                t = rng.randrange(n)
            evs.append(('q', t))
            continue
        r = rng.random()
        if r < churn:                                    # churn: change a known rank value
            ks = [e['first'] for e in case['edges'] if e.get('status') == 'computed' and e.get('score') is not None
                  and (not front or e['first'] < n // 4)]
            if ks:
                a = rng.choice(ks)
                evs.append(('edge', a, dict(status='computed', score=rng.randrange(0, 40), version=2)))
                for e in case['edges']:
                    if e['first'] == a:
                        e['score'] = evs[-1][2]['score']
                continue
        unk = [i for i, it in enumerate(case['items']) if it['analysis'].get('status') != 'computed'
               and (not front or i < n // 4)]
        miss = sorted(a for a in set(range(n - 1)) - {e['first'] for e in case['edges']} if not front or a < n // 4)
        if unk and (not miss or rng.random() < 0.5):
            i = rng.choice(unk)
            evs.append(('item', i, deepcopy(world[i]['analysis'])))
            case['items'][i]['analysis'] = deepcopy(world[i]['analysis'])
        elif miss:
            a = rng.choice(miss)
            ra, rb = world[a]['raw'], world[a + 1]['raw']
            rec = dict(status='computed', score=None if ra is None or rb is None else abs(ra - rb), version=1)
            evs.append(('edge', a, rec))
            case['edges'].append(dict(rec, first=a, second=a + 1))
        else:
            evs.append(('q', rng.randrange(n)))
    return dict(name=f'X05_{family}_n{n}_{pattern}{"_front" if front else ""}_s{seed}', initial=tr['initial'], events=evs)


def apply_event(case, ev):
    if ev[0] == 'item':
        case['items'][ev[1]]['analysis'] = deepcopy(ev[2])
        p = ev[1]
        return {('pos', p)}, max(0, p - 3)
    a = ev[1]
    for e in case['edges']:
        if e['first'] == a and e['second'] == a + 1:
            e.update(deepcopy(ev[2]))
            break
    else:
        case['edges'].append(dict(deepcopy(ev[2]), first=a, second=a + 1))
    return {('rank', a)}, max(0, a - 1)


def prepare(st, domain='nonneg', alpha=False):
    """Arm-independent preprocessing of a stream (done once, shared by every arm):
    the real changed keys of each delta (owner semantics: no-op writes report no
    change) and the ground-truth verdict of every query (certify_exact on the
    current case; harness only)."""
    case = deepcopy(st['initial'])
    out = []
    for ev in st['events']:
        if ev[0] != 'q':
            keys = {('pos', ev[1])} if ev[0] == 'item' else {('rank', ev[1])}
            F0 = T.Facts(case, 'omega', domain, alpha)
            old = {k: value(F0, k) for k in keys}         # captured BEFORE the in-place write
            _keys, positional = apply_event(case, ev)
            F1 = T.Facts(case, 'omega', domain, alpha)
            changed = {k for k in keys if old[k] != value(F1, k)}
            out.append(('d', ev, changed, positional))
        else:
            s2, u2 = O.certify_exact(case, ev[1], domain, alpha)
            out.append(('q', ev[1], u2 if s2 == 'certified' else None))
    return out


def run(st, arm_name, prep=None):
    arm = ARMS[arm_name]()
    prep = prep if prep is not None else prepare(st, arm.domain, arm.alpha)
    case = deepcopy(st['initial'])
    stale = wrong = answered = ambiguous = 0
    for item in prep:
        if item[0] == 'd':
            _tag, ev, changed, positional = item
            apply_event(case, ev)
            if not changed:
                arm.c['noop_deltas'] += 1
                continue
            arm.on_delta(changed, positional)
            arm.note_peak()
            continue
        _tag, t, truth = item
        unit, reused = arm.query(arm.facts(case), t)
        arm.note_peak()
        if unit is None:
            ambiguous += 1
            wrong += truth is not None
        else:
            answered += 1
            if unit != truth:
                stale += reused
                wrong += not reused
    out = dict(arm.c)
    out.update(stale_reuses=stale, wrong_fresh=wrong, answered=answered, ambiguous=ambiguous,
               residency_final=arm.residency(), residency_peak=arm.peak,
               support_entries_stored_final=_support_entries(arm))
    return out


def _support_entries(arm):
    if isinstance(arm, Fresh):
        return arm.residency()
    if arm.org == 'AB1':
        return sum(len(r) for r in arm.reads) + sum(len(c['support']['tail']) for c in arm.certs.values())
    if arm.org == 'AB2':
        seen = {}
        for r in arm.reads:
            seen[id(r)] = len(r)
        for c in arm.certs.values():
            for p in c['support']['parts']:
                seen[id(p)] = len(p)
        return sum(seen.values())
    return sum(len(r) for r in arm.reads) + sum(sum(len(p) for p in c['support']['parts']) for c in arm.certs.values())


METRICS = ('evaluations', 'validation_reads', 'prefix_reads_carried', 'support_entries_created',
           'support_entries_stored_final', 'delta_fanout', 'lazy_invalidations', 'release_work',
           'residency_peak', 'residency_final', 'reuses', 'stale_reuses', 'unsafe_reuses', 'wrong_fresh', 'noop_deltas')


def interaction(r0, ra, rb, rab):
    return {m: rab.get(m, 0) - ra.get(m, 0) - rb.get(m, 0) + r0.get(m, 0) for m in METRICS}
