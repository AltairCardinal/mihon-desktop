"""WP-H combination challenges X07 X08 X16 X22 X23 X24 X25 X29.

Each reports 0 / A / B / A+B plus a second organisation of the combination,
with per-metric interaction  I = m(A+B) - m(A) - m(B) + m(0)  (no composite score).
"""
import itertools
import json
import random
from copy import deepcopy
from pathlib import Path

import paths  # noqa: F401
import reference as ref
from common import random_case, roundtrip, fact, base_case
from coupling import Session, Witness
from current_baseline import typed
from strong import StrongSession
import workloads as W
import wpH_commit as H
import wpH_runner as R
from wpH_sched import Sim, latent
import wpH_exp_sched as ES

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpH'


def interaction(m0, ma, mb, mab):
    return {k: (mab[k] - ma[k] - mb[k] + m0[k]) for k in m0 if all(isinstance(x.get(k), (int, float)) for x in (m0, ma, mb, mab))}


def members_by_id(case):
    out = {}
    for u in ref.complete_plan(case):
        ids = tuple(case['items'][s['item']]['id'] for s in u['slots'])
        for s in u['slots']:
            out[case['items'][s['item']]['id']] = (ids, tuple(x['slot'] for x in u['slots']), u['reason'])
    return out


# ------------------------------------------------------------------ X07 dynamic order x publication revocation
def x07(seeds=range(200)):
    same_by_id = total = ordinal_stale_but_equal = cex = 0
    example = None
    for seed in seeds:
        rng = random.Random(seed)
        n = rng.randrange(4, 12)
        c = roundtrip(random_case(rng, n, settings_mix=False))
        k = rng.randrange(n)
        j = rng.randrange(n)
        d = deepcopy(c)
        it = d['items'].pop(k)
        d['items'].insert(j, it)
        d['edges'] = []                      # edges are ordinal-based evidence: not transferable by position
        for a in range(n - 1):
            d['edges'].append(dict(first=a, second=a + 1, status='computed', score=None, version=1))
        before, after = members_by_id(c), members_by_id(d)
        for x in before:
            total += 1
            if before[x] == after[x]:
                same_by_id += 1
        # same-value move counterexample: identical facts, unit membership by ordinal changes
        if example is None and k != j:
            pc, pd = ref.complete_plan(c), ref.complete_plan(d)
            for u in pc:
                ords = [s['item'] for s in u['slots']]
                ids_now = [d['items'][o]['id'] for o in ords if o < n]
                ids_old = [c['items'][o]['id'] for o in ords]
                if ids_now != ids_old:
                    example = dict(seed=seed, moved_from=k, moved_to=j, ordinal_unit=ords, ids_before=ids_old,
                                   ids_at_same_ordinals_after=ids_now)
                    break
    groups = {
        '0_replace_recertify_all': dict(recertifications='all n', authority='re-signed', reuse=0.0),
        'A_id_remap_work_reuse': dict(recertifications='all n (support is ordinal-based)', authority='re-signed',
                                      reuse=round(same_by_id / total, 3)),
        'B_incremental_revocation': dict(recertifications='all n', authority='global guard change -> full revocation',
                                         reuse=0.0),
        'AB': dict(recertifications='all n', authority='re-signed', reuse=round(same_by_id / total, 3)),
    }
    return dict(units_identical_by_id_after_one_move=round(same_by_id / total, 3), units=total,
                same_value_move_counterexample=example, groups=groups,
                conclusion='a move changes ordinals, edges and pairing; by-id equality holds for most units but '
                           'authority must be re-signed (support keys are ordinal); incremental revocation cannot help '
                           'because the guard changes globally - B adds nothing under reorder (interaction 0)')


# ------------------------------------------------------------------ X08 batch update x atomic admission
def x08(seeds=range(150)):
    res = dict(per_item=dict(intermediate_certs=0, wrong_vs_final=0, wrong_vs_own_state=0, validations=0),
               atomic=dict(intermediate_certs=0, wrong_vs_final=0, wrong_vs_own_state=0, validations=0),
               per_item_identity=dict(intermediate_certs=0, wrong_vs_own_truth_with_new_identity=0))
    for seed in seeds:
        rng = random.Random(seed)
        n = rng.randrange(5, 12)
        c = roundtrip(random_case(rng, n, settings_mix=False))
        t = rng.randrange(n)
        changes = {}
        for i in rng.sample(range(n), 3):
            changes[i] = {'analysis': dict(status='computed', fact=fact(rng.choice(('NARROW', 'WIDE')), rng.choice(('A', 'B', 'UNKNOWN'))), version=9)}
        final = deepcopy(c)
        for i, p in changes.items():
            final['items'][i].update(deepcopy(p))
            final['items'][i]['header'] = fact(p['analysis']['fact']['state'])
        ft = ref.certify_strategy(final, t)['selected']
        # per-item: evidence changes committed one by one, certify after each
        s = Session(c)
        cur = deepcopy(c)
        for i, p in changes.items():
            pp = dict(p, header=fact(p['analysis']['fact']['state']))
            s.owner.apply(item_updates={i: pp}); cur['items'][i].update(deepcopy(pp))
            v = s.certify(t, mode='L0'); res['per_item']['validations'] += 1
            if v['status'] == 'certified':
                res['per_item']['intermediate_certs'] += 1
                own = ref.certify_strategy(cur, t)['selected']
                res['per_item']['wrong_vs_own_state'] += own['unit'] != v['unit']
                res['per_item']['wrong_vs_final'] += ft['status'] == 'certified' and ft['unit'] != v['unit']
        s2 = Session(c)
        s2.owner.apply(item_updates={i: dict(p, header=fact(p['analysis']['fact']['state'])) for i, p in changes.items()})
        v = s2.certify(t, mode='L0'); res['atomic']['validations'] += 1
        if v['status'] == 'certified':
            res['atomic']['intermediate_certs'] += 1
            res['atomic']['wrong_vs_final'] += ft['unit'] != v['unit']
        # identity changes split from their evidence (content_version first)
        s3 = Session(c)
        i = next(iter(changes))
        s3.owner.apply(item_updates={i: {'content_version': 5}})
        v = s3.certify(t, mode='L0')
        if v['status'] == 'certified':
            res['per_item_identity']['intermediate_certs'] += 1
            truth_new = deepcopy(c); truth_new['items'][i].update(changes[i]); truth_new['items'][i]['content_version'] = 5
            truth_new['items'][i]['header'] = fact(changes[i]['analysis']['fact']['state'])
            tn = ref.certify_strategy(truth_new, t)['selected']
            res['per_item_identity']['wrong_vs_own_truth_with_new_identity'] += tn['status'] == 'certified' and tn['unit'] != v['unit']
    res['conclusion'] = ('per-item commits of individually valid evidence produce certificates that are correct for '
                         'their own intermediate version (observable intermediate versions); they may differ from '
                         'the final version, so a consumer that declared intermediate versions non-observable must use '
                         'the atomic batch; identity changes split from evidence certify stale facts')
    return res


# ------------------------------------------------------------------ X16 in-flight wait x shared externality
def x16():
    base = ES.i03(seeds=range(4))
    rows = []
    for fail_first in (False, True):
        for pol in ('wait', 'bypass_b8'):
            tot = dict(required_total=0, starts=0, busy_u=0)
            for seed in range(4):
                lat = {'X': 20 + (20 if fail_first else 0)}        # failed first attempt doubles the shared latency
                ints = [dict(at=0, id='pre', needs=['X'], required=False)]
                for j in range(3):
                    lat[f'Y{j}'] = latent(seed, f'Y{j}', 0, 2, 6)
                    ints.append(dict(at=1 + j, id=f't{j}', needs=['X', f'Y{j}'], any_of=True, required=True))
                bounds = {'X': 20}                                   # declared bound does NOT know about the failure

                def hook(sim, it, pol=pol):
                    if not it['id'].startswith('t'):
                        return
                    if pol == 'wait':
                        sim.cancel(it['needs'][1], it['id']); return
                    x = sim.tasks.get('X')
                    remaining = (x.start + bounds['X'] - sim.now) if (x is not None and x.start is not None) else bounds['X']
                    if remaining <= 8:
                        sim.cancel(it['needs'][1], it['id'])
                r = Sim(2, lat, dict(order='required_first'), bounds).run(ints, hooks=dict(on_intent=hook))
                for k in tot:
                    tot[k] += r[k]
            rows.append(dict(shared_first_attempt_fails=fail_first, policy=pol, **tot))
    return dict(i03_grid_rows=len(base['rows']), failure_variant=rows,
                conclusion='bounded bypass decides from the declared remaining bound; a late failure of the shared '
                           'task invalidates the bound (the declared bound covers one attempt), so bypass is the only '
                           'policy that limits first-result delay under shared failure; it never saves work')


# ------------------------------------------------------------------ X22 value reuse x cross-owner re-sign
class MigratingSession(StrongSession):
    """On rebind, previous certificates are kept as *unsigned* candidates; certify() re-issues one
    (new handle bound to the new guard/epoch) only if every support read is equal under the new owner.
    Publications and confirmations never migrate (Session.rebind clears them)."""

    def __init__(self, case, **kw):
        super().__init__(case, **kw)
        self._migr = {}

    def rebind(self, case, **kw):
        old = {c['target']: c for c in self._certs.values()}
        super().rebind(case, **kw)
        self._migr = old

    # fix round (LC): additive lifecycle hooks, no behaviour change
    def residency(self):
        return len(self._migr) + (super().residency() if hasattr(super(), 'residency') else 0)

    def close(self):
        super().close()
        self._migr = {}

    def certify(self, target, *, mode='L0', budget=None):
        c = self._migr.get(target)
        if c is not None:
            idx = self.owner._index()
            if all(typed(v) == typed(self.owner._read(idx, k)) for k, v in c['support'].items()):
                self._next_certificate += 1
                h = self._next_certificate
                self._certs[h] = dict(target=target, unit=deepcopy(c['unit']), guard=self.owner._guard(),
                                      epoch=self.epoch, support=dict(c['support']))
                self.metrics['migrated_certificates'] += 1
                del self._migr[target]
                return dict(status='certified', unit=deepcopy(c['unit']), needs=[], failures={}, first=None, steps=0,
                            dependent_items=[], certificate=h, route='migrated')
            del self._migr[target]
        return super().certify(target, mode=mode, budget=budget)


class MigratingValueSession(MigratingSession, H.ValueCacheSession):
    pass


def x22():
    out = {}
    for mode in ('fresh', 'carry'):
        for label, cls in (('0', StrongSession), ('A_value', H.ValueCacheSession), ('B_migrate', MigratingSession),
                           ('AB', MigratingValueSession)):
            tot = dict(physical_admissions=0, certification_steps=0, migrated=0, latency=0, wrong=0, wrong_current=0)
            for seed in range(6):
                tr = W.random_partial(100 + seed, n=16, pa=0.5, pe=0.5, count=16)
                evs = list(tr['events']) + [dict(at=at, op='rebind') for at in (45, 95, 145)]
                tr2 = dict(tr, events=sorted(evs, key=lambda e: e['at']))
                rr = R.RunnerH(tr2, session_cls=cls, policy='incumbent', service_u=3)
                if mode == 'fresh':
                    init = deepcopy(tr['initial']); orig = rr._custom

                    def custom(ev, rr=rr, init=init, orig=orig):
                        if ev['op'] == 'rebind':
                            rr.session.rebind(deepcopy(init)); rr.audit['rebinds'] += 1
                            for kk in list(rr.first_pub):
                                rr.first_pub.pop(kk); rr.intent[kk] = rr.now
                            return
                        orig(ev)
                    rr._custom = custom
                r = rr.run()
                s = rr.session
                tot['physical_admissions'] += r['physical_admissions']
                tot['certification_steps'] += s.metrics['certification_steps']
                tot['migrated'] += s.metrics['migrated_certificates']
                tot['latency'] += r['total_latency_u']; tot['wrong'] += r['wrong']; tot['wrong_current'] += r['wrong_current']
            out[f'{mode}_{label}'] = tot
        g = [out[f'{mode}_{x}'] for x in ('0', 'A_value', 'B_migrate', 'AB')]
        out[f'{mode}_interaction'] = interaction(*g)
    out['conclusion'] = ('fresh rebind (knowledge lost): value reuse removes physical work, migration finds no equal '
                         'support; carry rebind: migration skips proofs, value reuse has little to serve; the two are '
                         'complementary; publication/confirmation authority never migrates in any group')
    return out


# ------------------------------------------------------------------ X23 dynamic reservation x low-confidence speculation
def x23(seeds=range(4)):
    rows = []
    for seed in seeds:
        for pattern in ('forward', 'jump', 'drift'):
            seq = ES.target_seq(pattern, seed=seed)
            lat = {f'w{i}': latent(seed, f'w{i}', 0, 3, 8) for i in range(30)}
            bounds = dict(lat)          # honest declared bound = service latent
            for spec in ('none', 'gate', 'gate3'):
                for res_pol in ('none', 'fixed1', 'dyn5'):
                    hist, acc, budget = [], [], [30 if spec != 'gate3' else 90]

                    def hook(sim, it, spec=spec, hist=hist, acc=acc, budget=budget):
                        tgt = it['tgt']
                        if hist:
                            acc.append(1 if hist[-1][1] == tgt else 0)
                        pred = None
                        if len(hist) >= 2:
                            pred = (tgt + (hist[-1][0] - hist[-2][0])) % 30
                        hist.append((tgt, pred))
                        if spec == 'none' or pred is None or budget[0] <= 0:
                            return
                        recent = acc[-6:]
                        if len(recent) < 4 or sum(recent) < len(recent) - 1:
                            return
                        step = hist[-1][0] - hist[-2][0]
                        for d in range(1, 4 if spec == 'gate3' else 2):
                            if budget[0] <= 0:
                                break
                            budget[0] -= 1
                            sim.request(f'w{(tgt + d * step) % 30}', False, f'spec{len(hist)}_{d}')
                    pol = dict(order='required_first', retain=6)
                    if res_pol == 'fixed1':
                        pol.update(reserve=1)
                    if res_pol == 'dyn5':
                        pol.update(reserve=1, dyn_reserve_bound=5)
                    ints = [dict(at=3 * k, id=k, tgt=tg, needs=[f'w{tg}'], required=True) for k, tg in enumerate(seq)]
                    r = Sim(2, lat, pol, bounds).run(ints, hooks=dict(on_intent=hook))
                    rows.append(dict(seed=seed, pattern=pattern, speculation=spec, reservation=res_pol,
                                     required_total=r['required_total'], required_max=r['required_max'],
                                     starts=r['starts'], wasted_u=r['wasted_u'],
                                     spec_used=(30 if spec != 'gate3' else 90) - budget[0]))
    return dict(rows=rows, note='C=2; gate = 1-step lookahead, gate3 = 3-step lookahead; fixed1 caps optional '
                                'holdings at C-1; dyn5 lets optional borrow the reserved slot iff its declared '
                                'bound (= latent, 3..8) <= 5')


# ------------------------------------------------------------------ X24 micro-batch x aging
def x24(seed=8):
    rng = random.Random(seed)
    lat, ints = {}, []
    t = 0
    for k in range(60):
        t += rng.choice((1, 2))
        x = f'm{k}'
        req = rng.random() < 0.7
        lat[x] = latent(seed, x, 0, 1, 3) if (k % 11) else 20
        ints.append(dict(at=t, id=k, needs=[x], required=req))
    rows = []
    for batch in (None, dict(size=4, setup=3, per_item=None, barrier=False, max_wait=4),
                  dict(size=4, setup=3, per_item=None, barrier=True, max_wait=4)):
        for ab in (None, 30, 10):
            pol = dict(order='aging' if ab is not None else 'required_first', aging_bound=ab, batch=batch)
            lat_used = lat if batch else {x: v + 3 for x, v in lat.items()}   # immediate pays setup per task
            r = Sim(1, lat_used, pol).run(ints)
            rows.append(dict(batch=None if batch is None else ('barrier' if batch['barrier'] else 'per_item'),
                             aging_bound=ab, required_p95=r['required_p95'], required_max=r['required_max'],
                             optional_max=r['optional_max'], required_total=r['required_total'], end_u=r['end_u']))
    return dict(rows=rows, note='C=1, setup 3u; aging applied at task level inside batch selection (target-level '
                                'fairness); a barrier batch containing the 20u slow member delays every member')


# ------------------------------------------------------------------ X25 debounce x negative evidence cache
def x25():
    """A fact whose service fails transiently for the first f attempts (keyed by identity+attempt)."""
    rows = []
    for f in (0, 1, 3):
        for permanent_fraction in (0.0,):
            for pol in ('retry_immediate', 'debounce_w5', 'reason_cache_backoff', 'mutant_cache_transient_as_permanent',
                        'debounce+reason'):
                t, attempts, done = 0, 0, None
                S = 4
                cache_block_until = -1
                for k in range(50):
                    if pol == 'mutant_cache_transient_as_permanent' and attempts >= 1 and done is None and k > 0:
                        break                      # never retries again
                    start = t
                    if pol.startswith('debounce'):
                        start = t + 5
                    if 'reason' in pol and start < cache_block_until:
                        start = cache_block_until
                    attempts += 1
                    end = start + S
                    if attempts > f:
                        done = end
                        break
                    t = end
                    if 'reason' in pol:
                        cache_block_until = end + 2 * attempts       # transient: exponential-ish backoff, never permanent
                rows.append(dict(transient_failures=f, policy=pol, attempts=attempts, completed_at=done,
                                 progress=done is not None))
    return dict(rows=rows, conclusion='caching a transient failure as permanent stops progress (counterexample); '
                                      'debounce adds its window to every retry; a reason-keyed backoff bounds attempts '
                                      'without blocking forever; combining debounce with backoff double-charges the wait')


# ------------------------------------------------------------------ X29 protocol induction x revision saturation
def x29(depth=8):
    """Small-width owner memo model with rebind (new incarnation) events: B rebinds (memo cleared,
    incarnation+1), W relevant write, N unrelated write, R request.  Width 2."""
    maxv = 3
    res = {}
    for mode in ('wrap', 'saturate_exact', 'incarnation_rebuild_on_saturation'):
        stale = 0
        checks = 0
        for seq in itertools.product('WNRB', repeat=depth):
            rev, inc, memo, sv = 0, 0, None, 0
            for e in seq:
                if e == 'B':
                    inc += 1; rev = 0; memo = None; continue
                if e in 'WN':
                    sv += e == 'W'
                    if mode == 'wrap':
                        rev = (rev + 1) & maxv
                    elif mode == 'saturate_exact':
                        rev = min(maxv, rev + 1)
                    else:
                        if rev == maxv:
                            inc += 1; rev = 0
                        else:
                            rev += 1
                    continue
                if memo is not None:
                    fast = memo[0] == rev and memo[1] == inc and not (mode == 'saturate_exact' and rev == maxv)
                    if fast:
                        stale += memo[2] != sv
                        continue
                    checks += 1
                    if memo[2] == sv:
                        memo = (rev, inc, sv); continue
                memo = (rev, inc, sv)
        res[mode] = dict(stale_hits=stale, exact_checks=checks)
    res['induction'] = ('per-entry invariant: a fast hit requires (rev, incarnation) equal to the stored stamp and rev '
                        'not saturated; every relevant write strictly increases rev or the incarnation, and both '
                        'never revisit a value under saturate/incarnation modes -> no stale hit for any number of '
                        'entries/requests; wrap revisits values after 2^w writes (counterexample at w=2, depth 8)')
    return res


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    res = dict(X07=x07(), X08=x08(), X16=x16(), X22=x22(), X23=x23(), X24=x24(), X25=x25(), X29=x29())
    (OUT / 'combos.json').write_text(json.dumps(res, indent=1, default=str))
    return res


if __name__ == '__main__':
    r = main()
    print(json.dumps({k: v for k, v in r.items() if k in ('X07', 'X08', 'X22', 'X25', 'X29')}, indent=1, default=str)[:5000])
