"""Fix round, item 3: runner-level lifecycle of gated_shadow / shadow (+ rule gate) (tag LC).

`LifeShadowRunner` is wpA_lib.ShadowRunner verbatim (its drive / proof start /
proof delivery / publish / rebind are inherited, not re-implemented); only the
event loop is extended with harness events:
  churn(item)        re-delivery of an equal analysis with a new version label (touches support)
  admit_edge(a)      world-true rank of edge a (untouched when outside the support)
  confirm(t)         confirmation callback for the harness-recorded publication handle
  late_confirm(t)    callback carrying the publication handle seen BEFORE the last rebind
  cancel_item(i)     harness cancellation of a running task
  rebind(item, witness)  wpA_lib content-replacement rebind (inherited _rebind)
  reintent(t)        a new intent for an already-published target (expired publication)
  close              harness close protocol (see fixLC_lifecycle): no new drive, every task
                     cancelled and run to its real exit, then owner.close(), store clearing
Every event row records the session post-state.
"""
import heapq
import json
from copy import deepcopy

import paths  # noqa: F401
import workloads as W
from coupling import Witness
from current_baseline import typed
from strong import StrongSession
from wpA_lib import ShadowRunner, PersistentStrongSession
from fixLC_lifecycle import compose_bound


class LifeShadowRunner(ShadowRunner):
    def __init__(self, trace, *, bound=False, fixed=False, incumbent_drive=False, **kw):
        super().__init__(trace, **kw)
        self.fixed = fixed                      # lifecycle-completed variant (attempt identity + re-intent)
        self.incumbent_drive = incumbent_drive  # ARunner incumbent controller, for the E6 comparison
        if bound:
            cls = compose_bound(type(self.session))
            old = self.session
            self.session = cls(deepcopy(trace['initial']), capacity=old.capacity, raw_capacity=old.raw_capacity,
                               strong=dict(old.strong))
        self.bound = bound
        self.closed = False
        self.rows = []
        self.handles = {}
        self.handles_before_rebind = {}

    def _row(self, op, args, ret):
        s = self.session
        pub = s._published if self.closed else s.published
        conf = s._confirmed if self.closed else s.confirmed
        self.rows.append(dict(t=self.now, op=op, args=args, ret=ret, occupied=s.occupied, raw=s.raw_size,
                              certs=s.certificate_count, published=sorted(pub), confirmed=sorted(conf),
                              proof_inflight=sorted(self.proof_inflight), first_pub=dict(self.first_pub),
                              residency=self.residency()))

    def residency(self):
        return len(self.l0_pending) + len(self.pending) + len(self.proof_inflight) + len(self.republish)

    def _publish_proof(self, target, verdict):
        r = super()._publish_proof(target, verdict)
        self._row('publish', dict(target=target, route=verdict.get('route', 'L0')), r)
        if r == 'published':
            self.handles[target] = verdict['certificate']
        return r

    def _publish(self, target, verdict):            # ARunner publish path (incumbent comparison)
        r = super()._publish(target, verdict)
        self._row('publish', dict(target=target, route=verdict.get('route', 'L0')), r)
        if r == 'published':
            self.handles[target] = verdict['certificate']
        return r

    def drive(self):
        if self.closed:
            return
        before = dict(self.session._published_handles)
        if self.incumbent_drive:
            from wpA_lib import ARunner
            ARunner.drive(self)
        else:
            super().drive()
        for t, h in self.session._published_handles.items():   # L0 refresh path publishes directly
            if before.get(t) != h:
                self.handles[t] = h

    def _confirm(self, t, handle):
        s = self.session
        return s.confirm(t, handle) if self.bound else s.confirm(t)

    def run_life(self, max_steps=20000):
        for ev in self.trace['events']:
            self._push(ev['at'], 'ext', ev)
        steps = 0
        while self.q:
            t, _s, kind, payload = heapq.heappop(self.q)
            steps += 1
            if steps > max_steps:
                self._row('livelock_guard', {}, steps)
                break
            self.now = t
            if kind == 'service':
                token, i = payload
                self.scheduled.discard(token)
                if token in self.session._tasks:
                    fr = self.session.finish(token, self.world.complete(i))
                    cr = self.session.consume(token) if fr == 'completed' else None
                    self._row('exit', dict(item=i, issuance=token.issuance), [fr, cr])
                self.drive()
            elif kind == 'proof':
                tt, cls, v, rev = payload
                if self.closed:
                    self._row('proof_after_close_ignored', dict(target=tt), None)
                elif tt in self.proof_inflight and self.fixed and self.proof_inflight[tt] != t:
                    self._row('proof_stale_attempt_dropped', dict(target=tt, due=t, current_due=self.proof_inflight[tt]), None)
                elif tt in self.proof_inflight:
                    self._finish_proof(tt, cls, v=v, rev_at_start=rev)
                    self._row('proof_delivered', dict(target=tt, status=v['status'], route=v.get('route')), None)
                else:
                    self._row('proof_dropped', dict(target=tt), None)
                self.drive()
            else:
                ev = payload
                op = ev['op']
                if self.closed and op != 'probe_after_close':
                    self._row('event_after_close_ignored', dict(op=op), None)
                    continue
                if op in ('target', 'reintent') and getattr(self, '_fixed_intent_hook', None) is not None:
                    tt = ev['target']                  # main-session F2 (fix_main_shadow): physical mirroring
                    self._row(op, dict(target=tt), self._fixed_intent_hook(tt, t))
                elif op in ('target', 'reintent'):
                    tt = ev['target']
                    self.intent.setdefault(tt, t)
                    if self.fixed and tt in self.first_pub and tt not in self.session.published:
                        self.republish.setdefault(tt, t)         # expired publication: request it again
                        if tt not in self.pending:
                            self.pending.append(tt)
                    if tt not in self.first_pub and tt not in self.pending:
                        self.pending.append(tt)
                    self._row(op, dict(target=tt), tt in self.pending)
                elif op == 'churn':
                    i = ev['item']
                    a = deepcopy(self.session.owner._case['items'][i]['analysis']); a['version'] = a.get('version', 0) + 100
                    self._row('churn', dict(item=i), self.session.owner.apply(item_updates={i: {'analysis': a}}))
                elif op == 'admit_edge':
                    a = ev['edge']; w = self.world_w
                    rec = dict(status='computed', score=abs(w[a]['raw'] - w[a + 1]['raw']), version=1)
                    self._row('admit_edge', dict(edge=a), self.session.owner.apply(edge_updates={(a, a + 1): rec}))
                elif op == 'confirm':
                    tt = ev['target']
                    self._row('confirm', dict(target=tt), self._confirm(tt, self.handles.get(tt)))
                elif op == 'late_confirm':
                    tt = ev['target']
                    self._row('late_confirm', dict(target=tt), self._confirm(tt, self.handles_before_rebind.get(tt)))
                elif op == 'prefetch':
                    tk = self.session.acquire(ev['item'], required=False)
                    self._row('prefetch', dict(item=ev['item']), None if tk is None else tk.issuance)
                elif op == 'cancel_item':
                    self._row('cancel_item', dict(item=ev['item']), self.session.cancel_item(ev['item']))
                elif op == 'rebind':
                    self.handles_before_rebind = dict(self.handles)
                    self._rebind(ev)
                    self._row('rebind', dict(item=ev['item']), 'ok')
                elif op == 'close':
                    self._close()
                    continue
                elif op == 'probe_after_close':
                    s = self.session
                    tt = ev['target']
                    try:
                        s.certify(tt, mode='L0'); cert = 'accepted'
                    except Exception as e:  # noqa: BLE001
                        cert = type(e).__name__
                    self._row('probe_after_close', dict(target=tt),
                              dict(confirm=self._confirm(tt, self.handles.get(tt)),
                                   publish=s.publish(tt, self.handles.get(tt, -1)), certify=cert))
                    continue
                self.drive()
            self._sched()
        return self.rows

    def _close(self):
        s = self.session
        for tk in list(s._tasks):
            s.cancel(tk)
        self.closed = True
        self.pending.clear(); self.l0_pending.clear(); self.proof_inflight.clear(); self.republish.clear()
        self._row('close_begin', {}, dict(occupied=s.occupied))
        # run the remaining running tasks to their real exit (service events stay queued)
        while any(task['phase'] == 'running' for task in s._tasks.values()):
            t, _s, kind, payload = heapq.heappop(self.q)
            self.now = t
            if kind == 'service':
                token, i = payload
                if token in s._tasks:
                    self._row('exit_after_close', dict(item=i), s.finish(token, self.world.complete(i)))
            else:
                self._push(t, kind, payload) if kind == 'ext' else None
                if kind == 'proof':
                    self._row('proof_after_close_ignored', dict(target=payload[0]), None)
                if kind == 'ext':
                    break
        s.owner.close()
        s._raw.clear(); s._certs.clear(); s._published.clear(); s._confirmed.clear(); s._published_handles.clear()
        hook = getattr(s, 'close', None)
        if callable(hook):
            hook()
        self._row('close_end', {}, dict(occupied=s.occupied, raw=s.raw_size, certs=s.certificate_count))


HOLES = (13, 20, 28)


def fixture_trace():
    """W01 seed 0 (n=32) with rank holes at 13, 20, 28 (world unchanged)."""
    tr = W.w01_phase_chain(0)
    tr = deepcopy(tr)
    tr['initial']['edges'] = [e for e in tr['initial']['edges'] if e['first'] not in HOLES]
    return tr


def script(variant, rebind_item=13):
    """Scripted lifecycle, service 4u, proof 2u.  E1/E2 target 12 (hole 13); E3 target 19
    (hole 20, cancel item 21); E6 churn on 12 + reintent; E4 prefetch 3 + target 27 (hole 28,
    proof and tasks in flight) then content rebind of item 13; late/current confirm; E5
    target 4 (hole 5) in flight, then close and a probe."""
    ev = [dict(at=0, op='target', target=12)]
    if variant == 'touched':
        ev.append(dict(at=1, op='churn', item=12))           # proof in flight (due 2) -> stale at delivery
    elif variant == 'untouched':
        ev.append(dict(at=1, op='admit_edge', edge=28))      # outside support [0,15] -> proof publishes at 2
    ev += [dict(at=10, op='confirm', target=12),
           dict(at=11, op='target', target=19), dict(at=12, op='cancel_item', item=21),
           dict(at=40, op='churn', item=12),                  # E6: publication of 12 expires
           dict(at=41, op='reintent', target=12),
           dict(at=58, op='prefetch', item=3),
           dict(at=59, op='target', target=27),
           dict(at=60, op='rebind', item=rebind_item, witness=None),   # E4 with proof + tasks in flight
           dict(at=90, op='late_confirm', target=12),
           dict(at=91, op='confirm', target=12),
           dict(at=99, op='prefetch', item=2), dict(at=100, op='target', target=4), dict(at=101, op='close'),
           dict(at=200, op='probe_after_close', target=12)]
    return ev


def run_shadow(policy='gated_shadow', variant='touched', bound=False, persistent=False, rebind_item=13,
               fixed=False, incumbent_drive=False, runner_cls=None):
    tr = fixture_trace()
    evs = script(variant, rebind_item)
    for e in evs:
        if e['op'] == 'rebind':
            e['witness'] = deepcopy(tr['world'][e['item']])
    tr = dict(tr, events=evs)
    r = (runner_cls or LifeShadowRunner)(tr, policy=policy, service_u=4, q_u=2, bound=bound, persistent=persistent,
                                         fixed=fixed, incumbent_drive=incumbent_drive)
    rows = r.run_life()
    return r, rows


def evaluate(r, rows, variant):
    """Group checks from the event log (same group names as the session-level harness)."""
    chk = []

    def c(group, name, ok, detail=None):
        chk.append(dict(group=group, name=name, ok=bool(ok), detail=detail))

    pubs12 = [x for x in rows if x['op'] == 'publish' and x['args']['target'] == 12]
    first12 = r.first_pub.get(12)
    if variant == 'touched':
        c('E2', 'stale_proof_rejected', any(x['args']['route'].startswith('strong') and x['ret'] == 'stale' for x in pubs12),
          [(x['t'], x['args']['route'], x['ret']) for x in pubs12])
        c('E2', 'request_completes', first12 is not None, first12)
    elif variant == 'untouched':
        c('E2', 'untouched_proof_accepted', any(x['args']['route'].startswith('strong') and x['ret'] == 'published'
                                                and x['t'] == 2 for x in pubs12), [(x['t'], x['ret']) for x in pubs12])
    c('E1', 'first_legal_publication', first12 is not None, first12)
    conf = [x for x in rows if x['op'] == 'confirm']
    c('E1', 'confirm_current', conf and conf[0]['ret'] == 'confirmed', conf and conf[0]['ret'])
    canc = [x for x in rows if x['op'] == 'cancel_item']
    c('E3', 'cancel_marks_cancelling', canc and canc[0]['ret'] == 'cancelling', canc and canc[0]['ret'])
    c('E3', 'slot_held_after_cancel', canc and canc[0]['occupied'] >= 2, canc and canc[0]['occupied'])
    ex21 = [x for x in rows if x['op'] == 'exit' and x['args']['item'] == 21 and x['t'] <= 15]
    c('E3', 'cancelled_exit_discarded', ex21 and ex21[0]['ret'][0] == 'discarded', ex21 and ex21[0]['ret'])
    c('E3', 'request_after_cancel_completes', 19 in r.first_pub, r.first_pub.get(19))
    exp = [x for x in rows if x['op'] == 'churn' and x['t'] == 40]
    c('E6', 'old_publication_expires', exp and 12 not in exp[0]['published'], exp and exp[0]['published'])
    after = [x for x in rows if 41 <= x['t'] < 60]
    re = any(12 in x['published'] for x in after)
    c('E6', 'reobtained_after_invalidation', re,
      'ok' if re else 'runner treats the first publication as completion; reintent ignored until a rebind')
    post = [x for x in rows if 60 < x['t'] <= 61 and x['op'] in ('proof_delivered', 'proof_dropped',
                                                                 'proof_stale_attempt_dropped')]
    if variant != 'untouched':                     # untouched admits edge 28: no proof in flight at the rebind
        c('E4', 'old_epoch_proof_event_not_delivered', all(x['op'] != 'proof_delivered' for x in post),
          [(x['t'], x['op'], x['args']) for x in post])
        newp = [x for x in rows if x['op'] == 'proof_started_new_epoch']
    pubs27 = [x for x in rows if x['op'] == 'publish' and x['args']['target'] == 27]
    if variant != 'untouched':
        c('E4', 'old_epoch_result_never_published', not any(x['t'] <= 61 and x['ret'] == 'published' for x in pubs27),
          [(x['t'], x['args']['route'], x['ret']) for x in pubs27])
    oldex = [x for x in rows if x['op'] == 'exit' and 60 < x['t'] <= 63]
    c('E4', 'old_epoch_late_exits_discarded', oldex and all(x['ret'][0] == 'discarded' for x in oldex),
      [(x['args']['item'], x['ret']) for x in oldex])
    late = [x for x in rows if x['op'] == 'late_confirm']
    c('E4', 'old_callback_rejected_after_republish', late and late[0]['ret'] != 'confirmed', late and late[0]['ret'])
    cur = [x for x in rows if x['op'] == 'confirm' and x['t'] == 91]
    c('E4', 'current_callback_confirms', cur and cur[0]['ret'] == 'confirmed', cur and cur[0]['ret'])
    c('E4', 'reissued_requests_complete', all(t in r.first_pub for t in (12, 19, 27)) and
      all(any(x['op'] == 'publish' and x['args']['target'] == t and x['ret'] == 'published'
              for x in rows[[k for k, y in enumerate(rows) if y['op'] == 'rebind'][0]:])
          for t in (12, 19, 27)), sorted(r.first_pub))
    cb = [x for x in rows if x['op'] == 'close_begin']
    c('E5', 'tasks_running_at_close', cb and cb[0]['occupied'] > 0, cb and cb[0]['occupied'])
    eac = [x for x in rows if x['op'] == 'exit_after_close']
    c('E5', 'running_tasks_exit_after_close_discarded', eac and all(x['ret'] == 'discarded' for x in eac),
      [x['ret'] for x in eac])
    ce = [x for x in rows if x['op'] == 'close_end']
    c('E5', 'released_after_close', ce and ce[0]['ret'] == dict(occupied=0, raw=0, certs=0), ce and ce[0]['ret'])
    c('E5', 'runner_residency_zero', ce and ce[0]['residency'] == 0, ce and ce[0]['residency'])
    pr = [x for x in rows if x['op'] == 'probe_after_close']
    c('E5', 'late_calls_rejected', pr and pr[0]['ret']['confirm'] != 'confirmed' and pr[0]['ret']['publish'] != 'published'
      and pr[0]['ret']['certify'] != 'accepted', pr and pr[0]['ret'])
    c('LV', 'no_wrong_publication', r.wrong == 0, r.wrong)
    c('LV', 'all_intents_published', set(r.intent) <= set(r.first_pub), sorted(set(r.intent) - set(r.first_pub)))
    return chk
