"""Fix round, item 3: per-mechanism D4 lifecycle harness (tag LC).

`Life` drives ONE Session-based mechanism through scripted, event-by-event
lifecycles on coupling-style virtual time (integer u; every running physical
task exits `service_u` after admission; nothing is preempted).  Every public
call is logged with its return value and the post-state (occupied, raw_size,
certificate_count, published / confirmed keys, candidate residency).

Event groups (all executed for every mechanism):
  E1 publish + confirm; the request reaches its first legal publication
  E2 evidence admitted while a proof is "in flight" (certificate computed at
     revision r, publication attempted later): touched support -> rejected,
     untouched -> accepted; the request still completes
  E3 cancel: the running task keeps its slot until its real exit; the
     cancelled result is never admitted; the slot is released at exit
  E4 rebind: old-epoch late finish rejected, old certificate unusable, old
     confirm callbacks rejected (before AND after re-publication), re-issued
     request completes in the new epoch and equals a fresh session's result
  E5 close (harness protocol, see `close`): every task reaches its real exit,
     then owner.close() and candidate close(); occupied/raw/certificates/
     publications/candidate residency all 0; late finish / confirm / publish /
     certify after close rejected; tracemalloc retained bytes recorded
  E6 invalidation: old certificate rejected after a support change AND the
     mechanism re-obtains a legal, truthful publication
  LV liveness: a list of intents on fixed traces is fully published and
     confirmed with truthful units

Close protocol.  The package Session has no close().  Owner.close() sets
_case=None, so finish() of a *non-cancelled* running task after owner.close()
crashes inside Session._current (TypeError) -- demonstrated by
`naive_close_crash`.  Harness protocol: (1) stop issuing intents; (2) cancel
every task (completed ones are discarded and released immediately, running
ones become 'cancelling'); (3) advance time until every running task has
really exited (finish -> 'discarded', slot released); (4) owner.close();
(5) clear the Session's raw/certificate/publication stores (package has no API
for this -- a native session close is an interface requirement); (6) call the
candidate's close() hook.
"""
import gc
import json
import tracemalloc
from copy import deepcopy

import paths  # noqa: F401
from coupling import Session, World, Witness
from coupled_runner import truth_units, world_case
from current_baseline import typed


# --------------------------------------------------------------------------- composition helper

class BoundMixin:
    """bound_confirm semantics (wpH_commit.BoundConfirmSession) as a mixin, so it can be
    composed with any mechanism: the callback must name the publication it saw."""

    def confirm(self, target, handle=None):
        if handle is None:
            return 'unbound'
        if target not in self._published or self._published_handles.get(target) != handle:
            return 'stale_callback'
        return super().confirm(target)


def compose_bound(cls):
    return type(cls.__name__ + '+bound', (BoundMixin, cls), {})


# --------------------------------------------------------------------------- harness

def _keys(d):
    return sorted(int(k) for k in d)


class Life:
    def __init__(self, spec, trace, *, service_u=3, capacity=3, raw_capacity=3, bound=None):
        self.spec = spec
        self.mode = spec.get('mode', 'L0')
        self.bound = spec.get('bound', False) if bound is None else bound
        cls = spec['cls']
        if self.bound and not spec.get('native_bound', False):
            cls = compose_bound(cls)
        self.cls = cls
        self.trace = trace
        self.world_w = deepcopy(trace['world'])
        self.world = World([Witness(**w) for w in self.world_w])
        self.initial = deepcopy(trace['initial'])
        self.truth = truth_units(self.initial, self.world_w)
        self.service_u = service_u
        self.s = cls(deepcopy(trace['initial']), capacity=capacity, raw_capacity=raw_capacity, **spec.get('kw', {}))
        self.now = 0
        self.due = {}                    # running token -> exit time
        self.rows = []
        self.pubh = {}                   # target -> handle of the publication the harness saw
        self.closed = False

    # ---- logging
    def residency(self):
        f = getattr(self.s, 'residency', None)
        return f() if callable(f) else None

    def _state(self):
        s = self.s
        if self.closed:
            return dict(occupied=s.occupied, raw=s.raw_size, certs=s.certificate_count,
                        published=_keys(s._published), confirmed=_keys(s._confirmed), residency=self.residency())
        return dict(occupied=s.occupied, raw=s.raw_size, certs=s.certificate_count,
                    published=_keys(s.published), confirmed=_keys(s.confirmed), residency=self.residency())

    def log(self, op, args, ret):
        if isinstance(ret, dict):
            r = {k: ret.get(k) for k in ('status', 'route', 'certificate', 'steps')}
        else:
            r = ret if isinstance(ret, (str, int, float, bool, type(None))) else repr(ret)
        row = dict(t=self.now, op=op, args=args, ret=r)
        row.update(self._state())
        self.rows.append(row)
        return ret

    def _track(self):
        for tk, task in self.s._tasks.items():
            if task['phase'] == 'running' and tk not in self.due:
                self.due[tk] = self.now + self.service_u
        for tk in list(self.due):
            if tk not in self.s._tasks:
                del self.due[tk]

    # ---- primitives
    def acquire(self, i, required=True):
        tk = self.s.acquire(i, required=required)
        self._track()
        self.log('acquire', dict(item=i, required=required), None if tk is None else tk.issuance)
        return tk

    def exit_task(self, tk):
        """Real physical exit of a running task: finish + consume (consume only if completed)."""
        task = self.s._tasks.get(tk)
        item = task['item'] if task else None
        fr = self.s.finish(tk, self.world.complete(item)) if item is not None else self.s.finish(tk, None)
        self.log('finish', dict(issuance=tk.issuance, item=item), fr)
        cr = None
        if fr == 'completed':
            cr = self.s.consume(tk)
            self.log('consume', dict(issuance=tk.issuance, item=item), cr)
        self.due.pop(tk, None)
        self._track()
        return fr, cr

    def advance(self, until=None):
        """Advance to `until` (or the next exit), running every due exit in (due, issuance) order."""
        if until is None:
            if not self.due:
                return False
            until = min(self.due.values())
        while True:
            ready = sorted((d, tk.issuance, tk) for tk, d in self.due.items() if d <= until)
            if not ready:
                break
            d, _, tk = ready[0]
            self.now = max(self.now, d)
            self.exit_task(tk)
        self.now = max(self.now, until)
        return True

    def certify(self, t, mode=None):
        v = self.s.certify(t, mode=mode or self.mode)
        return self.log('certify', dict(target=t, mode=mode or self.mode), v)

    def publish(self, t, handle):
        r = self.s.publish(t, handle)
        if r == 'published':
            self.pubh[t] = handle
        return self.log('publish', dict(target=t, handle=handle), r)

    def confirm(self, t, handle='current'):
        if handle == 'current':
            handle = self.pubh.get(t)
        r = self.s.confirm(t, handle) if self.bound else self.s.confirm(t)
        return self.log('confirm', dict(target=t, handle=handle, bound=self.bound), r)

    def cancel(self, tk):
        r = self.s.cancel(tk)
        self._track()
        return self.log('cancel', dict(issuance=tk.issuance), r)

    def admit(self, *, item=None, edge=None, version_bump=None, edge_version_bump=None):
        """Harness evidence write that is consistent with the hidden world."""
        wc = world_case(self.initial, self.world_w)
        if item is not None:
            r = self.s.owner.apply(item_updates={item: {'analysis': deepcopy(wc['items'][item]['analysis'])}})
            args = dict(item=item)
        elif edge is not None:
            rec = next(e for e in wc['edges'] if e['first'] == edge)
            r = self.s.owner.apply(edge_updates={(edge, edge + 1): {k: v for k, v in rec.items() if k not in ('first', 'second')}})
            args = dict(edge=edge)
        elif version_bump is None and edge_version_bump is not None:   # equal rank, new version label
            a, b = edge_version_bump, edge_version_bump + 1
            rec = deepcopy(self.s.owner._edges[(a, b)])
            rec['version'] = rec.get('version', 0) + 100
            r = self.s.owner.apply(edge_updates={(a, b): {k: v for k, v in rec.items() if k not in ('first', 'second')}})
            args = dict(edge_version_bump=a)
        else:                             # re-delivery of an equal fact with a new version label
            a = deepcopy(self.s.owner._case['items'][version_bump]['analysis'])
            a['version'] = a.get('version', 0) + 100
            r = self.s.owner.apply(item_updates={version_bump: {'analysis': a}})
            args = dict(version_bump=version_bump)
        return self.log('admit', args, r)

    def rebind(self, case=None):
        case = deepcopy(self.s.observe()) if case is None else case
        self.s.rebind(case)
        self.pubh_old = dict(self.pubh)
        self.pubh = {}
        self._track()
        return self.log('rebind', {}, 'ok')

    def drive(self, t, limit=400, confirm=False):
        """Generic controller (needs -> acquisitions; certified -> publish) until the
        first legal publication of t; returns (published, verdict)."""
        for _ in range(limit):
            v = self.certify(t)
            if v['status'] == 'certified':
                if self.publish(t, v['certificate']) == 'published':
                    if confirm:
                        self.confirm(t)
                    return True, v
            elif v['status'] in ('need_facts', 'blocked', 'budget'):
                items = []
                for nd in v.get('needs', []):
                    items.append(nd['item'])
                    if 'second' in nd:
                        items.append(nd['second'])
                items += [int(k) for k in (v.get('failures') or {})]
                for i in items:
                    if not any(task['item'] == i and not task['cancelled'] for task in self.s._tasks.values()):
                        self.acquire(i)
            if not self.advance():
                return False, v
        return False, None

    # ---- close protocol
    def close(self):
        s = self.s
        for tk in list(s._tasks):
            self.cancel(tk)
        while self.due:
            self.advance()
        assert s.occupied == 0
        s.owner.close()
        s._raw.clear(); s._certs.clear(); s._published.clear(); s._confirmed.clear(); s._published_handles.clear()
        hook = getattr(s, 'close', None)
        if callable(hook):
            hook()
        self.closed = True
        return self.log('close', {}, 'ok')

    def dump(self, path):
        with open(path, 'a') as fh:
            for r in self.rows:
                fh.write(json.dumps(dict(r, mechanism=self.spec['name'], bound=self.bound), default=str) + '\n')


def naive_close_crash(cls=Session, trace=None):
    """owner.close() with a non-cancelled running task, then its exit: package behaviour."""
    import workloads as W
    tr = trace or W.w01_phase_chain(0)
    s = cls(deepcopy(tr['initial']))
    tk = s.acquire(13)
    s.owner.close()
    try:
        r = s.finish(tk, Witness(**tr['world'][13]))
        return dict(crashed=False, finish=r, occupied=s.occupied)
    except Exception as e:  # noqa: BLE001 - this is the observation
        return dict(crashed=True, error=type(e).__name__ + ': ' + str(e)[:120], occupied=s.occupied)


def reachable_size(root):
    """Bytes (sys.getsizeof) of every object reachable from `root`, excluding modules, classes,
    functions and code (shared program objects).  Used after close to find hidden residuals."""
    import sys
    import types
    skip = (types.ModuleType, type, types.FunctionType, types.BuiltinFunctionType, types.CodeType,
            types.MethodType)
    seen, stack, total, count = set(), [root], 0, 0
    while stack:
        o = stack.pop()
        if id(o) in seen or isinstance(o, skip):
            continue
        seen.add(id(o))
        total += sys.getsizeof(o)
        count += 1
        stack.extend(gc.get_referents(o))
    return total, count
