"""WP-A: coupled L1 adoption runner, decisive-edge workloads, information policies.

Layers: coupled (coupling.Session/StrongSession, virtual units u) + local
measured ns of strong attempts (reported separately, never added to u).
Controllers use only admitted evidence (session.owner._case read-only view,
own verdicts, own task table); the World object is harness-only.

ARunner extends the main-session Runner idea with:
  * several pending intents (an intent stays pending until a legal publication),
  * one compute lane for strong proofs (proofs are serialised; proof time is
    q_u per attempt, or ceil(q_eval * evaluations) when q_model='eval'),
  * policies: incumbent | proof_first | race | gated | gated_race |
    when_waiting | adaptive | strong_only (q=0, labelled idealised),
  * acquisition orders: all | one | witness | analysis_first,
  * multi-target 'targets' events (joint batches, O01/X21).
"""
import heapq
import math
import random
from copy import deepcopy
from itertools import count

import paths  # noqa: F401
import reference as ref
from coupling import World, Witness
from strong import StrongSession, strong_attempt
from coupled_runner import truth_units
from common import fact, base_case

# --------------------------------------------------------------------------- workloads


def _chain_world(n, side_mix=False, rng=None, step_noise=False):
    """Strictly decreasing adjacent ranks under the scalar adapter: raw_i = sum of
    decreasing gaps, so rank(i,i+1) = n-i (plus optional noise keeping order)."""
    raws, x = [], 0
    for i in range(n):
        raws.append(x)
        x += (n - i) * 2 + (rng.randrange(0, 2) if (rng and step_noise) else 0)
    w = []
    for i in range(n):
        side = rng.choice(('A', 'B', 'UNKNOWN', 'UNKNOWN')) if (rng and side_mix) else 'UNKNOWN'
        w.append(dict(analysis=dict(status='computed', fact=fact('NARROW', side), version=1),
                      raw=raws[i], available=True))
    return w


def _rand_world(rng, n, p_wide=0.1, raw_max=12):
    w = []
    for i in range(n):
        st = 'WIDE' if rng.random() < p_wide else 'NARROW'
        side = rng.choice(('A', 'B', 'UNKNOWN', 'UNKNOWN'))
        w.append(dict(analysis=dict(status='computed', fact=fact(st, side), version=1),
                      raw=rng.randrange(0, raw_max), available=True))
    return w


def _edges(world, pairs):
    out = []
    for a in pairs:
        ra, rb = world[a]['raw'], world[a + 1]['raw']
        out.append(dict(first=a, second=a + 1, status='computed',
                        score=None if ra is None or rb is None else abs(ra - rb), version=1))
    return out


def initial_from(world, known_items, known_edges, automatic=True, direction='AB'):
    n = len(world)
    c = base_case(n, automatic=automatic, direction=direction)
    for i, it in enumerate(c['items']):
        it['header'] = deepcopy(world[i]['analysis']['fact'])
        it['header']['side'] = 'UNKNOWN'
        it['analysis'] = deepcopy(world[i]['analysis']) if i in known_items else {'status': 'unknown'}
    c['edges'] = _edges(world, sorted(known_edges))
    return c


def target_events(rng, n, pattern, count_, gap, start=0):
    t, d, out = rng.randrange(n), 1, []
    for k in range(count_):
        if pattern == 'sweep':
            t = (t + 1) % n
        elif pattern == 'jump':
            t = rng.randrange(n)
        elif pattern == 'roundtrip':
            if not 0 <= t + d < n:
                d = -d
            t += d
        out.append(dict(at=start + k * gap, op='target', target=t))
    return out


def reserved_eviction(seed, n=40, holes=(9,), pattern='sweep', count_=20, gap=10, side_mix=False):
    """ALGORITHM_FRONTIER 40-item reserved-eviction construction in the scalar adapter
    domain: all analyses admitted, decreasing prefix ranks reserve (8,9); the rank of
    the hole edge(s) was lost with its raw witnesses."""
    rng = random.Random(seed)
    world = _chain_world(n, side_mix=side_mix, rng=rng)
    init = initial_from(world, set(range(n)), [a for a in range(n - 1) if a not in set(holes)])
    ev = target_events(rng, n, pattern, count_, gap)
    return dict(name=f'RE_n{n}_h{len(holes)}_{pattern}_s{seed}', initial=init, world=world, events=ev)


def decisive_holes(seed, n=24, holes=4, kind='chain', pattern='sweep', count_=24, gap=10, p_wide=0.1):
    """All analyses admitted, `holes` ranks missing; holes placed on edges that the
    L0 verdict of some target actually needs (decided from the ADMITTED state only,
    before any policy runs)."""
    rng = random.Random(seed)
    world = _chain_world(n, side_mix=True, rng=rng, step_noise=True) if kind == 'chain' else _rand_world(rng, n, p_wide)
    full = initial_from(world, set(range(n)), list(range(n - 1)))
    cand = list(range(1, n - 2))
    rng.shuffle(cand)
    miss = set(cand[:holes])
    init = initial_from(world, set(range(n)), [a for a in range(n - 1) if a not in miss])
    ev = target_events(rng, n, pattern, count_, gap)
    return dict(name=f'DH_{kind}_n{n}_h{holes}_{pattern}_s{seed}', initial=init, world=world, events=ev)


def partial_mix(seed, n=24, pa=0.7, pe=0.6, pattern='sweep', count_=24, gap=10, p_wide=0.1, kind='rand'):
    rng = random.Random(seed)
    world = _chain_world(n, side_mix=True, rng=rng, step_noise=True) if kind == 'chain' else _rand_world(rng, n, p_wide)
    known = {i for i in range(n) if rng.random() < pa}
    edges = [a for a in range(n - 1) if rng.random() < pe]
    init = initial_from(world, known, edges)
    return dict(name=f'PM_{kind}_n{n}_pa{pa}_pe{pe}_{pattern}_s{seed}', initial=init, world=world,
                events=target_events(rng, n, pattern, count_, gap))


# Tuning families (used to choose gates / thresholds) and HELD-OUT families (never used).
def tuning_traces():
    out = []
    for s in range(4):
        out.append(reserved_eviction(s, n=40, holes=(9,), count_=16))
        out.append(decisive_holes(s, n=24, holes=4, kind='chain'))
        out.append(decisive_holes(s, n=24, holes=3, kind='rand'))
        out.append(partial_mix(s, n=24, pa=0.7, pe=0.6))
    return out


def heldout_traces():
    out = []
    for s in range(100, 104):
        out.append(reserved_eviction(s, n=56, holes=(9, 23), pattern='roundtrip', count_=20, side_mix=True))
        out.append(decisive_holes(s, n=40, holes=6, kind='chain', pattern='jump'))
        out.append(decisive_holes(s, n=32, holes=5, kind='rand', pattern='roundtrip', p_wide=0.2))
        out.append(partial_mix(s, n=32, pa=0.5, pe=0.5, pattern='jump', kind='chain'))
    return out


# --------------------------------------------------------------------------- gates

def window_all_analyses(session, target):
    case = session.owner._case
    n = len(case['items'])
    return all(case['items'][p].get('analysis', {}).get('status') == 'computed'
               for p in range(0, min(n - 1, target + 3) + 1))


def gate_rank_only(session, target, verdict):
    return all(nd['kind'] == 'RANK' for nd in verdict['needs']) and window_all_analyses(session, target)


def gate_none(session, target, verdict):
    return True


def feature_class(session, target, verdict):
    """Coarse observable class for the adaptive learner (no hidden data)."""
    kinds = tuple(sorted({nd['kind'] for nd in verdict['needs']}))
    k = len(verdict['needs'])
    return (kinds, min(k, 3), window_all_analyses(session, target))


# --------------------------------------------------------------------------- runner

class ARunner:
    def __init__(self, trace, *, policy='incumbent', service_u=3, q_u=1, q_model='fixed', q_eval=0.01,
                 capacity=3, raw_capacity=3, strong=None, gate=gate_rank_only, acq='all',
                 adaptive_prior=(1, 1), adaptive_conf=1.0, explore_k=2, ski_ratio=1.0, persistent=False,
                 order='fifo', proof_when_blocked=False, resident_aware=True):
        self.trace = trace
        self.policy, self.service_u, self.q_u = policy, service_u, q_u
        self.q_model, self.q_eval = q_model, q_eval
        self.world = World([Witness(**w) for w in trace['world']])
        st = dict(kind='tree', domain='nonneg', alpha=False, gate='raw', budget=None)
        st.update(strong or {})
        cls = PersistentStrongSession if persistent else StrongSession
        self.session = cls(trace['initial'], capacity=capacity, raw_capacity=raw_capacity, strong=st)
        self.world_w = deepcopy(trace['world'])
        self.truth = truth_units(trace['initial'], trace['world'])
        self.rebinds = 0
        self.republish = {}
        self.gate, self.acq = gate, acq
        self.now = 0
        self.q = []
        self.seq = count()
        self.scheduled = set()
        self.pending = []                # ordered intents not yet published
        self.intent, self.first_pub = {}, {}
        self.lane_free = 0               # compute lane
        self.proof_inflight = {}         # target -> due
        self.proof_failed_at = {}        # target -> evidence revision of last failed proof
        self.wrong = 0
        self.stats = {}                  # adaptive: class -> [succ, fail]
        self.prior, self.conf = adaptive_prior, adaptive_conf
        self.explore_k, self.ski_ratio = explore_k, ski_ratio
        self.order, self.proof_when_blocked = order, proof_when_blocked
        self.resident_aware = resident_aware
        self.rent = {}                   # ski: need signature -> proof time already paid
        self.c = dict(proof_starts=0, proof_wins=0, race_cancels=0, gate_skips=0, lane_busy_u=0,
                      refusals=0, wasted_proofs=0, adaptive_skips=0, max_occupied=0, publish_rejects=0)

    # ---- helpers
    def _push(self, t, kind, payload):
        heapq.heappush(self.q, (t, next(self.seq), kind, payload))

    def _sched(self):
        for token, task in self.session._tasks.items():
            if token not in self.scheduled and task['phase'] == 'running':
                self.scheduled.add(token)
                self._push(self.now + self.service_u, 'service', (token, task['item']))
        self.c['max_occupied'] = max(self.c['max_occupied'], self.session.occupied)

    def _items_for(self, verdict):
        an, rk = [], []
        for nd in verdict['needs']:
            if nd['kind'] in ('ANALYSIS', 'DIMENSIONS'):
                an.append(nd['item'])
            elif nd['kind'] == 'RANK':
                rk.append((nd['item'], nd['second']))
        if verdict['status'] == 'blocked':
            an += [int(k) for k in verdict['failures']]
        return an, rk

    def _acquire(self, verdict, target):
        an, rk = self._items_for(verdict)
        order = []
        if self.acq == 'analysis_first' and an:
            order = an
        elif self.acq == 'one':
            # one physical service per round: the nearest needed item whose witness is not
            # already resident (a rank needs BOTH endpoint witnesses resident)
            cands = an + [x for pr in rk for x in pr if x not in self.session._raw]
            if not cands:
                cands = an + [x for pr in rk for x in pr]
            order = sorted(set(cands), key=lambda i: abs(i - target))[:1]
        elif self.acq == 'one_witness':
            cover = {}
            for i in an:
                cover[i] = cover.get(i, 0) + 2           # analysis + both adjacent channels
            for a, b in rk:
                for i in (a, b):
                    if i not in self.session._raw:
                        cover[i] = cover.get(i, 0) + 1
            if not cover:
                for a, b in rk:
                    cover[a] = cover.get(a, 0) + 1
            order = [i for i, _ in sorted(cover.items(), key=lambda kv: (-kv[1], abs(kv[0] - target)))][:1]
        elif self.acq == 'witness':
            cover = {}
            for i in an:
                cover[i] = cover.get(i, 0) + 1
            for a, b in rk:
                for i in (a, b):
                    cover[i] = cover.get(i, 0) + 1
            order = [i for i, _ in sorted(cover.items(), key=lambda kv: (-kv[1], abs(kv[0] - target)))]
        else:
            order = an + [x for pr in rk for x in pr]
        seen = set()
        rank_items = {x for pr in rk for x in pr} - set(an)
        for i in order:
            if i in seen:
                continue
            seen.add(i)
            # NH-A: a rank endpoint whose raw witness is resident and current needs no new
            # service; re-serving it can livelock at capacity 1 (package Controller does so)
            if self.resident_aware and i in rank_items and self.session._raw_current(i):
                self.c['resident_skips'] = self.c.get('resident_skips', 0) + 1
                continue
            if self.session.acquire(i) is None:
                self.c['refusals'] += 1
        self._sched()

    def _inflight_items(self):
        return {task['item'] for task in self.session._tasks.values() if not task['cancelled']}

    def _publish(self, target, verdict):
        r = self.session.publish(target, verdict['certificate'])
        if r == 'published':
            if verdict['unit'] != self.truth[target]:
                self.wrong += 1
            if target not in self.first_pub:
                self.first_pub[target] = self.now
            elif target in self.republish:
                self.c['republish_latency_u'] = self.c.get('republish_latency_u', 0) + self.now - self.republish.pop(target)
                self.c['republished'] = self.c.get('republished', 0) + 1
            if target in self.pending:
                self.pending.remove(target)
        else:
            self.c['publish_rejects'] += 1
        return r

    def _proof_time(self, evaluations):
        if self.q_model == 'eval':
            return max(1, math.ceil(self.q_eval * evaluations)) if self.q_u > 0 else 0
        return self.q_u

    def _adaptive_ok(self, cls):
        s, f = self.stats.get(cls, (0, 0))
        if s + f < self.explore_k:                      # forced exploration per observable class
            return True
        a, b = self.prior[0] + s, self.prior[1] + f
        mean = a / (a + b)
        var = a * b / ((a + b) ** 2 * (a + b + 1))
        lcb = max(0.0, mean - self.conf * math.sqrt(var))
        # benefit of a success ~ one avoided service round; cost ~ q_u on the critical path
        return lcb * self.service_u >= self.q_u

    # ---- control
    def drive(self):
        seq = list(self.pending) if self.order == 'fifo' else list(reversed(self.pending))
        for t in seq:
            if t not in self.pending:
                continue
            if t in self.first_pub and t not in self.republish:
                self.pending.remove(t)
                continue
            if t in self.proof_inflight:
                if self.policy in ('race', 'gated_race', 'race_keep', 'gated_keep', 'when_waiting'):
                    base = self.session.certify(t, mode='L0')   # service may beat the proof
                    if base['status'] == 'certified':
                        self._publish(t, base)
                    else:
                        self._acquire(base, t)                  # keep the service path progressing
                continue
            self._drive_one(t)

    def _drive_one(self, t):
        pol = self.policy
        base = self.session.certify(t, mode='L0')
        if base['status'] == 'certified':
            self._publish(t, base)
            return
        if pol == 'incumbent' or base['status'] == 'blocked':
            self._acquire(base, t)
            return
        rev = self.session.owner._revision
        if self.proof_failed_at.get(t) == rev:          # nothing new admitted since last failed proof
            self._acquire(base, t)
            return
        if pol in ('gated', 'gated_race', 'gated_keep', 'ski') and not self.gate(self.session, t, base):
            self.c['gate_skips'] += 1
            self._acquire(base, t)
            return
        cls = feature_class(self.session, t, base)
        if pol == 'adaptive' and not self._adaptive_ok(cls):
            self.c['adaptive_skips'] += 1
            self._acquire(base, t)
            return
        if pol == 'when_waiting':
            an, rk = self._items_for(base)
            needed = set(an) | {x for pr in rk for x in pr}
            if not needed or not needed <= self._inflight_items():
                self._acquire(base, t)                    # issue work; proof only when purely waiting
                needed_now = needed - self._inflight_items()
                if needed_now:
                    return
        if pol == 'ski':
            sig = tuple(sorted((nd['kind'], nd['item'], nd.get('second')) for nd in base['needs']))
            if self.rent.get(sig, 0) >= self.ski_ratio * self.service_u:
                self.c['ski_buys'] = self.c.get('ski_buys', 0) + 1
                self._acquire(base, t)                    # buy the evidence once
                return
            self.rent[sig] = self.rent.get(sig, 0) + self.q_u
        if pol in ('race', 'gated_race', 'race_keep', 'gated_keep'):
            before = self.c['refusals']
            self._acquire(base, t)
            if self.proof_when_blocked and self.c['refusals'] == before:
                return                                    # X01 staged gate: prove only when admission blocks
        self._start_proof(t, base, cls)

    def _start_proof(self, t, base, cls):
        self.c['proof_starts'] += 1
        if self.policy == 'strong_only':
            self._finish_proof(t, cls, immediate=True)
            return
        # run the proof now to know its evaluation count; its RESULT becomes visible at due time
        start = max(self.now, self.lane_free)
        v = self.session.certify(t, mode='S')
        evals = self.session.strong_log[-1]['evaluations'] if self.session.strong_log else 0
        dur = self._proof_time(evals)
        due = start + dur
        self.lane_free = due
        self.c['lane_busy_u'] += dur
        self.proof_inflight[t] = due
        self._push(due, 'proof', (t, cls, v, self.session.owner._revision))

    def _finish_proof(self, t, cls, immediate=False, v=None, rev_at_start=None):
        if immediate:
            v = self.session.certify(t, mode='S')
        self.proof_inflight.pop(t, None)
        ok = v is not None and v['status'] == 'certified' and str(v.get('route', '')).startswith('strong')
        if cls is not None:
            s, f = self.stats.get(cls, (0, 0))
            self.stats[cls] = (s + ok, f + (not ok))
        if t in self.first_pub and t not in self.republish:
            if ok:
                self.c['wasted_proofs'] += 1
            return
        if ok:
            r = self._publish(t, v)           # stale certificates are rejected by Session.publish
            if r == 'published':
                self.c['proof_wins'] += 1
                if self.policy in ('race', 'gated_race'):
                    self._cancel_unneeded()
                return
        self.proof_failed_at[t] = self.session.owner._revision
        self._drive_one(t) if t in self.pending else None

    def _cancel_unneeded(self):
        """Cancel running tasks no pending target's current L0 verdict still needs."""
        still = set()
        for t in self.pending:
            v = self.session.certify(t, mode='L0')
            an, rk = self._items_for(v)
            still |= set(an) | {x for pr in rk for x in pr}
        for token, task in list(self.session._tasks.items()):
            if task['phase'] == 'running' and not task['cancelled'] and task['item'] not in still:
                self.session.cancel(token)
                self.c['race_cancels'] += 1

    def _rebind(self, ev):
        """Content replacement of one item: new hidden witness, new content version.
        New partial case = admitted evidence minus that item's analysis and its edges."""
        k = ev['item']
        self.world_w[k] = deepcopy(ev['witness'])
        case = self.session.observe()
        case['items'][k]['content_version'] = case['items'][k].get('content_version', 0) + 1
        case['items'][k]['analysis'] = {'status': 'unknown'}
        case['edges'] = [e for e in case['edges'] if k not in (e['first'], e['second'])]
        self.session.rebind(case, version=self.session.version)
        self.world = World([Witness(**w) for w in self.world_w])
        self.truth = truth_units(case, self.world_w)
        self.rebinds += 1
        self.proof_inflight.clear(); self.proof_failed_at.clear(); self.rent.clear()
        for tt in list(self.first_pub):            # current publications were cleared by rebind
            if tt not in self.pending:
                self.pending.append(tt)
                self.republish[tt] = self.now
        self._repub_done = getattr(self, '_repub_done', {})

    # ---- loop
    def run(self, horizon=10 ** 6, max_steps=200000):
        for ev in self.trace['events']:
            self._push(ev['at'], 'ext', ev)
        steps = 0
        self.livelock = False
        while self.q:
            t, _s, kind, payload = heapq.heappop(self.q)
            steps += 1
            if t > horizon or steps > max_steps:          # livelock guard: reported, never hidden
                self.livelock = True
                break
            self.now = t
            if kind == 'service':
                token, i = payload
                self.scheduled.discard(token)
                if token in self.session._tasks:
                    self.session.finish(token, self.world.complete(i))
                    self.session.consume(token)
                self.drive()
            elif kind == 'proof':
                tt, cls, v, rev = payload
                if tt in self.proof_inflight:
                    self._finish_proof(tt, cls, v=v, rev_at_start=rev)
                self.drive()
            else:
                ev = payload
                if ev['op'] == 'target':
                    tt = ev['target']
                    self.intent.setdefault(tt, t)
                    if tt not in self.first_pub and tt not in self.pending:
                        self.pending.append(tt)
                elif ev['op'] == 'targets':
                    for tt in ev['targets']:
                        self.intent.setdefault(tt, t)
                        if tt not in self.first_pub and tt not in self.pending:
                            self.pending.append(tt)
                elif ev['op'] == 'prefetch':
                    self.session.acquire(ev['item'], required=False)
                elif ev['op'] == 'evict_raw':
                    self.session._raw.clear()
                elif ev['op'] == 'rebind':
                    self._rebind(ev)
                self.drive()
            self._sched()
        s = self.session
        lat = {k: self.first_pub[k] - self.intent[k] for k in self.first_pub}
        return dict(policy=self.policy, acq=self.acq, service_u=self.service_u, q_u=self.q_u,
                    published=len(self.first_pub), intents=len(self.intent), wrong=self.wrong,
                    total_latency_u=sum(lat.values()), max_latency_u=max(lat.values()) if lat else 0,
                    latency_u=lat, unserved=sorted(set(self.intent) - set(self.first_pub)),
                    physical_admissions=s.metrics['physical_admissions'],
                    physical_finishes=s.metrics['physical_finishes'],
                    discarded=s.metrics['discarded_completions'],
                    raw_insertions=s.metrics['raw_insertions'],
                    rank_computations=s.metrics['rank_computations'],
                    strong_attempts=s.metrics['strong_attempts'],
                    strong_certificates=s.metrics['strong_certificates'],
                    strong_evaluations=s.metrics['strong_evaluations'],
                    strong_stops=s.metrics['strong_stops'],
                    strong_ns=s.metrics['strong_ns'], certification_calls=s.metrics['certification_calls'],
                    certification_steps=s.metrics['certification_steps'], end_u=self.now, rebinds=self.rebinds,
                    livelock=self.livelock,
                    pending_republish=len(self.republish), **self.c)


# --------------------------------------------------------------------------- shared-state strong solver

import transducer as T
import omega as O
from strong import support_keys


class PersistentStrongSession(StrongSession):
    """O01/P03 shared-state route: one relation tree per owner context, updated
    incrementally from the positions the owner actually changed (window lemma:
    leaves [p-3, p+1]; edge (a,a+1): leaves a-1, a), queried per target in
    O(log n).  Identity/settings changes or a domain widening rebuild it.
    Support and gating are identical to StrongSession (same support_keys).

    Budget contract BC-2 (fix round): tree build, dirty-leaf recomputation and
    the query exploration are all charged to the calling certify; a stopped
    call restores the tree (undo log of overwritten entries / previous tree
    object) and the dirty sets, so no progress survives a stop.  Fact refresh
    of the Facts object is maintenance and is kept (idempotent)."""

    _route_name = 'persistent-tree'

    def __init__(self, case, **kw):
        super().__init__(case, **kw)
        self._tree = None
        self._tree_key = None
        self._undo = None
        self._dirty_items, self._dirty_edges = set(), set()
        orig = self.owner.apply

        def tracked_apply(*, item_updates=None, edge_updates=None, **rest):
            for i in (item_updates or {}):
                self._dirty_items.add(i)
            for (a, b) in (edge_updates or {}):
                self._dirty_edges.add(a)
            if rest:
                self._tree = None
            return orig(item_updates=item_updates, edge_updates=edge_updates, **rest)
        self.owner.apply = tracked_apply
        self.metrics['persistent_rebuilds'] = 0

    def rebind(self, case, **kw):
        super().rebind(case, **kw)
        self._tree = None
        self._dirty_items.clear(); self._dirty_edges.clear()

    def close(self):
        super().close()
        self._tree = None
        self._tree_key = None
        self._dirty_items.clear(); self._dirty_edges.clear()

    def residency(self):
        return 0 if self._tree is None else len(self._tree.tree)

    # ---- transaction hooks (BC-2)
    def _txn_begin(self):
        self._undo = []
        return dict(tree=self._tree, key=self._tree_key, di=set(self._dirty_items), de=set(self._dirty_edges),
                    undo=self._undo)

    def _txn_rollback(self, snap):
        tree = snap['tree']
        if tree is not None:
            for v, old in reversed(snap['undo']):
                tree.tree[v] = old
        self._tree, self._tree_key = tree, snap['key']
        self._dirty_items, self._dirty_edges = snap['di'], snap['de']
        self._undo = None
        self.metrics['persistent_rollbacks'] += 1

    def _txn_commit(self, snap):
        self._undo = None

    def _write(self, v, rel):
        tr = self._tree.tree
        if self._undo is not None:
            self._undo.append((v, tr[v]))
        tr[v] = rel

    def _sync(self):
        cfg = self.strong
        key = (self.owner._guard()[:4], cfg['domain'], cfg['alpha'])
        case = self.owner._case
        if self._tree is None or self._tree_key != key:
            F = T.Facts(case, 'omega', cfg['domain'], cfg['alpha'])
            if not F.domain_ok:
                F = T.Facts(case, 'omega', 'ext', cfg['alpha'])
            tree = T.RelTree(F, {})                    # charged: n leaf explorations
            self._tree, self._tree_key = tree, key     # rollback restores the previous reference
            self._dirty_items.clear(); self._dirty_edges.clear()
            self.metrics['persistent_rebuilds'] += 1
            self.metrics['persistent_compose'] += tree.size - 1
            return
        if not (self._dirty_items or self._dirty_edges):
            return
        F = self._tree.F
        leaves = set()
        for p in self._dirty_items:
            F.refresh_item(p, case['items'][p])
            leaves.update(T.affected_leaves(p))
        recs = {(e['first'], e['second']): e for e in case.get('edges', [])}
        for a in self._dirty_edges:
            r = recs.get((a, a + 1))
            if r is None:
                F.records.pop(a, None)
            else:
                F.records[a] = r
                s = r.get('score') if r.get('status') == 'computed' else None
                if s is not None and not T._in_domain(s, F.domain):
                    self._tree = None
                    self._sync()
                    return
            leaves.update((a - 1, a))
        F.ix._edges = None
        tree = self._tree
        new = {i: T.leaf_fast(tree.ctx, i) for i in sorted(leaves) if 0 <= i < tree.n}   # charged
        touched = set()
        for i, rel in new.items():
            self._write(tree.size + i, rel)
            v = (tree.size + i) // 2
            while v:
                touched.add(v)
                v //= 2
        for v in sorted(touched, reverse=True):
            self._write(v, T.compose(tree.tree[2 * v], tree.tree[2 * v + 1]))
        self._dirty_items.clear(); self._dirty_edges.clear()
        self.metrics['persistent_leaf_updates'] += len(new)
        self.metrics['persistent_compose'] += len(touched)

    def _strong_compute(self, target, limit):
        self._sync()
        units = self._tree.units(target)                # charged query exploration
        if len(units) == 1:
            return 'certified', next(iter(units.values())), 'persistent-tree'
        return 'ambiguous', None, 'persistent-tree'


def heldout2_traces():
    """Held-out variants of the adoption pattern (never used for tuning): other
    lengths, hole positions/counts, access patterns and two directions."""
    out = []
    for s in range(200, 204):
        out.append(reserved_eviction(s, n=72, holes=(9,), pattern='jump', count_=20))
        out.append(reserved_eviction(s, n=56, holes=(9, 31), pattern='roundtrip', count_=24))
        out.append(decisive_holes(s, n=48, holes=8, kind='chain', pattern='sweep', count_=24))
        tr = reserved_eviction(s, n=40, holes=(9,), pattern='sweep', count_=16)
        tr['initial']['settings']['direction'] = 'BA'           # direction flips slot labels
        tr['name'] = tr['name'].replace('RE_', 'REBA_')
        out.append(tr)
    return out


# --------------------------------------------------------------------------- shadow (publication-only) adoption

class ShadowRunner(ARunner):
    """Proof results touch ONLY the publication channel.

    The physical controller is the incumbent, verbatim: at exactly the incumbent's
    drive instants it L0-certifies every not-yet-L0-certified target in FIFO order and
    issues the incumbent's acquisitions -- including for targets a proof has already
    published.  A target leaves the physical queue only when L0 certifies it.  Proof
    events never trigger acquisitions.  Hence (lemma S1, proofs/wpA.md) the admitted
    evidence sequence, physical admissions and raw store are identical to the
    incumbent's, and every first publication time is min(incumbent time, proof time).

    policy: 'shadow' (prove every need_facts target) or 'gated_shadow' (observable gate).
    Found necessary by the race_keep counterexample (race_keep_counterexample.json):
    an early proof publication removed a target whose acquisitions other targets reused.
    """

    def __init__(self, trace, **kw):
        kw.setdefault('policy', 'gated_shadow')
        super().__init__(trace, **kw)
        self.l0_pending = []          # physical queue (incumbent's pending list)
        self._proof_event = False

    def _publish_proof(self, target, verdict):
        r = self.session.publish(target, verdict['certificate'])
        if r == 'published':
            if verdict['unit'] != self.truth[target]:
                self.wrong += 1
            if target not in self.first_pub:
                self.first_pub[target] = self.now
            elif target in self.republish:
                self.c['republish_latency_u'] = self.c.get('republish_latency_u', 0) + self.now - self.republish.pop(target)
                self.c['republished'] = self.c.get('republished', 0) + 1
        else:
            self.c['publish_rejects'] += 1
        return r

    def drive(self):
        # sync physical queue with intents (pending is fed by run(); mirror it)
        for t in self.pending:
            if t not in self.l0_pending:
                self.l0_pending.append(t)
        self.pending = [t for t in self.pending if t not in self.first_pub or t in self.republish]
        if self._proof_event:
            self._proof_event = False
            return                                    # proof events never act physically
        for t in list(self.l0_pending):
            base = self.session.certify(t, mode='L0')
            if base['status'] == 'certified':
                self.l0_pending.remove(t)
                if t not in self.first_pub or t in self.republish:
                    self._publish_proof(t, base)       # same publish path, L0 certificate
                elif t not in self.session.published:
                    # the proof publication expired (later evidence touched its support):
                    # refresh with the L0 certificate so the current-publication set at
                    # every drive instant is a superset of the incumbent's
                    if self.session.publish(t, base['certificate']) == 'published':
                        self.c['shadow_refresh'] = self.c.get('shadow_refresh', 0) + 1
                else:
                    self.c['shadow_l0_after_proof'] = self.c.get('shadow_l0_after_proof', 0) + 1
                continue
            self._acquire(base, t)                    # the incumbent's physical action, verbatim
            published = t in self.first_pub and t not in self.republish
            if published or base['status'] == 'blocked' or t in self.proof_inflight:
                continue
            if self.proof_failed_at.get(t) == self.session.owner._revision:
                continue
            if self.policy == 'gated_shadow' and not self.gate(self.session, t, base):
                self.c['gate_skips'] += 1
                continue
            self._start_proof(t, base, None)
        self.pending = [t for t in self.pending if t not in self.first_pub or t in self.republish]

    def _finish_proof(self, t, cls, immediate=False, v=None, rev_at_start=None):
        self.proof_inflight.pop(t, None)
        self._proof_event = True
        ok = v is not None and v['status'] == 'certified' and str(v.get('route', '')).startswith('strong')
        if t in self.first_pub and t not in self.republish:
            if ok:
                self.c['wasted_proofs'] += 1
            return
        if ok and self._publish_proof(t, v) == 'published':
            self.c['proof_wins'] += 1
            return
        self.proof_failed_at[t] = self.session.owner._revision

    def _rebind(self, ev):
        super()._rebind(ev)
        for tt in self.pending:
            if tt not in self.l0_pending:
                self.l0_pending.append(tt)


def make_runner(trace, policy, **kw):
    if policy in ('shadow', 'gated_shadow'):
        return ShadowRunner(trace, policy=policy, **kw)
    return ARunner(trace, policy=policy, **kw)


def shadow_boundary(q_u, service_u):
    """Executable adoption boundary (u only; observable configuration): a proof started
    when a target's service round starts can publish strictly earlier only if q_u < service_u."""
    return q_u < service_u
