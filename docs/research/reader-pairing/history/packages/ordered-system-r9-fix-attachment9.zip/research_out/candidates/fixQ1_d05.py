"""D05 (fix round, Q1): constraint sparsity -- two routes.

Route 1  PATHDEC  path decomposition over the scan comparison graph: the exact
                  shared-assignment frontier DP (omega), whose bags are the
                  boundary windows {state/side of positions b-1..b+2, rank choice
                  of edge b, the live order-constraint component} -- cost is
                  governed by the bag width, not by n.
Route 2  CSP      a generic finite-domain solver: depth-first backtracking over
                  the abstract facts (state, side, rank null/value, order
                  outcomes) that the scan of positions 0..t reads, with
                  propagation = order-constraint feasibility at every choice
                  (Ctx.compare) and early termination as soon as two distinct
                  target units are found.  No merging of equivalent prefixes.

Cost unit for both: calls of the frozen step function (transducer.step_result).

Lemma D05-1 (proofs/fix_Q1.md): in automatic mode a rank comparison happens only
in later_wins(i), between edges (i, i+1) and (i+1, i+2), and only when
can_pair(i).  If it returns True and i > 0, the scan reserves i+1, so step i+1
pairs without comparing; if False, (i, i+1) is paired and the next comparison is
at i+2 or later.  Therefore two comparisons share an edge only through the
opening (i = 0 cannot reserve): live order-constraint components have at most
2 constraints / 3 edges at the opening and 1 constraint / 2 edges elsewhere,
independently of n, pins and isolates (pins/isolates only remove comparisons).
"""
import paths  # noqa: F401
import transducer as T
import omega as O


class StepCounter:
    def __init__(self):
        self.n = 0

    def __enter__(self):
        self._orig = T.step_result
        orig = self._orig

        def counted(*a, **kw):
            self.n += 1
            return orig(*a, **kw)
        T.step_result = counted
        return self

    def __exit__(self, *e):
        T.step_result = self._orig
        return False


def pathdec(case, target, domain='ext', alpha=False, stats=None):
    """Exact DP; returns (status, units) and bag statistics."""
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    ctx = T.Ctx(F)
    frontier = {(T.S0, frozenset())}
    units = {}
    st = stats if stats is not None else {}
    st.setdefault('max_bag_vars', 0); st.setdefault('max_lt_edges', 0); st.setdefault('max_lt_constraints', 0)
    st.setdefault('max_frontier', 0); st.setdefault('max_lt_edges_at', None)
    for i in range(0, target + 1):
        include = i >= target - 1
        nxt = set()
        for s, asg in frontier:
            if s >> 1 == T.SKIP and i == target:
                continue
            for (ns, unit), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(asg)):
                if include and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                    units[T._key(unit)] = unit
                elif i < target:
                    key = frozenset(O._prune(a, i).items())
                    nxt.add((ns, key))
                    lts = [k for k, _v in key if k[0] == 'lt']
                    edges = {t[1] for k in lts for t in k[1:] if isinstance(t, tuple) and t and t[0] == 'e'}
                    st['max_bag_vars'] = max(st['max_bag_vars'], sum(1 for k, _v in key if k[0] != 'lt'))
                    if len(edges) > st['max_lt_edges']:
                        st['max_lt_edges'] = len(edges); st['max_lt_edges_at'] = i
                    st['max_lt_constraints'] = max(st['max_lt_constraints'], len(lts))
        frontier = nxt
        st['max_frontier'] = max(st['max_frontier'], len(frontier))
    if not units:
        return 'contradiction', {}
    return ('certified' if len(units) == 1 else 'ambiguous'), units


def csp(case, target, domain='ext', alpha=False, cap=2_000_000, early=True):
    """Generic backtracking solver.  Returns (status, units, nodes) ; status
    'limit' if more than `cap` step calls would be needed."""
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    ctx = T.Ctx(F)

    def run_prefix():
        s = T.S0
        i = 0
        while i <= target:
            if s >> 1 == T.SKIP:
                if i == target:
                    return None
                # skip state: the step at i consumes the pair started at i-1
            include = i >= target - 1
            ns, unit = T.step_result(ctx, i, s, include=include)
            if include and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                return T._key(unit), unit
            s = ns
            i += 1
        return None

    units = {}
    stack = [{}]
    nodes = 0
    calls0 = [0]
    while stack:
        asg = stack.pop()
        ctx.asg = asg
        nodes += 1
        try:
            r = run_prefix()
        except T.Need as e:
            for o in e.options:
                d = dict(asg)
                d[e.key] = o
                stack.append(d)
            continue
        if r is not None:
            units[r[0]] = r[1]
            if early and len(units) > 1:
                return 'ambiguous', units, nodes
        if nodes > cap:
            return 'limit', units, nodes
    if not units:
        return 'contradiction', units, nodes
    return ('certified' if len(units) == 1 else 'ambiguous'), units, nodes
