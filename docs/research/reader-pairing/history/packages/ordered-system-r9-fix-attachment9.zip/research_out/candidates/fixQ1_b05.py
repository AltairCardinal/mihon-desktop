"""B05 (fix round, Q1): backward goal constraints -- two routes.

Route 1  GOAL   wpB_layered.goal_pruned: exact forward DP from 0 whose frontier
                is filtered by tree-backward 'can reach a unit != u0' state sets
                (R9, refuted on cost).
Route 2  MITM   forward/backward meet-in-the-middle, exact:
                forward  = exact shared-assignment DP from 0 to the meet
                           boundary m (target-independent prefix);
                backward = for every candidate target unit u, the set B_m^u of
                           boundary constraints (cursor state, partial assignment)
                           from which u is produced, built by stepping backwards
                           from the target: a predecessor key is obtained by
                           evaluating step i from every cursor state under the
                           successor's constraint as base assignment
                           (explore enumerates exactly the facts step i still
                           needs), keeping results whose next state matches;
                           st/sd/rk variables no earlier step can read
                           (position >= i+3 / edge >= i+2) are projected away
                           (existential, they are read only inside the suffix),
                           order constraints are kept whole.
                meet     = u is possible iff some forward key and some backward
                           key of u have the same cursor state, agree on every
                           common variable, and their order constraints are
                           jointly feasible in the domain.
                Certified iff exactly one u is possible.

Soundness (no legal completion deleted; proofs/fix_Q1.md B05-1): a world's run
passes through a forward key f (exactness of the forward DP, Lemma B-1) and,
reading its suffix backwards, every backward step keeps the predecessor key that
the world's own assignment instantiates, so the world's unit u has a backward key
g compatible with f.  Both routes count evaluations with the same unit as BC-2.
"""
import paths  # noqa: F401
import transducer as T
import omega as O
import wpB_layered as L
from budget import Meter, BudgetExceeded


def _bwd_prune(asg, i):
    """Constraint kept at boundary i (before step i): variables steps < i can read."""
    out = {}
    for k, v in asg.items():
        tag = k[0]
        if tag in ('st', 'sd'):
            if k[1] <= i + 2:
                out[k] = v
        elif tag == 'rk':
            if k[1] <= i + 1:
                out[k] = v
        else:
            out[k] = v                      # order constraints kept whole (exact joint feasibility)
    return frozenset(out.items())


def _compatible(fa, ga, domain):
    d = dict(fa)
    for k, v in ga:
        if k in d and d[k] != v:
            return False
    cs = {((k[1], k[2]), v) for k, v in list(fa) + list(ga) if k[0] == 'lt'}
    return T.feasible(frozenset(cs), domain) if cs else True


def backward_sets(ctx, target, m):
    """{unit_key: set of (state, constraint)} at boundary m, plus the unit dicts."""
    units = {}
    goal = {}                                  # unit -> set of keys at current boundary
    # step target (non-SKIP entry states)
    for s in range(T.NSTATE):
        if s >> 1 == T.SKIP:
            continue
        for (ns, unit), a in T.explore(ctx, lambda: T.step_result(ctx, target, s, include=True)):
            if unit is not None and any(sl['item'] == target for sl in unit['slots']):
                k = T._key(unit); units[k] = unit
                goal.setdefault(k, set()).add((s, _bwd_prune(a, target)))
    i = target - 1
    while i >= m:
        include = i >= target - 1
        new = {}
        leaf = T.leaf_fast(ctx, i)               # over-approximate successor sets (filter only)
        for s in range(T.NSTATE):
            if include:
                for (ns, unit), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=True)):
                    if unit is not None and any(sl['item'] == target for sl in unit['slots']):
                        k = T._key(unit); units[k] = unit
                        new.setdefault(k, set()).add((s, _bwd_prune(a, i)))
            succ = leaf[s]
            for k, keys in goal.items():
                for gs, ga in keys:
                    if not (succ >> gs) & 1:
                        continue
                    res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(ga))
                    for (ns, unit), a in res:
                        if ns != gs:
                            continue
                        if include and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                            continue                  # target already produced here (pair) -- not a pass-through
                        if i == target - 1 and gs >> 1 == T.SKIP:
                            continue
                        new.setdefault(k, set()).add((s, _bwd_prune(a, i)))
        goal = new
        i -= 1
    return goal, units


def forward_frontier(ctx, m):
    frontier = {(T.S0, frozenset())}
    for i in range(0, m):
        nxt = set()
        for s, asg in frontier:
            for (ns, _u), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=False), dict(asg)):
                nxt.add((ns, frozenset(O._prune(a, i).items())))
        frontier = nxt
    return frontier


def mitm(case, target, domain='ext', alpha=True, d=4, budget=None, counters=None):
    """('certified', unit) | ('ambiguous', units) | ('contradiction', None) | ('unknown', None)."""
    c = counters if counters is not None else {}
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    ctx = T.Ctx(F)
    m = max(0, target - 1 - d)
    meter = Meter(budget)
    try:
        with meter:
            fwd = forward_frontier(ctx, m)
            ev_f = meter.n
            goal, units = backward_sets(ctx, target, m)
            ev_b = meter.n - ev_f
    except BudgetExceeded:
        c['evaluations'] = meter.n
        return 'unknown', None
    possible = {}
    joins = 0
    by_state = {}
    for s, a in fwd:
        by_state.setdefault(s, []).append(a)
    for k, keys in goal.items():
        for gs, ga in keys:
            hit = False
            for fa in by_state.get(gs, ()):
                joins += 1
                if _compatible(fa, ga, F.domain):
                    hit = True
                    break
            if hit:
                possible[k] = units[k]
                break
    c.update(evaluations=meter.n, forward_evaluations=ev_f, backward_evaluations=ev_b, meet=m,
             forward_keys=len(fwd), backward_keys=sum(len(v) for v in goal.values()), joins=joins)
    if not possible:
        return 'contradiction', None
    if len(possible) == 1:
        return 'certified', next(iter(possible.values()))
    return 'ambiguous', possible


def goal_pruned(case, target, domain='ext', alpha=True, budget=None, counters=None):
    c = counters if counters is not None else {}
    return L.goal_pruned(case, target, domain, alpha, budget=budget, counters=c)


def exact(case, target, domain='ext', alpha=True, budget=None, counters=None):
    c = counters if counters is not None else {}
    return L.exact_from_zero(case, target, domain, alpha, budget=budget, counters=c)


# ----------------------------------------------------------------- maintenance study helpers
class ForwardCache:
    """Target-independent exact forward frontiers with update invalidation:
    the frontier at boundary i depends only on facts read by steps < i
    (positions <= i+2, edges <= i), so an item update at p drops boundaries
    i >= p-2 and an edge update at a drops boundaries i >= a."""

    def __init__(self, case, domain='ext', alpha=True):
        self.case, self.domain, self.alpha = case, domain, alpha
        self._facts()
        self.frontiers = [{(T.S0, frozenset())}]

    def _facts(self):
        self.F = T.Facts(self.case, 'omega', self.domain, self.alpha)
        if not self.F.domain_ok:
            self.F = T.Facts(self.case, 'omega', 'ext', self.alpha)
        self.ctx = T.Ctx(self.F)

    def update(self, item=None, edge=None):
        self._facts()                           # facts copied from the updated case (no evaluations)
        cut = (item - 2) if item is not None else edge
        keep = max(1, cut + 1 if cut is not None else 1)
        if not self.F.domain_ok:
            keep = 1
        self.frontiers = self.frontiers[:min(len(self.frontiers), max(1, keep))]

    def frontier(self, m):
        ctx = self.ctx
        while len(self.frontiers) <= m:
            i = len(self.frontiers) - 1
            nxt = set()
            for s, asg in self.frontiers[i]:
                for (ns, _u), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=False), dict(asg)):
                    nxt.add((ns, frozenset(O._prune(a, i).items())))
            self.frontiers.append(nxt)
        return self.frontiers[m]

    def certify(self, target):
        """Exact (= certify_exact) using cached frontier at max(0, target-1)."""
        start = max(0, target - 1)
        frontier = self.frontier(start)
        ctx = self.ctx
        units = {}
        for i in range(start, target + 1):
            nxt = set()
            for s, asg in frontier:
                if s >> 1 == T.SKIP and i == target:
                    continue
                for (ns, unit), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=True), dict(asg)):
                    if unit is not None and any(sl['item'] == target for sl in unit['slots']):
                        units[T._key(unit)] = unit
                    elif i < target:
                        nxt.add((ns, frozenset(O._prune(a, i).items())))
            frontier = nxt
        if not units:
            return 'contradiction', None
        return ('certified', next(iter(units.values()))) if len(units) == 1 else ('ambiguous', units)

    def mitm(self, target, d=4):
        """MITM reusing the cached forward frontier; backward sets recomputed per query."""
        m = max(0, target - 1 - d)
        fwd = self.frontier(m)
        goal, units = backward_sets(self.ctx, target, m)
        by_state = {}
        for s, a in fwd:
            by_state.setdefault(s, []).append(a)
        possible = {}
        for k, keys in goal.items():
            if any(_compatible(fa, ga, self.F.domain) for gs, ga in keys for fa in by_state.get(gs, ())):
                possible[k] = units[k]
        if not possible:
            return 'contradiction', None
        return ('certified', next(iter(possible.values()))) if len(possible) == 1 else ('ambiguous', possible)
