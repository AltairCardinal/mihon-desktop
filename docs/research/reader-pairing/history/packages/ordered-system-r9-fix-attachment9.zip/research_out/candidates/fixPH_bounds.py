"""Fix round PH, item 6: arbitrary-length constructions for N01 and N06.

Family P_n(V)  (V0 > V1 > V2 >= 0 any three distinct non-null ranks)
  n items, every analysis computed NARROW with side UNKNOWN, settings
  automatic=True, direction AB, opening AUTO, no pins/isolates;
  edge e (between items e, e+1) has score V[e mod 3].

Lemma P (proofs/fix_PH.md): on P_n the frozen scan emits
  single 0 (FIRST), then for every free cursor j = 3k+1 <= n-3:
  single j (RANK_BOUNDARY) and pair (j+1, j+2)        -- phase A.
Edited family P'_n: edge 1 := V2.  Then pair (1,2) and for every free cursor
  j = 3k <= n-3 (k >= 1): single j, pair (j+1, j+2)   -- phase B.
Every position p in [1, n-3] has a different unit (as item set) in A and B.

N06: the two inputs differ in one fact (rank 1:2) yet differ in the unit of
item n-3, at distance n-5 from item 2: no rule equal to the reference can have
an influence radius R < n-5; n is arbitrary, so no constant R exists.
N01: for target t >= 1 the target unit is sensitive exactly to the rank facts
e in [1, j(t)+1] with e mod 3 in {1, 2}, j(t) = t - ((t-1) mod 3); every
certificate contains them (sensitivity), and they plus the item facts form a
certificate (verified with the exact shared-assignment DP), so the minimal
rank-fact certificate size is exactly 2*floor((t-1)/3) + 2 (Theta(t)).
"""
import itertools
from copy import deepcopy

import paths  # noqa: F401
import reference as ref
import omega as O
from common import base_case, unit_of

VALUE_SETS = {
    'ext': (3.0, 2.0, 1.0),
    'nonneg': (2.0, 1.0, 0.0),
    'G0': (0.04, 0.02, 0.0),          # m/50 grid
    'adapter_int': (3, 2, 1),         # realisable as |x_i - x_{i+1}| with x_{i+1} = x_i + d_i
}


def periodic_chain(n, V=(3.0, 2.0, 1.0)):
    c = base_case(n, automatic=True, direction='AB')
    for e in c['edges']:
        e['score'] = V[e['first'] % 3]
    return c


def edited(case, edge, value):
    d = deepcopy(case)
    for e in d['edges']:
        if e['first'] == edge:
            e['score'] = value
    return d


def members(case):
    """item -> frozenset of item ordinals in its unit (and the unit dict)."""
    plan = ref.complete_plan(case)
    out = {}
    for u in plan:
        s = frozenset(x['item'] for x in u['slots'])
        for x in u['slots']:
            out[x['item']] = (s, u)
    return out


def predicted_phase(n, phase):
    """Closed form of Lemma P (item sets) for p in [1, n-3]; phase 'A' or 'B'."""
    out = {}
    for p in range(1, n - 2):
        if phase == 'A':
            r = p % 3
            out[p] = frozenset([p]) if r == 1 else (frozenset([p, p + 1]) if r == 2 else frozenset([p - 1, p]))
        else:
            if p in (1, 2):
                out[p] = frozenset([1, 2])
                continue
            r = p % 3
            out[p] = frozenset([p]) if r == 0 else (frozenset([p, p + 1]) if r == 1 else frozenset([p - 1, p]))
    return out


# ------------------------------------------------------------------ N06
def n06_check(n, V):
    a, b = periodic_chain(n, V), edited(periodic_chain(n, V), 1, V[2])
    ma, mb = members(a), members(b)
    pa, pb = predicted_phase(n, 'A'), predicted_phase(n, 'B')
    lemma_ok = all(ma[p][0] == pa[p] for p in pa) and all(mb[p][0] == pb[p] for p in pb)
    changed = [p for p in range(n) if ma[p][0] != mb[p][0]]
    farthest = max(changed) if changed else None
    all_in_range_changed = all(ma[p][0] != mb[p][0] for p in range(1, n - 2))
    return dict(n=n, lemma_ok=lemma_ok, all_positions_1_to_n_minus_3_changed=all_in_range_changed,
                farthest_changed=farthest, radius_lower_bound=(farthest - 2) if farthest is not None else None,
                facts_differing=1)


def front_insertion(n, V, v_new=None):
    """Insert one item before item 0 (new edge score v_new); fraction of OLD items
    (by id) whose unit (as id set) changes."""
    a = periodic_chain(n, V)
    b = periodic_chain(n + 1, V)                 # shape; ids relabelled below
    ids_a = [it['id'] for it in a['items']]
    b['items'][0]['id'] = 'new'
    for k in range(n):
        b['items'][k + 1]['id'] = ids_a[k]
    for e in b['edges']:
        f = e['first']
        e['score'] = (V[0] if v_new is None else v_new) if f == 0 else V[(f - 1) % 3]
    ma, mb = members(a), members(b)
    ida = {p: frozenset(ids_a[x] for x in ma[p][0]) for p in range(n)}
    idb = {}
    for p in range(n + 1):
        idb[b['items'][p]['id']] = frozenset(b['items'][x]['id'] for x in mb[p][0])
    changed = sum(1 for p in range(n) if ida[p] != idb[ids_a[p]])
    return dict(n=n, old_items_relabelled=changed, fraction=changed / n)


def append_stability(case):
    """Append one item at the end (new edge V-like value); old units that change."""
    n = len(case['items'])
    b = deepcopy(case)
    it = deepcopy(b['items'][-1]); it['id'] = 'appended'
    b['items'].append(it)
    b['edges'].append(dict(first=n - 1, second=n, status='computed', score=0.5, version=1))
    ma, mb = members(case), members(b)
    return [p for p in range(n) if ma[p][1] != mb[p][1]]


def mirror(case):
    """Reverse item order and direction (AB<->BA); edges re-indexed."""
    n = len(case['items'])
    d = deepcopy(case)
    d['items'] = list(reversed(d['items']))
    d['settings']['direction'] = 'BA' if case['settings'].get('direction', 'AB') == 'AB' else 'AB'
    d['edges'] = [dict(e, first=n - 2 - e['first'], second=n - 1 - e['first']) for e in case['edges']]
    d['edges'].sort(key=lambda e: e['first'])
    return d


def mirror_equivariant(case):
    n = len(case['items'])
    ma, mb = members(case), members(mirror(case))
    return all(frozenset(n - 1 - x for x in mb[n - 1 - p][0]) == ma[p][0] for p in range(n))


# ------------------------------------------------------------------ N01
def j_of(t):
    return t - ((t - 1) % 3)


def predicted_sensitive(t):
    return [e for e in range(1, j_of(t) + 2) if e % 3 in (1, 2)]


def sensitive_edges(t, V, n=None):
    """Edges e whose single change (over a value set spanning every order outcome) changes unit(t)."""
    n = n or t + 4
    a = periodic_chain(n, V)
    u0 = unit_of(ref.complete_plan(a), t)
    vals = list(V) + [V[0] * 2 + 1, None]          # every strict-order outcome against neighbours + null
    out = []
    for e in range(n - 1):
        for v in vals:
            if v == V[e % 3]:
                continue
            if unit_of(ref.complete_plan(edited(a, e, v)), t) != u0:
                out.append(e)
                break
    return out


def certificate_check(t, V, domain, S, n=None):
    """Is S (set of rank facts; all item facts known) a certificate for unit(t)?
    Exact shared-assignment DP over every completion of the edges not in S."""
    n = n or t + 4
    a = periodic_chain(n, V)
    u0 = unit_of(ref.complete_plan(a), t)
    c = deepcopy(a)
    c['edges'] = [e for e in c['edges'] if e['first'] in S]
    st, u = O.certify_exact(c, t, domain, True, limit=10 ** 7)
    return st == 'certified' and u == u0, st


def n01_row(t, V=(3.0, 2.0, 1.0), domain='ext', check_minimal=True):
    sens = sensitive_edges(t, V)
    pred = predicted_sensitive(t)
    cert_ok, st = certificate_check(t, V, domain, set(sens))
    minimal = None
    if check_minimal:
        minimal = all(not certificate_check(t, V, domain, set(sens) - {e})[0] for e in sens)
    return dict(t=t, domain=domain, sensitive=len(sens), predicted=len(pred), formula=2 * ((t - 1) // 3) + 2,
                matches_prediction=sens == pred, sensitive_set_is_certificate=cert_ok, dp_status=st,
                each_removal_breaks=minimal)


# ---------------- exhaustive small-t: certificate complexity vs adaptive decision-tree depth
def _target_fn(t, V):
    """f(assignment of edges 1..t+1) -> unit of t on an (t+4)-chain with all items known.
    Edge 0 is never read (allowed(0) is False and reason FIRST precedes later_wins);
    edges >= t+2 are outside the window of steps <= t (window lemma)."""
    n = t + 4
    base = periodic_chain(n, V)
    variables = list(range(1, t + 2))
    cache = {}

    def f(assign):
        key = tuple(assign)
        if key not in cache:
            c = deepcopy(base)
            for e, v in zip(variables, assign):
                c['edges'][e]['score'] = v
            u = unit_of(ref.complete_plan(c), t)
            cache[key] = (tuple(s['item'] for s in u['slots']), u['reason'])
        return cache[key]
    return f, variables


def exhaustive_cd(t, V=(3.0, 2.0, 1.0)):
    """Over the domain V^k (k = t+1 variables): max_w C(f,w), C at the periodic world, and the
    optimal worst-case adaptive decision-tree depth D(f).  Exponential: t <= 5."""
    f, var = _target_fn(t, V)
    k = len(var)
    worlds = list(itertools.product(V, repeat=k))
    val = {w: f(w) for w in worlds}

    def cert_size(w):
        for size in range(0, k + 1):
            for S in itertools.combinations(range(k), size):
                outs = {val[x] for x in worlds if all(x[i] == w[i] for i in S)}
                if len(outs) == 1:
                    return size
        return k
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def depth(partial):
        cons = [w for w in worlds if all(p is None or w[i] == p for i, p in enumerate(partial))]
        if len({val[w] for w in cons}) == 1:
            return 0
        best = k
        for i, p in enumerate(partial):
            if p is not None:
                continue
            worst = 0
            for v in V:
                q = list(partial); q[i] = v
                worst = max(worst, 1 + depth(tuple(q)))
                if worst >= best:
                    break
            best = min(best, worst)
        return best
    periodic = tuple(V[e % 3] for e in var)
    cs = {w: cert_size(w) for w in worlds}
    return dict(t=t, variables=k, worlds=len(worlds), max_certificate=max(cs.values()),
                certificate_at_periodic=cs[periodic], formula_at_periodic=2 * ((t - 1) // 3) + 2,
                adaptive_depth_D=depth(tuple([None] * k)))


# ---------------- S02 audit: is the reference plan a maximal matching over allowed edges?
def allowed_edges(case):
    data = ref._Input(case)

    def dim(i):
        return data.effective(i)

    def side(i):
        f = dim(i)
        return f['side'] if f else 'UNKNOWN'

    def resolved(i):
        f = dim(i)
        return f['side'] if f else None

    def rank(a, b):
        e = data.edge(a, b)
        return e.get('score') if e['status'] == 'computed' else None
    scan = ref._Scan(len(data.items), data.settings, dim, side, resolved, rank)
    return [i for i in range(len(data.items) - 1) if scan.allowed(i)]


def is_maximal(case):
    paired = set()
    for u in ref.complete_plan(case):
        if len(u['slots']) == 2:
            paired.update(s['item'] for s in u['slots'])
    return all(i in paired or i + 1 in paired for i in allowed_edges(case))
