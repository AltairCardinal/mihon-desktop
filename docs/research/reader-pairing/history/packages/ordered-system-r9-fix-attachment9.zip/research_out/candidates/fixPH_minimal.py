"""Fix round PH: one minimal adversarial instance per workload class, each an
executable check of the adversarial property against the mechanism it targets.
Each function returns dict(cls, mechanism, property, holds, details).  Small
sizes only (seconds); development seeds only."""
import itertools
import math
import statistics
from copy import deepcopy

import paths  # noqa: F401
import reference as ref
import omega as O
from coupling import Session, Witness
from corrected_owner import Owner
from common import unit_of, roundtrip
import fixPH_workloads as PW
import fixPH_bounds as B


def _r(cls, mech, prop, holds, **details):
    return dict(cls=cls, mechanism=mech, property=prop, holds=bool(holds), details=details)


def m01():
    n = 12
    a = B.periodic_chain(n)
    b = B.edited(a, 1, 1.0)
    ma, mb = B.members(a), B.members(b)
    far = max(p for p in range(n) if ma[p][0] != mb[p][0])
    return _r('W01', 'any fixed-radius exact rule / local certifier', 'one rank edit (edge 1) changes the unit of a far item',
              far >= n - 3, farthest_changed=far, n=n)


def m02():
    """Island B fully known (analyses + internal ranks) yet its target is ambiguous:
    entry state depends on the unknown bridge, so islands cannot assume independent entries."""
    for seed in range(40):
        tr = PW.w02_sparse_islands(seed, n=16, island=4)
        c = tr['initial']
        known = [i for i, it in enumerate(c['items']) if it['analysis'].get('status') == 'computed']
        isl_b = [i for i in known if i >= 8]
        for t in isl_b[1:-1]:
            st, _ = O.certify_exact(c, t, 'nonneg', False, limit=10 ** 6)
            if st == 'ambiguous':
                return _r('W02', 'interval summary with assumed entry (O05/B01)',
                          'fully known island target ambiguous because the bridge is unknown', True,
                          seed=seed, target=t, island=isl_b)
    return _r('W02', 'interval summary with assumed entry', 'fully known island target ambiguous', False)


def m03():
    import wpC_structures as WS
    s = PW.w03_long_unqueried_updates(0, n=64, updates=120)
    tree = WS.DirtyLogTree(s['case'], cap=8)
    for op in s['ops']:
        if op[0] == 'set_edge':
            tree.set_edge(op[1], op[2])
    case = deepcopy(s['case'])
    for op in s['ops']:
        if op[0] == 'set_edge':
            case['edges'][op[1]] = op[2]
    t = s['ops'][-1][1]
    ok = tree.unit(t) == unit_of(ref.complete_plan(case), t)
    return _r('W03', 'bounded dirty log (C02-A)', 'long unqueried update run overflows the log (forced full drop) yet stays exact',
              tree.work['log_overflow_drops'] >= 1 and ok, overflow_drops=tree.work['log_overflow_drops'], exact=ok)


def m04():
    import wpC_structures as WS
    s = PW.w04_query_mode_switch(0, n=96, hot=20, jumps=24, flips=6)
    h = WS.Hybrid(s['case'], cap=16, quiet_to_demote=4)
    case = deepcopy(s['case'])
    wrong = 0
    for op in s['ops']:
        if op[0] == 'set_edge':
            h.set_edge(op[1], op[2]); case['edges'][op[1]] = op[2]
        elif op[0] == 'query':
            wrong += h.unit(op[1]) != unit_of(ref.complete_plan(case), op[1])
        elif op[0] == 'full':
            for t in range(len(case['items'])):
                h.unit(t)
    return _r('W04', 'resync/tree hybrid promote/demote (C03)', 'mode switch + front flips force at least one promotion (tree build)',
              h.work['promotions'] >= 1 and wrong == 0, promotions=h.work['promotions'], demotions=h.work['demotions'],
              wrong=wrong)


def _wit(i, raw):
    return Witness(analysis=dict(status='computed', fact=dict(state='NARROW', width=100, height=200, rotation=0,
                                                               orientation=1, side='UNKNOWN'), version=1), raw=raw)


def m05():
    tr = PW.w05_resident_missing_derivation(0, n=8, holes=2)
    out = {}
    for rc in (1, 2):
        s = Session(tr['initial'], raw_capacity=rc)
        for i in (3, 4):
            tk = s.acquire(i); s.finish(tk, _wit(i, tr['world'][i]['raw'])); s.consume(tk)
        out[rc] = s.metrics['rank_computations']
    return _r('W05', 'package Session.consume (evict-before-derive, K01)',
              'at raw capacity 1 two adjacent admitted witnesses never derive their rank', out[1] == 0 and out[2] >= 1,
              rank_computations_by_capacity=out)


def m06():
    import workloads as WW
    tr = WW.w06_complete_analysis_ambiguous(0, n=8)
    amb = [t for t in range(8) if O.certify_exact(tr['initial'], t, 'nonneg', False, limit=10 ** 6)[0] == 'ambiguous']
    from strong import StrongSession
    s = StrongSession(tr['initial'], strong=dict(kind='exact', domain='nonneg', gate='sound'))
    import coupled_runner as CR
    truth = CR.truth_units(tr['initial'], tr['world'])
    wrong = sum(1 for t in range(8) if (lambda v: v['status'] == 'certified' and v['unit'] != truth[t])(s.certify(t, mode='S')))
    return _r('W06', 'strong certification (no mis-certification)', 'all analyses known, some targets still ambiguous; strong never certifies wrong',
              len(amb) >= 1 and wrong == 0, ambiguous_targets=amb, wrong=wrong)


def m07():
    """All 5! orders of {complete a task, invalidate support, publish old cert, confirm, cancel}
    at one logical instant on the package Session: no stale publication, no confirmation of a
    stale publication, confirmed => current publication."""
    tr = PW.w05_resident_missing_derivation(1, n=8, holes=0)
    base = tr['initial']
    viol = 0; orders = 0
    for perm in itertools.permutations(('complete', 'invalidate', 'publish', 'confirm', 'cancel')):
        s = Session(base, capacity=2)
        v = s.certify(2)
        if v['status'] != 'certified':
            continue
        tk = s.acquire(6)
        e = next(x for x in s.owner._case['edges'] if x['first'] == 2)
        orders += 1
        for op in perm:
            if op == 'complete':
                if s.task(tk) is not None:
                    s.finish(tk, _wit(6, 1)); s.consume(tk)
            elif op == 'invalidate':
                s.owner.apply(edge_updates={(2, 3): dict(e, score=(e['score'] or 0) + 100, version=9)})
            elif op == 'publish':
                r = s.publish(2, v['certificate'])
                cur = s._certificate_current(s._certs[v['certificate']])
                viol += (r == 'published') and not cur
            elif op == 'confirm':
                r = s.confirm(2)
                if r == 'confirmed':
                    viol += not s._certificate_current(s._certs[s._published_handles[2]])
            elif op == 'cancel':
                s.cancel(tk)
        for t, u in s.confirmed.items():
            viol += t not in s.published
    return _r('W07', 'Session publish/confirm linearisation (A04/H01)', 'no stale publish/confirm over all same-instant orders',
              viol == 0 and orders == 120, orders=orders, violations=viol)


def m08():
    tr = PW.w08_cancel_without_exit(0, n=8, optional=2)
    s = Session(tr['initial'], capacity=1)
    t1 = s.acquire(0, required=False)
    st = s.cancel(t1)
    refused = s.acquire(1) is None
    occ = s.occupied
    fin = s.finish(t1, _wit(0, 1))
    after = s.acquire(1) is not None
    return _r('W08', 'capacity ledger (nonpreemptible cancel)', 'cancel does not free the slot until the physical finish',
              st == 'cancelling' and refused and occ == 1 and fin == 'discarded' and after,
              cancel=st, refused_while_cancelling=refused, finish=fin, admitted_after_exit=after)


def m09():
    tr = PW.w09_high_fanout_bottleneck(0, n=16, fanout=6)
    k = tr['meta']['shared_item']
    s = Session(tr['initial'], capacity=3)
    toks = {s.acquire(k) for _ in range(6)}
    return _r('W09', 'shared physical task (I03)', 'six consumers of the slow witness share one admission; first result waits for it',
              len(toks) == 1 and s.metrics['physical_admissions'] == 1,
              admissions=s.metrics['physical_admissions'], slow_service_u=tr['meta']['service_u_by_item'][str(k)])


def m10():
    tr = PW.w10_correlated_churn(0, n=10, changes=4, interval=2, service_u=3)
    s = Session(tr['initial'])
    tk = s.acquire(7)
    case = s.observe(); case['items'][7]['content_version'] = 1
    s.rebind(case)                                   # churn faster than service
    r = s.finish(tk, _wit(7, 5))
    return _r('W10', 'stale completion rejection under churn (J04)', 'a change before the service finishes discards its completion',
              r == 'discarded' and s.occupied == 0, finish=r, occupied=s.occupied)


def m11():
    s = PW.w11_overload_fairness(0, horizon=120, req_gap=3, req_service=3, opt=3)
    t, queue_r, queue_o, served_o = 0, [], [a for a in s['arrivals'] if a['kind'] == 'optional'], 0
    arr = sorted([a for a in s['arrivals'] if a['kind'] == 'required'], key=lambda a: a['at'])
    busy_until, i = 0, 0
    while t < s['horizon']:
        while i < len(arr) and arr[i]['at'] <= t:
            queue_r.append(arr[i]); i += 1
        if t >= busy_until:
            if queue_r:
                busy_until = t + queue_r.pop(0)['service']
            elif queue_o:
                busy_until = t + queue_o.pop(0)['service']; served_o += 1
        t += 1
    return _r('W11', 'required-first admission at capacity 1', 'at load rho >= 1 optional work is starved for the whole horizon',
              s['rho'] >= 1 and served_o == 0, rho=s['rho'], optional_served=served_o, horizon=s['horizon'])


def m12():
    a = B.periodic_chain(6, (3.0, 2.0, 1.0))
    b = deepcopy(a)
    b['edges'][2]['score'] = b['edges'][1]['score']                     # equal: later does not win
    c = deepcopy(a)
    c['edges'][2]['score'] = math.nextafter(b['edges'][1]['score'], 0.0)  # one ulp smaller: later wins
    z0, z1 = deepcopy(a), deepcopy(a)
    z0['edges'][3]['score'] = 0.0; z1['edges'][3]['score'] = -0.0
    pb, pc = ref.complete_plan(roundtrip(b)), ref.complete_plan(roundtrip(c))
    same_zero = ref.complete_plan(roundtrip(z0)) == ref.complete_plan(roundtrip(z1))
    nan_rejected = False
    try:
        roundtrip(dict(x=float('nan')))
    except ValueError:
        nan_rejected = True
    return _r('W12', 'binary64 representatives / JSON contract (D02/D06)',
              'a one-ulp change flips a later_wins decision; +0/-0 equal; NaN rejected at the JSON boundary',
              pb != pc and same_zero and nan_rejected, ulp_flip=pb != pc, signed_zero_equal=same_zero, nan_rejected=nan_rejected)


def m13():
    tr = PW.w13_identity_aba(0, n=8)
    s = Session(tr['initial'])
    v = s.certify(2)
    caseA = s.observe()
    caseB = deepcopy(caseA); caseB['items'][2]['content_version'] = 1
    s.rebind(caseB); s.rebind(deepcopy(caseA))          # A -> B -> A (identical content again)
    r = s.publish(2, v['certificate'])
    return _r('W13', 'authority across incarnations (H05/R05)', 'after A->B->A the old certificate is not revived',
              v['status'] == 'certified' and r == 'unsigned', first=v['status'], publish_old=r)


def m14():
    tr = PW.w14_failure_families(0, n=12)
    kinds = tr['meta']['kinds']
    s = Session(tr['initial'])
    i = kinds['failed']
    tk = s.acquire(i); s.finish(tk, Witness(**tr['world'][i])); s.consume(tk)
    v = s.certify(i)
    j = kinds['no_raw']
    tk = s.acquire(j); s.finish(tk, Witness(**tr['world'][j])); s.consume(tk)
    no_raw = j not in s._raw
    return _r('W14', 'failure contract (blocked vs need_facts; no raw witness)',
              'a failed analysis yields blocked (not need_facts); available=False admits analysis without raw',
              v['status'] == 'blocked' and no_raw, failed_status=v['status'], no_raw_resident=no_raw)


def m15():
    s = PW.w15_space_skew(0, n=60, cheap=30, sweeps=3)
    o = Owner(s['case'])
    sizes, cheap = [], []
    for op in s['ops']:
        o.request(op[1])
        e = o._memo.get(op[1])
        if e is not None:
            sizes.append(len(e['support']))
            if op[1] < 6:
                cheap.append(len(e['support']))
    ratio = max(sizes) / statistics.median(cheap)
    return _r('W15', 'equal-space retention / size estimators (K02)',
              'one expensive long support vs many cheap small ones: max support / median cheap support >= 5',
              ratio >= 5, max_support=max(sizes), median_cheap_support=statistics.median(cheap), ratio=round(ratio, 2),
              requests=len(sizes))


def m16():
    ws = PW.w16_witness_coincidence(0, n=12, extent=1)
    raws = [w['raw'] for w in ws['witnesses']]
    ranks = {abs(a - b) for a, b in zip(raws, raws[1:])}
    # the extension domain admits a strictly decreasing triple of adjacent ranks (needs 3 values)
    return _r('W16', 'extension domain vs service domain (E02/X10)',
              'with raw extent 1 only ranks {0,1} are realisable, so a strictly decreasing rank triple (an ext-domain world) is not physical',
              ranks <= {0, 1}, realised_ranks=sorted(ranks))


def m17():
    import coupled_runner as CR
    cfg = PW.w17_observer_perturbation(0, n=16, dup=3)['configs']
    rs = [CR.Runner(PW.for_runner(c, 'Runner'), policy='incumbent', service_u=3).run() for c in cfg]
    same = rs[0]['latency_u'] == rs[1]['latency_u'] and rs[0]['physical_admissions'] == rs[1]['physical_admissions']
    calls = [CR.Runner(PW.for_runner(c, 'Runner'), policy='incumbent', service_u=3) for c in cfg]
    cc = []
    for r in calls:
        r.run(); cc.append(r.session.metrics['certification_calls'])
    return _r('W17', 'logical counters vs physical events (M06)', 'extra wakeups change logical certification counters but not outputs or physical work',
              same and cc[1] > cc[0], certification_calls=cc, physical=[r['physical_admissions'] for r in rs])


def m18():
    import wpA_lib as A
    tr = PW.w18_composite(0, n=12, horizon=200)
    core = PW.for_runner(tr, 'ARunner')
    out = {}
    for pol in ('incumbent', 'gated_shadow'):
        r = A.make_runner(core, pol, service_u=3, q_u=1, capacity=3, raw_capacity=2).run(max_steps=40000)
        out[pol] = dict(wrong=r['wrong'], published=r['published'], intents=r['intents'], livelock=r['livelock'],
                        admissions=r['physical_admissions'], rebinds=r['rebinds'])
    ok = all(v['wrong'] == 0 for v in out.values())
    return _r('W18', 'composite lifecycle (ShadowRunner / ARunner core ops)',
              'reducible small composite trace runs with wrong=0; extended ops listed for the LC harness',
              ok, runs=out, dropped_ops=core['dropped_ops'], fingerprint=tr['fingerprint'])


ALL = [m01, m02, m03, m04, m05, m06, m07, m08, m09, m10, m11, m12, m13, m14, m15, m16, m17, m18]
