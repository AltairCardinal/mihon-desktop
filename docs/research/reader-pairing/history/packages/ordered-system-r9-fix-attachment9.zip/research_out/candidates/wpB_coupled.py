"""D4 wiring (WP-B): exact block summaries as the strong L1 attempt inside the
coupled Session, maintained incrementally from the owner's actual deltas.

BlockSession(StrongSession): strong kind 'blocks'.  Every successful
owner.apply (consume of a witness, derived ranks, harness scalar updates)
records the changed item ordinals / edge firsts; identity, order or settings
changes (owner identity ticket) force a rebuild.  The certificate support is
the same conservative range as strong.py ([0, t+3]); publication/confirmation
use the unchanged Session guards, so stale certificates are rejected exactly
as for the tree candidate.
"""
import time
from copy import deepcopy

import paths  # noqa: F401
from strong import StrongSession, support_keys
import wpB_blocks as WB
import coupled_runner as CR


class TxnBlockSummary(WB.BlockSummary):
    """BlockSummary whose lazily created table entries are logged per dict
    object, so a budget-stopped call can remove exactly what it created."""

    def __init__(self, *a, **kw):
        self._log = None
        super().__init__(*a, **kw)

    def exits(self, b, key):
        tab = self.tables[b]
        fresh = key not in tab
        out = super().exits(b, key)
        if fresh and self._log is not None:
            self._log.append((tab, key))
        return out


class BlockSession(StrongSession):
    """Budget contract BC-2: block table fills, frontier extensions and the tail
    exploration are charged to the calling certify; a stopped call removes the
    entries it created (and a summary it built) and keeps the dirty sets;
    invalidation from owner deltas is maintenance and is applied regardless."""

    _route_name = 'blocks'

    def __init__(self, case, *, strong=None, block=8, **kw):
        super().__init__(case, strong=strong, **kw)
        self.block = block
        self._bs = None
        self._bs_ticket = None
        self._dirty_items, self._dirty_edges = set(), set()
        orig = self.owner.apply

        def tracked_apply(**kwargs):
            changed = orig(**kwargs)
            for i in (kwargs.get('item_updates') or {}):
                self._dirty_items.add(i)
            for (a, b) in (kwargs.get('edge_updates') or {}):
                if b == a + 1:
                    self._dirty_edges.add(a)
            return changed
        self.owner.apply = tracked_apply

    def rebind(self, case, **kw):
        super().rebind(case, **kw)
        self._bs = None
        self._dirty_items.clear(); self._dirty_edges.clear()

    def close(self):
        super().close()
        self._bs = None
        self._bs_ticket = None
        self._cur_snap = None
        self._dirty_items.clear(); self._dirty_edges.clear()

    def residency(self):
        if self._bs is None:
            return 0
        sz = self._bs.size()
        return sz['entries'] + sz['exit_keys'] + len(self._bs.frontier_at)

    def _summary(self):
        ticket = self.owner._guard()
        if self._bs is None or self._bs_ticket != ticket:
            cfg = self.strong
            self._bs = TxnBlockSummary(deepcopy(self.owner._case), cfg['domain'], cfg['alpha'], block=self.block)
            self._bs_ticket = ticket
            self._dirty_items.clear(); self._dirty_edges.clear()
            self.metrics['block_rebuilds'] += 1
            return self._bs
        if self._dirty_items or self._dirty_edges:
            case = self.owner._case
            recs = {(e['first'], e['second']): e for e in case.get('edges', [])}
            items = {p: deepcopy(case['items'][p]) for p in self._dirty_items}
            edges = {a: deepcopy(recs.get((a, a + 1))) for a in self._dirty_edges}
            try:
                self._bs.update(items=items, edges=edges)
            except ValueError:                       # domain became illegal -> rebuild wider
                self._bs = None
                return self._summary()
            self.metrics['block_updates'] += 1
            self._dirty_items.clear(); self._dirty_edges.clear()
        return self._bs

    # ---- transaction hooks (BC-2): exact restore of the pre-call structure
    def _txn_begin(self):
        bs = self._bs
        snap = dict(bs=bs, ticket=self._bs_ticket, di=set(self._dirty_items), de=set(self._dirty_edges),
                    tables=list(bs.tables) if bs is not None else None,
                    frontier=dict(bs.frontier_at) if bs is not None else None, log=[])
        self._cur_snap = snap
        return snap

    def _txn_rollback(self, snap):
        cur = self._bs
        if cur is not None:
            for tab, key in reversed(snap['log']):
                tab.pop(key, None)
            cur._log = None
        bs = snap['bs']
        if bs is not None:
            bs.tables = snap['tables']
            bs.frontier_at = snap['frontier']
            bs._log = None
        self._bs, self._bs_ticket = bs, snap['ticket']
        self._dirty_items, self._dirty_edges = snap['di'], snap['de']
        self._cur_snap = None                         # LC E5 finding: do not keep the pre-call summary reachable
        self.metrics['block_rollbacks'] += 1

    def _txn_commit(self, snap):
        if self._bs is not None:
            self._bs._log = None
        self._cur_snap = None

    def _strong_compute(self, target, limit):
        if self.strong.get('kind') != 'blocks':
            return StrongSession._strong_compute(self, target, limit)
        bs = self._summary()                          # maintenance: no evaluations
        bs._log = self._cur_snap['log']
        st, unit = bs.certify(target)                 # charged: table fills, frontier, tail
        return st, unit, 'blocks'

    def certify(self, target, *, mode='L0', budget=None):
        if mode != 'S' or self.strong.get('kind') != 'blocks':
            return super().certify(target, mode=mode, budget=budget)
        base, l0_steps = self._base_l0(target, budget)
        if base['status'] != 'need_facts':
            return base
        return self._strong_call(target, base, l0_steps, budget)


class BlockRunner(CR.Runner):
    def __init__(self, trace, *, block=8, **kw):
        super().__init__(trace, **kw)
        strong = kw.get('strong')
        self.session = BlockSession(trace['initial'], capacity=kw.get('capacity', 3),
                                    raw_capacity=kw.get('raw_capacity', 3), strong=strong, block=block)
