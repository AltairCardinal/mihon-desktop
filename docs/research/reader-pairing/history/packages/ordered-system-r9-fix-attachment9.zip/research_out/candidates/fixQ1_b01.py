"""B01 (fix round, Q1): exact interval summaries -- explicit finite relation
tables vs a canonical decision diagram.

Route 1  TABLE  wpB_blocks.BlockSummary: per block b a dict
                entry key -> frozenset(exit keys); keys are (cursor state,
                pruned assignment) with ABSOLUTE positions.
Route 2  ZDD    a canonical zero-suppressed decision diagram (reduced, ordered,
                hash-consed through ONE unique table shared by all blocks).
                Literals are boundary variables with positions RELATIVE to the
                block boundary; a relation R_b is the family of literal sets
                {in:x | x in entry key} U {out:y | y in exit key}, with every
                in-literal ordered before every out-literal.  Frontiers are ZDDs
                over in-literals; composition is a relational image computed by
                a memoised ZDD recursion, followed by a structural out->in retag.
                Equal relative relations of different blocks are the SAME node.

Both routes run the identical block step (the frozen scan under explore) for
every (block, entry key) they need, so evaluation counts are equal by
construction; they differ in representation, sharing and composition.

Literal encoding (relative to boundary L): ('S', s) cursor state (0..9);
('st', p-L, v), ('sd', p-L, v), ('rk', a-L, v), ('lt', x', y', v) with edge
terms ('e', a) -> ('e', a-L).  Lemma B-1 (proofs/wpB.md) gives the sufficient
boundary interface; `ablation()` measures which variable classes are
necessary (dropping them changes some certified unit set).
"""
import copy
import sys
import tracemalloc

import paths  # noqa: F401
import transducer as T
import omega as O
import wpB_blocks as WB


# ----------------------------------------------------------------- ZDD core
class ZDD:
    """Canonical ZDD manager.  Nodes are ints; 0 = empty family, 1 = {{}}.
    Literal order: sort key of the literal (in-literals before out-literals)."""

    def __init__(self):
        self.unique = {}            # (lit, lo, hi) -> node id
        self.nodes = [None, None]   # id -> (lit, lo, hi)
        self.memo = {}
        self.ops = 0

    @staticmethod
    def order(lit):
        tag = lit[0]                # 'in' / 'out'
        return (0 if tag == 'in' else 1, repr(lit[1]))

    def mk(self, lit, lo, hi):
        if hi == 0:
            return lo                # zero-suppression rule
        key = (lit, lo, hi)
        nid = self.unique.get(key)
        if nid is None:
            nid = len(self.nodes)
            self.nodes.append(key)
            self.unique[key] = nid
        return nid

    def top(self, f):
        return None if f < 2 else self.nodes[f][0]

    def from_set(self, lits):
        f = 1
        for lit in sorted(lits, key=self.order, reverse=True):
            f = self.mk(lit, 0, f)
        return f

    def union(self, f, g):
        if f == 0 or f == g:
            return g
        if g == 0:
            return f
        if f > g:
            f, g = g, f
        k = ('u', f, g)
        r = self.memo.get(k)
        if r is not None:
            return r
        self.ops += 1
        tf, tg = self.top(f), self.top(g)
        if tf is None:                       # f == 1
            lit, lo, hi = self.nodes[g]
            r = self.mk(lit, self.union(1, lo), hi)
        elif tg is None:
            lit, lo, hi = self.nodes[f]
            r = self.mk(lit, self.union(lo, 1), hi)
        else:
            of, og = self.order(tf), self.order(tg)
            lf, lof, hif = self.nodes[f]
            lg, log_, hig = self.nodes[g]
            if of == og:
                r = self.mk(lf, self.union(lof, log_), self.union(hif, hig))
            elif of < og:
                r = self.mk(lf, self.union(lof, g), hif)
            else:
                r = self.mk(lg, self.union(f, log_), hig)
        self.memo[k] = r
        return r

    def has_empty(self, f):
        while f >= 2:
            f = self.nodes[f][1]
        return f == 1

    def image(self, F, R):
        """{out(S) : S in R, in(S) in F}; F over in-literals only."""
        if F == 0 or R == 0:
            return 0
        k = ('i', F, R)
        r = self.memo.get(k)
        if r is not None:
            return r
        self.ops += 1
        tr = self.top(R)
        if tr is None or tr[0] == 'out':
            r = R if self.has_empty(F) else 0
        else:
            tf = self.top(F)
            lr, lor, hir = self.nodes[R]
            if tf is None:                   # F = {{}}: R sets containing lr cannot match
                r = self.image(F, lor)
            else:
                of, orr = self.order(tf), self.order(tr)
                lf, lof, hif = self.nodes[F]
                if orr < of:
                    r = self.image(F, lor)
                elif of < orr:
                    r = self.image(lof, R)
                else:
                    r = self.union(self.image(hif, hir), self.image(lof, lor))
        self.memo[k] = r
        return r

    def retag(self, f):
        """out-literals -> in-literals (order preserved, structural map)."""
        if f < 2:
            return f
        k = ('r', f)
        r = self.memo.get(k)
        if r is not None:
            return r
        lit, lo, hi = self.nodes[f]
        r = self.mk(('in', lit[1]), self.retag(lo), self.retag(hi))
        self.memo[k] = r
        return r

    def sets(self, f, prefix=()):
        if f == 0:
            return
        if f == 1:
            yield prefix
            return
        lit, lo, hi = self.nodes[f]
        yield from self.sets(lo, prefix)
        yield from self.sets(hi, prefix + (lit,))

    def reachable(self, roots):
        seen, stack = set(), [r for r in roots if r >= 2]
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            _l, lo, hi = self.nodes[x]
            for y in (lo, hi):
                if y >= 2 and y not in seen:
                    stack.append(y)
        return seen


def _rel_term(t, L):
    return ('e', t[1] - L) if isinstance(t, tuple) and t and t[0] == 'e' else t


def _abs_term(t, L):
    return ('e', t[1] + L) if isinstance(t, tuple) and t and t[0] == 'e' else t


def key_to_lits(key, L, tag):
    s, asg = key
    lits = [(tag, ('S', s))]
    for k, v in asg:
        if k[0] in ('st', 'sd', 'rk'):
            lits.append((tag, (k[0], k[1] - L, v)))
        else:                                    # ('lt', x, y)
            lits.append((tag, ('lt', _rel_term(k[1], L), _rel_term(k[2], L), v)))
    return lits


def lits_to_key(lits, L):
    s, asg = None, []
    for _tag, x in lits:
        if x[0] == 'S':
            s = x[1]
        elif x[0] in ('st', 'sd', 'rk'):
            asg.append(((x[0], x[1] + L), x[2]))
        else:
            asg.append((('lt', _abs_term(x[1], L), _abs_term(x[2], L)), x[3]))
    return (s, frozenset(asg))


class ZDDSummary:
    """Route 2: same lazily computed block runs as BlockSummary, stored and
    composed as canonical ZDDs (one shared unique table)."""

    def __init__(self, case, domain='ext', alpha=True, block=8, mgr=None, counters=None):
        self.inner = WB.BlockSummary(case, domain, alpha, block=block)   # facts, ctx, _run_block
        self.B, self.n, self.nb = self.inner.B, self.inner.n, self.inner.nb
        self.z = mgr if mgr is not None else ZDD()
        self.rel = [0] * self.nb                 # R_b as ZDD
        self.done = [set() for _ in range(self.nb)]   # entry keys already materialised in R_b
        self.frontier_at = {0: self.z.from_set(key_to_lits((T.S0, frozenset()), 0, 'in'))}
        self.c = counters if counters is not None else {}
        for k in ('evaluations', 'block_runs', 'max_frontier_keys'):
            self.c.setdefault(k, 0)

    def _ensure(self, b, Fz):
        """Materialise R_b for every key of frontier Fz (relative in-literals)."""
        L = b * self.B
        R = (b + 1) * self.B
        for lits in self.z.sets(Fz):
            key = lits_to_key(lits, L)
            if key in self.done[b]:
                continue
            ev0 = self.inner.c['evaluations']
            exits = self.inner._run_block(b, key)
            self.c['evaluations'] += self.inner.c['evaluations'] - ev0
            self.c['block_runs'] += 1
            ent = key_to_lits(key, L, 'in')
            fam = 0
            for x in exits:
                fam = self.z.union(fam, self.z.from_set(ent + key_to_lits(x, R, 'out')))
            self.rel[b] = self.z.union(self.rel[b], fam)
            self.done[b].add(key)

    def frontier(self, bb):
        known = max(k for k in self.frontier_at if k <= bb)
        f = self.frontier_at[known]
        for b in range(known, bb):
            self._ensure(b, f)
            f = self.z.retag(self.z.image(f, self.rel[b]))
            self.frontier_at[b + 1] = f
        return f

    def certify(self, target):
        start_pos = max(0, target - 1)
        bb = start_pos // self.B
        Fz = self.frontier(bb)
        L = bb * self.B
        frontier = {lits_to_key(l, L) for l in self.z.sets(Fz)}
        self.c['max_frontier_keys'] = max(self.c['max_frontier_keys'], len(frontier))
        ctx = self.inner.ctx
        units = {}
        for i in range(L, target + 1):
            include = i >= target - 1
            nxt = set()
            for s, asg in frontier:
                if s >> 1 == T.SKIP and i == target:
                    continue
                res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(asg))
                self.c['evaluations'] += len(res)
                for (ns, unit), a in res:
                    if include and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                        units[T._key(unit)] = unit
                    elif i < target:
                        nxt.add((ns, frozenset(O._prune(a, i).items())))
            frontier = nxt
        if not units:
            return 'contradiction', None
        if len(units) == 1:
            return 'certified', next(iter(units.values()))
        return 'ambiguous', units

    def compact(self):
        """Garbage-collect: keep only nodes reachable from R_b and cached frontiers, drop op memo."""
        roots = [r for r in self.rel] + list(self.frontier_at.values())
        live = sorted(self.z.reachable(roots))
        new = ZDD()
        remap = {0: 0, 1: 1}
        for x in live:                       # children have smaller ids than parents
            lit, lo, hi = self.z.nodes[x]
            remap[x] = new.mk(lit, remap[lo], remap[hi])
        self.rel = [remap[r] for r in self.rel]
        self.frontier_at = {k: remap[v] for k, v in self.frontier_at.items()}
        self.z = new
        return len(live)

    def size(self):
        roots = [r for r in self.rel] + list(self.frontier_at.values())
        live = self.z.reachable(roots)
        return dict(zdd_live_nodes=len(live), zdd_unique_table=len(self.z.unique),
                    distinct_relations=len({r for r in self.rel if r}), blocks=self.nb)


# ----------------------------------------------------------------- measurement helpers
def table_size(bs):
    entries = sum(len(t) for t in bs.tables)
    exits = sum(len(v) for t in bs.tables for v in t.values())
    lits = sum(1 + len(k[1]) + sum(1 + len(x[1]) for x in v) for t in bs.tables for k, v in t.items())
    return dict(entries=entries, exit_keys=exits, stored_literals=lits)


def deep_bytes(obj, seen=None):
    """Python object bytes reachable from obj (sys.getsizeof, id-deduplicated; ints/strs counted once)."""
    seen = set() if seen is None else seen
    stack, total = [obj], 0
    while stack:
        o = stack.pop()
        if id(o) in seen:
            continue
        seen.add(id(o))
        total += sys.getsizeof(o)
        if isinstance(o, dict):
            stack.extend(o.keys()); stack.extend(o.values())
        elif isinstance(o, (list, tuple, set, frozenset)):
            stack.extend(o)
    return total


def measured_bytes(build):
    """tracemalloc current bytes held by the object returned by build() (structure only)."""
    tracemalloc.start()
    base = tracemalloc.get_traced_memory()[0]
    obj = build()
    cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return obj, cur - base, peak - base


def run_both(case, block, domain='ext', alpha=False, targets=None):
    n = len(case['items'])
    targets = range(n) if targets is None else targets

    def b1():
        bs = WB.BlockSummary(copy.deepcopy(case), domain, alpha, block=block)
        res = [bs.certify(t) for t in targets]
        return bs, res

    def b2():
        zs = ZDDSummary(copy.deepcopy(case), domain, alpha, block=block)
        res = [zs.certify(t) for t in targets]
        return zs, res
    (bs, r1), by1, pk1 = measured_bytes(b1)
    (zs, r2), by2, pk2 = measured_bytes(b2)
    same = all((a[0] == b[0]) and (a[0] != 'certified' or a[1] == b[1]) for a, b in zip(r1, r2))
    tbytes = deep_bytes([bs.tables, bs.frontier_at])
    zsz = zs.size(); ops = zs.z.ops
    zraw = deep_bytes([zs.z.nodes, zs.z.unique, zs.z.memo, zs.rel, zs.frontier_at])
    zs.compact()
    zcomp = deep_bytes([zs.z.nodes, zs.z.unique, zs.rel, zs.frontier_at])
    return dict(same=same,
                table=dict(table_size(bs), evaluations=bs.c['evaluations'], structure_bytes=tbytes,
                           traced_bytes=by1, traced_peak=pk1),
                zdd=dict(zsz, evaluations=zs.c['evaluations'], structure_bytes_uncompacted=zraw,
                         structure_bytes_compacted=zcomp, traced_bytes=by2, traced_peak=pk2, zdd_ops=ops)), r1, r2


# ----------------------------------------------------------------- minimal cross-boundary variables
CLASSES = ('manual_bit', 'st_b-1', 'st_b', 'st_b+1', 'st_b+2', 'sd_b-1', 'sd_b', 'sd_b+1', 'sd_b+2', 'rk_b', 'lt')


def _drop(asg_items, i, cls):
    """Remove one variable class from a pruned assignment after step i (boundary b=i+1)."""
    b = i + 1
    out = []
    for k, v in asg_items:
        if cls.startswith(('st_', 'sd_')):
            kind, off = cls[:2], cls[3:]
            d = {'b-1': -1, 'b': 0, 'b+1': 1, 'b+2': 2}[off]
            if k[0] == kind and k[1] == b + d:
                continue
        elif cls == 'rk_b' and k[0] == 'rk':
            continue
        elif cls == 'lt' and k[0] == 'lt':
            continue
        out.append((k, v))
    return frozenset(out)


def certify_ablated(case, target, cls, domain='ext', alpha=False, block=1):
    """Exact DP from 0 where, at every block boundary (multiple of `block`), the
    variable class `cls` is forgotten (projected away) -- the cross-boundary
    interface without that class."""
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    ctx = T.Ctx(F)
    frontier = {(T.S0, frozenset())}
    units = {}
    for i in range(0, target + 1):
        include = i >= target - 1
        nxt = set()
        for s, asg in frontier:
            if s >> 1 == T.SKIP and i == target:
                continue
            for (ns, unit), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(asg)):
                if include and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                    units[T._key(unit)] = unit
                elif i < target:
                    pa = frozenset(O._prune(a, i).items())
                    if (i + 1) % block == 0:
                        if cls == 'manual_bit':
                            ns = ns & ~1
                        else:
                            pa = _drop(pa, i, cls)
                    nxt.add((ns, pa))
        frontier = nxt
    return set(units)
