"""Fix round PH, item 7b: deterministic generators for all 18 adversarial
workload classes of ADVERSARIAL_WORKLOADS.md, minimal adversarial instances
(executable checks) and the held-out suite builder.

Every generator is a pure function of (seed, size parameters); traces are
frozen before any policy runs.  Artifact kinds:
  session_trace  dict(name, cls, kind, initial, world, events, meta)  -- same format as
                 workloads.py; core ops {target, targets, tick, prefetch, evict_raw,
                 rebind(item, witness)} are consumed by wpA ARunner/ShadowRunner;
                 coupled_runner.Runner consumes {target, tick}.  Extended ops
                 {cancel, confirm, settings, close_rebind, late_fail} are for the LC
                 lifecycle harness; `for_runner` filters them explicitly and returns
                 the dropped counts (never silently).
  case_set       list of complete/partial cases (core oracle inputs)
  owner_stream   dict(case, ops=[('set_edge'|'set_item'|'query'|'full', ...)])
  sim_stream     dict(arrivals=[...]) for the abstract scheduling simulators
  witness_set    list of witness dicts (service-domain realisability)
  config_matrix  list of observer configurations over one session trace

Development seeds: 0..999 only.  Held-out seeds are chosen by the main session
after freezing (heldout_suite(seed_base) with seed_base >= 10**6).
"""
import hashlib
import json
import math
import random
from copy import deepcopy

import paths  # noqa: F401
import workloads as W
from common import fact, base_case

DEV_SEED_MAX = 999
V3 = (3, 2, 1)


def _guard_seed(seed, heldout=False):
    if not heldout and not 0 <= seed <= DEV_SEED_MAX:
        raise ValueError('development generators accept seeds 0..999 only; held-out via heldout_suite')


def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _wit(state='NARROW', raw=0, status='computed', available=True, side='UNKNOWN'):
    if status == 'failed':
        return dict(analysis=dict(status='failed', reason='READ', version=1), raw=None, available=False)
    return dict(analysis=dict(status='computed', fact=fact(state, side), version=1), raw=raw, available=available)


def periodic_world(n, V=V3, start=0):
    """Raws x_{i+1} = x_i + V[i mod 3]  =>  adapter rank |x_i - x_{i+1}| = V[i mod 3]
    (Lemma P family of fixPH_bounds, realisable in the service domain)."""
    x, out = start, []
    for i in range(n):
        out.append(_wit(raw=x))
        x += V[i % 3]
    return out


def _trace(cls, seed, name, initial, world, events, **meta):
    events = sorted(events, key=lambda e: e['at'])            # stable: equal times keep list order
    tr = dict(name=name, cls=cls, kind='session_trace', seed=seed, initial=initial, world=world, events=events,
              meta=meta)
    tr['fingerprint'] = fingerprint(dict(initial=initial, world=world, events=events))
    return tr


CORE_OPS = {'ARunner': {'target', 'targets', 'tick', 'prefetch', 'evict_raw', 'rebind'},
            'Runner': {'target', 'tick'}}


def for_runner(trace, runner='ARunner'):
    keep = CORE_OPS[runner]
    dropped = {}
    evs = []
    for e in trace['events']:
        if e['op'] in keep:
            evs.append(e)
        else:
            dropped[e['op']] = dropped.get(e['op'], 0) + 1
    out = dict(trace, events=evs)
    out['dropped_ops'] = dropped
    return out


# ============================================================ session-trace classes
def w01_phase_flip_chain(seed, n=32, holes=2, pins=(), opening='AUTO', edit_at=None, count=16, gap=10):
    """W01: Lemma-P periodic chain (strictly separating phases A/B), missing ranks,
    optional pins/opening, optional single-point change position (rebind of the
    item after `edit_at` so that edge edit_at flips the phase)."""
    _guard_seed(seed, getattr(w01_phase_flip_chain, '_heldout', False))
    rng = random.Random(seed)
    world = periodic_world(n)
    missing = set(rng.sample(range(1, n - 1), min(holes, n - 2)))
    init = W._initial(world, set(range(n)), [a for a in range(n - 1) if a not in missing])
    init['settings']['pinned_links'] = sorted(pins)
    init['settings']['opening'] = opening
    events = W._targets(rng, n, 'jump', count, gap)
    if edit_at is not None:            # content change at edit_at+1 making edge edit_at small (phase flip)
        k = edit_at + 1
        w = deepcopy(world[k]); w['raw'] = world[edit_at]['raw'] + 1
        events.append(dict(at=count * gap // 2, op='rebind', item=k, witness=w))
    return _trace('W01', seed, f'W01_n{n}_h{holes}_s{seed}', init, world, events, holes=sorted(missing))


def w02_sparse_islands(seed, n=24, island=6, count=16, gap=10):
    _guard_seed(seed, getattr(w02_sparse_islands, '_heldout', False))
    tr = W.w02_islands(seed, n=n, island=island, count=count, gap=gap)
    return _trace('W02', seed, tr['name'], tr['initial'], tr['world'], tr['events'])


def w05_resident_missing_derivation(seed, n=24, holes=4, count=24, gap=10, evict_every=None):
    _guard_seed(seed, getattr(w05_resident_missing_derivation, '_heldout', False))
    tr = W.w05_raw_eviction(seed, n=n, holes=holes, count=count, gap=gap)
    evs = list(tr['events'])
    if evict_every:
        evs += [dict(at=t, op='evict_raw') for t in range(evict_every, count * gap, evict_every)]
    return _trace('W05', seed, tr['name'], tr['initial'], tr['world'], evs)


def w06_complete_analysis_insufficient(seed, n=12, count=12, gap=10):
    _guard_seed(seed, getattr(w06_complete_analysis_insufficient, '_heldout', False))
    tr = W.w06_complete_analysis_ambiguous(seed, n=n, count=count, gap=gap)
    return _trace('W06', seed, tr['name'], tr['initial'], tr['world'], tr['events'])


def w07_simultaneous_completion_invalidation(seed, n=10, count=8, gap=6, service_u=3):
    """Exogenous events placed exactly on service-completion instants (at = k*service_u):
    targets, content changes (rebind), confirms and cancels share logical times."""
    _guard_seed(seed, getattr(w07_simultaneous_completion_invalidation, '_heldout', False))
    rng = random.Random(seed)
    world = periodic_world(n)
    known = set(rng.sample(range(n), n // 2))
    init = W._initial(world, known, [a for a in range(n - 1) if a in known and a + 1 in known])
    evs = []
    for k in range(count):
        t = k * service_u
        tgt = rng.randrange(n)
        evs.append(dict(at=t, op='target', target=tgt))
        evs.append(dict(at=t, op='confirm', target=tgt))
        if rng.random() < 0.4:
            j = rng.randrange(n); w = deepcopy(world[j]); w['raw'] += 1
            evs.append(dict(at=t, op='rebind', item=j, witness=w))
        if rng.random() < 0.3:
            evs.append(dict(at=t, op='cancel', item=rng.randrange(n)))
    return _trace('W07', seed, f'W07_n{n}_s{seed}', init, world, evs, service_u=service_u)


def w08_cancel_without_exit(seed, n=16, optional=6, bursts=3, burst_len=4, gap=4):
    """Optional prefetches fill capacity, then required bursts; optional items are
    cancelled (logical) while their physical tasks keep running."""
    _guard_seed(seed, getattr(w08_cancel_without_exit, '_heldout', False))
    rng = random.Random(seed)
    world = W._world(rng, n)
    init = W._initial(world, set(), [])
    evs, t = [], 0
    opts = rng.sample(range(n), optional)
    for i in opts:
        evs.append(dict(at=0, op='prefetch', item=i))
    for b in range(bursts):
        t += gap
        for i in opts[: 2]:
            evs.append(dict(at=t, op='cancel', item=i))
        for _ in range(burst_len):
            evs.append(dict(at=t, op='target', target=rng.randrange(n)))
    return _trace('W08', seed, f'W08_n{n}_s{seed}', init, world, evs)


def w09_high_fanout_bottleneck(seed, n=24, fanout=6, slow_factor=10, gap=1):
    """Many targets whose certification needs the same slow witness (item k), plus
    cheap independent targets.  meta.service_u_by_item for simulators with
    per-item service; Session runners use uniform service (property: sharing)."""
    _guard_seed(seed, getattr(w09_high_fanout_bottleneck, '_heldout', False))
    rng = random.Random(seed)
    world = W._world(rng, n, p_wide=0.0)
    k = rng.randrange(2, n - 3)
    known = set(range(n)) - {k}
    init = W._initial(world, known, [a for a in range(n - 1) if a not in (k - 1, k)])
    targets = [max(0, k - 2 + j % 4) for j in range(fanout)]
    cheap = [rng.choice([x for x in range(n) if abs(x - k) > 4]) for _ in range(fanout)]
    evs = [dict(at=i * gap, op='target', target=t) for i, t in enumerate(targets)]
    evs += [dict(at=i * gap, op='target', target=t) for i, t in enumerate(cheap)]
    return _trace('W09', seed, f'W09_n{n}_f{fanout}_s{seed}', init, world, evs, shared_item=k,
                  service_u_by_item={str(k): slow_factor})


def w10_correlated_churn(seed, n=20, changes=12, interval=3, service_u=3, quiet_every=4, unrelated=0.3):
    """Content changes of neighbouring items every `interval` u (swept around
    service_u by the caller), unrelated far changes with probability `unrelated`,
    periodic quiet gaps."""
    _guard_seed(seed, getattr(w10_correlated_churn, '_heldout', False))
    rng = random.Random(seed)
    world = periodic_world(n)
    init = W._initial(world, set(range(n // 2)), [a for a in range(n // 2 - 1)])
    evs, t, focus = [], 0, rng.randrange(n // 2, n - 2)
    for c in range(changes):
        t += interval + (3 * service_u if quiet_every and c % quiet_every == quiet_every - 1 else 0)
        j = focus + rng.choice((-1, 0, 1)) if rng.random() > unrelated else rng.randrange(n)
        j = min(n - 1, max(0, j))
        w = deepcopy(world[j]); w['raw'] = (w['raw'] or 0) + c + 1
        evs.append(dict(at=t, op='rebind', item=j, witness=w))
        evs.append(dict(at=t, op='target', target=min(n - 1, focus)))
    return _trace('W10', seed, f'W10_n{n}_i{interval}_s{seed}', init, world, evs, interval=interval,
                  service_u=service_u)


def w13_identity_aba(seed, n=12, cycles=3, gap=8):
    """Content A -> B -> A of one item (repeated label service): rebind events with
    witness values alternating; LC harness also uses close_rebind of the whole case."""
    _guard_seed(seed, getattr(w13_identity_aba, '_heldout', False))
    rng = random.Random(seed)
    world = periodic_world(n)
    init = W._initial(world, set(range(n)), [a for a in range(n - 1)])
    j = rng.randrange(1, n - 1)
    A = deepcopy(world[j]); B = deepcopy(world[j]); B['raw'] = A['raw'] + 7
    evs, t = [], 0
    for c in range(cycles):
        for w in (B, A):
            t += gap
            evs.append(dict(at=t, op='rebind', item=j, witness=deepcopy(w)))
            evs.append(dict(at=t, op='target', target=j))
    evs.append(dict(at=t + gap, op='close_rebind'))
    return _trace('W13', seed, f'W13_n{n}_s{seed}', init, world, evs, aba_item=j)


def w14_failure_families(seed, n=16, gap=6):
    """Missing, temporary failure (failed then recovered witness), structural null
    (WIDE endpoint), no raw (available=False), and late failure of a shared item."""
    _guard_seed(seed, getattr(w14_failure_families, '_heldout', False))
    rng = random.Random(seed)
    world = periodic_world(n)
    init = W._initial(world, set(), [])                             # headers from the pre-failure world
    picks = rng.sample(range(1, n - 1), 4)
    world[picks[0]] = _wit(status='failed')                         # permanent failure
    world[picks[1]] = _wit('WIDE', raw=world[picks[1]]['raw'])      # structural null ranks
    world[picks[2]] = dict(world[picks[2]], available=False)        # analysis ok, no raw witness
    evs = [dict(at=k * gap, op='target', target=t) for k, t in enumerate(sorted(picks + [0, n - 1]))]
    j = picks[3]
    evs.append(dict(at=gap, op='rebind', item=j, witness=_wit(status='failed')))        # late failure
    evs.append(dict(at=5 * gap, op='rebind', item=j, witness=deepcopy(periodic_world(n)[j])))  # recovery
    return _trace('W14', seed, f'W14_n{n}_s{seed}', init, world, evs, kinds=dict(
        failed=picks[0], wide=picks[1], no_raw=picks[2], late_fail_then_recover=j))


def w17_observer_perturbation(seed, n=24, dup=3):
    """Same legal trace with `dup` extra wakeups (tick) at every event instant; the
    config_matrix toggles them (observer must not change outputs)."""
    _guard_seed(seed, getattr(w17_observer_perturbation, '_heldout', False))
    base = W.random_partial(seed, n=n)
    evs = list(base['events'])
    for e in base['events']:
        evs += [dict(at=e['at'], op='tick') for _ in range(dup)]
    perturbed = _trace('W17', seed, base['name'] + f'_dup{dup}', base['initial'], base['world'], evs)
    plain = _trace('W17', seed, base['name'] + '_dup0', base['initial'], base['world'], base['events'])
    return dict(kind='config_matrix', cls='W17', seed=seed, configs=[plain, perturbed])


def w18_composite(seed, n=64, horizon=2000, gap=10, churn_burst=4, evict_every=37, fail_at=None,
                  switch_at=None, close_at=None, long=False):
    """W18 composite long-lived pressure: long Lemma-P phase chain with holes, raw
    eviction, correlated churn bursts, late failure of a shared witness followed by
    recovery, a configuration switch (direction flip) and close+rebind.  `long=True`
    scales to a bounded long-lifetime run (resource/output caps are the caller's
    max_steps/horizon; hitting them is a result).  Reducible small form:
    w18_composite(seed, n=12, horizon=200)."""
    _guard_seed(seed, getattr(w18_composite, '_heldout', False))
    rng = random.Random(seed)
    if long:
        n, horizon = max(n, 256), max(horizon, 20000)
    world = periodic_world(n)
    holes = set(rng.sample(range(1, n - 1), max(2, n // 16)))
    init = W._initial(world, set(range(n)), [a for a in range(n - 1) if a not in holes])
    evs = []
    t = 0
    while t < horizon:
        evs.append(dict(at=t, op='target', target=rng.randrange(n)))
        t += gap
    for t in range(evict_every, horizon, evict_every):
        evs.append(dict(at=t, op='evict_raw'))
    # correlated churn bursts around a focus, interval ~ service time
    for b in range(max(1, horizon // 400)):
        focus = rng.randrange(2, n - 2)
        t0 = rng.randrange(horizon)
        for c in range(churn_burst):
            j = min(n - 1, max(0, focus + rng.choice((-1, 0, 1))))
            w = deepcopy(world[j]); w['raw'] = world[j]['raw'] + rng.choice((1, 2, 3))
            evs.append(dict(at=t0 + 3 * c, op='rebind', item=j, witness=w))
    fail_at = horizon // 3 if fail_at is None else fail_at
    shared = rng.randrange(1, n - 1)
    evs.append(dict(at=fail_at, op='rebind', item=shared, witness=_wit(status='failed')))
    evs.append(dict(at=fail_at + 4 * gap, op='rebind', item=shared, witness=deepcopy(world[shared])))
    evs.append(dict(at=fail_at, op='late_fail', item=shared))
    switch_at = horizon // 2 if switch_at is None else switch_at
    evs.append(dict(at=switch_at, op='settings', patch=dict(direction='BA')))
    close_at = (2 * horizon) // 3 if close_at is None else close_at
    evs.append(dict(at=close_at, op='close_rebind'))
    for k in range(4):
        evs.append(dict(at=close_at, op='confirm', target=rng.randrange(n)))
        evs.append(dict(at=close_at + 1, op='cancel', item=rng.randrange(n)))
    return _trace('W18', seed, f'W18_n{n}_H{horizon}_s{seed}', init, world, evs, holes=sorted(holes),
                  shared_failure_item=shared, switch_at=switch_at, close_at=close_at, long=long)


# ============================================================ non-trace classes
def w03_long_unqueried_updates(seed, n=256, updates=400, same_rate=0.5):
    """Owner stream: many updates (same-value rewrites mixed with real changes),
    no queries, then one far jump query."""
    _guard_seed(seed, getattr(w03_long_unqueried_updates, '_heldout', False))
    rng = random.Random(seed)
    case = base_case(n)
    for e in case['edges']:
        e['score'] = float(V3[e['first'] % 3])
    ops = []
    for _ in range(updates):
        a = rng.randrange(n - 1)
        if rng.random() < same_rate:
            ops.append(('set_edge', a, dict(case['edges'][a])))
        else:
            ops.append(('set_edge', a, dict(case['edges'][a], score=float(rng.choice((0.5, 1.0, 2.0, 3.0, 4.0))))))
    ops.append(('query', n - 2))
    return dict(kind='owner_stream', cls='W03', seed=seed, case=case, ops=ops)


def w04_query_mode_switch(seed, n=128, hot=40, full=2, jumps=40, flips=6):
    """Owner stream: hot point queries, then full outputs, then round trips/jumps,
    with front phase flips interleaved (forces propagation to the far end)."""
    _guard_seed(seed, getattr(w04_query_mode_switch, '_heldout', False))
    rng = random.Random(seed)
    case = base_case(n)
    for e in case['edges']:
        e['score'] = float(V3[e['first'] % 3])
    hotspot = rng.randrange(n // 4, n // 2)
    ops = [('query', hotspot + rng.randrange(-2, 3)) for _ in range(hot)]
    for f in range(flips):
        ops.append(('set_edge', 1, dict(case['edges'][1], score=float(V3[2] if f % 2 == 0 else V3[1]))))
        ops += [('full',)] * (full if f == 0 else 0)
        ops += [('query', rng.randrange(n)) for _ in range(jumps // flips)]
    return dict(kind='owner_stream', cls='W04', seed=seed, case=case, ops=ops)


def w11_overload_fairness(seed, horizon=200, req_gap=3, req_service=3, burst=0, opt=5, opt_service=5):
    """Sim stream: required arrivals every req_gap (load rho = req_service/req_gap),
    optional jobs waiting from t=0; bursts add `burst` extra required at once."""
    _guard_seed(seed, getattr(w11_overload_fairness, '_heldout', False))
    rng = random.Random(seed)
    arr = [dict(at=0, kind='optional', service=opt_service, id=f'o{k}') for k in range(opt)]
    t, k = 0, 0
    while t < horizon:
        for _ in range(1 + (burst if rng.random() < 0.1 else 0)):
            arr.append(dict(at=t, kind='required', service=req_service, id=f'r{k}')); k += 1
        t += req_gap
    return dict(kind='sim_stream', cls='W11', seed=seed, arrivals=arr, rho=req_service / req_gap, horizon=horizon)


def w12_numeric_edges(seed, n=8, count=20):
    """Case set: chains whose ranks sit on binary64 edges (adjacent floats, +-0,
    subnormals, max finite, equal values, null), pairwise differing by one ulp."""
    _guard_seed(seed, getattr(w12_numeric_edges, '_heldout', False))
    rng = random.Random(seed)
    specials = [0.0, -0.0, 5e-324, 2.2250738585072014e-308, 1.0, math.nextafter(1.0, 2.0),
                math.nextafter(1.0, 0.0), 1.7976931348623157e308, None, 0.1, 0.30000000000000004, 0.3]
    cases = []
    for _ in range(count):
        c = base_case(n)
        for e in c['edges']:
            e['score'] = rng.choice(specials)
            if e['score'] is not None and e['score'] < 0:
                e['score'] = 0.0 if rng.random() < 0.5 else -0.0
        cases.append(c)
    return dict(kind='case_set', cls='W12', seed=seed, cases=cases)


def w15_space_skew(seed, n=96, cheap=60, sweeps=3):
    """Owner request stream on a Lemma-P chain: far targets (support ~ t) and many
    cheap near-start targets, cyclic sweeps, then a sudden working-set expansion."""
    _guard_seed(seed, getattr(w15_space_skew, '_heldout', False))
    rng = random.Random(seed)
    case = base_case(n)
    for e in case['edges']:
        e['score'] = float(V3[e['first'] % 3])
    ops = []
    for s in range(sweeps):
        ops += [('query', n - 4 - (s % 3))]
        ops += [('query', rng.randrange(0, 6)) for _ in range(cheap // sweeps)]
    ops += [('query', t) for t in range(n // 2, n - 3)]          # working-set expansion
    return dict(kind='owner_stream', cls='W15', seed=seed, case=case, ops=ops)


def w16_witness_coincidence(seed, n=12, extent=1, repeat=0.5):
    """Witness set with tiny raw extent and repeated coordinates (service-domain
    realisability): adapter ranks are confined to {0..extent}."""
    _guard_seed(seed, getattr(w16_witness_coincidence, '_heldout', False))
    rng = random.Random(seed)
    xs, x = [], rng.randrange(extent + 1)
    for _ in range(n):
        if rng.random() > repeat:
            x = rng.randrange(extent + 1)
        xs.append(x)
    return dict(kind='witness_set', cls='W16', seed=seed, extent=extent, witnesses=[_wit(raw=v) for v in xs])


GENERATORS = {
    'W01': w01_phase_flip_chain, 'W02': w02_sparse_islands, 'W03': w03_long_unqueried_updates,
    'W04': w04_query_mode_switch, 'W05': w05_resident_missing_derivation,
    'W06': w06_complete_analysis_insufficient, 'W07': w07_simultaneous_completion_invalidation,
    'W08': w08_cancel_without_exit, 'W09': w09_high_fanout_bottleneck, 'W10': w10_correlated_churn,
    'W11': w11_overload_fairness, 'W12': w12_numeric_edges, 'W13': w13_identity_aba,
    'W14': w14_failure_families, 'W15': w15_space_skew, 'W16': w16_witness_coincidence,
    'W17': w17_observer_perturbation, 'W18': w18_composite,
}

# held-out size grid: deliberately different from the development defaults above
HELDOUT_SIZES = {
    'W01': dict(n=56, holes=3), 'W02': dict(n=36, island=7), 'W03': dict(n=384, updates=600),
    'W04': dict(n=192), 'W05': dict(n=40, holes=5, evict_every=23), 'W06': dict(n=14),
    'W07': dict(n=12, count=10), 'W08': dict(n=20, optional=7), 'W09': dict(n=32, fanout=9),
    'W10': dict(n=28, interval=2), 'W11': dict(req_gap=2, req_service=3, burst=3),
    'W12': dict(n=10, count=24), 'W13': dict(n=16, cycles=4), 'W14': dict(n=20),
    'W15': dict(n=128, cheap=90), 'W16': dict(n=16, extent=2), 'W17': dict(n=30, dup=2),
    'W18': dict(n=96, horizon=3000),
}


def heldout_suite(seed_base, per_class=4, classes=None):
    """Build the frozen held-out set: seeds seed_base + k (k < per_class), held-out
    size grid.  Intended only for the main session after code/parameter freeze
    (seed_base >= 10**6)."""
    if seed_base < 10 ** 6:
        raise ValueError('held-out seeds must be >= 10**6 (development seeds are 0..999)')
    out = {}
    for cls in (classes or GENERATORS):
        g = GENERATORS[cls]
        g._heldout = True
        try:
            out[cls] = [g(seed_base + k, **HELDOUT_SIZES[cls]) for k in range(per_class)]
        finally:
            g._heldout = False
    return out


# ============================================================ mapping table
MAPPING = [
    # class, generator, mechanisms/experiments stressed, existing R9 evidence
    ('W01', 'w01_phase_flip_chain (+workloads.w01_phase_chain)', 'fixed-radius rules (N06), tree increments, resync worst O(n), first tree build; strong tree vs L0',
     'results/raw/wpB/studies.json#N06_relaxations; results/raw/wpC/O02.json; results/raw/wpT/t05.json (W01 rows)'),
    ('W02', 'w02_sparse_islands (= workloads.w02_islands)', 'interval summaries/independent entry assumption (O05/B01), joint realisability',
     'tests/test_core_strong.py (W02 family); results/raw/wpB/coupled.json'),
    ('W03', 'w03_long_unqueried_updates', 'dirty-log growth/overflow (C02), lazy peak, first-result delay',
     'results/raw/wpC/C02.json'),
    ('W04', 'w04_query_mode_switch', 'hybrid promote/demote chasing (C03/X06/P01), cache pollution',
     'results/raw/wpC/C03.json; results/raw/wpC/X06.json; results/raw/wpC/P01.json'),
    ('W05', 'w05_resident_missing_derivation (= workloads.w05_raw_eviction)', 'derive-first vs evict-first (K01), L1 extra certificates, gate_rank_only',
     'results/raw/wpG/k01_coupled.json; results/raw/wpG/d4_k01_heldout.json; results/raw/wpA/grid_*.jsonl'),
    ('W06', 'w06_complete_analysis_insufficient (= workloads.w06)', 'strong proof must not mis-certify; T05 residual gain',
     'tests/test_core_strong.py; results/raw/wpT/t05.json'),
    ('W07', 'w07_simultaneous_completion_invalidation', 'linearisation, first-legal-wins, double publish, confirm revival (A04/H01/H04)',
     'results/raw/wpA/a04_interleavings.json; results/raw/wpH/commit.json'),
    ('W08', 'w08_cancel_without_exit', 'capacity ledger, reserved slots, duplicate starts (I02/J02)',
     'results/raw/wpH/sched.json (I02); tests/test_wpH.py'),
    ('W09', 'w09_high_fanout_bottleneck', 'sharing vs bounded bypass (I03/X16), first-result delay',
     'results/raw/wpH/sched.json#I03'),
    ('W10', 'w10_correlated_churn', 'debounce, stale completions, progress under unrelated change (J04/X25)',
     'results/raw/wpH/extra.json; results/raw/wpH/combos.json'),
    ('W11', 'w11_overload_fairness', 'required-first starvation, credits (I01/J06/X23)',
     'results/raw/wpH/sched.json; results/raw/wpH/extra.json#J06_sim'),
    ('W12', 'w12_numeric_edges', 'binary64 representatives, JSON contract, domain switch (D02/D03/D06)',
     'results/raw/wpB/domains_brute.json; results/raw/wpB/studies.json'),
    ('W13', 'w13_identity_aba', 'value reuse vs authority (H05/X22/R05/X29), saturation',
     'results/raw/wpH/commit.json#H05; results/raw/wpH/robust.json'),
    ('W14', 'w14_failure_families', 'failure contract, negative caches (K04/X25), blocked vs need_facts',
     'results/raw/wpG/k04_negative.json; results/raw/wpH/combos.json#X25'),
    ('W15', 'w15_space_skew', 'equal-space eviction, size estimators (K02/K03/X26)',
     'results/raw/wpG/k02_k03_retention.json; results/raw/wpG/combo_x26.json'),
    ('W16', 'w16_witness_coincidence', 'extension-domain worlds not physically realisable (E02/E03/X10)',
     'results/raw/wpB/studies.json (E02/E03)'),
    ('W17', 'w17_observer_perturbation', 'counter oracles vs physical events (M06/L06)',
     'results/raw/wpG/m06_counter_oracle.json; results/raw/wpG/l06_instrument.json'),
    ('W18', 'w18_composite (new; no R9 evidence)', 'all lifecycle mechanisms under combined pressure (LC D4 harness, ShadowRunner, coupled_runner)',
     'none in R9 (new in fix round)'),
]
