"""Fix round (main session): lifecycle-complete gated_shadow and its incumbent.

The LC fork found two runner-level defects of the R9 shadow runner (and of the
R9 incumbent runner for the second one):

  D-E4  proof events carry no attempt identity: after a rebind the pre-rebind
        proof event is delivered as if it were the new attempt, and the new
        attempt's own event is then dropped;
  D-E6  a re-intent for a target whose publication has expired is ignored, so
        the request is never re-obtained.

Fixes (this file; adoption spec for the next implementer):

  F1  attempt identity: a proof event is delivered only when its due time
      equals the target's current in-flight attempt (proof_inflight[t] == due);
      any other event for t is dropped and counted.
  F2  re-intent with physical mirroring (keeps Lemma S1): for a re-intent of a
      first-published target t
        physical queue   re-enters t iff the *incumbent-equivalent* L0
                         certificate of t (the L0 certificate issued when the
                         shadow's physical queue certified t, which is the
                         certificate the incumbent published at the same
                         instant) is no longer current -- exactly when the
                         incumbent re-requests;
        publication      if the shadow's current publication of t is not
                         current: publish the incumbent-equivalent L0
                         certificate if it is current (no physical work),
                         otherwise wait for the physical queue / a proof.
      The incumbent runner gets the same re-intent rule (its publication IS
      the L0 certificate), so both runners serve re-intents and the physical
      schedules stay identical (checked on every cell by tests and benches).

Metrics added: stale_proof_events_dropped, reintents, reintents_served
(re-intent republications), republish_latency_u (from the base runner).
"""
import heapq

import paths  # noqa: F401
from wpA_lib import ARunner, ShadowRunner


class _Fix:
    fixed = True

    def _cert_current(self, handle):
        s = self.session
        cert = s._certs.get(handle)
        return cert is not None and s._certificate_current(cert)

    def _currently_published(self, t):
        s = self.session
        h = s._published_handles.get(t)
        return h is not None and self._cert_current(h)

    def _fixed_intent(self, tt, now):
        """F2. Returns True when tt (re-)enters the request queue."""
        self.intent.setdefault(tt, now)
        if tt not in self.first_pub:
            if tt not in self.pending:
                self.pending.append(tt)
            return True
        self.c['reintents'] = self.c.get('reintents', 0) + 1
        return self._reintent(tt, now)

    def _on_proof(self, tt, due):
        """F1. True when the event belongs to the current attempt."""
        if self.proof_inflight.get(tt) == due:
            return True
        if tt in self.proof_inflight:
            self.c['stale_proof_events_dropped'] = self.c.get('stale_proof_events_dropped', 0) + 1
        return False

    def run(self, horizon=10 ** 6, max_steps=200000):
        for ev in self.trace['events']:
            self._push(ev['at'], 'ext', ev)
        steps = 0
        self.livelock = False
        while self.q:
            t, _s, kind, payload = heapq.heappop(self.q)
            steps += 1
            if t > horizon or steps > max_steps:
                self.livelock = True
                break
            self.now = t
            if kind == 'service':
                token, i = payload
                self.scheduled.discard(token)
                if token in self.session._tasks:
                    self.session.finish(token, self.world.complete(i))
                    self.session.consume(token)
                self.drive()
            elif kind == 'proof':
                tt, cls, v, rev = payload
                if self._on_proof(tt, t):
                    self._finish_proof(tt, cls, v=v, rev_at_start=rev)
                self.drive()
            else:
                ev = payload
                if ev['op'] == 'target':
                    self._fixed_intent(ev['target'], t)
                elif ev['op'] == 'targets':
                    for tt in ev['targets']:
                        self._fixed_intent(tt, t)
                elif ev['op'] == 'prefetch':
                    self.session.acquire(ev['item'], required=False)
                elif ev['op'] == 'evict_raw':
                    self.session._raw.clear()
                elif ev['op'] == 'rebind':
                    self._rebind(ev)
                self.drive()
            self._sched()
        return self._result()

    def _result(self):
        s = self.session
        lat = {k: self.first_pub[k] - self.intent[k] for k in self.first_pub}
        return dict(policy=self.policy, acq=self.acq, service_u=self.service_u, q_u=self.q_u,
                    published=len(self.first_pub), intents=len(self.intent), wrong=self.wrong,
                    total_latency_u=sum(lat.values()), max_latency_u=max(lat.values()) if lat else 0,
                    latency_u=lat, unserved=sorted(set(self.intent) - set(self.first_pub)),
                    physical_admissions=s.metrics['physical_admissions'],
                    physical_finishes=s.metrics['physical_finishes'],
                    discarded=s.metrics['discarded_completions'],
                    raw_insertions=s.metrics['raw_insertions'],
                    rank_computations=s.metrics['rank_computations'],
                    strong_attempts=s.metrics['strong_attempts'],
                    strong_certificates=s.metrics['strong_certificates'],
                    strong_evaluations=s.metrics['strong_evaluations'],
                    strong_stops=s.metrics['strong_stops'],
                    strong_ns=s.metrics['strong_ns'], certification_calls=s.metrics['certification_calls'],
                    certification_steps=s.metrics['certification_steps'], end_u=self.now, rebinds=self.rebinds,
                    livelock=self.livelock, current_at_end=sum(1 for k in self.first_pub if self._currently_published(k)),
                    pending_republish=len(self.republish), **self.c)


class FixedIncumbentRunner(_Fix, ARunner):
    """ARunner (policy incumbent) + F1 + F2 (its publication is the L0 certificate)."""

    def __init__(self, trace, **kw):
        kw['policy'] = 'incumbent'
        super().__init__(trace, **kw)

    def _reintent(self, tt, now):
        if self._currently_published(tt):
            return False
        if tt not in self.republish:
            self.republish[tt] = now
        if tt not in self.pending:
            self.pending.append(tt)
        return True

    def _publish(self, target, verdict):
        was_re = target in self.republish
        r = super()._publish(target, verdict)
        if r == 'published' and was_re:
            self.c['reintents_served'] = self.c.get('reintents_served', 0) + 1
        return r


class FixedShadowRunner(_Fix, ShadowRunner):
    """ShadowRunner + F1 + F2 with physical mirroring (Lemma S1 preserved)."""

    def __init__(self, trace, **kw):
        super().__init__(trace, **kw)
        self.l0_cert = {}             # target -> incumbent-equivalent L0 certificate handle

    def residency(self):              # post-freeze addition (release accounting only)
        return (len(self.l0_pending) + len(self.pending) + len(self.proof_inflight) + len(self.republish)
                + len(self.l0_cert) + len(getattr(self, '_last_l0', {})))

    def close(self):                  # post-freeze addition: the mirror must not outlive the session
        self.l0_cert.clear()
        getattr(self, '_last_l0', {}).clear()

    def drive(self):
        # record the incumbent-equivalent L0 certificate whenever the physical queue certifies
        before = list(self.l0_pending)
        super().drive()
        # ShadowRunner.drive removes a target from l0_pending exactly when L0 certified it; the
        # certificate it used is the most recent L0 certificate for that target in the session
        for t in before:
            if t not in self.l0_pending:
                h = self._last_l0.get(t)
                if h is not None:
                    self.l0_cert[t] = h

    def _reintent(self, tt, now):
        mirror_expired = not (tt in self.l0_cert and self._cert_current(self.l0_cert[tt]))
        entered = False
        if mirror_expired:                         # the incumbent re-requests exactly now
            if tt not in self.l0_pending:
                self.l0_pending.append(tt)
            entered = True
        if not self._currently_published(tt):
            h = self.l0_cert.get(tt)
            if h is not None and self._cert_current(h) and self.session.publish(tt, h) == 'published':
                self.c['reintents_served'] = self.c.get('reintents_served', 0) + 1
                self.c['reintent_l0_republish'] = self.c.get('reintent_l0_republish', 0) + 1
            else:
                if tt not in self.republish:
                    self.republish[tt] = now
                if tt not in self.pending:
                    self.pending.append(tt)
                entered = True
        return entered

    def _publish_proof(self, target, verdict):
        was_re = target in self.republish
        r = super()._publish_proof(target, verdict)
        if r == 'published' and was_re:
            self.c['reintents_served'] = self.c.get('reintents_served', 0) + 1
        return r


def _track_l0(cls):
    """Wrap session.certify so the runner knows the latest L0 certificate per target."""
    orig_init = cls.__init__

    def __init__(self, trace, **kw):
        orig_init(self, trace, **kw)
        self._last_l0 = {}
        s = self.session
        orig = s.certify

        def certify(target, *, mode='L0', budget=None):
            v = orig(target, mode=mode, budget=budget)
            if mode == 'L0' and v.get('status') == 'certified' and 'certificate' in v:
                self._last_l0[target] = v['certificate']
            return v
        s.certify = certify
    cls.__init__ = __init__
    return cls


FixedShadowRunner = _track_l0(FixedShadowRunner)


def make_fixed_runner(trace, policy, **kw):
    if policy == 'incumbent':
        return FixedIncumbentRunner(trace, **kw)
    if policy in ('shadow', 'gated_shadow'):
        return FixedShadowRunner(trace, policy=policy, **kw)
    raise ValueError(policy)


# ---------------------------------------------------------------- lifecycle-script variant (LC harness)
def life_fixed_runner_class():
    """LC's LifeShadowRunner (harness events, close protocol) with F1 (its due check, fixed=True)
    and the main-session F2 (physical mirroring) instead of LC's re-intent rule."""
    from fixLC_shadow import LifeShadowRunner

    class LifeFixedShadowRunner(LifeShadowRunner):
        _cert_current = _Fix._cert_current
        _currently_published = _Fix._currently_published
        _reintent = FixedShadowRunner._reintent

        def __init__(self, trace, **kw):
            kw['fixed'] = True
            super().__init__(trace, **kw)
            self.l0_cert = {}

        def _fixed_intent_hook(self, tt, now):
            return _Fix._fixed_intent(self, tt, now)

        def residency(self):          # post-freeze: count the L0-certificate mirror too
            return super().residency() + len(self.l0_cert) + len(getattr(self, '_last_l0', {}))

        def _close(self):             # post-freeze: release the mirror as part of the close protocol
            self.l0_cert.clear()
            getattr(self, '_last_l0', {}).clear()
            return super()._close()

        def drive(self):
            before = list(self.l0_pending)
            super().drive()
            for t in before:
                if t not in self.l0_pending and self._last_l0.get(t) is not None:
                    self.l0_cert[t] = self._last_l0[t]

    return _track_l0(LifeFixedShadowRunner)
