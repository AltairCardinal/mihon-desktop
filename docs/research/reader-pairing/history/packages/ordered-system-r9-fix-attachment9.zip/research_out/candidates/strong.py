"""Strong (L1) certification wired into the coupled Session.

The L0 verdict of the corrected owner is always computed first and is never
rewritten when it is `certified` or `blocked`.  Only a `need_facts` verdict may
be upgraded by a strong attempt over the *admitted* evidence (never World):

  kind   'tree'      independent-leaf relation tree (round-8 reproduction of the
                     frontier route one, 10-state encoding)
         'exact'     shared-assignment frontier DP from the true initial state
         'portfolio' tree, then exact only if the tree is not a singleton
  domain 'ext' | 'nonneg' | 'G0'   (rank completions; a known score outside the
                     declared domain silently widens to 'ext', reference: FORMAL §2)
  alpha  header authority (producer contract) or not (beta)
  gate   'sound'  - accept any complete singleton proof
         'raw'    - additionally every item in the support scope has an accepted
                     computed analysis (ALGORITHM_FRONTIER 'supported' gate)
  budget maximum step evaluations of the call (contract BC-2, candidates/budget.py):
         exceeding it stops the call, rolls back shared structures and issues
         nothing (work stays charged).  Same rule for every strong route.

Support of a strong certificate: typed owner reads of analysis/header/dimension
for every position in [0, min(n-1, t+3)] and rank of every edge in that range.
Lemma (proofs/R9_PROOFS.md, S-1): every leaf the attempt composes reads only
facts in that range, so equality of these reads implies the same proof.
"""
import time
from copy import deepcopy

import paths  # noqa: F401
import compact_core as core
import transducer as T
import omega as O
from coupling import Session
from current_baseline import typed


from budget import Meter, BudgetExceeded, effective_limit

Budget = BudgetExceeded            # R9 name kept for importers


def _attempt(case, target, kind, domain, alpha, limit):
    """Core of the fresh route; runs inside an active Meter. Returns (status, unit, route, domain)."""
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    if kind in ('tree', 'portfolio'):
        tree = T.RelTree(F)
        units = tree.units(target)
        if len(units) == 1:
            return 'certified', next(iter(units.values())), 'tree', F.domain
        if kind == 'tree':
            return 'ambiguous', None, 'tree', F.domain
    st, u = O.certify_exact(case, target, F.domain, alpha, limit=(limit if limit is not None else 400000))
    if st == 'limit':
        raise BudgetExceeded()
    return ('certified', u, 'exact', F.domain) if st == 'certified' else ('ambiguous', None, 'exact', F.domain)


def strong_attempt(case, target, kind='tree', domain='nonneg', alpha=False, budget=None):
    """Returns dict(status in certified|ambiguous|stopped, unit, evaluations, ns, route, domain)."""
    t0 = time.perf_counter_ns()
    meter = Meter(budget)
    try:
        with meter:
            st, unit, route, dom = _attempt(case, target, kind, domain, alpha, budget)
    except BudgetExceeded:
        return dict(status='stopped', unit=None, evaluations=meter.n, ns=time.perf_counter_ns() - t0,
                    route=kind, domain=domain)
    return dict(status=st, unit=unit, evaluations=meter.n, ns=time.perf_counter_ns() - t0, route=route, domain=dom)


def support_keys(n, target):
    hi = min(n - 1, target + 3)
    keys = []
    for p in range(0, hi + 1):
        keys += [('analysis', p), ('header', p), ('dimension', p)]
    for a in range(0, min(n - 2, hi) + 1):
        keys.append(('rank', a, a + 1))
    return keys


class StrongSession(Session):
    """Session with an additional certification mode 'S' (strong L1).

    All strong routes (this fresh route and the subclasses' shared-structure
    routes) go through `_strong_call`, which applies budget contract BC-2
    (candidates/budget.py): same unit, same charging, same stop, rollback of
    stopped calls, certificate only from a completed within-budget call.
    """

    def __init__(self, case, *, strong=None, **kw):
        super().__init__(case, **kw)
        self.strong = dict(kind='tree', domain='nonneg', alpha=False, gate='raw', budget=None)
        self.strong.update(strong or {})
        self.strong_log = []

    # ---- hooks for shared-structure subclasses
    def _strong_compute(self, target, limit):
        """Return (status, unit, route). Runs inside an active Meter. Fresh route."""
        cfg = self.strong
        st, unit, route, _dom = _attempt(self.owner._case, target, cfg['kind'], cfg['domain'], cfg['alpha'], limit)
        return st, unit, route

    def _txn_begin(self):
        """Snapshot what a stopped call must restore (fresh route: nothing)."""
        return None

    def _txn_rollback(self, snap):
        pass

    def _txn_commit(self, snap):
        pass

    # ---- shared driver
    def _base_l0(self, target, budget):
        before = self.metrics['certification_steps']
        base = Session.certify(self, target, mode='L0', budget=budget)
        return base, self.metrics['certification_steps'] - before

    def _strong_call(self, target, base, l0_steps, call_budget, route_prefix='strong-'):
        cfg = self.strong
        limit = effective_limit(cfg['budget'], call_budget, l0_steps)
        meter = self._meter = Meter(limit)
        t0 = time.perf_counter_ns()
        snap = self._txn_begin()
        try:
            with meter:
                st, unit, route = self._strong_compute(target, limit)
            self._txn_commit(snap)
        except BudgetExceeded:
            self._txn_rollback(snap)
            st, unit, route = 'stopped', None, getattr(self, '_route_name', cfg['kind'])
        ns = time.perf_counter_ns() - t0
        n = len(self.owner._case['items'])
        keys = support_keys(n, target)
        index = self.owner._index()
        gated = st == 'certified' and bool(unit) and unit['certain']
        if gated and cfg['gate'] == 'raw':
            gated = all(index.analysis(p)[0] == 'computed' for p in range(0, min(n - 1, target + 3) + 1))
        self.metrics['strong_attempts'] += 1
        self.metrics['strong_evaluations'] += meter.n
        self.metrics['strong_ns'] += ns
        self.metrics['strong_support_keys'] += len(keys)
        self.strong_log.append(dict(target=target, status=st, gated=gated, evaluations=meter.n, ns=ns, route=route,
                                    limit=limit))
        if st == 'stopped':
            self.metrics['strong_stops'] += 1
        if st == 'contradiction':
            self.metrics['strong_contradictions'] += 1
        if not gated:
            return base
        support = {k: self.owner._read(index, k) for k in keys}
        self.metrics['strong_certificates'] += 1
        self._next_certificate += 1
        handle = self._next_certificate
        self._certs[handle] = dict(target=target, unit=deepcopy(unit), guard=self.owner._guard(), epoch=self.epoch,
                                  support=support)
        return dict(status='certified', unit=deepcopy(unit), needs=[], failures={}, first=0,
                    steps=meter.n, dependent_items=list(range(0, min(n - 1, target + 3) + 1)),
                    certificate=handle, route=route_prefix + route)

    def certify(self, target, *, mode='L0', budget=None):
        if mode != 'S':
            return super().certify(target, mode=mode, budget=budget)
        base, l0_steps = self._base_l0(target, budget)
        if base['status'] != 'need_facts':
            return base
        return self._strong_call(target, base, l0_steps, budget)

    def close(self):
        """Release candidate-held structures (package Session has no close; see lifecycle.py)."""
        self.strong_log = []
