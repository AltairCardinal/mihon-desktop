"""Fix round, item 3: mechanism registry + event groups E1-E6 + liveness + mutants (tag LC).

Every group builds a fresh `Life` (candidates/fixLC_lifecycle.py) on the same
fixture: W01 phase chain seed 0 (n=32; rank holes at 13 and 28), target 12.
For strong-route mechanisms the target is certifiable by the strong route at
the initial state while L0 needs facts; for L0 mechanisms the controller first
acquires the needs.  `support-touching` change = re-delivery of an equal fact
with a new version label on item 12 (or edge 11); `untouched` change = the
world-true rank of edge 28 (outside every certificate support for target 12).
"""
import gc
import json
import time
import tracemalloc
from copy import deepcopy

import paths  # noqa: F401
import workloads as W
from coupling import Session, Witness
from strong import StrongSession
from wpA_lib import PersistentStrongSession
from wpB_coupled import BlockSession
from wpC_coupled import IndexedSession
from wpG_session import GSession
from wpG_owner import GOwner
from wpH_commit import IncSession, BoundConfirmSession, ValueCacheSession
from wpH_combos import MigratingSession
from wpH_runner import ReservingSession
from fixLC_lifecycle import Life, naive_close_crash, reachable_size
from current_baseline import typed

T0, NEAR, FAR = 12, 13, 28
STRONG = dict(domain='nonneg', alpha=False, gate='raw')


def fixture():
    return W.w01_phase_chain(0)


MECHANISMS = {
    # name: spec (cls, kw, mode, native_bound)
    'package_session': dict(cls=Session, mode='L0'),
    'fresh_strong': dict(cls=StrongSession, kw=dict(strong=dict(STRONG, kind='tree')), mode='S'),
    'persistent_tree': dict(cls=PersistentStrongSession, kw=dict(strong=dict(STRONG, kind='tree')), mode='S'),
    'block_session': dict(cls=BlockSession, kw=dict(strong=dict(STRONG, kind='blocks')), mode='S'),
    'gated_index_I': dict(cls=IndexedSession, kw=dict(strong=dict(STRONG, kind='tree')), mode='I'),
    'gated_index_SEL': dict(cls=IndexedSession, kw=dict(strong=dict(STRONG, kind='tree')), mode='SEL'),
    'derive_first': dict(cls=GSession, kw=dict(order='derive_first'), mode='L0'),
    'proj_support': dict(cls=GSession, kw=dict(owner_factory=lambda c: GOwner(c, support='proj')), mode='L0'),
    'reissue_eager': dict(cls=GSession, kw=dict(reissue=True, owner_factory=lambda c: GOwner(c, support='proj')),
                          mode='L0'),
    'reissue_lazy': dict(cls=GSession, kw=dict(reissue='lazy', owner_factory=lambda c: GOwner(c, support='proj')),
                         mode='L0'),
    'migrate_resign': dict(cls=MigratingSession, mode='L0'),
    'inc_revoke': dict(cls=IncSession, mode='L0'),
    'bound_confirm': dict(cls=BoundConfirmSession, mode='L0', bound=True, native_bound=True),
    'value_cache': dict(cls=ValueCacheSession, mode='L0'),
    'reserve1': dict(cls=ReservingSession, mode='L0'),
}


def spec(name, bound=None):
    s = dict(MECHANISMS[name], name=name)
    if bound is not None and not s.get('native_bound'):
        s['bound'] = bound
    return s


MECH_COUNTERS = ('value_cache_hits', 'migrated_certificates', 'reissued_publications', 'revoked_publications',
                 'incremental_suspects', 'strong_certificates', 'strong_stops', 'index_answers', 'index_gate_misses',
                 'reservation_refusals', 'persistent_rebuilds', 'persistent_leaf_updates', 'block_rebuilds',
                 'block_updates', 'rank_computations', 'raw_evictions', 'raw_dead_evictions', 'certs_collected',
                 'publication_read_checks', 'discarded_completions')


class G:
    """Collects named checks for one group run."""

    def __init__(self, group, mech, bound):
        self.group, self.mech, self.bound = group, mech, bound
        self.checks = []
        self.extra = {}

    def check(self, name, ok, detail=None):
        self.checks.append(dict(name=name, ok=bool(ok), detail=detail))
        return ok

    def result(self, life=None):
        out = dict(group=self.group, mechanism=self.mech, bound=self.bound, ok=all(c['ok'] for c in self.checks),
                   failed=[c['name'] for c in self.checks if not c['ok']], checks=self.checks, **self.extra)
        if life is not None:
            out['mechanism_counters'] = {k: life.s.metrics[k] for k in MECH_COUNTERS if life.s.metrics.get(k)}
            out['routes'] = sorted({str(r['ret'].get('route')) for r in life.rows
                                    if r['op'] == 'certify' and isinstance(r['ret'], dict) and r['ret'].get('status') == 'certified'})
            out['final'] = dict(occupied=life.s.occupied, raw=life.s.raw_size, certs=life.s.certificate_count,
                                residency=life.residency())
            out['events'] = len(life.rows)
        return out


def _obtain(life, t, limit=200):
    """Like Life.drive but stops at the first certified verdict (does not publish)."""
    for _ in range(limit):
        v = life.certify(t)
        if v['status'] == 'certified':
            return v
        items = []
        for nd in v.get('needs', []):
            items.append(nd['item'])
            if 'second' in nd:
                items.append(nd['second'])
        items += [int(k) for k in (v.get('failures') or {})]
        for i in items:
            if not any(task['item'] == i and not task['cancelled'] for task in life.s._tasks.values()):
                life.acquire(i)
        if not life.advance():
            return v
    return None


def _drain(life):
    while life.due:
        life.advance()


# --------------------------------------------------------------------------- groups

def E1(sp, sink=None):
    life = Life(sp, fixture())
    g = G('E1_publish_confirm', sp['name'], life.bound)
    ok, v = life.drive(T0)
    g.check('first_legal_publication', ok, v and v.get('route'))
    g.check('unit_truthful', ok and typed(v['unit']) == typed(life.truth[T0]))
    r = life.confirm(T0)
    g.check('confirm_current', r == 'confirmed', r)
    g.check('confirmed_view', T0 in life.s.confirmed)
    g.extra['route'] = v and v.get('route')
    _drain(life)
    g.check('no_task_left_after_drain', life.s.occupied == 0, life.s.occupied)
    sink and life.dump(sink)
    return g.result(life)


def E2(sp, sink=None):
    out = []
    for touched in (True, False):
        life = Life(sp, fixture())
        g = G('E2_change_during_proof_' + ('touched' if touched else 'untouched'), sp['name'], life.bound)
        v = _obtain(life, T0)
        g.check('obtained_certificate', v is not None and v['status'] == 'certified', v and v.get('status'))
        if not (v and v['status'] == 'certified'):
            out.append(g.result(life)); continue
        g.extra['route'] = v.get('route')
        if touched:
            life.admit(version_bump=T0)
            r = life.publish(T0, v['certificate'])
            g.check('stale_result_rejected', r != 'published', r)
        else:
            life.admit(edge=FAR)
            r = life.publish(T0, v['certificate'])
            g.check('untouched_result_accepted', r == 'published', r)
            g.check('accepted_unit_truthful', r != 'published' or typed(v['unit']) == typed(life.truth[T0]))
        ok, v2 = life.drive(T0)
        g.check('request_completes', ok and T0 in life.s.published, v2 and v2.get('route'))
        g.check('completed_unit_truthful', ok and typed(life.s.published[T0]) == typed(life.truth[T0]))
        _drain(life)
        sink and life.dump(sink)
        out.append(g.result(life))
    return out


def E3(sp, sink=None, mutant_cls=None):
    sp2 = dict(sp, cls=mutant_cls) if mutant_cls else sp
    life = Life(sp2, fixture())
    g = G('E3_cancel', sp['name'] + ('/' + mutant_cls.__name__ if mutant_cls else ''), life.bound)
    s = life.s
    item = NEAR + 1                                  # an endpoint of the near rank hole
    tk = life.acquire(item)
    rev0, raw0, edges0 = s.owner._revision, dict(s._raw), typed(s.owner._edges)
    r = life.cancel(tk)
    g.check('cancel_returns_cancelling', r == 'cancelling', r)
    g.check('slot_still_held_after_cancel', s.occupied == 1, s.occupied)
    life.advance(life.now + 1)                       # fillers exit one unit later than the cancelled task
    fillers = []
    for i in (0, 1, 2, 3, 4):
        x = life.acquire(i)
        if x is None:
            break
        fillers.append(x)
    g.check('cancelled_task_counts_against_capacity', len(fillers) == s.capacity - 1, len(fillers))
    if sp['name'] == 'reserve1':
        g.check('optional_refused_at_reserve', s.acquire(9, required=False) is None)
    due = life.due.get(tk)
    life.advance(due)
    fin = [rw for rw in life.rows if rw['op'] == 'finish' and rw['args']['issuance'] == tk.issuance]
    g.check('cancelled_exit_discarded', bool(fin) and fin[-1]['ret'] == 'discarded', fin and fin[-1]['ret'])
    g.check('cancelled_result_not_admitted', s.owner._revision == rev0 and typed(s.owner._edges) == edges0
            and set(s._raw) == set(raw0), dict(rev=s.owner._revision, rev0=rev0))
    g.check('slot_released_at_exit', tk not in s._tasks and s.occupied == len(fillers), s.occupied)
    g.check('late_finish_absent', s.finish(tk, Witness(**life.world_w[item])) == 'absent')
    _drain(life)
    ok, v = life.drive(T0)
    g.check('request_completes_after_cancel', ok, v and v.get('route'))
    _drain(life)
    sink and life.dump(sink)
    return g.result(life)


def _rebind_content_case(life):
    case = deepcopy(life.s.observe())
    it = case['items'][NEAR]
    it['content_version'] = it.get('content_version', 0) + 1
    it['analysis'] = {'status': 'unknown'}
    case['edges'] = [e for e in case['edges'] if NEAR not in (e['first'], e['second'])]
    return case


def _rebind_known_case(life):
    """Content replacement of item NEAR with a different (WIDE) witness whose analysis is admitted
    with the rebind; adjacent ranks unknown.  The hidden world changes accordingly."""
    from common import fact
    from coupling import World
    new = deepcopy(life.world_w[NEAR])
    new['analysis']['fact'] = fact('WIDE', 'UNKNOWN')
    life.world_w[NEAR] = new
    life.world = World([Witness(**w) for w in life.world_w])
    life.initial['items'][NEAR]['header'] = deepcopy(new['analysis']['fact'])
    life.initial['items'][NEAR]['content_version'] = life.initial['items'][NEAR].get('content_version', 0) + 1
    from coupled_runner import truth_units
    life.truth = truth_units(life.initial, life.world_w)
    case = deepcopy(life.s.observe())
    it = case['items'][NEAR]
    it['content_version'] = it.get('content_version', 0) + 1
    it['header'] = deepcopy(new['analysis']['fact'])
    it['analysis'] = deepcopy(new['analysis'])
    case['edges'] = [e for e in case['edges'] if NEAR not in (e['first'], e['second'])]
    return case


def E4(sp, sink=None, content_change=False, mutant_cls=None):
    sp2 = dict(sp, cls=mutant_cls) if mutant_cls else sp
    life = Life(sp2, fixture())
    g = G('E4_rebind' + ({True: '_content', 'known': '_content_known'}.get(content_change, '_same')),
          sp['name'] + ('/' + mutant_cls.__name__ if mutant_cls else ''), life.bound)
    s = life.s
    ok, v = life.drive(T0)
    g.check('pre_rebind_published', ok)
    h_old = v['certificate'] if ok else None
    life.confirm(T0)
    _drain(life)
    tk_old = life.acquire(20)
    if content_change == 'known':
        rev_case = _rebind_known_case(life)
    elif content_change:                             # hidden world: same values, new content label
        rev_case = _rebind_content_case(life)
    else:
        rev_case = None
    life.rebind(rev_case)
    g.check('old_certificate_unusable', h_old is None or life.publish(T0, h_old) != 'published')
    pre = life.confirm(T0, handle=h_old)
    g.check('old_callback_rejected_before_republish', pre != 'confirmed', pre)
    first_new = life.certify(T0)
    fresh = sp['cls'](deepcopy(s.observe()), **sp.get('kw', {}))
    fv = fresh.certify(T0, mode=sp.get('mode', 'L0'))
    same_as_fresh = (first_new['status'] == fv['status'] and typed(first_new.get('unit')) == typed(fv.get('unit')))
    g.check('post_rebind_result_equals_fresh_session', same_as_fresh,
            dict(mech=first_new['status'], fresh=fv['status'], route=first_new.get('route')))
    if tk_old is not None:
        life.advance(life.due.get(tk_old, life.now))
        fin = [rw for rw in life.rows if rw['op'] == 'finish' and rw['args']['issuance'] == tk_old.issuance]
        g.check('old_epoch_late_finish_rejected', bool(fin) and fin[-1]['ret'] == 'discarded', fin and fin[-1]['ret'])
        g.check('old_task_slot_released', tk_old not in s._tasks)
        g.check('repeat_old_finish_absent', s.finish(tk_old, Witness(**life.world_w[20])) == 'absent')
    ok2, v2 = life.drive(T0)
    g.check('reissued_request_completes', ok2, v2 and v2.get('route'))
    g.check('reissued_unit_truthful', ok2 and typed(v2['unit']) == typed(life.truth[T0]))
    g.extra['reissue_route'] = v2 and v2.get('route')
    late = life.confirm(T0, handle=h_old)
    g.check('old_callback_rejected_after_republish', late != 'confirmed', late)
    cur = life.confirm(T0)
    g.check('current_callback_confirms', cur == 'confirmed', cur)
    _drain(life)
    sink and life.dump(sink)
    return g.result(life)


_PKG_REACH = {}


def _package_reachable_after_close():
    if 'v' not in _PKG_REACH:
        life = Life(spec('package_session'), fixture())
        life.drive(T0); life.confirm(T0)
        for t in (20, 24):
            life.drive(t)
        life.close()
        _PKG_REACH['v'] = reachable_size(life.s)
    return _PKG_REACH['v']


def E5(sp, sink=None):
    gc.collect()
    tracemalloc.start()
    base = tracemalloc.get_traced_memory()[0]
    life = Life(sp, fixture())
    g = G('E5_close', sp['name'], life.bound)
    s = life.s
    ok, v = life.drive(T0)
    life.confirm(T0)
    h = v['certificate'] if ok else None
    for t in (20, 24):
        life.drive(t)
    running = [life.acquire(i) for i in (5, 6)]
    done = life.acquire(7)
    if done is not None:                              # completed but not consumed at close time
        s.finish(done, Witness(**life.world_w[7])); life.due.pop(done, None)
    gc.collect()
    cur_run, peak_run = tracemalloc.get_traced_memory()
    res_before = life.residency()
    life.close()
    gc.collect()
    cur_close = tracemalloc.get_traced_memory()[0]
    tracemalloc.stop()
    g.check('occupied_zero', s.occupied == 0, s.occupied)
    g.check('raw_zero', s.raw_size == 0)
    g.check('certificates_zero', s.certificate_count == 0)
    g.check('publications_zero', not s._published and not s._confirmed and not s._published_handles)
    res = life.residency()
    g.check('candidate_residency_zero', res in (0, None), res)
    late = [tk for tk in running if tk is not None]
    g.check('late_finish_after_close_rejected', all(s.finish(tk, Witness(**life.world_w[0])) == 'absent' for tk in late))
    c = s.confirm(T0, h) if life.bound else s.confirm(T0)
    g.check('late_confirm_after_close_rejected', c != 'confirmed', c)
    g.check('publish_after_close_rejected', h is None or s.publish(T0, h) != 'published')
    try:
        s.certify(T0, mode=sp.get('mode', 'L0'))
        g.check('certify_after_close_rejected', False, 'accepted')
    except Exception as e:  # noqa: BLE001
        g.check('certify_after_close_rejected', True, type(e).__name__)
    life.rows_saved = len(life.rows)
    reach, nobj = reachable_size(s)
    ref = _package_reachable_after_close()
    g.check('no_hidden_residual_reachable', reach <= ref[0] * 1.10 + 4096,
            dict(reachable_bytes=reach, objects=nobj, package_session_reference=ref))
    g.extra['memory'] = dict(layer='local_measured tracemalloc (bytes, Python 3.13)', baseline=base,
                             reachable_after_close_bytes=reach, reachable_after_close_objects=nobj,
                             current_running=cur_run - base, peak_running=peak_run - base,
                             retained_after_close=cur_close - base, residency_before_close=res_before,
                             residency_after_close=res)
    sink and life.dump(sink)
    return g.result(life)


def E6(sp, sink=None, mutant_cls=None, edge=False, via=None):
    sp2 = dict(sp, cls=mutant_cls) if mutant_cls else sp
    life = Life(sp2, fixture())
    g = G('E6_invalidation' + ('_consume' if via == 'consume' else '_edge' if edge else '_item'),
          sp['name'] + ('/' + mutant_cls.__name__ if mutant_cls else ''), life.bound)
    s = life.s
    ok, v = life.drive(T0)
    g.check('published', ok)
    life.confirm(T0)
    h1 = v['certificate'] if ok else None
    sup = s._certs[h1]['support'] if ok else {}
    if via == 'consume':                  # service re-delivers item T0 with a new version label
        from coupling import World
        life.world_w[T0]['analysis']['version'] = life.world_w[T0]['analysis'].get('version', 0) + 100
        life.world = World([Witness(**w) for w in life.world_w])
        tk = life.acquire(T0)
        if tk is not None and tk in life.due:
            life.advance(life.due[tk])
        g.extra['changed'] = ('consume', T0)
    elif edge:
        keys = sorted(k[1] for k in sup if k[0] == 'rank' and s.owner._edges.get((k[1], k[2])) is not None)
        a = keys[-1] if keys else 11
        life.admit(edge_version_bump=a)
        g.extra['changed'] = ('edge', a)
    else:
        life.admit(version_bump=T0)
    pub = s.published
    handle_now = s._published_handles.get(T0)
    g.check('old_certificate_rejected', h1 is None or s.publish(T0, h1) != 'published')
    g.check('stale_publication_not_visible_under_old_handle', T0 not in pub or handle_now != h1,
            dict(visible=T0 in pub, same_handle=handle_now == h1))
    g.check('confirmation_not_carried', T0 not in s.confirmed)
    ok2, v2 = life.drive(T0)
    g.check('legal_result_reobtained', ok2 and T0 in s.published, v2 and v2.get('route'))
    g.check('reobtained_unit_truthful', ok2 and typed(s.published[T0]) == typed(life.truth[T0]))
    c = life.confirm(T0)
    g.check('reobtained_confirmable', c == 'confirmed', c)
    _drain(life)
    sink and life.dump(sink)
    return g.result(life)


LV_TRACES = (('W01_s0', lambda: W.w01_phase_chain(0)), ('W05_s2', lambda: W.w05_raw_eviction(2)),
             ('RP_s0', lambda: W.random_partial(0)))


def LV(sp, sink=None, raw_capacity=3, n_targets=None):
    rows = []
    for name, mk in LV_TRACES:
        tr = mk()
        life = Life(sp, tr, raw_capacity=raw_capacity)
        targets = []
        for ev in tr['events']:
            if ev['op'] == 'target' and ev['target'] not in targets:
                targets.append(ev['target'])
        targets = targets[:n_targets] if n_targets else targets
        pub = conf = truthful = 0
        for t in targets:
            ok, v = life.drive(t, limit=300, confirm=True)
            pub += ok
            truthful += bool(ok and typed(v['unit']) == typed(life.truth[t]))
            conf += t in life.s._confirmed
        _drain(life)
        rows.append(dict(trace=name, targets=len(targets), published=pub, truthful=truthful, confirmed_now=conf,
                         admissions=life.s.metrics['physical_admissions'], events=len(life.rows)))
        sink and life.dump(sink)
    g = G('LV_liveness' + ('_rc%d' % raw_capacity if raw_capacity != 3 else ''), sp['name'], sp.get('bound', False))
    for r in rows:
        g.check('all_published_%s' % r['trace'], r['published'] == r['targets'], r)
        g.check('all_truthful_%s' % r['trace'], r['truthful'] == r['published'])
    g.extra['traces'] = rows
    return g.result()


GROUPS = (E1, E2, E3, E4, E5, E6)


def run_mechanism(name, bound=False, sink=None):
    sp = spec(name, bound)
    out = []
    for fn in GROUPS:
        r = fn(sp, sink)
        out += r if isinstance(r, list) else [r]
    out.append(E4(sp, sink, content_change=True))
    out.append(E4(sp, sink, content_change='known'))
    out.append(E6(sp, sink, edge=True))
    out.append(E6(sp, sink, via='consume'))
    out.append(E4_differential(sp))
    out.append(LV(sp, sink))
    if name in ('package_session', 'derive_first'):
        out.append(LV(sp, sink, raw_capacity=1))
    return out


# --------------------------------------------------------------------------- mutants (harness teeth)

class MutCancelFreesSlot(Session):
    def cancel(self, token):
        task = self._tasks.get(token)
        if task is not None and task['phase'] == 'running':
            del self._tasks[token]               # frees the slot early (forbidden)
            return 'cancelling'
        return super().cancel(token)


class MutIncSkipsRank(IncSession):
    def _expire_publications(self):
        self._dirty = {k for k in self._dirty if k[0] != 'rank'}   # revocation skips dirty rank keys
        super()._expire_publications()


class MutPersistentNoInval(PersistentStrongSession):
    def rebind(self, case, **kw):
        tree, key = self._tree, self._tree_key
        StrongSession.rebind(self, case, **kw)
        self._tree, self._tree_key = tree, key   # keeps the old tree

    def _sync(self):
        if self._tree is not None:
            self._dirty_items.clear(); self._dirty_edges.clear()
            return                               # never invalidated
        return super()._sync()


class MutReissueKeepsConfirm(GSession):
    def _reissue_stale(self):
        saved = dict(self._confirmed)
        super()._reissue_stale()
        for k, v in saved.items():
            if k in self._published:
                self._confirmed[k] = v           # carries confirmation (forbidden)


def mutants(sink=None):
    rows = []
    rows.append(dict(mutant='cancel_frees_slot', **E3(spec('package_session'), sink, mutant_cls=MutCancelFreesSlot)))
    rows.append(dict(mutant='unbound_confirm(package)', **E4(spec('package_session', bound=False), sink)))
    rows.append(dict(mutant='inc_revoke_skips_rank_key',
                     **E6(spec('inc_revoke'), sink, mutant_cls=MutIncSkipsRank, edge=True)))
    rows.append(dict(mutant='persistent_tree_not_invalidated',
                     **E4_differential(spec('persistent_tree'), mutant_cls=MutPersistentNoInval)))
    sp = spec('reissue_eager', bound=True)
    rows.append(dict(mutant='reissue_carries_confirmation',
                     **E6(sp, sink, mutant_cls=MutReissueKeepsConfirm, via='consume')))
    return rows


# --------------------------------------------------------------------------- randomized rebind/update differential

def E4_differential(sp, seeds=range(6), steps=40, mutant_cls=None):
    """Random rebinds (content replacement of one item with a new rank value, or an analysis
    reset), harness admissions and certify calls; after every step the mechanism's verdict
    (status, unit) must equal a FRESH instance of the same class built on the current
    admitted evidence (no carried structure).  Catches stale persistent structures."""
    import random
    cls = mutant_cls or sp['cls']
    g = G('E4_rebind_differential', sp['name'] + ('/' + mutant_cls.__name__ if mutant_cls else ''), sp.get('bound', False))
    mism, calls = [], 0
    for seed in seeds:
        rng = random.Random(seed)
        tr = [W.w01_phase_chain, W.w05_raw_eviction, W.random_partial][seed % 3](seed)
        s = cls(deepcopy(tr['initial']), **sp.get('kw', {}))
        n = len(tr['initial']['items'])
        for k in range(steps):
            op = rng.random()
            case = s.observe()
            if op < 0.25:                               # rebind: item content replaced, new rank values around it
                i = rng.randrange(1, n - 1)
                case['items'][i]['content_version'] = case['items'][i].get('content_version', 0) + 1
                for e in case['edges']:
                    if i in (e['first'], e['second']) and e.get('status') == 'computed':
                        e['score'] = rng.choice((None, 0, 1, 3, 7, 50))
                s.rebind(case)
            elif op < 0.45:                             # rank refinement / change under the same binding
                a = rng.randrange(0, n - 1)
                s.owner.apply(edge_updates={(a, a + 1): dict(status='computed', score=rng.choice((None, 0, 2, 9, 40)),
                                                             version=k)})
            elif op < 0.55:
                a = rng.randrange(0, n - 1)
                s.owner.apply(edge_updates={(a, a + 1): None})
            t = rng.randrange(n)
            v = s.certify(t, mode=sp.get('mode', 'L0'))
            f = sp['cls'](deepcopy(s.observe()), **sp.get('kw', {})).certify(t, mode=sp.get('mode', 'L0'))
            calls += 1
            if v['status'] != f['status'] or typed(v.get('unit')) != typed(f.get('unit')):
                mism.append(dict(seed=seed, step=k, target=t, mech=(v['status'], v.get('route')), fresh=(f['status'], f.get('route'))))
    g.check('verdicts_equal_fresh_instance', not mism, mism[:3])
    g.extra.update(calls=calls, mismatches=len(mism))
    return g.result()
