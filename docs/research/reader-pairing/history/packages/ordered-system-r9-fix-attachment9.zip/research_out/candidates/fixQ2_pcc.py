"""T04 hand-off package: issuer of proof-carrying frontier certificates (route 2),
the route-1 wrapper (re-derivation checker of R9, wpT_checker), and the
certificate mutants used to test both checkers.

The issuer may use the DP machinery (it is not trusted); only
fixQ2_pcc_checker.check is the trusted verifier of route 2.
"""
import copy
import json

import paths  # noqa: F401
import transducer as T
import omega as O
import wpT_checker as R1
from budget import Meter


def default_support(n, target):
    return min(n - 1, target + 3), min(n - 2, target + 2)


def _ser_key(k):
    return [_ser_key(x) for x in k] if isinstance(k, tuple) else k


def issue(case, target, domain='nonneg', alpha=False, limit=400000):
    """Exact shared-assignment DP from position 0 that keeps every boundary frontier.
    Returns (certificate | None, evaluations).  Evaluations are counted with the
    BC-2 meter (same unit as every strong route)."""
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        return None, 0
    ctx = T.Ctx(F)
    n = F.n
    frontier = {(T.S0, frozenset())}
    frontiers = [frontier]
    units = {}
    with Meter(limit) as meter:
        for i in range(target + 1):
            nxt = set()
            for s, asg in frontier:
                if s >> 1 == T.SKIP and i == target:
                    continue
                res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=i >= target - 1), dict(asg))
                for (ns, unit), a in res:
                    if unit is not None and any(sl['item'] == target for sl in unit['slots']):
                        units[T._key(unit)] = unit
                    elif i < target:
                        nxt.add((ns, frozenset(O._prune(a, i).items())))
            if i < target:
                frontier = nxt
                frontiers.append(frontier)
    if len(units) != 1:
        return None, meter.n
    unit = next(iter(units.values()))
    ph, eh = default_support(n, target)
    cert = dict(format='fixQ2-pcc-1', target=target, unit=unit, domain=domain, alpha=alpha, pos_hi=ph, edge_hi=eh,
                frontiers=[sorted(([s, sorted(([_ser_key(k), v] for k, v in asg), key=repr)] for s, asg in Fr),
                                  key=repr) for Fr in frontiers])
    return json.loads(json.dumps(cert)), meter.n          # exactly what a receiver would parse


def mask(case, pos_hi, edge_hi):
    """Forget every fact outside the claimed support (receiver's view)."""
    c = copy.deepcopy(case)
    for p, it in enumerate(c['items']):
        if p > pos_hi:
            it['analysis'] = {'status': 'unknown'}
            it.pop('header', None)
    c['edges'] = [e for e in c.get('edges', []) if not (e['second'] == e['first'] + 1 and e['first'] > edge_hi)]
    return c


def route1_check(case, cert, brute_max_n=7):
    """R9 route: re-derive the unit with the exact DP (and worlds for n <= 7) on the
    claimed-support view of the case.  Trusts transducer + omega."""
    c = mask(case, cert['pos_hi'], cert['edge_hi'])
    try:
        ok, why = R1.check(c, cert['target'], cert['unit'], cert['domain'], cert['alpha'], brute_max_n=brute_max_n)
    except Exception as e:                                  # noqa: BLE001
        return False, 'error:' + type(e).__name__
    return ok, why


def truth(case, cert):
    """Ground truth of the CLAIM (unit, domain, alpha, support): certify_exact on the
    claimed-support view.  Used only to label mutants as valid/invalid claims."""
    c = mask(case, cert['pos_hi'], cert['edge_hi'])
    if not T.Facts(c, 'omega', cert['domain'], cert['alpha']).domain_ok:
        return False                     # ill-formed claim: admitted ranks violate the declared domain
    st, u = O.certify_exact(c, cert['target'], cert['domain'], cert['alpha'])
    return st == 'certified' and u == cert['unit']


# ------------------------------------------------------------------ mutants
def mutants(cert, rng):
    out = []
    u = copy.deepcopy(cert)
    sl = u['unit']['slots'][0]
    sl['slot'] = {'A': 'B', 'B': 'A', 'ALL': 'A'}.get(sl['slot'], 'ALL')
    out.append(('wrong_unit', u))
    u = copy.deepcopy(cert)
    u['unit']['reason'] = 'UNRESOLVED' if u['unit']['reason'] != 'UNRESOLVED' else 'TAIL'
    out.append(('wrong_reason', u))
    cand = [i for i in range(1, len(cert['frontiers'])) if cert['frontiers'][i]]
    if cand:
        u = copy.deepcopy(cert)
        i = rng.choice(cand)
        u['frontiers'][i].pop(rng.randrange(len(u['frontiers'][i])))
        out.append(('dropped_frontier_element', u))
    t = cert['target']
    for d in (1, 2, 3):
        if cert['pos_hi'] - d >= t:
            u = copy.deepcopy(cert)
            u['pos_hi'] -= d
            u['edge_hi'] = min(u['edge_hi'], u['pos_hi'] - 1)
            out.append(('support_truncated_%d' % d, u))
    for dom in ('ext', 'nonneg', 'G0'):
        if dom != cert['domain']:
            u = copy.deepcopy(cert)
            u['domain'] = dom
            out.append(('domain_%s' % dom, u))
    if not cert['alpha']:
        pass
    else:
        u = copy.deepcopy(cert); u['alpha'] = False
        out.append(('alpha_dropped', u))
    return out
