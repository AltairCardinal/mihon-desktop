"""X30 = S03 (semantic migration to an L2 rule) x T05 (residual in-semantics gain),
run as ONE coupled experiment on common traces (no number splicing).

Groups on the same trace (initial case, hidden world, intents, one 'migrate'
event at time M):
  '0'   incumbent L0 policy, current semantics throughout (migrate = no-op)
  'A'   gated_shadow (wpA ShadowRunner), current semantics throughout
  'B'   incumbent policy; at M the rule changes to L2 = cut16 (wpS_rules.seg_cut_plan:
        every 16-segment planned independently with the frozen rule)
  'AB'  gated_shadow + the same L2 migration; after M the shadow proves under L2
Migration organisations (each B/AB group is run with both):
  'switch'   switch at context: every publication is revoked at M and the
             targets are re-requested under L2 (all certificates re-issued later)
  'perunit'  per-unit migration: at M each current publication whose unit is
             L2-certified from the admitted evidence with the IDENTICAL unit is
             re-signed in place (new handle, no visible change); the others are
             revoked and re-requested
Authority (certificates, publications, confirmations) never migrates; evidence,
raw witnesses and running tasks do (a rule change is not an identity change).
L2 certification of target t = the frozen L0 strategy (corrected Owner) on the
segment sub-case; its support is mapped back to the global typed keys and
validated by the unchanged Session guards.  The L2 shadow proof = strong.py
fresh route on the segment sub-case (BC-2 meter).
Quality: no truth exists; we only COUNT the distinct local disagreement motif
classes between the reference plan and the L2 plan on the hidden complete case
(wpS_rules.motifs) = adjudications a user would have to make.
"""
from copy import deepcopy

import paths  # noqa: F401
import compact_core as core
import reference as ref
from corrected_owner import Owner
from strong import StrongSession, strong_attempt, support_keys
from coupled_runner import world_case
import wpA_lib as A
import wpS_rules as S

SEG = 16


def sub_case(case, lo, hi):
    """Exactly the sub-sequence seg_cut_plan plans (same settings mapping)."""
    s = case.get('settings', {})
    sub = deepcopy(case)
    sub['items'] = sub['items'][lo:hi]
    sub['edges'] = [dict(e, first=e['first'] - lo, second=e['second'] - lo) for e in case.get('edges', [])
                    if lo <= e['first'] and e['second'] < hi]
    ss = dict(s)
    ss['hard_isolates'] = [i - lo for i in s.get('hard_isolates', []) if lo <= i < hi]
    ss['pinned_links'] = [i - lo for i in s.get('pinned_links', []) if lo <= i < hi - 1]
    sub['settings'] = ss
    return sub


def _shift_key(k, lo):
    return (k[0],) + tuple(x + lo if isinstance(x, int) and not isinstance(x, bool) else x for x in k[1:])


def _shift_unit(u, lo):
    u = deepcopy(u)
    for sl in u['slots']:
        sl['item'] += lo
    return u


def l2_truth(initial, world):
    plan = S.seg_cut_plan(world_case(initial, world), SEG)
    out = {}
    for u in plan:
        for s in u['slots']:
            out[s['item']] = u
    return out


class L2Session(StrongSession):
    def __init__(self, case, **kw):
        super().__init__(case, **kw)
        self.rule = 'ref'

    def _seg(self, t):
        n = len(self.owner._case['items'])
        lo = (t // SEG) * SEG
        return lo, min(n, lo + SEG)

    def reset_authority(self):
        self.epoch += 1                                  # old handles/callbacks can never validate again
        self._certs.clear(); self._published.clear(); self._confirmed.clear(); self._published_handles.clear()

    def _issue(self, t, unit, support_local, lo):
        index = self.owner._index()
        support = {}
        for k in support_local:
            gk = _shift_key(k, lo)
            support[gk] = self.owner._read(index, gk)
        self._next_certificate += 1
        h = self._next_certificate
        self._certs[h] = dict(target=t, unit=deepcopy(unit), guard=self.owner._guard(), epoch=self.epoch,
                              support=support)
        return h

    def certify(self, target, *, mode='L0', budget=None):
        if self.rule == 'ref':
            return super().certify(target, mode=mode, budget=budget)
        lo, hi = self._seg(target)
        sub = sub_case(self.owner._case, lo, hi)
        o = Owner(sub)
        res = o.request(target - lo)
        steps = o.metrics['scan_steps']
        entry = o._memo.get(target - lo)
        if entry is not None:
            sup = dict(entry['support'])
        else:
            b = core.certify(sub, target - lo, 2)
            atts = [b] + ([core.certify(sub, target - lo, 3)] if b['status'] == 'need_facts' else [])
            sup = dict(pair for a in atts for pair in a['proof'][2])
            steps += sum(a['steps'] for a in atts)
        self.metrics['certification_calls'] += 1
        self.metrics['certification_steps'] += steps
        self.metrics['l2_certifications'] += 1
        out = deepcopy(res)
        for nd in out.get('needs', []):
            nd['item'] += lo
            if 'second' in nd:
                nd['second'] += lo
        out['failures'] = {str(int(k) + lo): v for k, v in out.get('failures', {}).items()}
        out['dependent_items'] = [i + lo for i in out.get('dependent_items', [])]
        if out.get('unit'):
            out['unit'] = _shift_unit(out['unit'], lo)
        if out['status'] == 'certified':
            out['certificate'] = self._issue(target, out['unit'], sup, lo)
            return out
        if mode != 'S' or out['status'] != 'need_facts':
            return out
        # L2 shadow proof: fresh strong route on the segment (BC-2 meter, strong.budget)
        cfg = self.strong
        att = strong_attempt(sub, target - lo, cfg['kind'], cfg['domain'], cfg['alpha'], cfg['budget'])
        self.metrics['strong_attempts'] += 1
        self.metrics['strong_evaluations'] += att['evaluations']
        self.metrics['strong_ns'] += att['ns']
        if att['status'] == 'stopped':
            self.metrics['strong_stops'] += 1
        tl = target - lo
        nsub = len(sub['items'])
        gated = att['status'] == 'certified' and att['unit']['certain']
        if gated and cfg['gate'] == 'raw':
            ix = core.Index(sub, check_ids=False)
            gated = all(ix.analysis(p)[0] == 'computed' for p in range(0, min(nsub - 1, tl + 3) + 1))
        self.strong_log.append(dict(target=target, status=att['status'], gated=gated, evaluations=att['evaluations'],
                                    ns=att['ns'], route='l2-' + att['route']))
        if not gated:
            return out
        self.metrics['strong_certificates'] += 1
        unit = _shift_unit(att['unit'], lo)
        h = self._issue(target, unit, support_keys(nsub, tl), lo)
        return dict(status='certified', unit=unit, needs=[], failures={}, first=lo, steps=att['evaluations'],
                    dependent_items=list(range(lo, lo + min(nsub - 1, tl + 3) + 1)), certificate=h,
                    route='strong-l2-' + att['route'])


class _MigrateMixin:
    org = None                        # None (no L2), 'switch', 'perunit'

    def _install(self, trace, org, kw):
        self.org = org
        st = dict(kind='tree', domain='nonneg', alpha=False, gate='raw', budget=None)
        st.update(kw.get('strong') or {})
        self.session = L2Session(trace['initial'], capacity=kw.get('capacity', 3),
                                 raw_capacity=kw.get('raw_capacity', 3), strong=st)
        self.old_units = {}
        for k in ('revoked', 'resigned', 'visible_changes', 'same_unit_republished', 'migrations'):
            self.c[k] = 0

    def _publish(self, target, verdict):
        r = super()._publish(target, verdict)
        self._after_pub(target, verdict, r)
        return r

    def _after_pub(self, target, verdict, r):
        if r == 'published' and target in self.old_units:
            old = self.old_units.pop(target)
            if verdict['unit'] != old:
                self.c['visible_changes'] += 1
            else:
                self.c['same_unit_republished'] += 1

    def _rebind(self, ev):
        if ev.get('kind') != 'migrate':
            return super()._rebind(ev)
        if self.org is None:
            return                                        # groups 0 / A: rule never changes
        s = self.session
        self.c['migrations'] += 1
        current = {t: deepcopy(u) for t, u in s._published.items()}
        served = set(self.first_pub)
        s.rule = 'cut16'
        s.reset_authority()
        self.truth = l2_truth(self.trace['initial'], self.world_w)
        self.proof_inflight.clear(); self.proof_failed_at.clear()
        for t in sorted(served):
            u_old = current.get(t)
            if self.org == 'perunit' and u_old is not None:
                v = s.certify(t, mode='L0')
                if v['status'] == 'certified' and v['unit'] == u_old:
                    if s.publish(t, v['certificate']) == 'published':
                        self.c['resigned'] += 1
                        continue
            self.c['revoked'] += u_old is not None
            if u_old is not None:
                self.old_units[t] = u_old
            if t not in self.pending:
                self.pending.append(t)
            self.republish[t] = self.now
        if hasattr(self, 'l0_pending'):
            for t in self.pending:
                if t not in self.l0_pending:
                    self.l0_pending.append(t)


class X30Inc(_MigrateMixin, A.ARunner):
    def __init__(self, trace, org=None, **kw):
        super().__init__(trace, policy='incumbent', **kw)
        self._install(trace, org, kw)


class X30Shadow(_MigrateMixin, A.ShadowRunner):
    def __init__(self, trace, org=None, **kw):
        super().__init__(trace, policy='gated_shadow', **kw)
        self._install(trace, org, kw)

    def _publish_proof(self, target, verdict):
        r = super()._publish_proof(target, verdict)
        self._after_pub(target, verdict, r)
        return r


GROUPS = {
    '0': lambda tr, **kw: X30Inc(tr, None, **kw),
    'A': lambda tr, **kw: X30Shadow(tr, None, **kw),
    'B_switch': lambda tr, **kw: X30Inc(tr, 'switch', **kw),
    'B_perunit': lambda tr, **kw: X30Inc(tr, 'perunit', **kw),
    'AB_switch': lambda tr, **kw: X30Shadow(tr, 'switch', **kw),
    'AB_perunit': lambda tr, **kw: X30Shadow(tr, 'perunit', **kw),
}


def with_migration(trace, at):
    tr = deepcopy(trace)
    tr['events'] = sorted(tr['events'] + [dict(at=at, op='rebind', kind='migrate')], key=lambda e: e['at'])
    tr['name'] = tr['name'] + f'_mig{at}'
    return tr


def adjudications(trace):
    """Distinct local disagreement motif classes reference vs cut16 on the hidden
    complete case (counts only; no quality score exists)."""
    w = world_case(trace['initial'], trace['world'])
    a, b = ref.complete_plan(w), S.seg_cut_plan(w, SEG)
    ma, mb = S.plan_members(a), S.plan_members(b)
    return dict(motif_classes=len(S.motifs(a, b, w)), differing_items=sum(1 for i in range(len(ma)) if ma[i] != mb[i]),
                items=len(ma))


METRICS = ('physical_admissions', 'total_latency_u', 'published', 'intents', 'wrong', 'certification_steps',
           'strong_evaluations', 'strong_certificates', 'lane_busy_u', 'revoked', 'resigned', 'visible_changes',
           'same_unit_republished', 'republished', 'republish_latency_u', 'pending_republish', 'proof_wins')


def run_group(trace, group, service_u=4, q_u=1):
    r = GROUPS[group](trace, service_u=service_u, q_u=q_u).run(max_steps=60000)
    out = {k: r.get(k, 0) for k in METRICS}
    out['livelock'] = r.get('livelock', False)
    return out
