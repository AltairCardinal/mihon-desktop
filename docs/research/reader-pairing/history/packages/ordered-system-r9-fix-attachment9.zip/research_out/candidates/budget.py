"""Unified strong-proof budget contract BC-2 (fix round after R9).

Scope.  Every certify route other than the package L0 owner that can issue a
certificate ("strong route"): fresh tree / exact / portfolio (strong.py),
persistent tree (wpA_lib.PersistentStrongSession), block summaries
(wpB_coupled.BlockSession), gated full-information index
(wpC_coupled.IndexedSession, modes 'I'/'SEL').

Unit.  One *step evaluation* = one (result, assignment) pair returned by
transducer.explore over the frozen step predicate; an explore call that
returns nothing still costs 1.  A direct deterministic step (index query on
complete facts) costs 1.  This is the unit the fresh route already used in R9
(unchanged).  Segment-tree composes (bitmask joins) and fact refresh /
invalidation are maintenance, not step evaluations: they are reported
separately (node_compose, invalidations) and are not budgeted.

Charging.  The budget bounds the evaluations performed *in the call*:
building or rebuilding a structure, recomputing dirty leaves / blocks,
filling block tables and frontiers, and the query exploration itself.  No
route records 0 for work it performed.

Stop.  The meter raises BudgetExceeded right after the explore call whose
results take the running count above the limit.  The call then issues
nothing (returns the L0 verdict), `strong_stops` += 1, and the evaluations
stay charged in the metrics.  A call needing exactly `budget` evaluations
certifies; one evaluation less stops.

Transactions.  A stopped call is rolled back: every structure entry created
in the call is discarded and pending dirty sets are retained, so repeated
calls with a too-small budget never accumulate a proof (no slicing).
Maintenance that only removes cached state or refreshes facts from the owner
is kept (it is sound and idempotent).

Reuse.  (a) Reusing structure committed by an earlier successful call is
allowed; its evaluations were charged to that call.  (b) Reusing an issued
certificate (publish/confirm of a current handle, re-sign after rebind with
equal support) is not a proof computation: it is outside this budget and is
governed by the guard/epoch/support checks; it is counted separately.

Call-level budget.  In mode 'S', a `certify(..., budget=B)` argument bounds
L0 scan steps + strong evaluations of the call (strong limit = min(strong.budget,
B - L0 steps)).  Before the fix this argument only bounded L0.

Contract changes relative to R9 (listed in proofs/fix_budget.md):
  C1 persistent/block/index evaluations are charged and enforced (were 0 /
     charged-not-enforced / 0);
  C2 stopped calls roll back shared structures (new for all shared routes);
  C3 call-level budget composes with strong.budget in mode 'S';
  C4 the gated index (modes 'I'/'SEL') is a strong route and obeys strong.budget.
Unchanged: unit definition, fresh-route behaviour, guards/publication rules.
"""
import transducer as T


class BudgetExceeded(Exception):
    pass


class Meter:
    """Counts step evaluations while active; raises once the count exceeds limit."""

    def __init__(self, limit):
        self.limit = limit
        self.n = 0
        self._orig = None

    def tick(self, k=1):
        self.n += k
        if self.limit is not None and self.n > self.limit:
            raise BudgetExceeded()

    def __enter__(self):
        orig = self._orig = T.explore

        def explore(ctx, fn, base=None):
            out = orig(ctx, fn, base)
            self.tick(max(1, len(out)))
            return out
        T.explore = explore
        return self

    def __exit__(self, *exc):
        T.explore = self._orig
        return False


def effective_limit(strong_budget, call_budget, l0_steps):
    lim = strong_budget
    if call_budget is not None:
        rest = call_budget - l0_steps
        lim = rest if lim is None else min(lim, rest)
    if lim is not None and lim < 0:
        lim = 0
    return lim
