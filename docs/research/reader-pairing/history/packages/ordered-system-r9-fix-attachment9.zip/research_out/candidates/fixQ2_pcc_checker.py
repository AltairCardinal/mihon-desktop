"""T04 route 2: independent checker for proof-carrying frontier certificates.

Trusts ONLY: reference._Scan (frozen rule), compact_core.Index/_geometry_t
(frozen case parsing), the 10-state encoding lemma L-M (state = cursor mode x
manual(i-1) bit) and this file.  It does NOT import transducer/omega/strong
(no DP, no relation tree, no pruning, no feasibility search of the issuer).

Certificate (JSON-able dict, see fixQ2_pcc.issue):
  target, unit, domain ('ext'|'nonneg'|'G0'), alpha (header authority),
  pos_hi, edge_hi (claimed support: facts at positions <= pos_hi, ranks of
  edges (a, a+1) with a <= edge_hi; everything else is treated as unknown),
  frontiers[i] for i = 0..target: list of [state, [[key, value], ...]] = an
  inductive invariant at the boundary before position i.
Check:  F_0 contains (S0, {});  for every element (s, b) of F_i, every branch of
step i under b (all options of every unread fact; comparison outcomes dropped
only when provably infeasible over the reals) either yields a unit containing
the target, which must equal `unit`, or (i < target) a successor (s', a) that
is covered by some (s', b') in F_{i+1} with b' a subset of a; at least one
target unit must be reached.  Soundness: every completion of the claimed
support facts follows one branch per step, so by induction it is covered at
every boundary and its target unit is `unit` (proofs/fix_Q2.md, Lemma P-1).
"""
import json

import reference as ref
import compact_core as core

SKIP = 4
NSTATE = 10
G0_HI = 29.98


class Need(Exception):
    def __init__(self, key, options):
        self.key, self.options = key, options


def _tup(x):
    return tuple(_tup(y) for y in x) if isinstance(x, list) else x


class _Sym:
    __slots__ = ('edge', 'ev')

    def __init__(self, edge, ev):
        self.edge, self.ev = edge, ev

    def __lt__(self, other):
        return self.ev.compare(self, other)

    def __gt__(self, other):
        return self.ev.compare(other, self)


def _term(v):
    return ('e', v.edge) if isinstance(v, _Sym) else ('k', v)


def in_domain(s, domain):
    if s is None:
        return True                                   # computed null rank
    if isinstance(s, bool) or not isinstance(s, (int, float)) or s != s or s in (float('inf'), float('-inf')):
        return False
    if domain == 'nonneg':
        return s >= 0
    if domain == 'G0':
        return 0 <= s <= G0_HI and abs(s * 50 - round(s * 50)) < 1e-9
    return True


def infeasible(cons, domain):
    """Sound infeasibility over the reals: strict edge inside a cycle of the
    order graph (constants, domain bounds and symbols)."""
    succ = {}

    def add(u, v, strict):
        succ.setdefault(u, []).append((v, strict))
        succ.setdefault(v, [])
    syms, consts = set(), set()
    for (x, y), out in cons:
        for t in (x, y):
            (syms if t[0] == 'e' else consts).add(t if t[0] == 'e' else ('k', t[1]))
        if out:
            add(x if x[0] == 'e' else ('k', x[1]), y if y[0] == 'e' else ('k', y[1]), True)
        else:
            add(y if y[0] == 'e' else ('k', y[1]), x if x[0] == 'e' else ('k', x[1]), False)
    if domain in ('nonneg', 'G0'):
        consts.add(('k', 0))
        for s in syms:
            add(('k', 0), s, False)
    if domain == 'G0':
        consts.add(('k', G0_HI))
        for s in syms:
            add(s, ('k', G0_HI), False)
    cs = sorted({c[1] for c in consts})
    for a, b in zip(cs, cs[1:]):
        add(('k', a), ('k', b), True)
    norm = {}
    for c in list(succ):                          # merge equal-valued constants (1 == 1.0)
        if c[0] == 'k':
            norm.setdefault(c[1], []).append(c)
    for v, group in norm.items():
        for g in group[1:]:
            add(group[0], g, False); add(g, group[0], False)

    def reach(u, target):
        seen, st = {u}, [u]
        while st:
            x = st.pop()
            if x == target:
                return True
            for y, _ in succ.get(x, ()):
                if y not in seen:
                    seen.add(y); st.append(y)
        return False
    return any(strict and reach(v, u) for u, es in succ.items() for v, strict in es)


class Evaluator:
    def __init__(self, case, domain, alpha, pos_hi, edge_hi):
        ix = core.Index(case)
        self.n = ix.n
        self.settings = ix.settings
        self.domain = domain
        self.starts = set(ix.settings['pinned_links']) | ({0} if ix.settings['opening'] == 'PAIR' else set())
        self.forced = set(ix.settings['hard_isolates'])
        self.state, self.side = [None] * self.n, [None] * self.n
        for p in range(min(self.n, pos_hi + 1)):
            a, ident = ix.analysis(p), ix.ident(p)
            if a[0] == 'computed' and self._valid(a[1], ident):
                self.state[p], self.side[p] = a[1][0], a[1][5]
                continue
            h = ix.header(p)
            if alpha and self._valid(h, ident):
                self.state[p] = h[0]
        self.records = {a: e for (a, b), e in ix._edge_index().items() if b == a + 1 and 0 <= a <= edge_hi}
        self.asg, self.m = {}, {}
        self.scan = _Scan(self.n, self.settings, self._dim, self._side, self._side, self._rank, self)
        self.steps = 0

    @staticmethod
    def _valid(f, ident):
        return f is not None and core._geometry_t(f) and f[3] == ident[2] and f[4] == ident[3]

    def choose(self, key, options):
        if key not in self.asg:
            raise Need(key, options)
        return self.asg[key]

    def _st(self, p):
        s = self.state[p]
        return s if s is not None else self.choose(('st', p), ('NARROW', 'WIDE'))

    def _dim(self, i):
        return {'state': self._st(i)}

    def _side(self, i):
        s = self.side[i]
        return s if s is not None else self.choose(('sd', i), ('A', 'B', 'UNKNOWN'))

    def _rank(self, a, b):
        if self._st(a) == 'WIDE' or self._st(b) == 'WIDE':
            return None
        e = self.records.get(a)
        if e is not None and e.get('status') == 'computed':
            return e.get('score', None)
        if self.choose(('rk', a), ('NULL', 'VAL')) == 'NULL':
            return None
        return _Sym(a, self)

    def compare(self, x, y):
        key = ('lt', _term(x), _term(y))
        if key in self.asg:
            return self.asg[key]
        cons = [((k[1], k[2]), v) for k, v in self.asg.items() if k[0] == 'lt']
        opts = tuple(o for o in (True, False) if not infeasible(cons + [((key[1], key[2]), o)], self.domain))
        raise Need(key, opts)

    # ---- one step of the 10-state transducer (encoding lemma L-M)
    def _B(self, o):
        if o not in self.starts or not 0 <= o < self.n - 1 or o in self.forced or o + 1 in self.forced:
            return False
        return not self.scan.wide(o) and not self.scan.wide(o + 1)

    def step(self, i, state, include):
        mode, m_in = divmod(state, 2)
        self.m = {i - 1: bool(m_in)}
        prev = bool(m_in)
        for o in (i, i + 1, i + 2):
            prev = self._B(o) and not prev
            self.m[o] = prev
        m_out = int(self.m[i])
        self.steps += 1
        if mode == SKIP:
            return 2 * 2 + m_out, None                     # at(opening=False, reserved=False)
        opening, res = mode < 2, mode % 2 == 1
        unit, nxt = self.scan.step((i, opening, i if res else -1), include_single=include, include_pair=include)
        if nxt[0] == i + 2:
            return SKIP * 2 + m_out, unit
        return ((0 if nxt[1] else 2) + (1 if nxt[2] == i + 1 else 0)) * 2 + m_out, unit

    def branches(self, i, state, base, include):
        out, stack = [], [dict(base)]
        while stack:
            asg = stack.pop()
            self.asg = asg
            try:
                out.append((self.step(i, state, include), asg))
            except Need as e:
                for o in e.options:
                    d = dict(asg); d[e.key] = o; stack.append(d)
        return out


class _Scan(ref._Scan):
    def __init__(self, n, settings, dimension, side, resolved, distance, ev):
        super().__init__(n, settings, dimension, side, resolved, distance)
        self.ev = ev

    def manual(self, i):
        return self.ev.m[i]


def _covered(state, asg, index):
    items = set(asg.items())
    return any(b <= items for b in index.get(state, ()))


def check(case, cert):
    """(ok, reason). Never raises on malformed certificates."""
    try:
        t, unit = cert['target'], cert['unit']
        ev = Evaluator(case, cert['domain'], cert['alpha'], cert['pos_hi'], cert['edge_hi'])
        fr = [[(s, frozenset((_tup(k), v) for k, v in asg)) for s, asg in F] for F in cert['frontiers']]
    except Exception as e:                                  # noqa: BLE001
        return False, 'malformed:' + type(e).__name__
    if not 0 <= t < ev.n or len(fr) != t + 1:
        return False, 'shape'
    if cert['domain'] not in ('ext', 'nonneg', 'G0') or any(
            e.get('status') == 'computed' and not in_domain(e.get('score'), cert['domain']) for e in ev.records.values()):
        return False, 'domain_violation'
    if (0, frozenset()) not in fr[0]:
        return False, 'no_start'
    found = False
    for i in range(t + 1):
        nxt_index = {}
        if i < t:
            for s, b in fr[i + 1]:
                nxt_index.setdefault(s, []).append(b)
        for s, b in fr[i]:
            if not 0 <= s < NSTATE:
                return False, 'state'
            if s >> 1 == SKIP and i == t:
                continue
            for (ns, u), a in ev.branches(i, s, dict(b), include=i >= t - 1):
                if u is not None and any(sl['item'] == t for sl in u['slots']):
                    if u != unit:
                        return False, 'other_unit@%d' % i
                    found = True
                elif i < t:
                    if not _covered(ns, a, nxt_index):
                        return False, 'not_closed@%d' % i
                else:
                    return False, 'no_unit@%d' % i
    return (True, 'ok') if found else (False, 'empty')


def size(cert):
    return dict(bytes=len(json.dumps(cert, separators=(',', ':'))),
                elements=sum(len(F) for F in cert['frontiers']),
                assignment_entries=sum(len(a) for F in cert['frontiers'] for _s, a in F))
