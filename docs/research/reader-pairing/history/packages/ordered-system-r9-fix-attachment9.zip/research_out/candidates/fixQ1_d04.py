"""D04 (fix round, Q1): comparison-result cache vs value cache -- two routes.

Route 1  SIG       wpB_sigmemo.SigOwner (R9): memo valid iff non-rank reads are
                   typed-equal, null flags equal and, for every adjacent pair of
                   read ranks, BOTH strict-order bits (b<a, a<b) are unchanged.
Route 2  INTERVAL  carried difference-interval memo: at store time each adjacent
                   read pair (a = r(i,i+1), b = r(i+1,i+2)) carries the half-open
                   interval of delta = b - a in which the scan decision holds:
                   (-inf, 0) if b < a, [0, +inf) otherwise.  Valid iff non-rank
                   reads typed-equal, null flags equal, and every carried delta
                   stays inside its interval.

Theorem D04-1 (proofs/fix_Q1.md): the frozen scan reads ranks only in
later_wins(i) and uses them only as `b is not None and (a is None or b < a)`
with a = r(i,i+1), b = r(i+1,i+2).  So the indicator [b < a] (plus null flags)
is the whole decision content of a rank pair; the extra bit [a < b] that SIG also
freezes is never consulted.  Hence INTERVAL is exact for the FULL public
observation (status, unit, needs, failures, first, steps, dependent_items) and
accepts strictly more changes than SIG (e.g. a tie a == b becoming a < b, or
a < b becoming a tie).

Result reuse vs full public-observation reuse: `classify_change` recomputes the
public result fresh and reports whether a change kept (a) the full observation,
(b) only the canonical unit (diagnostics/steps changed: legal for a unit-only
consumer, illegal for full observation reuse), or (c) neither.
"""
import paths  # noqa: F401
from corrected_owner import Owner, SAT
from current_baseline import typed
import wpB_sigmemo as SG


def interval_equal(old_support, new_reads):
    ranks_old, ranks_new = {}, {}
    for key, old in old_support.items():
        new = new_reads[key]
        if key[0] == 'rank':
            ro, rn = SG._rank_val(old), SG._rank_val(new)
            if ro is None or rn is None:
                if typed(old) != typed(new):
                    return False
                continue
            if (ro[1] is None) != (rn[1] is None):
                return False
            ranks_old[key[1]] = ro[1]
            ranks_new[key[1]] = rn[1]
        elif typed(old) != typed(new):
            return False
    for a in ranks_old:
        b = a + 1
        if b not in ranks_old:
            continue
        x0, y0, x1, y1 = ranks_old[a], ranks_old[b], ranks_new[a], ranks_new[b]
        if x0 is None or y0 is None:
            continue
        if ((y0 - x0) < 0) != ((y1 - x1) < 0):         # delta left its carried interval
            return False
    return True


class IntervalOwner(Owner):
    """Corrected owner + carried difference-interval fallback (L0: identical public output)."""

    def _valid(self, entry, index):
        if entry['guard'] != self._guard() or self._case.get('closed', False):
            return False
        if self.config.stamps and self._revision < SAT and entry['stamp'] == self._revision:
            self.metrics['stamp_hits'] += 1
            return True
        self.metrics['support_validations'] += 1
        current = {}
        exact = True
        for key, old in entry['support'].items():
            self.metrics['typed_reads_checked'] += 1
            now = self._read(index, key)
            current[key] = now
            if exact and typed(old) != typed(now):
                exact = False
        if not exact:
            if not interval_equal(entry['support'], current):
                return False
            self.metrics['interval_hits'] += 1
            if not SG.signature_equal(entry['support'], current):
                self.metrics['interval_only_hits'] += 1      # accepted here, rejected by SIG
            entry['support'] = current
        entry['stamp'] = self._revision
        return True


class IntervalMutantBothSigns(IntervalOwner):
    """Mutant: interval keyed on delta <= 0 instead of delta < 0 (wrong boundary)."""

    def _valid(self, entry, index):
        import fixQ1_d04 as M
        orig = M.interval_equal

        def wrong(old, new):
            ranks_old, ranks_new = {}, {}
            for key, o in old.items():
                nw = new[key]
                if key[0] == 'rank':
                    ro, rn = SG._rank_val(o), SG._rank_val(nw)
                    if ro is None or rn is None:
                        if typed(o) != typed(nw):
                            return False
                        continue
                    if (ro[1] is None) != (rn[1] is None):
                        return False
                    ranks_old[key[1]] = ro[1]; ranks_new[key[1]] = rn[1]
                elif typed(o) != typed(nw):
                    return False
            for a in ranks_old:
                if a + 1 in ranks_old and None not in (ranks_old[a], ranks_old[a + 1]):
                    if ((ranks_old[a + 1] - ranks_old[a]) <= 0) != ((ranks_new[a + 1] - ranks_new[a]) <= 0):
                        return False
            return True
        M.interval_equal = wrong
        try:
            return IntervalOwner._valid(self, entry, index)
        finally:
            M.interval_equal = orig


def classify_change(before, after):
    """before/after: public results of a fresh request. -> 'full'|'unit_only'|'changed'."""
    if typed(before) == typed(after):
        return 'full'
    if before.get('status') == after.get('status') == 'certified' and typed(before.get('unit')) == typed(after.get('unit')):
        return 'unit_only'
    return 'changed'
