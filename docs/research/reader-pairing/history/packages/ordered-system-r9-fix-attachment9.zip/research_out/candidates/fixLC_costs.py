"""Fix round: per-mechanism memory / residency on one fixed common workload (tag LC).

Common workload = the LV traces (W01 s0, W05 s2, RP s0; every distinct target of each
trace, in order) driven by fixLC_lifecycle.Life.drive with confirmation, then the
harness close protocol.  Quantities and their layers:
  residency_peak / residency_end / residency_after_close
      structure entries the candidate itself holds (its residency() hook; None = the
      mechanism keeps nothing beyond the package Session) -- structural count, NOT bytes
  traced_current_end, traced_peak, retained_after_close
      tracemalloc bytes relative to the baseline taken before the session is built
      (local_measured, Python 3.13; includes the harness log and the package Session)
  positive_delta_sum
      sum of positive increments of traced memory sampled after every event: a LOWER
      BOUND of cumulative allocation (tracemalloc has no cumulative counter)
  wall_ns_exploratory
      one local wall measurement inside a fork on a shared 2-vCPU machine; exploratory
      only, never a formal D3 timing
"""
import gc
import time
import tracemalloc

import paths  # noqa: F401
from fixLC_lifecycle import Life
import fixLC_groups as G
from current_baseline import typed


def measure(name, bound=False, raw_capacity=3):
    sp = G.spec(name, bound)
    rows = []
    for tname, mk in G.LV_TRACES:
        tr = mk()
        gc.collect()
        tracemalloc.start()
        base = tracemalloc.get_traced_memory()[0]
        t0 = time.perf_counter_ns()
        life = Life(sp, tr, raw_capacity=raw_capacity)
        targets = []
        for ev in tr['events']:
            if ev['op'] == 'target' and ev['target'] not in targets:
                targets.append(ev['target'])
        prev, pos = 0, 0
        res_peak = 0
        ok = True
        for t in targets:
            p, v = life.drive(t, limit=300, confirm=True)
            ok &= bool(p and typed(v['unit']) == typed(life.truth[t]))
            cur = tracemalloc.get_traced_memory()[0] - base
            pos += max(0, cur - prev)
            prev = cur
            r = life.residency()
            res_peak = max(res_peak, r or 0)
        while life.due:
            life.advance()
        cur_end, peak = tracemalloc.get_traced_memory()
        res_end = life.residency()
        life.close()
        wall = time.perf_counter_ns() - t0
        life.rows.clear()                      # harness log is not mechanism residency
        gc.collect()
        retained = tracemalloc.get_traced_memory()[0] - base
        tracemalloc.stop()
        m = life.s.metrics
        rows.append(dict(trace=tname, targets=len(targets), all_published_truthful=ok,
                         residency_peak=res_peak if life.residency() is not None else None,
                         residency_end=res_end, residency_after_close=life.residency(),
                         traced_current_end=cur_end - base, traced_peak=peak - base,
                         retained_after_close=retained, positive_delta_sum=pos,
                         wall_ns_exploratory=wall,
                         admissions=m['physical_admissions'], certification_steps=m['certification_steps'],
                         strong_evaluations=m['strong_evaluations'], publication_read_checks=m['publication_read_checks']))
    return dict(mechanism=name, bound=bound, raw_capacity=raw_capacity, rows=rows,
                layers=dict(residency='structural entries', traced='tracemalloc bytes (local_measured)',
                            positive_delta_sum='lower bound of cumulative allocation (bytes)',
                            wall_ns_exploratory='fork-local single wall (not formal)'))
