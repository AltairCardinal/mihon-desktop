"""WP-H publication / certificate-transaction mechanisms on the coupled Session.

  IncSession      H03: incremental revocation. A reverse index support-key ->
                  publication handles plus a dirty-key log fed by the owner's
                  atomic writes; only publications whose support intersects the
                  dirty keys are re-validated (guard/epoch checked O(1) for all).
  BoundConfirm    H04: confirmation bound to the publication instance (handle);
                  the package Session.confirm(target) is NOT bound, so a late
                  callback for an expired publication confirms a NEW
                  publication of an equal unit (counterexample in tests).
  ValueCacheSession  H05: value-keyed work reuse across rebind (full content
                  identity + recipe version + transform) while certificates,
                  publications and confirmations stay incarnation-bound.
  commit_check_*  H01: snapshot certify + validate-at-commit (support equality)
                  vs owner short transaction (certify+publish without writes).
All classes keep the Session's public contract otherwise.
"""
from copy import deepcopy

import paths  # noqa: F401
from coupling import Session, Witness
from current_baseline import typed
from strong import StrongSession


def item_keys(i):
    return [('analysis', i), ('header', i), ('dimension', i), ('rank', i - 1, i), ('rank', i, i + 1)]


class _DirtyMixin:
    """Wraps owner.apply / replace so every atomic write reports the read keys it may change."""

    def _install_dirty(self):
        self._dirty = set()
        self._dirty_all = True          # start: everything unknown
        owner = self.owner
        orig_apply = owner.apply

        def apply(*, item_updates=None, edge_updates=None, settings=None, **kw):
            changed = orig_apply(item_updates=item_updates, edge_updates=edge_updates, settings=settings, **kw)
            if changed:
                for i in (item_updates or {}):
                    self._dirty.update(item_keys(i))
                for (a, b) in (edge_updates or {}):
                    self._dirty.add(('rank', a, b))
                if settings is not None or kw:
                    self._dirty_all = True
            return changed
        owner.apply = apply
        orig_rebind = owner.rebind

        def rebind(case):
            orig_rebind(case)
            self._dirty_all = True
        owner.rebind = rebind


class IncSession(_DirtyMixin, StrongSession):
    def __init__(self, case, **kw):
        super().__init__(case, **kw)
        self._install_dirty()
        self._rev = {}                  # support key -> set(handles) for current publications
        self._last_guard = None

    def publish(self, target, handle):
        r = super().publish(target, handle)
        if r == 'published':
            for k in self._certs[handle]['support']:
                self._rev.setdefault(k, set()).add(handle)
        return r

    def _drop(self, target, handle):
        self._published_handles.pop(target, None)
        self._published.pop(target, None)
        self._confirmed.pop(target, None)
        cert = self._certs.get(handle)
        if cert is not None:
            for k in cert['support']:
                s = self._rev.get(k)
                if s is not None:
                    s.discard(handle)
                    if not s:
                        del self._rev[k]

    def _expire_publications(self):
        guard = (self.owner._guard(), self.epoch)
        if self._dirty_all or guard != self._last_guard:
            # global change: fall back to the full check (same as the package Session)
            for target, handle in list(self._published_handles.items()):
                cert = self._certs.get(handle)
                if cert is None or not self._certificate_current(cert):
                    self._drop(target, handle)
            self._dirty_all = False
            self._dirty.clear()
            self._last_guard = guard
            return
        if not self._dirty:
            return
        suspects = set()
        for k in self._dirty:
            suspects |= self._rev.get(k, set())
        self._dirty.clear()
        self.metrics['incremental_suspects'] += len(suspects)
        for target, handle in list(self._published_handles.items()):
            if handle in suspects:
                cert = self._certs.get(handle)
                if cert is None or not self._certificate_current(cert):
                    self._drop(target, handle)

    def rebind(self, case, **kw):
        super().rebind(case, **kw)
        self._rev.clear()
        self._dirty_all = True

    # fix round (LC): additive lifecycle hooks, no behaviour change
    def residency(self):
        return sum(len(v) for v in self._rev.values()) + len(self._dirty)

    def close(self):
        super().close()
        self._rev.clear()
        self._dirty.clear()


class BoundConfirmSession(StrongSession):
    """confirm(target, handle): the callback must name the publication it saw."""

    def confirm(self, target, handle=None):
        if handle is None:
            return 'unbound'               # refuse unbound callbacks
        if target not in self._published or self._published_handles.get(target) != handle:
            return 'stale_callback'
        return super().confirm(target)


class ValueCacheSession(StrongSession):
    """Work reuse keyed by exact content value; authority keyed by incarnation.

    cache key = (item id, content_version, rotation, orientation, recipe version)
    The cache survives rebind; certificates/publications/confirmations do not
    (Session.rebind clears them).  A cache hit completes the request without a
    physical task; the witness is admitted through the normal consume path.
    """

    def __init__(self, case, **kw):
        super().__init__(case, **kw)
        self._vcache = {}

    def _vkey(self, i):
        return (typed(self.owner._identities[i]), typed(self.version))

    # fix round (LC): additive lifecycle hooks, no behaviour change
    def residency(self):
        return len(self._vcache)

    def close(self):
        super().close()
        self._vcache.clear()

    def acquire(self, i, *, required=True):
        key = self._vkey(i)
        if key in self._vcache:
            template = self._token(i)
            if any(self._physical(tk) == self._physical(template) for tk in self._tasks):
                return super().acquire(i, required=required)       # share the in-flight physical task
            tok = super().acquire(i, required=required)
            if tok is None:
                return None
            # value-cache hit: instant virtual completion and admission, no service time
            self.metrics['value_cache_hits'] += 1
            self.metrics['physical_admissions'] -= 1
            self.finish(tok, deepcopy(self._vcache[key]))
            self.metrics['physical_finishes'] -= 1
            self.consume(tok)
            return tok
        return super().acquire(i, required=required)

    def finish(self, token, result):
        r = super().finish(token, result)
        if r == 'completed':
            task = self._tasks[token]
            if result.analysis.get('status') == 'computed':
                self._vcache[self._vkey(task['item'])] = deepcopy(result)
        return r


def commit_window_cases():
    """Enumerate (certify -> one write -> publish) interleavings on small cases
    and return violations for the real Session and for two mutant commit checks."""
    import random
    import reference as ref
    from common import random_case, roundtrip, fact
    rng = random.Random(4)
    out = dict(cases=0, interleavings=0, published=0, stale=0, violations=0,
               mutant_guard_only=0, mutant_own_items_only=0)
    for k in range(120):
        n = rng.randrange(3, 8)
        c = roundtrip(random_case(rng, n, p_unknown=0.2, p_edge_unknown=0.2))
        t = rng.randrange(n)
        out['cases'] += 1
        writes = []
        for i in range(n):
            writes.append(('item', i, dict(analysis=dict(status='computed', fact=fact('WIDE'), version=7))))
            writes.append(('item', i, dict(analysis={'status': 'unknown'})))
        for a in range(n - 1):
            writes.append(('edge', a, dict(status='computed', score=rng.choice((None, 0.5, 9.0)), version=7)))
            writes.append(('edge', a, None))
        for w in writes:
            s = Session(c)
            v = s.certify(t, mode='L0')
            if v['status'] != 'certified':
                break
            out['interleavings'] += 1
            cert = s._certs[v['certificate']]
            before_guard = cert['guard']
            if w[0] == 'item':
                s.owner.apply(item_updates={w[1]: w[2]})
            else:
                s.owner.apply(edge_updates={(w[1], w[1] + 1): w[2]})
            now = {kk: vv for kk, vv in ref.certify_strategy(s.owner.snapshot(), t)['selected'].items() if kk != 'reads'}
            correct_unit = now['unit'] if now['status'] == 'certified' else None
            r = s.publish(t, v['certificate'])
            if r == 'published':
                out['published'] += 1
                if correct_unit is not None and correct_unit != v['unit']:
                    out['violations'] += 1
                if correct_unit is None:
                    # published although the current strategy is no longer certified -> must be justified:
                    # support unchanged means the proof is still the same proof (no violation by definition)
                    pass
            else:
                out['stale'] += 1
            # mutant 1: guard-only commit check (no support comparison)
            wrong_guard = (s.owner._guard() == before_guard) and correct_unit is not None and correct_unit != v['unit']
            out['mutant_guard_only'] += int(wrong_guard)
            # mutant 2: compare only the target's own item reads
            own = {kk: vv for kk, vv in cert['support'].items() if kk[1] == t}
            idx = s.owner._index()
            own_ok = all(typed(vv) == typed(s.owner._read(idx, kk)) for kk, vv in own.items())
            out['mutant_own_items_only'] += int(own_ok and correct_unit is not None and correct_unit != v['unit'])
    return out
