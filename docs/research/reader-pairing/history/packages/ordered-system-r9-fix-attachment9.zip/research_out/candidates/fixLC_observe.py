"""Fix round, item 2: public-observation differential (tag LC).

Runs the SAME random event stream on a reference session and a candidate
session and compares every public observation the package declares
(MODEL_API.md "Acquisition, physical work, admission, and publication"):

  return values of acquire (issuance or None) / finish / consume / cancel /
  certify (all public fields, certificate handle compared by local numbering)
  / publish / confirm / rebind; and after every event observe() (admitted
  scalar evidence), published, confirmed, task(token) for live tokens,
  occupied, raw_size, certificate_count.
Session.metrics counters are reported separately as cost counters.

Pairs:
  control      Session vs GSession(order='evict_first')         (must be identical)
  derive_first Session vs GSession(order='derive_first')
  bound_confirm StrongSession vs BoundConfirmSession; confirm wiring per call:
               'current' (handle of the publication the caller saw), 'stale' (an older
               handle of the same target), 'none' (legacy unbound call)
  inc_revoke   StrongSession vs IncSession
Event menu: acquire (required/optional), real exit (finish+consume), finish only,
consume only, cancel, certify L0, publish (handle from the caller's last certify),
confirm, harness evidence writes (rank value, rank removal, version churn),
settings change, rebind (same content / one item replaced), and a final harness
close (cancel all, drain, owner.close()).
"""
import json
import random
from collections import Counter
from copy import deepcopy

import paths  # noqa: F401
import workloads as W
from coupling import Session, World, Witness
from current_baseline import typed
from strong import StrongSession
from wpG_session import GSession
from wpH_commit import IncSession, BoundConfirmSession, ValueCacheSession
from wpH_combos import MigratingSession
from wpG_owner import GOwner

PAIRS = {
    'control': (Session, dict(), GSession, dict(order='evict_first')),
    'derive_first': (Session, dict(), GSession, dict(order='derive_first')),
    'bound_confirm': (StrongSession, dict(), BoundConfirmSession, dict()),
    'inc_revoke': (StrongSession, dict(), IncSession, dict()),
    'inc_revoke_strong': (StrongSession, dict(), IncSession, dict()),        # certify/publish in mode 'S'
    'proj_support': (Session, dict(), GSession, dict(owner_factory=lambda c: GOwner(c, support='proj'))),
    'reissue_eager': (Session, dict(), GSession, dict(reissue=True, owner_factory=lambda c: GOwner(c, support='proj'))),
    'reissue_lazy': (Session, dict(), GSession, dict(reissue='lazy', owner_factory=lambda c: GOwner(c, support='proj'))),
    'migrate_resign': (StrongSession, dict(), MigratingSession, dict()),
    'value_cache': (StrongSession, dict(), ValueCacheSession, dict()),
}


def _v(x):
    """Normalise a return value for comparison (tokens by issuance; dicts by public fields)."""
    if x is None or isinstance(x, (str, int, float, bool)):
        return x
    if hasattr(x, 'issuance'):
        return ('token', x.issuance)
    if isinstance(x, dict):
        return typed({k: v for k, v in x.items()})
    return repr(x)


class Side:
    def __init__(self, cls, kw, case, world_w, rc, mode='L0'):
        self.s = cls(deepcopy(case), raw_capacity=rc, **kw)
        self.mode = mode
        self.world_w = world_w
        self.tokens = {}            # issuance -> token
        self.last_cert = {}         # target -> handle from the caller's last certified verdict
        self.pub_handles = {}       # target -> list of handles the caller saw published
        self.closed = False

    def obs(self):
        s = self.s
        if self.closed:
            return dict(occupied=s.occupied, raw=s.raw_size, certs=s.certificate_count)
        live = sorted(self.tokens)
        return dict(observe=typed(s.observe()), published=typed(s.published), confirmed=typed(s.confirmed),
                    tasks=[typed(s.task(self.tokens[k])) for k in live], occupied=s.occupied, raw=s.raw_size,
                    certs=s.certificate_count)


def apply_op(side, op, bound_kind=None):
    s = side.s
    k = op[0]
    if k == 'acquire':
        tk = s.acquire(op[1], required=op[2])
        if tk is not None:
            side.tokens[tk.issuance] = tk
        return _v(tk)
    if k in ('exit', 'finish', 'consume', 'cancel'):
        live = sorted(side.tokens)
        if not live:
            return 'no_token'
        tk = side.tokens[live[op[1] % len(live)]]
        if k == 'cancel':
            r = s.cancel(tk)
        elif k == 'consume':
            r = s.consume(tk)
        else:
            task = s._tasks.get(tk)
            item = task['item'] if task else 0
            r = s.finish(tk, Witness(**side.world_w[item]))
            if k == 'exit' and r == 'completed':
                r = (r, s.consume(tk))
        if tk not in s._tasks:
            side.tokens.pop(tk.issuance, None)
        return _v(r)
    if k == 'certify':
        v = s.certify(op[1], mode=side.mode)
        if v.get('certificate') is not None:
            side.last_cert[op[1]] = v['certificate']
        return _v({kk: vv for kk, vv in v.items()})
    if k == 'certpub':
        v = s.certify(op[1], mode=side.mode)
        if v.get('certificate') is None:
            return ('certify', _v(v))
        side.last_cert[op[1]] = v['certificate']
        r = s.publish(op[1], v['certificate'])
        if r == 'published':
            side.pub_handles.setdefault(op[1], []).append(v['certificate'])
        return ('certpub', _v(v), r)
    if k == 'publish':
        h = side.last_cert.get(op[1])
        if h is None:
            return 'no_handle'
        r = s.publish(op[1], h)
        if r == 'published':
            side.pub_handles.setdefault(op[1], []).append(h)
        return r
    if k == 'confirm':
        t, wiring = op[1], op[2]
        if bound_kind is None:
            return s.confirm(t)
        hs = side.pub_handles.get(t, [])
        if wiring == 'current':
            h = hs[-1] if hs else None
        elif wiring == 'stale':
            h = hs[-2] if len(hs) >= 2 else (hs[-1] if hs else None)
        else:
            h = None
        return s.confirm(t, h) if h is not None or wiring == 'none' else s.confirm(t, None)
    if k == 'edge':
        a, val = op[1], op[2]
        rec = None if val == 'remove' else dict(status='computed', score=val, version=op[3])
        return s.owner.apply(edge_updates={(a, a + 1): rec})
    if k == 'churn':
        a = deepcopy(s.owner._case['items'][op[1]]['analysis'])
        if a.get('status') != 'computed':
            return 'skip'
        a['version'] = a.get('version', 0) + op[2]
        return s.owner.apply(item_updates={op[1]: {'analysis': a}})
    if k == 'settings':
        return s.owner.apply(settings={'direction': op[1]})
    if k == 'rebind':
        case = s.observe()
        if op[1] is not None:
            i = op[1]
            case['items'][i]['content_version'] = case['items'][i].get('content_version', 0) + 1
            case['items'][i]['analysis'] = {'status': 'unknown'}
            case['edges'] = [e for e in case['edges'] if i not in (e['first'], e['second'])]
        s.rebind(case)
        side.last_cert.clear()
        return 'ok'
    raise ValueError(k)


def random_ops(rng, n, length, settings_changes=True):
    ops = []
    for _ in range(length):
        x = rng.random()
        if x < 0.08:
            ops.append(('certpub', rng.randrange(n)))
        elif x < 0.22:
            ops.append(('acquire', rng.randrange(n), rng.random() < 0.8))
        elif x < 0.40:
            ops.append(('exit', rng.randrange(8)))
        elif x < 0.43:
            ops.append(('finish', rng.randrange(8)))
        elif x < 0.46:
            ops.append(('consume', rng.randrange(8)))
        elif x < 0.50:
            ops.append(('cancel', rng.randrange(8)))
        elif x < 0.63:
            ops.append(('certify', rng.randrange(n)))
        elif x < 0.73:
            ops.append(('publish', rng.randrange(n)))
        elif x < 0.80:
            ops.append(('confirm', rng.randrange(n), rng.choice(('current', 'current', 'stale', 'none'))))
        elif x < 0.86:
            ops.append(('edge', rng.randrange(n - 1), rng.choice((None, 0, 2, 9, 'remove')), rng.randrange(9)))
        elif x < 0.92:
            ops.append(('churn', rng.randrange(n), rng.randrange(1, 9)))
        elif x < 0.95 and settings_changes:
            ops.append(('settings', rng.choice(('AB', 'BA'))))
        else:
            ops.append(('rebind', rng.choice((None, rng.randrange(n)))))
    return ops


def random_ops_expiry(rng, n, length, settings_changes=True):
    """Expiry-heavy stream on three targets: publish / support churn / republish / callbacks."""
    ts = rng.sample(range(n), 3)
    ops = []
    for _ in range(length):
        x = rng.random()
        t = rng.choice(ts)
        if x < 0.25:
            ops.append(('certpub', t))
        elif x < 0.45:
            ops.append(('confirm', t, rng.choice(('current', 'stale', 'stale', 'none'))))
        elif x < 0.60:
            ops.append(('churn', min(n - 1, max(0, t + rng.randrange(-2, 3))), rng.randrange(1, 9)))
        elif x < 0.70:
            a = min(n - 2, max(0, t + rng.randrange(-2, 3)))
            ops.append(('edge', a, rng.choice((None, 0, 2, 9, 'remove')), rng.randrange(9)))
        elif x < 0.80:
            ops.append(('acquire', min(n - 1, max(0, t + rng.randrange(-2, 3))), True))
        elif x < 0.90:
            ops.append(('exit', rng.randrange(8)))
        elif x < 0.94 and settings_changes:
            ops.append(('settings', rng.choice(('AB', 'BA'))))
        else:
            ops.append(('rebind', rng.choice((None, rng.randrange(n)))))
    return ops


def harness_close(side):
    s = side.s
    for tk in list(s._tasks):
        s.cancel(tk)
    for tk in list(s._tasks):
        if s._tasks.get(tk, {}).get('phase') == 'running':
            s.finish(tk, Witness(**side.world_w[s._tasks[tk]['item']]))
    s.owner.close()
    s._raw.clear(); s._certs.clear(); s._published.clear(); s._confirmed.clear(); s._published_handles.clear()
    if callable(getattr(s, 'close', None)):
        s.close()
    side.closed = True
    side.tokens.clear()


FAMS = (lambda sd: W.w01_phase_chain(sd, n=16, count=8), lambda sd: W.w05_raw_eviction(sd, n=16),
        lambda sd: W.random_partial(sd, n=16), lambda sd: W.w06_complete_analysis_ambiguous(sd, n=10))


def compare_pair(name, traces=300, length=60, seed0=0, focus='mixed', rc_fixed=None):
    rcls, rkw, ccls, ckw = PAIRS[name]
    bound = 'bound' if name == 'bound_confirm' else None
    diff = Counter()
    pairs = Counter()
    first = {}
    by_op = Counter()
    metric_diff = Counter()
    coverage = Counter()
    events = 0
    traces_with_diff = 0
    for k in range(traces):
        rng = random.Random(seed0 * 100003 + k)
        tr = FAMS[k % len(FAMS)](k)
        n = len(tr['initial']['items'])
        rc = rng.choice((1, 2, 3)) if name in ('control', 'derive_first') else 3
        if rc_fixed is not None:
            rc = rc_fixed
        mode = 'S' if name == 'inc_revoke_strong' else 'L0'
        R = Side(rcls, rkw, tr['initial'], tr['world'], rc, mode)
        C = Side(ccls, ckw, tr['initial'], tr['world'], rc, mode)
        gen = random_ops_expiry if focus == 'expiry' else random_ops
        ops = gen(rng, n, length, settings_changes=name.startswith('inc_revoke'))
        had = False
        for j, op in enumerate(ops):
            try:
                rr = apply_op(R, op)
            except Exception as e:  # noqa: BLE001
                rr = 'EXC:' + type(e).__name__
            try:
                cr = apply_op(C, op, bound_kind=bound)
            except Exception as e:  # noqa: BLE001
                cr = 'EXC:' + type(e).__name__
            events += 1
            coverage['op:' + op[0]] += 1
            if op[0] in ('certpub', 'publish') and (rr == 'published' or (isinstance(rr, tuple) and rr[-1] == 'published')):
                coverage['reference_publications'] += 1
            if op[0] == 'settings' and rr is True:
                coverage['effective_settings_changes'] += 1
            if rr == 'confirmed':
                coverage['reference_confirmations'] += 1
            if rr != cr:
                key = ('return', op[0] + ('/' + op[2] if op[0] == 'confirm' else ''))
                diff[key] += 1; by_op[op[0]] += 1; had = True
                if op[0] in ('confirm', 'publish'):
                    pairs['%s:%s->%s' % (key[1], rr, cr)] += 1
                first.setdefault(key, dict(trace=k, step=j, op=op, reference=rr, candidate=cr))
            before = len(R.s._published_handles)
            ro, co = R.obs(), C.obs()
            if op[0] != 'rebind':        # publications expired by this event (lazy expiry runs inside obs)
                coverage['reference_expiries'] += max(0, before - len(R.s._published_handles))
            for f in ro:
                if ro[f] != co.get(f):
                    diff[('observation', f)] += 1; had = True
                    first.setdefault(('observation', f), dict(trace=k, step=j, op=op))
        harness_close(R); harness_close(C)
        ro, co = R.obs(), C.obs()
        for f in ro:
            if ro[f] != co.get(f):
                diff[('after_close', f)] += 1; had = True
        for m in set(R.s.metrics) | set(C.s.metrics):
            if R.s.metrics.get(m, 0) != C.s.metrics.get(m, 0):
                metric_diff[m] += 1
        traces_with_diff += had
    return dict(pair=name, focus=focus, raw_capacity=rc_fixed or 'random 1-3', reference=rcls.__name__, candidate=ccls.__name__ + str(ckw or ''), traces=traces,
                events_per_trace=length, events=events, traces_with_difference=traces_with_diff,
                differences={'%s:%s' % k: v for k, v in sorted(diff.items())},
                return_pairs=dict(sorted(pairs.items())),
                first_examples={'%s:%s' % k: v for k, v in first.items()},
                cost_counter_differences_traces=dict(sorted(metric_diff.items())),
                coverage=dict(sorted(coverage.items())), closes=traces)
