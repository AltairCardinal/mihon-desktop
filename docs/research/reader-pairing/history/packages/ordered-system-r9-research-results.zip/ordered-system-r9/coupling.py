"""Serial acquisition-to-publication experiment using explicit virtual units.

The controller never receives World. Python privacy is an API convention,
not a security boundary against a malicious participant in this process.
"""
from collections import Counter, OrderedDict
from copy import deepcopy
from dataclasses import dataclass
from itertools import count

import compact_core as core
from corrected_owner import Owner, SAT
from current_baseline import typed

_OWNERS = count()


@dataclass(frozen=True)
class Witness:
    analysis: dict
    raw: object = None
    available: bool = True


class World:
    """Harness-only latent service data. Never passed to the controller."""
    def __init__(self, witnesses):
        self.__values = deepcopy(witnesses)

    def complete(self, ordinal):
        return deepcopy(self.__values[ordinal])


@dataclass(frozen=True)
class TaskKey:
    owner: object
    scope: object
    epoch: int
    version: object
    identity: object
    issuance: int


class Session:
    def __init__(self, case, *, capacity=3, raw_capacity=3, owner=None,
                 scope='default', version=1):
        if capacity < 1 or raw_capacity < 1:
            raise ValueError('positive capacity required')
        self.owner = Owner(case)
        self.capacity, self.raw_capacity = capacity, raw_capacity
        self.owner_id = next(_OWNERS) if owner is None else owner
        self._incarnation = next(_OWNERS)
        self.scope, self.version, self.epoch = deepcopy(scope), deepcopy(version), 0
        self._tasks = OrderedDict()
        self._raw = OrderedDict()
        self._certs, self._published, self._confirmed = {}, {}, {}
        self._next_certificate = 0
        self._next_issuance = 0
        self._published_handles = {}
        self.metrics = Counter()

    @property
    def occupied(self): return len(self._tasks)

    @property
    def raw_size(self): return len(self._raw)

    @property
    def certificate_count(self): return len(self._certs)

    @property
    def published(self):
        self._expire_publications()
        return deepcopy(self._published)

    @property
    def confirmed(self):
        self._expire_publications()
        return deepcopy(self._confirmed)

    def observe(self):
        """Only admitted scalar evidence; raw service truth is absent."""
        return self.owner.snapshot()

    def _token(self, i):
        if type(i) is not int or not 0 <= i < len(self.owner._case['items']):
            raise ValueError('invalid item ordinal')
        return TaskKey(typed((self.owner_id, self._incarnation)), typed(self.scope), self.epoch,
                       typed(self.version), typed(self.owner._identities[i]), -1)

    @staticmethod
    def _physical(key):
        return key.owner, key.scope, key.epoch, key.version, key.identity

    def task(self, token):
        value = self._tasks.get(token)
        return deepcopy({k: v for k, v in value.items() if k != 'result'}) if value is not None else None

    def acquire(self, i, *, required=True):
        template = self._token(i)
        self.metrics['acquisition_requests'] += 1
        for token, value in self._tasks.items():
            if self._physical(token) != self._physical(template): continue
            if required and not value['required'] and not value['cancelled']:
                value['required'] = True
                self.metrics['required_promotions'] += 1
            return token
        if len(self._tasks) >= self.capacity:
            self.metrics['admission_refusals'] += 1
            return None
        self._next_issuance += 1
        token = TaskKey(template.owner, template.scope, template.epoch,
                        template.version, template.identity, self._next_issuance)
        self._tasks[token] = dict(item=i, required=required, cancelled=False,
                                  phase='running', result=None)
        self.metrics['physical_admissions'] += 1
        self.metrics['peak_occupied'] = max(self.metrics['peak_occupied'], self.occupied)
        return token

    def cancel(self, token):
        task = self._tasks.get(token)
        if task is None: return 'absent'
        if task['phase'] == 'completed':
            del self._tasks[token]
            return 'discarded'
        task['cancelled'] = True
        return 'cancelling'

    def cancel_item(self, i):
        template = self._token(i)
        for token in self._tasks:
            if self._physical(token) == self._physical(template): return self.cancel(token)
        return 'absent'

    def _current(self, token, task):
        if (token.owner != typed((self.owner_id, self._incarnation)) or token.scope != typed(self.scope)
                or token.epoch != self.epoch or token.version != typed(self.version)):
            return False
        i = task['item']
        return (0 <= i < len(self.owner._case['items'])
                and token.identity == typed(self.owner._identities[i]))

    def finish(self, token, result):
        task = self._tasks.get(token)
        if task is None: return 'absent'
        if task['phase'] != 'running': return 'already_completed'
        self.metrics['physical_finishes'] += 1
        if task['cancelled'] or not self._current(token, task):
            del self._tasks[token]
            self.metrics['discarded_completions'] += 1
            return 'discarded'
        if not isinstance(result, Witness): raise ValueError('witness required')
        task['result'] = deepcopy(result)
        task['phase'] = 'completed'
        return 'completed'

    def consume(self, token):
        task = self._tasks.get(token)
        if task is None or task['phase'] != 'completed': return 'unavailable'
        del self._tasks[token]  # physical task now relinquishes its permit
        if task['cancelled'] or not self._current(token, task): return 'discarded'
        i, result = task['item'], task['result']
        a = result.analysis
        if a.get('status') not in ('computed', 'failed'):
            raise ValueError('service must report computed or failed')
        self.owner.apply(item_updates={i: {'analysis': a}})
        self.metrics['accepted_analyses'] += 1
        self._raw.pop(i, None)
        if a['status'] == 'computed' and result.available:
            # One extracted witness is reused for both adjacent channels.
            self._raw.pop(i, None)
            self._raw[i] = dict(value=deepcopy(result.raw), identity=token.identity,
                                analysis=typed(core.Index(self.owner._case, check_ids=False).analysis(i)),
                                version=typed(self.version))
            self.metrics['raw_insertions'] += 1
            while len(self._raw) > self.raw_capacity:
                self._raw.popitem(last=False)
                self.metrics['raw_evictions'] += 1
            updates = {}
            for first, second in ((i - 1, i), (i, i + 1)):
                if not self._raw_current(first) or not self._raw_current(second): continue
                left, right = self._raw[first]['value'], self._raw[second]['value']
                score = None if left is None or right is None else abs(left - right)
                updates[first, second] = dict(status='computed', score=score, version=self.version)
                self.metrics['rank_computations'] += 1
            if updates: self.owner.apply(edge_updates=updates)
        return 'accepted'

    def _raw_current(self, i):
        value = self._raw.get(i)
        if value is None: return False
        self.metrics['raw_identity_checks'] += 1
        valid = (value['identity'] == typed(self.owner._identities[i])
                 and value['version'] == typed(self.version)
                 and value['analysis'] == typed(core.Index(self.owner._case, check_ids=False).analysis(i)))
        if not valid:
            del self._raw[i]
            self.metrics['raw_invalidations'] += 1
        return valid

    def rebind(self, case, *, scope=None, version=None):
        self.epoch += 1
        if scope is not None: self.scope = deepcopy(scope)
        if version is not None: self.version = deepcopy(version)
        self.owner.rebind(case)
        # Logical cancellation cannot free a running physical task.
        for token, task in list(self._tasks.items()):
            if task['phase'] == 'completed': del self._tasks[token]
            else: task['cancelled'] = True
        self._raw.clear(); self._certs.clear()
        self._published.clear(); self._confirmed.clear()
        self._published_handles.clear()

    def certify(self, target, *, mode='L0', budget=None):
        """L0 = frozen 2/3 decision with corrected union memo.

        L1 = toy exact prefix-start attempt, not a strong summary algorithm.
        Budget limits acceptance of scan work, not physical preemption.
        """
        if mode not in ('L0', 'L1'): raise ValueError('unknown mode')
        if type(target) is not int or not 0 <= target < len(self.owner._case['items']):
            raise ValueError('invalid target')
        index = self.owner._index()
        if mode == 'L0':
            before = self.owner.metrics['scan_steps']
            result = self.owner.request(target)
            steps = self.owner.metrics['scan_steps'] - before
            entry = self.owner._memo.get(target)
            if entry is not None:
                support = dict(entry['support'])
            else:
                baseline = core.certify(self.owner._case, target, 2, index=index)
                attempts = [baseline]
                if baseline['status'] == 'need_facts':
                    attempts.append(core.certify(self.owner._case, target, 3, index=index))
                support = dict(pair for a in attempts for pair in a['proof'][2])
                steps += sum(a['steps'] for a in attempts)
        else:
            answer = core.certify(self.owner._case, target, target, index=index)
            support, steps = dict(answer['proof'][2]), answer['steps']
            result = {k: deepcopy(v) for k, v in answer.items() if k != 'proof'}
        self.metrics['certification_calls'] += 1
        self.metrics['certification_steps'] += steps
        self.metrics['certificate_support_keys'] += len(support)
        if budget is not None and steps > budget:
            self.metrics['budget_refusals'] += 1
            return dict(status='budget', unit=None, needs=result['needs'], failures=result['failures'])
        if result['status'] == 'certified':
            self._next_certificate += 1
            handle = self._next_certificate
            self._certs[handle] = dict(target=target, unit=deepcopy(result['unit']),
                                      guard=self.owner._guard(), epoch=self.epoch,
                                      support=support)
            result['certificate'] = handle
        return result

    def _certificate_current(self, cert):
        if cert['epoch'] != self.epoch or cert['guard'] != self.owner._guard(): return False
        index = self.owner._index()
        for key, old in cert['support'].items():
            self.metrics['publication_read_checks'] += 1
            if typed(old) != typed(self.owner._read(index, key)): return False
        return True

    def publish(self, target, handle):
        cert = self._certs.get(handle)
        if cert is None: return 'unsigned'
        if target != cert['target']: return 'wrong_target'
        if not self._certificate_current(cert): return 'stale'
        unit = cert['unit']
        members = {s['item'] for s in unit['slots']}
        if target not in members: return 'wrong_membership'
        self._expire_publications()
        for existing in self._published.values():
            if members & {s['item'] for s in existing['slots']} and typed(existing) != typed(unit):
                return 'conflict'
        self._published[target] = deepcopy(unit)
        self._published_handles[target] = handle
        self.metrics['publications'] += 1
        return 'published'

    def confirm(self, target):
        if target not in self._published: return 'unpublished'
        cert = self._certs[self._published_handles[target]]
        if not self._certificate_current(cert):
            self._expire_publications()
            return 'stale'
        self._confirmed[target] = deepcopy(self._published[target])
        self.metrics['confirmations'] += 1
        return 'confirmed'

    def _expire_publications(self):
        for target, handle in list(self._published_handles.items()):
            cert = self._certs.get(handle)
            if cert is None or not self._certificate_current(cert):
                self._published_handles.pop(target, None)
                self._published.pop(target, None)
                self._confirmed.pop(target, None)


class Controller:
    """Small toy candidate. Its complete interface contains no latent world."""
    def __init__(self, session, mode):
        self.session, self.mode, self.target = session, mode, None

    def drive(self):
        if self.target is None: return
        result = self.session.certify(self.target, mode=self.mode)
        if result['status'] == 'certified':
            self.session.publish(self.target, result['certificate'])
        else:
            for need in result['needs']:
                self.session.acquire(need['item'])
                if 'second' in need: self.session.acquire(need['second'])


def run_trace(trace, *, mode='L0', service_units=1, capacity=3, raw_capacity=3):
    """Same exogenous event stream, endogenous candidate requests, virtual time.

    Equal-time external events retain list order. At each event time, due
    completions run first in (due, admission-order) order. Zero service is
    rejected so recursive drive cannot create an infinite zero-time loop.
    """
    if type(service_units) is not int or service_units <= 0:
        raise ValueError('positive integer virtual service units required')
    world = World([Witness(**w) for w in trace['world']])
    session = Session(trace['initial'], capacity=capacity, raw_capacity=raw_capacity)
    controller = Controller(session, mode)
    pending, scheduled, logs = {}, set(), []
    now, serial = 0, 0

    def schedule():
        nonlocal serial
        for token, task in session._tasks.items():
            if token not in scheduled and task['phase'] == 'running':
                scheduled.add(token)
                pending[token] = (now + service_units, serial, task['item'], world)
                serial += 1

    def drain(until):
        nonlocal now
        while pending:
            token, record = min(pending.items(), key=lambda pair: pair[1][:2])
            due, _, i, service_world = record
            if due > until: break
            now = due
            del pending[token]
            session.finish(token, service_world.complete(i))
            session.consume(token)
            # A new physical task may have the same immutable identity after
            # consumption; scheduling membership tracks live tasks, not history.
            scheduled.discard(token)
            controller.drive()
            schedule()
        now = until

    for event in trace['events']:
        at = event['at']
        if type(at) is not int or at < now: raise ValueError('nonmonotone time')
        drain(at)
        op = event['op']
        if op == 'target':
            controller.target = event['target']; controller.drive()
        elif op == 'prefetch': session.acquire(event['item'], required=False)
        elif op == 'cancel':
            session.cancel_item(event['item'])
        elif op == 'confirm': session.confirm(event['target'])
        elif op != 'tick': raise ValueError('unknown event')
        schedule()
        logs.append(dict(at=at, op=op, occupied=session.occupied,
                         raw=session.raw_size, published=deepcopy(session._published)))
    return dict(mode=mode, virtual_time=now, service_units=service_units,
                published={str(k): v for k, v in session.published.items()},
                confirmed={str(k): v for k, v in session.confirmed.items()},
                metrics=dict(session.metrics), owner_metrics=dict(session.owner.metrics), events=logs)
