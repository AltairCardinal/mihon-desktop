"""Current executable checks; all service work uses virtual units."""
import argparse
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import random

from corrected_owner import Owner, Config
from coupling import Session, run_trace
import reference as ref

ROOT = Path(__file__).resolve().parent


def selected(case, target):
    return {k: v for k, v in ref.certify_strategy(case, target)['selected'].items() if k != 'reads'}


def delta(owner, case):
    owner.apply(item_updates=dict(enumerate(case['items'])),
                edge_updates={(e['first'], e['second']): e for e in case['edges']})


def smoke(seed=905):
    counterexamples = []
    for name in ('c5_retry_support_cex.json', 'c5_adopted_variant_cex.json'):
        fixture = json.loads((ROOT / 'fixtures' / name).read_text(encoding='utf-8'))
        profiles = []
        for memo in (True, False):
            owner = Owner(fixture['case'], Config(memo=memo))
            owner.request(fixture['target'])
            delta(owner, fixture['changed'])
            assert owner.request(fixture['target']) == selected(fixture['changed'], fixture['target'])
            profiles.append(dict(memo=memo, metrics=dict(owner.metrics)))
        counterexamples.append(dict(fixture=name, profiles=profiles))
    trace = json.loads((ROOT / 'fixtures' / 'coupled-smoke.json').read_text(encoding='utf-8'))
    profiles = []
    for units in (1, 3):
        modes = [run_trace(trace, mode=mode, service_units=units) for mode in ('L0', 'L1')]
        assert modes[0]['published'] == modes[1]['published']
        assert modes[0]['confirmed'] == modes[1]['confirmed']
        assert '1' in modes[0]['published']
        profiles.append(dict(service_units=units, modes=modes))
    extra = json.loads((ROOT / 'fixtures' / 'prefix-extra.json').read_text(encoding='utf-8'))
    session = Session(extra['case'])
    l0, l1 = session.certify(extra['target'], mode='L0'), session.certify(extra['target'], mode='L1')
    assert l0['status'] == 'need_facts' and l1['status'] == 'certified'
    # Seeded delta differential is separate from the fixed service trace.
    rng = random.Random(seed)
    case = deepcopy(trace['initial'])
    owner = Owner(case)
    checks = 0
    for step in range(80):
        i = rng.randrange(len(case['items']))
        if rng.random() < .7:
            a = dict(status='computed', fact=deepcopy(trace['world'][i]['analysis']['fact']), version=step + 1)
        else:
            a = rng.choice([dict(status='unknown'), dict(status='failed', reason='RESOURCE')])
        case['items'][i]['analysis'] = a
        owner.apply(item_updates={i: {'analysis': a}})
        for target in range(len(case['items'])):
            assert owner.request(target) == selected(case, target)
            checks += 1
    return dict(schema='model-smoke-v1', seed=seed, status='pass',
                seeded_delta_checks=checks, counterexamples=counterexamples,
                coupled_profiles=profiles,
                extra_observation=dict(L0=l0['status'], L1=l1['status'],
                                       caveat='L1 is a toy prefix-start candidate'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=905)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    output = json.dumps(smoke(args.seed), indent=2) + '\n'
    if args.out: args.out.write_text(output, encoding='utf-8')
    else: print(output, end='')
