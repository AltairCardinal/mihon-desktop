"""Neutral serial virtual host; operation counts are not native cost estimates."""
from collections import Counter, OrderedDict
from copy import deepcopy
from dataclasses import dataclass
import reference as ref
import compact_core as core


def typed(value):
    """Exact structural comparison, including null/status/numeric type tags."""
    if isinstance(value, dict):
        return ('dict', tuple(sorted((typed(k), typed(v)) for k, v in value.items())))
    if isinstance(value, (tuple, list)):
        return (type(value).__name__, tuple(typed(v) for v in value))
    return (type(value).__name__, value)


@dataclass(frozen=True)
class Config:
    shared_input_index: bool
    compact_proof: bool
    change_stamps: bool
    bounded_memo: bool
    memo_capacity: int
    max_order: int
    max_reads: int

    @classmethod
    def current(cls):
        return cls(True, True, True, True, 4, 4096, 4096)

    @classmethod
    def strict(cls):
        return cls(False, False, False, True, 4, 4096, 4096)

    @classmethod
    def cold(cls):
        return cls(False, False, False, False, 4, 4096, 4096)


def public(result):
    return {k: deepcopy(v) for k, v in result.items() if k not in ('proof', 'reads')}


class Host:
    """Owned snapshots; dynamic evidence never remains cached in an index.

    Global identity/settings/location guards are always enabled. No branching,
    refinement or scoped-identity relaxation is implemented.
    """
    def __init__(self, case, *, config):
        if config.memo_capacity < 1 or min(config.max_order, config.max_reads) < 0:
            raise ValueError('invalid storage bound')
        self.config = config
        self.metrics = Counter()
        self._memo = OrderedDict()
        self._structure = None
        self._revision = 0
        self._binding = 0
        self._closed = False
        self._location = (None, 0)
        self._case = None
        self.replace(case)

    @property
    def memo_size(self):
        return len(self._memo)

    def snapshot(self):
        return deepcopy(self._case)

    def _index(self):
        reuse = self.config.shared_input_index and self._structure is not None
        index = core.Index(self._case, check_ids=not reuse)
        self.metrics['index_views'] += 1
        if not reuse:
            self._structure = {i: index.ident(i) for i in range(index.n)}
            self.metrics['input_index_builds'] += 1
            self.metrics['identity_slots_built'] += len(self._structure)
        index._ident = self._structure
        return index

    def replace(self, case):
        if self._closed:
            raise ValueError('closed host requires rebind')
        next_case = deepcopy(case)
        data = ref._Input(next_case)
        identity = typed(data.identity)
        settings = typed(data.settings)
        if self._case is None or typed(self._case) != typed(next_case):
            self._revision = min(self._revision + 1, (1 << 63) - 1)
            self.metrics['evidence_updates'] += 1
        if getattr(self, '_identity', None) != identity:
            self._structure = None
        self._case, self._identity, self._settings = next_case, identity, settings
        self.metrics['update_calls'] += 1
        self.metrics['update_item_slots'] += len(next_case['items'])

    def locate(self, item_id, sequence):
        self._location = (item_id, sequence)

    def _guard(self):
        return (self._binding, self._identity, self._settings, self._location)

    def _stamp(self):
        return (self._binding, self._revision)

    def _valid(self, entry, index):
        if self._case.get('closed', False) or entry['guard'] != self._guard():
            return False
        if (self.config.change_stamps and self._revision < (1 << 63) - 1
                and entry['stamp'] == self._stamp()):
            self.metrics['stamp_hits'] += 1
            return True
        self.metrics['read_validations'] += 1
        if self.config.compact_proof:
            for key, old in entry['result']['proof'][2]:
                kind = key[0]
                if kind == 'analysis':
                    now = index.analysis(key[1])
                elif kind == 'header':
                    now = index.header(key[1])
                elif kind == 'dimension':
                    fact = index.effective(key[1])
                    now = fact[:5] + ('UNKNOWN',) if fact else None
                else:
                    now = index.edge(key[1], key[2])
                self.metrics['typed_reads_checked'] += 1
                if typed(old) != typed(now):
                    return False
        else:
            data = ref._Input(self._case)
            for key, old in entry['result']['reads'].items():
                parts = key.split(':')
                if key == 'identity':
                    now = data.identity
                elif key == 'settings':
                    now = data.settings
                elif parts[0] == 'analysis':
                    now = data.analysis(int(parts[1]))
                elif parts[0] == 'header':
                    now = ref._fact(data.items[int(parts[1])].get('header'))
                elif parts[0] == 'dimension':
                    fact = data.effective(int(parts[1]))
                    now = dict(fact, side='UNKNOWN') if fact else None
                else:
                    now = data.edge(int(parts[1]), int(parts[2]))
                self.metrics['typed_reads_checked'] += 1
                if typed(old) != typed(now):
                    return False
        entry['stamp'] = self._stamp()
        return True

    def request(self, target):
        if self._closed:
            raise ValueError('closed host')
        self.metrics['requests'] += 1
        index = self._index() if self.config.compact_proof else None
        stored = self._memo.get(target)
        if stored is not None and self._valid(stored, index):
            self.metrics['memo_hits'] += 1
            return public(stored['result'])
        self.metrics['engine_runs'] += 1
        certify = (lambda window: core.certify(self._case, target, window, index=index)) if index else (
            lambda window: ref.certify(self._case, target, window))
        baseline = certify(2)
        selected = baseline
        total_steps = baseline['steps']
        if baseline['status'] == 'need_facts':
            retry = certify(3)
            self.metrics['confluence_retries'] += 1
            total_steps += retry['steps']
            if retry['status'] == 'certified':
                selected = retry
        self.metrics['scan_steps'] += total_steps
        size = len(selected['proof'][2]) + 2 if index else len(selected['reads'])
        if self.config.bounded_memo:
            if len(self._case['items']) > self.config.max_order or size > self.config.max_reads:
                self._memo.pop(target, None)
                self.metrics['oversized_bypasses'] += 1
            else:
                self._memo.pop(target, None)
                self._memo[target] = dict(guard=self._guard(), stamp=self._stamp(), result=selected)
                self.metrics['stored_read_keys'] += size
                while len(self._memo) > self.config.memo_capacity:
                    self._memo.popitem(last=False)
                    self.metrics['memo_evictions'] += 1
        return public(selected)

    def close(self):
        self._memo.clear()
        self._structure = None
        self._case = None
        self._closed = True
        self.metrics['closes'] += 1

    def rebind(self, case):
        self.close()
        self._binding += 1
        self._closed = False
        self._location = (None, 0)
        self.replace(case)
        self.metrics['rebinds'] += 1
