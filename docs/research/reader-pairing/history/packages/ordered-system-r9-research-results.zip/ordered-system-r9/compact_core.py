"""Compiled, copy-free equivalent of reference.certify (route A, same semantics).

Representation change only.  The decision rule is reference._Scan, reused
unchanged; the window loop below is the reference loop line by line.  What
changes:

* no deep copy of the case; positions are parsed lazily, once, into tuples;
* no typed deep-copied read snapshots; every read becomes a compact
  fingerprint (immutable tuple) keyed like the reference read keys;
* the proof carries the fingerprints, so validation is O(|reads|) and needs no
  input reconstruction (see proof.py).

Observable outputs that are compared with the reference by the differential
tests: status, unit, needs (same order), failures, first, steps,
dependent_items, and the set of read keys.  Errors raised for invalid input
are the reference's ValueError cases (direction, duplicate ids, target,
lookbehind, closed source, invalid analysis status on access).
"""
import reference as ref

_FACT_KEYS = ('state', 'width', 'height', 'rotation', 'orientation', 'side')
_MISSING = object()


def _reason(a):
    """The failure reason; a missing reason raises where the reference does."""
    if a[1] is _MISSING:
        raise KeyError('reason')
    return a[1]


def _fact_tuple(value):
    """reference._fact as an immutable tuple (or None)."""
    if value is None:
        return None
    return (value.get('state', 'UNKNOWN'), value.get('width', 0), value.get('height', 0),
            value.get('rotation', 0), value.get('orientation', 1), value.get('side', 'UNKNOWN'))


def _geometry_t(f):
    """reference._geometry on a fact tuple."""
    if f is None or f[1] <= 0 or f[2] <= 0:
        return False
    w, h = f[1], f[2]
    if f[3] in (90, 270):
        w, h = h, w
    return f[0] == ('WIDE' if w >= h else 'NARROW')


def _fact_dict(t):
    return dict(zip(_FACT_KEYS, t))


class Index:
    """Lazy, copy-free view of one case.  Parses each position at most once."""

    __slots__ = ('case', 'items', 'n', 'settings', 'context', '_ident', '_analysis',
                 '_header', '_edges', 'parsed')

    def __init__(self, case, check_ids=True):
        self.case = case
        self.items = case['items']
        self.n = len(self.items)
        s = case.get('settings', {})
        self.settings = dict(direction=s.get('direction', 'AB'), automatic=s.get('automatic', False),
                             hard_isolates=sorted(set(s.get('hard_isolates', []))),
                             pinned_links=sorted(set(s.get('pinned_links', []))),
                             opening=s.get('opening', 'AUTO'), revision=s.get('revision', 0))
        if self.settings['direction'] not in ('AB', 'BA'):
            raise ValueError('direction must be AB or BA')
        if check_ids:          # certify must raise like the reference; validation need not
            ids = set()
            for i, x in enumerate(self.items):
                ids.add(x.get('id', str(i)))
            if len(ids) != self.n:
                raise ValueError('item ids must be unique')
        self.context = (case.get('generation', 0), case.get('order_revision', 0), self.n,
                        _settings_key(self.settings))
        self._ident, self._analysis, self._header = {}, {}, {}
        self._edges = None
        if check_ids:
            # certify path: build the edge index eagerly so malformed edge
            # records raise at construction, exactly like reference._Input
            self._edge_index()
        self.parsed = 0          # positions parsed (work counter)

    # -- per position -------------------------------------------------------
    def ident(self, i):
        t = self._ident.get(i)
        if t is None:
            x = self.items[i]
            t = (x.get('id', str(i)), x.get('content_version', 0), x.get('rotation', 0),
                 x.get('orientation', 1))
            self._ident[i] = t
            self.parsed += 1
        return t

    def analysis(self, i):
        """('computed', fact_tuple, version) | ('failed', reason) | ('unknown',)."""
        t = self._analysis.get(i)
        if t is None:
            a = self.items[i].get('analysis', ref.UNKNOWN)
            st = a['status']
            if st == 'computed':
                t = ('computed', _fact_tuple(a['fact']), a.get('version', 1))
            elif st == 'failed':
                t = ('failed', a.get('reason', _MISSING))   # KeyError deferred to use, as in the reference
            elif st == 'unknown':
                t = ('unknown',)
            else:
                raise ValueError('invalid analysis status')
            self._analysis[i] = t
        return t

    def header(self, i):
        if i not in self._header:
            self._header[i] = _fact_tuple(self.items[i].get('header'))
        return self._header[i]

    def effective(self, i):
        a = self.analysis(i)
        return a[1] if a[0] == 'computed' else self.header(i)

    def edge(self, a, b):
        """Derived edge evidence exactly as reference._Input.edge, as a tuple:
        ('unknown',) | ('computed', score, version) | ('failed', failures_tuple)
        | (other_status, ...).  The content identities of both endpoints are
        covered by the position identities of the proof."""
        aa, bb = self.analysis(a), self.analysis(b)
        if b != a + 1 or aa[0] != 'computed' or bb[0] != 'computed':
            return ('unknown',)
        if (aa[1] is not None and aa[1][0] == 'WIDE') or (bb[1] is not None and bb[1][0] == 'WIDE'):
            return ('computed', None, 1)
        e = self._edge_index().get((a, b))
        if e is None:
            return ('unknown',)
        st = e['status']
        if st == 'computed':
            return ('computed', e.get('score', None), e.get('version', 1))
        if st == 'unknown':
            return ('unknown',)
        if st == 'failed':
            # iteration order kept: the reference merges failures in this order
            return ('failed', tuple((str(k), v) for k, v in e.get('failures', {}).items()))
        return (st, tuple(sorted((k, repr(v)) for k, v in e.items() if k not in ('first', 'second'))))


def _edge_index_of(self):
    if self._edges is None:
        self._edges = {}
        for e in self.case.get('edges', []):
            self._edges[(e['first'], e['second'])] = e
    return self._edges


Index._edge_index = _edge_index_of


def _settings_key(s):
    return (s['direction'], s['automatic'], tuple(s['hard_isolates']), tuple(s['pinned_links']),
            s['opening'], s['revision'])


def certify(case, target, lookbehind=2, index=None):
    """Same results as reference.certify; proof replaces the typed reads."""
    data = index if index is not None else Index(case)
    n = data.n
    if not 0 <= target < n or lookbehind < 0 or case.get('closed', False):
        raise ValueError('invalid target, lookbehind, or closed evidence source')
    reads = {}                    # read key -> fingerprint (insertion ordered)
    needs, failures, dimensions, analyses, edges = {}, {}, {}, {}, {}

    def analysis(i):
        a = data.analysis(i)
        reads[('analysis', i)] = a
        return a

    def dimension(i):
        if not 0 <= i < n:
            return None
        a = analysis(i)
        if a[0] == 'computed':
            f = a[1]
        else:
            f = data.header(i)
            reads[('header', i)] = f
        normalized = (f[:5] + ('UNKNOWN',)) if f else None
        reads[('dimension', i)] = normalized
        item = data.ident(i)
        if not _geometry_t(f) or f[3] != item[2] or f[4] != item[3]:
            if a[0] == 'failed':
                failures[str(i)] = _reason(a)
            elif f and f[0] == 'FAILED':
                failures[str(i)] = 'READ'
            needs[(i, 'DIMENSIONS')] = dict(item=i, kind='DIMENSIONS')
            return None
        dimensions[i] = normalized
        return _fact_dict(f)

    def side(i):
        a = analysis(i)
        if a[0] == 'computed':
            analyses[i] = a
            return a[1][5]
        if a[0] == 'failed':
            failures[str(i)] = _reason(a)
        needs[(i, 'ANALYSIS')] = dict(item=i, kind='ANALYSIS')
        return 'UNKNOWN'

    def resolved(i):
        a = analysis(i)
        if a[0] == 'computed':
            analyses[i] = a
            return a[1][5]
        return None

    def rank(a, b):
        e = data.edge(a, b)
        reads[('rank', a, b)] = e
        if e[0] == 'computed':
            edges[a, b] = e
            return e[1]
        if e[0] == 'failed':
            failures.update({str(k): v for k, v in e[1]})
        needs[(a, 'RANK', b)] = dict(item=a, kind='RANK', second=b)
        return None

    scan = ref._Scan(n, data.settings, dimension, side, resolved, rank)
    memo, steps = {}, 0

    def target_unit(cursor):
        nonlocal steps
        path, result = [], None
        while cursor[0] <= target:
            i, opening, reserved = cursor
            key = (i, opening, reserved == i)
            if key in memo:
                result = memo[key]
                break
            path.append(key)
            unit, cursor = scan.step((i, opening, i if key[2] else -1),
                                     include_single=i == target, include_pair=i + 1 >= target)
            steps += 1
            if unit is not None and any(s['item'] == target for s in unit['slots']):
                result = unit
                break
        for key in path:
            memo[key] = result
        return result

    def output(first, unit=None):
        deps = set(dimensions) | set(analyses)
        for a, b in edges:
            deps.update((a, b))
        if unit is None:
            for need in needs.values():
                deps.add(need['item'])
                if 'second' in need:
                    deps.add(need['second'])
        status = 'certified' if unit is not None else ('blocked' if failures else 'need_facts')
        return dict(status=status, unit=unit, needs=list(needs.values()), failures=dict(failures),
                    first=first, steps=steps, dependent_items=sorted(deps),
                    proof=make_proof(data, reads, status))

    target_fact = dimension(target)
    if target_fact is None:
        return output(target)
    isolated = target_fact['state'] == 'WIDE' or target in scan.forced
    first = target if isolated else max(0, target - lookbehind)
    while True:
        if first == 0:
            entries = [(0, True, -1)]
        elif isolated:
            entries = [(first, True, -1), (first, False, -1)]
        else:
            entries = []
            boundary_free = first - 1 not in scan.forced and first not in scan.forced
            for opening in ([True] if first == 1 else [True, False]):
                entries.append((first, opening, -1))
                if first > 1 and boundary_free:
                    entries.append((first, opening, first))
            if boundary_free:
                entries.append((first + 1, False, -1))
        candidates = [target_unit(e) for e in entries]
        if failures or needs:
            return output(first)
        unit = candidates[0]
        if unit is not None and all(u == unit for u in candidates):
            return output(first, unit)
        if first > 0 and not scan.allowed(first - 1):
            if failures or needs:
                return output(first)
            normal = [target_unit((first, o, -1)) for o in (True, False)]
            if normal[0] is not None and normal[0] == normal[1]:
                return output(first, normal[0])
        if first <= 0:
            raise AssertionError('unique initial state must determine a unit')
        first -= 1


def make_proof(data, reads, status, mode='alpha'):
    """Compact proof: context, identities of read positions, read fingerprints.

    All proofs require exact typed evidence equality; no refinement is enabled."""
    positions = set()
    for key in reads:
        positions.add(key[1])
        if key[0] == 'rank':
            positions.add(key[2])
    return (data.context, tuple((p, data.ident(p)) for p in sorted(positions)),
            tuple(reads.items()), False, mode)


def read_keys(result):
    """Reference-vocabulary read keys of a fast result (for differential tests)."""
    out = set()
    for key, _ in result['proof'][2]:
        out.add(':'.join(str(x) for x in key))
    return out
