"""Independent mathematical incumbent for 50 packed four-channel feature values.

The high channel is coverage; three lower channels are bounded measurements.
This is a research operator, not a native bridge or a claim of new speed gain.
"""

COUNT = 50

def normalize(value):
    if not isinstance(value,int) or not 0 <= value <= 0xffffffff:
        raise ValueError('feature value must be an unsigned 32-bit integer')
    coverage = value >> 24
    return tuple((((value >> shift) & 255)*coverage + 255*(255-coverage)+127)//255
                 for shift in (16,8,0))

def _variance(features):
    values = [0.299*x[0]+0.587*x[1]+0.114*x[2] for x in features]
    mean = sum(values)/COUNT
    return sum(x*x for x in values)/COUNT - mean*mean

def score(first, second):
    if len(first) != COUNT or len(second) != COUNT:
        raise ValueError('exactly 50 feature values per witness required')
    left, right, total = [], [], 0
    for x,y in zip(first,second):
        a,b = normalize(x),normalize(y)
        left.append(a); right.append(b)
        total += sum(abs(u-v) for u,v in zip(a,b))
        if total >= 30*COUNT:
            return None  # nonnegative remaining terms cannot recover eligibility
    if all(sum(min(x)>220 for x in side) >= COUNT*0.8 for side in (left,right)):
        return None
    if all(sum(max(x)<50 for x in side) >= COUNT*0.8 for side in (left,right)):
        return None
    if _variance(left)<100 and _variance(right)<100:
        return None
    return float(total)/COUNT
