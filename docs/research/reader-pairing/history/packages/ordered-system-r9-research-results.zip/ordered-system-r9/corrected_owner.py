"""Owned evidence and exact union-support memo. Virtual work, not timing."""
from collections import Counter, OrderedDict
from copy import deepcopy
from dataclasses import dataclass

import compact_core as core
from current_baseline import typed

SAT = (1 << 63) - 1
_UNSET = object()
_IDENT = ('id', 'content_version', 'rotation', 'orientation')


@dataclass(frozen=True)
class Config:
    memo: bool = True
    stamps: bool = True
    shared_index: bool = True
    memo_capacity: int = 4
    max_order: int = 4096
    max_reads: int = 4096


def public(result):
    return deepcopy({k: v for k, v in result.items() if k != 'proof'})


class Owner:
    """Serial owner; only its atomic methods may change stored input.

    Complete replacement is an explicit O(n) boundary operation. Delta writes
    copy only changed records; ordinary requests never copy the full input.
    Identity changes invalidate globally, including unrelated positions.
    """
    def __init__(self, case, config=Config()):
        if config.memo_capacity < 1 or min(config.max_order, config.max_reads) < 0:
            raise ValueError('invalid bounds')
        self.config = config
        self.metrics = Counter()
        self._memo = OrderedDict()
        self._revision = self._identity_epoch = self._binding = 0
        self._location = (None, 0)
        self._closed = False
        self._case = None
        self._identity_ticket = object()
        self.replace(case)

    def _open(self):
        if self._closed:
            raise ValueError('closed owner')

    @property
    def memo_size(self):
        return len(self._memo)

    def snapshot(self):
        self._open()
        self.metrics['snapshot_item_slots'] += len(self._case['items'])
        return deepcopy(self._case)

    def replace(self, case):
        self._open()
        candidate = deepcopy(case)
        index = core.Index(candidate)
        identities = {i: index.ident(i) for i in range(index.n)}
        self._case = candidate
        self._ids = {x[0]: i for i, x in identities.items()}
        self._identities = identities
        self._edges = index._edge_index()
        self._edge_positions = {(e['first'], e['second']): p
                                for p, e in enumerate(candidate.get('edges', []))}
        self._case.setdefault('edges', [])
        self._settings = core._settings_key(index.settings)
        # Full replacement conservatively changes revision and identity guard.
        self._revision = min(SAT, self._revision + 1)
        self._identity_epoch = min(SAT, self._identity_epoch + 1)
        self._identity_ticket = object()
        self._memo.clear()
        self.metrics['boundary_item_slots'] += index.n
        self.metrics['boundary_edge_slots'] += len(self._edges)
        self.metrics['identity_slots_built'] += index.n
        self.metrics['replacements'] += 1

    def apply(self, *, item_updates=None, edge_updates=None, settings=None,
              generation=_UNSET, order_revision=_UNSET):
        """Atomically merge record fields; reject invalid batch before mutation.

        edge_updates maps (a,b) to an evidence record, or None to remove it.
        settings merges fields. Structural insert/delete/reorder uses replace.
        All supplied values become owned; no mutable caller aliases survive.
        """
        self._open()
        items, edges = {}, {}
        n = len(self._case['items'])
        for i, patch in (item_updates or {}).items():
            if type(i) is not int or not 0 <= i < n:
                raise ValueError('invalid item ordinal')
            item = dict(self._case['items'][i])
            item.update(deepcopy(patch))
            items[i] = item
        for key, value in (edge_updates or {}).items():
            if (len(key) != 2 or any(type(i) is not int for i in key)
                    or not 0 <= key[0] < key[1] < n):
                raise ValueError('invalid edge ordinals')
            edges[key] = dict(deepcopy(value), first=key[0], second=key[1]) if value is not None else None
        next_settings = dict(self._case.get('settings', {}))
        if settings is not None:
            next_settings.update(deepcopy(settings))
        # O(1) settings normalization; no whole-input validation on delta path.
        probe = core.Index({'items': [], 'settings': next_settings}, check_ids=False)
        settings_key = core._settings_key(probe.settings)
        identity_change = False
        staged_ids = {}
        removed_ids = {self._identities[i][0] for i in items}
        for i, x in items.items():
            ident = (x.get('id', str(i)), x.get('content_version', 0),
                     x.get('rotation', 0), x.get('orientation', 1))
            item_id = ident[0]
            if item_id in staged_ids or (item_id in self._ids and item_id not in removed_ids):
                raise ValueError('item ids must be unique')
            staged_ids[item_id] = i
            identity_change |= typed(ident) != typed(self._identities[i])
        changed_items = {i: x for i, x in items.items() if typed(x) != typed(self._case['items'][i])}
        changed_edges = {k: x for k, x in edges.items() if typed(x) != typed(self._edges.get(k))}
        global_change = any(v is not _UNSET and typed(v) != typed(self._case.get(k, 0))
                            for k, v in (('generation', generation), ('order_revision', order_revision)))
        changed_settings = typed(settings_key) != typed(self._settings)
        changed = bool(changed_items or changed_edges or global_change or changed_settings)
        # Commit starts here; all shape/identity checks above are side effect free.
        for item_id in removed_ids:
            del self._ids[item_id]
        self._ids.update(staged_ids)
        for i, x in changed_items.items():
            self._case['items'][i] = x
            self._identities[i] = (x.get('id', str(i)), x.get('content_version', 0),
                                   x.get('rotation', 0), x.get('orientation', 1))
        for key, value in changed_edges.items():
            if value is None:
                # Deletion is rare and explicitly charged as a structural list rebuild.
                self._case['edges'] = [e for e in self._case['edges']
                                       if (e['first'], e['second']) != key]
                self._edge_positions = {(e['first'], e['second']): p
                                        for p, e in enumerate(self._case['edges'])}
                self._edges.pop(key, None)
                self.metrics['edge_rebuild_slots'] += len(self._case['edges'])
            else:
                if key in self._edge_positions:
                    self._case['edges'][self._edge_positions[key]] = value
                else:
                    self._edge_positions[key] = len(self._case['edges'])
                    self._case['edges'].append(value)
                self._edges[key] = value
        if settings is not None:
            self._case['settings'] = next_settings
        self._settings = settings_key
        for k, v in (('generation', generation), ('order_revision', order_revision)):
            if v is not _UNSET:
                self._case[k] = deepcopy(v)
        if identity_change or global_change or changed_settings:
            self._identity_epoch = min(SAT, self._identity_epoch + 1)
            self._identity_ticket = object()
            self._memo.clear()  # required even when the identity epoch saturates
        if changed:
            self._revision = min(SAT, self._revision + 1)
        self.metrics['delta_calls'] += 1
        self.metrics['delta_item_slots'] += len(items)
        self.metrics['delta_edge_slots'] += len(edges)
        return changed

    def locate(self, item_id, sequence):
        self._open()
        self._location = typed((item_id, sequence))

    def _guard(self):
        return (self._binding, self._identity_epoch, self._identity_ticket,
                self._settings, self._location)

    def _index(self):
        index = core.Index(self._case, check_ids=False)
        if self.config.shared_index:
            index._ident = self._identities
            index._edges = self._edges
        else:
            self.metrics['identity_slots_built'] += index.n
            for i in range(index.n): index.ident(i)
        self.metrics['index_views'] += 1
        return index

    @staticmethod
    def _read(index, key):
        if key[0] == 'analysis': return index.analysis(key[1])
        if key[0] == 'header': return index.header(key[1])
        if key[0] == 'dimension':
            f = index.effective(key[1])
            return f[:5] + ('UNKNOWN',) if f else None
        return index.edge(key[1], key[2])

    def _valid(self, entry, index):
        if entry['guard'] != self._guard() or self._case.get('closed', False):
            return False
        if self.config.stamps and self._revision < SAT and entry['stamp'] == self._revision:
            self.metrics['stamp_hits'] += 1
            return True
        self.metrics['support_validations'] += 1
        for key, old in entry['support'].items():
            self.metrics['typed_reads_checked'] += 1
            if typed(old) != typed(self._read(index, key)):
                return False
        entry['stamp'] = self._revision  # successful fallback must refresh the stamp
        return True

    def request(self, target):
        self._open()
        if type(target) is not int or not 0 <= target < len(self._case['items']):
            raise ValueError('invalid target ordinal')
        self.metrics['requests'] += 1
        index = self._index()
        entry = self._memo.get(target)
        if entry and self._valid(entry, index):
            self.metrics['memo_hits'] += 1
            self._memo.move_to_end(target)
            return public(entry['result'])
        self.metrics['engine_runs'] += 1
        baseline = core.certify(self._case, target, 2, index=index)
        attempts, selected = [baseline], baseline
        if baseline['status'] == 'need_facts':
            retry = core.certify(self._case, target, 3, index=index)
            attempts.append(retry)
            self.metrics['retries'] += 1
            if retry['status'] == 'certified': selected = retry
        # Public fields remain selected-attempt fields. Memo validity covers
        # every attempt that affected the strategy's adoption decision.
        support = {}
        for attempt in attempts:
            support.update(attempt['proof'][2])
        self.metrics['scan_steps'] += sum(a['steps'] for a in attempts)
        self.metrics['support_keys_built'] += len(support)
        self._memo.pop(target, None)
        if (self.config.memo and len(self._case['items']) <= self.config.max_order
                and len(support) + 2 <= self.config.max_reads):
            self._memo[target] = dict(guard=self._guard(), stamp=self._revision,
                                      result=selected, support=support)
            while len(self._memo) > self.config.memo_capacity:
                self._memo.popitem(last=False)
                self.metrics['memo_evictions'] += 1
        elif self.config.memo:
            self.metrics['storage_bypasses'] += 1
        return public(selected)

    def close(self):
        self._memo.clear()
        self._case = None
        self._edges = self._ids = self._identities = {}
        self._closed = True
        self.metrics['closes'] += 1

    def rebind(self, case):
        self.close()
        self._binding += 1
        self._location = (None, 0)
        self._closed = False
        self.replace(case)
