"""Standard-library harness. Timing and allocation are separate passes."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import tracemalloc
from current_baseline import Config, Host
from trace_generator import changed_case, generate


PROFILES = {'current': Config.current(), 'strict': Config.strict(), 'cold': Config.cold()}


def execute(trace, profile):
    case = deepcopy(trace['initial'])
    host = Host(case, config=PROFILES[profile])
    verdicts = []
    for event in trace['events']:
        if event['op'] == 'request':
            verdicts.append(host.request(event['target']))
        elif event['op'] in ('analysis', 'header'):
            case = changed_case(case, event)
            host.replace(case)
        elif event['op'] == 'rebind':
            host.rebind(case)
        elif event['op'] == 'close':
            host.close()
        else:
            raise ValueError('unknown trace event')
    host.close()
    metrics = dict(host.metrics)
    return verdicts, metrics


def run(trace, profile):
    start = time.perf_counter_ns()
    verdicts, counters = execute(trace, profile)
    elapsed = time.perf_counter_ns() - start
    tracemalloc.start()
    execute(trace, profile)
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    encode = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
    return dict(profile=profile, config=vars(PROFILES[profile]),
                trace_sha256=hashlib.sha256(encode(trace)).hexdigest(),
                verdict_sha256=hashlib.sha256(encode(verdicts)).hexdigest(),
                host_elapsed_ns=elapsed, separate_allocation_peak_bytes=peak, work=counters,
                service_profile=trace['service_profile'],
                limitation='Python virtual host only; native and end-to-end cost missing')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--trace')
    parser.add_argument('--profile', choices=list(PROFILES))
    parser.add_argument('--processes', type=int, choices=(1, 3), default=1)
    args = parser.parse_args()
    if args.processes == 3:
        rows = []
        for _ in range(3):
            command = [sys.executable, str(Path(__file__).resolve()), '--processes', '1']
            if args.smoke: command.append('--smoke')
            if args.trace: command.extend(['--trace', args.trace])
            if args.profile: command.extend(['--profile', args.profile])
            rows.append(json.loads(subprocess.check_output(command, text=True, encoding='utf-8')))
        print(json.dumps(dict(independent_processes=rows), allow_nan=False))
        return
    trace = json.loads(Path(args.trace).read_text(encoding='utf-8')) if args.trace else generate(rounds=3 if args.smoke else 20)
    rows = [run(trace, profile) for profile in ([args.profile] if args.profile else PROFILES)]
    if len({row['verdict_sha256'] for row in rows}) != 1:
        raise AssertionError('profile verdict mismatch')
    print(json.dumps(dict(results=rows), allow_nan=False))


if __name__ == '__main__':
    main()
