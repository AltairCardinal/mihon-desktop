"""Provenance checks complement, and do not replace, behavior contracts."""
import hashlib
import json
from pathlib import Path
import unittest


class FrozenArtifacts(unittest.TestCase):
    def test_frozen_bytes_and_golden_count(self):
        root = Path(__file__).parent.parent
        entries = json.loads((root / 'fixtures/frozen-hashes.json').read_text(encoding='utf-8'))['sha256']
        self.assertEqual(len(entries), 13)
        for name, digest in entries.items():
            self.assertEqual(hashlib.sha256((root / name).read_bytes()).hexdigest(), digest, name)
        with (root / 'fixtures/golden.jsonl').open(encoding='utf-8') as source:
            self.assertEqual(sum(1 for line in source if line.strip()), 7)


if __name__ == '__main__': unittest.main()
