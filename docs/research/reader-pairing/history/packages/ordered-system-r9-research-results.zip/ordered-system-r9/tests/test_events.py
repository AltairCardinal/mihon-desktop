import copy
import random
import unittest
from unittest.mock import patch
import reference as R
from current_baseline import Host, Config
from trace_generator import generate, changed_case, failure_for


class EventContracts(unittest.TestCase):
    def test_terminal_cleanup_is_counted_without_close_event(self):
        from benchmark import execute, PROFILES
        trace=generate(rounds=0); trace['events']=[]
        for profile in PROFILES:
            _, work=execute(trace,profile)
            self.assertEqual(work.get('closes',0),1)

    def test_fixed_external_trace_and_identity_failure(self):
        self.assertEqual(generate(19),generate(19))
        expected=failure_for(19,['i1',0],4)
        for i in range(30): failure_for(19,['other',i],1)
        self.assertEqual(failure_for(19,['i1',0],4),expected)

    def test_random_event_differential(self):
        for seed in range(8):
            trace=generate(seed,n=7,rounds=12); c=trace['initial']
            hosts=[Host(c,config=cfg) for cfg in (Config.current(),Config.strict(),Config.cold())]
            for event in trace['events']:
                if event['op']=='request':
                    expected={k:v for k,v in R.certify_strategy(c,event['target'])['selected'].items() if k!='reads'}
                    for h in hosts: self.assertEqual(h.request(event['target']),expected)
                elif event['op'] in ('analysis','header'):
                    c=changed_case(c,event)
                    for h in hosts: h.replace(c)
                elif event['op']=='rebind':
                    for h in hosts: h.rebind(c)
                elif event['op']=='close':
                    for h in hosts: h.close()

    def test_disconnected_stamp_mutant_is_detected(self):
        trace=generate(rounds=1); c=trace['initial']; h=Host(c,config=Config.current()); h.request(2)
        c['items'][2]['analysis']={'status':'unknown'}
        h.replace(c)
        with patch.object(h,'_stamp',return_value=(0,1)):
            wrong=h.request(2)
        self.assertEqual(wrong['status'],'certified')
        expected=R.certify_strategy(c,2)['selected']
        self.assertNotEqual(wrong['status'],expected['status'])

    def test_disabled_optimization_has_detectable_work_signature(self):
        c=generate(rounds=1)['initial']
        optimized=Host(c,config=Config.current()); cold=Host(c,config=Config.cold())
        for h in (optimized,cold): h.request(2); h.request(3); h.request(2)
        self.assertEqual(optimized.metrics['engine_runs'],2)
        self.assertEqual(cold.metrics['engine_runs'],3)
        self.assertGreater(optimized.metrics['stamp_hits'],0)
