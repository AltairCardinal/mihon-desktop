"""Synthetic protocol obligations; these do not test a native runtime."""
import unittest
from protocol import run_event_trace


class ProtocolContracts(unittest.TestCase):
    def test_completed_unconsumed_still_occupies_capacity(self):
        r = run_event_trace(dict(capacity=1, events=[
            dict(op='request', key='a'), dict(op='finish', key='a'),
            dict(op='request', key='b'), dict(op='consume', key='a'),
            dict(op='request', key='b')]))
        self.assertEqual([x['outcome'] for x in r], ['admitted', 'completed', 'full', 'consumed', 'admitted'])

    def test_cancel_does_not_release_nonpreemptible_work(self):
        r = run_event_trace(dict(capacity=1, events=[
            dict(op='request', key='a'), dict(op='cancel', key='a'),
            dict(op='request', key='b'), dict(op='finish', key='a'),
            dict(op='request', key='b')]))
        self.assertEqual(r[2]['outcome'], 'full')
        self.assertEqual(r[3]['outcome'], 'discarded')
        self.assertEqual(r[4]['outcome'], 'admitted')

    def test_upgrade_reuses_identity_and_old_completion_is_rejected(self):
        r = run_event_trace(dict(capacity=2, events=[
            dict(op='request', key='a', required=False),
            dict(op='request', key='a', required=True),
            dict(op='version', version=1), dict(op='finish', key='a', version=0)]))
        self.assertEqual(r[1]['outcome'], 'reused')
        self.assertEqual(r[1]['occupied'], 1)
        self.assertEqual(r[3]['outcome'], 'discarded')

    def test_same_target_disjoint_replacement_is_rejected(self):
        rows=run_event_trace(dict(events=[dict(op='publish',target=2,unit={'slots':[2,3]}),
            dict(op='publish',target=2,unit={'slots':[4,5]})]))
        self.assertEqual(rows[-1]['outcome'],'conflict')

    def test_cross_target_overlap_is_rejected(self):
        rows=run_event_trace(dict(events=[
            dict(op='publish',target=0,unit={'slots':[0,1]}),
            dict(op='publish',target=1,unit={'slots':[1,2]})]))
        self.assertEqual(rows[-1]['outcome'],'conflict')

    def test_version_cannot_return_to_old_identity(self):
        rows=run_event_trace(dict(events=[dict(op='version',version=1),dict(op='version',version=0),
            dict(op='publish',version=0,target=0,unit={'slots':[0]})]))
        self.assertEqual([r['outcome'] for r in rows],['advanced','stale','stale'])

    def test_publication_is_immutable_within_identity(self):
        r = run_event_trace(dict(events=[
            dict(op='publish', target=2, unit={'slots':[2,3]}),
            dict(op='publish', target=2, unit={'slots':[2]}),
            dict(op='version', version=1),
            dict(op='publish', target=2, unit={'slots':[2]})]))
        self.assertEqual([x['outcome'] for x in r], ['published', 'conflict', 'advanced', 'published'])


if __name__ == '__main__':
    unittest.main()
