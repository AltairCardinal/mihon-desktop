import copy
import json
from pathlib import Path
import unittest

import reference as ref
from corrected_owner import Owner, Config, SAT
from current_baseline import Host, Config as HistoricalConfig
from test_reference import case, fact


def wanted(c, t):
    return {k: v for k, v in ref.certify_strategy(c, t)['selected'].items() if k != 'reads'}


def delta(o, changed):
    o.apply(item_updates={i: x for i, x in enumerate(changed['items'])},
            edge_updates={(e['first'], e['second']): e for e in changed['edges']})


class OwnerContracts(unittest.TestCase):
    def test_c5_rejected_attempt_is_a_real_dependency(self):
        for name in ('c5_retry_support_cex.json', 'c5_adopted_variant_cex.json'):
            fx = json.loads((Path(__file__).parent.parent / 'fixtures' / name).read_text(encoding='utf-8'))
            c, changed, t = fx['case'], fx['changed'], fx['target']
            h = Host(c, config=HistoricalConfig.current())
            h.request(t); h.replace(changed)
            self.assertNotEqual(h.request(t), wanted(changed, t))
            o = Owner(c); o.request(t); delta(o, changed)
            self.assertEqual(o.request(t), wanted(changed, t))
            self.assertEqual(o.metrics['engine_runs'], 2)

    def test_c5_selected_only_mutant_is_killed_on_delta_path(self):
        fx = json.loads((Path(__file__).parent.parent / 'fixtures' / 'c5_retry_support_cex.json').read_text(encoding='utf-8'))
        o = Owner(fx['case']); o.request(fx['target'])
        entry = o._memo[fx['target']]
        entry['support'] = dict(entry['result']['proof'][2])
        delta(o, fx['changed'])
        self.assertNotEqual(o.request(fx['target']), wanted(fx['changed'], fx['target']))

    def test_unrelated_change_refreshes_stamp_without_engine(self):
        o = Owner(case(20, True)); first = o.request(2)
        o.apply(item_updates={19: {'header': fact('WIDE')}})
        self.assertEqual(o.request(2), first)
        self.assertEqual(o.metrics['support_validations'], 1)
        o.request(2)
        self.assertEqual(o.metrics['stamp_hits'], 1)
        self.assertEqual(o.metrics['engine_runs'], 1)
        self.assertEqual(o.metrics['delta_item_slots'], 1)
        self.assertEqual(o.metrics['boundary_item_slots'], 20)

    def test_relevant_change_and_request_isolation(self):
        c = case(8, True); o = Owner(c)
        answer = o.request(2); answer['unit']['slots'][0]['item'] = 99
        c['items'][2]['analysis']['fact'] = fact('WIDE')
        self.assertEqual(o.request(2), wanted(case(8, True), 2))
        o.apply(item_updates={2: {'analysis': c['items'][2]['analysis']}})
        self.assertEqual(o.request(2), wanted(c, 2))
        self.assertEqual(o.metrics['engine_runs'], 2)

    def test_global_identity_settings_location_and_saturation_guards(self):
        o = Owner(case(12, True)); o.request(2)
        for update in ({11: {'content_version': 1}}, {11: {'orientation': 2}}):
            o.apply(item_updates=update); o.request(2)
        self.assertEqual(o.metrics['engine_runs'], 3)
        o.locate('i2', 2); o.request(2)
        self.assertEqual(o.metrics['engine_runs'], 4)
        o.apply(settings={'direction': 'BA'}); o.request(2)
        self.assertEqual(o.metrics['engine_runs'], 5)
        o._revision = SAT
        o.request(2); o.request(2)
        self.assertEqual(o.metrics['support_validations'], 2)
        o._identity_epoch = SAT
        o.apply(item_updates={11: {'content_version': 2}}); o.request(2)
        o.apply(item_updates={11: {'content_version': 3}}); o.request(2)
        self.assertEqual(o.metrics['engine_runs'], 7)

    def test_atomic_batch_rejects_duplicate_without_partial_write(self):
        o = Owner(case(4)); before = o.snapshot()
        with self.assertRaises(ValueError):
            o.apply(item_updates={0: {'header': fact('WIDE')}, 1: {'id': 'i2'}})
        self.assertEqual(o.snapshot(), before)
        o.apply(item_updates={0: {'id': 'i1'}, 1: {'id': 'i0'}})
        self.assertEqual(o.snapshot()['items'][0]['id'], 'i1')

    def test_storage_limits_close_and_rebind(self):
        o = Owner(case(8, True), config=Config(max_reads=1)); o.request(2)
        self.assertEqual(o.memo_size, 0)
        o.close()
        with self.assertRaises(ValueError): o.request(2)
        with self.assertRaises(ValueError): o.apply(item_updates={0: {'content_version': 1}})
        o.rebind(case(3)); self.assertEqual(o.request(2), wanted(case(3), 2))

    def test_all_facilities_charge_even_without_memo(self):
        o = Owner(case(10, True), config=Config(memo=False))
        for _ in range(3): o.request(2)
        self.assertEqual(o.metrics['engine_runs'], 3)
        self.assertGreater(o.metrics['scan_steps'], 0)
        self.assertGreater(o.metrics['support_keys_built'], 0)
        self.assertEqual(o.metrics['boundary_item_slots'], 10)
        self.assertEqual(o.memo_size, 0)

    def test_public_needs_failures_order_and_golden_differential(self):
        path = Path(__file__).parent.parent / 'fixtures' / 'golden.jsonl'
        for line in path.read_text(encoding='utf-8').splitlines():
            sample = json.loads(line); c, t = sample['case'], sample['target']
            self.assertEqual(Owner(c).request(t), wanted(c, t), sample['id'])
        c = case(7, True); c['items'][2]['analysis'] = {'status': 'failed', 'reason': 'READ'}
        c['edges'][3] = dict(first=3, second=4, status='failed', failures={'4': 'RESOURCE', '3': 'READ'})
        o = Owner(c)
        self.assertEqual(o.request(3), wanted(c, 3))
        self.assertEqual(list(o.request(3)['failures']), list(wanted(c, 3)['failures']))


if __name__ == '__main__': unittest.main()
