import copy
import itertools
import unittest
import reference as R
from current_baseline import Host, Config
from test_reference import case, fact


class BaselineContracts(unittest.TestCase):
    def test_explicit_controls_and_cross_target_bound(self):
        c=case(8,True)
        for config in (Config.current(),Config.strict(),Config.cold()):
            h=Host(c,config=config)
            for t in (2,3,2,4,5,6):
                self.assertEqual(h.request(t), {k:v for k,v in R.certify_strategy(c,t)['selected'].items() if k!='reads'})
            self.assertLessEqual(h.memo_size,config.memo_capacity)
        h=Host(c,config=Config.current()); h.request(2); h.request(3); h.request(2)
        self.assertEqual(h.metrics['engine_runs'],2)
        self.assertEqual(h.metrics['stamp_hits'],1)

    def test_mutation_stamp_and_strict_revalidation(self):
        c=case(6,True); h=Host(c,config=Config.current()); h.request(2)
        changed=copy.deepcopy(c); changed['items'][5]['header']['width']=101
        h.replace(changed); h.request(2)
        self.assertEqual(h.metrics['read_validations'],1)
        self.assertEqual(h.metrics['engine_runs'],1)
        changed['items'][2]['analysis']['fact']=fact('WIDE')
        h.replace(changed); got=h.request(2)
        self.assertEqual(got['unit']['reason'],'WIDE')
        self.assertEqual(h.metrics['engine_runs'],2)

    def test_global_identity_and_location_guard(self):
        c=case(6,True); h=Host(c,config=Config.current()); h.request(2)
        c['items'][5]['content_version']=1; h.replace(c); h.request(2)
        self.assertEqual(h.metrics['engine_runs'],2)
        h.locate('i3',1); h.request(2)
        self.assertEqual(h.metrics['engine_runs'],3)

    def test_pending_status_cannot_be_reused_after_completion(self):
        c=case(5,True); c['items'][2]['analysis']={'status':'unknown'}
        h=Host(c,config=Config.current()); self.assertEqual(h.request(2)['status'],'need_facts')
        c['items'][2]['analysis']={'status':'computed','fact':fact(),'version':1}
        h.replace(c); self.assertEqual(h.request(2)['status'],'certified')

    def test_small_domain_complete_plan_oracle(self):
        for states in itertools.product(('NARROW','WIDE'),repeat=4):
            c=case(4,True)
            for i,state in enumerate(states): c['items'][i]['analysis']['fact']=fact(state)
            h=Host(c,config=Config.current())
            for target in range(4):
                wanted=next(u for u in R.complete_plan(c) if any(s['item']==target for s in u['slots']))
                self.assertEqual(h.request(target)['unit'],wanted)

    def test_each_control_is_explicit_and_observable(self):
        from dataclasses import replace
        c=case(8,True)
        for field in ('shared_input_index','compact_proof','change_stamps'):
            cfg=replace(Config.current(),**{field:False})
            h=Host(c,config=cfg); h.request(2); h.request(3); h.request(2)
            self.assertEqual(h.metrics['engine_runs'],2)
            if field=='shared_input_index': self.assertEqual(h.metrics['input_index_builds'],3)
            if field=='compact_proof': self.assertEqual(h.metrics['index_views'],0)
            if field=='change_stamps': self.assertEqual(h.metrics['stamp_hits'],0)

    def test_stamp_saturation_requires_read_validation(self):
        h=Host(case(),config=Config.current()); h.request(2)
        h._revision=(1<<63)-1; h.request(2); h.request(2)
        self.assertEqual(h.metrics['read_validations'],2)

    def test_close_and_rebind_reclaim(self):
        h=Host(case(),config=Config.current()); h.request(2); h.close()
        self.assertEqual(h.memo_size,0)
        with self.assertRaises(ValueError): h.request(2)
        h.rebind(case(3)); self.assertEqual(h.request(2)['status'],'certified')

    def test_oversized_storage_is_bypass_not_failure(self):
        h=Host(case(),config=Config(True,True,True,True,4,2,2))
        self.assertEqual(h.request(2)['status'],'certified'); self.assertEqual(h.memo_size,0)
        self.assertEqual(h.metrics['oversized_bypasses'],1)
