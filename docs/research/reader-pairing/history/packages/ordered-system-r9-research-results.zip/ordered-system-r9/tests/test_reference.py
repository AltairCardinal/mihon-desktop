"""Focused executable contracts for the neutral ordered system."""
import copy
import json
from pathlib import Path
import unittest
import reference as r


def fact(state="NARROW", side="UNKNOWN"):
    return dict(state=state, width=200 if state == "WIDE" else 100,
                height=200, rotation=0, orientation=1, side=side)


def case(n=6, automatic=False):
    return dict(items=[dict(id=f"i{i}", header=fact(),
                           analysis=dict(status="computed", fact=fact(), version=1))
                       for i in range(n)], settings=dict(automatic=automatic),
                edges=[dict(first=i, second=i+1, status="computed", score=None, version=1)
                       for i in range(n-1)])


class Contracts(unittest.TestCase):
    def test_anonymous_golden_contracts(self):
        path = Path(__file__).parent.parent / 'fixtures' / 'golden.jsonl'
        count = 0
        with path.open(encoding='utf-8') as source:
            for line in source:
                sample = json.loads(line)
                with self.subTest(sample=sample['id']):
                    expected = sample['expected']
                    self.assertEqual(r.complete_plan(sample['full_case']), expected['full_units'])
                    baseline = r.certify(sample['case'], sample['target'])
                    strategy = r.certify_strategy(sample['case'], sample['target'])
                    for label, actual in (('baseline', baseline), ('selected', strategy['selected'])):
                        comparable = {k: v for k, v in actual.items() if k != 'reads'}
                        comparable['needs'] = sorted(comparable['needs'], key=lambda x: json.dumps(x, sort_keys=True))
                        wanted = copy.deepcopy(expected[label])
                        wanted['needs'] = sorted(wanted['needs'], key=lambda x: json.dumps(x, sort_keys=True))
                        self.assertEqual(comparable, wanted)
                    for field in ('retried', 'adopted', 'total_steps'):
                        self.assertEqual(strategy[field], expected[field])
                count += 1
        self.assertGreater(count, 0)
        self.assertLessEqual(count, 64)

    def test_partition_slots_and_opening(self):
        c = case(4)
        units = r.complete_plan(c)
        self.assertEqual([[s['item'] for s in u['slots']] for u in units], [[0], [1, 2], [3]])
        self.assertEqual(units[0]['reason'], 'FIRST')
        self.assertEqual(units[0]['slots'][0]['slot'], 'B')
        self.assertEqual(units[2]['slots'][0]['slot'], 'A')

    def test_computed_null_is_not_unknown(self):
        c = case(6, True)
        self.assertEqual(r.certify(c, 2)['status'], 'certified')
        c['edges'] = []
        result = r.certify(c, 2)
        self.assertEqual(result['status'], 'need_facts')
        self.assertTrue(any(n['kind'] == 'RANK' for n in result['needs']))

    def test_failures_do_not_become_null(self):
        c = case(5, True)
        c['edges'][1] = dict(first=1, second=2, status='failed', failures={'1':'RESOURCE'})
        self.assertEqual(r.certify(c, 2)['failures'], {'1':'RESOURCE'})
        self.assertEqual(r.certify(c, 2)['status'], 'blocked')

    def test_isolation_reason_priority_and_dependency(self):
        c = case(5, True)
        c['settings']['hard_isolates'] = [0, 3]
        c['items'][2]['analysis'] = dict(status='failed', reason='READ')
        result = r.certify(c, 3)
        self.assertEqual(result['status'], 'certified')
        self.assertEqual(result['unit']['reason'], 'ISOLATE')
        self.assertNotIn(2, result['dependent_items'])
        self.assertEqual(r.complete_plan(c)[0]['reason'], 'FIRST')

    def test_pinned_overlap_is_alternating(self):
        c = case(5)
        c['settings']['pinned_links'] = [0, 1, 2, 3]
        self.assertEqual([len(u['slots']) for u in r.complete_plan(c)], [2, 2, 1])

    def test_read_set_version_and_conditional_header(self):
        c = case(5, True)
        result = r.certify(c, 2)
        changed = copy.deepcopy(c)
        changed['items'][2]['analysis']['version'] = 2
        self.assertFalse(r.reads_current(result, changed))
        changed = copy.deepcopy(c)
        changed['items'][2]['header']['width'] = 101
        self.assertTrue(r.reads_current(result, changed))

    def test_known_side_outranks_default_single_slot(self):
        c = case(3, True)
        c['settings']['hard_isolates'] = [2]
        c['items'][2]['analysis']['fact']['side'] = 'A'
        self.assertEqual(r.certify(c, 2)['unit']['slots'][0]['slot'], 'A')

    def test_reserved_pair_does_not_recompare(self):
        c = case(5, True)
        c['edges'][1]['score'] = 9
        c['edges'][2]['score'] = 2
        c['edges'][3]['score'] = 0
        self.assertEqual([[s['item'] for s in u['slots']] for u in r.complete_plan(c)],
                         [[0], [1], [2, 3], [4]])

    def test_strategy_attempts_are_independent(self):
        c = case(8, True)
        c['edges'] = []
        result = r.certify_strategy(c, 5)
        self.assertEqual(result['selected'], result['baseline'])
        self.assertEqual(result['selected']['reads'], result['baseline']['reads'])
        self.assertEqual(result['total_steps'], result['baseline']['steps'] + result['retry']['steps'])

    def test_strategy_adopts_only_retry_support(self):
        c = case(7, True)
        c['settings']['opening'] = 'SINGLE'
        c['edges'][1]['score'] = 15
        c['edges'][2]['score'] = 6
        c['edges'][3] = dict(first=3, second=4, status='unknown')
        c['edges'][4]['score'] = 15
        result = r.certify_strategy(c, 3)
        self.assertEqual(result['baseline']['status'], 'need_facts')
        self.assertTrue(result['adopted'])
        self.assertEqual(result['selected']['status'], 'certified')
        self.assertIn('rank:3:4', result['baseline']['reads'])
        self.assertNotIn('rank:3:4', result['selected']['reads'])
        self.assertEqual(result['selected']['unit'], r.complete_plan(c)[2])

    def test_geometry_and_identity_staleness(self):
        c = case(4, True)
        c['items'][2]['rotation'] = 90
        self.assertEqual(r.certify(c, 2)['needs'], [dict(item=2, kind='DIMENSIONS')])
        c = case(4)
        result = r.certify(c, 2)
        c['generation'] = 1
        self.assertEqual(r.first_changed_read(result, c), 'identity')

    def test_certified_full_units_match_snapshot_plan(self):
        # Bounded deterministic cross-check, not a proof over all inputs.
        for mask in range(32):
            c = case(5, True)
            for i in range(5):
                if mask & (1 << i):
                    c['items'][i]['analysis']['fact'] = fact('WIDE')
            for direction in ('AB', 'BA'):
                c['settings']['direction'] = direction
                units = r.complete_plan(c)
                for target in range(5):
                    result = r.certify(c, target)
                    self.assertEqual(result['status'], 'certified')
                    expected = next(u for u in units if any(s['item'] == target for s in u['slots']))
                    self.assertEqual(result['unit'], expected)


if __name__ == '__main__':
    unittest.main()
