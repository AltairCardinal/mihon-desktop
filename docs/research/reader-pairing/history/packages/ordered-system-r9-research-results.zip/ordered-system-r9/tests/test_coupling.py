import copy
import json
from pathlib import Path
import unittest

from coupling import Session, Witness, World, run_trace
from corrected_owner import SAT
from test_reference import case, fact


def partial(n=5):
    c = case(n, True)
    for item in c['items']: item['analysis'] = {'status': 'unknown'}
    c['edges'] = []
    return c


def witness(value=0, side='UNKNOWN'):
    return Witness({'status': 'computed', 'fact': fact(side=side), 'version': 1}, value)


class CoupledContracts(unittest.TestCase):
    def test_shared_task_required_promotion_and_no_privileged_truth(self):
        s = Session(partial(), capacity=2)
        t = s.acquire(2, required=False)
        self.assertEqual(s.acquire(2, required=True), t)
        self.assertEqual(s.occupied, 1)
        self.assertTrue(s.task(t)['required'])
        self.assertEqual(s.observe()['items'][2]['analysis'], {'status': 'unknown'})
        self.assertFalse(hasattr(s, 'world'))
        self.assertFalse(hasattr(s, '_world'))
        s.finish(t, witness()); self.assertEqual(s.occupied, 1)
        self.assertNotIn('result', s.task(t))
        s.consume(t)
        self.assertEqual(s.observe()['items'][2]['analysis']['status'], 'computed')

    def test_one_witness_feeds_analysis_and_both_neighbors(self):
        s = Session(partial(), capacity=3, raw_capacity=3)
        for i in (1, 3, 2):
            t = s.acquire(i); s.finish(t, witness(i * 2)); s.consume(t)
        edges = {(e['first'], e['second']): e for e in s.observe()['edges']}
        self.assertEqual(edges[1, 2]['score'], 2)
        self.assertEqual(edges[2, 3]['score'], 2)
        self.assertEqual(s.metrics['physical_admissions'], 3)
        self.assertEqual(s.metrics['rank_computations'], 2)

    def test_computed_null_missing_and_failed_remain_distinct(self):
        s = Session(partial(), raw_capacity=2)
        for i, raw in ((1, None), (2, 3)):
            t = s.acquire(i); s.finish(t, witness(raw)); s.consume(t)
        e = s.observe()['edges'][0]
        self.assertEqual((e['status'], e['score']), ('computed', None))
        t = s.acquire(3)
        s.finish(t, Witness({'status': 'failed', 'reason': 'RESOURCE'}, available=False))
        s.consume(t)
        self.assertEqual(s.observe()['items'][3]['analysis']['status'], 'failed')
        self.assertFalse(any(e['first'] == 2 for e in s.observe()['edges']))

    def test_raw_bound_persistent_scalar_and_reacquisition(self):
        s = Session(partial(), raw_capacity=2)
        for i in (0, 1, 2, 3):
            t = s.acquire(i); s.finish(t, witness(i)); s.consume(t)
        self.assertLessEqual(s.raw_size, 2)
        before = copy.deepcopy(s.observe()['edges'])
        self.assertGreaterEqual(len(before), 3)
        t = s.acquire(0); self.assertIsNotNone(t)
        self.assertEqual(s.observe()['edges'], before)
        self.assertEqual(s.metrics['raw_evictions'], 2)

    def test_raw_cannot_cross_content_identity_or_analysis_replacement(self):
        for patch in ({'content_version': 1}, {'analysis': {'status': 'failed', 'reason': 'READ'}}):
            s = Session(partial())
            t = s.acquire(1); s.finish(t, witness(1)); s.consume(t)
            s.owner.apply(item_updates={1: patch})
            t = s.acquire(2); s.finish(t, witness(2)); s.consume(t)
            self.assertFalse(any(e['first'] == 1 for e in s.observe()['edges']))

    def test_prefix_candidate_has_own_prefix_support_and_extra_certificate(self):
        sample = json.loads((Path(__file__).parent.parent / 'fixtures' / 'prefix-extra.json').read_text(encoding='utf-8'))
        s = Session(sample['case']); target = sample['target']
        self.assertEqual(s.certify(target, mode='L0')['status'], 'need_facts')
        result = s.certify(target, mode='L1')
        self.assertEqual(result['status'], 'certified')
        handle = result['certificate']
        self.assertIn(('analysis', 0), s._certs[handle]['support'])
        s.owner.apply(item_updates={0: {'analysis': dict(sample['case']['items'][0]['analysis'], version=2)}})
        self.assertEqual(s.publish(target, handle), 'stale')

    def test_cancel_keeps_physical_permit_until_finish(self):
        s = Session(partial(), capacity=1)
        t = s.acquire(0); s.cancel(t)
        self.assertEqual(s.occupied, 1)
        self.assertIsNone(s.acquire(1))
        self.assertEqual(s.acquire(0), t)
        self.assertEqual(s.finish(t, witness()), 'discarded')
        self.assertEqual(s.occupied, 0)
        self.assertEqual(s.observe()['items'][0]['analysis']['status'], 'unknown')

    def test_physical_issuance_prevents_late_completion_aba(self):
        s = Session(partial())
        old = s.acquire(2); s.finish(old, witness(1)); s.consume(old)
        current = s.acquire(2)
        self.assertNotEqual(old, current)
        self.assertEqual(s.finish(old, witness(999)), 'absent')
        self.assertEqual(s.task(current)['phase'], 'running')

    def test_same_owner_label_is_not_same_owner_incarnation(self):
        a, b = Session(partial(), owner='same'), Session(partial(), owner='same')
        ta, tb = a.acquire(2), b.acquire(2)
        self.assertNotEqual(ta, tb)
        self.assertEqual(a.finish(tb, witness()), 'absent')
        self.assertEqual(a.task(ta)['phase'], 'running')

    def test_shorter_rebind_rejects_old_completion_without_index_access(self):
        s = Session(partial(5)); old = s.acquire(4)
        s.rebind(partial(2))
        self.assertEqual(s.finish(old, witness()), 'discarded')

    def test_old_owner_scope_version_and_identity_rejected(self):
        s = Session(partial(), capacity=2)
        old = s.acquire(2)
        changed = partial(); changed['items'][2]['content_version'] = 1
        s.rebind(changed, scope='other', version=2)
        current = s.acquire(2)
        self.assertNotEqual(old, current)
        self.assertEqual(s.finish(old, witness()), 'discarded')
        self.assertEqual(s.observe()['items'][2]['analysis']['status'], 'unknown')
        s.finish(current, witness()); self.assertEqual(s.consume(current), 'accepted')
        foreign = Session(partial(), owner='foreign').acquire(2)
        self.assertEqual(s.finish(foreign, witness()), 'absent')

    def test_publication_certificate_membership_and_confirm_separate(self):
        s = Session(case(5, True))
        outcome = s.certify(2)
        self.assertEqual(outcome['status'], 'certified')
        handle = outcome['certificate']
        self.assertEqual(s.publish(4, handle), 'wrong_target')
        self.assertEqual(s.publish(2, handle), 'published')
        self.assertEqual(s.confirmed, {})
        self.assertIn(2, s.published)
        self.assertEqual(s.confirm(2), 'confirmed')
        self.assertEqual(s.confirm(4), 'unpublished')
        s.owner.apply(item_updates={2: {'analysis': {'status': 'computed', 'fact': fact('WIDE')}}})
        self.assertEqual(s.publish(2, handle), 'stale')
        self.assertEqual(s.confirm(2), 'stale')
        self.assertEqual(s.confirmed, {})
        new = s.certify(2)
        self.assertEqual(s.publish(2, new['certificate']), 'published')
        self.assertEqual(s.published[2]['reason'], 'WIDE')

    def test_budget_refusal_does_not_sign(self):
        s = Session(case(8, True))
        self.assertEqual(s.certify(3, budget=0)['status'], 'budget')
        self.assertEqual(s.certificate_count, 0)
        self.assertEqual(s.published, {})
        self.assertGreater(s.metrics['certification_steps'], 0)

    def test_saturated_identity_guard_cannot_publish_old_certificate(self):
        s = Session(case(12, True)); s.owner._identity_epoch = SAT
        handle = s.certify(2)['certificate']
        s.owner.apply(item_updates={11: {'content_version': 1}})
        self.assertEqual(s.publish(2, handle), 'stale')

    def test_ordered_same_timestamp_and_two_profiles_same_public_goal(self):
        trace = {'initial': partial(3), 'world': [
            {'analysis': {'status': 'computed', 'fact': fact(side='A'), 'version': 1}, 'raw': 0},
            {'analysis': {'status': 'computed', 'fact': fact(side='B'), 'version': 1}, 'raw': 1},
            {'analysis': {'status': 'computed', 'fact': fact(), 'version': 1}, 'raw': 2}],
            'events': [{'at': 0, 'op': 'target', 'target': 1},
                       {'at': 0, 'op': 'prefetch', 'item': 2},
                       {'at': 20, 'op': 'tick'}, {'at': 40, 'op': 'tick'}]}
        for duration in (1, 3):
            a = run_trace(trace, mode='L0', service_units=duration)
            b = run_trace(trace, mode='L1', service_units=duration)
            self.assertEqual(a['published'], b['published'])
            self.assertIn('1', a['published'])
            self.assertEqual(a['events'][0]['at'], a['events'][1]['at'])
            self.assertEqual(a['events'][0]['op'], 'target')
            self.assertEqual(a['events'][1]['op'], 'prefetch')

    def test_different_hidden_world_same_observation_until_consume(self):
        s = Session(partial()); token = s.acquire(2)
        a, b = World([witness(0)] * 5), World([witness(999)] * 5)
        self.assertNotEqual(a.complete(2).raw, b.complete(2).raw)
        self.assertEqual(s.observe()['items'][2]['analysis']['status'], 'unknown')
        s.finish(token, a.complete(2))
        self.assertEqual(s.observe()['items'][2]['analysis']['status'], 'unknown')
        s.consume(token)
        self.assertEqual(s.observe()['items'][2]['analysis']['status'], 'computed')


if __name__ == '__main__': unittest.main()
