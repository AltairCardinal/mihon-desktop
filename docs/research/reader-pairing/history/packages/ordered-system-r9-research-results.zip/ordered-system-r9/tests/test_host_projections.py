import json
from pathlib import Path
import unittest
import reference as R
from current_baseline import Config, Host


def unit(u):
    return {k:u[k] for k in ('slots','certain')} if u is not None else None


class HostProjections(unittest.TestCase):
    def test_exported_projections(self):
        samples=json.loads((Path(__file__).parent.parent/'fixtures'/'host-projections.json').read_text(encoding='utf-8'))
        for sample in samples:
            with self.subTest(sample=sample['name']):
                c=sample['case']; target=sample['target']; expected=sample['expected_certification_projection']
                for got in (R.certify_strategy(c,target)['selected'],Host(c,config=Config.current()).request(target)):
                    projection={'status':got['status']}
                    if 'unit' in expected: projection['unit']=unit(got['unit'])
                    if 'failures' in expected: projection['failures']=got['failures']
                    self.assertEqual(projection,expected)
                if 'expected_complete_plan_projection' in sample:
                    self.assertEqual([unit(u) for u in R.complete_plan(c)],sample['expected_complete_plan_projection'])
