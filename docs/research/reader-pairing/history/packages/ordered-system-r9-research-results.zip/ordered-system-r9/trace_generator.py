"""Fixed exogenous events; no measured service-time distribution is assumed."""
from copy import deepcopy
import hashlib
import json
import random


def failure_for(seed, identity, attempt):
    key = json.dumps([seed, identity, attempt], sort_keys=True, separators=(',', ':'))
    return int.from_bytes(hashlib.sha256(key.encode('utf-8')).digest()[:8], 'big') % 11 == 0


def make_case(n=12):
    def fact():
        return dict(state='NARROW', width=100, height=200, rotation=0, orientation=1, side='UNKNOWN')
    return dict(generation=0, order_revision=0,
                items=[dict(id=f'i{i}', header=fact(), analysis=dict(status='computed', fact=fact(), version=1))
                       for i in range(n)], settings=dict(automatic=True, direction='AB'),
                edges=[dict(first=i, second=i+1, status='computed', score=None, version=1)
                       for i in range(n-1)])


def generate(seed=17, n=12, rounds=20):
    if n < 1 or rounds < 0:
        raise ValueError('invalid trace bounds')
    rng = random.Random(seed)
    events = []
    for step in range(rounds):
        target = rng.randrange(n)
        events.extend([dict(op='request', target=target), dict(op='request', target=target)])
        if step % 3 == 0:
            item = rng.randrange(n)
            identity = [f'i{item}', 0, 0, 1]
            failed = failure_for(seed, identity, step)
            events.append(dict(op='analysis', item=item, failed=failed, attempt=step))
        if step % 5 == 0:
            events.append(dict(op='header', item=rng.randrange(n), width=101 + step))
        if step % 7 == 0:
            events.append(dict(op='rebind'))
    events.append(dict(op='close'))
    return dict(schema=1, seed=seed, initial=make_case(n), events=events,
                service_profile=dict(kind='synthetic_parameter_only', per_task_ns=None,
                                     missing='measured acquisition, derivation, queue and end-to-end costs'))


def changed_case(case, event):
    result = deepcopy(case)
    if event['op'] == 'analysis':
        item = result['items'][event['item']]
        item['analysis'] = (dict(status='failed', reason='RESOURCE') if event['failed'] else
                            dict(status='computed', fact=deepcopy(item['header']), version=event['attempt']+2))
    elif event['op'] == 'header':
        result['items'][event['item']]['header']['width'] = event['width']
    else:
        raise ValueError('not an evidence event')
    return result
