"""Executable ordered-system reference, Python 3.10+, standard library only.

The deterministic scan is normative for this research instance. The finite-entry
proof and its lookbehind are implementation choices, not a completeness claim.
Scalar ranks are a conservative extension domain: arbitrary independent ranks
are not claimed realizable by any particular physical measurement process.
No decoding, extraction, acquisition, scheduling or presentation is modeled.
"""
from copy import deepcopy
import json
import sys


UNKNOWN = {'status': 'unknown'}


def _fact(value):
    if value is None:
        return None
    return dict(state=value.get('state', 'UNKNOWN'), width=value.get('width', 0),
                height=value.get('height', 0), rotation=value.get('rotation', 0),
                orientation=value.get('orientation', 1), side=value.get('side', 'UNKNOWN'))


def _geometry(f):
    if f is None or f['width'] <= 0 or f['height'] <= 0:
        return False
    w, h = f['width'], f['height']
    if f['rotation'] in (90, 270):
        w, h = h, w
    return f['state'] == ('WIDE' if w >= h else 'NARROW')


class _Input:
    def __init__(self, case):
        self.case = deepcopy(case)
        self.items = self.case['items']
        s = self.case.get('settings', {})
        self.settings = dict(direction=s.get('direction', 'AB'), automatic=s.get('automatic', False),
                             hard_isolates=sorted(set(s.get('hard_isolates', []))),
                             pinned_links=sorted(set(s.get('pinned_links', []))),
                             opening=s.get('opening', 'AUTO'), revision=s.get('revision', 0))
        if self.settings['direction'] not in ('AB', 'BA'):
            raise ValueError('direction must be AB or BA')
        self.identity = dict(generation=case.get('generation', 0),
                             order_revision=case.get('order_revision', 0),
                             items=[dict(id=x.get('id', str(i)), content_version=x.get('content_version', 0),
                                         rotation=x.get('rotation', 0), orientation=x.get('orientation', 1))
                                    for i, x in enumerate(self.items)])
        if len({x['id'] for x in self.identity['items']}) != len(self.items):
            raise ValueError('item ids must be unique')
        self.edges = {(e['first'], e['second']): e for e in case.get('edges', [])}

    def analysis(self, i):
        e = deepcopy(self.items[i].get('analysis', UNKNOWN))
        if e['status'] == 'computed':
            e['fact'] = _fact(e['fact'])
            e.setdefault('version', 1)
            e['content'] = self.identity['items'][i]
        elif e['status'] == 'failed':
            e['content'] = self.identity['items'][i]
        elif e['status'] != 'unknown':
            raise ValueError('invalid analysis status')
        return e

    def effective(self, i):
        a = self.analysis(i)
        return a['fact'] if a['status'] == 'computed' else _fact(self.items[i].get('header'))

    def edge(self, a, b):
        # The evidence provider requires adjacent computed endpoint analyses.
        aa, bb = self.analysis(a), self.analysis(b)
        if b != a + 1 or aa['status'] != 'computed' or bb['status'] != 'computed':
            return deepcopy(UNKNOWN)
        if aa['fact']['state'] == 'WIDE' or bb['fact']['state'] == 'WIDE':
            e = dict(status='computed', score=None, version=1)
        else:
            e = deepcopy(self.edges.get((a, b), UNKNOWN))
            e.pop('first', None)
            e.pop('second', None)
            if e['status'] == 'computed':
                e.setdefault('score', None)
                e.setdefault('version', 1)
        if e['status'] != 'unknown':
            e['content'] = [self.identity['items'][a], self.identity['items'][b]]
        return e


class _Scan:
    def __init__(self, n, settings, dimension, side, resolved, distance):
        self.n, self.s = n, settings
        self.dimension, self.side_fact, self.resolved, self.distance = dimension, side, resolved, distance
        self.leading, self.trailing = ('A', 'B') if settings['direction'] == 'AB' else ('B', 'A')
        self.forced = set(settings['hard_isolates'])
        self.starts = set(settings['pinned_links']) | ({0} if settings['opening'] == 'PAIR' else set())
        self.manual_cache = {}

    def wide(self, i):
        f = self.dimension(i) if 0 <= i < self.n else None
        return f is not None and f['state'] == 'WIDE'

    def known(self, i):
        f = self.dimension(i) if 0 <= i < self.n else None
        return f is not None and f['state'] in ('NARROW', 'WIDE')

    def side(self, i):
        return self.side_fact(i) if self.s['automatic'] and 0 <= i < self.n else 'UNKNOWN'

    def manual(self, i):
        if i not in self.starts or not 0 <= i < self.n - 1:
            return False
        if i in self.manual_cache:
            return self.manual_cache[i]
        ordinal, pending, previous = i, [], False
        while ordinal >= 0 and ordinal in self.starts:
            if ordinal in self.manual_cache:
                previous = self.manual_cache[ordinal]
                break
            valid = (ordinal not in self.forced and ordinal + 1 not in self.forced
                     and not self.wide(ordinal) and not self.wide(ordinal + 1))
            if not valid:
                self.manual_cache[ordinal] = False
                break
            pending.append(ordinal)
            ordinal -= 1
        for candidate in reversed(pending):
            previous = not previous
            self.manual_cache[candidate] = previous
        return self.manual_cache[i]

    def allowed(self, i):
        if (not 0 <= i < self.n - 1 or i in self.forced or i + 1 in self.forced
                or self.wide(i) or self.wide(i + 1)):
            return False
        if self.manual(i):
            return True
        if self.manual(i - 1) or self.manual(i + 1):
            return False
        if self.s['automatic'] and (self.resolved(i) == self.trailing or self.resolved(i + 1) == self.leading):
            return False
        if i == 0 and (self.s['opening'] != 'AUTO' or not self.known(0) or not self.known(1)
                       or self.side(1) != self.trailing or self.side(0) == self.trailing):
            return False
        return self.side(i) != self.trailing and self.side(i + 1) != self.leading

    def strength(self, i):
        if not self.allowed(i):
            return -1
        if self.manual(i):
            return 3
        if self.side(i) == self.leading or self.side(i + 1) == self.trailing:
            return 2
        return 0

    def later_wins(self, i):
        near, later = self.strength(i), self.strength(i + 1)
        if later != near:
            return later > near
        if not self.s['automatic'] or later < 0 or i + 2 >= self.n:
            return False
        a, b = self.distance(i, i + 1), self.distance(i + 1, i + 2)
        return b is not None and (a is None or b < a)

    def step(self, cursor, include_single=True, include_pair=True):
        i, opening, reserved = cursor
        can_pair = self.allowed(i)
        if can_pair and (i == reserved or not self.later_wins(i)):
            unit = dict(slots=[dict(item=i, slot=self.leading), dict(item=i+1, slot=self.trailing)],
                        certain=self.known(i) and self.known(i+1), reason=None) if include_pair else None
            return unit, (i+2, False, reserved)
        nxt = (i+1, opening, i+1 if i > 0 and can_pair else reserved)
        if not include_single:
            return None, nxt
        if self.n == 1:
            reason = 'ONLY'
        elif self.wide(i):
            reason = 'WIDE'
        elif i == 0:
            reason = 'FIRST'
        elif i in self.forced:
            reason = 'ISOLATE'
        elif i == self.n - 1:
            reason = 'TAIL'
        elif opening and self.wide(i + 1):
            reason = 'OPENING'
        elif self.wide(i + 1) and self.wide(i - 1):
            reason = 'BETWEEN_WIDE'
        elif self.wide(i + 1):
            reason = 'BEFORE_WIDE'
        elif self.later_wins(i):
            reason = 'RANK_BOUNDARY'
        else:
            reason = 'UNRESOLVED'
        if reason in ('WIDE', 'ONLY'):
            slot = 'ALL'
        elif self.side(i) == 'A':
            slot = 'A'
        elif self.side(i) == 'B':
            slot = 'B'
        elif reason == 'ISOLATE':
            slot = self.leading
        elif reason in ('FIRST', 'OPENING', 'RANK_BOUNDARY'):
            slot = self.trailing
        elif reason in ('TAIL', 'BEFORE_WIDE'):
            slot = self.leading
        else:
            slot = 'ALL'
        return dict(slots=[dict(item=i, slot=slot)], certain=self.known(i), reason=reason), nxt


def complete_plan(case):
    """Deterministic snapshot plan. Incomplete inputs yield provisional units."""
    data = _Input(case)
    def dim(i):
        return data.effective(i)
    def side(i):
        f = dim(i)
        return f['side'] if f else 'UNKNOWN'
    def resolved(i):
        f = dim(i)
        return f['side'] if f else None
    def rank(a, b):
        e = data.edge(a, b)
        return e.get('score') if e['status'] == 'computed' else None
    scan = _Scan(len(data.items), data.settings, dim, side, resolved, rank)
    result, cursor = [], (0, True, -1)
    while cursor[0] < len(data.items):
        unit, cursor = scan.step(cursor)
        result.append(unit)
    return result


def certify(case, target, lookbehind=2):
    """Conservative finite-entry proof; target and all references are ordinals.

    Reads are JSON objects keyed by identity/settings/analysis:i/header:i/
    dimension:i/rank:a:b. They snapshot typed evidence, including unknown,
    computed-null, failures, content identity and algorithm versions.
    """
    data = _Input(case)
    n = len(data.items)
    if not 0 <= target < n or lookbehind < 0 or case.get('closed', False):
        raise ValueError('invalid target, lookbehind, or closed evidence source')
    reads = {'identity': deepcopy(data.identity), 'settings': deepcopy(data.settings)}
    needs, failures, dimensions, analyses, edges = {}, {}, {}, {}, {}
    def record(key, value):
        reads[key] = deepcopy(value)
        return value
    def analysis(i):
        return record(f'analysis:{i}', data.analysis(i))
    def dimension(i):
        if not 0 <= i < n:
            return None
        a = analysis(i)
        f = a['fact'] if a['status'] == 'computed' else record(f'header:{i}', _fact(data.items[i].get('header')))
        normalized = dict(f, side='UNKNOWN') if f else None
        record(f'dimension:{i}', normalized)
        item = data.identity['items'][i]
        if not _geometry(f) or f['rotation'] != item['rotation'] or f['orientation'] != item['orientation']:
            if a['status'] == 'failed':
                failures[str(i)] = a['reason']
            elif f and f['state'] == 'FAILED':
                failures[str(i)] = 'READ'
            needs[(i, 'DIMENSIONS')] = dict(item=i, kind='DIMENSIONS')
            return None
        dimensions[i] = normalized
        return f
    def side(i):
        a = analysis(i)
        if a['status'] == 'computed':
            analyses[i] = a
            return a['fact']['side']
        if a['status'] == 'failed':
            failures[str(i)] = a['reason']
        needs[(i, 'ANALYSIS')] = dict(item=i, kind='ANALYSIS')
        return 'UNKNOWN'
    def resolved(i):
        a = analysis(i)
        if a['status'] == 'computed':
            analyses[i] = a
            return a['fact']['side']
        return None
    def rank(a, b):
        e = record(f'rank:{a}:{b}', data.edge(a, b))
        if e['status'] == 'computed':
            edges[a, b] = e
            return e['score']
        if e['status'] == 'failed':
            failures.update({str(k): v for k, v in e.get('failures', {}).items()})
        needs[(a, 'RANK', b)] = dict(item=a, kind='RANK', second=b)
        return None
    scan = _Scan(n, data.settings, dimension, side, resolved, rank)
    memo, steps = {}, 0
    def target_unit(cursor):
        nonlocal steps
        path, result = [], None
        while cursor[0] <= target:
            i, opening, reserved = cursor
            key = (i, opening, reserved == i)
            if key in memo:
                result = memo[key]
                break
            path.append(key)
            unit, cursor = scan.step((i, opening, i if key[2] else -1),
                                     include_single=i == target, include_pair=i+1 >= target)
            steps += 1
            if unit is not None and any(s['item'] == target for s in unit['slots']):
                result = unit
                break
        for key in path:
            memo[key] = result
        return result
    def output(first, unit=None):
        deps = set(dimensions) | set(analyses)
        for a, b in edges:
            deps.update((a, b))
        if unit is None:
            for need in needs.values():
                deps.add(need['item'])
                if 'second' in need:
                    deps.add(need['second'])
        return dict(status='certified' if unit is not None else ('blocked' if failures else 'need_facts'),
                    unit=unit, needs=list(needs.values()), failures=dict(failures), first=first,
                    steps=steps, dependent_items=sorted(deps), reads=deepcopy(reads))
    target_fact = dimension(target)
    if target_fact is None:
        return output(target)
    isolated = target_fact['state'] == 'WIDE' or target in scan.forced
    first = target if isolated else max(0, target - lookbehind)
    while True:
        if first == 0:
            entries = [(0, True, -1)]
        elif isolated:
            entries = [(first, True, -1), (first, False, -1)]
        else:
            entries = []
            boundary_free = first-1 not in scan.forced and first not in scan.forced
            for opening in ([True] if first == 1 else [True, False]):
                entries.append((first, opening, -1))
                if first > 1 and boundary_free:
                    entries.append((first, opening, first))
            if boundary_free:
                entries.append((first+1, False, -1))
        candidates = [target_unit(e) for e in entries]
        if failures or needs:
            return output(first)
        unit = candidates[0]
        if unit is not None and all(u == unit for u in candidates):
            return output(first, unit)
        if first > 0 and not scan.allowed(first-1):
            if failures or needs:
                return output(first)
            normal = [target_unit((first, o, -1)) for o in (True, False)]
            if normal[0] is not None and normal[0] == normal[1]:
                return output(first, normal[0])
        if first <= 0:
            raise AssertionError('unique initial state must determine a unit')
        first -= 1


def certify_strategy(case, target):
    """Optional E research strategy, not a general safe deployment default.

    Retry only a need_facts baseline. Adopt only a certified retry. Never merge
    failed-path demands, dependencies or reads into the selected attempt.
    """
    baseline = certify(case, target, 2)
    retry = certify(case, target, 3) if baseline['status'] == 'need_facts' else None
    adopted = retry is not None and retry['status'] == 'certified'
    return dict(selected=deepcopy(retry if adopted else baseline), baseline=baseline, retry=retry,
                retried=retry is not None, adopted=adopted,
                total_steps=baseline['steps'] + (retry['steps'] if retry else 0))


def first_changed_read(result, case):
    """Read-set validity, distinct from a certificate's narrower proof support."""
    if case.get('closed', False):
        return 'identity'
    data = _Input(case)
    for key, old in result['reads'].items():
        parts = key.split(':')
        if key == 'identity':
            new = data.identity
        elif key == 'settings':
            new = data.settings
        elif parts[0] == 'analysis':
            new = data.analysis(int(parts[1]))
        elif parts[0] == 'header':
            new = _fact(data.items[int(parts[1])].get('header'))
        elif parts[0] == 'dimension':
            f = data.effective(int(parts[1]))
            new = dict(f, side='UNKNOWN') if f else None
        else:
            new = data.edge(int(parts[1]), int(parts[2]))
        if new != old:
            return key
    return None


def reads_current(result, case):
    return first_changed_read(result, case) is None


def main():
    """JSONL requests: {op:plan|certify|strategy, case:..., target?:integer}."""
    for line in sys.stdin:
        if not line.strip():
            continue
        request = json.loads(line)
        op, case = request.get('op', 'plan'), request['case']
        if op == 'plan':
            result = complete_plan(case)
        elif op == 'certify':
            result = certify(case, request['target'], request.get('lookbehind', 2))
        elif op == 'strategy':
            result = certify_strategy(case, request['target'])
        else:
            raise ValueError('unknown operation')
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
