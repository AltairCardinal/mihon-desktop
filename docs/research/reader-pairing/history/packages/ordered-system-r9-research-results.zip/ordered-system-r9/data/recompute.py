"""Recompute deterministic summaries from the distributed, unfiltered projection."""
import argparse
import hashlib
import json
import statistics
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
COUNTS = {'owner':1800,'memo':792,'partial':630,'direction':72,'kernels':405,'scheduling':162}
DIMENSIONS = ('source','kind','scenario','n','config','candidate','staged','edge_needed','domain')
METRICS = ('elapsed_ns','policy_lifecycle_ns','thread_allocated_bytes','runs','hits','reads','steps',
           'attempts','exactReads','structure_weight','gates','candidates','supported','evaluations',
           'frontier','stops','starts','completions','cancellations','queued_drops','max_physical',
           'admitted','stale','sample_reads','service_stages','different_units','positions')

def recompute():
    output = {}
    for name,count in COUNTS.items():
        path = HERE / (name+'.jsonl')
        rows = [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines()]
        assert len(rows) == count, (name,len(rows),count)
        groups = defaultdict(list)
        for row in rows:
            if row.get('warmup',False): continue
            key = tuple((k,row[k]) for k in DIMENSIONS if k in row)
            groups[key].append(row)
        cells = []
        for key,items in sorted(groups.items(),key=lambda x:repr(x[0])):
            cell = dict(key)
            cell['records'] = len(items)
            cell['process_indices'] = sorted({r['process_index'] for r in items})
            cell['metrics'] = {}
            for metric in METRICS:
                vals = [r[metric] for r in items if metric in r]
                if vals:
                    cell['metrics'][metric] = {'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
            cell['per_process_medians'] = {
                str(process): {metric:statistics.median([r[metric] for r in items
                                  if r['process_index']==process and metric in r])
                               for metric in METRICS if any(metric in r and r['process_index']==process for r in items)}
                for process in cell['process_indices']}
            cell['output_signatures'] = sorted({str(r.get('checksum',r.get('output_sha256','unspecified'))) for r in items})
            cells.append(cell)
        output[name] = {'records':len(rows),'warmup_records':sum(bool(r.get('warmup',False)) for r in rows),
                        'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'cells':cells}
        comparisons = []
        for cell in cells:
            dims = {k:cell[k] for k in DIMENSIONS if k in cell}
            baseline = dict(dims)
            if name=='owner': baseline.update(source='corrected',config='default')
            elif name=='memo': baseline['config']='union-global'
            elif name=='partial': baseline['config']='L0'
            elif name=='direction': baseline['config']='recompute'
            elif name=='kernels' and cell.get('kind')=='score': baseline['candidate']='frozen'
            elif name=='kernels' and cell.get('kind')=='complete_lifecycle': baseline['candidate']='canonical'
            elif name=='scheduling':
                baseline['config'] = 'strict' if cell.get('scenario')=='fairness' else (
                    'immediate' if str(cell.get('scenario','')).startswith('churn-') else 'fixed')
            else: continue
            match = [b for b in cells if {k:b[k] for k in DIMENSIONS if k in b}==baseline]
            assert len(match)==1,(name,baseline)
            base = match[0]
            ratios = {metric:cell['metrics'][metric]['median']/base['metrics'][metric]['median']
                      for metric in ('elapsed_ns','policy_lifecycle_ns','thread_allocated_bytes')
                      if metric in cell['metrics'] and base['metrics'][metric]['median']>0}
            paired = {process:{metric:values[metric]/base['per_process_medians'][process][metric]
                               for metric in ('elapsed_ns','policy_lifecycle_ns','thread_allocated_bytes')
                               if metric in values and base['per_process_medians'][process].get(metric,0)>0}
                      for process,values in cell['per_process_medians'].items()
                      if process in base['per_process_medians']}
            comparisons.append({'cell':dims,'baseline':baseline,'pooled_median_ratios':ratios,
                                'same_process_median_ratios':paired})
        output[name]['comparisons'] = comparisons
    # Equal externally observable signatures on every matched historical comparison cell.
    by_cell = defaultdict(set)
    for row in [json.loads(s) for s in (HERE/'owner.jsonl').read_text(encoding='utf-8').splitlines()]:
        by_cell[(row['scenario'],row['n'],row['config'])].add(row['checksum'])
    assert len(by_cell) == 40 and all(len(x)==1 for x in by_cell.values())
    output['checks'] = {'matched_owner_signature_cells':len(by_cell),'all_owner_signatures_equal':True}
    return output

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--check',action='store_true')
    args = parser.parse_args()
    text = json.dumps(recompute(),indent=2,sort_keys=True)+'\n'
    target = HERE/'aggregates.json'
    if args.check:
        assert target.read_text(encoding='utf-8') == text, 'aggregate mismatch'
        print('PASS: six datasets, counts, 40 matched cells, hashes and all aggregate cells')
    else:
        target.write_text(text,encoding='utf-8')
        print('Wrote aggregates.json')
