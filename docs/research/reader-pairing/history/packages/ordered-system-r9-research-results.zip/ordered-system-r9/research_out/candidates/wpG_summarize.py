"""Aggregate WP-G raw results into results/summary/wpG/summary.json (pure aggregation, no new runs)."""
import json
from collections import defaultdict
from pathlib import Path

RAW = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpG'
OUT = Path(__file__).resolve().parents[1] / 'results' / 'summary' / 'wpG'


def load(n):
    return json.loads((RAW / f'{n}.json').read_text())


def agg(rows, keys, fields):
    acc = defaultdict(lambda: defaultdict(int))
    for r in rows:
        k = '|'.join(str(r[x]) for x in keys)
        acc[k]['runs'] += 1
        for f in fields:
            v = r.get(f, 0)
            acc[k][f] += int(v) if isinstance(v, bool) else v
    return {k: dict(v) for k, v in sorted(acc.items())}


def main():
    s = {'schema': 'wpG-summary-v1', 'layers': {}}
    g01 = load('g01_support')
    owner = defaultdict(lambda: defaultdict(int))
    for row in g01['trace_counts']:
        for v in ('incumbent', 'fact_support', 'proj_support'):
            for f, x in row[v].items():
                owner[f"{row['mix']}|{v}"][f] += x
    s['G01_support'] = dict(aggregate=g01['aggregate'], per_mix=dict(owner))
    cf = ('physical_admissions', 'total_latency_u', 'published', 'intents', 'wrong', 'horizon_hit', 'rank_computations', 'raw_evictions')
    s['K01_tuning'] = agg(load('k01_coupled')['rows'], ('family', 'raw_capacity', 'variant'), cf)
    d4 = load('d4_k01_heldout')
    s['K01_D4_heldout'] = dict(by=agg(d4['rows'], ('family', 'raw_capacity', 'variant'),
                                     ('physical_admissions', 'total_latency_u', 'published', 'intents', 'wrong', 'horizon_hit')),
                               derive_worse_than_lru=d4['derive_worse_than_lru'])
    pf = ('first_publications', 'published_at_end', 'wrong_current', 'reissued', 'revoked', 'publication_read_checks',
          'certification_calls', 'certs_live', 'certs_collected')
    s['G05_G06'] = dict(by=agg(load('g05_g06_coupled')['rows'], ('family', 'variant'), pf),
                        **{k: v for k, v in load('g05_g06_coupled').items() if k != 'rows'})
    s['X20_D4_proj_reissue'] = agg(load('d4_proj_reissue')['rows'], ('family', 'variant'),
                                   ('first_publications', 'published_at_end', 'wrong', 'wrong_current', 'engine_runs',
                                    'memo_hits', 'reissued', 'publication_read_checks'))
    s['X20_invalid_first_run'] = agg(load('d4_proj_reissue_INVALID_policy_support_leak')['rows'], ('family', 'variant'),
                                     ('published_at_end', 'wrong', 'memo_hits', 'reissued'))
    k02 = load('k02_k03_retention')
    s['K02_K03'] = dict(bytes_per_key=k02['bytes_per_key_measured'], weight_model_rel_error=k02['weight_model_rel_error'],
                        by=agg(k02['rows'], ('variant',), ('engine_runs', 'scan_steps', 'memo_hits', 'evictions', 'clock_samples')),
                        verdicts_identical=len({r['verdict'] for r in k02['rows'] if r['seed'] == 0}) == 1)
    s['K05'] = agg(load('k05_split')['rows'], ('total', 'raw_capacity', 'memo_capacity'),
                   ('physical_admissions', 'total_latency_u', 'engine_runs', 'wrong'))
    for n in ('k04_negative', 'k06_adversary', 'l01_transitions', 'l03_operator', 'g02_sharing', 'm03_fault_pairing',
              'm04_censoring', 'm05_noninferiority', 't03_gap', 'x11_features', 'm01_m02_identifiability',
              'm06_counter_oracle', 'l04_locality', 'l05_views', 'l06_instrument', 'g04_noop'):
        s[n] = load(n)
    for x in ('x11', 'x18', 'x19', 'x20', 'x26', 'x27', 'x28'):
        d = load(f'combo_{x}')
        s[f'combo_{x}'] = {k: v for k, v in d.items() if k != 'arms'} | {'arms': d.get('arms')}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'summary.json').write_text(json.dumps(s, indent=1, sort_keys=True, allow_nan=False))
    return s


if __name__ == '__main__':
    s = main()
    for k in ('K01_D4_heldout', 'X20_D4_proj_reissue', 'G05_G06', 'K02_K03'):
        print(k, json.dumps(s[k])[:1500])
