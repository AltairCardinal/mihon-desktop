"""Main-session completions for Q02 (persistent derived index break-even) and
X12 (progressive in-stream service x staged acquisition), both executable.

Q02 (hypothesis branch, never default): three stores keyed by full content
identity (id, content_version, rotation, orientation, recipe version):
  scalar   - analysis + derived directional ranks (JSON-serialised)
  witness  - the 50 packed features of each side (enough to recompute any rank
             with OPTIMIZED_OPERATOR.score in either direction)
  none     - re-acquire (service, cost parameter A)
A direction change makes stored scalar ranks useless (ranks are directional),
while stored witnesses still answer it (score is recomputed).

X12: real element counts from OPTIMIZED_OPERATOR's exact early-null exit.
  in-stream progressive: one service open, read features until the exact
     operator decides (null by distance at element k, else all 50)
  second stage: stage 1 reads analysis only; stage 2 (a second open) reads all
     50 features only if a rank is still needed
"""
import json
import random
import time

import paths  # noqa: F401
import OPTIMIZED_OPERATOR as OP


def pack(cov, a, b, c):
    return (cov << 24) | (a << 16) | (b << 8) | c


def random_witness(rng, base=None, spread=40):
    out = []
    for k in range(OP.COUNT):
        if base is None:
            v = [rng.randrange(40, 216) for _ in range(3)]
        else:
            b = base[k]
            v = [min(255, max(0, ((b >> s) & 255) + rng.randrange(-spread, spread + 1))) for s in (16, 8, 0)]
        out.append(pack(255, *v))
    return out


def elements_until_decision(first, second):
    """Exact count of feature pairs the reference operator reads before returning
    (early null by distance), else COUNT."""
    total = 0
    for k, (x, y) in enumerate(zip(first, second)):
        a, b = OP.normalize(x), OP.normalize(y)
        total += sum(abs(u - v) for u, v in zip(a, b))
        if total >= 30 * OP.COUNT:
            return k + 1
    return OP.COUNT


def x12_study(seed=12, pairs=400):
    rng = random.Random(seed)
    rows = []
    for spread in (5, 20, 60, 120):
        counts = []
        nulls = 0
        for _ in range(pairs):
            a = random_witness(rng)
            b = random_witness(rng, a, spread)
            k = elements_until_decision(a, b)
            counts.append(k)
            nulls += OP.score(a, b) is None
        rows.append(dict(spread=spread, mean_elements=sum(counts) / len(counts), early_null_fraction=nulls / pairs,
                         full_reads=sum(1 for c in counts if c == OP.COUNT) / pairs))
    return rows


def x12_cost(open_cost, elem_cost, mean_elements, p_rank_needed):
    """Expected cost per item: in-stream progressive vs two-stage (labelled u)."""
    progressive = open_cost + elem_cost * mean_elements
    staged = open_cost + p_rank_needed * (open_cost + elem_cost * OP.COUNT)
    both = open_cost + p_rank_needed * (open_cost + elem_cost * mean_elements)
    return dict(progressive=progressive, staged=staged, staged_plus_progressive=both)


# ------------------------------------------------------------------ Q02
class Store:
    def __init__(self, kind):
        self.kind, self.data, self.bytes, self.ns = kind, {}, 0, 0

    def put(self, key, value):
        t = time.perf_counter_ns()
        blob = json.dumps(value, separators=(',', ':'))
        self.data[json.dumps(key)] = blob
        self.bytes += len(blob)
        self.ns += time.perf_counter_ns() - t

    def get(self, key):
        t = time.perf_counter_ns()
        blob = self.data.get(json.dumps(key))
        v = json.loads(blob) if blob is not None else None
        self.ns += time.perf_counter_ns() - t
        return v


def q02_study(seed=2, n=40, visits=4, direction_flip=True):
    """Visits a sequence n times; between visits optionally flips the direction.
    Returns hits/misses (re-acquisitions) and local ns per store kind."""
    rng = random.Random(seed)
    witnesses = [random_witness(rng) for _ in range(n)]
    out = {}
    for kind in ('none', 'scalar', 'witness'):
        st = Store(kind)
        reacq = recompute_ns = 0
        direction = 'AB'
        for v in range(visits):
            for i in range(n - 1):
                key = ('i%d' % i, 0, 0, 1, 'recipe1', direction) if kind == 'scalar' else ('i%d' % i, 0, 0, 1, 'recipe1')
                got = st.get(key) if kind != 'none' else None
                if got is None:
                    reacq += 1
                    if kind == 'scalar':
                        a, b = witnesses[i], witnesses[i + 1]
                        st.put(key, {'v': OP.score(a, b) if direction == 'AB' else OP.score(b, a)})
                    elif kind == 'witness':
                        st.put(key, witnesses[i])
                elif kind == 'witness':
                    t = time.perf_counter_ns()
                    nxt = st.get(('i%d' % (i + 1), 0, 0, 1, 'recipe1'))
                    if nxt is None:
                        reacq += 1
                        st.put(('i%d' % (i + 1), 0, 0, 1, 'recipe1'), witnesses[i + 1])
                        nxt = witnesses[i + 1]
                    OP.score(got, nxt) if direction == 'AB' else OP.score(nxt, got)
                    recompute_ns += time.perf_counter_ns() - t
            if direction_flip:
                direction = 'BA' if direction == 'AB' else 'AB'
        out[kind] = dict(reacquisitions=reacq, store_bytes=st.bytes, store_ns=st.ns, recompute_ns=recompute_ns)
    return out
