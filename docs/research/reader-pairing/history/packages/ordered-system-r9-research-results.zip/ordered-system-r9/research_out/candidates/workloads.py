"""Coupled workloads (ADVERSARIAL_WORKLOADS families) as fixed exogenous traces.

Every trace = dict(initial=<admitted partial case>, world=[witness dicts],
events=[...]); the world is harness-only.  Generators are deterministic in
their seed and are frozen before any policy runs.
"""
import random
from copy import deepcopy

import paths  # noqa: F401
from common import fact, base_case


def _world(rng, n, p_wide=0.1, side_mix=True, raw_max=12):
    w = []
    for i in range(n):
        st = 'WIDE' if rng.random() < p_wide else 'NARROW'
        side = rng.choice(('A', 'B', 'UNKNOWN', 'UNKNOWN')) if side_mix else 'UNKNOWN'
        w.append(dict(analysis=dict(status='computed', fact=fact(st, side), version=1),
                      raw=rng.randrange(0, raw_max), available=True))
    return w


def _edges_from(world, pairs):
    out = []
    for a in pairs:
        ra, rb = world[a]['raw'], world[a + 1]['raw']
        out.append(dict(first=a, second=a + 1, status='computed',
                        score=None if ra is None or rb is None else abs(ra - rb), version=1))
    return out


def _initial(world, known_items, known_edges, automatic=True, direction='AB'):
    n = len(world)
    c = base_case(n, automatic=automatic, direction=direction)
    for i, it in enumerate(c['items']):
        it['header'] = deepcopy(world[i]['analysis']['fact'])
        it['header']['side'] = 'UNKNOWN'
        it['analysis'] = deepcopy(world[i]['analysis']) if i in known_items else {'status': 'unknown'}
    c['edges'] = _edges_from(world, sorted(known_edges))
    return c


def _targets(rng, n, pattern, count, gap):
    t, d, out = rng.randrange(n), 1, []
    for k in range(count):
        if pattern == 'sweep':
            t = (t + 1) % n
        elif pattern == 'jump':
            t = rng.randrange(n)
        elif pattern == 'roundtrip':
            if not 0 <= t + d < n:
                d = -d
            t += d
        out.append(dict(at=k * gap, op='target', target=t))
    return out


def w05_raw_eviction(seed, n=24, holes=4, pattern='sweep', count=24, gap=10):
    """All analyses admitted; a few adjacent ranks missing because their raw
    witnesses were evicted (Session starts with an empty raw store)."""
    rng = random.Random(seed)
    world = _world(rng, n)
    missing = set(rng.sample(range(n - 1), holes))
    init = _initial(world, set(range(n)), [a for a in range(n - 1) if a not in missing])
    return dict(name=f'W05_n{n}_h{holes}_{pattern}_s{seed}', initial=init, world=world,
                events=_targets(rng, n, pattern, count, gap))


def random_partial(seed, n=24, pa=0.6, pe=0.6, pattern='sweep', count=24, gap=10):
    rng = random.Random(seed)
    world = _world(rng, n)
    known = {i for i in range(n) if rng.random() < pa}
    edges = [a for a in range(n - 1) if rng.random() < pe]
    init = _initial(world, known, edges)
    return dict(name=f'RP_n{n}_pa{pa}_pe{pe}_{pattern}_s{seed}', initial=init, world=world,
                events=_targets(rng, n, pattern, count, gap))


def w06_complete_analysis_ambiguous(seed, n=12, count=12, gap=10):
    """All analyses admitted, every rank missing: shared rank variables keep
    several canonical units possible for many targets; strong proof must not
    certify those."""
    rng = random.Random(seed)
    world = _world(rng, n, p_wide=0.0, side_mix=False)
    init = _initial(world, set(range(n)), [])
    return dict(name=f'W06_n{n}_s{seed}', initial=init, world=world,
                events=_targets(rng, n, 'sweep', count, gap))


def w01_phase_chain(seed, n=32, count=16, gap=10, holes=2):
    """Decreasing-rank chain (phase sensitivity) with a few missing ranks."""
    rng = random.Random(seed)
    world = []
    for i in range(n):
        world.append(dict(analysis=dict(status='computed', fact=fact('NARROW', 'UNKNOWN'), version=1),
                          raw=(n - i) * (n - i + 1) // 2, available=True))  # strictly decreasing gaps
    missing = set(rng.sample(range(1, n - 1), holes))
    init = _initial(world, set(range(n)), [a for a in range(n - 1) if a not in missing])
    return dict(name=f'W01_n{n}_h{holes}_s{seed}', initial=init, world=world,
                events=_targets(rng, n, 'jump', count, gap))


def w02_islands(seed, n=24, island=6, count=16, gap=10):
    """Two fully known islands separated by an unknown bridge."""
    rng = random.Random(seed)
    world = _world(rng, n)
    a0 = rng.randrange(0, n // 2 - island)
    b0 = rng.randrange(n // 2, n - island)
    known = set(range(a0, a0 + island)) | set(range(b0, b0 + island))
    edges = [a for a in range(n - 1) if a in known and a + 1 in known]
    init = _initial(world, known, edges)
    return dict(name=f'W02_n{n}_s{seed}', initial=init, world=world,
                events=_targets(rng, n, 'jump', count, gap))


FAMILIES = {
    'W05': w05_raw_eviction,
    'RP': random_partial,
    'W06': w06_complete_analysis_ambiguous,
    'W01': w01_phase_chain,
    'W02': w02_islands,
}
