"""Strong (L1) certification wired into the coupled Session.

The L0 verdict of the corrected owner is always computed first and is never
rewritten when it is `certified` or `blocked`.  Only a `need_facts` verdict may
be upgraded by a strong attempt over the *admitted* evidence (never World):

  kind   'tree'      independent-leaf relation tree (round-8 reproduction of the
                     frontier route one, 10-state encoding)
         'exact'     shared-assignment frontier DP from the true initial state
         'portfolio' tree, then exact only if the tree is not a singleton
  domain 'ext' | 'nonneg' | 'G0'   (rank completions; a known score outside the
                     declared domain silently widens to 'ext', reference: FORMAL §2)
  alpha  header authority (producer contract) or not (beta)
  gate   'sound'  - accept any complete singleton proof
         'raw'    - additionally every item in the support scope has an accepted
                     computed analysis (ALGORITHM_FRONTIER 'supported' gate)
  budget maximum step evaluations of the attempt; exceeding it stops the attempt
         and issues nothing (work stays charged).

Support of a strong certificate: typed owner reads of analysis/header/dimension
for every position in [0, min(n-1, t+3)] and rank of every edge in that range.
Lemma (proofs/R9_PROOFS.md, S-1): every leaf the attempt composes reads only
facts in that range, so equality of these reads implies the same proof.
"""
import time
from copy import deepcopy

import paths  # noqa: F401
import compact_core as core
import transducer as T
import omega as O
from coupling import Session
from current_baseline import typed


class Budget(Exception):
    pass


class _Counter:
    def __init__(self, limit):
        self.n, self.limit = 0, limit

    def tick(self, k=1):
        self.n += k
        if self.limit is not None and self.n > self.limit:
            raise Budget()


def _explore_counted(counter):
    orig = T.explore

    def explore(ctx, fn, base=None):
        out = orig(ctx, fn, base)
        counter.tick(max(1, len(out)))
        return out
    return orig, explore


def strong_attempt(case, target, kind='tree', domain='nonneg', alpha=False, budget=None):
    """Returns dict(status in certified|ambiguous|stopped|error, unit, evaluations, ns)."""
    counter = _Counter(budget)
    orig, counted = _explore_counted(counter)
    t0 = time.perf_counter_ns()
    T.explore = counted
    O.T.explore = counted
    try:
        F = T.Facts(case, 'omega', domain, alpha)
        if not F.domain_ok:
            F = T.Facts(case, 'omega', 'ext', alpha)
        if kind in ('tree', 'portfolio'):
            tree = T.RelTree(F)
            units = tree.units(target)
            if len(units) == 1:
                return dict(status='certified', unit=next(iter(units.values())), evaluations=counter.n,
                            ns=time.perf_counter_ns() - t0, route='tree', domain=F.domain)
            if kind == 'tree':
                return dict(status='ambiguous', unit=None, evaluations=counter.n,
                            ns=time.perf_counter_ns() - t0, route='tree', domain=F.domain)
        st, u = O.certify_exact(case, target, F.domain, alpha,
                                limit=(budget if budget is not None else 400000))
        if st == 'limit':
            raise Budget()
        return dict(status='certified' if st == 'certified' else 'ambiguous',
                    unit=u if st == 'certified' else None, evaluations=counter.n,
                    ns=time.perf_counter_ns() - t0, route='exact', domain=F.domain)
    except Budget:
        return dict(status='stopped', unit=None, evaluations=counter.n, ns=time.perf_counter_ns() - t0,
                    route=kind, domain=domain)
    finally:
        T.explore = orig
        O.T.explore = orig


def support_keys(n, target):
    hi = min(n - 1, target + 3)
    keys = []
    for p in range(0, hi + 1):
        keys += [('analysis', p), ('header', p), ('dimension', p)]
    for a in range(0, min(n - 2, hi) + 1):
        keys.append(('rank', a, a + 1))
    return keys


class StrongSession(Session):
    """Session with an additional certification mode 'S' (strong L1)."""

    def __init__(self, case, *, strong=None, **kw):
        super().__init__(case, **kw)
        self.strong = dict(kind='tree', domain='nonneg', alpha=False, gate='raw', budget=None)
        self.strong.update(strong or {})
        self.strong_log = []

    def certify(self, target, *, mode='L0', budget=None):
        if mode != 'S':
            return super().certify(target, mode=mode, budget=budget)
        base = super().certify(target, mode='L0', budget=budget)
        if base['status'] != 'need_facts':
            return base
        cfg = self.strong
        case = self.owner._case
        att = strong_attempt(case, target, cfg['kind'], cfg['domain'], cfg['alpha'], cfg['budget'])
        n = len(case['items'])
        keys = support_keys(n, target)
        index = self.owner._index()
        support = {k: self.owner._read(index, k) for k in keys}
        gated = att['status'] == 'certified'
        if gated and not att['unit']['certain']:
            gated = False
        if gated and cfg['gate'] == 'raw':
            gated = all(index.analysis(p)[0] == 'computed' for p in range(0, min(n - 1, target + 3) + 1))
        self.metrics['strong_attempts'] += 1
        self.metrics['strong_evaluations'] += att['evaluations']
        self.metrics['strong_support_keys'] += len(keys)
        self.metrics['strong_ns'] += att['ns']
        self.strong_log.append(dict(target=target, status=att['status'], gated=gated, evaluations=att['evaluations'],
                                    ns=att['ns'], route=att['route']))
        if not gated:
            if att['status'] == 'stopped':
                self.metrics['strong_stops'] += 1
            return base
        self.metrics['strong_certificates'] += 1
        self._next_certificate += 1
        handle = self._next_certificate
        unit = deepcopy(att['unit'])
        self._certs[handle] = dict(target=target, unit=unit, guard=self.owner._guard(), epoch=self.epoch,
                                  support=support)
        return dict(status='certified', unit=deepcopy(unit), needs=[], failures={}, first=0,
                    steps=att['evaluations'], dependent_items=list(range(0, min(n - 1, target + 3) + 1)),
                    certificate=handle, route='strong-' + att['route'])
