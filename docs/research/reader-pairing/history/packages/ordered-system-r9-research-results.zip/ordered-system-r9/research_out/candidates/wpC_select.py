"""WP-C online selection among linear / resync / tree (P01, P04, P05, P06, X06).

Every selector answers queries exactly (complete_plan semantics); selection can
only change cost.  Work unit (deterministic, reported with wall time):
    work = scan_steps + 5 * leaf_evals          (leaf_fast = 5 step evaluations)
node compositions and probes are counted separately.

Selectors
  Hybrid(cap, D)     C03 threshold automaton (single-update cap, D quiet updates)
  SkiRental(alpha)   promote when the accumulated *excess* resync propagation
                     since the last switch reaches alpha*n (the build bound);
                     demote when the accumulated tree surplus over a local repair
                     reaches the rescan bound n.  Ski-rental *style* only: NO
                     competitive bound is claimed - the adaptive adversary in
                     P01 drives it to 3.49-3.76x the model OPT (proofs/wpC.md P01).
  Advised(advice, max_switch_rate) P06: an external advisor proposes a mode;
                     switches are rate-limited; advice never touches answers.
"""
from collections import Counter

import paths  # noqa: F401
import transducer as T
from wpC_structures import Hybrid, LazyTree, _Base, _step, _unit_from_states


def work_units(w):
    return w.get('steps', 0) + w.get('resync_steps', 0) + 5 * w.get('leaf_evals', 0)


class SkiRental(Hybrid):
    name = 'skirental'

    def __init__(self, case, alpha=1.0, local=8):
        super().__init__(case, cap=10 ** 9, quiet_to_demote=10 ** 9)
        self.alpha, self.local = alpha, local
        self.excess = 0          # resync steps beyond the local window since last switch
        self.surplus = 0         # tree cost surplus while promoted

    def _changed(self, lo, hi):
        if self.tree is not None:
            before_leaf = self.work['leaf_evals']
            probe = min(self.n, hi + 2)
            b = self.tree.state(probe)
            LazyTree._changed(self.tree, lo, hi)
            a = self.tree.state(probe)
            self.work['tree_probes'] += 2
            self.valid = min(self.valid, max(0, lo - 3))
            cost_tree = 5 * (self.work['leaf_evals'] - before_leaf) + 2
            if a == b:                       # a local repair would have converged within the window
                self.surplus += max(0, cost_tree - self.local)
                if self.surplus >= self.n:
                    self.work['demotions'] += 1
                    self.tree = None
                    self.surplus = 0
                    self.excess = 0
            else:
                self.surplus = 0
            return
        before = self.work['resync_steps']
        Hybrid._changed(self, lo, hi)
        steps = self.work['resync_steps'] - before
        self.excess += max(0, steps - self.local)
        if self.tree is None and self.excess >= self.alpha * self.n:
            # promote: identical machinery to Hybrid's cap overflow
            self.valid = min(self.valid, max(0, lo - 3))
            self._promote()
            self.excess = 0

    def _promote(self):
        t = LazyTree.__new__(LazyTree)
        t.F, t.ctx, t.n, t.work = self.F, self.ctx, self.n, self.work
        size = 1
        while size < max(1, self.n):
            size *= 2
        t.size, t.leaves, t.nodes = size, [None] * self.n, [None] * (2 * size)
        self.tree = t
        self.work['promotions'] += 1


class FixedTree(LazyTree):
    name = 'fixedtree'


class FixedResync(Hybrid):
    name = 'fixedresync'

    def __init__(self, case):
        super().__init__(case, cap=10 ** 9, quiet_to_demote=10 ** 9)


class Advised(Hybrid):
    """P06: modes switched only on advice, at most one switch per `gap` updates."""
    name = 'advised'

    def __init__(self, case, advice, gap=16):
        super().__init__(case, cap=10 ** 9, quiet_to_demote=10 ** 9)
        self.advice, self.gap, self.since = advice, gap, gap
        self.k = 0

    def _changed(self, lo, hi):
        want = self.advice(self.k)
        self.k += 1
        self.since += 1
        if self.since >= self.gap:
            if want == 'tree' and self.tree is None:
                self.valid = min(self.valid, max(0, lo - 3))
                SkiRental._promote(self)
                self.since = 0
            elif want == 'resync' and self.tree is not None:
                self.tree = None
                self.work['demotions'] += 1
                self.since = 0
        if self.tree is not None:
            LazyTree._changed(self.tree, lo, hi)
            self.valid = min(self.valid, max(0, lo - 3))
            return
        Hybrid._changed(self, lo, hi)


def offline_opt(costs_R, costs_T, S_RT, S_TR):
    """Offline optimum with switching costs (DP), per-event costs given."""
    INF = float('inf')
    r, t = 0.0, S_RT
    for cr, ct in zip(costs_R, costs_T):
        r, t = min(r + cr, t + S_TR + cr), min(t + ct, r + S_RT + ct)
    return min(r, t)


class SkiQuiet(SkiRental):
    """X06 A+B, organisation 1: ski-rental promotion + quiet-probe demotion (D quiet updates)."""
    name = 'skiquiet'

    def __init__(self, case, alpha=1.0, D=8):
        super().__init__(case, alpha=alpha)
        self.D_quiet = D
        self.q_count = 0

    def _changed(self, lo, hi):
        if self.tree is not None:
            probe = min(self.n, hi + 2)
            b = self.tree.state(probe)
            LazyTree._changed(self.tree, lo, hi)
            a = self.tree.state(probe)
            self.work['tree_probes'] += 2
            self.valid = min(self.valid, max(0, lo - 3))
            self.q_count = self.q_count + 1 if a == b else 0
            if self.q_count >= self.D_quiet:
                self.work['demotions'] += 1
                self.tree = None
                self.q_count = 0
                self.excess = 0
            return
        SkiRental._changed(self, lo, hi)


class SkiKeep(SkiRental):
    """X06 organisation 2: long-lived layered index - once promoted, never demoted."""
    name = 'skikeep'

    def _changed(self, lo, hi):
        if self.tree is not None:
            LazyTree._changed(self.tree, lo, hi)
            self.valid = min(self.valid, max(0, lo - 3))
            return
        SkiRental._changed(self, lo, hi)
