"""S01-S06 / X30 studies (L2, separate from the frozen rule) -> results/raw/wpS/studies.json"""
import json, random, statistics, sys, time, itertools, collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates')); import paths  # noqa
from common import random_case, roundtrip, ref
import wpS_rules as S
import theory_a as A

out = {}; t0 = time.time(); rng = random.Random(901)
cases = [roundtrip(random_case(rng, rng.randrange(4, 40), p_wide=0.12, domain='G0')) for _ in range(800)]
cases += [A.decreasing_chain(n) for n in (16, 32, 48, 64)]
# S01/S02: legality, maximality, pair counts, quality ratio vs maximum cardinality
rows = {r: collections.Counter() for r in S.RULES}
ratio_min = {r: 1.0 for r in S.RULES}
for c in cases:
    n = len(c['items'])
    mc = S.metrics(S.maxcard_plan(c), c)
    for r, f in S.RULES.items():
        p = f(c)
        ok = S.legal(p, n)
        m = S.metrics(p, c)
        rows[r]['legal'] += ok; rows[r]['cases'] += 1; rows[r]['pairs'] += m['pairs']
        rows[r]['maximal'] += m['maximal']; rows[r]['strength'] += m['strength']
        if mc['pairs']:
            ratio_min[r] = min(ratio_min[r], m['pairs'] / mc['pairs'])
diff = {}
for r in S.RULES:
    if r == 'reference': continue
    d = tot = 0
    for c in cases:
        a, b = S.plan_members(ref.complete_plan(c)), S.plan_members(S.RULES[r](c))
        d += sum(a[i] != b[i] for i in a); tot += len(a)
    diff[r] = round(d / tot, 4)
out['S01_S02_structure'] = dict(rules={r: dict(rows[r]) for r in S.RULES}, min_pair_ratio_vs_maxcard=ratio_min,
                                fraction_positions_differing_from_reference=diff,
                                note='quality proxies only (pairs, strength); no external quality truth')
# S04: locality vs agreement curve (edit radius on chains and random), insertion relabel (absolute-position cost)
loc = {}
for r, f in S.RULES.items():
    rr = random.Random(5)
    loc[r] = dict(edit_radius_chain96=S.edit_radius(f, A.decreasing_chain(96), rr, 30),
                  edit_radius_random96=S.edit_radius(f, roundtrip(random_case(random.Random(6), 96, domain='G0', settings_mix=False)), rr, 30),
                  insertion_relabel_chain64=round(S.insertion_relabel(f, A.decreasing_chain(64)), 3),
                  insertion_relabel_random64=round(S.insertion_relabel(f, roundtrip(random_case(random.Random(7), 64, domain='G0', settings_mix=False))), 3))
out['S04_locality'] = loc
# S05: disagreement motifs and the minimal number of adjudication questions separating all rules
mot = {}
names = list(S.RULES)
for a, b in itertools.combinations(names, 2):
    s = set()
    for c in cases[:300]:
        s |= S.motifs(S.RULES[a](c), S.RULES[b](c), c)
    mot[(a, b)] = s
# a 'question' = one motif; it separates rules a,b if it is in their disagreement set
allm = set().union(*mot.values())
pairs_needed = [(a, b) for a, b in itertools.combinations(names, 2) if mot[(a, b)]]
chosen, uncovered = [], set(pairs_needed)
while uncovered:
    best = max(allm, key=lambda m: sum(1 for p in uncovered if m in mot[p]))
    cov = {p for p in uncovered if best in mot[best and p] } if False else {p for p in uncovered if best in mot[p]}
    if not cov: break
    chosen.append(best); uncovered -= cov
out['S05_adjudication'] = dict(rules=names, motif_classes_total=len(allm),
                               disagreement_motifs_per_pair={f'{a}|{b}': len(mot[(a, b)]) for a, b in itertools.combinations(names, 2)},
                               greedy_separating_questions=len(chosen), unseparated_pairs=sorted(map(list, uncovered)),
                               note='a motif = canonical +-3 window (wide/allowed/strength/nullness + adjacent order bits); '
                                    'if user preferences are local over such windows, this many judgments suffice to rank all rules')
# S03: migration cost reference -> lmp under per-unit migration vs new context
mig = collections.Counter()
for c in cases:
    a, b = ref.complete_plan(c), S.lmp_plan(c)
    ka = {tuple(s['item'] for s in u['slots']): u for u in a}
    kb = {tuple(s['item'] for s in u['slots']): u for u in b}
    same = sum(1 for k, u in ka.items() if k in kb and kb[k] == u)
    mig['units'] += len(a); mig['unchanged_units'] += same; mig['changed_old_units'] += len(a) - same
    mig['new_units_to_publish'] += sum(1 for k, u in kb.items() if not (k in ka and ka[k] == u))
out['S03_migration'] = dict(dict(mig), new_context_republish=mig['units'],
    per_unit_republish=mig['new_units_to_publish'],
    note='per-unit migration: revoke changed old units, then publish new ones; unchanged units are re-signed under '
         'the new context without visible change (both are partitions, so no transient overlap); certificates and '
         'confirmations never carry over (authority is per context)')
# S06 / X30: certification locality - reference lookback vs LMP constant window, complete knowledge
look = []
for c in cases[:400]:
    n = len(c['items'])
    for t in (n // 2, n - 1):
        r = ref.certify(c, t)
        if r['status'] == 'certified':
            look.append(t - r['first'])
look.sort()
out['S06_locality_gain'] = dict(reference_lookback_quantiles={q: look[int(q * (len(look) - 1))] for q in (0.5, 0.9, 0.99, 1.0)},
    lmp_dependency_window='positions t-6..t+6 plus pinned-run length (proofs/R8 H5)',
    chain_lookback=[(n, n - 1 - ref.certify(A.decreasing_chain(n), n - 1)['first']) for n in (16, 64, 256)],
    note='L2 locality buys O(1) certificate support only on long phase chains; on random inputs the reference '
         'lookback is already small, so the in-semantics residual gain bounds the L2 benefit')
out['seconds'] = round(time.time() - t0, 1)
Path('results/raw/wpS').mkdir(parents=True, exist_ok=True)
Path('results/raw/wpS/studies.json').write_text(json.dumps(out, indent=1, default=str))
print(json.dumps({k: v for k, v in out.items()}, indent=1, default=str)[:6000])
