"""T05: residual-gain reference points on small coupled workloads -> results/raw/wpT/t05.json"""
import json, sys, time, collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates')); import paths  # noqa
import workloads as W, coupled_runner as CR, wpT_bounds as TB

out = []; t0 = time.time()
fams = [('W06', lambda s: W.w06_complete_analysis_ambiguous(s, n=10, count=10)),
        ('RP', lambda s: W.random_partial(s, n=12, count=12)),
        ('W01', lambda s: W.w01_phase_chain(s, n=12, count=10, holes=3)),
        ('W05', lambda s: W.w05_raw_eviction(s, n=12, holes=4, count=12))]
for fam, gen in fams:
    agg = collections.defaultdict(collections.Counter)
    for seed in range(4):
        tr = gen(seed)
        runs = {
            'incumbent': CR.Runner(tr, policy='incumbent', service_u=3).run(),
            'strong_exact_q0': CR.Runner(tr, policy='strong_only', service_u=3,
                                         strong=dict(kind='exact', domain='nonneg', gate='sound')).run(),
            'oracle_min': TB.OracleRunner(tr, service_u=3).run(),
        }
        for k, r in runs.items():
            for f in ('physical_admissions', 'total_latency_u', 'published', 'intents', 'wrong'):
                agg[k][f] += r[f]
    out.append(dict(family=fam, **{k: dict(v) for k, v in agg.items()}))
    print(fam, {k: dict(v) for k, v in agg.items()}, flush=True)
Path('results/raw/wpT').mkdir(parents=True, exist_ok=True)
Path('results/raw/wpT/t05.json').write_text(json.dumps(dict(rows=out, seconds=round(time.time() - t0, 1),
    note='oracle_min reads the hidden world (evaluator-only reference point, not a candidate); '
         'strong_exact_q0 = exact DP with free proofs; both bound what stronger proofs / better choice could save'), indent=1))
