"""WP-G experiment runner: python3 research_out/candidates/wpG_experiments.py [name ...]
Writes research_out/results/raw/wpG/<name>.json.  Single process, capped sizes;
local timings here are exploratory (formal timing: bench/bench_wpG.py via drive_formal)."""
import copy
import gc
import json
import math
import random
import statistics
import sys
import time
import tracemalloc
from pathlib import Path

import paths  # noqa: F401
from common import random_case, roundtrip, fact
import reference as ref
import compact_core as core
from corrected_owner import Owner, Config
import wpG_traces as TR
import wpG_owner as GO
import wpG_repr as RP
import wpG_support as SP
import wpG_retention as RT
import wpG_coupled as GC
import workloads as W

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpG'
OUT.mkdir(parents=True, exist_ok=True)


def save(name, obj):
    (OUT / f'{name}.json').write_text(json.dumps(obj, indent=1, default=str, allow_nan=False))
    print('wrote', name)


def timeit(fn, reps=5):
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter_ns(); fn(); ts.append(time.perf_counter_ns() - t0)
    return statistics.median(ts)


# ------------------------------------------------------------------ G01
def g01_support():
    rng = random.Random(5)
    rows = []
    for k in range(250):
        n = rng.randrange(4, 14)
        c = roundtrip(random_case(rng, n, p_unknown=.25, p_edge_unknown=.25, p_fail=.03))
        t = rng.randrange(n)
        try:
            r = SP.counterfactual_relevance(c, t)
        except Exception as e:
            rows.append(dict(error=repr(e)[:120])); continue
        rows.append(r)
    ok = [r for r in rows if 'error' not in r]
    agg = {k: sum(r[k] for r in ok) for k in ('union_keys', 'union_facts', 'dimension_keys', 'relevant_facts',
                                              'baseline_only_facts', 'baseline_only_relevant')}
    # projection hit gain on traces (counts, deterministic)
    gains = []
    for mix in ('refresh', 'dependent', 'unrelated', 'churn'):
        for seed in range(4):
            tr = TR.generate(seed, n=48, rounds=80, mix=mix)
            row = dict(mix=mix, seed=seed)
            for nm in ('incumbent', 'fact_support', 'proj_support'):
                o = GO.make(nm, tr['initial']); TR.replay(tr, o, collect=False)
                row[nm] = dict(engine_runs=o.metrics['engine_runs'], support_keys_built=o.metrics['support_keys_built'],
                               typed_reads_checked=o.metrics['typed_reads_checked'])
            gains.append(row)
    save('g01_support', dict(cases=len(ok), errors=len(rows) - len(ok), aggregate=agg, rows=rows[:60], trace_counts=gains,
                             note='single-fact counterfactual relevance is an upper bound on droppable facts, not a joint proof'))


# ------------------------------------------------------------------ G02 / L02 / X27
def g02_sharing():
    rng = random.Random(7)
    c = roundtrip(random_case(rng, 256, p_unknown=.2, p_edge_unknown=.2, settings_mix=False))
    o = Owner(c, Config(memo_capacity=200))
    targets = list(range(0, 256, 2))
    for t in targets:
        o.request(t)
    entries = list(o._memo.values())
    keysets = [e['support'] for e in entries]
    total_keys = sum(len(s) for s in keysets)
    distinct_pairs = len({(k, json.dumps(v, default=str)) for s in keysets for k, v in s.items()})
    gc.collect(); tracemalloc.start()
    flat = [RP.FlatSupport(s) for s in keysets]
    flat_bytes = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    gc.collect(); tracemalloc.start()
    dicts = [dict(s) for s in keysets]
    dict_bytes = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    # interning shared (key,value) cells (proof-DAG-like sharing of identical facts)
    gc.collect(); tracemalloc.start()
    table = {}
    interned = [tuple(table.setdefault((k, repr(v)), (k, v)) for k, v in s.items()) for s in keysets]
    intern_bytes = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    # validation cost: dict typed compare vs flat fingerprint (+exact confirm)
    from current_baseline import typed
    idx = o._index()

    def val_dict():
        for s in keysets:
            all(typed(v) == typed(o._read(idx, k)) for k, v in s.items())

    def val_flat():
        for f in flat:
            f.matches(tuple(typed(o._read(idx, k)) for k in f.keys))
    # collision safety
    a = RP.CollidingTyped((1,)); b = RP.CollidingTyped((2,))
    fs = RP.FlatSupport({('analysis', 0): ('x',)}); fs.values = a; fs.fp = hash(a)
    collision_rejected = not fs.matches(b)
    save('g02_sharing', dict(entries=len(entries), total_keys=total_keys, distinct_key_value_cells=distinct_pairs,
                             sharing_ratio=round(total_keys / max(1, distinct_pairs), 2),
                             tracemalloc_bytes=dict(dict_copy=dict_bytes, flat_tuples=flat_bytes, interned_cells=intern_bytes),
                             validate_ns=dict(dict_typed=timeit(val_dict, 3), flat_fp=timeit(val_flat, 3)),
                             collision_detected_and_rejected=collision_rejected,
                             note='single process exploratory; tracemalloc counts objects created by the construction only'))


# ------------------------------------------------------------------ G04
def g04_noop():
    rows = []
    for same in (0.0, 0.3, 0.6, 0.9):
        for chain in (False, True):
            tr = TR.generate(3, n=64, rounds=100, mix='churn', chain=chain, same_rate=same)
            want = TR.truth(tr)
            row = dict(same_rate=same, chain=chain)
            for nm in ('incumbent', 'noop_none', 'noop_hint'):
                o = GO.make(nm, tr['initial'])
                ok = TR.replay(tr, o) == want
                o2 = GO.make(nm, tr['initial'])
                w = timeit(lambda: TR.replay(tr, GO.make(nm, tr['initial']), collect=False), 3)
                row[nm] = dict(ok=ok, wall_ns=w, engine_runs=o.metrics['engine_runs'],
                               support_validations=o.metrics['support_validations'],
                               typed_reads_checked=o.metrics['typed_reads_checked'], stamp_hits=o.metrics['stamp_hits'])
            rows.append(row)
    # wrong producer hint is a contract violation: demonstrate the hazard
    tr = TR.generate(1, n=32, rounds=40, mix='dependent')
    o = GO.GOwner(tr['initial'], noop='hint'); o.request(5)
    a = dict(status='computed', fact=fact('WIDE'), version=99)
    o.apply(item_updates={5: {'analysis': a}}, same={('item', 5)})       # lying hint
    c2 = copy.deepcopy(tr['initial']); c2['items'][5]['analysis'] = a
    lie = o.request(5) != {k: v for k, v in ref.certify_strategy(c2, 5)['selected'].items() if k != 'reads'}
    save('g04_noop', dict(rows=rows, lying_hint_returns_stale=lie,
                          note='exploratory single-process walls (median of 3)'))


# ------------------------------------------------------------------ K01 (+derive order) and K05
def k01_coupled():
    rows = []
    for fam, kw in (('RP', dict(pa=0.3, pe=0.2)), ('RP', dict(pa=0.6, pe=0.3)), ('W02', {}), ('W06', {})):
        for pat in ('sweep', 'roundtrip', 'jump'):
            for seed in range(4):
                if fam == 'RP':
                    tr = W.random_partial(seed, n=32, pattern=pat, count=32, **kw)
                elif fam == 'W06':
                    tr = W.w06_complete_analysis_ambiguous(seed, n=16, count=16)
                else:
                    tr = W.w02_islands(seed)
                for rc in (1, 2, 3):
                    for name, skw in (('lru', {}), ('useless', dict(raw_policy='useless_first')),
                                      ('derive', dict(order='derive_first')),
                                      ('both', dict(raw_policy='useless_first', order='derive_first'))):
                        r = GC.run(tr, skw, raw_capacity=rc, horizon=3000)
                        rows.append(dict(family=fam, kw=kw, pattern=pat, seed=seed, raw_capacity=rc, variant=name,
                                         **{k: r[k] for k in ('physical_admissions', 'total_latency_u', 'raw_evictions',
                                                              'raw_dead_evictions', 'wrong', 'published', 'intents',
                                                              'rank_computations', 'discarded', 'end_u', 'horizon_hit')}))
            if fam != 'RP':
                break
    save('k01_coupled', dict(rows=rows, layer='coupled virtual u + counts'))


def k05_split():
    rows = []
    for total in (4, 6, 8):
        for seed in range(6):
            tr = W.random_partial(seed, n=32, pa=0.4, pe=0.3, pattern='roundtrip', count=32)
            for rc in range(1, total):
                mc = total - rc
                g = GC.GRunner(tr, session_kw=dict(order='derive_first'), raw_capacity=rc)
                g.session.owner.config = Config(memo_capacity=max(1, mc))
                out = g.run()
                om = g.session.owner.metrics
                rows.append(dict(total=total, seed=seed, raw_capacity=rc, memo_capacity=mc,
                                 physical_admissions=out['physical_admissions'], total_latency_u=out['total_latency_u'],
                                 engine_runs=om['engine_runs'], scan_steps=om['scan_steps'], wrong=out['wrong']))
    save('k05_split', dict(rows=rows, note='raw slots and memo entries are different units; total = rc + mc entries (illustrative split)'))


# ------------------------------------------------------------------ G05/G06 coupled
def g05_g06_coupled():
    rows = []
    for fam in ('RP', 'W02', 'W06', 'W01'):
        for seed in range(10):
            tr = W.FAMILIES[fam](seed) if fam != 'RP' else W.random_partial(seed, pa=0.4, pe=0.3, n=24, count=24)
            for name, kw in (('plain', {}), ('reissue', dict(reissue=True)), ('gc', dict(cert_gc=True)),
                             ('reissue_gc', dict(reissue=True, cert_gc=True))):
                g = GC.GRunner(tr, session_kw=kw); out = g.run(); s = g.session
                wrong = sum(1 for t, u in s.published.items() if u != g.truth[t])
                rows.append(dict(family=fam, seed=seed, variant=name, first_publications=out['published'],
                                 published_at_end=len(s.published), certs_live=len(s._certs),
                                 certs_collected=s.metrics['certs_collected'], reissued=s.metrics['reissued_publications'],
                                 revoked=s.metrics['revoked_publications'], wrong_current=wrong,
                                 publication_read_checks=s.metrics['publication_read_checks'],
                                 certification_calls=s.metrics['certification_calls']))
    # rebind lifecycle: old certificates/publications unreachable for publish, memory stable
    tr = W.random_partial(0, pa=0.4, pe=0.3, n=24, count=24)
    from wpG_session import GSession
    s = GSession(tr['initial'], cert_gc=True)
    gc.collect(); tracemalloc.start()
    sizes = []
    for cycle in range(30):
        for t in range(0, 24, 3):
            v = s.certify(t, mode='L0')
            if v['status'] == 'certified':
                s.publish(t, v['certificate'])
        old = dict(s._certs)
        s.rebind(copy.deepcopy(tr['initial']))
        assert all(s.publish(t, h) in ('unsigned', 'stale') for h, c in old.items() for t in [c['target']])
        gc.collect(); sizes.append(tracemalloc.get_traced_memory()[0])
    tracemalloc.stop()
    save('g05_g06_coupled', dict(rows=rows, rebind_cycles=30, retained_bytes_first_last=[sizes[0], sizes[-1]],
                                 retained_bytes_max=max(sizes), old_handles_never_publishable=True))


# ------------------------------------------------------------------ K02/K03/K06/X26
def k02_calibrate():
    rng = random.Random(9)
    c = roundtrip(random_case(rng, 128, p_unknown=.2, p_edge_unknown=.2, settings_mix=False))
    o = Owner(c, Config(memo_capacity=10 ** 6))
    per = []
    for t in range(0, 128, 4):
        gc.collect(); tracemalloc.start()
        o.request(t)
        cur = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
        per.append((len(o._memo[t]['support']), cur))
    keys = sum(k for k, _ in per); byts = sum(b for _, b in per)
    return byts / max(1, keys), per


def k02_k03_retention():
    bpk, per = k02_calibrate()
    # estimate error of the structure-weight model per entry
    errs = [abs(b - bpk * (k + 2)) / max(1, b) for k, b in per]
    rows = []
    for seed in range(4):
        rng = random.Random(seed)
        # skewed: long-chain expensive targets mixed with cheap ones; cyclic working set > capacity
        n = 96
        c = TR._case(rng, n, chain=True, p_unknown=0.0, p_edge_unknown=0.0)
        for it in c['items'][:: 7]:
            it['analysis'] = {'status': 'unknown'}
        seq = []
        for r in range(150):
            seq += [n - 1 - (r % 3) * 9, rng.randrange(0, 12), rng.randrange(0, 12)]
        tr = dict(initial=c, ops=[['req', t] for t in seq])
        sizes = []
        o = Owner(c, Config(memo_capacity=10 ** 6)); TR.replay(tr, o, collect=False)
        mean_keys = statistics.mean(len(e['support']) for e in o._memo.values())
        budget = int(4 * bpk * (mean_keys + 2))          # equal space to 4 average entries
        for nm, kw in (('lru4', dict(policy='lru')), ('bytes', dict(policy='bytes', byte_budget=budget)),
                       ('gds_steps', dict(policy='gds', byte_budget=budget, estimator='steps')),
                       ('gds_clock', dict(policy='gds', byte_budget=budget, estimator='clock', sample=4))):
            o = RT.ROwner(c, policy=kw.pop('policy'), bytes_per_key=bpk, **kw)
            t0 = time.perf_counter_ns(); out = TR.replay(tr, o); wall = time.perf_counter_ns() - t0
            gc.collect(); tracemalloc.start(); o2 = RT.ROwner(c, policy=o.policy, byte_budget=o.byte_budget, estimator=o.estimator,
                                                               bytes_per_key=bpk); TR.replay(tr, o2, collect=False)
            peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
            rows.append(dict(seed=seed, variant=nm, budget_bytes=budget, engine_runs=o.metrics['engine_runs'],
                             scan_steps=o.metrics['scan_steps'], memo_hits=o.metrics['memo_hits'],
                             evictions=o.metrics['memo_evictions'], bypass=o.metrics['oversize_bypasses'],
                             clock_samples=o.metrics['clock_samples'], wall_ns=wall, alloc_peak=peak,
                             verdict=hash(json.dumps(out, sort_keys=True))))
    save('k02_k03_retention', dict(bytes_per_key_measured=round(bpk, 1), weight_model_rel_error=dict(
        median=round(statistics.median(errs), 3), max=round(max(errs), 3)), rows=rows))


def k06_adversary():
    rng = random.Random(2)
    c = roundtrip(random_case(rng, 32, settings_mix=False))
    rows = []
    for cap in (2, 4, 8):
        for pattern in ('cyclic_cap_plus_1', 'cyclic_cap', 'hot_cold'):
            if pattern == 'cyclic_cap_plus_1':
                seq = [j % (cap + 1) for j in range(200)]
            elif pattern == 'cyclic_cap':
                seq = [j % cap for j in range(200)]
            else:
                seq = [0 if j % 2 else rng.randrange(1, 32) for j in range(200)]
            o = Owner(c, Config(memo_capacity=cap))
            for t in seq:
                o.request(t)
            # offline optimum (Belady) misses for comparison
            cache, miss = [], 0
            for i, t in enumerate(seq):
                if t in cache:
                    continue
                miss += 1
                if len(cache) >= cap:
                    def nxt(x):
                        for j in range(i + 1, len(seq)):
                            if seq[j] == x:
                                return j
                        return 10 ** 9
                    cache.remove(max(cache, key=nxt))
                cache.append(t)
            rows.append(dict(capacity=cap, pattern=pattern, requests=len(seq), engine_runs=o.metrics['engine_runs'],
                             belady_misses=miss))
    save('k06_adversary', dict(rows=rows, statement='any deterministic online k-entry policy has a k+1 cyclic sequence missing every request (competitive ratio >= k vs Belady)'))


# ------------------------------------------------------------------ K04
def k04_negative():
    rng = random.Random(4)
    out = dict(cases=0, incumbent_wrong=0, permanent_negative_mutant_wrong=0)
    for k in range(200):
        c = roundtrip(random_case(rng, 10, p_unknown=0.3, p_fail=0.2))
        t = rng.randrange(10)
        o = Owner(c); v = o.request(t)
        if v['status'] not in ('need_facts', 'blocked'):
            continue
        out['cases'] += 1
        # recovery: every failed/unknown analysis becomes computed
        d = copy.deepcopy(c); upd = {}
        for i, it in enumerate(d['items']):
            if it['analysis'].get('status') != 'computed':
                it['analysis'] = dict(status='computed', fact=dict(it['header']), version=5)
                upd[i] = {'analysis': it['analysis']}
        o.apply(item_updates=upd)
        want = {kk: vv for kk, vv in ref.certify_strategy(d, t)['selected'].items() if kk != 'reads'}
        out['incumbent_wrong'] += o.request(t) != want
        out['permanent_negative_mutant_wrong'] += v != want         # a cache keyed by target only
    save('k04_negative', out)


# ------------------------------------------------------------------ L01 / L03 / L05 / L06
def l01_transitions():
    fs = RP.all_functions()
    rng = random.Random(1)
    pairs = [(rng.choice(fs), rng.choice(fs)) for _ in range(20000)]
    exhaustive_ok = all(RP.compose_straight(f, g) == RP.compose_tuple(f, g) for f in fs[::7] for g in fs[::11])
    ok = all(RP.unpack(RP.compose_packed(RP.pack(f), RP.pack(g))) == RP.compose_tuple(f, g)
             and tuple(RP.compose_bytes(RP.as_bytes(f), RP.as_bytes(g))[:5]) == RP.compose_tuple(f, g) for f, g in pairs)
    bp = [(RP.as_bytes(f), RP.as_bytes(g)) for f, g in pairs]
    pp = [(RP.pack(f), RP.pack(g)) for f, g in pairs]
    res = dict(tuple=timeit(lambda: [RP.compose_tuple(f, g) for f, g in pairs]),
               straight=timeit(lambda: [RP.compose_straight(f, g) for f, g in pairs]),
               bytes_translate=timeit(lambda: [f.translate(g) for f, g in bp]),
               packed_int=timeit(lambda: [RP.compose_packed(a, b) for a, b in pp]))
    gc.collect(); tracemalloc.start(); x = [RP.compose_tuple(f, g) for f, g in pairs]; tb = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    gc.collect(); tracemalloc.start(); y = [f.translate(g) for f, g in bp]; bb = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    gc.collect(); tracemalloc.start(); z = [RP.compose_packed(a, b) for a, b in pp]; pb = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    save('l01_transitions', dict(pairs=len(pairs), equivalence_ok=ok and exhaustive_ok, compose_ns_20000=res,
                                 result_bytes=dict(tuple=tb, bytes_translate=bb, packed_int=pb),
                                 note='5-state functions; bytes tables are 256-byte translate tables (states in first 5)'))


def l03_operator():
    import importlib.util
    spec = importlib.util.spec_from_file_location('opt', str(Path(paths.ROOT) / 'OPTIMIZED_OPERATOR.py'))
    opt = importlib.util.module_from_spec(spec); spec.loader.exec_module(opt)
    rng = random.Random(3)

    def rnd_witness(kind):
        out = []
        for i in range(50):
            if kind == 'bright':
                c, x = 255, [rng.randrange(225, 256) for _ in range(3)]
            elif kind == 'dark':
                c, x = 255, [rng.randrange(0, 45) for _ in range(3)]
            elif kind == 'flat':
                c, x = 255, [120, 120, 120]
            elif kind == 'alpha0':
                c, x = 0, [rng.randrange(256) for _ in range(3)]
            elif kind == 'alpha_mix':
                c, x = rng.choice((0, 1, 127, 128, 254, 255)), [rng.randrange(256) for _ in range(3)]
            else:
                c, x = rng.randrange(256), [rng.randrange(256) for _ in range(3)]
            out.append((c << 24) | (x[0] << 16) | (x[1] << 8) | x[2])
        return out
    kinds = ('random', 'bright', 'dark', 'flat', 'alpha0', 'alpha_mix')
    pairs, mism, nulls = [], 0, 0
    for k in range(3000):
        a = rnd_witness(rng.choice(kinds)); b = rnd_witness(rng.choice(kinds))
        if rng.random() < 0.3:
            b = list(a)
            for j in rng.sample(range(50), rng.randrange(0, 6)):
                b[j] = (b[j] & 0xff000000) | (((b[j] >> 16) & 255) ^ rng.randrange(0, 40)) << 16 | (b[j] & 0xffff)
        pairs.append((a, b))
    for a, b in pairs:
        x, y = opt.score(a, b), RP.score_lut(a, b)
        mism += x != y
        nulls += x is None
    # zero distance and the exact 1500 limit
    a = rnd_witness('random'); zero_ok = opt.score(a, a) == RP.score_lut(a, a)
    errs_same = 0
    for bad in (-1, 2 ** 32, 1.5):
        try: opt.score([bad] * 50, [0] * 50); e1 = None
        except ValueError as e: e1 = 'VE'
        try: RP.score_lut([bad] * 50, [0] * 50); e2 = None
        except ValueError as e: e2 = 'VE'
        errs_same += e1 == e2
    w_opt = timeit(lambda: [opt.score(a, b) for a, b in pairs[:600]], 3)
    w_lut = timeit(lambda: [RP.score_lut(a, b) for a, b in pairs[:600]], 3)
    save('l03_operator', dict(pairs=len(pairs), mismatches=mism, null_results=nulls, zero_distance_equal=zero_ok,
                              invalid_inputs_same_error=errs_same, wall_ns_600_pairs=dict(optimized=w_opt, lut_fused=w_lut),
                              kinds=kinds, note='Python-level exploratory; says nothing about JVM cost'))


def l05_views():
    rows = []
    for n in (64, 256, 1024):
        rng = random.Random(n)
        c = roundtrip(random_case(rng, n, settings_mix=False))
        o = Owner(c)
        k = 16
        w_snap = timeit(lambda: (lambda s: [s['items'][i]['analysis'] for i in range(k)])(o.snapshot()), 3)
        w_view = timeit(lambda: (lambda v: [v.analysis(i) for i in range(k)])(RP.OwnerView(o)), 3)
        v = RP.OwnerView(o)
        stale_raised = False
        o.apply(item_updates={0: {'analysis': {'status': 'unknown'}}})
        try:
            v.analysis(1)
        except RP.StaleView:
            stale_raised = True
        snap = o.snapshot(); snap['items'][1]['analysis'] = 'mutated'
        isolated = o._case['items'][1]['analysis'] != 'mutated'
        immut = isinstance(RP.OwnerView(o).analysis(1), tuple)
        rows.append(dict(n=n, reads=k, snapshot_ns=w_snap, view_ns=w_view, stale_view_raises=stale_raised,
                         snapshot_isolated=isolated, view_values_immutable=immut))
    save('l05_views', dict(rows=rows))


def l06_instrument():
    rows = []
    for mix in ('dependent', 'refresh', 'churn'):
        tr = TR.generate(2, n=64, rounds=100, mix=mix)
        a = TR.replay(tr, GO.make('incumbent', tr['initial']))
        b = TR.replay(tr, GO.make('no_instrument', tr['initial']))
        w1 = timeit(lambda: TR.replay(tr, GO.GOwner(tr['initial']), collect=False), 3)
        w0 = timeit(lambda: TR.replay(tr, GO.GOwner(tr['initial'], instrument=False), collect=False), 3)
        rows.append(dict(mix=mix, same_outputs=a == b, instrumented_ns=w1, uninstrumented_ns=w0))
    save('l06_instrument', dict(rows=rows))


def l04_locality():
    rows = []
    for n in (16, 128, 1024):
        rng = random.Random(n)
        c = roundtrip(random_case(rng, n, settings_mix=False))
        idx_build = timeit(lambda: [core.Index(c).analysis(i) for i in range(0, n, max(1, n // 16))], 3)
        flat = [it['analysis'] for it in c['items']]
        flat_build = timeit(lambda: [ (lambda f: f[i])(flat) for i in range(0, n, max(1, n // 16))], 3)
        rows.append(dict(n=n, compact_index_ns=idx_build, flat_list_ns=flat_build))
    save('l04_locality', dict(rows=rows, note='Index construction is lazy (O(edges) eager edge index on certify path); flat list is a lower bound without typed fingerprints'))


# ------------------------------------------------------------------ M family
def m03_fault_pairing():
    import hashlib

    def keyed(task, attempt, seed):
        h = hashlib.sha256(f'{seed}|{task}|{attempt}'.encode()).digest()
        return h[0] < 64                 # 25 % failure per (task identity, attempt)

    def run(policy, mode, seed):
        """Both policies serve the same 30 required tasks; B first issues 3 speculative
        tasks that are wasted.  Cost = required failures + every task attempt."""
        rng = random.Random(seed)
        order = (['spec0', 'spec1', 'spec2'] if policy == 'B' else []) + [f'req{i}' for i in range(30)]
        required_failures = 0
        for t in order:
            attempt = 0
            while True:
                f = (rng.random() < 0.25) if mode == 'shared' else keyed(t, attempt, seed)
                attempt += 1
                if f and t.startswith('req'):
                    required_failures += 1
                if not f or attempt > 5:
                    break
        return required_failures
    rows = [dict(seed=s, shared_A=run('A', 'shared', s), shared_B=run('B', 'shared', s),
                 keyed_A=run('A', 'keyed', s), keyed_B=run('B', 'keyed', s)) for s in range(300)]
    sb = sum(1 for r in rows if r['shared_B'] < r['shared_A'])
    kb = sum(1 for r in rows if r['keyed_B'] < r['keyed_A'])
    ex = next((r for r in rows if r['shared_B'] < r['shared_A']), None)
    save('m03_fault_pairing', dict(seeds=300, wasteful_policy_B_looks_cheaper_shared_rng=sb,
                                   wasteful_policy_B_looks_cheaper_keyed=kb, pseudo_winner_example=ex,
                                   note='metric = failures on the 30 common required tasks; B also runs 3 wasted speculative tasks. A shared RNG stream '
                                        'shifts the draws seen by the common tasks and makes B look better on many seeds; keyed failures make the common tasks identical'))


def m04_censoring():
    rng = random.Random(4)
    # candidate faster on most runs but times out (censored at cap) on some
    cap = 100.0
    inc = [rng.gauss(50, 5) for _ in range(30)]
    cand = [rng.gauss(40, 5) if rng.random() > 0.2 else cap for _ in range(30)]
    dropped = [x for x in cand if x < cap]
    out = dict(cap=cap, incumbent_median=statistics.median(inc), candidate_median_dropping_timeouts=statistics.median(dropped),
               candidate_median_with_censored_at_cap=statistics.median(cand),
               candidate_mean_with_penalty_2cap=statistics.mean([x if x < cap else 2 * cap for x in cand]),
               incumbent_mean=statistics.mean(inc), timeouts=sum(1 for x in cand if x >= cap))
    save('m04_censoring', out)


def m05_noninferiority():
    rng = random.Random(5)
    # null world: k identical candidates, 3 processes each, per-process medians ~ N(1, sigma_proc)
    res = {}
    for k in (2, 5, 10, 20):
        naive_win = margin_win = 0
        for trial in range(2000):
            inc = [rng.gauss(1, 0.04) for _ in range(3)]
            best_ratio, best_max = 9, 9
            for c in range(k):
                cand = [rng.gauss(1, 0.04) for _ in range(3)]
                ratios = [x / y for x, y in zip(cand, inc)]
                med = statistics.median(ratios)
                if med < best_ratio:
                    best_ratio, best_max = med, max(ratios)
            naive_win += best_ratio < 0.97                      # 'best median 3% faster'
            margin_win += best_max < 0.95                       # all processes >=5% faster
        res[k] = dict(naive_false_winner=naive_win / 2000, all_process_margin_false_winner=margin_win / 2000)
    save('m05_noninferiority', dict(per_screened_candidates=res, sigma_process=0.04,
                                    rule='adopt only if every independent process ratio < 1 - margin (margin 5%) and screen size is reported'))


def m06_counter_oracle():
    # coupled: count controller wakeups (logical) vs physical services for two policies
    rows = []
    for seed in range(6):
        tr = W.random_partial(seed, n=24, pa=0.4, pe=0.3, count=24)
        import coupled_runner as CR
        for pol in ('incumbent', 'proof_first'):
            r = CR.Runner(tr, policy=pol, service_u=3, q_u=1, strong=dict(kind='tree', domain='nonneg', gate='sound'))
            calls = {'n': 0}
            orig = r.drive

            def counted():
                calls['n'] += 1
                return orig()
            r.drive = counted
            out = r.run()
            rows.append(dict(seed=seed, policy=pol, logical_wakeups=calls['n'], certification_calls=out['strong_attempts'],
                             physical_admissions=out['physical_admissions'], latency=out['total_latency_u']))
    save('m06_counter_oracle', dict(rows=rows, historical_count_failures='4 unresolved (NATIVE_CONSTRAINTS); not modified, not attributed'))


def m01_m02_identifiability():
    import coupled_runner as CR
    tr = W.w01_phase_chain(0)
    rows = []
    for q in (0, 1, 3):
        r = CR.Runner(tr, policy='proof_first', service_u=3, q_u=q, strong=dict(kind='tree', domain='nonneg', gate='sound')).run()
        rows.append(dict(q_u=q, latency=r['total_latency_u'], admissions=r['physical_admissions'], strong_ns=r['strong_ns'],
                         attempts=r['strong_attempts']))
    # same counts, different latency => latency depends on the unobserved q mapping (identifiability)
    save('m01_m02_identifiability', dict(rows=rows,
        minimal_calibration=['service time quantiles per physical identity (p50,p90) under real admission',
                             'q per strong attempt on target runtime (median, p90) vs evaluations',
                             'frequency of need_facts verdicts upgradable by the gate (per workload class)'],
        note='physical counts identical across q; intent latency is not identifiable without the q->service-time ratio'))


# ------------------------------------------------------------------ T03
def t03_gap():
    rows = [json.loads(l) for l in open(Path(paths.ROOT) / 'data' / 'owner.jsonl')]
    cur = [r for r in rows if r['source'] == 'current']
    native = {}
    for sc in sorted({r['scenario'] for r in cur}):
        for cfg in ('default', 'no-index', 'no-compact', 'no-stamp'):
            v = [r['elapsed_ns'] for r in cur if r['scenario'] == sc and r['config'] == cfg]
            native[(sc, cfg)] = statistics.median(v)
    # Python analogue: corrected Owner with the same switches on analogous frozen traces
    mixmap = {'lifecycle': 'quiet', 'unrelated': 'unrelated', 'dependent': 'dependent', 'churn': 'churn', 'chain': 'dependent'}
    cfgmap = {'default': Config(), 'no-index': Config(shared_index=False), 'no-stamp': Config(stamps=False)}
    pyr = {}
    for sc, mix in mixmap.items():
        tr = TR.generate(1, n=64, rounds=100, mix=mix, chain=(sc == 'chain'))
        for cfg, conf in cfgmap.items():
            pyr[(sc, cfg)] = timeit(lambda: TR.replay(tr, Owner(tr['initial'], conf), collect=False), 3)
    out = []
    for sc in mixmap:
        for cfg in ('no-index', 'no-stamp'):
            nr = native[(sc, cfg)] / native[(sc, 'default')]
            pr = pyr[(sc, cfg)] / pyr[(sc, 'default')]
            out.append(dict(scenario=sc, config=cfg, native_ratio=round(nr, 3), python_ratio=round(pr, 3),
                            log_error=round(math.log(pr / nr), 3)))
    errs = [abs(r['log_error']) for r in out]
    save('t03_gap', dict(rows=out, median_abs_log_error=round(statistics.median(errs), 3), max_abs_log_error=round(max(errs), 3),
                         note='native = anonymous anchor medians (current source); python = this machine; compact ablation has no Python analogue switch; workloads are analogues not replays'))


# ------------------------------------------------------------------ X11 (E01 x K01) with the D_src operator
def x11_features():
    import importlib.util
    spec = importlib.util.spec_from_file_location('opt', str(Path(paths.ROOT) / 'OPTIMIZED_OPERATOR.py'))
    opt = importlib.util.module_from_spec(spec); spec.loader.exec_module(opt)
    rng = random.Random(11)

    def wit():
        return [(255 << 24) | (rng.randrange(40, 200) << 16) | (rng.randrange(40, 200) << 8) | rng.randrange(40, 200) for _ in range(50)]
    # statistics-only retention is insufficient: same mean features, different distance to a neighbour
    a = wit(); b = list(a)
    i, j = 3, 7
    ai, aj = [(a[i] >> s) & 255 for s in (16, 8, 0)], [(a[j] >> s) & 255 for s in (16, 8, 0)]
    b[i], b[j] = a[j], a[i]          # swapped elements: identical multiset statistics
    nb = list(a)
    for q in (0, 1, 2, 5, 9, 11):
        nb[q] = (255 << 24) | ((((a[q] >> 16) & 255) + 9) << 16) | (a[q] & 0xffff)
    stats_counterexample = dict(same_multiset=sorted(a) == sorted(b), score_a=opt.score(a, nb), score_b=opt.score(b, nb))
    # retention simulation along a sweep: raw packed vs normalised vectors (bytes) x LRU vs useless-first
    rows = []
    for policy in ('lru', 'useless_first'):
        for store in ('packed', 'normalised'):
            for cap in (2, 3):
                n, reacq, norm_ops, resident_bytes = 24, 0, 0, 0
                raws = {}
                known = set()            # edges admitted
                order = [rng.randrange(n) for _ in range(80)]
                for t in order:
                    for e in (t - 1, t):
                        if 0 <= e < n - 1 and e not in known:
                            for x in (e, e + 1):
                                if x not in raws:
                                    reacq += 1
                                    raws[x] = True
                                    norm_ops += 50 if store == 'normalised' else 0
                                else:
                                    raws[x] = raws.pop(x)
                            known.add(e)
                            norm_ops += 0 if store == 'normalised' else 100      # packed: renormalise both sides
                            while len(raws) > cap:
                                victim = None
                                if policy == 'useless_first':
                                    for r in raws:
                                        if all(not (0 <= ee < n - 1) or ee in known for ee in (r - 1, r)):
                                            victim = r; break
                                del raws[victim if victim is not None else next(iter(raws))]
                per = 50 * 4 if store == 'packed' else 50 * 3 * 8
                rows.append(dict(policy=policy, store=store, raw_capacity=cap, reacquisitions=reacq,
                                 normalisation_ops=norm_ops, bytes_per_witness=per))
    save('x11_features', dict(statistics_counterexample=stats_counterexample, rows=rows,
                              note='model: a rank needs both endpoint witnesses resident; synthetic access sequence'))


ALL = ['g01_support', 'g02_sharing', 'g04_noop', 'k01_coupled', 'k05_split', 'g05_g06_coupled', 'k02_k03_retention',
       'k06_adversary', 'k04_negative', 'l01_transitions', 'l03_operator', 'l05_views', 'l06_instrument', 'l04_locality',
       'm03_fault_pairing', 'm04_censoring', 'm05_noninferiority', 'm06_counter_oracle', 'm01_m02_identifiability',
       't03_gap', 'x11_features']

if __name__ == '__main__':
    names = sys.argv[1:] or ALL
    for nm in names:
        t0 = time.time()
        globals()[nm]()
        print(nm, round(time.time() - t0, 1), 's', flush=True)
