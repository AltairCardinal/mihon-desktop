"""E1: policy x service_u x q_u grid on tuning or held-out coupled traces (virtual u).
Writes results/raw/wpA/grid_<set>.jsonl (one row per run) and a summary json."""
import json, sys, time, collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import wpA_lib as A

which = sys.argv[1]
traces = {'tuning': A.tuning_traces, 'heldout': A.heldout_traces, 'heldout2': A.heldout2_traces}[which]()
POL = ['incumbent', 'proof_first', 'gated', 'race', 'race_keep', 'gated_keep', 'ski', 'adaptive', 'strong_only']
out = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpA' / f'grid_{which}.jsonl'
agg = collections.defaultdict(collections.Counter)
t0 = time.time()
with open(out, 'w') as fh:
    for tr in traces:
        for su in (2, 4, 8):
            for q in (0, 1, 2, 4, 8):
                for pol in POL:
                    if pol in ('incumbent', 'strong_only') and q != 0:
                        continue
                    r = A.ARunner(tr, policy=pol, service_u=su, q_u=q).run()
                    r.pop('latency_u', None)
                    r['trace'] = tr['name']; r['set'] = which
                    fh.write(json.dumps(r) + '\n')
                    k = (pol, su, q)
                    for f in ('published', 'intents', 'wrong', 'total_latency_u', 'physical_admissions', 'discarded',
                              'strong_attempts', 'proof_wins', 'strong_ns', 'race_cancels'):
                        agg[k][f] += r[f]
summ = [dict(policy=k[0], service_u=k[1], q_u=k[2], **v) for k, v in sorted(agg.items())]
(Path(__file__).resolve().parents[1] / 'results' / 'summary' / 'wpA' / f'grid_{which}.json').write_text(
    json.dumps(dict(set=which, traces=[t['name'] for t in traces], rows=summ, seconds=round(time.time() - t0, 1)), indent=1))
print(which, 'rows', len(summ), 'seconds', round(time.time() - t0, 1))
