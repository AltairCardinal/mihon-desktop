"""B02/D01/D02 feasibility checks: symbolic vs bitset vs brute force (G0 grid), INT_MASK holes, binary64 dense neighbourhoods."""
import sys,random,math,itertools,time,os,json
os.chdir(os.path.dirname(os.path.abspath(__file__))+"/.."); sys.path.insert(0,"candidates"); import paths
OUT={}
import transducer as T, wpB_domains as D
rng=random.Random(4); bad=0; badb=0; n=0
def brute(cons, vals_by_var):
    vars_=sorted({t[1] for (xy,_) in cons for t in xy if t[0]=='e'})
    for assign in itertools.product(*[vals_by_var for _ in vars_]):
        m=dict(zip(vars_,assign)); val=lambda t: m[t[1]] if t[0]=='e' else t[1]
        if all((val(xy[0])<val(xy[1]))==o for xy,o in cons): return True
    return False
G=D.GRID
t_sym=t_bit=0
for trial in range(400):
    nv=rng.randrange(1,3); knowns=[rng.randrange(0,1500)/50 + rng.choice((0,0,0,1e-9,-1e-9,0.01)) for _ in range(rng.randrange(0,3))]
    terms=[('e',v) for v in range(nv)]+[('k',k) for k in knowns]
    cons=set()
    for _ in range(rng.randrange(1,4)):
        x,y=rng.sample(terms,2) if len(terms)>1 else (terms[0],('k',rng.randrange(0,1500)/50))
        if x[0]=='k' and y[0]=='k': continue
        cons.add(((x,y),rng.random()<.5))
    cons=frozenset(cons)
    if not cons: continue
    t0=time.perf_counter_ns(); a=T.feasible(cons,'G0'); t_sym+=time.perf_counter_ns()-t0
    t0=time.perf_counter_ns(); b=D.feasible_bits(cons); t_bit+=time.perf_counter_ns()-t0
    c=brute(cons,G) ; n+=1
    bad+=a!=c; badb+=b!=c
OUT['G0']=dict(cases=n,symbolic_wrong=bad,bitset_wrong=badb,sym_ms_local=round(t_sym/1e6,1),bit_ms_local=round(t_bit/1e6,1))
# holes domain: integer ranks
cons=frozenset({((('e',0),('k',0.5)),True), ((('k',0.1),('e',0)),True)})
OUT['int_mask_0.1<x<0.5']=dict(int_mask=D.feasible_bits(cons, D.INT_MASK), full_grid=D.feasible_bits(cons))
# D02 binary64 dense brute force around tight gaps
bad=0; cases=0
for trial in range(300):
    base=rng.choice((0.0,-0.0,5e-324,1.0,1e17,-1.7976931348623157e308,1.7976931348623157e308, 3.0))
    ks=[base]
    for _ in range(rng.randrange(0,3)):
        x=ks[-1]
        for _ in range(rng.randrange(1,4)): x=math.nextafter(x,math.inf)
        if math.isfinite(x): ks.append(x)
    nv=rng.randrange(1,4); terms=[('e',v) for v in range(nv)]+[('k',k) for k in ks]
    cons=set()
    for _ in range(rng.randrange(1,5)):
        x,y=rng.sample(terms,2)
        if x[0]=='k' and y[0]=='k': continue
        cons.add(((x,y),rng.random()<.5))
    cons=frozenset(cons)
    if not cons: continue
    dense=set()
    for k in ks+[0.0,-0.0,5e-324,-5e-324,1.7976931348623157e308,-1.7976931348623157e308,1.0,-1.0]:
        x=y=k
        for _ in range(8):
            x=math.nextafter(x,math.inf); y=math.nextafter(y,-math.inf)
            if math.isfinite(x): dense.add(x)
            if math.isfinite(y): dense.add(y)
        dense.add(k)
    dense=sorted(dense)
    if len(dense)**nv>400000: continue
    cases+=1; bad+= T.feasible(cons,'ext')!=brute(cons,dense)
OUT['binary64_dense']=dict(cases=cases,symbolic_vs_bruteforce_mismatches=bad)
OUT['command']='python3 research_out/bench/run_wpB_domains.py'
json.dump(OUT,open('results/raw/wpB/domains_brute.json','w'),indent=1); print(json.dumps(OUT))
