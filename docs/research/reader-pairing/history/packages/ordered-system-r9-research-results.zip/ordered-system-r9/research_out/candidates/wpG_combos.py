"""WP-G combinations X11 X18 X19 X20 X26 X27 X28: arms 0/A/B/A+B, two combination
organisations each, additive per-metric interaction  I = (AB - B) - (A - 0).

Usage: python3 wpG_combos.py [x11|x18|x19|x20|x26|x27|x28 ...]   (default: all)
Outputs results/raw/wpG/combo_<id>.json.  Each run is capped by the caller (timeout 300)."""
import copy
import gc
import hashlib
import json
import random
import statistics
import sys
import time
import tracemalloc
from array import array
from pathlib import Path

import paths  # noqa: F401
import compact_core as core
import workloads as W
from corrected_owner import Owner, Config
from common import random_case, roundtrip
import wpG_traces as TR
import wpG_owner as GO
import wpG_coupled as GC
import wpG_retention as RT
import wpG_repr as RP

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpG'


def save(name, obj):
    (OUT / f'{name}.json').write_text(json.dumps(obj, indent=1, sort_keys=True, allow_nan=False))


def interaction(arms, ab_key, metrics):
    z, a, b, ab = arms['0'], arms['A'], arms['B'], arms[ab_key]
    return {m: dict(zero=z[m], A=a[m], B=b[m], AB=ab[m], dA=a[m] - z[m], dB=b[m] - z[m], dAB=ab[m] - z[m],
                    interaction=(ab[m] - b[m]) - (a[m] - z[m])) for m in metrics}


def total(rows, metrics):
    return {m: sum(r[m] for r in rows) for m in metrics}


# ------------------------------------------------------------------ X11 (E01/K01)
def x11():
    M = ('physical_admissions', 'published', 'horizon_hit', 'raw_evictions', 'rank_computations', 'wrong')
    arms_kw = {'0': {}, 'A': dict(raw_policy='useless_first'), 'B': dict(order='derive_first'),
               'AB1': dict(raw_policy='useless_first', order='derive_first'), 'AB2': dict(raw_policy='closure')}
    traces = [('W06', W.w06_complete_analysis_ambiguous(s, n=16, count=16)) for s in range(200, 203)] + \
             [('RP', W.random_partial(s, n=32, pa=0.4, pe=0.3, pattern='roundtrip', count=32)) for s in range(200, 203)]
    res = {}
    for rc in (1, 2):
        arms = {k: total([GC.run(tr, kw, raw_capacity=rc, horizon=3000) for _, tr in traces], M) for k, kw in arms_kw.items()}
        res[f'rc{rc}'] = dict(arms=arms, org1_useless_plus_derive=interaction(arms, 'AB1', M),
                              org2_closure_protect=interaction(arms, 'AB2', M))
    save('combo_x11', dict(traces=[f for f, _ in traces], seeds='200-202 (not used for tuning)', results=res,
                           note='org1 = dead-raw-first eviction + derive-before-evict; org2 = one dependency-closure '
                                'eviction rule (protect new witness and neighbours) inside the frozen evict-first order'))


# ------------------------------------------------------------------ X18 (G01/B04)
def x18():
    rng = random.Random(18)
    acc = dict(union=0, per_attempt=0, proj_union=0, proj_per_attempt=0, cases=0, two_attempt_cases=0)
    for _ in range(300):
        c = roundtrip(random_case(rng, rng.choice((8, 12, 16)), p_unknown=0.3))
        t = rng.randrange(len(c['items']))
        idx = core.Index(c, check_ids=False)
        b = core.certify(c, t, 2, index=idx)
        atts = [b] + ([core.certify(c, t, 3, index=idx)] if b['status'] == 'need_facts' else [])
        sup = [dict(a['proof'][2]) for a in atts]
        u = {}
        for s in sup:
            u.update(s)
        drop = lambda s: {k for k in s if k[0] != 'dimension'}  # noqa: E731
        acc['cases'] += 1
        acc['two_attempt_cases'] += len(atts) == 2
        acc['union'] += len(u)
        acc['per_attempt'] += sum(len(s) for s in sup)
        acc['proj_union'] += len(drop(u))
        acc['proj_per_attempt'] += sum(len(drop(s)) for s in sup)
    # validation work on traces: union (0) vs proj (A); attempt-local (B) costs per_attempt/union x reads
    M = ('engine_runs', 'typed_reads_checked', 'support_keys_built')
    rows = {}
    for nm in ('incumbent', 'proj_support', 'fact_support'):
        t = dict(engine_runs=0, typed_reads_checked=0, support_keys_built=0)
        for mix in ('refresh', 'dependent'):
            for seed in (200, 201):
                tr = TR.generate(seed, n=48, rounds=60, mix=mix)
                o = GO.make(nm, tr['initial']); TR.replay(tr, o, collect=False)
                for m in M:
                    t[m] += o.metrics[m]
        rows[nm] = t
    ratio = acc['per_attempt'] / acc['union']
    arms = {'0': dict(stored_keys=acc['union'], **rows['incumbent']),
            'A': dict(stored_keys=acc['proj_union'], **rows['proj_support']),
            'B': dict(stored_keys=acc['per_attempt'], engine_runs=rows['incumbent']['engine_runs'],
                      typed_reads_checked=round(rows['incumbent']['typed_reads_checked'] * ratio),
                      support_keys_built=round(rows['incumbent']['support_keys_built'] * ratio)),
            'AB1': dict(stored_keys=acc['proj_per_attempt'], engine_runs=rows['proj_support']['engine_runs'],
                        typed_reads_checked=round(rows['proj_support']['typed_reads_checked'] * acc['proj_per_attempt'] / acc['proj_union']),
                        support_keys_built=round(rows['proj_support']['support_keys_built'] * acc['proj_per_attempt'] / acc['proj_union'])),
            'AB2': dict(stored_keys=acc['proj_union'], **rows['fact_support'])}
    MM = ('stored_keys',) + M
    save('combo_x18', dict(static=acc, attempt_local_overhead=ratio, arms=arms,
                           org1_attempt_local_projection=interaction(arms, 'AB1', MM),
                           org2_shared_union_dimension_drop=interaction(arms, 'AB2', MM),
                           note='B (attempt-local supports) is derived: stored keys exact; validation reads scaled by the '
                                'measured per-attempt/union ratio (upper bound: no early exit). Attempt-local validation must '
                                'still invalidate when the rejected attempt becomes certifiable, so it cannot drop attempts.'))


# ------------------------------------------------------------------ X19 (G03/K05)
def x19():
    M = ('physical_admissions', 'engine_runs', 'support_validations', 'typed_reads_checked', 'posrev_checks', 'wrong')
    traces = [W.random_partial(s, n=32, pa=0.4, pe=0.3, pattern='roundtrip', count=32) for s in range(200, 204)]

    def arm(barrier, support, rc, mc):
        out = {m: 0 for m in M}
        for tr in traces:
            f = None if barrier == 'global' and support == 'union' else \
                (lambda c, b=barrier, s=support: GO.GOwner(c, Config(memo_capacity=mc), support=s, barrier=b))
            g = GC.GRunner(tr, session_kw=dict(order='derive_first', owner_factory=f), raw_capacity=rc)
            if f is None:
                g.session.owner.config = Config(memo_capacity=mc)
            r = g.run(horizon=3000)
            om = g.session.owner.metrics
            out['physical_admissions'] += r['physical_admissions']; out['wrong'] += r['wrong']
            for m in M[1:5]:
                out[m] += om[m]
        return out
    arms = {'0': arm('global', 'union', 2, 2), 'A': arm('posrev', 'union', 2, 2), 'B': arm('global', 'union', 3, 1),
            'AB1': arm('posrev', 'union', 3, 1), 'AB2': arm('posrev', 'fact', 3, 1)}
    save('combo_x19', dict(arms=arms, org1_posrev_with_shifted_budget=interaction(arms, 'AB1', M),
                           org2_posrev_fact_with_shifted_budget=interaction(arms, 'AB2', M),
                           posrev_space='one int per position (n=32 -> 32 slots) outside the memo budget; '
                                        'entries store their position tuple (counted in posrev_checks)',
                           note='0: global stamp, raw 2 / memo 2; B: raw 3 / memo 1; derive_first order in all arms'))


# ------------------------------------------------------------------ X20 (G05/H01)
def x20():
    M = ('published_now', 'engine_runs', 'memo_hits', 'reissued', 'wrong', 'publication_read_checks', 'certification_calls')
    traces = [W.random_partial(s, n=48, pa=0.5, pe=0.25, pattern='jump', count=40) for s in range(200, 203)] + \
             [W.w02_islands(s) for s in range(200, 203)]
    pj = lambda c: GO.GOwner(c, support='proj')  # noqa: E731

    def arm(kw):
        out = {m: 0 for m in M}
        for tr in traces:
            g = GC.GRunner(tr, session_kw=kw, versioned=True)
            r = g.run(horizon=6000)
            s = g.session
            out['published_now'] += len(s.published); out['wrong'] += r['wrong']
            out['engine_runs'] += s.owner.metrics['engine_runs']; out['memo_hits'] += s.owner.metrics['memo_hits']
            out['reissued'] += s.metrics['reissued_publications']
            out['publication_read_checks'] += s.metrics['publication_read_checks']
            out['certification_calls'] += s.metrics['certification_calls']
        return out
    arms = {'0': arm({}), 'A': arm(dict(owner_factory=pj)), 'B': arm(dict(reissue=True)),
            'AB1': arm(dict(reissue=True, owner_factory=pj)), 'Blazy': arm(dict(reissue='lazy')),
            'AB2': arm(dict(reissue='lazy', owner_factory=pj))}
    lazy_arms = dict(arms, B=arms['Blazy'])
    save('combo_x20', dict(arms=arms, org1_eager_atomic_reissue=interaction(arms, 'AB1', M),
                           org2_lazy_hold_old_until_observation=interaction(lazy_arms, 'AB2', M),
                           note='versioned world (re-extraction gives a new evidence version); held-out seeds 200-202; '
                                'published_now counted by the public `published` property (which runs lazy reissue)'))


# ------------------------------------------------------------------ X26 (K02/K03)
class GDSCount(RT.ROwner):
    """B arm: cost-aware GDS priority but structural count capacity (every entry weighs 1/4 budget)."""
    def _size(self, entry):
        return self.byte_budget // 4


def x26():
    bpk = 1186
    M = ('engine_runs', 'scan_steps', 'memo_hits', 'memo_evictions', 'clock_samples')
    arms = {k: {m: 0 for m in M + ('wall_ns',)} for k in ('0', 'A', 'B', 'AB1', 'AB2')}
    verdicts = set()
    for seed in range(200, 204):
        rng = random.Random(seed)
        n = 96
        c = TR._case(rng, n, chain=True, p_unknown=0.0, p_edge_unknown=0.0)
        for it in c['items'][::7]:
            it['analysis'] = {'status': 'unknown'}
        seq = []
        for r in range(150):
            seq += [n - 1 - (r % 3) * 9, rng.randrange(0, 12), rng.randrange(0, 12)]
        tr = dict(initial=c, ops=[['req', t] for t in seq])
        o = Owner(c, Config(memo_capacity=10 ** 6)); TR.replay(tr, o, collect=False)
        mean_keys = statistics.mean(len(e['support']) for e in o._memo.values())
        budget = int(4 * bpk * (mean_keys + 2))
        mk = {'0': lambda: RT.ROwner(c, policy='lru', bytes_per_key=bpk),
              'A': lambda: RT.ROwner(c, policy='bytes', byte_budget=budget, bytes_per_key=bpk),
              'B': lambda: GDSCount(c, policy='gds', byte_budget=budget, estimator='steps', bytes_per_key=bpk),
              'AB1': lambda: RT.ROwner(c, policy='gds', byte_budget=budget, estimator='steps', bytes_per_key=bpk),
              'AB2': lambda: RT.ROwner(c, policy='gds', byte_budget=budget, estimator='clock', sample=4, bytes_per_key=bpk)}
        for k, f in mk.items():
            ow = f()
            t0 = time.perf_counter_ns(); out = TR.replay(tr, ow); arms[k]['wall_ns'] += time.perf_counter_ns() - t0
            verdicts.add((seed, hashlib.sha256(json.dumps(out, sort_keys=True, default=str).encode()).hexdigest()))
            for m in M:
                arms[k][m] += ow.metrics[m]
    save('combo_x26', dict(arms=arms, verdicts_identical_per_seed=len(verdicts) == 4,
                           org1_bytes_plus_steps=interaction(arms, 'AB1', M + ('wall_ns',)),
                           org2_bytes_plus_sampled_clock=interaction(arms, 'AB2', M + ('wall_ns',)),
                           note='held-out seeds 200-203; wall_ns exploratory single process (shared 2 vCPU), not formal'))


# ------------------------------------------------------------------ X27 (L01/L02)
def x27():
    rng = random.Random(27)
    fs = RP.all_functions()
    res = {}
    for keys in (4, 60):
        reqs = []
        for _ in range(2000):
            f = rng.choice(fs)
            vals = tuple(rng.randrange(1 << 20) for _ in range(keys))
            reqs.append((f, vals))

        def separate():                     # A: packed state + separate shared-key value tuple
            return [(RP.pack(f), tuple(list(v))) for f, v in reqs]   # fresh value block (no sharing of the input tuple)

        def unified():                      # B: one contiguous typed buffer per request
            return [array('q', (RP.pack(f),) + v) for f, v in reqs]

        def tuple_state():                  # 0: tuple state + dict support (r8-like)
            return [(tuple(f), {('k', j): x for j, x in enumerate(v)}) for f, v in reqs]

        def unified_tuple():                # AB org2: tuple state, values in one array
            return [(f, array('q', v)) for f, v in reqs]
        row = {}
        for nm, fn in (('0_tuple_dict', tuple_state), ('A_packed_tuple', separate), ('B_unified_array', unified),
                       ('AB2_tuple_state_array_values', unified_tuple)):
            t0 = time.perf_counter_ns(); fn(); dt = time.perf_counter_ns() - t0
            gc.collect(); tracemalloc.start(); x = fn(); mem = tracemalloc.get_traced_memory()[0]; tracemalloc.stop(); del x
            row[nm] = dict(build_ns=dt, retained_bytes=mem)
        res[f'keys{keys}'] = row
    # aliasing counterexample: a reused buffer across requests overwrites the earlier certificate
    buf = array('q', [0] * 5)
    certs = []
    for state in ((1, 2, 3, 4, 0), (0, 0, 0, 0, 0)):
        buf[:] = array('q', state)
        certs.append(buf)                    # borrowed, not copied
    aliased = certs[0].tolist() == [0, 0, 0, 0, 0]
    save('combo_x27', dict(results=res, reused_buffer_overwrites_first_certificate=aliased,
                           note='single-process exploratory tracemalloc/ns; AB1 = B (unified buffer already holds packed state); '
                                'per-request fresh buffers are required for correctness'))


# ------------------------------------------------------------------ X28 (M03/P04)
def x28():
    def keyed(task, attempt, seed):
        h = hashlib.sha256(f'{seed}|{task}|{attempt}'.encode()).digest()
        return h[0] < 64

    def cost(policy_spec, mode, seed):
        rng = random.Random(seed)
        order = [f'spec{j}' for j in range(policy_spec)] + [f'req{i}' for i in range(30)]
        fails = 0
        for t in order:
            att = 0
            while True:
                f = (rng.random() < 0.25) if mode == 'shared' else keyed(t, att, seed)
                att += 1
                if f and t.startswith('req'):
                    fails += 1
                if not f or att > 5:
                    break
        return fails
    out = {}
    reps = 60
    for mode in ('shared', 'keyed'):
        for holdout in (False, True):
            false_win = 0
            for rep in range(reps):
                train = range(1000 * rep, 1000 * rep + 20)
                test = range(1000 * rep + 500, 1000 * rep + 520)
                base_tr = statistics.mean(cost(0, mode, s) for s in train)
                cand = {k: statistics.mean(cost(k, mode, s) for s in train) for k in range(1, 9)}
                best = min(cand, key=cand.get)
                if not holdout:
                    false_win += cand[best] < base_tr
                else:
                    false_win += cand[best] < base_tr and \
                        statistics.mean(cost(best, mode, s) for s in test) < statistics.mean(cost(0, mode, s) for s in test)
            out[f'{mode}|holdout={holdout}'] = false_win / reps
    arms = {'0': dict(false_winner_rate=out['shared|holdout=False']), 'A': dict(false_winner_rate=out['keyed|holdout=False']),
            'B': dict(false_winner_rate=out['shared|holdout=True']), 'AB1': dict(false_winner_rate=out['keyed|holdout=True'])}
    save('combo_x28', dict(rates=out, arms=arms, org1_keyed_plus_holdout=interaction(arms, 'AB1', ('false_winner_rate',)),
                           org2='replayable service kernel = keyed table (A) already; holdout organisation differs only by split; see note',
                           note='8 useless candidates (k wasted speculative tasks); true effect 0 for all; '
                                'false winner = screened best claims improvement (and, with holdout, also wins on test)'))


ALL = dict(x11=x11, x18=x18, x19=x19, x20=x20, x26=x26, x27=x27, x28=x28)

if __name__ == '__main__':
    for name in (sys.argv[1:] or list(ALL)):
        t0 = time.time(); ALL[name](); print(name, 'done', round(time.time() - t0, 1), 's', flush=True)
