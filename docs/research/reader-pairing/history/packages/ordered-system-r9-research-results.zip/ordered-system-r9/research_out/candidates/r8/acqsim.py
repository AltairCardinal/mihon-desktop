"""D1/D2/D3/D6 + NH5: acquisition simulation with a hidden complete world.

Layer: SIMULATED (unit-less).  The hidden world is a complete case; current
knowledge starts with headers (alpha) and a fraction of analyses/ranks, and
grows only through acquisitions.  Physical model (GENERATIVE_DOMAIN.md):
  * acquiring the raw witness of item i  -> 1 acquisition (cost A); it yields
    analysis(i) after one derivation (cost D);
  * rank(a,a+1) needs BOTH raw witnesses resident -> one derivation (cost D);
  * raw witnesses live in a FIFO of capacity R; scalars survive eviction.
A request loops: certify -> if not certified, plan the round's work from the
verdict's needs -> perform it (parallel inside a round) -> next round.
Every certified unit is checked against complete_plan(hidden world).
"""
import copy
import random
from collections import OrderedDict

from common import ref, unit_of, random_case, roundtrip, fact
import transducer as T
import omega as O


def make_world(rng, n, p_wide=0.12):
    w = roundtrip(random_case(rng, n, p_wide=p_wide, domain='G0', settings_mix=False, automatic=True))
    # complete: every analysis computed, every NARROW-NARROW edge computed
    for it in w['items']:
        if it['analysis']['status'] != 'computed':
            st = it['header']['state']
            it['analysis'] = dict(status='computed', fact=fact(st, rng.choice(('A', 'B', 'UNKNOWN'))), version=1)
    recs = {e['first']: e for e in w['edges']}
    w['edges'] = []
    for a in range(n - 1):
        e = recs.get(a)
        if e is None or e.get('status') != 'computed':
            e = dict(first=a, second=a + 1, status='computed', score=rng.randrange(0, 1500) / 50, version=1)
        w['edges'].append(e)
    return w


def initial_knowledge(world, rng, p_analysis=0.3, p_rank=0.3):
    k = copy.deepcopy(world)
    for it in k['items']:
        if rng.random() > p_analysis:
            it['analysis'] = {'status': 'unknown'}
    k['edges'] = [e for e in k['edges'] if rng.random() < p_rank]
    return k


class Sim:
    def __init__(self, world, knowledge, R=4, certifier='ref', work='fact', select='all', capacity=2):
        self.W, self.K = world, knowledge
        self.R, self.certifier, self.work, self.select, self.C = R, certifier, work, select, capacity
        self.resident = OrderedDict()
        self.c = dict(acquisitions=0, derivations=0, rounds=0, certify_calls=0, rel_calls=0, wrong=0,
                      early=0, slots=0, prefetch_acq=0, prefetch_wasted=0)
        self.prefetched = set()

    # ---- physical work ------------------------------------------------
    def _acquire(self, i, prefetch=False):
        if i in self.resident:
            self.resident.move_to_end(i)
            if i in self.prefetched and not prefetch:
                self.prefetched.discard(i)
            return 0
        self.resident[i] = True
        self.c['acquisitions'] += 1
        if prefetch:
            self.c['prefetch_acq'] += 1
            self.prefetched.add(i)
        elif i in self.prefetched:
            self.prefetched.discard(i)
        while len(self.resident) > self.R:
            old, _ = self.resident.popitem(last=False)
            if old in self.prefetched:
                self.c['prefetch_wasted'] += 1
                self.prefetched.discard(old)
        return 1

    def _know_analysis(self, i):
        if self.K['items'][i]['analysis']['status'] != 'computed':
            self.K['items'][i]['analysis'] = copy.deepcopy(self.W['items'][i]['analysis'])
            self.c['derivations'] += 1

    def _know_edge(self, a):
        if any(e['first'] == a for e in self.K['edges']):
            return
        self.K['edges'].append(copy.deepcopy(self.W['edges'][a]))
        self.c['derivations'] += 1

    def do_round(self, needs):
        items_an, edges = set(), set()
        for nd in needs:
            if nd['kind'] in ('ANALYSIS', 'DIMENSIONS'):
                items_an.add(nd['item'])
            elif nd['kind'] == 'RANK':
                edges.add(nd['item'])
        if self.select == 'analysis_first' and items_an:
            edges = set()                      # NH5: ranks deferred until analyses are known
        if self.select == 'one':               # D1: single most local fact per round
            pick = sorted(items_an)[:1] if items_an else sorted(edges)[:1]
            items_an, edges = (set(pick), set()) if items_an else (set(), set(pick))
        units = 0
        if self.work == 'fact':                  # independent per-fact tasks: no witness reuse
            for i in sorted(items_an):
                units += 1
                self.c['acquisitions'] += 1
                self._know_analysis(i)
            for a in sorted(edges):
                units += 2
                self.c['acquisitions'] += 2
                for i in (a, a + 1):
                    self._know_analysis(i)       # the witness also yields the analysis
                self._know_edge(a)
        else:                                    # 'witness' (D2): shared physical work
            need_items = set(items_an) | {a for a in edges} | {a + 1 for a in edges}
            for i in sorted(need_items):
                units += self._acquire(i)
            for i in sorted(need_items):
                self._know_analysis(i)
            for a in sorted(edges):
                self._know_edge(a)
            if self.work == 'witness_eager':     # derive every newly derivable adjacent rank
                for i in list(self.resident):
                    for a in (i - 1, i):
                        if 0 <= a < len(self.W['items']) - 1 and a in self.resident and a + 1 in self.resident:
                            if self.K['items'][a]['analysis']['status'] == 'computed' and \
                                    self.K['items'][a + 1]['analysis']['status'] == 'computed':
                                self._know_edge(a)
        self.c['rounds'] += 1
        self.c['slots'] += -(-units // self.C) if units else 0

    # ---- certification --------------------------------------------------
    def certify(self, t):
        self.c['certify_calls'] += 1
        v = ref.certify_strategy(self.K, t)['selected']
        if v['status'] == 'need_facts' and self.certifier in ('tree', 'exact'):
            self.c['rel_calls'] += 1
            if self.certifier == 'tree':
                st, unit = T.certify_tree(self.K, t)
            else:
                st, unit = O.certify_exact(self.K, t)[:2]
            if st == 'certified':
                self.c['early'] += 1
                return dict(status='certified', unit=unit, needs=[]), v
        return v, v

    def serve(self, t, max_rounds=12):
        for _ in range(max_rounds):
            v, base = self.certify(t)
            if v['status'] == 'certified':
                if v['unit'] != unit_of(ref.complete_plan(self.W), t):
                    self.c['wrong'] += 1
                return True
            needs = base['needs']
            if not needs:
                # blocked by a failure: the hidden world has none, so re-acquire the failing items
                needs = [dict(item=int(k), kind='ANALYSIS') for k in base['failures']]
                for k in base['failures']:
                    self.K['items'][int(k)]['analysis'] = {'status': 'unknown'}
            self.do_round(needs)
        return False

    def prefetch(self, history, budget):
        """D3: only past requests are used.  Predict the next target by the last
        step's direction and acquire witnesses around it."""
        if len(history) < 2 or budget <= 0:
            return
        d = history[-1] - history[-2]
        d = (d > 0) - (d < 0) or 1
        n = len(self.W['items'])
        guess = history[-1] + d
        for i in (guess, guess + d, guess - d)[:budget]:
            if 0 <= i < n:
                self._acquire(i, prefetch=True)
                self._know_analysis(i)


def targets(rng, n, pattern, count):
    t = rng.randrange(n)
    out = []
    d = 1
    for _ in range(count):
        if pattern == 'sweep':
            t = (t + 1) % n
        elif pattern == 'roundtrip':
            if not 0 <= t + d < n:
                d = -d
            t += d
        elif pattern == 'jump':
            t = rng.randrange(n)
        elif pattern == 'reverse_once':
            t = (t + d) % n
            if len(out) == count // 2:
                d = -d
        out.append(t)
    return out


def serve_joint(sim, ts, max_rounds=12):
    """X2/B5: one round serves the union of the needs of every uncertified target."""
    pending = list(dict.fromkeys(ts))
    done = 0
    for _ in range(max_rounds):
        needs, still = [], []
        for t in pending:
            v, base = sim.certify(t)
            if v['status'] == 'certified':
                if v['unit'] != unit_of(ref.complete_plan(sim.W), t):
                    sim.c['wrong'] += 1
                done += 1
            else:
                still.append(t)
                needs.extend(base['needs'] or [dict(item=int(k), kind='ANALYSIS') for k in base['failures']])
        pending = still
        if not pending:
            return done
        seen, uniq = set(), []
        for nd in needs:
            k = (nd['kind'], nd['item'], nd.get('second'))
            if k not in seen:
                seen.add(k); uniq.append(nd)
        sim.do_round(uniq)
    return done


def run(seed, n=24, pattern='sweep', count=24, R=4, certifier='ref', work='fact', select='all',
        prefetch=0, p_analysis=0.3, p_rank=0.3, capacity=2, batch=1):
    rng = random.Random(seed)
    W = make_world(rng, n)
    K = initial_knowledge(W, rng, p_analysis, p_rank)
    sim = Sim(W, K, R=R, certifier=certifier, work=work, select=select, capacity=capacity)
    hist = []
    served = 0
    ts = targets(random.Random(seed + 1), n, pattern, count)
    if batch > 1:
        for j in range(0, len(ts), batch):
            served += serve_joint(sim, ts[j:j + batch])
    else:
        for t in ts:
            served += sim.serve(t)
            hist.append(t)
            sim.prefetch(hist, prefetch)
    out = dict(sim.c)
    out['served'] = served
    return out
