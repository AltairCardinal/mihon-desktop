"""WP-A fast tests: proof/service adoption on the coupled Session (virtual u)."""
import json, sys, unittest
from copy import deepcopy
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'candidates'))
import paths  # noqa
import wpA_lib as A
import wpA_interleave as I
from strong import StrongSession

PHYS = ('physical_admissions', 'physical_finishes', 'raw_insertions', 'rank_computations', 'discarded')


def small_traces():
    return [A.reserved_eviction(0, n=40), A.decisive_holes(1, n=24, holes=4, kind='chain'),
            A.partial_mix(2, n=24), A.reserved_eviction(3, n=40, direction='BA') if 'direction' in
            A.reserved_eviction.__code__.co_varnames else A.reserved_eviction(3, n=40)]


class TestCorrectness(unittest.TestCase):
    def test_no_wrong_publication_any_policy(self):
        for tr in small_traces()[:2]:
            for pol in ('incumbent', 'gated', 'race', 'race_keep', 'gated_keep', 'ski', 'adaptive',
                        'shadow', 'gated_shadow'):
                r = A.make_runner(tr, pol, service_u=4, q_u=1).run(max_steps=20000)
                self.assertEqual(r['wrong'], 0, (tr['name'], pol))
                self.assertFalse(r['livelock'], (tr['name'], pol))
                self.assertEqual(r['published'], r['intents'], (tr['name'], pol))

    def test_persistent_tree_equals_fresh(self):
        tr = A.reserved_eviction(5, n=40)
        for pol in ('gated_keep', 'gated_shadow'):
            a = A.make_runner(tr, pol, service_u=4, q_u=1).run()
            b = A.make_runner(tr, pol, service_u=4, q_u=1, persistent=True).run()
            for k in ('latency_u',) + PHYS + ('proof_wins',):
                self.assertEqual(a[k], b[k], (pol, k))


class TestShadowLemma(unittest.TestCase):
    """Lemma S1: identical physical schedule, per-target latency <= incumbent, final current set superset."""
    def test_shadow_vs_incumbent(self):
        for tr in small_traces():
            for cap in (1, 3):
                for su, q in ((3, 1), (8, 4)):
                    kw = dict(service_u=su, q_u=q, capacity=cap)
                    ri = A.make_runner(tr, 'incumbent', **kw); inc = ri.run(max_steps=20000)
                    rs = A.make_runner(tr, 'gated_shadow', **kw); sh = rs.run(max_steps=20000)
                    for k in PHYS:
                        self.assertEqual(inc[k], sh[k], (tr['name'], kw, k))
                    self.assertEqual(inc['livelock'], sh['livelock'])
                    for t, l in inc['latency_u'].items():
                        self.assertLessEqual(sh['latency_u'][t], l, (tr['name'], kw, t))
                    self.assertTrue(set(ri.session.published) <= set(rs.session.published))

    def test_race_keep_counterexample_and_shadow_fix(self):
        cex = json.loads((ROOT / 'results/raw/wpA/race_keep_counterexample.json').read_text())
        tr = cex['trace']
        kw = dict(service_u=3, q_u=1, capacity=1)
        inc = A.make_runner(tr, 'incumbent', **kw).run()
        rk = A.make_runner(tr, 'race_keep', **kw).run()
        sh = A.make_runner(tr, 'gated_shadow', **kw).run()
        self.assertGreater(rk['total_latency_u'], inc['total_latency_u'])   # race_keep is NOT dominant
        self.assertLess(sh['total_latency_u'], inc['total_latency_u'])
        self.assertEqual(sh['physical_admissions'], inc['physical_admissions'])

    def test_boundary(self):
        tr = A.reserved_eviction(0, n=40)
        for su, q in ((4, 1), (4, 3), (4, 4), (4, 6), (8, 6), (2, 2)):
            r = A.make_runner(tr, 'gated_shadow', service_u=su, q_u=q).run()
            if not A.shadow_boundary(q, su):
                self.assertEqual(r['proof_wins'], 0, (su, q))

    def test_rebind_lifecycle_republishes_correctly(self):
        tr = A.reserved_eviction(7, n=40)
        ev = list(tr['events'])
        w = deepcopy(tr['world'][11]); w['raw'] += 5
        ev += [dict(at=75, op='rebind', item=11, witness=w), dict(at=120, op='evict_raw')]
        ev.sort(key=lambda e: e['at'])
        tr = dict(tr, events=ev)
        for pol in ('incumbent', 'gated_shadow', 'gated_keep'):
            runner = A.make_runner(tr, pol, service_u=4, q_u=1)
            r = runner.run()
            self.assertEqual(r['wrong'], 0, pol)
            self.assertEqual(r['rebinds'], 1)
            for t, u in runner.session.published.items():
                self.assertEqual(u, runner.truth[t], (pol, t))


class TestNegativeControls(unittest.TestCase):
    def test_race_cancel_discards_reusable_evidence(self):
        tr = A.reserved_eviction(0, n=40)
        inc = A.make_runner(tr, 'incumbent', service_u=8, q_u=1).run()
        rc = A.make_runner(tr, 'race', service_u=8, q_u=1).run()
        self.assertGreater(rc['race_cancels'], 0)
        self.assertGreaterEqual(rc['physical_admissions'], inc['physical_admissions'])

    def test_capacity1_livelock_and_resident_fix(self):
        tr = A.reserved_eviction(0, n=40)
        bad = A.ARunner(tr, policy='incumbent', capacity=1, resident_aware=False).run(max_steps=300)
        good = A.ARunner(tr, policy='incumbent', capacity=1, resident_aware=True).run(max_steps=3000)
        self.assertTrue(bad['livelock'] or bad['published'] < bad['intents'])
        self.assertFalse(good['livelock'])
        self.assertEqual(good['published'], good['intents'])


class TestInterleavings(unittest.TestCase):
    def test_session_invariants_subset(self):
        import itertools
        sc = I.small_case()
        orders = list(itertools.permutations(I.EVENTS))[::97]
        for o in orders:
            self.assertEqual(I.run_order(sc, o), [], o)

    def test_mutants_caught(self):
        import itertools
        sc = I.small_case()
        orders = list(itertools.permutations(I.EVENTS))[::7]
        for m in ('publish_no_support', 'cancel_frees_slot'):
            self.assertTrue(any(I.run_order(sc, o, m) for o in orders), m)
        # honest negative: keeping old certificates across rebind is NOT observable, because the
        # binding counter in the publish guard already rejects them (clearing is defence in depth)
        self.assertFalse(any(I.run_order(sc, o, 'rebind_keeps_certs') for o in orders[::5]))


if __name__ == '__main__':
    unittest.main()
