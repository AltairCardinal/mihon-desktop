"""I01-I06 and J01-J06 experiments on the WP-H physical simulator (virtual u).

All exogenous intents and all service latents are generated from fixed seeds
before any policy runs; latents are keyed by (identity, attempt).
"""
import json
import random
import sys
from pathlib import Path

import paths  # noqa: F401
from wpH_sched import Sim, latent

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpH'


def run(cap, intents, lat, policy=None, bounds=None, hooks=None):
    return Sim(cap, lat, policy, bounds).run(intents, hooks=hooks)


# ------------------------------------------------------------------ I01
def i01(seed=1):
    """Shared tasks with blocking depth; required-first vs critical vs fifo."""
    rng = random.Random(seed)
    idents = [f'x{k}' for k in range(30)]
    lat = {x: latent(seed, x, 0, 1, 12) for x in idents}
    intents = []
    t = 0
    for k in range(60):
        t += rng.choice((0, 1, 2))
        needs = rng.sample(idents, rng.choice((1, 2, 3)))
        intents.append(dict(at=t, id=k, needs=needs, required=rng.random() < .6))
    out = {}
    for order in ('fifo', 'required_first', 'critical'):
        for cap in (1, 2, 4):
            r = run(cap, intents, lat, dict(order=order))
            out[f'{order}_C{cap}'] = r
    # bound-aware critical (declared bound = true latent: idealised upper envelope, labelled)
    for cap in (1, 2, 4):
        out[f'critical_boundaware_C{cap}'] = run(cap, intents, lat, dict(order='critical'), bounds=lat)
    # counterexample: 'most consumers first' delays a short single-consumer required intent
    lat2 = {'big': 10, 'small': 1}
    ints2 = [dict(at=0, id='a', needs=['big'], required=True), dict(at=0, id='b', needs=['big'], required=True),
             dict(at=0, id='c', needs=['small'], required=True)]
    cex = {o: run(1, ints2, lat2, dict(order=o)) for o in ('fifo', 'critical')}
    cex['critical_boundaware'] = run(1, ints2, lat2, dict(order='critical'), bounds={'big': 10, 'small': 1})
    cex['smith'] = run(1, ints2, lat2, dict(order='smith'), bounds={'big': 10, 'small': 1})
    for cap in (1, 2, 4):
        out[f'smith_C{cap}'] = run(cap, intents, lat, dict(order='smith'), bounds=lat)
    return dict(grid=out, counterexample=cex,
                note='critical = required, then most blocked consumers, then declared bound; without bounds it can '
                     'delay a short intent (total 31 vs 22 style cex); bound-aware ordering needs a declared upper bound')


# ------------------------------------------------------------------ I02 / X23
def burst_workload(seed, n_opt=6, opt_len=(3, 40), bursts=4, cap=1):
    rng = random.Random(seed)
    lat, intents, bounds = {}, [], {}
    for k in range(n_opt):
        x = f'opt{k}'
        lat[x] = latent(seed, x, 0, *opt_len)
        bounds[x] = -(-lat[x] // 10) * 10      # declared honest upper bound (rounded up to 10u)
        intents.append(dict(at=k * 3, id=f'o{k}', needs=[x], required=False))
    t = 5
    for b in range(bursts):
        t += rng.randrange(15, 40)
        for j in range(3):
            x = f'req{b}_{j}'
            lat[x] = latent(seed, x, 0, 1, 4)
            bounds[x] = 4
            intents.append(dict(at=t + j, id=f'r{b}_{j}', needs=[x], required=True))
    return intents, lat, bounds


def i02(seeds=range(6)):
    rows = []
    for seed in seeds:
        for cap in (1, 2, 3):
            ints, lat, bounds = burst_workload(seed, cap=cap)
            for name, pol in (('none', dict(order='required_first')),
                              ('fixed1', dict(order='required_first', reserve=1)),
                              ('dyn_b10', dict(order='required_first', reserve=1, dyn_reserve_bound=10)),
                              ('dyn_b20', dict(order='required_first', reserve=1, dyn_reserve_bound=20))):
                r = run(cap, ints, lat, pol, bounds)
                rows.append(dict(seed=seed, C=cap, policy=name, required_max=r['required_max'],
                                 required_p95=r['required_p95'], optional_max=r['optional_max'],
                                 optional_served=r['optional_n'], unserved=r['unserved'], end_u=r['end_u']))
    # mutant: logical cancel frees the slot -> physical concurrency exceeds C
    lat = {'long': 30, 'r': 2}
    ints = [dict(at=0, id='o', needs=['long'], required=False), dict(at=1, id='q', needs=['r'], required=True)]
    hooks = dict(on_intent=lambda sim, it: sim.cancel('long', 'o') if it['id'] == 'q' else None)
    good = Sim(1, lat, dict(order='required_first')).run(ints, hooks=hooks)
    bad = Sim(1, lat, dict(order='required_first', mutant_cancel_releases=True)).run(ints, hooks=hooks)
    return dict(rows=rows, mutant=dict(correct=dict(max_physical=good['max_physical'], required_max=good['required_max']),
                                       cancel_releases=dict(max_physical=bad['max_physical'],
                                                            required_max=bad['required_max'])))


# ------------------------------------------------------------------ I03 / X16
def i03(seeds=range(8)):
    """Fan-out k consumers of one slow shared witness X vs any-of bypass Y."""
    rows = []
    for seed in seeds:
        for fan in (1, 3, 6):
            for slow in (5, 20, 60):
                lat = {'X': slow}
                ints = [dict(at=0, id='pre', needs=['X'], required=False)]
                for j in range(fan):
                    y = f'Y{j}'
                    lat[y] = latent(seed, y, 0, 2, 6)
                    ints.append(dict(at=1 + j, id=f't{j}', needs=['X', y], any_of=True, required=True))
                bounds = dict(lat)
                for pol in ('wait', 'bypass_b8', 'always_both'):
                    def hook(sim, it, pol=pol):
                        if not it['id'].startswith('t'):
                            return
                        x = sim.tasks.get('X')
                        if pol == 'wait':
                            sim.intents[it['id']]['needs_used'] = ['X']
                            return
                        remaining = (x.start + bounds['X'] - sim.now) if (x is not None and x.start is not None) else bounds['X']
                        if pol == 'always_both' or remaining > 8:
                            return     # keep the Y request (bypass)
                        sim.cancel(it['needs'][1], it['id'])
                    # baseline 'wait': drop the Y requests (consumers wait on shared X only)
                    def hook_wait(sim, it):
                        if it['id'].startswith('t'):
                            sim.cancel(it['needs'][1], it['id'])
                    r = run(2, ints, lat, dict(order='required_first'), bounds,
                            dict(on_intent=hook_wait if pol == 'wait' else hook))
                    rows.append(dict(seed=seed, fan=fan, slow=slow, policy=pol, required_total=r['required_total'],
                                     required_max=r['required_max'], starts=r['starts'], busy_u=r['busy_u'],
                                     wasted_u=r['wasted_u']))
    return dict(rows=rows, note='capacity 2; bypass starts an independent alternative only if the declared remaining '
                                'bound of the shared task exceeds 8u; sharing minimises work but delays first results')


# ------------------------------------------------------------------ I04 / I05 / I06
def i04():
    """Joint (acquire+derive) vs split (derive only when needed) stage timing."""
    rows = []
    for a in (1, 5, 20):
        for d in (1, 5, 20):
            for p_need in (0.25, 0.5, 1.0):
                joint_work = a + d
                split_work = a + p_need * d
                joint_lat = a + d
                split_lat = a + d + 1      # one extra admission hop for the second stage (model: +1u)
                rows.append(dict(acquire=a, derive=d, p_need=p_need, joint_work=joint_work, split_work=split_work,
                                 joint_latency=joint_lat, split_latency_when_needed=split_lat,
                                 split_wins_work=split_work < joint_work))
    return dict(rows=rows, note='split saves (1-p_need)*d work but costs one extra admission hop when the derived '
                                'fact is needed; phase boundary = d > hop/(1-p_need)')


def i05(seed=3):
    rng = random.Random(seed)
    lat, ints = {}, []
    t = 0
    for k in range(40):
        t += rng.choice((1, 2, 3))
        x = f'b{k}'
        lat[x] = latent(seed, x, 0, 1, 3) if k % 9 else 25     # a slow member every 9th
        ints.append(dict(at=t, id=k, needs=[x], required=True))
    out = {}
    out['immediate_setup4'] = None
    # immediate: setup folded into each task
    lat_imm = {x: v + 4 for x, v in lat.items()}
    out['immediate_setup4'] = run(2, ints, lat_imm, dict(order='fifo'))
    for barrier in (True, False):
        for mw in (None, 3, 8):
            out[f'batch4_barrier{barrier}_maxwait{mw}'] = run(
                2, ints, lat, dict(order='fifo', batch=dict(size=4, setup=4, per_item=None, barrier=barrier,
                                                            max_wait=mw)))
    return out


def i06():
    rows = []
    lat = {f'x{k}': 3 for k in range(40)}
    ints = [dict(at=k, id=k, needs=[f'x{k}'], required=True) for k in range(40)]
    for delay in (0, 1, 2):
        for rb in (None, 2, 8, 10 ** 6):
            r = run(3, ints, lat, dict(order='fifo', result_buffer=rb, consume_delay=delay, serial_consumer=True))
            rows.append(dict(consume_delay=delay, result_buffer=rb, required_total=r['required_total'],
                             required_max=r['required_max'], max_slots=r['max_slots'], max_buffer=r['max_buffer'],
                             memory_bound=3 + (rb if rb is not None else 0), end_u=r['end_u']))
    return dict(rows=rows, note='serial consumer taking consume_delay u per result; producer 1 result/u at C=3 '
                                'service 3u; result_buffer None = Session semantics (completed result keeps its slot); 10**6 = '
                                'effectively unbounded buffer: throughput like a free consumer but max_buffer grows '
                                'with the backlog -> no memory bound')


# ------------------------------------------------------------------ J01 / J06
def target_seq(pattern, n=30, count=60, seed=0):
    rng = random.Random(seed)
    t, d, out = 0, 1, []
    for k in range(count):
        if pattern == 'forward':
            t = (t + 1) % n
        elif pattern == 'reverse':
            t = (t - 1) % n
        elif pattern == 'zigzag':
            if not 0 <= t + d < n:
                d = -d
            t += d
        elif pattern == 'jump':
            t = rng.randrange(n)
        elif pattern == 'drift':
            d = 1 if (k // 15) % 2 == 0 else -1
            t = (t + d) % n
        out.append(t)
    return out


def j01(seeds=range(4)):
    rows = []
    for seed in seeds:
        for pattern in ('forward', 'reverse', 'zigzag', 'jump', 'drift'):
            seq = target_seq(pattern, seed=seed)
            lat = {f'w{i}': latent(seed, f'w{i}', 0, 3, 8) for i in range(30)}
            for pol in ('none', 'idle_only', 'lowerbound_gate'):
                budget = [30]
                hist = []
                acc = []

                def hook(sim, it, pol=pol, budget=budget, hist=hist, acc=acc):
                    tgt = it['tgt']
                    if hist:
                        acc.append(1 if (hist[-1][1] == tgt) else 0)
                    pred = None
                    if len(hist) >= 2:
                        step = hist[-1][0] - hist[-2][0]
                        pred = (hist[-1][0] + 2 * step - step) % 30 if False else (tgt + step) % 30
                    hist.append((tgt, pred))
                    if pol == 'none' or pred is None or budget[0] <= 0:
                        return
                    if pol == 'idle_only' and sim.slots_used() + len(sim.queue) >= sim.C:
                        return
                    if pol == 'lowerbound_gate':
                        recent = acc[-6:]
                        # lower confidence bound on accuracy (rule of three style): need >= 5/6 hits
                        if len(recent) < 4 or sum(recent) < len(recent) - 1:
                            return
                    budget[0] -= 1
                    sim.request(f'w{pred}', False, f'spec{len(hist)}')
                ints = [dict(at=4 * k, id=k, tgt=tg, needs=[f'w{tg}'], required=True) for k, tg in enumerate(seq)]
                r = run(2, ints, lat, dict(order='required_first', retain=6), hooks=dict(on_intent=hook))
                rows.append(dict(seed=seed, pattern=pattern, policy=pol, required_total=r['required_total'],
                                 required_p95=r['required_p95'], required_max=r['required_max'], starts=r['starts'],
                                 speculative_used=30 - budget[0]))
    return dict(rows=rows, note='equal total speculative budget 30 per run; capacity 2; arrivals every 4u; consumed '
                                'results retained in an LRU of 6 (bounded raw residency)')


def j06():
    """Global speculative credit vs per-target isolation; hotspot starvation counterexample."""
    # two targets: H (hotspot, predictions always wrong) and G (predictions right). Global credit 6.
    res = {}
    for mode in ('global', 'isolated'):
        credit = {'global': 6} if mode == 'global' else {'H': 3, 'G': 3}
        spent = {'H': 0, 'G': 0}
        hits = {'H': 0, 'G': 0}
        order = ['H'] * 8 + ['G'] * 4      # hotspot asks first and often
        for who in order:
            key = 'global' if mode == 'global' else who
            if credit[key] > 0:
                credit[key] -= 1
                spent[who] += 1
                hits[who] += 1 if who == 'G' else 0
        res[mode] = dict(spent=spent, useful_hits=hits)
    return dict(result=res, note='global credit: the always-wrong hotspot drains all 6 credits and G gets 0 '
                                 '(starvation); isolation guarantees G 3 credits; repayment rule: charge failed '
                                 'speculation to the target that requested it')


# ------------------------------------------------------------------ J02
def j02():
    rows = []
    for phase in (2, 5, 10):
        lat = {'long': 30, 'r': 2, 'long2': 30}
        ints = [dict(at=0, id='o', needs=['long'], required=False), dict(at=3, id='q', needs=['r'], required=True),
                dict(at=4, id='o2', needs=['long'], required=False)]

        def hook(sim, it):
            if it['id'] == 'q':
                sim.cancel('long', 'o')
        for name, pol in (('queued_only', dict(order='required_first')),
                          ('coop_exit', dict(order='required_first', coop_exit=True, phase_len=phase)),
                          ('coop_exit_revive', dict(order='required_first', coop_exit=True, phase_len=phase, revive=True)),
                          ('revive_only', dict(order='required_first', revive=True))):
            r = run(1, ints, lat, pol, hooks=dict(on_intent=hook))
            rows.append(dict(phase_len=phase, policy=name, required_max=r['required_max'], optional_max=r['optional_max'],
                             wasted_u=r['wasted_u'], starts=r['starts'], coop_exits=r['coop_exits'],
                             revives=r.get('revives', 0)))
    return dict(rows=rows, note='o is cancelled at t=3 when required q arrives (C=1); o2 re-requests the same long '
                                'witness at t=4: revive re-attaches to the still-running instance (no restart)')


# ------------------------------------------------------------------ J03 / X24
def j03(seed=5):
    rng = random.Random(seed)
    lat, ints = {}, []
    t = 0
    for k in range(80):
        t += rng.choice((1, 1, 2))
        x = f'z{k}'
        req = rng.random() < 0.7
        lat[x] = latent(seed, x, 0, 1, 3) if req else latent(seed, x, 0, 2, 6)
        ints.append(dict(at=t, id=k, needs=[x], required=req))
    rows = []
    for ab in (None, 120, 100, 80, 60, 40, 20, 0):
        pol = dict(order='aging', aging_bound=ab) if ab is not None else dict(order='required_first')
        r = run(1, ints, lat, pol)
        rows.append(dict(aging_bound=ab, optional_max=r['optional_max'], required_p50=r['required_p50'],
                         required_p95=r['required_p95'], required_max=r['required_max'],
                         required_total=r['required_total'], unserved=r['unserved']))
    return dict(rows=rows, note='load ~ 1 at C=1: no aging bound gives both small optional max wait and unchanged '
                                'required tail (service curve trade-off)')


# ------------------------------------------------------------------ J04 / X25
def j04():
    """Debounce: an intent's task must be redone when a dependency changes while it is in flight
    (stale completion discarded, nonpreemptible so the full service is wasted).  Intermediate
    versions are declared mergeable; the final version must be served."""
    rows = []
    S = 8
    for period in (2, 6, 15):
        for unrelated in (False, True):
            changes = [(k * period, 'dep') for k in range(1, 6)]
            if unrelated:
                changes += [(k * 3 + 1, 'other') for k in range(20)]
            changes.sort()
            deps = [c for c, kind in changes if kind == 'dep']
            last_dep = deps[-1]
            for pol, w in (('immediate', 0), ('global_w7', 7), ('relevant_w7', 7)):
                qual = [c for c, kind in changes if kind == 'dep' or (pol.startswith('global') and kind == 'other')]
                t, wasted, starts, served, finished = 0, 0, 0, 0, None
                for _guard in range(1000):
                    start = t
                    if w:
                        while True:
                            recent = [c for c in qual if start - w < c <= start]
                            if not recent:
                                break
                            start = max(recent) + w
                    starts += 1
                    end = start + S
                    if any(start < c <= end for c in deps):
                        wasted += S
                        t = end
                        continue
                    if start >= last_dep:
                        finished = end
                        break
                    served += 1
                    t = min(c for c in deps if c > end) if any(c > end for c in deps) else end
                rows.append(dict(change_period=period, unrelated=unrelated, policy=pol, starts=starts, wasted_u=wasted,
                                 intermediate_versions_served=served,
                                 final_wait_after_last_change=None if finished is None else finished - last_dep))
    return dict(rows=rows, note='service 8u; five dependency changes; unrelated changes every 3u reset a GLOBAL window '
                                '(never quiet for 7u -> start only after the unrelated stream ends); relevant-only '
                                'window ignores them')


# ------------------------------------------------------------------ J05
def j05():
    rows = []
    for lam_req, lam_opt in ((0.3, 0.3), (0.5, 0.4), (0.6, 0.6)):
        for pol in ('unbounded_queue', 'reject_optional_q4', 'degrade_optional_half'):
            for horizon in (200, 800):
                rng = random.Random(9)
                lat, ints = {}, []
                t = 0.0
                k = 0
                while t < horizon:
                    t += rng.expovariate(lam_req + lam_opt)
                    req = rng.random() < lam_req / (lam_req + lam_opt)
                    x = f'v{k}'
                    lat[x] = 2 if req else (1 if pol == 'degrade_optional_half' else 2)
                    ints.append(dict(at=int(t), id=k, needs=[x], required=req))
                    k += 1
                sim = Sim(1, lat, dict(order='required_first'))
                hooks = None
                if pol == 'reject_optional_q4':
                    def hook(s, it):
                        if not it['required'] and sum(1 for q in s.queue if not q.required) > 4:
                            s.cancel(it['needs'][0], it['id'])
                            s.intents[it['id']]['rejected'] = True
                    hooks = dict(on_intent=hook)
                r = sim.run(ints, horizon=horizon, hooks=hooks)
                rejected = sum(1 for it in sim.intents.values() if it.get('rejected'))
                rows.append(dict(lam_req=lam_req, lam_opt=lam_opt, rho=round(2 * lam_req + (lam_opt if pol == 'degrade_optional_half' else 2 * lam_opt), 2),
                                 policy=pol, horizon=horizon, required_max=r['required_max'], optional_max=r['optional_max'],
                                 unserved_at_horizon=r['unserved'] - rejected, rejected=rejected, max_queue=r['max_queue']))
    return dict(rows=rows, note='C=1, service 2u: required load 2*lam_req; at 2*lam_req>=1 no policy bounds required '
                                'latency as the horizon grows (impossibility); optional work can only be rejected or '
                                'degraded; unbounded queue hides unserved work in max_queue')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    res = dict(I01=i01(), I02=i02(), I03=i03(), I04=i04(), I05=i05(), I06=i06(), J01=j01(), J02=j02(), J03=j03(),
               J04=j04(), J05=j05(), J06=j06())
    (OUT / 'sched.json').write_text(json.dumps(res, indent=1, default=str))
    return res


if __name__ == '__main__':
    r = main()
    print(json.dumps({k: (list(v.keys()) if isinstance(v, dict) else len(v)) for k, v in r.items()}))
