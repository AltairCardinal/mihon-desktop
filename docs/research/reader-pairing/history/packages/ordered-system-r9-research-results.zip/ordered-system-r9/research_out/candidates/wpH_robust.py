"""R01-R06 robustness studies and the N03 bounded protocol checker on the
real coupled Session (no abstract re-implementation)."""
import itertools
import json
import random
from copy import deepcopy
from pathlib import Path

import paths  # noqa: F401
import reference as ref
from common import random_case, roundtrip, fact, base_case
from coupling import Session, Witness
from corrected_owner import Owner, Config, SAT
from current_baseline import typed
import transducer as T
import omega as O

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpH'


def sel(case, t):
    return {k: v for k, v in ref.certify_strategy(case, t)['selected'].items() if k != 'reads'}


# ------------------------------------------------------------------ R01
def r01():
    """Identity change and its replacement evidence committed in two separate
    atomic writes: the intermediate state certifies with the OLD analysis under
    the NEW content identity."""
    c = base_case(5, automatic=True)
    o_split, o_atomic = Owner(c), Owner(c)
    t = 2
    new_analysis = dict(status='computed', fact=fact('WIDE'), version=2)
    # split: identity first
    o_split.apply(item_updates={t: {'content_version': 1}})
    mid = o_split.request(t)
    o_split.apply(item_updates={t: {'analysis': new_analysis}})
    end = o_split.request(t)
    # atomic
    o_atomic.apply(item_updates={t: {'content_version': 1, 'analysis': new_analysis}})
    at = o_atomic.request(t)
    truth = sel(dict(c, items=[dict(x) for x in c['items']]), t)
    cc = deepcopy(c); cc['items'][t]['content_version'] = 1; cc['items'][t]['analysis'] = new_analysis
    final_truth = sel(cc, t)
    # coupled Session admission is per witness: analysis then ranks in two owner writes; show that
    # every intermediate state is a legal knowledge state (ranks simply unknown) - no proof can see
    # a rank derived from a witness whose analysis was not yet admitted.
    s = Session(dict(base_case(4, automatic=True), edges=[]))
    for i in range(4):
        s.owner.apply(item_updates={i: {'analysis': {'status': 'unknown'}}})
    tok = s.acquire(1); s.finish(tok, Witness(dict(status='computed', fact=fact(), version=1), 5)); s.consume(tok)
    tok = s.acquire(2)
    s.finish(tok, Witness(dict(status='computed', fact=fact(), version=1), 7))
    seen = []
    orig = s.owner.apply

    def spy(**kw):
        r = orig(**kw)
        seen.append((sorted(kw.get('item_updates') or {}), sorted(kw.get('edge_updates') or {})))
        return r
    s.owner.apply = spy
    s.consume(tok)
    return dict(split_intermediate_status=mid['status'], split_intermediate_unit=mid['unit'],
                split_final_unit=end['unit'], atomic_unit=at['unit'], final_truth_unit=final_truth['unit'],
                split_intermediate_wrong=(mid['status'] == 'certified' and mid['unit'] != final_truth['unit']),
                session_consume_writes=seen,
                note='identity+evidence must be one atomic batch (Owner.apply already supports it); per-fact commit '
                     'is safe only for facts that are individually valid evidence (analysis, then derived ranks)')


# ------------------------------------------------------------------ R02
def detect_inconsistency(case, domain='nonneg', alpha=False):
    """Explicit inconsistency verdicts instead of silent widening / vacuous truth."""
    issues = []
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        issues.append('known_rank_outside_declared_domain')
    ix = F.ix
    for (a, b), e in ix._edge_index().items():
        if e.get('status') == 'computed' and e.get('score') is not None and b == a + 1 and 0 <= a < F.n - 1:
            for p in (a, b):
                an = ix.analysis(p)
                if an[0] == 'computed' and an[1] is not None and an[1][0] == 'WIDE':
                    issues.append(f'numeric_rank_on_WIDE_endpoint_{a}_{b}')
    if alpha:
        for p in range(F.n):
            an, h = ix.analysis(p), ix.header(p)
            if an[0] == 'computed' and h is not None and T._valid(h, ix.ident(p)) and an[1][0] != h[0]:
                issues.append(f'alpha_header_contradiction_{p}')
    return issues


def r02():
    rows = []
    c = base_case(5, automatic=True)
    c['edges'][1]['score'] = -2.0
    rows.append(dict(case='negative rank in nonneg domain', issues=detect_inconsistency(c),
                     strong_route='widens to ext (reference FORMAL §2) -> certificate valid only in ext'))
    c = base_case(5, automatic=True)
    c['items'][2]['analysis']['fact'] = fact('WIDE')
    c['edges'][1]['score'] = 3.0
    rows.append(dict(case='numeric rank stored on WIDE endpoint', issues=detect_inconsistency(c),
                     reference_reads=ref._Input(c).edge(1, 2)))
    c = base_case(5, automatic=False)
    c['items'][2]['analysis']['fact'] = fact('WIDE')
    rows.append(dict(case='alpha claimed, analysis contradicts valid header', issues=detect_inconsistency(c, alpha=True)))
    # empty completion set must never certify: exact DP with zero frontier returns no unit
    c = base_case(3, automatic=True)
    st = O.certify_exact(c, 1, 'nonneg', False)
    rows.append(dict(case='nonempty sanity', status=st[0]))
    # construct an empty-world probe: a domain whose candidate set cannot satisfy a forced comparison
    feas = T.feasible(frozenset({((('e', 1), ('k', 0)), True)}), 'nonneg')
    rows.append(dict(case='x < 0 in nonneg', feasible=feas,
                     note='infeasible branch removed; a proof over an EMPTY set returns ambiguous (0 units), never '
                          'certified, because certification requires exactly one unit'))
    return rows


# ------------------------------------------------------------------ R03
def r03():
    """Event truth table for one item: every sequence of <=4 events from the alphabet,
    checking idempotence and stale rejection on the real Session."""
    alphabet = ['acq', 'fin_ok', 'fin_fail', 'consume', 'cancel', 'rebind', 'fin_old']
    table = {}
    viol = []
    for L in range(1, 5):
        for seq in itertools.product(alphabet, repeat=L):
            s = Session(dict(base_case(3, automatic=True), edges=[]), capacity=2)
            for i in range(3):
                s.owner.apply(item_updates={i: {'analysis': {'status': 'unknown'}}})
            tok = None
            old = None
            out = []
            for e in seq:
                if e == 'acq':
                    nt = s.acquire(1)
                    if tok is not None and nt != tok:
                        old = tok
                    tok = nt
                    out.append('tok' if nt else 'full')
                elif e == 'fin_ok':
                    out.append(s.finish(tok, Witness(dict(status='computed', fact=fact(), version=1), 1)) if tok else 'none')
                elif e == 'fin_fail':
                    out.append(s.finish(tok, Witness(dict(status='failed', reason='RESOURCE'), available=False)) if tok else 'none')
                elif e == 'fin_old':
                    out.append(s.finish(old, Witness(dict(status='computed', fact=fact('WIDE'), version=1), 9)) if old else 'none')
                elif e == 'consume':
                    out.append(s.consume(tok) if tok else 'none')
                elif e == 'cancel':
                    out.append(s.cancel(tok) if tok else 'none')
                elif e == 'rebind':
                    s.rebind(s.owner.snapshot()); old = tok; tok = None
                    out.append('rebound')
                # invariants
                if s.occupied > s.capacity:
                    viol.append((seq, 'capacity'))
                a = s.owner._case['items'][1]['analysis']
                if a.get('status') == 'computed' and a['fact']['state'] == 'WIDE':
                    viol.append((seq, 'stale_admitted'))
            if L <= 2:
                table[' '.join(seq)] = out
    return dict(sequences=sum(len(alphabet) ** L for L in range(1, 5)), violations=viol[:10], n_violations=len(viol),
                table_len_le2=table)


# ------------------------------------------------------------------ R04
def r04():
    rows = []
    configs = []
    for n in (1, 2, 3):
        for automatic in (True, False):
            for direction in ('AB', 'BA'):
                for opening in ('AUTO', 'PAIR', 'SINGLE'):
                    for iso in ([], list(range(n))):
                        for pins in ([], list(range(max(0, n - 1)))):
                            configs.append((n, automatic, direction, opening, iso, pins))
    mism = 0
    strong_mism = 0
    for (n, automatic, direction, opening, iso, pins) in configs:
        c = base_case(n, automatic, direction, opening, iso, pins)
        o = Owner(c)
        from strong import StrongSession
        ss = StrongSession(c)
        for t in range(n):
            want = sel(c, t)
            got = o.request(t)
            mism += got != want
            sv = ss.certify(t, mode='S')
            if sv['status'] == 'certified':
                strong_mism += sv['unit'] != next(u for u in ref.complete_plan(c) if any(s['item'] == t for s in u['slots']))
    try:
        Owner(dict(base_case(1), items=[], edges=[])).request(0)
        n0 = 'accepted'
    except ValueError as e:
        n0 = 'ValueError: ' + str(e)
    return dict(configs=len(configs), owner_public_field_mismatches=mism, strong_unit_mismatches=strong_mism,
                n0_request=n0, note='n=0 has no valid target: every request is rejected by ordinal validation')


# ------------------------------------------------------------------ R05 / X29
def r05(widths=(2, 3), depth=None):
    """Exhaustive small-width revision counters: wrap vs saturate+exact fallback vs incarnation switch.
    Model: one memo entry; events W (relevant write changing the support), N (unrelated write),
    R (request).  A stale hit = memo returns a result although a relevant write happened since storing."""
    res = {}
    for w in widths:
        maxv = (1 << w) - 1
        for mode in ('wrap', 'saturate_exact', 'incarnation_switch'):
            stale = 0
            exact_checks = 0
            total = 0
            for seq in itertools.product('WNR', repeat=depth or ((1 << w) + 2)):
                rev, inc = 0, 0
                memo = None       # (stamp_rev, stamp_inc, support_version)
                support_version = 0
                for e in seq:
                    if e in 'WN':
                        if e == 'W':
                            support_version += 1
                        if mode == 'wrap':
                            rev = (rev + 1) & maxv
                        elif mode == 'saturate_exact':
                            rev = min(maxv, rev + 1)
                        else:
                            if rev == maxv:
                                inc += 1; rev = 0; memo = None if memo is None else memo   # new incarnation
                            else:
                                rev += 1
                    else:
                        total += 1
                        if memo is not None:
                            fast = (memo[0] == rev and memo[1] == inc)
                            if mode == 'saturate_exact' and rev == maxv:
                                fast = False
                            if fast:
                                if memo[2] != support_version:
                                    stale += 1
                                continue
                            exact_checks += 1
                            if memo[2] == support_version:
                                memo = (rev, inc, support_version)    # refresh stamp after exact success
                                continue
                        memo = (rev, inc, support_version)
            res[f'w{w}_{mode}'] = dict(stale_hits=stale, exact_checks=exact_checks, requests=total)
    # real Owner: forced saturation keeps exact validation (no stale hit) - executable check
    c = base_case(5, automatic=True)
    o = Owner(c)
    o.request(2)
    o._revision = SAT
    c2 = deepcopy(c); c2['items'][2]['analysis']['fact'] = fact('WIDE')
    o.apply(item_updates={2: {'analysis': c2['items'][2]['analysis']}})
    got = o.request(2)
    res['owner_saturated_relevant_change_correct'] = got == sel(c2, 2)
    return res


# ------------------------------------------------------------------ R06
def r06(seeds=range(40)):
    """Fault injection: an exception raised inside owner.apply during consume (after the task permit is
    released and analysis admitted, before ranks), inside certify (strong attempt) and inside publish.
    After recovery: no stale or wrong publication, occupied <= capacity, raw entries current."""
    from strong import StrongSession
    viol = []
    stats = dict(injected=0, recovered=0)
    for seed in seeds:
        rng = random.Random(seed)
        n = 8
        c = roundtrip(random_case(rng, n, p_unknown=0.5, p_edge_unknown=0.5, settings_mix=False))
        world = [dict(analysis=dict(status='computed', fact=deepcopy(it['header']), version=1), raw=rng.randrange(9))
                 for it in c['items']]
        s = StrongSession(c, capacity=2)
        for step in range(30):
            i = rng.randrange(n)
            tok = s.acquire(i)
            if tok is None:
                tok = next(iter(s._tasks))
            if s._tasks.get(tok, {}).get('phase') == 'running':
                s.finish(tok, Witness(**world[s._tasks[tok]['item']]))
            orig = s.owner.apply
            if rng.random() < 0.3:
                calls = [0]

                def flaky(**kw):
                    calls[0] += 1
                    if calls[0] == 2:
                        raise RuntimeError('injected')
                    return orig(**kw)
                s.owner.apply = flaky
                stats['injected'] += 1
            try:
                s.consume(tok)
            except RuntimeError:
                stats['recovered'] += 1
            finally:
                s.owner.apply = orig
            t = rng.randrange(n)
            v = s.certify(t, mode='S')
            if v['status'] == 'certified':
                s.publish(t, v['certificate'])
            if s.occupied > s.capacity:
                viol.append((seed, step, 'capacity'))
            snap = s.owner.snapshot()
            for tt, u in s.published.items():
                cur = sel(snap, tt)
                if cur['status'] == 'certified' and cur['unit'] != u:
                    viol.append((seed, step, 'published_unit_differs_from_current_certificate'))
            for j in list(s._raw):
                s._raw_current(j)
    return dict(stats, violations=viol[:5], n_violations=len(viol),
                note='an exception between the analysis write and the rank write leaves a legal knowledge state '
                     '(analysis admitted, ranks unknown); certificates and publications are validated by support')


# ------------------------------------------------------------------ N03 bounded checker on the real Session
def n03(max_depth=6, cap_values=(1, 2)):
    """BFS over event sequences on real Session objects (2 items, symmetric witnesses), with
    canonicalisation of the observable protocol state and item-permutation symmetry reduction."""
    results = {}
    alphabet = [('acq', 0), ('acq', 1), ('opt', 0), ('fin', 0), ('fin', 1), ('con', 0), ('con', 1),
                ('can', 0), ('can', 1), ('cert', 0), ('pub', 0), ('conf', 0), ('rebind', None)]
    w = Witness(dict(status='computed', fact=fact(), version=1), 2)
    for cap in cap_values:
        for symmetric in (False, True):
            def canon(s):
                tasks = tuple(sorted((tk.identity[1][0][1] if False else s._tasks[tk]['item'],
                                      s._tasks[tk]['phase'], s._tasks[tk]['cancelled'], s._tasks[tk]['required'])
                                     for tk in s._tasks))
                items = tuple(s.owner._case['items'][i]['analysis'].get('status') for i in range(2))
                pubs = tuple(sorted(s._published))
                conf = tuple(sorted(s._confirmed))
                key = (tasks, items, pubs, conf, s.epoch > 0, len(s._certs) > 0)
                if symmetric:
                    swapped = (tuple(sorted(((1 - x[0]),) + x[1:] for x in tasks)), items[::-1], pubs, conf, key[4], key[5])
                    key = min(key, swapped, key=repr)
                return key
            base = dict(base_case(2, automatic=True), edges=[])
            s0 = Session(base, capacity=cap)
            for i in range(2):
                s0.owner.apply(item_updates={i: {'analysis': {'status': 'unknown'}}})
            frontier = [(s0, [])]
            seen = {canon(s0)}
            states = 1
            viol = []
            for d in range(max_depth):
                nxt = []
                for s, hist in frontier:
                    for op, i in alphabet:
                        x = deepcopy(s)
                        handle = getattr(x, '_last_handle', None)
                        try:
                            if op in ('acq', 'opt'):
                                x.acquire(i, required=(op == 'acq'))
                            elif op == 'fin':
                                tk = next((k for k, v in x._tasks.items() if v['item'] == i and v['phase'] == 'running'), None)
                                if tk is None:
                                    continue
                                x.finish(tk, w)
                            elif op == 'con':
                                tk = next((k for k, v in x._tasks.items() if v['item'] == i and v['phase'] == 'completed'), None)
                                if tk is None:
                                    continue
                                x.consume(tk)
                            elif op == 'can':
                                tk = next((k for k, v in x._tasks.items() if v['item'] == i), None)
                                if tk is None:
                                    continue
                                x.cancel(tk)
                            elif op == 'cert':
                                v = x.certify(0, mode='L0')
                                x._last_handle = v.get('certificate')
                            elif op == 'pub':
                                if handle is None:
                                    continue
                                x.publish(0, handle)
                            elif op == 'conf':
                                x.confirm(0)
                            elif op == 'rebind':
                                x.rebind(deepcopy(base)); x._last_handle = None
                        except ValueError as e:
                            viol.append((hist + [(op, i)], 'exception ' + str(e)))
                            continue
                        # invariants
                        if x.occupied > x.capacity:
                            viol.append((hist + [(op, i)], 'capacity'))
                        if not set(x._confirmed) <= set(x._published):
                            viol.append((hist + [(op, i)], 'confirm_without_publication'))
                        for tgt, h in x._published_handles.items():
                            cert = x._certs.get(h)
                            if cert is None or cert['epoch'] != x.epoch:
                                viol.append((hist + [(op, i)], 'publication_from_old_epoch'))
                        k = canon(x)
                        if k not in seen:
                            seen.add(k)
                            nxt.append((x, hist + [(op, i)]))
                            states += 1
                frontier = nxt
                if states > 20000:
                    break
            results[f'C{cap}_{"sym" if symmetric else "plain"}'] = dict(states=states, depth=d + 1,
                                                                        violations=viol[:5], n_violations=len(viol))
    return results


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    res = dict(R01=r01(), R02=r02(), R03=r03(), R04=r04(), R05=r05(), R06=r06(), N03=n03())
    (OUT / 'robust.json').write_text(json.dumps(res, indent=1, default=str))
    return res


if __name__ == '__main__':
    r = main()
    print(json.dumps({k: (v if k != 'R03' else {kk: vv for kk, vv in v.items() if kk != 'table_len_le2'}) for k, v in r.items()},
                     indent=1, default=str)[:6000])
