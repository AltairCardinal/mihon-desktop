"""WP-H coupled runner extension (virtual u).

Adds to coupled_runner.Runner: a pluggable session class, exogenous 'prefetch'
(optional acquisition), 'rebind' (same-content new owner binding), 'churn'
(an admitted-evidence write by the harness that does not change truth, e.g.
re-delivery of an equal fact with a new version label, or an unrelated item's
analysis version bump) and 'confirm' events, plus a reservation admission
gate for optional work.  Lifecycle audit at the end: occupied tasks, raw size,
current publications vs truth, confirmations subset of publications.
"""
from copy import deepcopy

import paths  # noqa: F401
import coupled_runner as CR
from strong import StrongSession


class ReservingSession(StrongSession):
    """I02 in the coupled Session: optional acquisitions may use at most
    capacity-reserve slots (required ones may use all).  Cancelling does not
    free a running slot (inherited nonpreemptible semantics)."""

    reserve = 1

    def acquire(self, i, *, required=True):
        if not required:
            template = self._token(i)
            shared = any(self._physical(tk) == self._physical(template) for tk in self._tasks)
            if not shared and self.occupied >= self.capacity - self.reserve:
                self.metrics['reservation_refusals'] += 1
                return None
        return super().acquire(i, required=required)


class RunnerH(CR.Runner):
    def __init__(self, trace, *, session_cls=StrongSession, bound_confirm=False, **kw):
        super().__init__(trace, **kw)
        strong = kw.get('strong')
        self.session = session_cls(trace['initial'], capacity=kw.get('capacity', 3),
                                   raw_capacity=kw.get('raw_capacity', 3), strong=strong)
        self.bound_confirm = bound_confirm
        self.pub_handle = {}
        self.audit = dict(confirm_results={}, rebinds=0, churn_writes=0)

    def _publish(self, target, verdict):
        r = super()._publish(target, verdict)
        if r == 'published':
            self.pub_handle[target] = verdict['certificate']
            self.handle_history = getattr(self, 'handle_history', {})
            self.handle_history.setdefault(target, []).append(verdict['certificate'])
        return r

    def run(self, horizon=10 ** 6):
        # wrap the external-event dispatcher by pre-expanding custom events into callbacks
        ext = []
        for ev in self.trace['events']:
            ext.append(ev)
        self.trace = dict(self.trace, events=[e for e in ext if e['op'] in ('target', 'tick')])
        for ev in ext:
            if ev['op'] not in ('target', 'tick'):
                self._push(ev['at'], 'custom', ev)
        return self._run_with_custom(horizon)

    def _run_with_custom(self, horizon):
        import heapq
        for ev in self.trace['events']:
            self._push(ev['at'], 'ext', ev)
        while self.q:
            t, _s, kind, payload = heapq.heappop(self.q)
            if t > horizon:
                break
            self.now = t
            if kind == 'service':
                token, i = payload
                self.scheduled.discard(token)
                if token in self.session._tasks:
                    self.session.finish(token, self.world.complete(i))
                    self.session.consume(token)
                self.drive()
            elif kind == 'proof':
                (tt,) = payload
                if self.proof_pending and self.proof_pending[0] == tt:
                    self._finish_proof(tt, self.proof_pending[1])
                    self.blocked_until = -1
                    self.drive()
            elif kind == 'custom':
                self._custom(payload)
                self.drive()
            else:
                ev = payload
                if ev['op'] == 'target':
                    self.active = ev['target']
                    self.intent.setdefault(ev['target'], t)
                    self.drive()
                else:
                    self.drive()
            self._schedule_tasks()
        return self._result()

    def _custom(self, ev):
        s = self.session
        op = ev['op']
        if op == 'prefetch':
            s.acquire(ev['item'], required=False)
        elif op == 'rebind':
            # same content, new owner binding: current admitted knowledge is carried as the new partial case
            case = s.owner.snapshot()
            s.rebind(case)
            self.audit['rebinds'] += 1
            # every target whose publication was dropped must be re-served: re-open intents
            for k in list(self.first_pub):
                self.first_pub.pop(k)
                self.intent[k] = self.now
            self.pub_handle.clear()
            self.scheduled = {tk for tk in self.scheduled if tk in s._tasks}
        elif op == 'cancel':
            # exogenous cancellation of one in-flight physical task (lowest issuance first); nonpreemptible:
            # a running task keeps its slot until its service event, whose completion is then discarded
            live = sorted(s._tasks, key=lambda tk: tk.issuance if hasattr(tk, 'issuance') else str(tk))
            if live:
                r = s.cancel(live[0])
                self.audit['cancels'] = self.audit.get('cancels', 0) + 1
                self.audit.setdefault('cancel_results', {}).setdefault(r, 0)
                self.audit['cancel_results'][r] += 1
                if r == 'discarded':
                    self.scheduled.discard(live[0])
        elif op == 'churn':
            i = ev['item']
            a = deepcopy(s.owner._case['items'][i].get('analysis'))
            if a and a.get('status') == 'computed':
                a['version'] = a.get('version', 1) + 1          # equal fact, new version label
                s.owner.apply(item_updates={i: {'analysis': a}})
                self.audit['churn_writes'] += 1
        elif op == 'late_confirm':
            # a callback that refers to the FIRST publication of the target (possibly expired since)
            t = ev['target']
            hist = getattr(self, 'handle_history', {}).get(t)
            if hist:
                if self.bound_confirm:
                    r = s.confirm(t, hist[0])
                else:
                    r = s.confirm(t)
                stale = hist[0] != self.pub_handle.get(t)
                self.audit.setdefault('late_callbacks', []).append(dict(target=t, result=r, refers_to_expired=stale))
        elif op == 'confirm':
            t = ev['target']
            if self.bound_confirm:
                r = s.confirm(t, self.pub_handle.get(t)) if hasattr(s, 'confirm') else None
            else:
                r = s.confirm(t)
            self.audit['confirm_results'][str(t)] = r
        # a churn/rebind may expire publications: re-open intents whose publication vanished
        cur = s.published
        for k in list(self.first_pub):
            if k not in cur:
                self.first_pub.pop(k)
                self.intent[k] = self.now
                self.audit['reopened'] = self.audit.get('reopened', 0) + 1

    def drive(self):
        # serve every open intent, not only the most recent target (re-opened intents need service)
        open_targets = [k for k in self.intent if k not in self.first_pub]
        keep = self.active
        for k in open_targets:
            self.active = k
            super().drive()
        self.active = keep

    def _result(self):
        s = self.session
        lat = {k: self.first_pub[k] - self.intent[k] for k in self.first_pub if k in self.intent}
        cur = s.published
        wrong_now = sum(1 for k, u in cur.items() if u != self.truth[k])
        res = dict(policy=self.policy, published_now=len(cur), intents=len(self.intent), wrong=self.wrong,
                   wrong_current=wrong_now, total_latency_u=sum(lat.values()),
                   unserved=sorted(set(self.intent) - set(self.first_pub)),
                   physical_admissions=s.metrics['physical_admissions'], physical_finishes=s.metrics['physical_finishes'],
                   discarded=s.metrics['discarded_completions'], value_cache_hits=s.metrics['value_cache_hits'],
                   publication_read_checks=s.metrics['publication_read_checks'],
                   reservation_refusals=s.metrics['reservation_refusals'],
                   occupied_end=s.occupied, raw_end=s.raw_size, peak_occupied=s.metrics['peak_occupied'],
                   capacity=s.capacity, raw_capacity=s.raw_capacity, confirmed_subset=set(s.confirmed) <= set(cur),
                   end_u=self.now, **self.audit, **self.c)
        res['confirm_results'] = dict(self.audit['confirm_results'])
        return res
