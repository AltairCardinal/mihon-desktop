"""N04: performance-counterexample reduction with reproducible slow cause.

Route A: delta debugging over the event list keeping cost_ratio > threshold
         (deterministic work units, so reduction is noise-free).
Route B: structure-aware reduction: shrink n (drop suffix items) and collapse
         repeated identical events before ddmin.
Cross-process check: run the reduced trace in independent interpreters and
report deterministic work ratio + measured wall ratio for each.
"""
import copy
import json
import subprocess
import sys
import time
from pathlib import Path

import paths  # noqa: F401
import wpC_structures as S
from wpC_select import work_units


def replay(cls, case, events, **kw):
    m = cls(case, **kw)
    t0 = time.perf_counter_ns()
    for ev in events:
        if ev[0] == 'item':
            m.set_item(ev[1], copy.deepcopy(ev[2]))
        elif ev[0] == 'edge':
            m.set_edge(ev[1], copy.deepcopy(ev[2]))
        else:
            m.unit(ev[1])
    return work_units(m.work), time.perf_counter_ns() - t0


def ratio(slow, fast, case, events, kws=({}, {})):
    a = replay(slow, case, events, **kws[0])[0]
    b = replay(fast, case, events, **kws[1])[0]
    return (a + 1) / (b + 1)


def ddmin(events, pred):
    cur = list(events)
    chunk = max(1, len(cur) // 2)
    tests = 0
    while chunk >= 1:
        i, changed = 0, False
        while i < len(cur):
            trial = cur[:i] + cur[i + chunk:]
            tests += 1
            if trial and pred(trial):
                cur, changed = trial, True
            else:
                i += chunk
        if not changed:
            chunk //= 2
    return cur, tests


def structural_shrink(case, events, pred_case):
    """Route B: drop trailing items while the predicate holds, then dedupe."""
    c = copy.deepcopy(case)
    while len(c['items']) > 4:
        d = copy.deepcopy(c)
        d['items'].pop()
        n = len(d['items'])
        d['edges'] = [e for e in d['edges'] if e['second'] < n]
        ev = [e for e in events if (e[0] != 'query' or e[1] < n) and (e[0] != 'item' or e[1] < n)
              and (e[0] != 'edge' or e[1] < n - 1)]
        if ev and pred_case(d, ev):
            c, events = d, ev
        else:
            break
    dedup = []
    for e in events:
        if not dedup or json.dumps(e) != json.dumps(dedup[-1]):
            dedup.append(e)
    if pred_case(c, dedup):
        events = dedup
    return c, events


CHILD = r'''
import sys, json; sys.path.insert(0, %r); import paths
import wpC_reduce as R, wpC_structures as S
d = json.loads(open(%r).read())
ev = [tuple(e) for e in d['events']]
a = R.replay(getattr(S, d['slow']), d['case'], ev, **d['kw'][0]); b = R.replay(getattr(S, d['fast']), d['case'], ev, **d['kw'][1])
print(json.dumps(dict(work_ratio=(a[0]+1)/(b[0]+1), wall_ratio=a[1]/max(1,b[1]))))
'''


def cross_process(case, events, slow, fast, kws, path, procs=3):
    Path(path).write_text(json.dumps(dict(case=case, events=events, slow=slow, fast=fast, kw=list(kws))))
    cand = str(Path(__file__).resolve().parent)
    out = []
    for _ in range(procs):
        r = subprocess.run([sys.executable, '-c', CHILD % (cand, str(path))], capture_output=True, text=True, timeout=120)
        out.append(json.loads(r.stdout))
    return out
