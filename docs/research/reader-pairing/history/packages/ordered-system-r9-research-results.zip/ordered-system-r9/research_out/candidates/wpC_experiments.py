"""WP-C experiments.  `python3 research_out/candidates/wpC_experiments.py <section>...`
Each section writes results/raw/wpC/<section>.json (deterministic seeds; work units are
deterministic, wall times are single-process local measurements and labelled trial)."""
import copy
import json
import random
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

import paths  # noqa: F401
from common import ref, random_case, roundtrip, unit_of, fact, SIDES, rank_value, base_case
import transducer as T
import incremental as I8
import theory_a as A8
import wpC_structures as S
import wpC_select as SEL
import wpC_output as OUT
import wpC_witness as WIT
import wpC_persist as PER
import wpC_reduce as RED

RAW = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpC'
RAW.mkdir(parents=True, exist_ok=True)


# ------------------------------------------------------------ traces
def chain_case(n):
    return A8.decreasing_chain(n)


def make_events(case, rng, n_updates, q_per_update, pattern, kind='local', hot=None):
    n = len(case['items'])
    ev = []
    t = n // 2
    d = 1
    for u in range(n_updates):
        if kind == 'flip':
            ev.append(('edge', 1, dict(status='computed', score=(0.25 if u % 2 == 0 else float(n - 1)), version=u + 2)))
        elif kind == 'chainlocal':
            a = rng.randrange(2, n - 1)
            ev.append(('edge', a, dict(status='computed', score=float(n - a) + rng.choice((0.0, 0.5)), version=u + 2)))
        elif kind == 'none':
            pass
        else:
            if rng.random() < 0.6:
                p = rng.randrange(n)
                st = 'WIDE' if rng.random() < 0.12 else 'NARROW'
                item = copy.deepcopy(case['items'][p])
                item['analysis'] = dict(status='computed', fact=fact(st, rng.choice(SIDES)), version=u + 2)
                item['header'] = fact(st)
                ev.append(('item', p, item))
            else:
                ev.append(('edge', rng.randrange(n - 1), dict(status='computed', score=rng.randrange(0, 1500) / 50,
                                                              version=u + 2)))
        k = int(q_per_update) + (1 if rng.random() < q_per_update - int(q_per_update) else 0)
        for _ in range(k):
            if pattern == 'hot':
                t = max(0, min(n - 1, (hot or n // 2) + rng.randrange(-8, 9)))
            elif pattern == 'jump':
                t = rng.randrange(n)
            elif pattern == 'roundtrip':
                if not 0 <= t + d < n:
                    d = -d
                t += d
            elif pattern == 'end':
                t = n - 1 - rng.randrange(4)
            ev.append(('query', t))
    return ev


class R8Tree(I8.TreePlan):
    def residency(self):
        return 2 * self.tree.size


class R8Resync(I8.ResyncPlan):
    def residency(self):
        return len(self.states)


def run(cls, case, events, kw=None, check=False, sample_res=True):
    kw = kw or {}
    t0 = time.perf_counter_ns()
    m = cls(case, **kw)
    build_ns = time.perf_counter_ns() - t0
    first_q = None
    peak = 0
    answers = []
    for ev in events:
        if ev[0] == 'item':
            m.set_item(ev[1], copy.deepcopy(ev[2]))
        elif ev[0] == 'edge':
            m.set_edge(ev[1], copy.deepcopy(ev[2]))
        else:
            before = SEL.work_units(m.work)
            answers.append(m.unit(ev[1]))
            if first_q is None:
                first_q = SEL.work_units(m.work) - before
        if sample_res and hasattr(m, 'residency'):
            peak = max(peak, m.residency())
    wall = time.perf_counter_ns() - t0
    w = dict(m.work)
    return dict(work=SEL.work_units(w), wall_ms=round(wall / 1e6, 2), build_ms=round(build_ns / 1e6, 2),
                first_query_work=first_q, peak_residency=peak, raw_work=w,
                answers_sha=__import__('hashlib').sha256(json.dumps(answers, sort_keys=True).encode()).hexdigest()[:16])


def save(name, obj):
    (RAW / f'{name}.json').write_text(json.dumps(obj, indent=1, default=str))
    print('wrote', name)


def table(rows, cands):
    for r in rows:
        print(r['scenario'], {c: (r[c]['work'], r[c]['wall_ms'], r[c]['peak_residency']) for c in cands if c in r})


# ------------------------------------------------------------ C01
def sec_C01():
    cands = dict(prefixscan=(S.PrefixScan, {}), lazytree=(S.LazyTree, {}), sparsecp=(S.SparseCheckpoints, {'K': 16}),
                 r8tree=(R8Tree, {}), r8resync=(R8Resync, {}), hybrid=(S.Hybrid, {}))
    rows = []
    for n in (256, 1024):
        rng = random.Random(n)
        case = roundtrip(random_case(rng, n, p_wide=0.12, domain='G0', settings_mix=False))
        for pattern, kind, nu, q in (('hot', 'local', 200, 1), ('jump', 'local', 200, 1), ('roundtrip', 'local', 200, 1),
                                     ('end', 'local', 200, 1), ('jump', 'local', 400, 0.0025)):
            ev = make_events(case, random.Random(n + 7), nu, q, pattern, kind)
            if q < 0.01:
                ev.append(('query', n - 1))
                scen = f'n{n}_W03_updates{nu}_then_far'
            else:
                scen = f'n{n}_{pattern}'
            row = dict(scenario=scen, events=len(ev))
            hashes = set()
            for name, (cls, kw) in cands.items():
                row[name] = run(cls, case, ev, kw)
                hashes.add(row[name]['answers_sha'])
            row['answers_agree'] = len(hashes) == 1
            rows.append(row)
    table(rows, cands)
    save('C01', rows)


# ------------------------------------------------------------ C02
def sec_C02():
    cands = dict(prefixscan=(S.PrefixScan, {}), lazytree=(S.LazyTree, {}), dirtylog64=(S.DirtyLogTree, {'cap': 64}),
                 dirtylog8=(S.DirtyLogTree, {'cap': 8}), r8tree=(R8Tree, {}))
    rows = []
    n = 2048
    case = roundtrip(random_case(random.Random(5), n, p_wide=0.12, domain='G0', settings_mix=False))
    for q in (1.0, 0.1, 0.02, 0.005):
        ev = make_events(case, random.Random(11), 400, q, 'jump')
        row = dict(scenario=f'n{n}_q{q}', queries=sum(1 for e in ev if e[0] == 'query'))
        hs = set()
        for name, (cls, kw) in cands.items():
            row[name] = run(cls, case, ev, kw)
            hs.add(row[name]['answers_sha'])
        row['answers_agree'] = len(hs) == 1
        rows.append(row)
    table(rows, cands)
    save('C02', rows)


# ------------------------------------------------------------ C03 / P01 / X06
def phase_events(n, rng, phases, q=1.0):
    case = chain_case(n)
    ev = []
    for kind, length in phases:
        ev += make_events(case, rng, length, q, 'jump', kind)
    return case, ev


def sec_C03():
    cands = dict(r8resync=(R8Resync, {}), lazytree=(S.LazyTree, {}), r8tree=(R8Tree, {}),
                 hybrid=(S.Hybrid, {'cap': 32, 'quiet_to_demote': 8}), skirental=(SEL.SkiRental, {'alpha': 1.0}))
    rows = []
    for n in (256, 1024):
        for label, phases in (('local', [('chainlocal', 300)]), ('flip', [('flip', 300)]),
                              ('flip_then_local', [('flip', 100), ('chainlocal', 200)]),
                              ('alternating', [('flip', 30), ('chainlocal', 60)] * 4)):
            case, ev = phase_events(n, random.Random(n), phases)
            row = dict(scenario=f'n{n}_{label}')
            hs = set()
            for name, (cls, kw) in cands.items():
                row[name] = run(cls, case, ev, kw)
                hs.add(row[name]['answers_sha'])
            row['answers_agree'] = len(hs) == 1
            rows.append(row)
    table(rows, cands)
    save('C03', rows)


def per_event_costs(cls, case, events, kw=None):
    m = cls(case, **(kw or {}))
    costs = []
    for ev in events:
        b = SEL.work_units(m.work)
        if ev[0] == 'item':
            m.set_item(ev[1], copy.deepcopy(ev[2]))
        elif ev[0] == 'edge':
            m.set_edge(ev[1], copy.deepcopy(ev[2]))
        else:
            m.unit(ev[1])
        costs.append(SEL.work_units(m.work) - b)
    return costs


def chasing_adversary(n, rounds=6, sel_cls=S.Hybrid, kw=None):
    """Adaptive: flip until the selector promotes, then local edits until it demotes."""
    kw = kw or {}
    case = chain_case(n)
    m = sel_cls(case, **kw)
    rng = random.Random(1)
    ev = []
    for r in range(rounds):
        k = 0
        while m.tree is None and k < 4 * n:
            e = ('edge', 1, dict(status='computed', score=(0.25 if (len(ev) // 2) % 2 == 0 else float(n - 1)), version=len(ev) + 2))
            m.set_edge(e[1], copy.deepcopy(e[2])); ev.append(e); ev.append(('query', n - 1)); m.unit(n - 1); k += 1
        k = 0
        while m.tree is not None and k < 4 * n:
            a = rng.randrange(2, n - 1)
            e = ('edge', a, dict(status='computed', score=float(n - a), version=len(ev) + 2))
            m.set_edge(e[1], copy.deepcopy(e[2])); ev.append(e); ev.append(('query', rng.randrange(n))); m.unit(ev[-1][1]); k += 1
    return case, ev


def sec_P01():
    rows = []
    for n in (256, 512):
        scen = []
        for label, phases in (('alternating_long', [('flip', 60), ('chainlocal', 120)] * 3),
                              ('alternating_short', [('flip', 8), ('chainlocal', 8)] * 20),
                              ('local_only', [('chainlocal', 300)]), ('flip_only', [('flip', 300)])):
            case, ev = phase_events(n, random.Random(n + 3), phases)
            scen.append((label, case, ev))
        for nm, (cls, kw) in (('hybrid_D2', (S.Hybrid, {'cap': 32, 'quiet_to_demote': 2})),
                              ('skirental', (SEL.SkiRental, {'alpha': 1.0}))):
            case, ev = chasing_adversary(n, 5, cls, kw)
            scen.append((f'chasing_vs_{nm}', case, ev))
        for label, case, ev in scen:
            cR = per_event_costs(SEL.FixedResync, case, ev)
            cT = per_event_costs(S.LazyTree, case, ev)
            opt = SEL.offline_opt(cR, cT, S_RT=5 * n, S_TR=n)
            row = dict(scenario=f'n{n}_{label}', events=len(ev), OPT=opt, fixed_resync=sum(cR), fixed_tree=sum(cT))
            for name, (cls, kw) in dict(hybrid_D8=(S.Hybrid, {'cap': 32, 'quiet_to_demote': 8}),
                                        hybrid_D2=(S.Hybrid, {'cap': 32, 'quiet_to_demote': 2}),
                                        skirental=(SEL.SkiRental, {'alpha': 1.0}),
                                        skirental_a05=(SEL.SkiRental, {'alpha': 0.5})).items():
                r = run(cls, case, ev, kw, sample_res=False)
                row[name] = dict(work=r['work'], ratio_to_OPT=round(r['work'] / max(1, opt), 3),
                                 promotions=r['raw_work'].get('promotions', 0), demotions=r['raw_work'].get('demotions', 0),
                                 wall_ms=r['wall_ms'])
            rows.append(row)
            print(row['scenario'], 'OPT', opt, {k: (v['ratio_to_OPT'], v['promotions']) for k, v in row.items() if isinstance(v, dict)})
    save('P01', rows)


def sec_P04():
    """Tune Hybrid (cap, D) on training generator; evaluate on held-out lengths/mixes."""
    grid = [(c, d) for c in (8, 32, 128) for d in (2, 8, 32)]
    def gen(n, mix, seed):
        rng = random.Random(seed)
        if mix == 'A':
            phases = [('flip', rng.randrange(10, 40)), ('chainlocal', rng.randrange(20, 80))] * 3
        else:
            phases = [('chainlocal', rng.randrange(100, 200)), ('flip', rng.randrange(80, 150)), ('chainlocal', 50)]
        return phase_events(n, rng, phases)
    train = [gen(128, 'A', s) for s in range(3)]
    scores = {}
    for c, d in grid:
        scores[(c, d)] = sum(run(S.Hybrid, case, ev, {'cap': c, 'quiet_to_demote': d}, sample_res=False)['work'] for case, ev in train)
    best = min(scores, key=scores.get)
    rows = []
    for n, mix in ((128, 'A'), (512, 'A'), (512, 'B'), (1024, 'B')):
        for s in (10, 11):
            case, ev = gen(n, mix, s)
            cR = per_event_costs(SEL.FixedResync, case, ev); cT = per_event_costs(S.LazyTree, case, ev)
            opt = SEL.offline_opt(cR, cT, 5 * n, n)
            tuned = run(S.Hybrid, case, ev, {'cap': best[0], 'quiet_to_demote': best[1]}, sample_res=False)['work']
            sr = run(SEL.SkiRental, case, ev, {'alpha': 1.0}, sample_res=False)['work']
            rows.append(dict(n=n, mix=mix, seed=s, OPT=opt, tuned_hybrid=tuned, skirental=sr,
                             tuned_ratio=round(tuned / opt, 3), skirental_ratio=round(sr / opt, 3),
                             fixed_resync_ratio=round(sum(cR) / opt, 3), fixed_tree_ratio=round(sum(cT) / opt, 3)))
            print(rows[-1])
    save('P04', dict(train_grid={f'{c},{d}': v for (c, d), v in scores.items()}, best=best, held_out=rows))


def sec_P05():
    """Detection delay / false promotions after phase changes."""
    rows = []
    n = 512
    for label, phases in (('noisy_local', [('chainlocal', 400)]), ('change_at_200', [('chainlocal', 200), ('flip', 200)])):
        case, ev = phase_events(n, random.Random(9), phases, q=0.5)
        for name, (cls, kw) in dict(hybrid_cap32_D8=(S.Hybrid, {'cap': 32, 'quiet_to_demote': 8}),
                                    hybrid_cap8_D2=(S.Hybrid, {'cap': 8, 'quiet_to_demote': 2}),
                                    skirental=(SEL.SkiRental, {'alpha': 1.0})).items():
            m = cls(case, **kw)
            upd = 0
            first_promo = None
            for e in ev:
                if e[0] == 'query':
                    m.unit(e[1]); continue
                (m.set_item if e[0] == 'item' else m.set_edge)(e[1], copy.deepcopy(e[2]))
                upd += 1
                if first_promo is None and m.work.get('promotions', 0) > 0:
                    first_promo = upd
            rows.append(dict(scenario=label, selector=name, first_promotion_at_update=first_promo,
                             promotions=m.work.get('promotions', 0), demotions=m.work.get('demotions', 0),
                             probes=m.work.get('tree_probes', 0), work=SEL.work_units(m.work)))
            print(rows[-1])
    save('P05', rows)


def sec_P06():
    rows = []
    n = 256
    case, ev = phase_events(n, random.Random(4), [('flip', 60), ('chainlocal', 120)] * 2)
    want = [None]
    refm = S.PrefixScan(case)
    good = []
    for e in ev:
        if e[0] == 'query':
            good.append(refm.unit(e[1]))
        else:
            (refm.set_item if e[0] == 'item' else refm.set_edge)(e[1], copy.deepcopy(e[2]))
    advices = dict(always_tree=lambda k: 'tree', always_resync=lambda k: 'resync',
                   alternate=lambda k: 'tree' if k % 2 else 'resync',
                   random=(lambda r: (lambda k: r.choice(('tree', 'resync'))))(random.Random(3)),
                   adversarial=lambda k: 'resync' if (k // 60) % 3 == 0 else 'tree')
    for name, adv in advices.items():
        for gap in (1, 16):
            m = SEL.Advised(case, adv, gap=gap)
            got = []
            for e in ev:
                if e[0] == 'query':
                    got.append(m.unit(e[1]))
                else:
                    (m.set_item if e[0] == 'item' else m.set_edge)(e[1], copy.deepcopy(e[2]))
            rows.append(dict(advice=name, gap=gap, exact=got == good, work=SEL.work_units(m.work),
                             promotions=m.work.get('promotions', 0)))
            print(rows[-1])
    save('P06', rows)


# ------------------------------------------------------------ C04
def sec_C04():
    rows = []
    for n in (256, 1024):
        rng = random.Random(n)
        case = roundtrip(random_case(rng, n, p_wide=0.12, domain='G0', settings_mix=False))
        ops = []
        for k in range(40):
            p = rng.randrange(1, n - 1)
            if k % 2 == 0:
                st = 'NARROW'
                ops.append(('ins', p, dict(id=f'x{k}', header=fact(st), analysis=dict(status='computed', fact=fact(st, 'A'), version=1)),
                            dict(status='computed', score=3.0, version=1), dict(status='computed', score=4.0, version=1)))
            else:
                ops.append(('del', p, dict(status='computed', score=2.0, version=1)))
        t0 = time.perf_counter_ns()
        rope = S.RopePlan(case, B=32)
        for op in ops:
            if op[0] == 'ins':
                rope.insert(op[1], copy.deepcopy(op[2]), op[3], op[4])
            else:
                rope.delete(op[1], op[2])
            rope.unit(rng.randrange(len(rope.case['items'])))
        rope_ms = (time.perf_counter_ns() - t0) / 1e6
        # baseline: full rebuild of a lazy tree / eager tree after every order change
        t0 = time.perf_counter_ns()
        cur = copy.deepcopy(case)
        leaf_rebuild = 0
        rng2 = random.Random(n)
        for op in ops:
            cur = copy.deepcopy(rope_mirror(cur, op))
            tp = I8.TreePlan(cur)
            leaf_rebuild += tp.work.get('leaf_evals', 0)
            tp.unit(rng2.randrange(len(cur['items'])))
        rebuild_ms = (time.perf_counter_ns() - t0) / 1e6
        ok = rope.case['items'] == cur['items'] and all(rope.unit(t) == unit_of(ref.complete_plan(cur), t)
                                                         for t in range(0, len(cur['items']), 7))
        rows.append(dict(n=n, ops=len(ops), rope_ms=round(rope_ms, 1), rope_leaf_evals=rope.work['leaf_evals'],
                         rope_parse_slots=rope.work['fact_parse_slots'], rebuild_ms=round(rebuild_ms, 1),
                         rebuild_leaf_evals=leaf_rebuild, exact=ok))
        print(rows[-1])
    # counterexample 1: position-indexed reuse after insertion
    case = chain_case(12)
    tp = I8.TreePlan(case)
    old_leaves = list(tp.tree.tree[tp.tree.size:tp.tree.size + 12])
    new = copy.deepcopy(case)
    new['items'].insert(3, dict(id='new', header=fact('NARROW'), analysis=dict(status='computed', fact=fact('NARROW'), version=1)))
    edges = []
    for e in case['edges']:
        if e['second'] <= 2:
            edges.append(dict(e))
        elif e['first'] >= 3:
            edges.append(dict(e, first=e['first'] + 1, second=e['second'] + 1))
    edges += [dict(first=2, second=3, status='computed', score=0.5, version=1), dict(first=3, second=4, status='computed', score=0.4, version=1)]
    new['edges'] = edges
    bad = I8.TreePlan(new)
    for i in range(12):                      # illegal: keep the ordinal-indexed leaf functions
        bad.tree.tree[bad.tree.size + i] = old_leaves[i]
    for v in range(bad.tree.size - 1, 0, -1):
        bad.tree.tree[v] = T.compose(bad.tree.tree[2 * v], bad.tree.tree[2 * v + 1])
    truth = ref.complete_plan(new)
    wrong = [t for t in range(13) if bad.unit(t) != unit_of(truth, t)]
    # counterexample 2: translated leaves are wrong when settings carry absolute ordinals
    c2 = base_case(10); c2['settings']['pinned_links'] = [4, 5]
    try:
        S.RopePlan(c2); pins_rejected = False
    except ValueError:
        pins_rejected = True
    c3 = copy.deepcopy(c2); c3['items'].insert(0, copy.deepcopy(c2['items'][0])); c3['items'][0]['id'] = 'front'
    c3['edges'] = [dict(e, first=e['first'] + 1, second=e['second'] + 1) for e in c2['edges']] + [dict(first=0, second=1, status='computed', score=None, version=1)]
    plan_unmapped = ref.complete_plan(c3)            # pins NOT remapped: different pairs move
    c3['settings']['pinned_links'] = [5, 6]
    plan_mapped = ref.complete_plan(c3)
    # counterexample 3: an owner/session certificate for the old order is stale after replace
    import coupling
    s = coupling.Session(case)
    v = s.certify(5, mode='L0')
    s.owner.replace(new)
    pub = s.publish(5, v['certificate'])
    save('C04', dict(rope_vs_rebuild=rows, illegal_ordinal_reuse_wrong_targets=wrong, pins_precondition_rejected=pins_rejected,
                     pins_unmapped_changes_plan=plan_unmapped != plan_mapped, old_certificate_after_reorder=pub))
    print('illegal reuse wrong targets', wrong, 'pins rejected', pins_rejected, 'old cert', pub)


def rope_mirror(cur, op):
    items = cur['items']
    old = {(e['first'], e['second']): e for e in cur['edges']}
    ne = []
    p = op[1]
    if op[0] == 'ins':
        for (a, b), e in old.items():
            if b <= p - 1:
                ne.append(dict(e))
            elif a >= p:
                ne.append(dict(e, first=a + 1, second=b + 1))
        if p > 0:
            ne.append(dict(op[3], first=p - 1, second=p))
        if p < len(items):
            ne.append(dict(op[4], first=p, second=p + 1))
        items.insert(p, copy.deepcopy(op[2]))
    else:
        for (a, b), e in old.items():
            if b <= p - 1:
                ne.append(dict(e))
            elif a >= p + 1:
                ne.append(dict(e, first=a - 1, second=b - 1))
        if 0 < p < len(items) - 1:
            ne.append(dict(op[2], first=p - 1, second=p))
        del items[p]
    cur['edges'] = ne
    return cur


# ------------------------------------------------------------ C05
def sec_C05():
    rows = []
    n = 1024
    case = roundtrip(random_case(random.Random(2), n, p_wide=0.12, domain='G0', settings_mix=False))
    for k in (1, 4, 16, 64):
        rng = random.Random(k)
        bursts = []
        for b in range(30):
            ups = make_events(case, rng, k, 0, 'jump')
            bursts.append((ups, rng.randrange(n)))
        res = {}
        for name in ('per_update', 'batched', 'replaylog'):
            t0 = time.perf_counter_ns()
            m = (S.LazyTree if name == 'per_update' else OUT.Batched if name == 'batched' else OUT.ReplayLog)(case)
            ans = []
            for ups, t in bursts:
                if name == 'batched':
                    m.apply_batch([(e[1], copy.deepcopy(e[2])) for e in ups if e[0] == 'item'],
                                  [(e[1], copy.deepcopy(e[2])) for e in ups if e[0] == 'edge'])
                else:
                    for e in ups:
                        (m.set_item if e[0] == 'item' else m.set_edge)(e[1], copy.deepcopy(e[2]))
                ans.append(m.unit(t))
            res[name] = dict(work=SEL.work_units(m.work), invalidations=m.work.get('invalidations', 0),
                             wall_ms=round((time.perf_counter_ns() - t0) / 1e6, 1),
                             sha=__import__('hashlib').sha256(json.dumps(ans, sort_keys=True).encode()).hexdigest()[:12])
        rows.append(dict(burst=k, **res, agree=len({v['sha'] for v in res.values()}) == 1))
        print(rows[-1])
    # observable-intermediate counterexample: v0 -> v1 -> v2 where v1's unit differs from both
    c = chain_case(8)
    v1 = copy.deepcopy(c); v1['edges'][2]['score'] = 0.1
    v2 = copy.deepcopy(v1); v2['edges'][2]['score'] = c['edges'][2]['score']
    u0, u1, u2 = (unit_of(ref.complete_plan(x), 4) for x in (c, v1, v2))
    save('C05', dict(bursts=rows, intermediate=dict(u0=u0, u1=u1, u2=u2, v1_unique=(u1 != u0 and u1 != u2),
                                                     note='a merged batch v0->v2 never exposes u1; legal only if the consumer declared intermediate versions mergeable')))


# ------------------------------------------------------------ C06 / X09 / O02
def mixed_consumer_events(case, rng, phases):
    n = len(case['items'])
    ev = []
    for kind, length in phases:
        for k in range(length):
            if rng.random() < 0.5:
                p = rng.randrange(n); st = 'WIDE' if rng.random() < 0.12 else 'NARROW'
                item = copy.deepcopy(case['items'][p])
                item['analysis'] = dict(status='computed', fact=fact(st, rng.choice(SIDES)), version=k + 2); item['header'] = fact(st)
                ev.append(('item', p, item))
            ev.append((kind, rng.randrange(n)))
    return ev


class Dedicated:
    """Point queries from a LazyTree, full/prefix from a DiffPlan (both maintained)."""
    def __init__(self, case):
        self.t, self.d = S.LazyTree(case), OUT.DiffPlan(case)
        self.work = Counter()

    def set_item(self, p, it):
        self.t.set_item(p, copy.deepcopy(it)); self.d.set_item(p, it)

    def point(self, x): return self.t.unit(x)

    def full(self): return [u for i, u in enumerate(self.d.cover) if i == 0 or u is not self.d.cover[i - 1]]

    def prefix(self, x): return [u for u in self.full() if min(s['item'] for s in u['slots']) <= x]

    def wu(self): return SEL.work_units(self.t.work) + SEL.work_units(self.d.work)


class Shared:
    """One DiffPlan (dense states + cover) serves every consumer."""
    def __init__(self, case):
        self.d = OUT.DiffPlan(case)

    def set_item(self, p, it): self.d.set_item(p, it)

    def point(self, x): return self.d.unit(x)

    def full(self): return [u for i, u in enumerate(self.d.cover) if i == 0 or u is not self.d.cover[i - 1]]

    def prefix(self, x): return [u for u in self.full() if min(s['item'] for s in u['slots']) <= x]

    def wu(self): return SEL.work_units(self.d.work)


class ScanOnly:
    def __init__(self, case):
        self.p = S.PrefixScan(case)

    def set_item(self, pos, it): self.p.set_item(pos, it)

    def point(self, x): return self.p.unit(x)

    def full(self): return self.p.plan()

    def prefix(self, x): return self.p.prefix(x)

    def wu(self): return SEL.work_units(self.p.work)


def sec_C06():
    rows = []
    n = 512
    case = roundtrip(random_case(random.Random(8), n, p_wide=0.12, domain='G0', settings_mix=False))
    for label, phases in (('point_heavy', [('point', 300)]), ('full_heavy', [('full', 60)]),
                          ('switching', [('point', 100), ('full', 20), ('prefix', 60), ('point', 100)])):
        ev = mixed_consumer_events(case, random.Random(1), phases)
        out_units = 0
        row = dict(scenario=label)
        shas = set()
        for name, cls in (('scan_only', ScanOnly), ('dedicated', Dedicated), ('shared', Shared)):
            m = cls(case)
            t0 = time.perf_counter_ns()
            outs = []
            out_units = 0
            for e in ev:
                if e[0] == 'item':
                    m.set_item(e[1], copy.deepcopy(e[2]))
                elif e[0] == 'point':
                    outs.append(m.point(e[1])); out_units += 1
                elif e[0] == 'full':
                    o = m.full(); outs.append(len(o)); out_units += len(o)
                else:
                    o = m.prefix(e[1]); outs.append(len(o)); out_units += len(o)
            row[name] = dict(work=m.wu(), wall_ms=round((time.perf_counter_ns() - t0) / 1e6, 1))
            shas.add(json.dumps(outs, sort_keys=True))
        row['output_units_lower_bound'] = out_units
        row['agree'] = len(shas) == 1
        rows.append(row)
        print(row)
    save('C06', rows)


def sec_O02():
    rows = []
    for n in (256, 1024):
        for label, case, kind in (('random_local', roundtrip(random_case(random.Random(n), n, p_wide=0.12, domain='G0', settings_mix=False)), 'local'),
                                  ('phase_flip', chain_case(n), 'flip')):
            ev = [e for e in make_events(case, random.Random(3), 100, 0, 'jump', kind)]
            d = OUT.DiffPlan(case)
            full = S.PrefixScan(case)
            diff_entries, full_units, mism = 0, 0, 0
            cur = copy.deepcopy(case)
            t0 = time.perf_counter_ns()
            for e in ev:
                (d.set_item if e[0] == 'item' else d.set_edge)(e[1], copy.deepcopy(e[2]))
                diff_entries += len(d.last_diff)
            tdiff = time.perf_counter_ns() - t0
            for e in ev:
                if e[0] == 'item':
                    cur['items'][e[1]] = copy.deepcopy(e[2])
                else:
                    cur['edges'] = [x for x in cur['edges'] if x['first'] != e[1]] + [dict(e[2], first=e[1], second=e[1] + 1)]
            t0 = time.perf_counter_ns()
            for e in ev:
                (full.set_item if e[0] == 'item' else full.set_edge)(e[1], copy.deepcopy(e[2]))
                full_units += len(full.plan())
            tfull = time.perf_counter_ns() - t0
            truth = ref.complete_plan(cur)
            cov = {}
            for u in truth:
                for s in u['slots']:
                    cov[s['item']] = u
            mism = sum(d.cover[i] != cov[i] for i in range(n))
            rows.append(dict(n=n, scenario=label, updates=len(ev), diff_entries=diff_entries, full_output_units=full_units,
                             diff_work=SEL.work_units(d.work), full_work=SEL.work_units(full.work),
                             diff_ms=round(tdiff / 1e6, 1), full_ms=round(tfull / 1e6, 1), final_cover_mismatch=mism))
            print(rows[-1])
    save('O02', rows)


# ------------------------------------------------------------ O03 / O04
def sec_O03():
    rows = []
    n = 512
    case = roundtrip(random_case(random.Random(6), n, p_wide=0.12, domain='G0', settings_mix=False))
    for pattern in ('roundtrip', 'hot', 'jump'):
        for w in (0, 2, 8):
            ev = make_events(case, random.Random(4), 150, 4, pattern)
            m = S.Hybrid(case)
            cache = {}
            hits = waste = pre = 0
            for e in ev:
                if e[0] != 'query':
                    (m.set_item if e[0] == 'item' else m.set_edge)(e[1], copy.deepcopy(e[2]))
                    lo = e[1] - 3
                    cache = {k: v for k, v in cache.items() if k < lo}   # drop entries a change may affect
                    continue
                t = e[1]
                if t in cache:
                    hits += 1; cache.pop(t)
                else:
                    m.unit(t)
                for x in range(t - w, t + w + 1):
                    if 0 <= x < n and x != t and x not in cache:
                        cache[x] = m.unit(x); pre += 1
                while len(cache) > 2 * w:
                    cache.pop(next(iter(cache))); waste += 1
            rows.append(dict(pattern=pattern, w=w, hits=hits, precomputed=pre, evicted_unused=waste,
                             queries=sum(1 for e in ev if e[0] == 'query'), work=SEL.work_units(m.work), residency_bound=2 * w))
            print(rows[-1])
    save('O03', rows)


def sec_O04():
    """Background tree construction with a per-idle-tick leaf budget; foreground queries."""
    rows = []
    n = 1024
    case = chain_case(n)
    for upd_every in (2, 10, 1000):
        for budget in (0, 16, 64, 10 ** 6):
            rng = random.Random(5)
            m = S.LazyTree(case)
            fg = bg = 0
            nxt = 0
            for k in range(400):
                if k % upd_every == 0:
                    a = rng.randrange(2, n - 1)
                    m.set_edge(a, dict(status='computed', score=float(n - a) + 0.5 * (k % 2), version=k + 2))
                    nxt = min(nxt, max(0, a - 3))               # discard progress beyond the change (one version only)
                # idle tick: build up to `budget` leaves in prefix order (never a required slot)
                b0 = m.work['leaf_evals']
                while m.work['leaf_evals'] - b0 < budget and nxt < n:
                    m._leaf(nxt); nxt += 1
                bg += m.work['leaf_evals'] - b0
                b1 = m.work['leaf_evals']
                m.unit(rng.randrange(n))
                fg += m.work['leaf_evals'] - b1
            rows.append(dict(update_every=upd_every, idle_budget=budget, foreground_leaf_evals=fg, background_leaf_evals=bg,
                             residency=m.residency()))
            print(rows[-1])
    save('O04', rows)


# ------------------------------------------------------------ E04/E05/E06/X12/X13/X14
def sec_E():
    rng = random.Random(1)
    out = {}
    # E06 / X14: fused vs separate across fan-out and early-null mix
    rows = []
    for label, spread, fan in (('near_fan2', 8, 2), ('far_fan2', 160, 2), ('near_fan1', 8, 1), ('near_fan0', 8, 0),
                               ('mixed_fan2', None, 2)):
        res = {}
        for name in ('separate', 'fused_eager', 'fused_lazy', 'fused_prefix'):
            c = Counter()
            t0 = time.perf_counter_ns()
            vals = []
            r2 = random.Random(7)
            for trial in range(60):
                ws = [WIT.random_witness(r2, spread=spread if spread else r2.choice((8, 160))) for _ in range(6)]
                if fan == 2:
                    pairs = [(i, i + 1) for i in range(5)]
                elif fan == 1:
                    pairs = [(i, i + 1) for i in range(0, 5, 2)]
                else:
                    pairs = []
                if name == 'separate':
                    vals.append(WIT.separate_ranks(ws, pairs, c))
                elif name == 'fused_prefix':
                    vals.append(WIT.prefix_ranks(ws, pairs, c))
                else:
                    vals.append(WIT.fused_ranks(ws, pairs, c, eager=(name == 'fused_eager')))
            res[name] = dict(normalize_calls=c['normalize_calls'], pair_elements=c['pair_elements'],
                             wall_ms=round((time.perf_counter_ns() - t0) / 1e6, 1), sha=hash(json.dumps([sorted((str(k), v) for k, v in d.items()) for d in vals])))
        rows.append(dict(scenario=label, **res, agree=len({v['sha'] for v in res.values()}) == 1))
        print(rows[-1])
    out['E06_X14_fused'] = rows
    # E04: progressive segmented service
    rows = []
    for spread in (8, 40, 120, 200):
        for seg in (5, 10, 25, 50):
            c = Counter(); reads = []
            r2 = random.Random(spread)
            for trial in range(200):
                wa = WIT.random_witness(r2, spread=spread); wb = WIT.random_witness(r2, spread=spread)
                s, rd = WIT.progressive_pair(wa, wb, seg, c)
                assert s == WIT.OP.score(wa, wb)
                reads.append(rd)
            rows.append(dict(spread=spread, segment=seg, mean_elements_read=round(statistics.mean(reads), 2),
                             full=50, segment_opens=c['segment_opens'], null_fraction=round(sum(1 for r in reads if r < 50) / 200, 3)))
    out['E04_progressive'] = rows
    print(rows[:4])
    # X12: in-stream progressive vs second service stage (synthetic u: setup s, element e)
    rows = []
    for s_u in (1, 10, 50):
        for null_frac in (0.0, 0.3, 0.7):
            e_u = 1
            full = 2 * (s_u + 50 * e_u)
            prog_stream = 2 * (s_u + e_u * (null_frac * 20 + (1 - null_frac) * 50)) + 2 * 4      # 4 extra segment opens
            two_stage = 2 * (s_u + 0) + (1 - null_frac) * 2 * (s_u + 50 * e_u) + null_frac * 2 * (s_u + 20 * e_u)
            rows.append(dict(setup_u=s_u, null_fraction=null_frac, full_u=full, progressive_in_stream_u=prog_stream,
                             second_stage_u=two_stage))
    out['X12_model'] = dict(rows=rows, label='synthetic u (uncalibrated); elements to early null = 20 assumed from E04 medians')
    # E05: symmetry, reversal and direction reuse
    sym = rev = 0
    r2 = random.Random(3)
    for trial in range(2000):
        wa = WIT.random_witness(r2, spread=r2.choice((8, 40, 120)), cov_choices=(255, 200, 100))
        wb = WIT.random_witness(r2, spread=r2.choice((8, 40, 120)), cov_choices=(255, 200, 100))
        sym += WIT.OP.score(wa, wb) != WIT.OP.score(wb, wa)
        rev += WIT.OP.score(wa, wb) != WIT.OP.score(wa[::-1], wb[::-1])
    out['E05'] = dict(pairs=2000, symmetry_mismatch=sym, reversal_mismatch=rev,
                      structured_variance_search=WIT.find_variance_formula_disagreement(tries=50000),
                      note='AB uses (R_i,L_{i+1}), BA uses (L_i,R_{i+1}): ranks are NOT reusable across directions; '
                           'normalised vectors are (per-witness cache); symmetry makes the edge rank reusable under order reversal')
    # X13: transform label in the value-cache key.  An item witness is a pair (L, R) of
    # sampled vectors; direction AB scores (R_i, L_j), BA scores (L_i, R_j).
    vc_strict, vc_nolabel = PER.ValueCache('strict'), PER.ValueCache('strict')
    wrong_nolabel = differ = 0
    for trial in range(200):
        Li, Ri, Lj, Rj = (WIT.random_witness(r2, spread=4) for _ in range(4))
        content = [[Li, Ri], [Lj, Rj]]
        ab_fn = lambda c: WIT.OP.score(c[0][1], c[1][0])
        ba_fn = lambda c: WIT.OP.score(c[0][0], c[1][1])
        ab, ba = ab_fn(content), ba_fn(content)
        differ += ab != ba
        vc_strict.get_or_compute(content, 'AB', 'op-v1', ab_fn)
        got = vc_strict.get_or_compute(content, 'BA', 'op-v1', ba_fn)
        assert got == ba
        vc_nolabel.get_or_compute(content, '', 'op-v1', ab_fn)
        n2 = vc_nolabel.get_or_compute(content, '', 'op-v1', ba_fn)
        wrong_nolabel += (n2 != ba)
    out['X13'] = dict(trials=200, ab_ne_ba=differ, strict_with_label_hits=vc_strict.stats['hits'],
                      missing_label_wrong_values=wrong_nolabel,
                      note='same two item witnesses, different direction: without the transform label the cache returns the AB rank for a BA request')
    save('E', out)


# ------------------------------------------------------------ Q
def sec_Q():
    import coupling
    out = {}
    rng = random.Random(1)
    contents = [[rng.randrange(2 ** 32) for _ in range(6)] for _ in range(3000)]
    for mode, bits in (('strict', None), ('short', 8), ('short', 16)):
        vc = PER.ValueCache(mode, bits or 16)
        for c in contents:
            vc.get_or_compute(c, 'AB', 'v1', lambda x: sum(x) % 997)
        out[f'Q01_{mode}{bits or ""}'] = vc.stats
    # capability key with in-place replacement under the same capability (producer violated the contract)
    vc = PER.ValueCache('capability')
    cap = object()
    a = vc.get_or_compute([1, 2, 3], 'AB', 'v1', lambda x: sum(x), capability=cap)
    b = vc.get_or_compute([9, 9, 9], 'AB', 'v1', lambda x: sum(x), capability=cap)
    out['Q01_capability_inplace_replacement'] = dict(first=a, second_returned=b, true_second=27, stale=b != 27)
    # Q02 break-even (synthetic u)
    rows = []
    for acq in (10, 100, 1000):
        for verify in (1, 5):
            for visits in (1, 2, 10):
                store_scalar = visits * verify + acq        # first visit acquires, later ones verify
                no_store = visits * acq
                rows.append(dict(acquire_u=acq, verify_u=verify, visits=visits, persist_scalar_u=store_scalar,
                                 recompute_u=no_store, persist_wins=store_scalar < no_store))
    out['Q02_model'] = dict(rows=rows, label='synthetic u; ignores migration, invalidation and storage pressure (see text)')
    # Q03 cross-owner migration on real Sessions
    import workloads as WL
    tr = WL.w01_phase_chain(0)
    sA = coupling.Session(tr['initial'])
    hA, tA = None, None
    for t in range(len(tr['initial']['items'])):
        v = sA.certify(t, mode='L0')
        if v['status'] == 'certified':
            hA, tA = v['certificate'], t
            break
    sA.publish(tA, hA); sA.confirm(tA)
    sB = coupling.Session(copy.deepcopy(tr['initial']))
    direct = sB.publish(tA, hA)                                  # a handle from A means nothing in B
    hB = PER.migrate_certificate(sA, hA, sB)
    pub = sB.publish(tA, hB) if isinstance(hB, int) else hB
    changed = copy.deepcopy(tr['initial']); changed['items'][0]['content_version'] = 7
    sC = coupling.Session(changed)
    mig_changed = PER.migrate_certificate(sA, hA, sC)
    out['Q03'] = dict(old_handle_in_new_owner=direct, migrated=pub, confirmations_in_new_owner=len(sB.confirmed),
                      migrate_into_changed_content=mig_changed)
    out['Q04'] = PER.crash_matrix()
    out['Q04_invariants_all_ok'] = all(r['invariant_ok'] for r in out['Q04'])
    out['Q05'] = dict(same=PER.combine_certificate([(1, 'v1'), (2, 'v1')]), mixed=PER.combine_certificate([(1, 'v1'), (2, 'v2')]))
    out['Q06'] = [PER.leakage_experiment(shared=s) for s in (True, False)]
    save('Q', out)
    print({k: v for k, v in out.items() if k not in ('Q04', 'Q02_model')})


# ------------------------------------------------------------ N04
def sec_N04():
    n = 128
    case = chain_case(n)
    ev = make_events(case, random.Random(2), 60, 1, 'jump', 'flip')
    pred = lambda e: RED.ratio(S.Hybrid, S.LazyTree, case, e, ({'cap': 10 ** 9, 'quiet_to_demote': 10 ** 9}, {})) > 3.0
    start = RED.ratio(S.Hybrid, S.LazyTree, case, ev, ({'cap': 10 ** 9, 'quiet_to_demote': 10 ** 9}, {}))
    t0 = time.time()
    red_a, tests_a = RED.ddmin(ev, pred)
    ta = time.time() - t0
    pc = lambda c, e: RED.ratio(S.Hybrid, S.LazyTree, c, e, ({'cap': 10 ** 9, 'quiet_to_demote': 10 ** 9}, {})) > 3.0
    t0 = time.time()
    c_b, ev_b = RED.structural_shrink(case, ev, pc)
    red_b, tests_b = RED.ddmin(ev_b, lambda e: pc(c_b, e))
    tb = time.time() - t0
    cross = RED.cross_process(c_b, [list(x) for x in red_b], 'Hybrid', 'LazyTree',
                              ({'cap': 10 ** 9, 'quiet_to_demote': 10 ** 9}, {}), RAW / 'N04_reduced_trace.json')
    out = dict(start_events=len(ev), start_ratio=round(start, 2), routeA_events=len(red_a), routeA_tests=tests_a,
               routeA_seconds=round(ta, 1), routeA_ratio=round(RED.ratio(S.Hybrid, S.LazyTree, case, red_a, ({'cap': 10 ** 9, 'quiet_to_demote': 10 ** 9}, {})), 2),
               routeB_n=len(c_b['items']), routeB_events=len(red_b), routeB_tests=tests_b, routeB_seconds=round(tb, 1),
               reduced_events=red_b, cross_process=cross)
    save('N04', out)
    print({k: v for k, v in out.items() if k != 'reduced_events'})




def sec_X():
    out = {}
    rows = []
    for n in (256, 512):
        scen = []
        for label, phases in (('alternating_long', [('flip', 60), ('chainlocal', 120)] * 3),
                              ('alternating_short', [('flip', 8), ('chainlocal', 8)] * 20),
                              ('flip_then_local', [('flip', 100), ('chainlocal', 300)])):
            case, ev = phase_events(n, random.Random(n + 3), phases)
            scen.append((label, case, ev))
        case, ev = chasing_adversary(n, 5, S.Hybrid, {'cap': 32, 'quiet_to_demote': 8})
        scen.append(('chasing_vs_hybrid_D8', case, ev))
        for label, case, ev in scen:
            row = dict(scenario=f'n{n}_{label}')
            for name, (cls, kw) in dict(zero_resync=(SEL.FixedResync, {}), A_hybrid=(S.Hybrid, {'cap': 32, 'quiet_to_demote': 8}),
                                        B_skirental=(SEL.SkiRental, {'alpha': 1.0}), AB_skiquiet=(SEL.SkiQuiet, {'alpha': 1.0, 'D': 8}),
                                        AB_org2_skikeep=(SEL.SkiKeep, {'alpha': 1.0})).items():
                r = run(cls, case, ev, kw, sample_res=True)
                row[name] = dict(work=r['work'], peak_residency=r['peak_residency'], wall_ms=r['wall_ms'],
                                 promotions=r['raw_work'].get('promotions', 0), sha=r['answers_sha'])
            w = {k: v['work'] for k, v in row.items() if isinstance(v, dict)}
            row['interaction_work'] = w['AB_skiquiet'] - w['A_hybrid'] - w['B_skirental'] + w['zero_resync']
            row['agree'] = len({v['sha'] for v in row.values() if isinstance(v, dict)}) == 1
            rows.append(row)
            print(row['scenario'], w, row['agree'])
    out['X06'] = rows
    save('X06', out)



def sec_D4():
    """Held-out coupled workloads (seeds 100+, never used for any parameter choice)."""
    import workloads as W
    import wpC_coupled as WC
    rows = []
    fams = (('W01', dict(n=96)), ('W01', dict(n=48, holes=4)), ('RP', dict(n=64, pa=0.95, pe=0.95)),
            ('RP', dict(n=48, pa=0.6, pe=0.6)), ('W05', dict(n=64, holes=2)), ('W06', {}), ('W02', {}))
    for fam, kw in fams:
        for seed in (100, 101, 102):
            tr = W.FAMILIES[fam](seed, **kw)
            for pol in ('incumbent', 'indexed', 'selector', 'gated'):
                t0 = time.perf_counter_ns()
                r = WC.IndexedRunner(tr, policy=pol, service_u=3, q_u=0,
                                     strong=dict(kind='tree', domain='nonneg', gate='raw')).run()
                rows.append(dict(family=fam, kw=kw, seed=seed, policy=pol, wall_ms=round((time.perf_counter_ns() - t0) / 1e6, 2),
                                 published=r['published'], intents=r['intents'], wrong=r['wrong'],
                                 latency_u=r['total_latency_u'], admissions=r['physical_admissions'],
                                 certification_steps=r['certification_steps'], index_wins=r.get('index_wins', 0),
                                 strong_certificates=r['strong_certificates']))
    agg = {}
    for r in rows:
        k = (r['family'] + json.dumps(r['kw'], sort_keys=True), r['policy'])
        a = agg.setdefault(k, Counter())
        for f in ('wall_ms', 'published', 'intents', 'wrong', 'latency_u', 'admissions', 'certification_steps', 'index_wins', 'strong_certificates'):
            a[f] += r[f]
    summary = [dict(workload=k[0], policy=k[1], **{f: round(v, 1) if isinstance(v, float) else v for f, v in a.items()}) for k, a in agg.items()]
    for x in summary:
        print(x)
    save('D4_coupled', dict(rows=rows, summary=summary))

if __name__ == '__main__':
    for s in sys.argv[1:]:
        globals()['sec_' + s]()
