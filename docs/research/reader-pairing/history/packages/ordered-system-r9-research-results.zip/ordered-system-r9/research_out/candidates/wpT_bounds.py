"""T05 residual-gain bounds (evaluator-only; NOT candidates).

oracle_min policy: at each decision the evaluator (which knows the hidden
world) acquires the smallest set of items whose admitted evidence makes the
exact shared-assignment DP (sound gate, nonneg domain, beta) certify the
active target; proofs cost 0 virtual units.  It bounds what better
information choice + stronger proofs could save in physical admissions and
service waits on the same exogenous trace.  It reads World by design and is
excluded from every adoption table.
"""
import itertools
from copy import deepcopy

import paths  # noqa: F401
import omega as O
from coupled_runner import Runner, world_case


class OracleRunner(Runner):
    def __init__(self, trace, max_set=4, **kw):
        kw.setdefault('policy', 'strong_only')
        kw.setdefault('strong', dict(kind='exact', domain='nonneg', alpha=False, gate='sound'))
        super().__init__(trace, **kw)
        self.max_set = max_set
        self.full = world_case(trace['initial'], trace['world'])
        self.c['oracle_searches'] = 0

    def _knowledge_after(self, items):
        case = deepcopy(self.session.owner._case)
        n = len(case['items'])
        for i in items:
            case['items'][i]['analysis'] = deepcopy(self.full['items'][i]['analysis'])
        have = {(e['first'], e['second']) for e in case['edges']}
        known = {i for i in range(n) if case['items'][i]['analysis'].get('status') == 'computed'}
        # ranks become derivable when both endpoints were (re)acquired now
        for e in self.full['edges']:
            k = (e['first'], e['second'])
            if k not in have and e['first'] in items and e['second'] in items:
                case['edges'].append(deepcopy(e))
        return case

    def _min_set(self, t):
        n = len(self.session.owner._case['items'])
        pool = list(range(0, min(n, t + 4)))
        for k in range(1, self.max_set + 1):
            for S in itertools.combinations(pool, k):
                self.c['oracle_searches'] += 1
                st, _u = O.certify_exact(self._knowledge_after(set(S)), t, 'nonneg', False)
                if st == 'certified':
                    return S
        return None

    def drive(self):
        t = self.active
        if t is None or t in self.first_pub or self.session._tasks:
            return
        v = self.session.certify(t, mode='S')
        if v['status'] == 'certified':
            self._publish(t, v)
            return
        S = self._min_set(t)
        if S is None:                                   # fall back to the incumbent's needs
            self._acquire_needs(v)
            return
        for i in S:
            self.session.acquire(i)
        self._schedule_tasks()
