"""T04: minimal hand-off certificate checker (independent of the issuing route).

check(case, target, unit, domain, alpha) re-derives the certificate with the
exact shared-assignment DP from the true initial state (not the relation tree
that usually issues it) and, for n <= 7, by brute-force world enumeration.
check_support(...) perturbs every fact OUTSIDE the declared support range and
confirms the certificate is unchanged (support-sufficiency spot check, lemma S-1).
"""
import copy
import random

import paths  # noqa: F401
import omega as O
import transducer as T


def check(case, target, unit, domain='nonneg', alpha=False, brute_max_n=7):
    st, u = O.certify_exact(case, target, domain, alpha)
    if st != 'certified' or u != unit:
        return False, 'dp_disagrees'
    if len(case['items']) <= brute_max_n:
        try:
            U = O.oracle_units(case, target, domain, alpha, cap=50000)
        except OverflowError:
            return True, 'dp_only'
        if set(U) != {T._key(unit)}:
            return False, 'worlds_disagree'
        return True, 'dp+worlds'
    return True, 'dp_only'


def check_support(case, target, unit, domain='nonneg', alpha=False, trials=20, seed=0):
    rng = random.Random(seed)
    n = len(case['items'])
    hi = min(n - 1, target + 3)
    for _ in range(trials):
        c = copy.deepcopy(case)
        for p in range(hi + 1, n):
            if rng.random() < 0.5:
                c['items'][p]['analysis'] = {'status': 'unknown'}
        c['edges'] = [e for e in c['edges'] if e['first'] <= hi - 1 or rng.random() < 0.5]
        st, u = O.certify_exact(c, target, domain, alpha)
        if st != 'certified' or u != unit:
            return False
    return True
