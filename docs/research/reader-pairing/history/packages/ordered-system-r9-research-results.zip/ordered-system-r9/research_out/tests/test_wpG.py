"""WP-G tests: owner L0 variants (support compression, posrev, no-op), coupled raw order,
reissue / certificate GC, representations, measurement counterexamples."""
import copy
import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import reference as ref  # noqa: E402
import compact_core as core  # noqa: E402
from corrected_owner import Owner  # noqa: E402
from coupling import Session  # noqa: E402
from common import random_case, roundtrip  # noqa: E402
import workloads as W  # noqa: E402
import wpG_traces as TR  # noqa: E402
import wpG_owner as GO  # noqa: E402
import wpG_session as GS  # noqa: E402
import wpG_coupled as GC  # noqa: E402
import wpG_repr as RP  # noqa: E402
import wpG_retention as RT  # noqa: E402


def wanted(c, t):
    return {k: v for k, v in ref.certify_strategy(c, t)['selected'].items() if k != 'reads'}


def fresh_union(c, t):
    idx = core.Index(c, check_ids=False)
    b = core.certify(c, t, 2, index=idx)
    atts = [b] + ([core.certify(c, t, 3, index=idx)] if b['status'] == 'need_facts' else [])
    s = {}
    for a in atts:
        s.update(a['proof'][2])
    return s


class OwnerVariantsL0(unittest.TestCase):
    VARIANTS = ('fact_support', 'proj_support', 'posrev', 'posrev_fact', 'proj_posrev', 'noop_none', 'no_instrument')

    def test_differential_against_reference_on_all_mixes(self):
        for mix in ('refresh', 'dependent', 'unrelated', 'churn', 'quiet'):
            for seed in (1, 2):
                tr = TR.generate(seed, n=24, rounds=40, mix=mix, chain=(seed == 2))
                want = TR.truth(tr)
                for name in ('incumbent',) + self.VARIANTS:
                    self.assertEqual(TR.replay(tr, GO.make(name, tr['initial'])), want, (mix, seed, name))

    def test_proj_support_saves_engine_runs_on_version_refresh(self):
        tr = TR.generate(3, n=32, rounds=60, mix='refresh')
        inc, pj = GO.make('incumbent', tr['initial']), GO.make('proj_support', tr['initial'])
        self.assertEqual(TR.replay(tr, inc), TR.replay(tr, pj))
        self.assertLess(pj.metrics['engine_runs'], inc.metrics['engine_runs'])

    def test_fact_support_drops_only_derived_dimension_keys(self):
        rng = random.Random(5)
        for _ in range(40):
            c = roundtrip(random_case(rng, 10, p_unknown=0.3))
            t = rng.randrange(10)
            o = GO.make('fact_support', c); o.request(t)
            e = o._memo.get(t)
            if e is None:
                continue
            full = fresh_union(c, t)
            self.assertEqual(set(e['support']), {k for k in full if k[0] != 'dimension'})

    def test_projection_exact_refresh_equals_fresh_union_support(self):
        """L-G3: after a projection hit, entry['exact'] equals a fresh recomputation's support."""
        tr = TR.generate(4, n=24, rounds=60, mix='refresh')
        o = GO.make('proj_support', tr['initial'])
        c = copy.deepcopy(tr['initial'])
        checked = 0
        for op in tr['ops']:
            if op[0] == 'req':
                hits = o.metrics['memo_hits']
                o.request(op[1])
                if o.metrics['memo_hits'] > hits:
                    self.assertEqual(o._memo[op[1]]['exact'], fresh_union(o._case, op[1]))
                    checked += 1
            else:
                TR.replay(dict(ops=[op]), o)
        self.assertGreater(checked, 0)

    def test_int_float_and_version_changes_are_unobservable(self):
        c = roundtrip(random_case(random.Random(9), 8, p_unknown=0.0))
        for t in range(8):
            o = GO.make('proj_support', c); first = o.request(t)
            d = copy.deepcopy(c); upd = {}
            for i, it in enumerate(d['items']):
                a = dict(it['analysis']); a['version'] = 77; it['analysis'] = a; upd[i] = {'analysis': a}
            o.apply(item_updates=upd)
            eu = {}
            for e in d['edges']:
                if e.get('status') == 'computed' and isinstance(e.get('score'), (int, float)) and e['score'] is not None:
                    e['score'] = float(e['score']); eu[(e['first'], e['second'])] = dict(e)
            o.apply(edge_updates=eu)
            self.assertEqual(o.request(t), wanted(d, t))
            self.assertEqual(first, wanted(d, t))

    def test_posrev_skips_validation_on_unrelated_writes(self):
        tr = TR.generate(6, n=32, rounds=60, mix='unrelated')
        inc, pr = GO.make('incumbent', tr['initial']), GO.make('posrev', tr['initial'])
        self.assertEqual(TR.replay(tr, inc), TR.replay(tr, pr))
        self.assertLessEqual(pr.metrics['support_validations'], inc.metrics['support_validations'])
        self.assertGreater(pr.metrics['posrev_hits'], 0)

    def test_lying_noop_hint_returns_stale_verdict(self):
        """G04 hazard: a producer 'same' hint is a contract; a wrong hint yields a stale answer."""
        found = False
        rng = random.Random(11)
        for _ in range(80):
            c = roundtrip(random_case(rng, 8, p_unknown=0.3))
            t = rng.randrange(8)
            o = GO.make('noop_hint', c); o.request(t)
            d = copy.deepcopy(c)
            j = rng.randrange(8)
            d['items'][j]['analysis'] = {'status': 'failed', 'reason': 'READ'}
            o.apply(item_updates={j: {'analysis': d['items'][j]['analysis']}}, same={('item', j)})
            if o.request(t) != wanted(d, t):
                found = True
                break
        self.assertTrue(found)

    def test_negative_cache_keyed_by_target_is_wrong_incumbent_is_not(self):
        rng = random.Random(4)
        mutant_wrong = 0
        for _ in range(60):
            c = roundtrip(random_case(rng, 10, p_unknown=0.3, p_fail=0.2))
            t = rng.randrange(10)
            o = Owner(c); v = o.request(t)
            if v['status'] not in ('need_facts', 'blocked'):
                continue
            d = copy.deepcopy(c); upd = {}
            for i, it in enumerate(d['items']):
                if it['analysis'].get('status') != 'computed':
                    it['analysis'] = dict(status='computed', fact=dict(it['header']), version=5)
                    upd[i] = {'analysis': it['analysis']}
            o.apply(item_updates=upd)
            self.assertEqual(o.request(t), wanted(d, t))
            mutant_wrong += v != wanted(d, t)
        self.assertGreater(mutant_wrong, 0)

    def test_retention_policies_are_l0(self):
        rng = random.Random(0)
        c = TR._case(rng, 40, chain=True, p_unknown=0.0, p_edge_unknown=0.0)
        tr = dict(initial=c, ops=[['req', rng.randrange(40)] for _ in range(120)])
        want = TR.replay(tr, Owner(c))
        for kw in (dict(policy='lru'), dict(policy='bytes', byte_budget=60000),
                   dict(policy='gds', byte_budget=60000, estimator='steps'),
                   dict(policy='gds', byte_budget=60000, estimator='clock', sample=4)):
            self.assertEqual(TR.replay(tr, RT.ROwner(c, bytes_per_key=1186, **kw)), want, kw)


class CoupledRawOrder(unittest.TestCase):
    def test_gsession_default_equals_frozen_session(self):
        for seed in range(3):
            tr = W.random_partial(seed, n=16, pattern='roundtrip', count=16, pa=0.3, pe=0.2)
            import coupled_runner as CR
            base = CR.Runner(tr, capacity=3, raw_capacity=2).run(horizon=3000)
            g = GC.run(tr, {}, raw_capacity=2, horizon=3000)
            for k in ('published', 'latency_u', 'physical_admissions', 'wrong'):
                self.assertEqual(base[k], g[k], (seed, k))

    def test_evict_before_derive_livelock_and_derive_first_fix(self):
        """K01 counterexample: frozen order evicts the new witness's neighbour before deriving
        the rank; at raw capacity 1 adjacent ranks are never derived (horizon hit)."""
        tr = W.w06_complete_analysis_ambiguous(0, n=16, count=16)
        inc = GC.run(tr, {}, raw_capacity=1, horizon=3000)
        der = GC.run(tr, dict(order='derive_first'), raw_capacity=1, horizon=3000)
        self.assertEqual(inc['wrong'], 0); self.assertEqual(der['wrong'], 0)
        self.assertTrue(inc['horizon_hit'])
        self.assertFalse(der['horizon_hit'])
        self.assertGreater(der['published'], inc['published'])
        self.assertLess(der['physical_admissions'], inc['physical_admissions'])

    def test_dead_raw_definition(self):
        c = roundtrip(random_case(random.Random(2), 5, p_unknown=0.0))
        s = GS.GSession(c, raw_policy='useless_first')
        n = len(s.owner._case['items'])
        for i in range(n):
            nb = [(a, b) for a, b in ((i - 1, i), (i, i + 1)) if 0 <= a and b < n]
            want = all((s.owner._edges.get(k) or {}).get('status') == 'computed' for k in nb)
            self.assertEqual(s._dead(i), want)


class ReissueAndGC(unittest.TestCase):
    def test_reissue_keeps_publications_and_never_carries_confirmation(self):
        tr = W.random_partial(1, n=48, pattern='roundtrip', count=48, pa=0.5, pe=0.25)
        plain = GC.run(tr, {}, versioned=True, horizon=6000)
        re = GC.run(tr, dict(reissue=True), versioned=True, horizon=6000)
        self.assertEqual(plain['wrong'], 0); self.assertEqual(re['wrong'], 0)
        self.assertGreaterEqual(re['published_now'], plain['published_now'])

    def test_reissue_drops_confirmation_and_old_handle_unpublishable(self):
        tr = W.random_partial(1, n=48, pattern='roundtrip', count=48, pa=0.5, pe=0.25)
        r = GC.GRunner(tr, session_kw=dict(reissue=True, cert_gc=True), versioned=True)
        s = r.session
        orig = s._after_admission
        seen = dict(n=0)

        def spy():
            before = dict(s._published_handles)
            for t in before:
                s._confirmed[t] = True                     # pretend each publication was confirmed
            orig()
            for t, h in before.items():
                if t in s._published_handles and s._published_handles[t] != h:
                    seen['n'] += 1
                    self.assertNotIn(t, s._confirmed)
                    self.assertNotIn(h, s._certs)       # collected by GC; cannot publish again
        s._after_admission = spy
        r.run(horizon=6000)
        self.assertGreater(seen['n'], 0)
        self.assertEqual(len(s._certs), len(s._published_handles))

    def test_proj_reissue_uses_exact_support_not_projection(self):
        """X20 counterexample (fixed): recertifying through the base Session.certify stores the
        projection as publication support, so reissued certificates go stale immediately."""
        tr = W.random_partial(2, n=48, pattern='roundtrip', count=48, pa=0.5, pe=0.25)
        f = lambda c: GO.GOwner(c, support='proj')  # noqa: E731
        re = GC.run(tr, dict(reissue=True), versioned=True, horizon=6000)
        pr = GC.run(tr, dict(reissue=True, owner_factory=f), versioned=True, horizon=6000)
        self.assertEqual(pr['wrong'], 0)
        self.assertEqual(pr['published_now'], re['published_now'])
        s = GS.GSession(tr['initial'], owner_factory=f)
        for t in range(len(tr['initial']['items'])):
            v = s.certify(t)
            if v['status'] == 'certified':
                self.assertEqual(s._certs[v['certificate']]['support'], fresh_union(s.owner._case, t))
                self.assertTrue(s._certificate_current(s._certs[v['certificate']]))


class Representations(unittest.TestCase):
    def test_compose_equivalence(self):
        fs = RP.all_functions()
        for f in fs[::13]:
            for g in fs[::17]:
                want = RP.compose_tuple(f, g)
                self.assertEqual(RP.compose_straight(f, g), want)
                self.assertEqual(RP.unpack(RP.compose_packed(RP.pack(f), RP.pack(g))), want)
                self.assertEqual(tuple(RP.compose_bytes(RP.as_bytes(f), RP.as_bytes(g))[:5]), want)

    def test_x27_shared_translation_table_aliasing_is_safe_only_because_bytes_immutable(self):
        f = RP.as_bytes((1, 2, 3, 4, 0))
        g = RP.as_bytes((0, 0, 1, 1, 2))
        h = f.translate(g)
        self.assertIsNot(h, f)
        buf = bytearray(f)                       # mutable buffer: in-place reuse aliases the input
        alias = buf
        buf[:] = buf.translate(g)
        self.assertEqual(bytes(alias[:5]), bytes(h[:5]))
        self.assertNotEqual(bytes(alias[:5]), bytes(f[:5]))   # the 'input' f-view changed: aliasing hazard

    def test_lut_operator_equals_optimized(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location('opt', str(Path(paths.ROOT) / 'OPTIMIZED_OPERATOR.py'))
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        rng = random.Random(8)
        for k in range(300):
            a = [(rng.randrange(256) << 24) | rng.randrange(1 << 24) for _ in range(50)]
            b = list(a) if k % 2 else [(rng.randrange(256) << 24) | rng.randrange(1 << 24) for _ in range(50)]
            if k % 2:
                for j in rng.sample(range(50), 4):
                    b[j] = (b[j] & 0xff00ffff) | (rng.randrange(256) << 16)
            self.assertEqual(RP.score_lut(a, b), m.score(a, b))

    def test_flat_support_collision_is_confirmed_not_trusted(self):
        fs = RP.FlatSupport({('analysis', 0): ('unknown',), ('header', 0): None})
        self.assertTrue(fs.matches(fs.values))
        self.assertFalse(fs.matches((('unknown',), 1)))

    def test_owner_view_raises_when_stale(self):
        o = Owner(roundtrip(random_case(random.Random(3), 6)))
        v = RP.OwnerView(o)
        self.assertEqual(v.analysis(0), core.Index(o.snapshot(), check_ids=False).analysis(0))
        o.apply(item_updates={0: {'analysis': {'status': 'failed', 'reason': 'READ'}}})
        with self.assertRaises(RP.StaleView):
            v.analysis(0)


class CombinationCounterexamples(unittest.TestCase):
    def test_x11_closure_eviction_inside_evict_first_does_not_fix_livelock(self):
        tr = W.w06_complete_analysis_ambiguous(0, n=16, count=16)
        clo = GC.run(tr, dict(raw_policy='closure'), raw_capacity=1, horizon=3000)
        der = GC.run(tr, dict(order='derive_first'), raw_capacity=1, horizon=3000)
        self.assertTrue(clo['horizon_hit']); self.assertFalse(der['horizon_hit'])
        self.assertEqual(clo['wrong'], 0)

    def test_x20_lazy_reissue_matches_eager_publications(self):
        tr = W.random_partial(200, n=48, pattern='jump', count=40, pa=0.5, pe=0.25)
        out = {}
        for nm, kw in (('eager', dict(reissue=True)), ('lazy', dict(reissue='lazy'))):
            g = GC.GRunner(tr, session_kw=kw, versioned=True); r = g.run(horizon=6000)
            self.assertEqual(r['wrong'], 0)
            out[nm] = g.session.published
        self.assertEqual(out['eager'], out['lazy'])

    def test_x27_reused_buffer_overwrites_borrowed_certificate(self):
        from array import array
        buf = array('q', [0] * 5); certs = []
        for state in ((1, 2, 3, 4, 0), (0, 0, 0, 0, 0)):
            buf[:] = array('q', state); certs.append(buf)
        self.assertEqual(certs[0].tolist(), [0, 0, 0, 0, 0])
        fresh = [array('q', st) for st in ((1, 2, 3, 4, 0), (0, 0, 0, 0, 0))]
        self.assertEqual(fresh[0].tolist(), [1, 2, 3, 4, 0])



class DeriveFirstLifecycle(unittest.TestCase):
    def test_derive_first_rebind_cancel_and_publication(self):
        import coupled_runner as CR
        tr = W.w06_complete_analysis_ambiguous(1, n=16, count=16)
        world = CR.World([CR.Witness(**w) for w in tr['world']])
        s = GS.GSession(tr['initial'], raw_capacity=1, order='derive_first')
        t0, t1, t2 = s.acquire(0), s.acquire(1), s.acquire(2)
        self.assertEqual(s.finish(t0, world.complete(0)), 'completed')
        self.assertEqual(s.consume(t0), 'accepted')
        self.assertEqual(s.finish(t1, world.complete(1)), 'completed')
        self.assertEqual(s.consume(t1), 'accepted')
        self.assertEqual(s.raw_size, 1)                       # retained bound respected after the step
        self.assertEqual(s.metrics['peak_raw'], 2)            # transient r+1 inside the atomic step
        self.assertIn((0, 1), s.owner._edges)                 # rank derived before eviction
        self.assertEqual(s.cancel(t2), 'cancelling')
        self.assertEqual(s.finish(t2, world.complete(2)), 'discarded')
        handles = {}
        for t in range(16):
            v = s.certify(t)
            if v['status'] == 'certified' and s.publish(t, v['certificate']) == 'published':
                handles[t] = v['certificate']
        t3 = s.acquire(3)
        s.rebind(copy.deepcopy(tr['initial']))
        self.assertEqual(s.raw_size, 0)
        self.assertEqual(s.finish(t3, world.complete(3)), 'discarded')
        for t, h in handles.items():
            self.assertEqual(s.publish(t, h), 'unsigned')
        self.assertEqual(s.published, {})


if __name__ == '__main__':
    unittest.main()
