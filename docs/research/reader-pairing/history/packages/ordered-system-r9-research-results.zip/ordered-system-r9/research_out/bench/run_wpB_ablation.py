"""B01 necessity ablation: drop parts of the boundary interface kept by omega._prune."""
import sys,random,collections; import os; os.chdir(os.path.dirname(os.path.abspath(__file__))+'/..'); sys.path.insert(0,'candidates'); import paths
from common import *
import omega as O, transducer as T
orig=O._prune
def drop(asg,i,what):
    out=orig(asg,i)
    if what=='b-1': return {k:v for k,v in out.items() if not (k[0] in ('st','sd') and k[1]==i)}
    if what=='all_st': return {k:v for k,v in out.items() if k[0] not in ('st','sd')}
    if what=='edge': return {k:v for k,v in out.items() if k[0]!='rk'}
    if what=='lt': return {k:v for k,v in out.items() if k[0]!='lt'}
rng=random.Random(8); cases=[]
for k in range(int(sys.argv[1])):
    n=rng.randrange(3,9); c=roundtrip(random_case(rng,n,p_unknown=0.5,p_edge_unknown=0.5,p_wide=0.3)); t=rng.randrange(n)
    full=O.certify_exact(c,t,'ext',False)
    cases.append((c,t,full))
seen=collections.Counter()
for c,t,full in cases[:200]:
    calls=collections.Counter()
    def spy(a,i):
        for k in a: calls[k[0]]+=1
        return orig(a,i)
    O._prune=spy; O.certify_exact(c,t,'ext',False); seen.update(calls)
import json; OUT={'cases':len(cases),'key_tags_seen':dict(seen),'ablations':{}}
for what in ('b-1','all_st','edge','lt'):
    O._prune=lambda a,i,w=what: drop(a,i,w)
    diff=lost=0
    for c,t,full in cases:
        r=O.certify_exact(c,t,'ext',False)
        diff += (r[0]!=full[0]) or (r[0]=='certified' and r[1]!=full[1]) or (r[0]=='ambiguous' and len(r[1])!=len(full[1]))
        lost += full[0]=='certified' and r[0]!='certified'
    OUT['ablations'][what]=dict(verdict_or_unitcount_diffs=diff,lost_certificates=lost,certified_base=sum(f[0]=='certified' for _,_,f in cases))
O._prune=orig
OUT['command']='python3 research_out/bench/run_wpB_ablation.py 1500'
json.dump(OUT,open('results/raw/wpB/prune_ablation.json','w'),indent=1)
print(json.dumps(OUT))
