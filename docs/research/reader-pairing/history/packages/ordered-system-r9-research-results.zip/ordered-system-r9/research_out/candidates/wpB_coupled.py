"""D4 wiring (WP-B): exact block summaries as the strong L1 attempt inside the
coupled Session, maintained incrementally from the owner's actual deltas.

BlockSession(StrongSession): strong kind 'blocks'.  Every successful
owner.apply (consume of a witness, derived ranks, harness scalar updates)
records the changed item ordinals / edge firsts; identity, order or settings
changes (owner identity ticket) force a rebuild.  The certificate support is
the same conservative range as strong.py ([0, t+3]); publication/confirmation
use the unchanged Session guards, so stale certificates are rejected exactly
as for the tree candidate.
"""
import time
from copy import deepcopy

import paths  # noqa: F401
from strong import StrongSession, support_keys
import wpB_blocks as WB
import coupled_runner as CR


class BlockSession(StrongSession):
    def __init__(self, case, *, strong=None, block=8, **kw):
        super().__init__(case, strong=strong, **kw)
        self.block = block
        self._bs = None
        self._bs_ticket = None
        self._dirty_items, self._dirty_edges = set(), set()
        orig = self.owner.apply

        def tracked_apply(**kwargs):
            changed = orig(**kwargs)
            for i in (kwargs.get('item_updates') or {}):
                self._dirty_items.add(i)
            for (a, b) in (kwargs.get('edge_updates') or {}):
                if b == a + 1:
                    self._dirty_edges.add(a)
            return changed
        self.owner.apply = tracked_apply

    def _summary(self):
        ticket = self.owner._guard()
        if self._bs is None or self._bs_ticket != ticket:
            cfg = self.strong
            self._bs = WB.BlockSummary(deepcopy(self.owner._case), cfg['domain'], cfg['alpha'], block=self.block)
            self._bs_ticket = ticket
            self._dirty_items.clear(); self._dirty_edges.clear()
            self.metrics['block_rebuilds'] += 1
            return self._bs
        if self._dirty_items or self._dirty_edges:
            case = self.owner._case
            recs = {(e['first'], e['second']): e for e in case.get('edges', [])}
            items = {p: deepcopy(case['items'][p]) for p in self._dirty_items}
            edges = {a: deepcopy(recs.get((a, a + 1))) for a in self._dirty_edges}
            try:
                self._bs.update(items=items, edges=edges)
            except ValueError:                       # domain became illegal -> rebuild wider
                self._bs = None
                return self._summary()
            self.metrics['block_updates'] += 1
            self._dirty_items.clear(); self._dirty_edges.clear()
        return self._bs

    def certify(self, target, *, mode='L0', budget=None):
        if mode != 'S' or self.strong.get('kind') != 'blocks':
            return super().certify(target, mode=mode, budget=budget)
        base = StrongSession.certify(self, target, mode='L0', budget=budget)
        if base['status'] != 'need_facts':
            return base
        t0 = time.perf_counter_ns()
        bs = self._summary()
        ev0 = bs.c['evaluations']
        st, unit = bs.certify(target)
        ev = bs.c['evaluations'] - ev0
        ns = time.perf_counter_ns() - t0
        n = len(self.owner._case['items'])
        index = self.owner._index()
        keys = support_keys(n, target)
        support = {k: self.owner._read(index, k) for k in keys}
        gated = st == 'certified' and unit['certain']
        if gated and self.strong['gate'] == 'raw':
            gated = all(index.analysis(p)[0] == 'computed' for p in range(0, min(n - 1, target + 3) + 1))
        self.metrics['strong_attempts'] += 1
        self.metrics['strong_evaluations'] += ev
        self.metrics['strong_ns'] += ns
        self.strong_log.append(dict(target=target, status=st, gated=gated, evaluations=ev, ns=ns, route='blocks'))
        if st == 'contradiction':
            self.metrics['strong_contradictions'] += 1
        if not gated:
            return base
        self.metrics['strong_certificates'] += 1
        self._next_certificate += 1
        handle = self._next_certificate
        self._certs[handle] = dict(target=target, unit=deepcopy(unit), guard=self.owner._guard(), epoch=self.epoch,
                                  support=support)
        return dict(status='certified', unit=deepcopy(unit), needs=[], failures={}, first=0, steps=ev,
                    dependent_items=list(range(0, min(n - 1, target + 3) + 1)), certificate=handle,
                    route='strong-blocks')


class BlockRunner(CR.Runner):
    def __init__(self, trace, *, block=8, **kw):
        super().__init__(trace, **kw)
        strong = kw.get('strong')
        self.session = BlockSession(trace['initial'], capacity=kw.get('capacity', 3),
                                    raw_capacity=kw.get('raw_capacity', 3), strong=strong, block=block)
