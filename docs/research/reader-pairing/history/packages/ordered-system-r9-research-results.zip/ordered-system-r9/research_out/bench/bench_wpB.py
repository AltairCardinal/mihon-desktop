"""WP-B D3 registration (see CONVENTIONS.md / drive_formal.py).

Families (CANDIDATES[0] of each family = incumbent it must beat):
  inc     exact certification under a knowledge stream (reveal 1 fact, 3 queries per round):
          frontier (r8 FrontierCache, truncated at first changed boundary)  | blocks8 | blocks32 | exact0 | tree(r8 RelTree, approx)
  sig     corrected Owner vs SigOwner (decision-signature validation) on value-churn request traces (L0)
  feas    symbolic candidate-set feasibility (r8) vs bitset propagation on recorded constraint sets
  layer   single-query exact0 vs seeded_exact vs goal_pruned (negative control family)
  coupled coupled runner gated policy: incumbent L0 | gated tree | gated exact | gated blocks (local wall of a full run;
          virtual u metrics in `work`)
"""
import copy, hashlib, json, random, sys, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
import paths  # noqa
from common import ref, random_case, roundtrip, fact, SIDES
import transducer as T, omega as O
import wpB_blocks as WB, wpB_sigmemo as SG, wpB_domains as D, wpB_layered as L

FAM = {
    'inc': ['frontier', 'blocks8', 'blocks32', 'exact0', 'tree'],
    'sig': ['owner', 'sig'],
    'feas': ['symbolic', 'bitset'],
    'layer': ['exact0', 'seeded', 'goal'],
    'coupled': ['incumbent', 'gated_tree', 'gated_exact', 'gated_blocks'],
}
CANDIDATES = sorted({c for v in FAM.values() for c in v})
SCENARIOS = []
for n in (32, 128):
    for pu in (0.3, 0.6):
        SCENARIOS.append(dict(name=f'inc_n{n}_pu{pu}', family='inc', n=n, pu=pu, rounds=30, seed=n + int(pu * 10)))
for n in (16, 64):
    SCENARIOS.append(dict(name=f'sig_n{n}_order', family='sig', n=n, mode='order', seed=n))
    SCENARIOS.append(dict(name=f'sig_n{n}_shuffle', family='sig', n=n, mode='shuffle', seed=n + 1))
SCENARIOS.append(dict(name='feas_G0', family='feas', domain='G0', seed=5))
SCENARIOS.append(dict(name='feas_ext', family='feas', domain='ext', seed=6))
for n in (16, 64, 128):
    SCENARIOS.append(dict(name=f'layer_n{n}', family='layer', n=n, seed=n))
for fam in ('W01', 'W05', 'W06', 'RP', 'W02'):
    SCENARIOS.append(dict(name=f'coupled_{fam}', family='coupled', wfam=fam, seeds=list(range(200, 204))))


def FAMILY_CANDIDATES(sc):
    return FAM[sc['family']]


def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


def _stream(sc):
    rng = random.Random(sc['seed'])
    n = sc['n']
    world = roundtrip(random_case(rng, n, p_unknown=0.0, p_edge_unknown=0.0, settings_mix=False))
    case = copy.deepcopy(world)
    for it in case['items']:
        if rng.random() < sc['pu']:
            it['analysis'] = {'status': 'unknown'}
    case['edges'] = [e for e in case['edges'] if rng.random() >= sc['pu']]
    events = []
    unknown_items = [i for i, it in enumerate(case['items']) if it['analysis']['status'] == 'unknown']
    known_e = {e['first'] for e in case['edges']}
    unknown_edges = [a for a in range(n - 1) if a not in known_e]
    rng.shuffle(unknown_items); rng.shuffle(unknown_edges)
    wrec = {e['first']: e for e in world['edges']}
    for r in range(sc['rounds']):
        if (r % 2 == 0 and unknown_items) or not unknown_edges:
            if unknown_items:
                p = unknown_items.pop()
                events.append(('item', p, copy.deepcopy(world['items'][p])))
        else:
            a = unknown_edges.pop()
            events.append(('edge', a, copy.deepcopy(wrec.get(a))))
        for _ in range(3):
            events.append(('q', rng.randrange(n // 3, n)))
    return case, events


class _Frontier:
    """r8 FrontierCache with truncation at the first changed boundary (incumbent)."""
    def __init__(self, case):
        self.case = case
        self.F = T.Facts(case, 'omega', 'ext', False)
        self.fc = O.FrontierCache(case, 'ext', False)
        self.fc.F, self.fc.ctx = self.F, T.Ctx(self.F)

    def update(self, items=None, edges=None):
        lo = 10 ** 9
        for p, it in (items or {}).items():
            self.F.refresh_item(p, it); lo = min(lo, p - 1)
        for a, rec in (edges or {}).items():
            if rec is None: self.F.records.pop(a, None)
            else: self.F.records[a] = dict(rec, first=a, second=a + 1)
            lo = min(lo, a)
        self.F.ix._edges = None
        keep = max(1, lo - 2)
        del self.fc.frontiers[keep:]
        self.fc.ctx = T.Ctx(self.F)

    def certify(self, t):
        return self.fc.certify(t)

    def evaluations(self):
        return self.fc.evals


def run_inc(sc, cand):
    case, events = _stream(sc)
    out = []; work = {}
    t0 = time.perf_counter_ns()
    if cand == 'frontier':
        m = _Frontier(copy.deepcopy(case))
    elif cand.startswith('blocks'):
        m = WB.BlockSummary(copy.deepcopy(case), 'ext', False, block=int(cand[6:]), counters=work)
    elif cand == 'tree':
        F = T.Facts(copy.deepcopy(case), 'omega', 'ext', False); m = T.RelTree(F, work)
    else:
        m = copy.deepcopy(case)
    for ev in events:
        if ev[0] == 'item':
            if cand == 'exact0': m['items'][ev[1]] = ev[2]
            elif cand == 'tree': m.F.refresh_item(ev[1], ev[2]); m.update_leaves(T.affected_leaves(ev[1]))
            else: m.update(items={ev[1]: ev[2]})
        elif ev[0] == 'edge':
            if cand == 'exact0':
                m['edges'] = [e for e in m['edges'] if e['first'] != ev[1]] + ([ev[2]] if ev[2] else [])
            elif cand == 'tree':
                if ev[2]: m.F.records[ev[1]] = ev[2]
                m.update_leaves((ev[1] - 1, ev[1]))
            else: m.update(edges={ev[1]: ev[2]})
        else:
            t = ev[1]
            if cand == 'exact0':
                r = L.exact_from_zero(m, t, 'ext', False, counters=work)
                work['evaluations_total'] = work.get('evaluations_total', 0) + work['evaluations']
            elif cand == 'tree':
                us = m.units(t); r = ('certified', next(iter(us.values()))) if len(us) == 1 else ('ambiguous', None)
            else:
                r = m.certify(t)
            out.append((r[0] == 'certified', T._key(r[1]) if r[0] == 'certified' else None))
    wall = time.perf_counter_ns() - t0
    if cand == 'frontier': work['evaluations'] = m.evaluations()
    if cand == 'exact0': work['evaluations'] = work.pop('evaluations_total', 0)
    return dict(wall_ns=wall, verdict_sha256=_sha(out), certified=sum(1 for x in out if x[0]), work=work, ok=True)


def run_sig(sc, cand):
    from corrected_owner import Owner
    rng = random.Random(sc['seed'])
    n = sc['n']
    c = roundtrip(random_case(rng, n, p_unknown=0.15, p_edge_unknown=0.2, domain='G0', settings_mix=False))
    ow = (Owner if cand == 'owner' else SG.SigOwner)(c)
    out = []; cur = copy.deepcopy(c)
    hot = [rng.randrange(n) for _ in range(3)]
    t0 = time.perf_counter_ns()
    for step in range(60):
        for t in hot:
            out.append(ow.request(t))
        upd = {}
        for e in cur['edges']:
            if e.get('status') != 'computed' or e.get('score') is None: continue
            if sc['mode'] == 'order':
                e['score'] = e['score'] * 1.01 + 0.001; e['version'] = e.get('version', 1) + 1
            else:
                e['score'] = rng.randrange(0, 1500) / 50
            upd[(e['first'], e['second'])] = dict(e)
        ow.apply(edge_updates=upd)
    wall = time.perf_counter_ns() - t0
    return dict(wall_ns=wall, verdict_sha256=_sha(out), ok=True, work={k: ow.metrics[k] for k in
                ('engine_runs', 'memo_hits', 'support_validations', 'typed_reads_checked', 'signature_hits')})


_FEAS_CACHE = {}


def _constraint_sets(sc):
    key = sc['name']
    if key not in _FEAS_CACHE:
        rng = random.Random(sc['seed']); sets = []
        for _ in range(600):
            nv = rng.randrange(1, 4)
            ks = [rng.randrange(0, 1500) / 50 for _ in range(rng.randrange(0, 3))]
            terms = [('e', v) for v in range(nv)] + [('k', k) for k in ks]
            cons = set()
            for _ in range(rng.randrange(1, 5)):
                x, y = rng.sample(terms, 2) if len(terms) > 1 else (terms[0], ('k', 1.0))
                if x[0] == 'k' and y[0] == 'k': continue
                cons.add(((x, y), rng.random() < .5))
            if cons: sets.append(frozenset(cons))
        _FEAS_CACHE[key] = sets
    return _FEAS_CACHE[key]


def run_feas(sc, cand):
    sets = _constraint_sets(sc)
    T.feasible.cache_clear(); D.feasible_bits.cache_clear()
    t0 = time.perf_counter_ns()
    if cand == 'symbolic':
        out = [T.feasible(c, sc['domain']) for c in sets]
    else:
        if sc['domain'] != 'G0':
            out = [T.feasible(c, 'ext') for c in sets]   # bitsets only exist for quantized domains: fallback
        else:
            out = [D.feasible_bits(c) for c in sets]
    wall = time.perf_counter_ns() - t0
    return dict(wall_ns=wall, verdict_sha256=_sha(out), ok=True, work=dict(sets=len(sets)))


def run_layer(sc, cand):
    rng = random.Random(sc['seed']); n = sc['n']
    cases = [(roundtrip(random_case(rng, n, p_unknown=pu, p_edge_unknown=pu, settings_mix=False)), rng.randrange(n // 2, n))
             for pu in (0.1, 0.3, 0.5) for _ in range(3)]
    fn = {'exact0': L.exact_from_zero, 'seeded': L.seeded_exact, 'goal': L.goal_pruned}[cand]
    out = []; ev = 0
    t0 = time.perf_counter_ns()
    for c, t in cases:
        cc = {}; r = fn(c, t, 'ext', False, budget=400000, counters=cc); ev += cc['evaluations']
        out.append((r[0] == 'certified', T._key(r[1]) if r[0] == 'certified' else None))
    wall = time.perf_counter_ns() - t0
    return dict(wall_ns=wall, verdict_sha256=_sha(out), ok=True, work=dict(evaluations=ev))


def run_coupled(sc, cand):
    import workloads as W, coupled_runner as CR, wpB_coupled as BC
    tot = {}; outs = []
    t0 = time.perf_counter_ns()
    for seed in sc['seeds']:
        tr = W.FAMILIES[sc['wfam']](seed)
        if cand == 'incumbent':
            r = CR.Runner(tr, policy='incumbent', service_u=3, q_u=1).run()
        else:
            kind = cand.split('_')[1]
            strong = dict(kind=kind, domain='nonneg', alpha=False, gate='raw')
            R = BC.BlockRunner if kind == 'blocks' else CR.Runner
            r = R(tr, policy='gated', service_u=3, q_u=1, strong=strong).run()
        outs.append((r['published'], r['wrong']))
        for k in ('published', 'wrong', 'total_latency_u', 'physical_admissions', 'strong_attempts',
                  'strong_certificates', 'strong_evaluations'):
            tot[k] = tot.get(k, 0) + r[k]
    wall = time.perf_counter_ns() - t0
    return dict(wall_ns=wall, verdict_sha256=_sha(outs), ok=tot['wrong'] == 0, work=tot)


def run_one(sc, cand, rep=0):
    return {'inc': run_inc, 'sig': run_sig, 'feas': run_feas, 'layer': run_layer, 'coupled': run_coupled}[sc['family']](sc, cand)
