"""Lemma S1 check: shadow adoption == incumbent physically; per-target latency <= incumbent.
python3 bench/run_wpA_shadow.py [sets]  -> results/summary/wpA/shadow.json"""
import json, sys, time, random
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import wpA_lib as A

ROOT = Path(__file__).resolve().parents[1]
PHYS = ('physical_admissions', 'physical_finishes', 'raw_insertions', 'rank_computations', 'discarded', 'end_u')


def attack_traces(seed, k):
    rng = random.Random(seed)
    out = []
    for j in range(k):
        n = rng.randrange(6, 20)
        world = A._chain_world(n, rng=rng, step_noise=rng.random() < .5) if rng.random() < .6 else A._rand_world(rng, n)
        holes = set(rng.sample(range(n - 1), rng.randrange(1, max(2, n // 4))))
        init = A.initial_from(world, set(range(n)), [a for a in range(n - 1) if a not in holes])
        ev = [dict(at=rng.randrange(0, 30), op='target', target=rng.randrange(n)) for _ in range(rng.randrange(2, 8))]
        if rng.random() < .3:
            ev.append(dict(at=rng.randrange(0, 30), op='evict_raw'))
        ev.sort(key=lambda e: e['at'])
        out.append(dict(name=f'atk{seed}_{j}', initial=init, world=world, events=ev))
    return out


def main():
    sets = sys.argv[1:] or ['tuning', 'heldout', 'heldout2', 'attack']
    traces = []
    for s in sets:
        if s == 'tuning': traces += A.tuning_traces()
        elif s == 'heldout': traces += A.heldout_traces()
        elif s == 'heldout2': traces += A.heldout2_traces()
        elif s == 'attack': traces += attack_traces(7, 60)
    cells = viol_phys = viol_lat = viol_cur = 0
    better = 0
    gains = []
    examples = []
    t0 = time.time()
    for tr in traces:
        for cap in (1, 3):
            for su in (2, 4, 8):
                for q in (1, 4):
                    kw = dict(service_u=su, q_u=q, capacity=cap)
                    ri = A.make_runner(tr, 'incumbent', **kw)
                    inc = ri.run(max_steps=20000)
                    for pol in ('gated_shadow', 'shadow'):
                        rr = A.make_runner(tr, pol, **kw)
                        r = rr.run(max_steps=20000)
                        cells += 1
                        if not set(ri.session.published) <= set(rr.session.published):
                            viol_cur += 1
                        pd = {k: (inc[k], r[k]) for k in PHYS if inc[k] != r[k] and k != 'end_u'}
                        if pd or inc['livelock'] != r['livelock'] or r['wrong']:
                            viol_phys += 1
                            if len(examples) < 5: examples.append(dict(trace=tr['name'], pol=pol, kw=kw, diff=pd, wrong=r['wrong']))
                        lv = [t for t, l in inc['latency_u'].items() if r['latency_u'].get(t, 10 ** 9) > l]
                        if lv:
                            viol_lat += 1
                            if len(examples) < 5: examples.append(dict(trace=tr['name'], pol=pol, kw=kw, later=lv))
                        if r['total_latency_u'] < inc['total_latency_u']:
                            better += 1
                        gains.append(dict(trace=tr['name'], pol=pol, cap=cap, su=su, q=q,
                                          inc=inc['total_latency_u'], new=r['total_latency_u'],
                                          proofs=r['proof_starts'], wins=r['proof_wins'],
                                          lane_u=r['lane_busy_u'], inc_livelock=inc['livelock']))
    out = dict(sets=sets, traces=len(traces), cells=cells, physical_or_correctness_violations=viol_phys,
               per_target_latency_violations=viol_lat, final_current_publication_subset_violations=viol_cur, strictly_better_cells=better, examples=examples,
               wall_s=round(time.time() - t0, 1))
    agg = {}
    for g in gains:
        k = f"{g['pol']}|cap{g['cap']}|su{g['su']}|q{g['q']}"
        a = agg.setdefault(k, dict(inc=0, new=0, proofs=0, wins=0, lane_u=0))
        for x in ('inc', 'new', 'proofs', 'wins', 'lane_u'): a[x] += g[x]
    out['aggregate'] = agg
    (ROOT / 'results/summary/wpA/shadow.json').write_text(json.dumps(out, indent=1))
    with open(ROOT / 'results/raw/wpA/shadow_cells.jsonl', 'w') as f:
        for g in gains: f.write(json.dumps(g) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k != 'aggregate'}))


if __name__ == '__main__':
    main()
