"""WP-H coupled D4 runs on HELD-OUT workloads (seeds 100-107; families never used to tune any WP-H
parameter).  Every run audits lifecycle: wrong (at publication time vs hidden truth), wrong_current (end
state), confirmed subset of published, occupied tasks at the end, raw residency bound, unserved intents."""
import json
import random
import time
from copy import deepcopy
from pathlib import Path

import paths  # noqa: F401
import workloads as W
import wpH_runner as R
import wpH_commit as H

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpH'
HELD_OUT = [('RP', s) for s in range(100, 104)] + [('W01', s) for s in range(100, 102)] + \
           [('W02', s) for s in range(100, 102)] + [('W06', s) for s in range(100, 102)]


def with_events(tr, seed, churn=True, rebind=True, confirms=True, prefetch=False, late=False, cancels=True):
    rng = random.Random(seed)
    n = len(tr['initial']['items'])
    evs = list(tr['events'])
    end = max(e['at'] for e in evs)
    if churn:
        evs += [dict(at=rng.randrange(1, end + 1), op='churn', item=rng.randrange(n)) for _ in range(8)]
    if rebind:
        evs += [dict(at=end // 2, op='rebind')]
    if confirms:
        evs += [dict(at=rng.randrange(1, end + 20), op='confirm', target=rng.randrange(n)) for _ in range(6)]
    if late:
        evs += [dict(at=rng.randrange(5, end + 20), op='late_confirm', target=rng.randrange(n)) for _ in range(10)]
    if prefetch:
        evs += [dict(at=k, op='prefetch', item=rng.randrange(n)) for k in range(0, end, 2)]
    if cancels:
        evs += [dict(at=rng.randrange(1, end + 1), op='cancel') for _ in range(6)]
    return dict(tr, events=sorted(evs, key=lambda e: e['at']))


def lifecycle(r):
    """adoption, publication, confirmation, cancellation, invalidation/rebind, release audit of one run."""
    return dict(admissions=r['physical_admissions'], finishes=r['physical_finishes'], discarded=r['discarded'],
                cancels=r.get('cancels', 0), cancel_results=r.get('cancel_results', {}),
                publications_now=r['published_now'], reopened=r.get('reopened', 0), rebinds=r['rebinds'],
                confirm_results=sorted(set(map(str, r['confirm_results'].values()))),
                released=r['occupied_end'] == 0, peak_le_capacity=r['peak_occupied'] <= r['capacity'],
                raw_le_cap=r['raw_end'] <= r['raw_capacity'], confirmed_subset=r['confirmed_subset'],
                wrong=r['wrong'], wrong_current=r['wrong_current'], unserved=len(r['unserved']))


def run(fam, seed, cls, **kw):
    tr = W.FAMILIES[fam](seed)
    ev_kw = {k: kw.pop(k) for k in ('churn', 'rebind', 'confirms', 'prefetch', 'late', 'cancels') if k in kw}
    tr2 = with_events(tr, seed, **ev_kw)
    t0 = time.perf_counter_ns()
    rr = R.RunnerH(tr2, session_cls=cls, policy=kw.pop('policy', 'incumbent'), service_u=kw.pop('service_u', 3), **kw)
    r = rr.run()
    r['wall_ns'] = time.perf_counter_ns() - t0
    r['family'], r['seed'] = fam, seed
    r['raw_le_cap'] = rr.session.raw_size <= rr.session.raw_capacity
    return r, rr


def d4_incremental():
    rows = []
    for fam, seed in HELD_OUT:
        a, ra = run(fam, seed, R.StrongSession)
        b, rb = run(fam, seed, H.IncSession)
        rows.append(dict(family=fam, seed=seed, same_publications=ra.session.published == rb.session.published,
                         same_confirmations=ra.session.confirmed == rb.session.confirmed,
                         same_latency=a['total_latency_u'] == b['total_latency_u'],
                         read_checks_full=a['publication_read_checks'], read_checks_inc=b['publication_read_checks'],
                         wrong=a['wrong'] + b['wrong'], wrong_current=a['wrong_current'] + b['wrong_current'],
                         reopened=b.get('reopened', 0), rebinds=b['rebinds'], confirmed_subset=a['confirmed_subset'] and b['confirmed_subset'],
                         occupied_end=b['occupied_end'], unserved=len(b['unserved']), wall_full_ns=a['wall_ns'], wall_inc_ns=b['wall_ns'],
                         lifecycle=lifecycle(b)))
    return rows


def d4_value_cache():
    rows = []
    for fam, seed in HELD_OUT:
        out = {}
        for label, cls in (('incumbent', R.StrongSession), ('value_cache', H.ValueCacheSession)):
            tr = W.FAMILIES[fam](seed)
            tr2 = with_events(tr, seed, churn=False, rebind=False, confirms=True, cancels=True)
            end = max(e['at'] for e in tr2['events'])
            tr2['events'] = sorted(tr2['events'] + [dict(at=end // 3, op='rebind'), dict(at=2 * end // 3, op='rebind')],
                                   key=lambda e: e['at'])
            rr = R.RunnerH(tr2, session_cls=cls, policy='incumbent', service_u=3)
            init = deepcopy(tr['initial']); orig = rr._custom

            def custom(ev, rr=rr, init=init, orig=orig):
                if ev['op'] == 'rebind':          # knowledge-losing rebind (fresh owner incarnation)
                    rr.session.rebind(deepcopy(init)); rr.audit['rebinds'] += 1
                    for kk in list(rr.first_pub):
                        rr.first_pub.pop(kk); rr.intent[kk] = rr.now
                    return
                orig(ev)
            rr._custom = custom
            t0 = time.perf_counter_ns()
            r = rr.run()
            r['wall_ns'] = time.perf_counter_ns() - t0
            # authority check: no certificate handle issued before the last rebind is accepted now
            old = [h for h, c in rr.session._certs.items() if c['epoch'] != rr.session.epoch]
            out[label] = dict(physical_admissions=r['physical_admissions'], latency=r['total_latency_u'],
                              hits=r['value_cache_hits'], wrong=r['wrong'], wrong_current=r['wrong_current'],
                              old_epoch_certificates_retained=len(old), unserved=len(r['unserved']),
                              confirmed_subset=r['confirmed_subset'], wall_ns=r['wall_ns'], lifecycle=lifecycle(r))
        rows.append(dict(family=fam, seed=seed, **{f'{k}_{kk}': vv for k, v in out.items() for kk, vv in v.items()}))
    return rows


def d4_bound_confirm():
    rows = []
    for fam, seed in HELD_OUT:
        out = {}
        for label, cls, bound in (('package_confirm', R.StrongSession, False), ('bound_confirm', H.BoundConfirmSession, True)):
            r, rr = run(fam, seed, cls, churn=True, rebind=False, confirms=False, late=True, bound_confirm=bound)
            lc = r.get('late_callbacks', [])
            out[label] = dict(late_callbacks=len(lc),
                              confirmed_via_expired_callback=sum(1 for x in lc if x['refers_to_expired'] and x['result'] == 'confirmed'),
                              wrong=r['wrong'], wrong_current=r['wrong_current'], confirmed_subset=r['confirmed_subset'],
                              lifecycle=lifecycle(r))
        rows.append(dict(family=fam, seed=seed, **{f'{k}_{kk}': vv for k, v in out.items() for kk, vv in v.items()}))
    return rows


def d4_reservation():
    rows = []
    for fam, seed in HELD_OUT:
        out = {}
        for label, cls in (('no_reserve', R.StrongSession), ('reserve1', R.ReservingSession)):
            r, rr = run(fam, seed, cls, churn=False, rebind=False, confirms=False, prefetch=True)
            out[label] = dict(latency=r['total_latency_u'], admissions=r['physical_admissions'],
                              refusals=r['reservation_refusals'], wrong=r['wrong'], unserved=len(r['unserved']),
                              discarded=r['discarded'], lifecycle=lifecycle(r), max_latency=max(rr.first_pub[k] - rr.intent[k] for k in rr.first_pub) if rr.first_pub else None)
        rows.append(dict(family=fam, seed=seed, **{f'{k}_{kk}': vv for k, v in out.items() for kk, vv in v.items()}))
    return rows


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    res = dict(held_out=HELD_OUT, incremental=d4_incremental(), value_cache=d4_value_cache(),
               bound_confirm=d4_bound_confirm(), reservation=d4_reservation())
    (OUT / 'd4.json').write_text(json.dumps(res, indent=1, default=str))
    return res


if __name__ == '__main__':
    r = main()
    for k in ('incremental', 'value_cache', 'bound_confirm', 'reservation'):
        for row in r[k]:
            print(k, json.dumps(row))
