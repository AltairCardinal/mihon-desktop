"""Scan rule as a finite transducer over positions (F1/A1/A2/B2/E6 core).

Frozen semantics are evaluated by reference._Scan itself; this module only
changes *where* steps are evaluated and how their effects are composed.

State at the boundary before position i (10 states):
    mode in {at(opening, reserved==i) x4, skip}   skip = i is the 2nd member of a pair
    m    = manual(i-1) as a bit                    (pinned-link parity, forward recurrence)
manual(o) = B(o) and not manual(o-1), with
    B(o) = o in starts and 0 <= o < n-1 and valid(o)          (proof in proofs/PROOFS.md, L-M)
so step i only reads facts in the window [i-1, i+3] and edges (i,i+1),(i+1,i+2).

Two fact semantics:
  * 'complete'  - complete_plan semantics (effective facts, provisional units).
  * 'omega'     - possible completions of current knowledge (alpha header
                  authority, see proofs), ranks from an abstract domain:
                  'ext' finite doubles, 'nonneg', 'G0' (m/50 grid, 0<=m<=1499).
Relations are 10-bit masks; a leaf maps each input state to the set of states
reachable under *some* assignment of the unknown facts in its window.  Leaves
branch independently, so composition over-approximates Omega (sound, see L-R1).
"""
import math
from functools import lru_cache

from common import ref
import compact_core as core

NSTATE = 10
SKIP = 4
S0 = 0 * 2 + 0          # mode at(opening=True, res=False) encoded below
_FULL = (1 << NSTATE) - 1
DBL_MAX = 1.7976931348623157e308


def enc(mode, m):
    return mode * 2 + m


def mode_of(opening, res):
    # mode 0: at(True,False) 1: at(True,True) 2: at(False,False) 3: at(False,True) 4: skip
    return (0 if opening else 2) + (1 if res else 0)


S0 = enc(mode_of(True, False), 0)


class Need(Exception):
    __slots__ = ('key', 'options')

    def __init__(self, key, options):
        self.key, self.options = key, options


# ---------------------------------------------------------------- rank domain
def _cands(domain, knowns):
    """Finite candidate set exhibiting every strict-order outcome realisable in
    the domain with respect to the given known values (used by joint checks)."""
    ks = sorted(set(knowns))
    if domain == 'G0':
        grid = set()
        for k in ks:
            m = k * 50
            for d in (-2, -1, 0, 1, 2):
                for base in (math.floor(m), math.ceil(m)):
                    if 0 <= base + d <= 1499:
                        grid.add((base + d) / 50)
        grid.update((0.0, 0.02, 0.04, 29.94, 29.96, 29.98, 10.0, 10.02, 10.04))
        return sorted(grid)
    lo = 0.0 if domain == 'nonneg' else -DBL_MAX
    out = {lo, DBL_MAX, 1.0, 2.0, 3.0}
    if domain != 'nonneg':
        out.update((-1.0, -2.0, -3.0))
    for k in ks:
        if isinstance(k, int):
            out.update((k - 1, k, k + 1))
        a = float(k)
        for _ in range(3):
            a = math.nextafter(a, -math.inf)
            out.add(a)
        a = float(k)
        for _ in range(3):
            a = math.nextafter(a, math.inf)
            out.add(a)
        out.add(k)
    return sorted(x for x in out if lo <= x <= DBL_MAX and (isinstance(x, int) or math.isfinite(x)))


@lru_cache(maxsize=65536)
def feasible(constraints, domain):
    """constraints: frozenset of ((x, y), outcome) meaning (x < y) == outcome,
    x/y = ('e', edge) symbolic non-null rank or ('k', value).  Joint check."""
    vars_ = sorted({t[1] for (xy, _) in constraints for t in xy if t[0] == 'e'})
    knowns = [t[1] for (xy, _) in constraints for t in xy if t[0] == 'k']
    cands = _cands(domain, knowns)
    if not vars_:
        return all(((xy[0][1] < xy[1][1]) == out) for xy, out in constraints)
    idx = {v: j for j, v in enumerate(vars_)}

    def val(t, assign):
        return assign[idx[t[1]]] if t[0] == 'e' else t[1]

    def rec(j, assign):
        if j == len(vars_):
            return all((val(xy[0], assign) < val(xy[1], assign)) == out for xy, out in constraints)
        for c in cands:
            assign.append(c)
            # prune: check constraints whose vars are all assigned
            ok = True
            for xy, out in constraints:
                if all(t[0] == 'k' or idx[t[1]] <= j for t in xy):
                    if (val(xy[0], assign) < val(xy[1], assign)) != out:
                        ok = False
                        break
            if ok and rec(j + 1, assign):
                assign.pop()
                return True
            assign.pop()
        return False
    return rec(0, [])


class Sym:
    """A non-null rank whose value is unknown; comparisons branch."""
    __slots__ = ('edge', 'ctx')

    def __init__(self, edge, ctx):
        self.edge, self.ctx = edge, ctx

    def _cmp(self, x, y):
        return self.ctx.compare(x, y)

    def __lt__(self, other):
        return self.ctx.compare(self, other)

    def __gt__(self, other):
        return self.ctx.compare(other, self)


def _term(v):
    # known values keep their exact Python numeric type (int vs float, N04)
    return ('e', v.edge) if isinstance(v, Sym) else ('k', v)


# ------------------------------------------------------------------- facts
class Facts:
    """Per-position compiled knowledge."""

    def __init__(self, case, semantics='omega', domain='ext', header_authority=True):
        self.case = case
        self.semantics, self.domain, self.alpha = semantics, domain, header_authority
        ix = core.Index(case)
        self.ix = ix
        self.n = ix.n
        self.settings = ix.settings
        self.starts = set(ix.settings['pinned_links']) | ({0} if ix.settings['opening'] == 'PAIR' else set())
        self.forced = set(ix.settings['hard_isolates'])
        self.automatic = ix.settings['automatic']
        n = self.n
        # fixed[p] = (state, side) or None if state free; side None = free
        self.state = [None] * n     # 'NARROW'/'WIDE'/other or None(free)
        self.side = [None] * n      # side string or None(free)
        self.fact = [None] * n      # complete semantics: effective fact tuple
        self.acomp = [None] * n     # complete semantics: computed analysis fact (or None)
        for p in range(n):
            if semantics == 'complete':
                self._load_complete(p)
                continue
            self._load_omega(p)
        self.domain_ok = True
        self.records = {}
        for (a, b), e in ix._edge_index().items():
            if b == a + 1 and 0 <= a < n - 1:
                self.records[a] = e
                if semantics == 'omega' and e.get('status') == 'computed':
                    s = e.get('score', None)
                    if s is not None and not _in_domain(s, domain):
                        self.domain_ok = False

    def _load_omega(self, p):
        ix = self.ix
        a = ix.analysis(p)
        ident = ix.ident(p)
        if a[0] == 'computed' and _valid(a[1], ident):
            self.state[p], self.side[p] = a[1][0], a[1][5]
            return
        h = ix.header(p)
        self.state[p] = h[0] if (self.alpha and _valid(h, ident)) else None
        self.side[p] = None

    def refresh_item(self, p, item):
        """Owner-method update of item p (identity unchanged), either semantics."""
        self.case['items'][p] = item
        self.ix._analysis.pop(p, None)
        self.ix._header.pop(p, None)
        self.ix._ident.pop(p, None)
        if self.semantics == 'complete':
            self._load_complete(p)
        else:
            self._load_omega(p)

    def _load_complete(self, p):
        a = self.ix.analysis(p)
        self.acomp[p] = a[1] if a[0] == 'computed' else None
        self.fact[p] = a[1] if a[0] == 'computed' else self.ix.header(p)

    # ---- owner-method delta API (complete semantics) -------------------
    def set_item(self, p, item):
        """Replace item p's evidence (same identity) and refresh compiled facts."""
        self.case['items'][p] = item
        self.ix._analysis.pop(p, None)
        self.ix._header.pop(p, None)
        self.ix._ident.pop(p, None)
        self._load_complete(p)

    def set_edge(self, a, record):
        """record=None removes the record (unknown rank)."""
        if record is None:
            self.records.pop(a, None)
        else:
            self.records[a] = dict(record, first=a, second=a + 1)

    def free_positions(self):
        return [p for p in range(self.n) if self.state[p] is None or (self.automatic and self.side[p] is None)]


def _valid(f, ident):
    return f is not None and core._geometry_t(f) and f[3] == ident[2] and f[4] == ident[3]


def _in_domain(s, domain):
    if isinstance(s, bool) or not isinstance(s, (int, float)) or not math.isfinite(s):
        return False
    if domain == 'nonneg':
        return s >= 0
    if domain == 'G0':
        return 0 <= s <= 29.98 and abs(s * 50 - round(s * 50)) < 1e-9
    return True


# --------------------------------------------------------------- evaluation
class Ctx:
    """Evaluates reference._Scan steps under an assignment of abstract facts."""

    def __init__(self, facts):
        self.F = facts
        self.asg = {}
        self.m = {}
        F = facts
        if F.semantics == 'complete':
            dim = self._dim_complete
            side = resolved = self._side_complete
            rank = self._rank_complete
        else:
            dim, side, resolved, rank = self._dim, self._side, self._side, self._rank
        self.scan = _LocalScan(F.n, F.settings, dim, side, resolved, rank, self)

    # complete_plan semantics
    def _dim_complete(self, i):
        f = self.F.fact[i]
        return None if f is None else {'state': f[0]}

    def _side_complete(self, i):
        f = self.F.fact[i]
        return f[5] if f else 'UNKNOWN'

    def _resolved_complete(self, i):
        f = self.F.fact[i]
        return f[5] if f else None

    def _rank_complete(self, a, b):
        # reference._Input.edge: computed endpoint analyses required; WIDE -> null
        F = self.F
        fa, fb = F.acomp[a], F.acomp[b]
        if b != a + 1 or fa is None or fb is None:
            return None
        if fa[0] == 'WIDE' or fb[0] == 'WIDE':
            return None
        e = F.records.get(a)
        if e is None or e.get('status') != 'computed':
            return None
        return e.get('score', None)

    # omega semantics
    def choose(self, key, options):
        v = self.asg.get(key, _UNSET)
        if v is _UNSET:
            raise Need(key, options)
        return v

    def _state(self, p):
        s = self.F.state[p]
        return s if s is not None else self.choose(('st', p), ('NARROW', 'WIDE'))

    def _dim(self, i):
        return {'state': self._state(i)}

    def _side(self, i):
        s = self.F.side[i]
        return s if s is not None else self.choose(('sd', i), ('A', 'B', 'UNKNOWN'))

    def _rank(self, a, b):
        if self._state(a) == 'WIDE' or self._state(b) == 'WIDE':
            return None
        e = self.F.records.get(a)
        if e is not None and e.get('status') == 'computed':
            return e.get('score', None)
        if self.choose(('rk', a), ('NULL', 'VAL')) == 'NULL':
            return None
        return Sym(a, self)

    def compare(self, x, y):
        key = ('lt', _term(x), _term(y))
        v = self.asg.get(key, _UNSET)
        if v is not _UNSET:
            return v
        opts = tuple(o for o in (True, False) if feasible(self._constraints(key, o), self.F.domain))
        raise Need(key, opts)

    def _constraints(self, key, outcome):
        cs = {((k[1], k[2]), v) for k, v in self.asg.items() if k[0] == 'lt'}
        cs.add(((key[1], key[2]), outcome))
        return frozenset(cs)


_UNSET = object()


class _LocalScan(ref._Scan):
    """Frozen scan rule; only manual() reads the forward-recurrence bits."""

    def __init__(self, n, settings, dimension, side, resolved, distance, ctx):
        super().__init__(n, settings, dimension, side, resolved, distance)
        self.ctx = ctx

    def manual(self, i):
        return self.ctx.m[i]


def explore(ctx, fn, base=None):
    """All (result, assignment) over assignments of the facts fn actually reads."""
    out = []
    stack = [dict(base or {})]
    while stack:
        asg = stack.pop()
        ctx.asg = asg
        try:
            out.append((fn(), asg))
        except Need as e:
            for o in e.options:
                d = dict(asg)
                d[e.key] = o
                stack.append(d)
    return out


def _B(ctx, o):
    F = ctx.F
    if o not in F.starts or not 0 <= o < F.n - 1:
        return False
    if o in F.forced or o + 1 in F.forced:
        return False
    return not ctx.scan.wide(o) and not ctx.scan.wide(o + 1)


def set_manual(ctx, i, m_in):
    """Forward recurrence for manual(i-1..i+2) from the incoming bit."""
    ctx.m = {i - 1: bool(m_in)}
    prev = bool(m_in)
    for o in (i, i + 1, i + 2):
        prev = _B(ctx, o) and not prev
        ctx.m[o] = prev


def step_result(ctx, i, state, include=False):
    """(next_state, unit_or_None) for one evaluation under ctx.asg."""
    mode, m_in = divmod(state, 2)
    set_manual(ctx, i, m_in)
    m_out = int(ctx.m[i])
    if mode == SKIP:
        return enc(mode_of(False, False), m_out), None
    opening = mode < 2
    res = mode % 2 == 1
    unit, nxt = ctx.scan.step((i, opening, i if res else -1), include_single=include, include_pair=include)
    if nxt[0] == i + 2:
        return enc(SKIP, m_out), unit
    return enc(mode_of(nxt[1], nxt[2] == i + 1), m_out), unit


def leaf(ctx, i):
    """Relation for position i as 10 bitmasks."""
    rel = [0] * NSTATE
    for s in range(NSTATE):
        for (nxt, _), _a in explore(ctx, lambda: step_result(ctx, i, s)):
            rel[s] |= 1 << nxt
    return tuple(rel)


def leaf_fast(ctx, i):
    """Same relation; evaluates m-independent windows once (no starts nearby)."""
    F = ctx.F
    if not any(o in F.starts for o in range(i - 1, i + 3)):
        rel = [0] * NSTATE
        for mode in range(5):
            s = enc(mode, 0)
            mask = 0
            for (nxt, _), _a in explore(ctx, lambda: step_result(ctx, i, s)):
                mask |= 1 << nxt
            rel[s] = mask
            rel[s + 1] = mask            # m_in only feeds manual(i-1): False without starts
        return tuple(rel)
    return leaf(ctx, i)


def compose(f, g):
    """first f then g."""
    out = []
    for s in range(NSTATE):
        mask, acc = f[s], 0
        while mask:
            low = mask & -mask
            acc |= g[low.bit_length() - 1]
            mask ^= low
        out.append(acc)
    return tuple(out)


def apply(rel, states):
    acc = 0
    while states:
        low = states & -states
        acc |= rel[low.bit_length() - 1]
        states ^= low
    return acc


IDENTITY = tuple(1 << s for s in range(NSTATE))


class RelTree:
    """Segment tree of leaf relations; point updates and prefix queries."""

    def __init__(self, facts, counters=None):
        self.F = facts
        self.ctx = Ctx(facts)
        self.n = facts.n
        size = 1
        while size < max(1, self.n):
            size *= 2
        self.size = size
        self.tree = [IDENTITY] * (2 * size)
        self.counters = counters if counters is not None else {}
        for i in range(self.n):
            self.tree[size + i] = leaf_fast(self.ctx, i)
        for v in range(size - 1, 0, -1):
            self.tree[v] = compose(self.tree[2 * v], self.tree[2 * v + 1])
        self._count('leaf_evals', self.n)
        self._count('node_compose', size - 1)

    def _count(self, k, v=1):
        self.counters[k] = self.counters.get(k, 0) + v

    def update_leaves(self, positions):
        touched = set()
        for i in positions:
            if 0 <= i < self.n:
                self.tree[self.size + i] = leaf_fast(self.ctx, i)
                self._count('leaf_evals')
                v = (self.size + i) // 2
                while v:
                    touched.add(v)
                    v //= 2
        for v in sorted(touched, reverse=True):
            self.tree[v] = compose(self.tree[2 * v], self.tree[2 * v + 1])
        self._count('node_compose', len(touched))

    def prefix(self, t, states=1 << S0):
        """States at the boundary before position t (bitmask)."""
        node, lo, hi = 1, 0, self.size
        while t > lo:
            if t >= hi:
                return apply(self.tree[node], states)
            mid = (lo + hi) // 2
            if t >= mid:
                states = apply(self.tree[2 * node], states)
                node, lo = 2 * node + 1, mid
            else:
                node, hi = 2 * node, mid
        return states

    def units(self, target):
        """Set of possible target units (as canonical keys) and one dict each."""
        ctx = self.ctx
        found = {}
        before_t = self.prefix(target)
        at_states = before_t & ~(((1 << enc(SKIP, 0)) | (1 << enc(SKIP, 1))))
        for s in _bits(at_states):
            for (nxt, unit), _a in explore(ctx, lambda: step_result(ctx, target, s, include=True)):
                found[_key(unit)] = unit
        if before_t & ((1 << enc(SKIP, 0)) | (1 << enc(SKIP, 1))):
            before = self.prefix(target - 1)
            for s in _bits(before):
                for (nxt, unit), _a in explore(ctx, lambda: step_result(ctx, target - 1, s, include=True)):
                    if nxt >> 1 == SKIP and unit is not None:
                        found[_key(unit)] = unit
        self._count('queries')
        return found


def _bits(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask ^= low


def _key(unit):
    return (tuple((s['item'], s['slot']) for s in unit['slots']), unit['certain'], unit['reason'])


def window_positions(i):
    """Positions whose facts leaf i reads (window lemma L-W)."""
    return range(i - 1, i + 4)


def affected_leaves(p):
    """Leaves whose window contains position p (fact or adjacent-edge change)."""
    return range(p - 3, p + 2)


def complete_plan_tree(case):
    """complete_plan via the transducer (deterministic special case)."""
    F = Facts(case, 'complete')
    T = RelTree(F)
    out = []
    ctx = T.ctx
    s, i = S0, 0
    while i < F.n:
        ctx.asg = {}
        nxt, unit = step_result(ctx, i, s, include=True)
        out.append(unit)
        if nxt >> 1 == SKIP:
            ctx.asg = {}
            s = step_result(ctx, i + 1, nxt)[0]
            i += 2
        else:
            s, i = nxt, i + 1
    return out


def certify_tree(case, target, domain='ext', header_authority=True):
    """Over-approximate Omega certification from the exact start state."""
    F = Facts(case, 'omega', domain, header_authority)
    T = RelTree(F)
    us = T.units(target)
    if len(us) == 1:
        return 'certified', next(iter(us.values()))
    return 'ambiguous', None
