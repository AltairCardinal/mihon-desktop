"""B01/B04/X02/X05: exact composable interval summaries with explicit boundary
assignments (WP-B).

Boundary interface (proofs/wpB.md, Lemma B-1).  At the boundary before
position b the only facts that steps < b may already have bound AND steps >= b
may still read are
    state/side of positions b-1, b, b+1, b+2      (window lemma [i-1, i+3])
    the null/value choice of edge (b, b+1)
    order constraints on edges >= b (non-empty only for the i=0 chain, Lemma R)
plus the transducer state (cursor mode x manual bit).  `omega._prune` keeps
exactly these; we use the pruned assignment as the boundary key.

A block [L, R) summary is the relation  key_L -> {key_R}  obtained by running
the shared-assignment DP from key_L over the block's positions.  It depends
only on facts in [L-1, R+2] and edges L-1..R (read by steps L..R-1), so a
change elsewhere leaves it valid.  Tables are filled lazily per entry key
(route A, explicit finite relation table).  Route B interns tables
canonically (hash-consed decision-table sharing, MDD-like).

Exactness (Theorem B-2): composing block relations from {(S0, {})} reproduces
the exact DP frontier at every block boundary, hence certify() equals
omega.certify_exact(first=0) on every input.  Verified against the DP and the
world oracle in tests/test_wpB_core.py.
"""
import paths  # noqa: F401
import transducer as T
import omega as O


class BlockSummary:
    def __init__(self, case, domain='ext', alpha=True, block=8, intern=False, lazy=True, counters=None):
        self.case = case
        self.domain, self.alpha, self.B = domain, alpha, max(1, block)
        self.F = T.Facts(case, 'omega', domain, alpha)
        if not self.F.domain_ok:
            self.F = T.Facts(case, 'omega', 'ext', alpha)
        self.ctx = T.Ctx(self.F)
        self.n = self.F.n
        self.nb = (self.n + self.B - 1) // self.B
        self.tables = [dict() for _ in range(self.nb)]     # entry key -> frozenset(exit keys)
        self.frontier_at = {0: frozenset({(T.S0, frozenset())})}   # boundary block index -> frontier
        self.intern = intern
        self._interned = {}
        self.lazy = lazy
        self.c = counters if counters is not None else {}
        for k in ('evaluations', 'table_entries', 'table_hits', 'block_runs', 'invalidated_blocks',
                  'frontier_recompose', 'max_frontier', 'max_key_vars'):
            self.c.setdefault(k, 0)
        if not lazy:
            self._eager_build()

    # ------------------------------------------------------------ blocks
    def _range(self, b):
        return b * self.B, min(self.n, (b + 1) * self.B)

    def _run_block(self, b, key):
        L, R = self._range(b)
        ctx = self.ctx
        frontier = {key}
        for i in range(L, R):
            nxt = set()
            for s, asg in frontier:
                res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=False), dict(asg))
                self.c['evaluations'] += len(res)
                for (ns, _u), a in res:
                    nxt.add((ns, frozenset(O._prune(a, i).items())))
            frontier = nxt
        self.c['block_runs'] += 1
        out = frozenset(frontier)
        if self.intern:
            out = self._interned.setdefault(out, out)
        return out

    def exits(self, b, key):
        tab = self.tables[b]
        got = tab.get(key)
        if got is None:
            got = self._run_block(b, key)
            tab[key] = got
            self.c['table_entries'] += 1
            self.c['max_key_vars'] = max(self.c['max_key_vars'], len(key[1]))
        else:
            self.c['table_hits'] += 1
        return got

    def _eager_build(self):
        # X02 contrast: materialise every block reachable from the true start
        f = self.frontier_at[0]
        for b in range(self.nb):
            nxt = set()
            for key in f:
                nxt |= self.exits(b, key)
            f = frozenset(nxt)
            self.frontier_at[b + 1] = f

    def frontier(self, bb):
        """Exact frontier at the boundary before block bb (position bb*B)."""
        known = max(k for k in self.frontier_at if k <= bb)
        f = self.frontier_at[known]
        for b in range(known, bb):
            nxt = set()
            for key in f:
                nxt |= self.exits(b, key)
            f = frozenset(nxt)
            self.frontier_at[b + 1] = f
            self.c['frontier_recompose'] += 1
            self.c['max_frontier'] = max(self.c['max_frontier'], len(f))
        return f

    # ------------------------------------------------------------ query
    def certify(self, target):
        """('certified', unit) | ('ambiguous', units) | ('contradiction', None)."""
        start_pos = max(0, target - 1)
        bb = start_pos // self.B
        frontier = self.frontier(bb)
        ctx = self.ctx
        # finish with direct steps from the block boundary to the target
        pos = bb * self.B
        units = {}
        for i in range(pos, target + 1):
            include = i >= target - 1
            nxt = set()
            for s, asg in frontier:
                if s >> 1 == T.SKIP and i == target:
                    continue
                res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(asg))
                self.c['evaluations'] += len(res)
                for (ns, unit), a in res:
                    if include and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                        units[T._key(unit)] = unit
                    elif i < target:
                        nxt.add((ns, frozenset(O._prune(a, i).items())))
            frontier = nxt
        if not units:
            return 'contradiction', None          # empty completion set: never a vacuous certificate
        if len(units) == 1:
            return 'certified', next(iter(units.values()))
        return 'ambiguous', units

    # ------------------------------------------------------------ updates
    def _affected_blocks_pos(self, p):
        # block b reads positions [L-1, R+2]
        out = set()
        for b in range(self.nb):
            L, R = self._range(b)
            if L - 1 <= p <= R + 2:
                out.add(b)
        return out

    def _affected_blocks_edge(self, a):
        # edge (a,a+1) is read by steps a-1 and a
        return {q // self.B for q in (a - 1, a) if 0 <= q < self.n}

    def update(self, items=None, edges=None):
        """items: {p: item_dict}; edges: {a: record or None}. Same identity/settings only."""
        dirty = set()
        for p, it in (items or {}).items():
            self.F.refresh_item(p, it)
            dirty |= self._affected_blocks_pos(p)
            dirty |= self._affected_blocks_edge(p - 1) | self._affected_blocks_edge(p)   # WIDE->structural null
        for a, rec in (edges or {}).items():
            if rec is None:
                self.F.records.pop(a, None)
            else:
                self.F.records[a] = dict(rec, first=a, second=a + 1)
                sc = rec.get('score')
                if rec.get('status') == 'computed' and sc is not None and not T._in_domain(sc, self.F.domain):
                    self.F.domain_ok = False
            dirty |= self._affected_blocks_edge(a)
        self.F.ix._edges = None
        for b in dirty:
            if self.tables[b]:
                self.tables[b] = {}
            self.c['invalidated_blocks'] += 1
        if dirty:
            first = min(dirty)
            for k in [k for k in self.frontier_at if k > first]:
                del self.frontier_at[k]
        if not self.F.domain_ok:
            raise ValueError('domain became illegal; rebuild with a wider domain')
        return dirty

    def size(self):
        entries = sum(len(t) for t in self.tables)
        exits = sum(len(v) for t in self.tables for v in t.values())
        uniq = len({id(v) for t in self.tables for v in t.values()}) if self.intern else None
        return dict(entries=entries, exit_keys=exits, unique_tables=uniq)


class StaleFrontierMutant(BlockSummary):
    """B04 mutant: forgets to drop cached frontiers after an update (keeps the
    old prefix reads) -- must be killed by tests."""

    def update(self, items=None, edges=None):
        saved = dict(self.frontier_at)
        dirty = super().update(items, edges)
        self.frontier_at = saved
        return dirty
