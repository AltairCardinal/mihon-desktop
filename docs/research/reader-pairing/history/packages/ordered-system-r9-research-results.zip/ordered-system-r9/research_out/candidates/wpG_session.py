"""WP-G coupled mechanisms on top of the public Session API.

GSession(case, raw_policy='lru'|'useless_first', reissue=False, cert_gc=False, **kw)

raw_policy='useless_first' (K01): when raw capacity is exceeded, evict first a
  resident raw witness whose BOTH adjacent ranks are already admitted (or are
  impossible: sequence end), i.e. a witness no future derivation in the current
  context can use; fall back to LRU.  Admitted scalar ranks are persistent, so a
  dead raw can only matter again after a content/analysis change, which already
  invalidates it (Session._raw_current).  Proof: wpG.md L-K1.
reissue='lazy' (X20 org. 2): same recertification, deferred to the next observation.
reissue=True (G05/X20): after every admission that makes a published
  certificate stale, the owner immediately recertifies that target (L0) and, if
  certified with the identical unit, republishes under the NEW handle in the same
  serial step.  Confirmation is never carried over (FORMAL §4).
cert_gc=True (G06): certificates that are stale (epoch/guard/support mismatch)
  and not referenced by a current publication are deleted after each admission;
  a later publish of a collected handle returns 'unsigned' (never a stale success).
"""
from copy import deepcopy

import paths  # noqa: F401
import compact_core as core
from coupling import Session
from current_baseline import typed


class GSession(Session):
    def __init__(self, case, *, raw_policy='lru', order='evict_first', reissue=False, cert_gc=False,
                 owner_factory=None, **kw):
        super().__init__(case, **kw)
        if owner_factory is not None:
            self.owner = owner_factory(case)
        self.raw_policy, self.order, self.reissue, self.cert_gc = raw_policy, order, reissue, cert_gc
        self.metrics['peak_raw'] = 0

    def _dead(self, i):
        n = len(self.owner._case['items'])
        edges = self.owner._edges
        for a, b in ((i - 1, i), (i, i + 1)):
            if a < 0 or b >= n:
                continue
            e = edges.get((a, b))
            if e is None or e.get('status') != 'computed':
                return False
        return True

    def _evict(self, protect=None):
        while len(self._raw) > self.raw_capacity:
            victim = None
            prot = protect if isinstance(protect, (set, frozenset)) else {protect}
            if self.raw_policy in ('useless_first', 'closure'):
                for i in self._raw:              # oldest first
                    if i not in prot and self._dead(i):
                        victim = i
                        break
            if victim is None and self.raw_policy == 'closure':
                # X11 org. 2: dependency closure - never evict the new witness or its
                # neighbours (the witnesses its pending ranks need) while another victim exists
                victim = next((i for i in self._raw if i not in prot), None)
            if victim is None:
                victim = next(iter(self._raw))
            else:
                self.metrics['raw_dead_evictions'] += 1
            del self._raw[victim]
            self.metrics['raw_evictions'] += 1

    def consume(self, token):
        task = self._tasks.get(token)
        if task is None or task['phase'] != 'completed':
            return 'unavailable'
        del self._tasks[token]
        if task['cancelled'] or not self._current(token, task):
            return 'discarded'
        i, result = task['item'], task['result']
        a = result.analysis
        if a.get('status') not in ('computed', 'failed'):
            raise ValueError('service must report computed or failed')
        self.owner.apply(item_updates={i: {'analysis': a}})
        self.metrics['accepted_analyses'] += 1
        self._raw.pop(i, None)
        if a['status'] == 'computed' and result.available:
            self._raw[i] = dict(value=deepcopy(result.raw), identity=token.identity,
                                analysis=typed(core.Index(self.owner._case, check_ids=False).analysis(i)),
                                version=typed(self.version))
            self.metrics['raw_insertions'] += 1
            self.metrics['peak_raw'] = max(self.metrics['peak_raw'], len(self._raw))
            if self.order == 'evict_first':          # frozen Session order
                self._evict({i - 1, i, i + 1} if self.raw_policy == 'closure' else None)
            updates = {}
            for first, second in ((i - 1, i), (i, i + 1)):
                if not self._raw_current(first) or not self._raw_current(second):
                    continue
                left, right = self._raw[first]['value'], self._raw[second]['value']
                score = None if left is None or right is None else abs(left - right)
                updates[first, second] = dict(status='computed', score=score, version=self.version)
                self.metrics['rank_computations'] += 1
            if updates:
                self.owner.apply(edge_updates=updates)
            if self.order == 'derive_first':          # K01 variant: never evict a witness before use
                self._evict()
        self._after_admission()
        return 'accepted'

    # ---------------------------------------------------------------- R_policy vs R_publish
    def certify(self, target, *, mode='L0', budget=None):
        """With a projection-support owner the memo entry carries `exact` reads; the
        certificate (publication) support must use those, never the projection."""
        if mode != 'L0' or not hasattr(self.owner, 'support_mode') or self.owner.support_mode != 'proj':
            return super().certify(target, mode=mode, budget=budget)
        result = self.owner.request(target)
        entry = self.owner._memo.get(target)
        if entry is not None and 'exact' in entry:
            support = dict(entry['exact'])
        else:
            index = self.owner._index()
            import compact_core as core2
            b = core2.certify(self.owner._case, target, 2, index=index)
            atts = [b] + ([core2.certify(self.owner._case, target, 3, index=index)] if b['status'] == 'need_facts' else [])
            support = dict(p for a in atts for p in a['proof'][2])
        self.metrics['certification_calls'] += 1
        self.metrics['certificate_support_keys'] += len(support)
        if result['status'] == 'certified':
            self._next_certificate += 1
            handle = self._next_certificate
            self._certs[handle] = dict(target=target, unit=deepcopy(result['unit']), guard=self.owner._guard(),
                                       epoch=self.epoch, support=support)
            result['certificate'] = handle
        return result

    # ---------------------------------------------------------------- G05/G06
    def _after_admission(self):
        if self.reissue and self.reissue != 'lazy':
            self._reissue_stale()
        self._gc()

    def _reissue_stale(self):
        if True:
            for target, handle in list(self._published_handles.items()):
                cert = self._certs.get(handle)
                if cert is not None and self._certificate_current(cert):
                    continue
                v = self.certify(target, mode='L0')
                if v['status'] == 'certified' and typed(v['unit']) == typed(self._published.get(target)):
                    self._published_handles[target] = v['certificate']
                    self._confirmed.pop(target, None)          # confirmation never carried over
                    self.metrics['reissued_publications'] += 1
                else:
                    self._published_handles.pop(target, None)
                    self._published.pop(target, None)
                    self._confirmed.pop(target, None)
                    self.metrics['revoked_publications'] += 1

    def _gc(self):
        if self.cert_gc:
            live = set(self._published_handles.values())
            for h in list(self._certs):
                if h in live:
                    continue
                if not self._certificate_current(self._certs[h]):
                    del self._certs[h]
                    self.metrics['certs_collected'] += 1

    def _expire_publications(self):
        # eager reissue keeps publications current after each admission; reissue='lazy'
        # (X20 organisation 2) keeps the old certificate until the next observation
        # (published/confirmed/publish/confirm), then recertifies before expiring.
        if self.reissue == 'lazy' and not getattr(self, '_in_lazy', False):
            self._in_lazy = True
            try:
                self._reissue_stale()
            finally:
                self._in_lazy = False
        super()._expire_publications()
