"""N01/N02/N05/D05: bounds, distinguishability and oracle independence (WP-B)."""
import copy
import itertools
import random

import paths  # noqa: F401
from common import ref, unit_of, base_case, random_case, roundtrip
import transducer as T
import omega as O
import theory_a as A
import generative as G


# ------------------------------------------------------------------ N01
def chain_dependency(n, target, seed=0):
    """For a G0-realised decreasing chain: on which edges e < target does the
    target unit depend (single-edge change within G0 flips the unit)?
    Every such edge belongs to EVERY certificate for target (two realisable
    worlds agreeing elsewhere with different units)."""
    ranks = [round((n - j) * 0.5, 2) for j in range(n - 1)]
    widths = [4] * n
    tens, L, R = G.realise_chain(ranks, widths, h=60, seed=seed)
    base = G.derive_ranks(tens, widths, h=60)
    plan = ref.complete_plan(A.chain_case(n, base))
    u0 = unit_of(plan, target)
    dep = []
    for e in range(0, target + 2):
        if e >= n - 1:
            break
        hit = False
        for v in (0.02, 29.98, None, round((ranks[e] + (ranks[e - 1] if e > 0 else 29.98)) / 2, 2) + 0.02):
            alt = list(ranks)
            alt[e] = v
            t2, _, _ = G.realise_chain(alt, widths, h=60, seed=seed)
            r2 = G.derive_ranks(t2, widths, h=60)
            if unit_of(ref.complete_plan(A.chain_case(n, r2)), target) != u0:
                hit = True
                break
        if hit:
            dep.append(e)
    return dict(n=n, target=target, dependent_edges=dep, count=len(dep))


# ------------------------------------------------------------------ N02
def boundary_classes(case, b, domain='ext', alpha=False):
    """Exact frontier keys at boundary b and the number of distinct FUTURE
    behaviours (for every target t >= b, the set of target units reachable from
    the key).  Distinct behaviours = keys no exact summary may merge."""
    F = T.Facts(case, 'omega', domain, alpha)
    ctx = T.Ctx(F)
    frontier = {(T.S0, frozenset())}
    for i in range(0, b):
        nxt = set()
        for s, asg in frontier:
            for (ns, _u), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=False), dict(asg)):
                nxt.add((ns, frozenset(O._prune(a, i).items())))
        frontier = nxt
    sig = {}
    n = F.n
    for key in frontier:
        beh = []
        for t in range(b, n):
            units = set()
            fr = {key}
            for i in range(b, t + 1):
                include = i >= t - 1
                nxt = set()
                for s, asg in fr:
                    if s >> 1 == T.SKIP and i == t:
                        continue
                    for (ns, unit), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(asg)):
                        if include and unit is not None and any(sl['item'] == t for sl in unit['slots']):
                            units.add(T._key(unit))
                        elif i < t:
                            nxt.add((ns, frozenset(O._prune(a, i).items())))
                fr = nxt
            beh.append(frozenset(units))
        sig[key] = tuple(beh)
    return len(frontier), len(set(sig.values())), len({k[0] for k in frontier})


# ------------------------------------------------------------------ D05
def width_profile(case, domain='ext', alpha=False):
    """Max live (bound) variables per boundary key, max rank-constraint component
    (edges), and max frontier size along an exact DP over all positions."""
    F = T.Facts(case, 'omega', domain, alpha)
    ctx = T.Ctx(F)
    frontier = {(T.S0, frozenset())}
    mx_vars = mx_comp = mx_front = 0
    for i in range(F.n):
        nxt = set()
        for s, asg in frontier:
            for (ns, _u), a in T.explore(ctx, lambda: T.step_result(ctx, i, s, include=False), dict(asg)):
                key = frozenset(O._prune(a, i).items())
                nxt.add((ns, key))
                edges = {t[1] for k, _v in key if k[0] == 'lt' for t in k[1:] if t[0] == 'e'}
                mx_comp = max(mx_comp, len(edges))
                mx_vars = max(mx_vars, sum(1 for k, _v in key if k[0] != 'lt'))
        frontier = nxt
        mx_front = max(mx_front, len(frontier))
    return dict(max_live_vars=mx_vars, max_rank_component_edges=mx_comp, max_frontier=mx_front)


# ------------------------------------------------------------------ N05
def oracle_independence(cases=60, seed=9):
    """Shared-code mutant (omega._prune keeps one position too few) vs two oracles:
    O1 implementation differential (BlockSummary vs certify_exact, both use
    _prune) and O2 independent world enumeration + reference.complete_plan."""
    import wpB_blocks as WB
    rng = random.Random(seed)
    orig = T.Ctx.choose

    def bad_choose(self, key, options):            # shared-code mutant: never branches on side labels
        if key[0] == 'sd':
            options = options[:1]
        return orig(self, key, options)
    T.Ctx.choose = bad_choose
    o1 = o2 = active = 0
    try:
        for _ in range(cases):
            n = rng.randrange(3, 7)
            c = roundtrip(random_case(rng, n, p_unknown=0.4, p_edge_unknown=0.3))
            for t in range(n):
                a = O.certify_exact(c, t, 'ext', True)
                b = WB.BlockSummary(copy.deepcopy(c), 'ext', True, block=2).certify(t)
                try:
                    U = O.oracle_units(c, t, 'ext', True, cap=20000)
                except OverflowError:
                    continue
                wrong = (a[0] == 'certified' and set(U) != {T._key(a[1])})
                missed = (a[0] != 'certified' and len(U) == 1)
                if wrong or missed:
                    active += 1
                    o2 += 1
                    if (a[0] == 'certified') != (b[0] == 'certified') or (a[0] == 'certified' and a[1] != b[1]):
                        o1 += 1
    finally:
        T.Ctx.choose = orig
    return dict(mutant='Ctx.choose drops side-label branches (shared by DP and block summary)',
                mutant_active_cases=active, caught_by_independent_world_oracle=o2,
                caught_by_shared_code_differential=o1)
