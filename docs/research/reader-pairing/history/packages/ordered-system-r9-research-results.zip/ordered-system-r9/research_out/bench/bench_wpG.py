"""WP-G D3 registration (run only through bench/drive_formal.py in the main session).

Families (FAMILY_CANDIDATES picks the comparable set; [0] = incumbent):
  owner_*      corrected Owner vs L0 variants (fact/proj support, posrev barrier, no-op
               detection off, instrumentation off) on frozen owner traces; ok = outputs equal
               the frozen reference strategy verdicts (precomputed once per scenario).
  coupled_*    raw-witness order/eviction (K01) and atomic reissue (G05) inside the coupled
               runner (L1 acquisition semantics); ok = no wrong publication.
  retention_*  memo retention at equal measured space (K02/K03); ok = outputs identical.
  operator_*   D_src score: OPTIMIZED_OPERATOR vs LUT-fused (L03); ok = identical outputs.
  compose_*    5-state transition composition representations (L01); ok = identical.
  view_*       snapshot deepcopy vs clone-free versioned view (L05); ok = identical reads.
"""
import hashlib
import importlib.util
import json
import random
import sys
import time
import tracemalloc
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
import paths  # noqa: E402,F401
import wpG_traces as TR  # noqa: E402
import wpG_owner as GO  # noqa: E402
import wpG_coupled as GC  # noqa: E402
import wpG_retention as RT  # noqa: E402
import wpG_repr as RP  # noqa: E402
import workloads as W  # noqa: E402
from corrected_owner import Owner  # noqa: E402
from common import random_case, roundtrip  # noqa: E402


def digest(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


OWNER_C = ['incumbent', 'fact_support', 'proj_support', 'posrev', 'proj_posrev', 'noop_none', 'no_instrument']
COUPLED_C = ['lru', 'useless', 'derive', 'both', 'reissue', 'proj_reissue']
RET_C = ['lru4', 'bytes', 'gds_steps', 'gds_clock']
OP_C = ['optimized', 'lut_fused']
COMP_C = ['tuple', 'straight', 'bytes_translate', 'packed_int']
VIEW_C = ['snapshot', 'view']
CANDIDATES = OWNER_C

SCENARIOS = []
for mix in ('refresh', 'dependent', 'unrelated', 'churn', 'quiet'):
    for n in (64, 256):
        SCENARIOS.append(dict(name=f'owner_{mix}_n{n}', family='owner', mix=mix, n=n, chain=False))
SCENARIOS.append(dict(name='owner_chain_dependent_n64', family='owner', mix='dependent', n=64, chain=True))
SCENARIOS.append(dict(name='owner_churn_same60_n64', family='owner', mix='churn', n=64, chain=False, same=0.6))
for fam, kw, rc in (('RP', dict(pa=0.3, pe=0.2), 2), ('RP', dict(pa=0.6, pe=0.3), 2), ('RP', dict(pa=0.3, pe=0.2), 3),
                    ('W06', {}, 1), ('W02', {}, 2)):
    SCENARIOS.append(dict(name=f"coupled_{fam}{kw.get('pa', '')}_rc{rc}", family='coupled', wfam=fam, kw=kw, rc=rc))
SCENARIOS.append(dict(name='retention_skewed', family='retention'))
SCENARIOS.append(dict(name='operator_mixed600', family='operator'))
SCENARIOS.append(dict(name='compose_20000', family='compose'))
for n in (64, 1024):
    SCENARIOS.append(dict(name=f'view_n{n}', family='view', n=n))


def FAMILY_CANDIDATES(sc):
    return {'owner': OWNER_C, 'coupled': COUPLED_C, 'retention': RET_C, 'operator': OP_C,
            'compose': COMP_C, 'view': VIEW_C}[sc['family']]


_cache = {}


def _owner_trace(sc):
    k = sc['name']
    if k not in _cache:
        tr = TR.generate(17, n=sc['n'], rounds=100 if sc['n'] == 64 else 60, mix=sc['mix'], chain=sc['chain'],
                         same_rate=sc.get('same', 0.0))
        _cache[k] = (tr, digest(TR.truth(tr)))
    return _cache[k]


def _coupled_traces(sc):
    k = sc['name']
    if k not in _cache:
        trs = []
        for seed in range(4):
            if sc['wfam'] == 'RP':
                trs.append(W.random_partial(seed, n=32, pattern='roundtrip', count=32, **sc['kw']))
            elif sc['wfam'] == 'W06':
                trs.append(W.w06_complete_analysis_ambiguous(seed, n=16, count=16))
            else:
                trs.append(W.w02_islands(seed))
        _cache[k] = trs
    return _cache[k]


def _opt():
    if 'opt' not in _cache:
        spec = importlib.util.spec_from_file_location('opt', str(Path(paths.ROOT) / 'OPTIMIZED_OPERATOR.py'))
        m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        rng = random.Random(3)
        pairs = []
        for k in range(600):
            a = [(rng.randrange(256) << 24) | rng.randrange(1 << 24) for _ in range(50)]
            b = list(a) if k % 3 == 0 else [(rng.randrange(256) << 24) | rng.randrange(1 << 24) for _ in range(50)]
            if k % 3 == 0:
                for j in rng.sample(range(50), 5):
                    b[j] = (b[j] & 0xff00ffff) | (rng.randrange(256) << 16)
            pairs.append((a, b))
        _cache['opt'] = (m, pairs)
    return _cache['opt']


def run_one(sc, cand, rep):
    fam = sc['family']
    if fam == 'owner':
        tr, want = _owner_trace(sc)
        t0 = time.perf_counter_ns()
        o = GO.make(cand, tr['initial'])
        out = TR.replay(tr, o)
        wall = time.perf_counter_ns() - t0
        h = digest(out)
        m = o.metrics
        return dict(wall_ns=wall, verdict_sha256=h, ok=h == want,
                    work={k: m[k] for k in ('engine_runs', 'scan_steps', 'support_validations', 'typed_reads_checked',
                                            'stamp_hits', 'posrev_hits', 'support_keys_built', 'memo_hits')})
    if fam == 'coupled':
        kw = {'lru': {}, 'useless': dict(raw_policy='useless_first'), 'derive': dict(order='derive_first'),
              'both': dict(raw_policy='useless_first', order='derive_first'), 'reissue': dict(reissue=True),
              'proj_reissue': dict(reissue=True, owner_factory=lambda c: GO.GOwner(c, support='proj'))}[cand]
        t0 = time.perf_counter_ns()
        res = [GC.run(tr, kw, raw_capacity=sc['rc'], horizon=3000) for tr in _coupled_traces(sc)]
        wall = time.perf_counter_ns() - t0
        agg = {k: sum(r[k] for r in res) for k in ('physical_admissions', 'total_latency_u', 'published', 'intents',
                                                   'wrong', 'rank_computations', 'raw_evictions', 'horizon_hit',
                                                   'published_now', 'reissued')}
        return dict(wall_ns=wall, verdict_sha256=digest([(r['published'], r['latency_u']) for r in res]),
                    ok=agg['wrong'] == 0, work=agg)
    if fam == 'retention':
        if 'ret' not in _cache:
            rng = random.Random(0)
            n = 96
            c = TR._case(rng, n, chain=True, p_unknown=0.0, p_edge_unknown=0.0)
            for it in c['items'][::7]:
                it['analysis'] = {'status': 'unknown'}
            seq = []
            for r in range(150):
                seq += [n - 1 - (r % 3) * 9, rng.randrange(0, 12), rng.randrange(0, 12)]
            tr = dict(initial=c, ops=[['req', t] for t in seq])
            o = Owner(c); want = digest(TR.replay(tr, o))
            _cache['ret'] = (tr, want, int(4 * 1186 * 30))
        tr, want, budget = _cache['ret']
        kw = {'lru4': dict(policy='lru'), 'bytes': dict(policy='bytes', byte_budget=budget),
              'gds_steps': dict(policy='gds', byte_budget=budget, estimator='steps'),
              'gds_clock': dict(policy='gds', byte_budget=budget, estimator='clock', sample=4)}[cand]
        t0 = time.perf_counter_ns()
        o = RT.ROwner(tr['initial'], bytes_per_key=1186, **kw)
        out = TR.replay(tr, o)
        wall = time.perf_counter_ns() - t0
        h = digest(out)
        return dict(wall_ns=wall, verdict_sha256=h, ok=h == want,
                    work={k: o.metrics[k] for k in ('engine_runs', 'scan_steps', 'memo_hits', 'memo_evictions', 'clock_samples')})
    if fam == 'operator':
        m, pairs = _opt()
        fn = m.score if cand == 'optimized' else RP.score_lut
        t0 = time.perf_counter_ns()
        out = [fn(a, b) for a, b in pairs]
        wall = time.perf_counter_ns() - t0
        want = digest([m.score(a, b) for a, b in pairs]) if 'opt_want' not in _cache else _cache['opt_want']
        _cache['opt_want'] = want
        h = digest(out)
        return dict(wall_ns=wall, verdict_sha256=h, ok=h == want, work=dict(pairs=len(pairs), nulls=sum(x is None for x in out)))
    if fam == 'compose':
        if 'comp' not in _cache:
            rng = random.Random(1)
            fs = RP.all_functions()
            pairs = [(rng.choice(fs), rng.choice(fs)) for _ in range(20000)]
            _cache['comp'] = (pairs, [(RP.as_bytes(f), RP.as_bytes(g)) for f, g in pairs],
                              [(RP.pack(f), RP.pack(g)) for f, g in pairs], digest([RP.compose_tuple(f, g) for f, g in pairs]))
        pairs, bp, pp, want = _cache['comp']
        t0 = time.perf_counter_ns()
        if cand == 'tuple':
            out = [RP.compose_tuple(f, g) for f, g in pairs]
        elif cand == 'straight':
            out = [RP.compose_straight(f, g) for f, g in pairs]
        elif cand == 'bytes_translate':
            out = [f.translate(g) for f, g in bp]
        else:
            out = [RP.compose_packed(a, b) for a, b in pp]
        wall = time.perf_counter_ns() - t0
        norm = [tuple(x[:5]) if isinstance(x, bytes) else (RP.unpack(x) if isinstance(x, int) else x) for x in out]
        h = digest(norm)
        return dict(wall_ns=wall, verdict_sha256=h, ok=h == want, work=dict(pairs=len(pairs)))
    if fam == 'view':
        k = 'view%d' % sc['n']
        if k not in _cache:
            rng = random.Random(sc['n'])
            _cache[k] = Owner(roundtrip(random_case(rng, sc['n'], settings_mix=False)))
        o = _cache[k]
        t0 = time.perf_counter_ns()
        if cand == 'snapshot':
            s = o.snapshot()
            from current_baseline import typed  # noqa
            import compact_core as core
            idx = core.Index(s, check_ids=False)
            out = [idx.analysis(i) for i in range(16)]
        else:
            v = RP.OwnerView(o)
            out = [v.analysis(i) for i in range(16)]
        wall = time.perf_counter_ns() - t0
        return dict(wall_ns=wall, verdict_sha256=digest(out), ok=True, work=dict(reads=16))
    raise ValueError(fam)
