"""A1 / A5 / E3 / E4 executable theory checks (complete-information semantics).

A1  entry-state equivalence: which of the 5 cursor modes are separated by some
    legal suffix, and how long the shortest separating suffix is; constructive
    unbounded-separation family (decreasing-rank chain).
A5  order compression: the plan depends on ranks only through null-ness and
    the strict order of each adjacent edge pair.
E3  label-swap equivariance of the rule (direction AB<->BA with A<->B sides),
    reversal non-equivariance counterexample.
E4  numeric interface boundaries (Python int vs IEEE double, signed zero,
    subnormals, extremes) with strict JSON round trips.
"""
import copy
import itertools
import json
import math
import random

from common import ref, base_case, fact, unit_of, roundtrip, random_case
import transducer as T

MODES = ('at(open,free)', 'at(open,res)', 'at(closed,free)', 'at(closed,res)', 'skip')


# ----------------------------------------------------------------------- A1
def suffix_units(case, b, mode):
    """Units emitted at positions >= b when the scan enters boundary b in `mode`."""
    F = T.Facts(case, 'complete')
    ctx = T.Ctx(F)
    s = T.enc(mode, 0)
    out = []
    i = b
    while i < F.n:
        ctx.asg = {}
        nxt, unit = T.step_result(ctx, i, s, include=True)
        if s >> 1 != T.SKIP:
            out.append(T._key(unit))
        s = nxt
        i += 1
    return tuple(out)


def chain_case(n, ranks, automatic=True, direction='AB'):
    c = base_case(n, automatic=automatic, direction=direction)
    for e, r in zip(c['edges'], ranks):
        e['score'] = r
    return c


def decreasing_chain(n):
    return chain_case(n, [float(n - j) for j in range(n - 1)])


def separation_table(max_len=7, b=2, seed=0, samples=400):
    """Shortest suffix length (positions after b) separating each mode pair,
    searched over random complete inputs (W02/W03 families)."""
    rng = random.Random(seed)
    best = {}
    for L in range(1, max_len + 1):
        for _ in range(samples):
            c = random_case(rng, b + L, p_wide=0.25, automatic=True, settings_mix=False)
            for x, y in itertools.combinations(range(5), 2):
                if (x, y) in best:
                    continue
                if suffix_units(c, b, x) != suffix_units(c, b, y):
                    best[(x, y)] = (L, c)
    return best


def unbounded_separation(n_values=(8, 16, 32, 64, 128)):
    """Decreasing-rank chain: at(closed,free) vs skip disagree on every later
    position, for every n (no fixed-radius state)."""
    rows = []
    for n in n_values:
        c = decreasing_chain(n)
        u2 = suffix_units(c, 1, 2)
        u4 = suffix_units(c, 1, 4)
        # count positions covered differently
        def cover(units, start):
            m = {}
            for key in units:
                items = [s[0] for s in key[0]]
                for it in items:
                    m[it] = tuple(items)
            return m
        a, bb = cover(u2, 1), cover(u4, 1)
        diff = sum(1 for k in set(a) & set(bb) if a[k] != bb[k])
        last = max((k for k in set(a) & set(bb) if a[k] != bb[k]), default=None)
        rows.append(dict(n=n, differing_positions=diff, last_differing=last))
    return rows


def reference_lookback_cost(n_values=(8, 16, 32, 64, 128, 256)):
    """How far reference.certify must look back (first) on the chain family."""
    rows = []
    for n in n_values:
        c = decreasing_chain(n)
        t = n - 1
        r = ref.certify(c, t)
        rows.append(dict(n=n, target=t, status=r['status'], first=r['first'], steps=r['steps'],
                         reads=len(r['reads'])))
    return rows


# ----------------------------------------------------------------------- A5
def order_signature(case):
    """(null flags of every edge, strict-order bit of every adjacent edge pair)
    computed with the reference's own edge semantics."""
    data = ref._Input(case)
    n = len(data.items)
    vals = []
    for a in range(n - 1):
        e = data.edge(a, a + 1)
        vals.append(e.get('score') if e['status'] == 'computed' else None)
    bits = tuple((vals[i + 1] is not None and (vals[i] is None or vals[i + 1] < vals[i]))
                 for i in range(n - 2))
    return tuple(v is None for v in vals), bits


def compress_ranks(case):
    """Replace every computed score by a small integer code preserving the
    strict order of each adjacent pair and null-ness (dense ranks are
    sufficient but not necessary; this uses a per-chain monotone recoding)."""
    c = copy.deepcopy(case)
    recs = {(e['first'], e['second']): e for e in c.get('edges', [])}
    scores = sorted({e['score'] for e in recs.values()
                     if e.get('status') == 'computed' and e.get('score') is not None})
    code = {}
    for s in scores:                     # equal values share a code (Python equality)
        if not any(s == k for k in code):
            code[s] = len(code)
    for e in recs.values():
        if e.get('status') == 'computed' and e.get('score') is not None:
            e['score'] = next(v for k, v in code.items() if k == e['score'])
    return c


# ----------------------------------------------------------------------- E3
def swap_sides(case):
    c = copy.deepcopy(case)
    sw = {'A': 'B', 'B': 'A'}
    for it in c['items']:
        for k in ('header',):
            if it.get(k):
                it[k]['side'] = sw.get(it[k].get('side', 'UNKNOWN'), it[k].get('side', 'UNKNOWN'))
        a = it.get('analysis', {})
        if a.get('status') == 'computed':
            a['fact']['side'] = sw.get(a['fact'].get('side', 'UNKNOWN'), a['fact'].get('side', 'UNKNOWN'))
    s = c['settings']
    s['direction'] = 'BA' if s.get('direction', 'AB') == 'AB' else 'AB'
    return c


def swap_unit_labels(units):
    sw = {'A': 'B', 'B': 'A'}
    out = copy.deepcopy(units)
    for u in out:
        for sl in u['slots']:
            sl['slot'] = sw.get(sl['slot'], sl['slot'])
    return out


def reversed_case(case):
    c = copy.deepcopy(case)
    n = len(c['items'])
    c['items'] = list(reversed(c['items']))
    c['edges'] = [dict(e, first=n - 1 - e['second'], second=n - 1 - e['first']) for e in c.get('edges', [])]
    s = c['settings']
    s['hard_isolates'] = [n - 1 - i for i in s.get('hard_isolates', [])]
    s['pinned_links'] = [n - 2 - i for i in s.get('pinned_links', [])]
    return c


# ----------------------------------------------------------------------- E4
def e4_cases():
    """Concrete numeric boundary cases; each returns (label, case, note).
    Without sides allowed(0) is False, so the decisive comparison is
    edge(2,3) < edge(1,2) at position 1."""
    out = []
    big_int, big_float = 9007199254740993, 9007199254740992.0
    out.append(('int_vs_double', chain_case(5, [1.0, big_int, big_float, 1.0]),
                'Python: 2**53 (double) < 2**53+1 (int) is True; a double-only reader sees equal values'))
    out.append(('int_vs_double_1e17', chain_case(5, [1.0, 100000000000000002, 1e17, 1.0]),
                'int 1e17+2 survives JSON in Python only; as doubles both are 1e17 (N03/N04)'))
    out.append(('signed_zero', chain_case(5, [1.0, 0.0, -0.0, 1.0]), '-0.0 < 0.0 is False in Python and IEEE'))
    out.append(('subnormal', chain_case(5, [1.0, 5e-324, 0.0, 1.0]), '0.0 < 5e-324 is True'))
    out.append(('extremes', chain_case(5, [1.0, -1.7976931348623157e308, -1.7976931348623157e308, 0.0]),
                'equal finite extremes: strict < is False; nothing representable below -DBL_MAX'))
    return out


def as_double_interface(case):
    """What a double-only consumer would read after JSON transport."""
    c = copy.deepcopy(case)
    for e in c.get('edges', []):
        if isinstance(e.get('score'), int) and not isinstance(e.get('score'), bool):
            e['score'] = float(e['score'])
    return c
