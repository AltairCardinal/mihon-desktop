"""Executable adoption boundary for gated_shadow: proof wins exist iff q_u < service_u.
-> results/summary/wpA/boundary.json"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import wpA_lib as A
ROOT = Path(__file__).resolve().parents[1]
traces = A.tuning_traces() + A.heldout_traces() + A.heldout2_traces()
cells = []
for su in (2, 3, 4, 8):
    for q in (1, 2, 3, 4, 6, 8, 9):
        wins = lane = gain = 0
        for tr in traces:
            inc = A.make_runner(tr, 'incumbent', service_u=su, q_u=q).run(max_steps=20000)
            r = A.make_runner(tr, 'gated_shadow', service_u=su, q_u=q).run(max_steps=20000)
            wins += r['proof_wins']; lane += r['lane_busy_u']; gain += inc['total_latency_u'] - r['total_latency_u']
        cells.append(dict(service_u=su, q_u=q, proof_wins=wins, lane_busy_u=lane, latency_gain_u=gain,
                          predicted_adopt=A.shadow_boundary(q, su), consistent=(wins > 0) == A.shadow_boundary(q, su)))
out = dict(traces=len(traces), rule='adopt proof lane iff q_u < service_u', cells=cells,
           all_consistent=all(c['consistent'] for c in cells))
(ROOT / 'results/summary/wpA/boundary.json').write_text(json.dumps(out, indent=1))
for c in cells: print(c)
print('all_consistent', out['all_consistent'])
