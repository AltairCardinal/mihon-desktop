"""Writes coverage_parts/wpH.csv, hypotheses_parts/wpH.csv, adoption_parts/wpH.csv (content authored from
results/raw/wpH/*; every number below appears in a raw/summary file)."""
import csv
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT.parent
T = "python3 -m unittest discover -s research_out/tests -t research_out -p 'test_wpH*.py'"
ANCH = 'PRIOR_EVIDENCE_MAP.md; ALGORITHM_FRONTIER.md; COST_EVIDENCE.md'


def fp(*names):
    h = hashlib.sha256()
    for n in names:
        h.update((ROOT / 'candidates' / n).read_bytes())
    return h.hexdigest()[:16]


titles = {}
for r in csv.DictReader(open(PKG / 'coverage-template.csv', encoding='utf-8')):
    titles[r['question_id']] = (r['title'], r['family'])

C, S, RB, CB, X = 'wpH_commit.py', 'wpH_sched.py', 'wpH_robust.py', 'wpH_combos.py', 'wpH_extra.py'
EC, ESF, D4, RN = 'wpH_exp_commit.py', 'wpH_exp_sched.py', 'wpH_d4.py', 'wpH_runner.py'
rows = [
 # id, new_gap, route_a, route_b, status, depth, impl, proof/cex, raw, files, domain, cost_layer, assumptions, refutation, decision, remaining
 ('H01', 'where does certificate commit linearise; is support+guard check sufficient and necessary',
  'exhaustive interleavings certify -> one write -> publish on real Session (1590)', 'deductive replay lemma (proofs L1) + critical-section cost (support reads vs proof steps)',
  'implemented_verified', 'D3', 'Session commit check (incumbent); mutants guard-only / own-items-only',
  'Session 0 violations (1153 published, 437 stale); guard-only 122, own-items-only 46 wrong; commit reads mean 8.53 vs proof 6.48 steps',
  'results/raw/wpH/commit.json#H01', (C, EC), 'Session/Owner L0', 'coupled', 'deterministic certifier, all-attempt union support',
  'any interleaving where the commit check passes and the unit differs from recertification', 'keep commit check as linearisation point; proof outside critical section', 'no native concurrency'),
 ('H02', 'can multi-target publications be composed locally without cross-world views',
  'randomised search for cross-world pair (found t1 unit (0,1), t2 [0] WIDE)', 'minimal revalidation lemma L2 (support ∩ dirty ≠ ∅ or guard change) + IncSession differential',
  'implemented_verified', 'D3', 'Session._expire_publications; IncSession (H03)', 'no-revalidation mutant publishes two inconsistent overlapping units; Session and IncSession consistent',
  'results/raw/wpH/commit.json#H02', (C, EC), 'Session L0', 'coupled', 'publications validated on read/publish',
  'a revalidation subset strictly smaller than L2 that is always safe', 'local composition is safe only with L2 revalidation', 'joint multi-target commit not adopted (H06)'),
 ('H03', 'incremental revocation of the publication table',
  'differential IncSession vs Session: 1800 random steps, 0 view mismatches, read checks 67966->5484', 'D4 coupled held-out (10 runs RP/W01/W02/W06 seeds 100+) with churn, rebind, confirm, cancel: identical publications/confirmations/latency, read checks 128092->18936',
  'implemented_verified', 'D4', 'IncSession (wpH_commit.py), reverse index support-key->handles', 'proofs L2; test_h03 + test_incremental_heldout_equals_full',
  'results/raw/wpH/commit.json#H03; results/raw/wpH/d4.json#incremental', (C, EC, D4, RN), 'Session L0/L1 strong', 'coupled+local_measured', 'dirty keys collected from owner.apply arguments; settings/identity => full check',
  'any view mismatch vs full revalidation', 'adopt (gate_inc_revoke)', 'formal timing in main session (bench_wpH revoke)'),
 ('H04', 'candidate/commit/confirm: is confirmation bound to the publication instance',
  'targeted counterexample on package Session.confirm(target)', 'D4 held-out late callbacks: package 16/35 confirmations via expired callbacks (7/10 runs); bound 0',
  'implemented_verified', 'D4', 'BoundConfirmSession.confirm(target, handle)', 'package confirms re-issued publication of an equal unit (confirmed_new_context=True); bound -> stale_callback',
  'results/raw/wpH/commit.json#H04; results/raw/wpH/d4.json#bound_confirm', (C, EC, D4, RN), 'Session', 'coupled', 'callback carries the handle it observed',
  'a bound confirm rejecting a caller holding the current handle', 'adopt (interface change: confirm takes handle)', 'none'),
 ('H05', 'value-keyed work reuse vs identity-keyed authority',
  'coupled RunnerH fresh vs carry rebinds (adm 220->53, latency 700->193 fresh; carry latency 3->3)', 'ABA + label-reuse counterexample + D4 held-out (10 runs, 2 knowledge-losing rebinds each): adm 417->115, latency 937->138, 0 wrong, 0 old-epoch certificates',
  'implemented_verified', 'D4', 'ValueCacheSession (key = typed identity + version)', 'label reuse with different content serves stale value (producer precondition); authority never cached',
  'results/raw/wpH/commit.json#H05; results/raw/wpH/d4.json#value_cache', (C, EC, D4), 'Session', 'coupled', 'producer contract: equal (identity, version) => equal content',
  'a wrong publication with the contract intact', 'adopt when rebinds lose knowledge (gate_value_cache)', 'contract cannot be checked by the cache'),
 ('H06', 'local correctness vs global liveness under churn',
  'event model: per-target vs joint commit windows q in {1,3,6}, churn period {1,2,4,8}', 'analytic liveness window (proofs L5: geometric per support vs union)',
  'limit_proved', 'D2', 'per-target commit (incumbent Session)', 'joint 0/8 published in 400u (q=3 p=1; q=6 p=1,2,4) while per-target 8/8',
  'results/raw/wpH/commit.json#H06', (EC,), 'Session L0', 'simulated', 'independent uniform churn', 'joint commit live where per-target starves', 'keep per-target commits', 'no coupled D4 run'),
 ('I01', 'critical-path-aware admission', 'Sim C=1/2/4 fifo/required_first/critical/smith', 'minimal counterexample: fifo & critical 31 vs smith 23 (bound-aware ordering)',
  'conditional', 'D2', 'wpH_sched.Sim order=smith (declared bounds)', 'required_total C=1: fifo 3104, smith 2805; C=2 smith 1137 vs required_first 1082 (no win)',
  'results/raw/wpH/sched.json#I01', (S, ESF), 'simulator', 'simulated', 'honest declared bounds', 'smith worse than fifo at C=1', 'conditional: only with declared bounds and C=1', 'coupled run'),
 ('I02', 'dynamic reservation of slots', 'Sim burst workload C=1..3 fixed/dyn_b10/dyn_b20 + cancel-releases mutant', 'bound lemma L6 + coupled ReservingSession D4 held-out',
  'conditional', 'D4', 'Sim reserve/dyn_reserve_bound; ReservingSession', 'C=1 fixed: required max 9 but 0/36 optional (starvation); dyn_b10 9 with 7 served; mutant max_physical 2>C; D4 coupled: latency 113->112, 1 better 1 worse (no gain)',
  'results/raw/wpH/sched.json#I02; results/raw/wpH/d4.json#reservation', (S, ESF, RN, D4), 'simulator+Session', 'simulated+coupled', 'honest bounds; nonpreemptible cancel',
  'required delay > fixed + B', 'adopt only when optional services exceed required tolerance (gate_reserve)', 'none'),
 ('I03', 'negative externality of shared multi-consumer tasks', 'Sim fan-out grid (108 rows) wait vs bounded bypass', 'X16 failure variant (shared first attempt fails)',
  'implemented_verified', 'D2', 'Sim any_of bypass_b8', 'fan 6 slow 60: wait 2712 vs bypass 619; bypass = wait at slow 5, = always_both at slow>=20',
  'results/raw/wpH/sched.json#I03', (S, ESF), 'simulator', 'simulated', 'declared remaining bound', 'bypass worse than wait in latency', 'bounded bypass (B=8)', 'never saves work'),
 ('I04', 'optimal phase split', 'analytic work/hop table', 'queueing DES (72 configs): split wins needed-job latency iff p<1 and rho_joint>=1.25; loses at rho<=0.75 or p=1',
  'implemented_verified', 'D3', 'wpH_extra.split_des; gate_split', 'split work always lower for p<1; latency gain only under overload', 'results/raw/wpH/sched.json#I04; results/raw/wpH/extra.json#I04_des',
  (ESF, X, 'wpH_adopt.py'), 'simulator', 'simulated', 'FIFO, keyed need flags', 'split wins at rho<1 or loses at rho>1 with p<1', 'gate_split', 'rho in (0.75,1.25) untested'),
 ('I05', 'dynamic micro-batching and first result', 'Sim immediate vs batch per-item vs barrier, max_wait', 'X24 with aging; bench microbatch family',
  'implemented_verified', 'D3', 'Sim batch(per_item)', 'immediate 1926, per-item 940, barrier 1144; max_wait raises latency (994/1194)',
  'results/raw/wpH/sched.json#I05', (S, ESF), 'simulator', 'simulated', 'setup 4u per dispatch', 'barrier beats per-item', 'per-item completion, no max_wait', 'coupled batching absent in Session'),
 ('I06', 'backpressure of completed-unconsumed results', 'Sim serial consumer with result buffer None/2/8/inf', 'memory-bound argument: unbounded buffer throughput gain = 0 at delay 2 while max_buffer 21',
  'implemented_verified', 'D2', 'Sim result_buffer', 'delay1: buffer2 407->160; delay2: no gain, unbounded buffer grows to 21', 'results/raw/wpH/sched.json#I06', (S, ESF), 'simulator', 'simulated', 'serial consumer',
  'unbounded buffer improves throughput at consumer saturation', 'small bounded buffer (2)', 'none'),
 ('J01', 'speculative admission under low-confidence prediction', 'Sim patterns forward/zigzag/drift/jump, policies none/idle_only/lowerbound_gate', 'X23 combination with reservation (C=2)',
  'implemented_verified', 'D3', 'lowerbound_gate (accuracy window)', 'forward 1378->923, zigzag 1220->828, drift 1045->808, jump 1112 (no spec) vs idle_only 1154',
  'results/raw/wpH/sched.json#J01', (S, ESF), 'simulator', 'simulated', 'retain=6', 'gate worse than none on jump', 'gate on recent accuracy', 'coupled'),
 ('J02', 'stop rule for nonpreemptible speculation', 'Sim queued_only/coop_exit/revive', 'phantom-completion regression (exiting instance cannot be revived)',
  'implemented_verified', 'D2', 'coop_exit + phase_len', 'queued_only required 29 wasted 30; coop phase 2/5/10 required 3/4/9 wasted 4/5/10; revive_only saves a restart but required waits 29',
  'results/raw/wpH/sched.json#J02', (S, ESF), 'simulator', 'simulated', 'declared phase boundaries', 'revive of an exiting task completes early', 'coop exit at phase boundary', 'none'),
 ('J03', 'service curve of aging', 'Sim aging bounds none/100/80/<=60', 'X24 aging inside batching',
  'implemented_verified', 'D2', 'Sim aging', 'none: opt max 125 req max 28; aging 100: 117/82; <=60: 86/91 with total 2233-3112', 'results/raw/wpH/sched.json#J03', (S, ESF), 'simulator', 'simulated', 'C=1',
  'aging improves both maxima', 'aging bound only from an optional-latency SLO', 'none'),
 ('J04', 'debounce only relevant changes', 'event model global vs relevant window', 'analytic liveness argument (proofs L8)',
  'implemented_verified', 'D2', 'relevant_w7', 'unrelated churn: global final wait 63/43 vs relevant 15; slow changes: debounce 15 & 32 wasted vs immediate 8 & 0',
  'results/raw/wpH/sched.json#J04', (ESF,), 'model', 'simulated', 'service 8u, mergeable intermediate versions', 'relevant window starves', 'relevant-only, only when changes are faster than service', 'coupled'),
 ('J05', 'reachability guarantee under sustained overload', 'Sim lambda_req sweep, reject/degrade optional', 'queueing argument: required load >=1 => unbounded required max',
  'limit_proved', 'D2', 'reject optional at queue bound', 'lambda 0.6: required max 60->130 with horizon; unbounded queue hides 543 unserved; reject bounds queue at 90', 'results/raw/wpH/sched.json#J05', (S, ESF),
  'simulator', 'simulated', 'stationary load', 'bounded required max at rho_req>=1', 'no guarantee without rho_req<1', 'none'),
 ('J06', 'cross-target speculation budget borrowing', 'credit arithmetic (global 6 drained by always-wrong hotspot)', 'Sim C=1 two streams: global/isolated/refund (4 seeds)',
  'implemented_verified', 'D3', 'refund_isolated credit', 'global: H spends 5, G 1; refund_isolated G_total 5-9 vs none 59-76, H waste capped at 3 specs',
  'results/raw/wpH/sched.json#J06; results/raw/wpH/extra.json#J06_sim', (ESF, X), 'simulator', 'simulated', 'use observable when later intent needs the witness', 'global >= isolated for G', 'per-requester credit with refund on use', 'H latency rises with speculation (126->135, seed 200)'),
 ('R01', 'atomic multi-fact admission', 'counterexample: identity committed before its evidence', 'Session consume order (analysis then edges) audit + X08',
  'implemented_verified', 'D2', 'Owner.apply atomic batch', 'split intermediate certificate (1,2) A/B wrong vs final [2] WIDE; atomic correct', 'results/raw/wpH/robust.json#R01', (RB,), 'Owner', 'owner', 'certify between writes',
  'atomic batch yields intermediate certificate', 'admit identity+evidence in one apply', 'none'),
 ('R02', 'contradictory knowledge and empty completion sets', 'detectors on crafted cases', 'domain argument (nonneg infeasible x<0; empty set => ambiguous never certified)',
  'implemented_verified', 'D2', 'detect_inconsistency', '3 detectors fire; empty completion => ambiguous', 'results/raw/wpH/robust.json#R02', (RB,), 'core', 'core', 'declared domain', 'certified result on empty set', 'detect then refuse', 'none'),
 ('R03', 'order, duplication, idempotence', 'exhaustive event sequences <=4 (2800)', 'truth table for <=2 events',
  'implemented_verified', 'D2', 'Session task lifecycle', '0 violations', 'results/raw/wpH/robust.json#R03', (RB,), 'Session', 'coupled', 'single item', 'any violation', 'no change', 'longer sequences'),
 ('R04', 'extreme lengths and configs', 'grid 144 configs n=1..3 owner vs reference', 'strong session differential',
  'implemented_verified', 'D2', 'Owner/StrongSession', '0 mismatches; n=0 ValueError invalid target ordinal', 'results/raw/wpH/robust.json#R04', (RB,), 'Owner', 'owner', 'small n', 'mismatch', 'no change', 'large n handled by others'),
 ('R05', 'counter saturation in long runs', 'exhaustive small-width counters wrap/saturate/incarnation', 'induction L9 + real saturated Owner',
  'implemented_verified', 'D3', 'Owner SAT + exact fallback', 'w2 wrap 15 stale hits, w3 255; saturate 0; incarnation 0; saturated owner correct', 'results/raw/wpH/robust.json#R05', (RB,), 'Owner', 'owner', 'monotone counter', 'stale hit with saturation', 'keep saturate+exact', 'none'),
 ('R06', 'pressure and exception recovery', 'fault injection 364 points', 'legal-state argument (analysis admitted, ranks unknown)',
  'implemented_verified', 'D2', 'Session consume', '364 injected, 162 recovered, 0 violations', 'results/raw/wpH/robust.json#R06', (RB,), 'Session', 'coupled', 'exceptions between writes', 'violation', 'no change', 'none'),
 ('N03', 'bounded async protocol to general', 'real-Session BFS depth 6 C=1/2', 'symmetry reduction + generalisation limits (proofs L10)',
  'conditional', 'D2', 'Session', '0 violations; C1 71/46, C2 201/152 states', 'results/raw/wpH/robust.json#N03', (RB,), 'Session', 'coupled', 'trusted incarnation, C<=2',
  'violation at larger bound', 'per-identity invariants generalise; capacity/liveness do not', 'unbounded retry, C>2'),
 ('X07', 'dynamic order x publication revocation', 'move experiment (1494 units)', 'same-value move counterexample',
  'implemented_verified', 'D2', 'groups 0/A(id remap)/B(inc revoke)/AB', '64.9% units identical by id; ordinal 8 changes i8->i9; B adds nothing (global guard change), interaction 0', 'results/raw/wpH/combos.json#X07', (CB,), 'Session', 'coupled',
  'ordinal-keyed support', 'B helps under reorder', 'authority re-signed after moves', 'id-keyed support'),
 ('X08', 'batch update x atomic admission', 'per-item vs atomic batch certificates', 'identity-split variant',
  'implemented_verified', 'D2', 'Owner.apply batch', 'per-item 450 certs, 69 differ from final (0 wrong vs own state); atomic 0; identity split 29/150 wrong', 'results/raw/wpH/combos.json#X08', (CB,), 'Owner', 'owner',
  'intermediate versions observable?', 'atomic batch wrong', 'atomic batch when intermediates non-observable', 'none'),
 ('X16', 'in-flight wait x shared externality', 'I03 grid', 'failure variant of the shared task',
  'implemented_verified', 'D2', 'bypass_b8', 'shared fails: wait 456 vs bypass 98; no failure 216 vs 98 (bypass busier 213 vs 160 busy u)', 'results/raw/wpH/combos.json#X16', (CB, S), 'simulator', 'simulated', 'bound covers one attempt',
  'wait beats bypass', 'bypass bounded', 'work cost'),
 ('X22', 'value reuse x cross-owner re-sign', '0/A/B/AB with fresh rebinds', '0/A/B/AB with carry rebinds',
  'implemented_verified', 'D3', 'MigratingValueSession', 'fresh: adm 205/55/205/55, steps 11281/2793/11114/2123 (I=-503 reinforcing); carry: steps 2077/2077/1136/1136 (I=0)', 'results/raw/wpH/combos.json#X22', (CB, C), 'Session', 'coupled',
  'migration changes public diagnostics => L1', 'wrong publication', 'complementary: value reuse for fresh, migration for carry', 'formal timing'),
 ('X23', 'dynamic reservation x low-confidence speculation', 'Sim C=2, gate (1-step) vs gate3 (3-step) x none/fixed1/dyn5', 'interaction terms per metric',
  'refuted', 'D2', 'Sim reserve + lowerbound gate', '1-step: reservation never binds (I=0); 3-step forward 0/A/B/AB 1721/1721/1356/1452 (I=+96), dyn5 1413 (I=+57); drift I=+60: antagonistic', 'results/raw/wpH/combos.json#X23', (CB, S), 'simulator', 'simulated',
  'short optional services 3..8', 'reservation reduces required latency with speculation', 'do not combine for short speculative work', 'long speculative services'),
 ('X24', 'micro-batch x aging', '0/A/B/AB batch x aging', 'barrier vs per-item organisation',
  'implemented_verified', 'D2', 'per-item batch, aging off', 'required_total 4564/2677/7396/4568 (I=-941); per-item p95 117, aging raises it to 189; barrier max 146 vs 121', 'results/raw/wpH/combos.json#X24', (CB, S), 'simulator', 'simulated', 'C=1 setup 3',
  'aging improves required', 'batch per-item; aging only for optional SLO', 'none'),
 ('X25', 'debounce x negative-evidence cache', 'transient failures f=0/1/3 policies', 'mutant caching transient as permanent',
  'implemented_verified', 'D2', 'reason-keyed backoff', 'mutant never completes; f=1 completion 8/18/10/18 (0/A/B/AB, I=-2); f=3 16/36/28/37 (I=-11)', 'results/raw/wpH/combos.json#X25', (CB,), 'model', 'simulated', 'transient vs permanent reason known',
  'permanent caching of transient failure progresses', 'reason-keyed cache, no debounce on retries', 'none'),
 ('X29', 'protocol induction x revision saturation', 'exhaustive w=2 depth 8 with rebind events', 'induction invariant (proofs L9)',
  'implemented_verified', 'D3', 'saturate+exact / incarnation rebuild', 'wrap 855 stale hits; saturate 0; incarnation 0', 'results/raw/wpH/combos.json#X29', (CB, RB), 'model+Owner', 'owner', 'monotone counters', 'stale hit', 'keep', 'none'),
]

cov_hdr = ['question_id', 'title', 'family', 'prior_anchor', 'new_gap', 'route_a', 'route_b', 'status', 'depth', 'implementation',
           'proof_or_counterexample', 'test_command', 'raw_evidence', 'source_fingerprint', 'domain', 'cost_layer', 'assumptions',
           'refutation_condition', 'decision', 'remaining']


def main():
    with open(ROOT / 'coverage_parts' / 'wpH.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(cov_hdr)
        for (q, gap, ra, rb, st, dp, impl, pc, raw, files, dom, cl, asm, ref, dec, rem) in rows:
            title, fam = titles[q]
            w.writerow([q, title, fam, ANCH, gap, ra, rb, st, dp, impl, pc, T, raw, fp(*files), dom, cl, asm, ref, dec, rem])
    hyp = [
        ('HH1', 'H04 counterexample', 'Q list asks about confirm semantics, not that the package API is unbound',
         'unbound confirm(target) confirms re-issued publications on late callbacks', 'late_confirm events on held-out D4 runs',
         'package 16/35 late callbacks confirmed via an expired publication (7/10 runs); bound 0', 'D4', 'adopt bound confirm'),
        ('HH2', 'H06 + J06', 'cross-target coupling of liveness and of speculation credit is not in QUESTIONS',
         'any shared resource across targets (joint commit window, global credit) lets one bad target starve the others; per-target isolation + refund restores progress',
         'joint vs per-target commit under churn; global vs isolated vs refund credit in Sim',
         'joint 0/8 vs per-target 8/8; global credit G gets 1 of 6; refund_isolated G latency 5-9 vs 59-76', 'D3', 'adopt isolation'),
        ('HH3', 'X22', 'complementarity of value reuse and re-sign migration depends on rebind kind',
         'fresh (knowledge-losing) rebinds favour value reuse; carry rebinds favour migration; interaction sign flips',
         '0/A/B/AB under fresh and carry', 'fresh steps I=-503, carry I=0; adm 205->55 only fresh', 'D3', 'choose by rebind kind'),
        ('HH4', 'J02 bug', 'revive after cooperative exit decision is a phantom completion',
         'revive is only safe before the exit decision; an exiting instance must count as wasted',
         'regression test with cancel at 3, re-request at 4, phase 5', 'fixed simulator: revives 0, restart latency >=30', 'D2', 'keep exiting flag'),
        ('HH5', 'I04 route B', 'phase split value is a load effect, not a per-job effect',
         'split improves needed-job latency iff p<1 and pipeline overloaded (rho_joint>1)', '72-config DES', 'gate matches all 72 configs (tested 0.75 / >=1.25)', 'D3', 'gate_split'),
        ('HH6', 'X23', 'reservation and speculation are antagonistic for short speculative work',
         'with accurate multi-step prefetch, a reserved slot removes useful prefetch without lowering required max',
         '3-step lookahead C=2', 'forward I=+96 (fixed), +57 (dyn5); required max unchanged', 'D2', 'do not combine'),
    ]
    with open(ROOT / 'hypotheses_parts' / 'wpH.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['id', 'origin', 'difference_from_questions', 'prediction', 'minimal_experiment', 'result', 'depth', 'decision'])
        w.writerows(hyp)
    ad = [
        ('inc_revoke', 'L0', 'guard/epoch change vs item-write rate (gate_inc_revoke)', 'full revalidation on guard change or dirty_all',
         'publication read checks 128092->18936 on held-out D4', 'reverse index maintenance per certificate', 'none (equal views)', 'every write a guard change => equal to full',
         'any n, any write mix', 'guard_change_rate >= item_write_rate', 'none', 'none (internal)', 'results/raw/wpH/d4.json#incremental (cancels, rebinds, confirms, release audited)', 'adopt'),
        ('bound_confirm', 'L0', 'handle in callback', 'reject as stale_callback',
         'prevents 16/35 misattributed confirmations', 'carry handle', 'caller must re-confirm with current handle', 'same as package when no expiry',
         'all', 'none', 'none', 'confirm(target, handle)', 'results/raw/wpH/d4.json#bound_confirm', 'adopt'),
        ('value_cache', 'L0', 'knowledge-losing rebind count and producer label contract (gate_value_cache)', 'identity-only reuse',
         'adm 417->115, latency 937->138 on held-out D4 (2 fresh rebinds/run)', 'cache memory (bounded by key count)', 'first acquisition unchanged', 'contract violated => stale value (precondition)',
         'fresh rebinds >=1', 'carry-over rebinds: latency equal (H05 3 vs 3)', 'producer contract audit', 'none', 'results/raw/wpH/d4.json#value_cache', 'adopt conditional on contract'),
        ('reserve1', 'L2', 'optional service bound vs required tolerance (gate_reserve)', 'no reservation',
         'coupled D4: latency 113->112 (1 better, 1 worse), adm 904->883', '53 refusals of optional prefetch', 'required unchanged', 'Sim fixed: optional starvation 0/36',
         'optional bound > required tolerance', 'short optional services (coupled service_u=3, X23)', 'declared bounds', 'none', 'results/raw/wpH/d4.json#reservation', 'do not adopt at coupled parameters'),
        ('dyn_borrow', 'L2', 'declared bound <= B (gate_dyn_borrow)', 'fixed reservation', 'C=1: 7/36 optional served at required max 9 (B=10)',
         'bound declaration', 'required delay <= B', 'dishonest bounds void L6', 'B 10..20', 'B >= required tolerance', 'honest bounds', 'declared bound per task', 'results/raw/wpH/sched.json#I02', 'conditional'),
        ('split_phase', 'L2', 'p_need and rho_joint (gate_split)', 'joint phase', 'needed latency e.g. 1344->197 (a1 d5 p.25 gap4)', 'one hop + requeue',
         'needed jobs pay hop at low load', 'p=1: always worse', 'p<1, rho>=1.25', 'rho<=0.75 or p=1', 'load estimate', 'two-stage task', 'results/raw/wpH/extra.json#I04_des', 'conditional'),
        ('microbatch_peritem', 'L2', 'setup >= mean service (gate_microbatch)', 'immediate', 'required_total 1926->940 (I05)', 'batch bookkeeping',
         'first member waits for batch fill when max_wait set', 'barrier with slow member', 'setup 3..4u', 'setup << service', 'setup estimate', 'batch dispatch', 'results/raw/wpH/sched.json#I05', 'conditional'),
        ('refund_isolated_credit', 'L2', 'per-requester use observations (gate_spec_credit)', 'no speculation', 'G latency 59-76 -> 5-9 (J06 sim)', 'H extra work 8-10u',
         'H latency +9 (seed 200)', 'all requesters always wrong => 3 wasted specs each', 'credits 3/requester', 'hit rate 0 everywhere', 'use observable', 'none', 'results/raw/wpH/extra.json#J06_sim', 'conditional'),
    ]
    with open(ROOT / 'adoption_parts' / 'wpH.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['candidate', 'route(L0/L1/L2)', 'gate_observable', 'fallback', 'physical_work_saved', 'extra_cost', 'first_miss_penalty',
                    'worst_case', 'parameter_range', 'reversal_point', 'min_calibration', 'interface_change', 'lifecycle_evidence', 'decision'])
        w.writerows(ad)


if __name__ == '__main__':
    main()
