"""WP-H: commit/publication protocol, scheduling simulator, robustness, D4 chain (all capped, seconds)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import wpH_exp_commit as C  # noqa: E402
import wpH_exp_sched as E  # noqa: E402
import wpH_robust as RB  # noqa: E402
import wpH_combos as X  # noqa: E402
import wpH_d4 as D4  # noqa: E402
import wpH_commit as H  # noqa: E402
import wpH_runner as R  # noqa: E402
from wpH_sched import Sim  # noqa: E402


class Commit(unittest.TestCase):
    def test_h01_commit_check_safe_and_mutants_caught(self):
        r = C.h01()
        self.assertEqual(r['violations'], 0)
        self.assertGreater(r['stale'], 0)
        self.assertGreater(r['mutant_guard_only'], 0)
        self.assertGreater(r['mutant_own_items_only'], 0)

    def test_h02_cross_world_counterexample_exists_and_session_rejects(self):
        r = C.h02()
        self.assertIsNotNone(r['counterexample'])
        self.assertTrue(r['session_full_revalidation']['consistent'])
        self.assertTrue(r['incremental_revalidation']['consistent'])
        self.assertFalse(r['mutant_no_revalidation']['consistent'])

    def test_h03_incremental_revocation_equals_full(self):
        r = C.h03(seeds=range(5))
        self.assertEqual(r['view_mismatches'], 0)
        self.assertLess(r['incremental_read_checks'], r['full_read_checks'])

    def test_h04_package_confirm_accepts_late_callback_bound_rejects(self):
        r = C.h04()
        self.assertEqual(r['package_session']['late_callback'], 'confirmed')
        self.assertTrue(r['package_session']['confirmed_new_context'])
        self.assertEqual(r['bound_confirm']['late_callback'], 'stale_callback')

    def test_h05_aba_and_label_reuse_precondition(self):
        r = C.h05()
        self.assertTrue(r['aba']['cache_hit_on_restored_content'])
        self.assertNotEqual(r['aba']['old_certificate_publishable'], 'published')
        self.assertTrue(r['aba']['label_reuse_violation_served_stale_value'])
        for k in ('fresh_incumbent', 'fresh_value_cache', 'carry_incumbent', 'carry_value_cache'):
            self.assertEqual(r[k]['wrong'] + r[k]['wrong_current'] + r[k]['unserved'], 0, k)
        self.assertLess(r['fresh_value_cache']['adm'], r['fresh_incumbent']['adm'])

    def test_h06_joint_commit_starves_per_target_lives(self):
        rows = C.h06()['rows']
        starve = [x for x in rows if x['mode'] == 'joint' and x['published'] == 0]
        self.assertTrue(starve)
        for x in starve:
            per = [y for y in rows if y['mode'] == 'per_target' and y['commit_window'] == x['commit_window']
                   and y['churn_period'] == x['churn_period']]
            self.assertEqual(per[0]['published'], per[0]['of'])


class Sched(unittest.TestCase):
    def test_phantom_revive_regression(self):
        lat = {'long': 30, 'r': 2}
        ints = [dict(at=0, id='o', needs=['long'], required=False), dict(at=3, id='q', needs=['r'], required=True),
                dict(at=4, id='o2', needs=['long'], required=False)]

        def hook(sim, it):
            if it['id'] == 'q':
                sim.cancel('long', 'o')
        r = Sim(1, lat, dict(order='required_first', coop_exit=True, phase_len=5, revive=True)).run(
            ints, hooks=dict(on_intent=hook))
        self.assertEqual(r.get('revives', 0), 0)        # an exiting instance must not be revived
        self.assertGreaterEqual(r['optional_max'], 30)  # o2 needs a real restart

    def test_cancel_is_nonpreemptible_mutant_overcommits(self):
        m = E.i02(seeds=range(1))['mutant']
        self.assertEqual(m['correct']['max_physical'], 1)
        self.assertGreater(m['cancel_releases']['max_physical'], 1)

    def test_i02_dynamic_reserve_bound(self):
        rows = E.i02(seeds=range(3))['rows']
        base = {x['seed']: x['required_max'] for x in rows if x['C'] == 1 and x['policy'] == 'fixed1'}
        for x in rows:
            if x['policy'].startswith('dyn_b') and x['C'] == 1:
                b = int(x['policy'][5:])
                self.assertLessEqual(x['required_max'], base[x['seed']] + b)

    def test_j06_global_credit_starves(self):
        r = E.j06()['result']
        self.assertEqual(r['global']['useful_hits']['G'], 0)
        self.assertGreater(r['isolated']['useful_hits']['G'], 0)

    def test_x23_reservation_never_helps_and_blocks_useful_prefetch(self):
        rows = X.x23(seeds=range(2))['rows']
        key = {(x['seed'], x['pattern'], x['speculation'], x['reservation']): x['required_total'] for x in rows}
        for (s, p, sp, rp), v in key.items():
            self.assertGreaterEqual(v, key[(s, p, sp, 'none')])


class Robust(unittest.TestCase):
    def test_r01_split_identity_counterexample(self):
        r = RB.r01()
        self.assertTrue(r['split_intermediate_wrong'])
        self.assertEqual(r['atomic_unit'], r['final_truth_unit'])

    def test_r05_wrap_stale_saturate_exact(self):
        r = RB.r05(widths=(2,))
        self.assertGreater(r['w2_wrap']['stale_hits'], 0)
        self.assertEqual(r['w2_saturate_exact']['stale_hits'], 0)
        self.assertEqual(r['w2_incarnation_switch']['stale_hits'], 0)
        self.assertTrue(r['owner_saturated_relevant_change_correct'])

    def test_n03_bounded_protocol_no_violation(self):
        r = RB.n03(max_depth=4)
        for k, v in r.items():
            self.assertEqual(v['n_violations'], 0, k)


class SecondRoutesAndGates(unittest.TestCase):
    def test_i04_des_gate_matches_every_config(self):
        import wpH_extra as EX
        import wpH_adopt as A
        for x in EX.i04_des()['rows']:
            self.assertEqual(A.gate_split(x['p_need'], x['rho_joint']), x['split_wins_latency_for_needed'], x)
            if x['p_need'] < 1:
                self.assertLess(x['split_work'], x['joint_work'])

    def test_j06_sim_refund_isolation_dominates_global(self):
        import wpH_extra as EX
        rows = EX.j06_sim(seeds=range(2))['rows']
        for seed in range(2):
            by = {x['organisation']: x for x in rows if x['seed'] == seed}
            self.assertGreater(by['global']['spent_H'], by['global']['spent_G'])
            self.assertLessEqual(by['isolated']['G_total'], by['global']['G_total'])
            self.assertLess(by['refund_isolated']['G_total'], by['isolated']['G_total'])
            self.assertLessEqual(by['refund_isolated']['extra_work_u'], by['global']['extra_work_u'])

    def test_microbatch_peritem_beats_barrier(self):
        r = E.i05()
        for mw in (None, 3, 8):
            self.assertLessEqual(r[f'batch4_barrierFalse_maxwait{mw}']['required_total'],
                                 r[f'batch4_barrierTrue_maxwait{mw}']['required_total'])
        self.assertLess(r['batch4_barrierFalse_maxwaitNone']['required_total'], r['immediate_setup4']['required_total'])


class D4Chain(unittest.TestCase):
    def test_bound_confirm_heldout(self):
        r_pkg, _ = D4.run('RP', 102, R.StrongSession, churn=True, rebind=False, confirms=False, late=True,
                          bound_confirm=False)
        r_bnd, _ = D4.run('RP', 102, H.BoundConfirmSession, churn=True, rebind=False, confirms=False, late=True,
                          bound_confirm=True)
        bad = lambda r: sum(1 for x in r.get('late_callbacks', []) if x['refers_to_expired'] and x['result'] == 'confirmed')
        self.assertGreater(bad(r_pkg), 0)
        self.assertEqual(bad(r_bnd), 0)
        for r in (r_pkg, r_bnd):
            self.assertEqual(r['wrong'] + r['wrong_current'], 0)
            self.assertTrue(r['confirmed_subset'])

    def test_incremental_heldout_equals_full(self):
        a, ra = D4.run('W02', 100, R.StrongSession)
        b, rb = D4.run('W02', 100, H.IncSession)
        self.assertEqual(ra.session.published, rb.session.published)
        self.assertEqual(ra.session.confirmed, rb.session.confirmed)
        self.assertEqual(a['total_latency_u'], b['total_latency_u'])
        self.assertLess(b['publication_read_checks'], a['publication_read_checks'])
        self.assertEqual(b['occupied_end'], 0)


if __name__ == '__main__':
    unittest.main()
