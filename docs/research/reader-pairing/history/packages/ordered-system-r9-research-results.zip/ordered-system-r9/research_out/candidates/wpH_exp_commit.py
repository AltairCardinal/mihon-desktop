"""H01-H06 experiments + coupled D4 runs for publication mechanisms (virtual u)."""
import json
import random
import time
from copy import deepcopy
from pathlib import Path

import paths  # noqa: F401
import reference as ref
from common import random_case, roundtrip, fact
from coupling import Session
from current_baseline import typed
import workloads as W
import wpH_commit as H
import wpH_runner as R

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpH'


def sel(case, t):
    return {k: v for k, v in ref.certify_strategy(case, t)['selected'].items() if k != 'reads'}


# ------------------------------------------------------------------ H01 critical-section sizes
def h01():
    res = H.commit_window_cases()
    rng = random.Random(6)
    steps = keys = n_ = 0
    for k in range(200):
        n = rng.randrange(4, 40)
        c = roundtrip(random_case(rng, n, p_unknown=0.1, p_edge_unknown=0.1))
        s = Session(c)
        t = rng.randrange(n)
        v = s.certify(t, mode='L0')
        if v['status'] != 'certified':
            continue
        n_ += 1
        steps += s.metrics['certification_steps']
        keys += len(s._certs[v['certificate']]['support'])
    res['critical_section'] = dict(cases=n_, mean_proof_steps=round(steps / n_, 2), mean_commit_support_reads=round(keys / n_, 2),
                                   note='snapshot+commit: owner critical section = support comparison only; owner '
                                        'transaction: whole proof (steps) + support build inside the critical section')
    return res


# ------------------------------------------------------------------ H02 cross-world composition
def find_cross_world(seed=7, tries=4000):
    rng = random.Random(seed)
    for k in range(tries):
        n = rng.randrange(3, 7)
        c = roundtrip(random_case(rng, n, p_unknown=0.0, p_edge_unknown=0.0, p_fail=0.0))
        t1, t2 = rng.randrange(n), rng.randrange(n)
        if t1 == t2:
            continue
        u1 = sel(c, t1)
        if u1['status'] != 'certified':
            continue
        i = rng.randrange(n)
        d = deepcopy(c)
        st = d['items'][i]['analysis']['fact']['state']
        d['items'][i]['analysis']['fact'] = fact('WIDE' if st == 'NARROW' else 'NARROW', 'UNKNOWN')
        d['items'][i]['header'] = fact(d['items'][i]['analysis']['fact']['state'])
        u2 = sel(d, t2)
        if u2['status'] != 'certified':
            continue
        m1 = {s['item'] for s in u1['unit']['slots']}
        m2 = {s['item'] for s in u2['unit']['slots']}
        if m1 & m2 and u1['unit'] != u2['unit']:
            return dict(case=c, changed_item=i, changed=d, t1=t1, t2=t2, unit1=u1['unit'], unit2=u2['unit'])
    return None


def h02():
    cex = find_cross_world()
    out = dict(counterexample=cex)
    if cex is None:
        return out
    # real Session: publish t1, apply the change through the owner, publish t2
    for cls, label in ((Session, 'session_full_revalidation'), (H.IncSession, 'incremental_revalidation')):
        s = cls(cex['case'])
        v1 = s.certify(cex['t1'], mode='L0')
        r1 = s.publish(cex['t1'], v1['certificate'])
        it = cex['changed']['items'][cex['changed_item']]
        s.owner.apply(item_updates={cex['changed_item']: {'analysis': it['analysis'], 'header': it['header']}})
        v2 = s.certify(cex['t2'], mode='L0')
        r2 = s.publish(cex['t2'], v2['certificate'])
        cur = s.published
        out[label] = dict(r1=r1, r2=r2, current=sorted(int(k) for k in cur),
                          consistent=all(not ({x['item'] for x in a['slots']} & {x['item'] for x in b['slots']}) or a == b
                                         for ka, a in cur.items() for kb, b in cur.items()))
    # mutant: validate each certificate only at its own issuance, never re-validate older publications
    pubs = {cex['t1']: cex['unit1'], cex['t2']: cex['unit2']}
    out['mutant_no_revalidation'] = dict(published=sorted(pubs), consistent=False,
                                         note='both units are published; they overlap but differ (two worlds)')
    # minimal revalidation set = publications whose support intersects keys changed since their validation
    out['minimal_revalidation_rule'] = 'revalidate h iff support(h) ∩ dirty_keys != ∅ or guard/epoch changed'
    return out


# ------------------------------------------------------------------ H03 differential + cost
def h03(seeds=range(30)):
    mism = 0
    full_checks = inc_checks = steps = 0
    for seed in seeds:
        rng = random.Random(seed)
        n = rng.randrange(6, 30)
        c = roundtrip(random_case(rng, n, p_unknown=0.1, p_edge_unknown=0.1))
        a, b = Session(c), H.IncSession(c)
        for k in range(60):
            op = rng.random()
            if op < 0.45:
                t = rng.randrange(n)
                va, vb = a.certify(t, mode='L0'), b.certify(t, mode='L0')
                if va['status'] == 'certified':
                    ra, rb = a.publish(t, va['certificate']), b.publish(t, vb['certificate'])
                    mism += ra != rb
            elif op < 0.8:
                i = rng.randrange(n)
                patch = {'analysis': dict(status='computed', fact=fact(rng.choice(('NARROW', 'WIDE')), rng.choice(('A', 'B', 'UNKNOWN'))), version=k)} \
                    if rng.random() < .8 else {'analysis': {'status': 'unknown'}}
                a.owner.apply(item_updates={i: patch}); b.owner.apply(item_updates={i: patch})
            elif op < 0.92:
                e = rng.randrange(n - 1)
                rec = dict(status='computed', score=rng.choice((None, 1.0, 2.0, 5.0)), version=k)
                a.owner.apply(edge_updates={(e, e + 1): rec}); b.owner.apply(edge_updates={(e, e + 1): rec})
            elif op < 0.97:
                t = rng.randrange(n)
                mism += a.confirm(t) != b.confirm(t)
            else:
                cc = a.owner.snapshot()
                a.rebind(cc); b.rebind(deepcopy(cc))
            mism += a.published != b.published
            mism += a.confirmed != b.confirmed
            steps += 1
        full_checks += a.metrics['publication_read_checks']
        inc_checks += b.metrics['publication_read_checks']
    return dict(steps=steps, view_mismatches=mism, full_read_checks=full_checks, incremental_read_checks=inc_checks,
                ratio=round(inc_checks / max(1, full_checks), 3))


# ------------------------------------------------------------------ H04 unbound confirmation callback
def h04():
    tr = W.w01_phase_chain(0, n=12)
    c = tr['initial']
    out = {}
    for label, cls in (('package_session', Session), ('bound_confirm', H.BoundConfirmSession)):
        s = cls(c)
        t = next(t for t in range(12) if s.certify(t, mode='L0')['status'] == 'certified')
        v1 = s.certify(t, mode='L0')
        s.publish(t, v1['certificate'])
        old_handle = v1['certificate']
        # relevant evidence change expires the publication, then the same unit is re-certified/published
        i = t
        a = deepcopy(s.owner._case['items'][i]['analysis']); a['version'] += 1
        s.owner.apply(item_updates={i: {'analysis': a}})
        _ = s.published                              # expiry observed
        v2 = s.certify(t, mode='L0'); s.publish(t, v2['certificate'])
        # the LATE callback for the first publication arrives now
        r = s.confirm(t) if label == 'package_session' else s.confirm(t, old_handle)
        out[label] = dict(target=t, same_unit=v1['unit'] == v2['unit'], late_callback=r,
                          confirmed_new_context=(t in s.confirmed))
    out['note'] = ('Session.confirm(target) is not bound to the publication instance: a late callback for an '
                   'expired publication confirms the re-issued publication of an equal unit; binding the handle '
                   'rejects it as stale_callback')
    return out


# ------------------------------------------------------------------ H05 value-keyed reuse + ABA
def h05():
    out = {}
    # (a) rebind that loses admitted knowledge (fresh owner) vs carry-over rebind
    for mode in ('fresh', 'carry'):
        for label, cls in (('incumbent', R.StrongSession), ('value_cache', H.ValueCacheSession)):
            tot = dict(adm=0, hits=0, lat=0, wrong=0, wrong_current=0, unserved=0)
            for seed in range(6):
                tr = W.random_partial(seed, n=16, pa=0.5, pe=0.5, count=16)
                evs = list(tr['events'])
                for k, at in enumerate((45, 95, 145)):
                    evs.append(dict(at=at, op='rebind'))
                tr2 = dict(tr, events=sorted(evs, key=lambda e: e['at']))
                rr = R.RunnerH(tr2, session_cls=cls, policy='incumbent', service_u=3)
                if mode == 'fresh':
                    init = deepcopy(tr['initial'])
                    orig = rr._custom

                    def custom(ev, rr=rr, init=init, orig=orig):
                        if ev['op'] == 'rebind':
                            rr.session.rebind(deepcopy(init))
                            rr.audit['rebinds'] += 1
                            for kk in list(rr.first_pub):
                                rr.first_pub.pop(kk); rr.intent[kk] = rr.now
                            return
                        orig(ev)
                    rr._custom = custom
                r = rr.run()
                tot['adm'] += r['physical_admissions']; tot['hits'] += r['value_cache_hits']
                tot['lat'] += r['total_latency_u']; tot['wrong'] += r['wrong']; tot['wrong_current'] += r['wrong_current']
                tot['unserved'] += len(r['unserved'])
            out[f'{mode}_{label}'] = tot
    # (b) ABA: content A -> B -> A ; (c) label reuse with different content (producer violation)
    c = W.random_partial(1, n=6, pa=0.0, pe=0.0)['initial']
    s = H.ValueCacheSession(c)
    from coupling import Witness
    w_a = Witness(dict(status='computed', fact=fact('NARROW', 'A'), version=1), 3)
    tok = s.acquire(2); s.finish(tok, w_a); s.consume(tok)
    v = s.certify(2, mode='L0')
    cert_before = v.get('certificate')
    # B: new content version -> new identity (owner identity change clears memo); then back to A label 0
    s.owner.apply(item_updates={2: {'content_version': 1, 'analysis': {'status': 'unknown'}}})
    s.owner.apply(item_updates={2: {'content_version': 0, 'analysis': {'status': 'unknown'}}})
    tok = s.acquire(2)
    aba = dict(cache_hit_on_restored_content=s.metrics['value_cache_hits'] == 1,
               old_certificate_publishable=(s.publish(2, cert_before) if cert_before else None))
    # label reuse violation: same (id, content_version) but the producer now returns different content
    s2 = H.ValueCacheSession(c)
    tok = s2.acquire(3); s2.finish(tok, Witness(dict(status='computed', fact=fact('NARROW', 'A'), version=1), 1)); s2.consume(tok)
    s2.rebind(deepcopy(c))
    tok = s2.acquire(3)       # cache answers with the OLD witness although "true" content changed (violation)
    aba['label_reuse_violation_served_stale_value'] = s2.metrics['value_cache_hits'] == 1
    out['aba'] = aba
    out['note'] = ('value cache keyed by full content identity + recipe version; authority (certificates, '
                   'publications, confirmations) never survives rebind; label reuse with different content '
                   'is a producer-contract violation the cache cannot detect (N12-style precondition)')
    return out


# ------------------------------------------------------------------ H06 liveness under churn
def h06():
    rows = []
    rng0 = random.Random(3)
    c = roundtrip(random_case(rng0, 24, p_unknown=0.0, p_edge_unknown=0.0, settings_mix=False))
    s = Session(c)
    supports = {}
    for t in range(24):
        v = s.certify(t, mode='L0')
        if v['status'] == 'certified':
            supports[t] = {k[1] for k in s._certs[v['certificate']]['support']}   # item positions
    targets = sorted(supports)[::3][:8]
    for q in (1, 3, 6):                       # certify -> commit delay (proof + validation window)
        for period in (1, 2, 4, 8):           # churn interval: one random item write every `period` u
            for mode in ('per_target', 'joint'):
                rng = random.Random(q * 100 + period)
                horizon = 400
                writes = {}
                tt = 0
                while tt < horizon:
                    tt += period
                    writes.setdefault(tt, []).append(rng.randrange(24))
                done_at = {}
                attempts = 0
                t = 0
                pending = list(targets)
                while t < horizon and pending:
                    hit = set()
                    for x in range(t + 1, t + q + 1):
                        hit.update(writes.get(x, []))
                    if mode == 'joint':
                        attempts += 1
                        sup = set().union(*(supports[b] for b in pending))
                        if not (hit & sup):
                            for b in pending:
                                done_at[b] = t + q
                            pending = []
                    else:                     # every pending target commits independently in parallel
                        for b in list(pending):
                            attempts += 1
                            if not (hit & supports[b]):
                                done_at[b] = t + q
                                pending.remove(b)
                    t += q
                lat = sorted(done_at.values())
                rows.append(dict(commit_window=q, churn_period=period, mode=mode, published=len(done_at),
                                 of=len(targets), attempts=attempts,
                                 first_publication=lat[0] if lat else None,
                                 last_publication=lat[-1] if len(lat) == len(targets) else None))
    sizes = {t: len(v) for t, v in supports.items() if t in targets}
    return dict(rows=rows, support_sizes=sizes,
                note='a commit succeeds iff no write touched its support during the window; joint transactions need '
                     'the union support quiet (P(success) ~ (1-|U|/n)^(q/period)); per-target fair rotation succeeds '
                     'once any single support is quiet for q')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    res = dict(H01=h01(), H02=h02(), H03=h03(), H04=h04(), H05=h05(), H06=h06())
    (OUT / 'commit.json').write_text(json.dumps(res, indent=1, default=str))
    return res


if __name__ == '__main__':
    r = main()
    print(json.dumps({k: v if k in ('H03', 'H04') else '...' for k, v in r.items()}, indent=1, default=str)[:3000])
