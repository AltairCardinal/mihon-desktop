"""WP-B D4: exact block summary as strong L1 in the coupled chain (held-out seeds 100-109).
Virtual u for service/proof; local ns of strong attempts reported separately."""
import json, sys, time, collections
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
import paths  # noqa
import workloads as W, coupled_runner as CR, wpB_coupled as BC
from strong import StrongSession

OUT = HERE.parents[1] / 'results' / 'raw' / 'wpB'; OUT.mkdir(parents=True, exist_ok=True)
rows = []
for fam in ('W05', 'W06', 'W01', 'W02', 'RP'):
    for seed in range(100, 110):
        tr = W.FAMILIES[fam](seed)
        for pol in ('incumbent', 'proof_first', 'gated'):
            kinds = ('none',) if pol == 'incumbent' else ('tree', 'exact', 'blocks')
            for kind in kinds:
                strong = dict(kind=kind if kind != 'none' else 'tree', domain='nonneg', alpha=False, gate='raw')
                R = BC.BlockRunner if kind == 'blocks' else CR.Runner
                r = R(tr, policy=pol, service_u=3, q_u=1, strong=strong).run()
                rows.append(dict(family=fam, seed=seed, policy=pol, kind=kind,
                                 **{k: r[k] for k in ('published', 'intents', 'wrong', 'total_latency_u', 'physical_admissions',
                                                      'discarded', 'strong_attempts', 'strong_certificates',
                                                      'strong_evaluations', 'strong_ns', 'end_u')}))
agg = collections.defaultdict(collections.Counter)
for r in rows:
    k = (r['family'], r['policy'], r['kind'])
    for f in ('published', 'intents', 'wrong', 'total_latency_u', 'physical_admissions', 'strong_attempts',
              'strong_certificates', 'strong_evaluations', 'strong_ns'):
        agg[k][f] += r[f]
summary = [dict(family=k[0], policy=k[1], kind=k[2], **v) for k, v in sorted(agg.items())]
# lifecycle: publish -> support change -> stale confirm / expired publication
tr = W.w01_phase_chain(101)
s = BC.BlockSession(tr['initial'], strong=dict(kind='blocks', domain='nonneg', alpha=False, gate='raw'))
life = None
for t in range(len(tr['initial']['items'])):
    v = s.certify(t, mode='S')
    if v.get('route') == 'strong-blocks':
        pub = s.publish(t, v['certificate'])
        conf1 = s.confirm(t)
        e = next(x for x in s.owner._case['edges'] if x['first'] <= t)
        s.owner.apply(edge_updates={(e['first'], e['second']): dict(status='computed', score=999, version=7)})
        life = dict(target=t, publish=pub, confirm_before=conf1, confirm_after_change=s.confirm(t),
                    published_after=str(t) in {str(k) for k in s.published}, confirmed_after=str(t) in {str(k) for k in s.confirmed},
                    block_updates=s.metrics['block_updates'], block_rebuilds=s.metrics['block_rebuilds'])
        break
# rebind: old certificate cannot publish in new owner context
s2 = BC.BlockSession(tr['initial'], strong=dict(kind='blocks', domain='nonneg', alpha=False, gate='raw'))
handle = None
for t in range(len(tr['initial']['items'])):
    v = s2.certify(t, mode='S')
    if v.get('route') == 'strong-blocks':
        handle = (t, v['certificate']); break
s2.rebind(tr['initial'])
rebind = dict(old_handle_publish=s2.publish(*handle) if handle else None, rebuilds_after=s2.metrics['block_rebuilds'])
res = dict(layer='coupled (virtual u) + local ns', service_u=3, q_u=1, held_out_seeds='100-109', rows=rows, summary=summary,
           lifecycle=life, rebind=rebind)
(OUT / 'coupled.json').write_text(json.dumps(res, indent=1))
for r in summary: print(r)
print(life); print(rebind)
