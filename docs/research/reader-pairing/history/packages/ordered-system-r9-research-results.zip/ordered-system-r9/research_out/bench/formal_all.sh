#!/bin/sh
# Serial formal timing of every registered bench module: 3 independent processes,
# 1 warmup + 3 measured reps each, rotated candidate order.  ~30 min on 2 vCPU.
cd "$(dirname "$0")/.."
date -u +%FT%TZ > results/raw/formal/started_utc.txt
for m in bench_wpA bench_wpB bench_wpC bench_wpG bench_wpH; do
  python3 bench/drive_formal.py $m --out results/raw/formal/$m.jsonl --procs 3 --reps 3 --warmup 1
  date -u +%FT%TZ > results/raw/formal/${m}_done_utc.txt
done
date -u +%FT%TZ > results/raw/formal/finished_utc.txt
