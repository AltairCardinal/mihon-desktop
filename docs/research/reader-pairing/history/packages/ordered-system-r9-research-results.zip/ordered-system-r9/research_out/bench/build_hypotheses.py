"""hypotheses.csv (deduplicated, renumbered NH01..) + NH rows appended to coverage.csv."""
import csv, io
from pathlib import Path
OUT = Path(__file__).resolve().parents[1]
MAIN = [
 dict(id='NH-M1', origin='S04 implementation (main session)', difference_from_questions='S04 asks for tunable locality; this states that restart-based rules cannot provide it at all',
      prediction='restarting the frozen scan at absolute or anchored boundaries leaves the influence radius unbounded on phase chains',
      minimal_experiment='edit radius of seg8/seg16/anchor on a 96-item decreasing chain', result='radius 94/31/95 vs reference 92; forced cuts give 6/14', depth='D2', decision='drop restart rules; only forced cuts bound locality (with pair loss)'),
 dict(id='NH-M2', origin='T05 oracle reference point', difference_from_questions='T05 asks for a bound; this predicts WHERE residual gain lives',
      prediction='remaining physical-work savings concentrate in families with shared unknown variables (all ranks missing / phase chains), not in random partial knowledge',
      minimal_experiment='incumbent vs exact-q0 vs oracle_min on W06/W01/RP/W05 (n=10-12)', result='W06 82->76->42, W01 33->25->15, RP 26->26->23, W05 3->3->2', depth='D2', decision='direct F-family effort to ambiguity-heavy workloads only'),
 dict(id='NH-M3', origin='T01 premise P6; independently NH-A5 (WP-A)', difference_from_questions='not a listed question: exact typed support makes certificates refinement-intolerant',
      prediction='a strong publication expires when an unknown fact in its support becomes known even if the canonical unit is unchanged; a refresh from L0 restores it',
      minimal_experiment='tests/test_wpT.py::test_P6 (W01 chain, admit the true rank of a hole)', result='publication expires; L0 now certifies the same unit; WP-A shadow refresh keeps current publications >= incumbent', depth='D3', decision='adopt refresh-on-expiry for proof publications'),
]
MERGE = {'NH-A1': 'NH-G1', 'NH-A5': 'NH-M3'}       # same root cause -> merged into the target id


def main():
    rows = []
    for p in sorted((OUT / 'hypotheses_parts').glob('*.csv')):
        for r in csv.DictReader(io.StringIO(p.read_text(encoding='utf-8'))):
            r['work_package'] = p.stem
            rows.append(r)
    for r in MAIN:
        rows.append(dict(r, work_package='main'))
    merged = {}
    for r in rows:
        if r['id'] in MERGE:
            merged.setdefault(MERGE[r['id']], []).append(r['id'])
    keep = [r for r in rows if r['id'] not in MERGE]
    hdr = ['nh', 'id', 'work_package', 'origin', 'difference_from_questions', 'prediction', 'minimal_experiment', 'result',
           'depth', 'decision', 'merged_duplicates']
    out = io.StringIO(); w = csv.DictWriter(out, fieldnames=hdr, extrasaction='ignore'); w.writeheader()
    for k, r in enumerate(keep, 1):
        r['nh'] = f'NH{k:02d}'; r['merged_duplicates'] = ';'.join(merged.get(r['id'], []))
        w.writerow(r)
    (OUT / 'hypotheses.csv').write_text(out.getvalue(), encoding='utf-8')
    # append NH rows to coverage.csv
    cov = (OUT / 'coverage.csv').read_text(encoding='utf-8').splitlines()
    hdrc = next(csv.reader([cov[0]]))
    buf = io.StringIO(); cw = csv.DictWriter(buf, fieldnames=hdrc, extrasaction='ignore')
    for r in keep:
        cw.writerow(dict(question_id=r['nh'], title=r['id'], family='NH', prior_anchor=r['origin'], new_gap=r['difference_from_questions'],
                         route_a=r['minimal_experiment'], route_b='-', status='implemented_verified' if 'refut' not in r['decision'].lower() else 'refuted',
                         depth=r['depth'], proof_or_counterexample=r['result'], decision=r['decision'], work_package=r['work_package'],
                         audit_note='new hypothesis; not counted as one of the 150 items'))
    lines = [l for l in cov if not l.startswith('NH')]
    (OUT / 'coverage.csv').write_text('\n'.join(lines) + '\n' + buf.getvalue(), encoding='utf-8')
    print('hypotheses kept', len(keep), 'merged', merged)


if __name__ == '__main__':
    main()
