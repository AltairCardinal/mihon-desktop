"""WP-C witness pipeline (E04, E05, E06, X12, X13, X14).

Reference operator: package OPTIMIZED_OPERATOR.score (frozen copy, imported).
Every variant here must return results identical (==, same None) to it.

E06  fused derivation: normalise each witness once and serve both neighbours
     (eager), or normalise on first use and cache (lazy); same summation order,
     same early-null exit, same filter formulas.
E04  progressive service: read a witness pair in segments of k elements;
     the only exact early stop is the distance null (partial L1 >= 1500).
E05  transform reuse: score is symmetric in its two arguments (proved by
     inspection), element-order reversal is NOT guaranteed bit-identical
     because the variance sums are order-dependent in binary64 (searched).
"""
import random
from collections import Counter

import paths  # noqa: F401
import OPTIMIZED_OPERATOR as OP

COUNT = OP.COUNT


def pack(c1, c2, c3, cov=255):
    return (cov << 24) | (c1 << 16) | (c2 << 8) | c3


def random_witness(rng, base=None, spread=40, cov_choices=(255,)):
    out = []
    for k in range(COUNT):
        b = base[k] if base else (60 + (k * 37) % 120, 70 + (k * 53) % 110, 80 + (k * 29) % 100)
        c = tuple(max(0, min(255, b[j] + rng.randrange(-spread, spread + 1))) for j in range(3))
        out.append(pack(*c, rng.choice(cov_choices)))
    return out


def unpack_norm(w):
    return [OP.normalize(x) for x in w]


def score_from_norm(left, right, counter=None):
    """OP.score on pre-normalised vectors; identical decision sequence."""
    total = 0
    for k, (a, b) in enumerate(zip(left, right)):
        total += sum(abs(u - v) for u, v in zip(a, b))
        if counter is not None:
            counter['pair_elements'] += 1
        if total >= 30 * COUNT:
            return None
    if all(sum(min(x) > 220 for x in side) >= COUNT * 0.8 for side in (left, right)):
        return None
    if all(sum(max(x) < 50 for x in side) >= COUNT * 0.8 for side in (left, right)):
        return None
    if OP._variance(left) < 100 and OP._variance(right) < 100:
        return None
    return float(total) / COUNT


def separate_ranks(witnesses, pairs, counter):
    """Incumbent: OP.score per needed pair (each call normalises its prefix)."""
    out = {}
    for a, b in pairs:
        # count normalisations exactly as OP.score performs them (stops at early null)
        total, k = 0, 0
        for x, y in zip(witnesses[a], witnesses[b]):
            k += 1
            total += sum(abs(u - v) for u, v in zip(OP.normalize(x), OP.normalize(y)))
            if total >= 30 * COUNT:
                break
        counter['normalize_calls'] += 2 * k
        counter['pair_elements'] += k
        out[(a, b)] = OP.score(witnesses[a], witnesses[b])
    return out


def fused_ranks(witnesses, pairs, counter, eager=True, cache=None):
    """E06: normalise once per witness (eager: every witness offered, lazy: on first use)."""
    cache = {} if cache is None else cache
    if eager:
        for i, w in enumerate(witnesses):
            if i not in cache:
                cache[i] = unpack_norm(w)
                counter['normalize_calls'] += COUNT
    out = {}
    for a, b in pairs:
        for i in (a, b):
            if i not in cache:
                cache[i] = unpack_norm(witnesses[i])
                counter['normalize_calls'] += COUNT
        out[(a, b)] = score_from_norm(cache[a], cache[b], counter)
    return out


def progressive_pair(wa, wb, seg, counter, open_cost=1):
    """E04: segmented extraction of BOTH witnesses for one pair decision.
    Returns (score, elements_read).  Exact: stops only on the distance null."""
    total = 0
    read = 0
    for start in range(0, COUNT, seg):
        counter['segment_opens'] += 1
        counter['open_cost_u'] += open_cost
        for x, y in zip(wa[start:start + seg], wb[start:start + seg]):
            read += 1
            total += sum(abs(u - v) for u, v in zip(OP.normalize(x), OP.normalize(y)))
        if total >= 30 * COUNT:
            counter['elements_read'] += 2 * read
            return None, read
    counter['elements_read'] += 2 * read
    return OP.score(wa, wb), read


def variance_two_pass(features):
    values = [0.299 * x[0] + 0.587 * x[1] + 0.114 * x[2] for x in features]
    mean = sum(values) / COUNT
    return sum((x - mean) ** 2 for x in values) / COUNT


def find_variance_formula_disagreement(seed=0, tries=200000):
    """Search normalised vectors whose one-pass (OP) and two-pass variance fall on
    different sides of the 100 threshold."""
    rng = random.Random(seed)
    for t in range(tries):
        m = rng.randrange(30, 220)
        d = rng.choice((10,))
        feats = []
        for k in range(COUNT):
            v = m + (d if k % 2 else -d) + rng.choice((0, 0, 0, 1, -1))
            g = max(0, min(255, v))
            feats.append((g, g, g))
        a, b = OP._variance(feats), variance_two_pass(feats)
        if (a < 100) != (b < 100):
            return dict(feats=feats, one_pass=a, two_pass=b, tries=t + 1)
    return None


def find_reversal_disagreement(seed=0, tries=200000):
    """Element-order reversal of both witnesses: is OP.score always identical?"""
    rng = random.Random(seed)
    for t in range(tries):
        m = rng.randrange(30, 220)
        wa, wb = [], []
        for k in range(COUNT):
            v = m + (10 if k % 2 else -10) + rng.choice((0, 0, 1, -1))
            g = max(0, min(255, v))
            wa.append(pack(g, g, g))
            u = max(0, min(255, g + rng.choice((0, 1, -1, 2))))
            wb.append(pack(u, u, u))
        s1, s2 = OP.score(wa, wb), OP.score(wa[::-1], wb[::-1])
        if s1 != s2:
            return dict(wa=wa, wb=wb, forward=s1, reversed=s2, tries=t + 1)
    return None


class PrefixNormCache:
    """E06 route 3: per-witness normalised PREFIX cache, extended only as far as
    some consumer's exact computation needs (early null stops extension)."""

    def __init__(self, witnesses, counter):
        self.w, self.c, self.cache = witnesses, counter, {}

    def elem(self, i, k):
        lst = self.cache.setdefault(i, [])
        while len(lst) <= k:
            lst.append(OP.normalize(self.w[i][len(lst)]))
            self.c['normalize_calls'] += 1
        return lst[k]

    def score(self, a, b):
        total = 0
        for k in range(COUNT):
            x, y = self.elem(a, k), self.elem(b, k)
            total += sum(abs(u - v) for u, v in zip(x, y))
            self.c['pair_elements'] += 1
            if total >= 30 * COUNT:
                return None
        left, right = self.cache[a][:COUNT], self.cache[b][:COUNT]
        if all(sum(min(x) > 220 for x in side) >= COUNT * 0.8 for side in (left, right)):
            return None
        if all(sum(max(x) < 50 for x in side) >= COUNT * 0.8 for side in (left, right)):
            return None
        if OP._variance(left) < 100 and OP._variance(right) < 100:
            return None
        return float(total) / COUNT


def prefix_ranks(witnesses, pairs, counter):
    pc = PrefixNormCache(witnesses, counter)
    return {(a, b): pc.score(a, b) for a, b in pairs}
