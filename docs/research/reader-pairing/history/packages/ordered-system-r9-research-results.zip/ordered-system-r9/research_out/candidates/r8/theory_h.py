"""H2/H3/H4/H5 executable studies.

H4  discriminating power of validation projections against injected mutants.
H5  an L2 alternative rule with bounded dependency radius (local maxima +
    parity passes) - pending adjudication, NOT an equivalence claim.
H3  cache policy competitiveness on adversarial / drifting target sequences.
H2  delta-debugging reducer for performance counterexamples (deterministic
    work counters as the cost, so the reduction is reproducible).
"""
import copy
import json
import random
from contextlib import contextmanager

from common import ref, random_case, roundtrip, unit_of
import compact_core as core


# ----------------------------------------------------------------------- H4
PROJECTIONS = {
    'status': lambda v: v['status'],
    'host_fixture': lambda v: (v['status'], None if v['unit'] is None else
                               (json.dumps(v['unit']['slots']), v['unit']['certain']), json.dumps(v['failures'], sort_keys=True)),
    'unit_full': lambda v: (v['status'], json.dumps(v['unit'], sort_keys=True)),
    'members_only': lambda v: (v['status'], None if v['unit'] is None else tuple(s['item'] for s in v['unit']['slots'])),
    'public_full': lambda v: json.dumps({k: v[k] for k in ('status', 'unit', 'needs', 'failures', 'first', 'steps', 'dependent_items')},
                                        sort_keys=True),
}


@contextmanager
def patched(obj, name, new):
    old = getattr(obj, name)
    setattr(obj, name, new)
    try:
        yield
    finally:
        setattr(obj, name, old)


def _mut_reason_order(self, cursor, include_single=True, include_pair=True):
    unit, nxt = ORIG_STEP(self, cursor, include_single, include_pair)
    if unit is not None and unit['reason'] == 'BEFORE_WIDE':
        unit['reason'] = 'OPENING'                    # reason-only mutant
    return unit, nxt


def _mut_slot_default(self, cursor, include_single=True, include_pair=True):
    unit, nxt = ORIG_STEP(self, cursor, include_single, include_pair)
    if unit is not None and len(unit['slots']) == 1 and unit['reason'] == 'TAIL':
        unit['slots'][0]['slot'] = self.trailing      # slot-only mutant
    return unit, nxt


def _mut_tie(self, i):
    near, later = self.strength(i), self.strength(i + 1)
    if later != near:
        return later > near
    if not self.s['automatic'] or later < 0 or i + 2 >= self.n:
        return False
    a, b = self.distance(i, i + 1), self.distance(i + 1, i + 2)
    return b is not None and (a is None or b <= a)  # tie-break mutant (<= instead of <)


ORIG_STEP = ref._Scan.step


def certify_mutant(kind, case, target):
    if kind == 'none':
        return ref.certify_strategy(case, target)['selected']
    if kind == 'reason':
        with patched(ref._Scan, 'step', _mut_reason_order):
            return ref.certify_strategy(case, target)['selected']
    if kind == 'slot':
        with patched(ref._Scan, 'step', _mut_slot_default):
            return ref.certify_strategy(case, target)['selected']
    if kind == 'tie':
        with patched(ref._Scan, 'later_wins', _mut_tie):
            return ref.certify_strategy(case, target)['selected']
    v = ref.certify_strategy(case, target)['selected']
    v = copy.deepcopy(v)
    if kind == 'needs_order':
        v['needs'] = list(reversed(v['needs']))
    elif kind == 'swallow_failure':
        if v['failures']:
            v['failures'] = {}
            v['status'] = 'need_facts' if v['needs'] else v['status']
    elif kind == 'steps_off':
        v['steps'] += 1
    elif kind == 'certain_true':
        if v['unit'] is not None:
            v['unit']['certain'] = True
    elif kind == 'drop_dependency':
        if len(v['dependent_items']) > 1:
            v['dependent_items'] = v['dependent_items'][1:]
    return v


MUTANTS = ('reason', 'slot', 'tie', 'needs_order', 'swallow_failure', 'steps_off', 'certain_true', 'drop_dependency')


def projection_power(cases=1500, seed=31):
    rng = random.Random(seed)
    kill = {m: {p: 0 for p in PROJECTIONS} for m in MUTANTS}
    active = {m: 0 for m in MUTANTS}
    for _ in range(cases):
        n = rng.randrange(2, 12)
        c = roundtrip(random_case(rng, n, p_wide=0.2, p_unknown=0.2, p_edge_unknown=0.2, p_fail=0.05, header_missing=0.05))
        t = rng.randrange(n)
        good = certify_mutant('none', c, t)
        for m in MUTANTS:
            bad = certify_mutant(m, c, t)
            if bad == good:
                continue
            active[m] += 1
            for p, f in PROJECTIONS.items():
                kill[m][p] += f(bad) != f(good)
    return dict(active=active, killed=kill)


# ----------------------------------------------------------------------- H5
def lmp_plan(case):
    """L2 rule 'local maxima + parity passes' on complete facts.

    Candidate edges and strengths come from the frozen _Scan predicates
    (allowed/strength incl. pins, sides, WIDE, isolates, opening).  An edge's
    key is (strength, rank preference [smaller rank better, null worst],
    even-first, -index): a strict total order.  Pass 1 picks keys that beat
    both candidate neighbours; pass 2 adds even edges with no chosen
    neighbour; pass 3 adds odd edges with no chosen neighbour.  Every
    decision reads edges within distance 4 => facts within ~6 positions.
    """
    data = ref._Input(case)
    n = len(data.items)

    def dim(i):
        return data.effective(i)

    def side(i):
        f = dim(i)
        return f['side'] if f else 'UNKNOWN'

    def rank(a, b):
        e = data.edge(a, b)
        return e.get('score') if e['status'] == 'computed' else None
    sc = ref._Scan(n, data.settings, dim, side, side, rank)
    cand = [i for i in range(n - 1) if sc.allowed(i)]
    cs = set(cand)

    def key(i):
        r = rank(i, i + 1)
        return (sc.strength(i), 0 if r is None else 1, -(r if r is not None else 0), i % 2 == 0, -i)
    chosen = set()
    for i in cand:
        k = key(i)
        if all((j not in cs) or key(j) < k for j in (i - 1, i + 1)):
            chosen.add(i)
    for parity in (0, 1):
        for i in cand:
            if i % 2 == parity and i not in chosen and i - 1 not in chosen and i + 1 not in chosen:
                chosen.add(i)
    units, i = [], 0
    while i < n:
        if i in chosen:
            units.append(dict(slots=[dict(item=i, slot=sc.leading), dict(item=i + 1, slot=sc.trailing)],
                              certain=sc.known(i) and sc.known(i + 1), reason=None))
            i += 2
            continue
        if n == 1:
            reason = 'ONLY'
        elif sc.wide(i):
            reason = 'WIDE'
        elif i == 0:
            reason = 'FIRST'
        elif i in sc.forced:
            reason = 'ISOLATE'
        elif i == n - 1:
            reason = 'TAIL'
        elif sc.wide(i + 1) and sc.wide(i - 1):
            reason = 'BETWEEN_WIDE'
        elif sc.wide(i + 1):
            reason = 'BEFORE_WIDE'
        else:
            reason = 'LOCAL_UNMATCHED'
        s = sc.side(i)
        slot = 'ALL' if reason in ('WIDE', 'ONLY') else (s if s in ('A', 'B') else
               (sc.leading if reason in ('ISOLATE', 'TAIL', 'BEFORE_WIDE') else
                sc.trailing if reason == 'FIRST' else 'ALL'))
        units.append(dict(slots=[dict(item=i, slot=slot)], certain=sc.known(i), reason=reason))
        i += 1
    return units


def plan_members(plan):
    m = {}
    for u in plan:
        it = tuple(s['item'] for s in u['slots'])
        for x in it:
            m[x] = it
    return m


# ----------------------------------------------------------------------- H3
def cache_misses(seq, k, policy):
    """Misses of a target memo of capacity k (FIFO = frozen insertion queue)."""
    from collections import OrderedDict
    cache, misses = OrderedDict(), 0
    for idx, t in enumerate(seq):
        if t in cache:
            if policy == 'lru':
                cache.move_to_end(t)
            continue
        misses += 1
        if len(cache) >= k:
            if policy in ('fifo', 'lru'):
                cache.popitem(last=False)
            elif policy == 'opt':                         # Belady (offline, sees the future)
                def nxt(x):
                    for j in range(idx + 1, len(seq)):
                        if seq[j] == x:
                            return j
                    return 10 ** 9
                victim = max(cache, key=nxt)
                del cache[victim]
        cache[t] = True
    return misses


# ----------------------------------------------------------------------- H2
def ddmin(events, cost_ratio, threshold):
    """Greedy delta-debugging: shrink `events` while cost_ratio(events) > threshold."""
    cur = list(events)
    chunk = max(1, len(cur) // 2)
    while chunk >= 1:
        i, changed = 0, False
        while i < len(cur):
            trial = cur[:i] + cur[i + chunk:]
            if trial and cost_ratio(trial) > threshold:
                cur = trial
                changed = True
            else:
                i += chunk
        if not changed:
            chunk //= 2
    return cur
