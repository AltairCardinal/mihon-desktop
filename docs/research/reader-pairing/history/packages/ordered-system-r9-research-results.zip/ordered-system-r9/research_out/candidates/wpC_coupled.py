"""WP-C coupled consumers (D4 candidates; abstract service model + local compute).

IndexedSession (mode 'I'): a lazily built full-information index used as a
  partial-information consumer.  Gate (current admitted evidence only): every
  position in [0, t+3] has an accepted computed analysis with valid geometry and
  every adjacent pair (a, a+1), a <= t+2, whose endpoints are both NARROW has a
  computed rank record.  Lemma C-I1 (proofs/wpC.md): under this gate the unit
  of t is identical in every completion (all facts the scan reads for positions
  <= t are fixed), so the index answer is a sound certificate; its support is
  the same typed key range as strong certificates.  Otherwise it falls back to
  the corrected L0 owner.  The index is maintained from owner deltas (dirty
  positions) and dropped on replace/rebind (identity ticket change).
SelectorSession (mode 'SEL'): per request choose index (gate) / strong tree
  (rank-only gate) / L0 + acquisition.  Advice affects cost only.
IndexedRunner: coupled_runner.Runner with policies 'indexed' and 'selector'.
"""
import bisect
from copy import deepcopy

import paths  # noqa: F401
import transducer as T
from coupled_runner import Runner, gate_rank_only
from strong import StrongSession, support_keys
from wpC_structures import LazyTree, _Base


class _OwnerIndex(LazyTree):
    """LazyTree over the owner's live case (complete semantics) plus gate sets."""

    def __init__(self, owner_case):
        _Base.__init__(self, {'items': [], 'settings': {}})
        self.F = T.Facts(owner_case, 'complete')      # shares the owner's case object
        self.F_case = owner_case
        self.ctx = T.Ctx(self.F)
        self.n = self.F.n
        size = 1
        while size < max(1, self.n):
            size *= 2
        self.size, self.leaves, self.nodes = size, [None] * self.n, [None] * (2 * size)
        self.bad_pos, self.bad_edge = [], []
        for p in range(self.n):
            if not self._pos_ok(p):
                self.bad_pos.append(p)
        for a in range(self.n - 1):
            if not self._edge_ok(a):
                self.bad_edge.append(a)

    def _pos_ok(self, p):
        a = self.F.ix.analysis(p)
        return a[0] == 'computed' and T._valid(a[1], self.F.ix.ident(p))

    def _edge_ok(self, a):
        fa, fb = self.F.ix.analysis(a), self.F.ix.analysis(a + 1)
        if fa[0] != 'computed' or fb[0] != 'computed':
            return False                     # covered by bad_pos anyway
        if fa[1][0] == 'WIDE' or fb[1][0] == 'WIDE':
            return True                      # structural computed null
        r = self.F.records.get(a)
        return r is not None and r.get('status') == 'computed'

    @staticmethod
    def _set(lst, x, ok):
        j = bisect.bisect_left(lst, x)
        present = j < len(lst) and lst[j] == x
        if ok and present:
            del lst[j]
        elif not ok and not present:
            lst.insert(j, x)

    def refresh(self, items, edges):
        for p in items:
            self.F.set_item(p, self.F_case['items'][p])
        recs = {(e['first'], e['second']): e for e in self.F_case.get('edges', [])}
        for a in edges:
            self.F.set_edge(a, recs.get((a, a + 1)))
        touched = set(items) | set(edges)
        for p in touched:
            for i in range(max(0, p - 3), min(self.n, p + 2)):
                self._invalidate(i)
        for p in items:
            self._set(self.bad_pos, p, self._pos_ok(p))
        for x in touched:
            for a in (x - 1, x):
                if 0 <= a < self.n - 1:
                    self._set(self.bad_edge, a, self._edge_ok(a))

    def gate(self, t):
        hi = min(self.n - 1, t + 3)
        j = bisect.bisect_left(self.bad_pos, 0)
        if j < len(self.bad_pos) and self.bad_pos[j] <= hi:
            return False
        if self.bad_edge and self.bad_edge[0] <= min(self.n - 2, t + 2):
            return False
        return True


class IndexedSession(StrongSession):
    def __init__(self, case, **kw):
        super().__init__(case, **kw)
        self._index_obj = None
        self._index_ticket = None
        self._dirty_items, self._dirty_edges = set(), set()
        orig = self.owner.apply

        def apply(**kwargs):
            changed = orig(**kwargs)
            for i in (kwargs.get('item_updates') or {}):
                self._dirty_items.add(i)
            for (a, b) in (kwargs.get('edge_updates') or {}):
                if b == a + 1:
                    self._dirty_edges.add(a)
            if kwargs.get('settings') is not None or 'generation' in kwargs or 'order_revision' in kwargs:
                self._index_obj = None
            return changed
        self.owner.apply = apply

    def _index_ready(self):
        if self._index_obj is None or self._index_ticket is not self.owner._identity_ticket \
                or self._index_obj.F_case is not self.owner._case:
            self._index_obj = _OwnerIndex(self.owner._case)
            self._index_ticket = self.owner._identity_ticket
            self._dirty_items.clear(); self._dirty_edges.clear()
            self.metrics['index_builds'] += 1
        elif self._dirty_items or self._dirty_edges:
            self._index_obj.refresh(sorted(self._dirty_items), sorted(self._dirty_edges))
            self._dirty_items.clear(); self._dirty_edges.clear()
        return self._index_obj

    def certify(self, target, *, mode='L0', budget=None):
        if mode not in ('I', 'SEL'):
            return super().certify(target, mode=mode, budget=budget)
        idx = self._index_ready()
        before = idx.work['leaf_evals']
        if idx.gate(target):
            unit = idx.unit(target)
            self.metrics['index_answers'] += 1
            self.metrics['index_leaf_evals'] += idx.work['leaf_evals'] - before
            n = len(self.owner._case['items'])
            index = self.owner._index()
            support = {k: self.owner._read(index, k) for k in support_keys(n, target)}
            self._next_certificate += 1
            h = self._next_certificate
            self._certs[h] = dict(target=target, unit=deepcopy(unit), guard=self.owner._guard(), epoch=self.epoch,
                                  support=support)
            return dict(status='certified', unit=deepcopy(unit), needs=[], failures={}, first=0, steps=0,
                        dependent_items=list(range(0, min(n - 1, target + 3) + 1)), certificate=h, route='index')
        self.metrics['index_gate_misses'] += 1
        if mode == 'I':
            return super().certify(target, mode='L0', budget=budget)
        base = super().certify(target, mode='L0', budget=budget)
        if base['status'] == 'need_facts' and gate_rank_only(self, target, base):
            return super().certify(target, mode='S', budget=budget)
        return base

    def rebind(self, case, **kw):
        super().rebind(case, **kw)
        self._index_obj = None


class IndexedRunner(Runner):
    def __init__(self, trace, **kw):
        policy = kw.get('policy')
        super().__init__(trace, **{k: v for k, v in kw.items()})
        if policy in ('indexed', 'selector'):
            self.session = IndexedSession(trace['initial'], capacity=kw.get('capacity', 3),
                                          raw_capacity=kw.get('raw_capacity', 3), strong=kw.get('strong'))

    def drive(self):
        if self.policy not in ('indexed', 'selector'):
            return super().drive()
        t = self.active
        if t is None or t in self.first_pub:
            return
        v = self.session.certify(t, mode='I' if self.policy == 'indexed' else 'SEL')
        if v['status'] == 'certified':
            if v.get('route') == 'index':
                self.c['index_wins'] = self.c.get('index_wins', 0) + 1
            self._publish(t, v)
        else:
            self._acquire_needs(v)
