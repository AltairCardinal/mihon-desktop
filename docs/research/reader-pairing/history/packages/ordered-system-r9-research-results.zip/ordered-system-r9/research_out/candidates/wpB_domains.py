"""B02/D01/D02/D03/D06/X03/X10: rank-domain reasoning (WP-B).

Route A (existing, r8 transducer.feasible): symbolic order constraints checked on
a finite candidate set (exact adjacent doubles / int+-1 / grid neighbours).
Route B (this file): quantized-domain BITSETS.  Every unknown non-null rank is a
Python int bitmask over grid indices m (value m/50, 0<=m<=1499) intersected with
an optional realizability mask (e.g. E02: repeated rows make every rank an
integer).  Constraints are outcomes of strict '<' between ranks/knowns, so
bounds propagation on bitsets to a fixpoint decides feasibility exactly
(difference constraints over a finite total order; proofs/wpB.md D-1).

D03: evidence-source tagged domain selection.  A narrow domain is used only if
EVERY known rank in the case carries a provenance tag admitted by that domain;
numeric shape alone never selects a narrow domain.
"""
import bisect
import math
from functools import lru_cache

import paths  # noqa: F401
import transducer as T

GRID = [m / 50 for m in range(1500)]
FULL = (1 << 1500) - 1


def mask_lt(k):
    """grid indices m with GRID[m] < k (exact Python comparison)."""
    j = bisect.bisect_left(GRID, k) if not (isinstance(k, float) and math.isnan(k)) else 0
    # bisect on floats; ints compare exactly with floats in Python
    while j > 0 and not GRID[j - 1] < k:
        j -= 1
    while j < 1500 and GRID[j] < k:
        j += 1
    return (1 << j) - 1


def mask_gt(k):
    j = 0
    j = bisect.bisect_right(GRID, k)
    while j < 1500 and not GRID[j] > k:
        j += 1
    while j > 0 and GRID[j - 1] > k:
        j -= 1
    return FULL & ~((1 << j) - 1)


def _lowbit(m):
    return (m & -m).bit_length() - 1


def _highbit(m):
    return m.bit_length() - 1


@lru_cache(maxsize=65536)
def feasible_bits(constraints, domain_mask=FULL, edge_masks=frozenset()):
    """constraints: frozenset of ((x, y), outcome) meaning (x < y) == outcome;
    terms ('e', edge) unknown non-null rank, ('k', value) known.
    edge_masks: frozenset of (edge, mask) per-edge realizability masks (X10)."""
    vars_ = sorted({t[1] for (xy, _) in constraints for t in xy if t[0] == 'e'})
    em = dict(edge_masks)
    dom = {v: domain_mask & em.get(v, FULL) for v in vars_}
    if any(not m for m in dom.values()):
        return False
    for (x, y), out in constraints:
        if x[0] == 'k' and y[0] == 'k':
            if (x[1] < y[1]) != out:
                return False
    changed = True
    while changed:
        changed = False
        for (x, y), out in constraints:
            # out: x < y ; not out: x >= y  i.e. y <= x
            lo_t, hi_t = (x, y) if out else (y, x)       # lo_t < hi_t (strict) or lo_t <= hi_t
            strict = out
            if lo_t[0] == 'e':
                if hi_t[0] == 'e':
                    hm = dom[hi_t[1]]
                    if not hm:
                        return False
                    top = _highbit(hm)
                    lim = (1 << (top if strict else top + 1)) - 1
                else:
                    lim = mask_lt(hi_t[1]) if strict else FULL & ~mask_gt(hi_t[1])
                new = dom[lo_t[1]] & lim
                if new != dom[lo_t[1]]:
                    dom[lo_t[1]] = new
                    changed = True
                if not new:
                    return False
            if hi_t[0] == 'e':
                if lo_t[0] == 'e':
                    lm = dom[lo_t[1]]
                    if not lm:
                        return False
                    bot = _lowbit(lm)
                    lim = FULL & ~((1 << (bot + 1 if strict else bot)) - 1)
                else:
                    lim = mask_gt(lo_t[1]) if strict else FULL & ~mask_lt(lo_t[1])
                new = dom[hi_t[1]] & lim
                if new != dom[hi_t[1]]:
                    dom[hi_t[1]] = new
                    changed = True
                if not new:
                    return False
    return all(dom[v] for v in vars_)


def integer_rank_mask():
    """E02: realizability mask when every element of a witness vector repeats
    (h=1: all 50 rows identical => m multiple of 50 => integer ranks 0..29)."""
    m = 0
    for q in range(0, 1500, 50):
        m |= 1 << q
    return m


INT_MASK = integer_rank_mask()


def install_bitset_domain(mask=FULL, name='G0bits', edge_masks=None):
    """Make transducer.feasible use the bitset route for domain `name`."""
    orig = T.feasible
    em = frozenset((edge_masks or {}).items())

    def feas(constraints, domain):
        if domain == name:
            return feasible_bits(constraints, mask, em)
        return orig(constraints, domain)
    T.feasible = feas
    orig_in = T._in_domain

    def in_dom(s, domain):
        if domain == name:
            if isinstance(s, bool) or not isinstance(s, (int, float)) or not math.isfinite(s):
                return False
            if not 0 <= s <= 29.98 or abs(s * 50 - round(s * 50)) > 1e-9:
                return False
            return bool(mask >> int(round(s * 50)) & 1)
        return orig_in(s, domain)
    T._in_domain = in_dom
    return orig, orig_in


def uninstall(saved):
    T.feasible, T._in_domain = saved


# ---------------------------------------------------------------- D03
SOURCE_DOMAIN = {'operator': 'G0', 'adapter': 'nonneg'}


def select_domain(case, requested='G0'):
    """Narrow domain only if every known rank carries an admitted provenance tag
    and its value is inside the domain; otherwise widen (nonneg if all >=0 and
    tagged adapter/operator, else ext).  Returns (domain, reason)."""
    tags, vals = set(), []
    for e in case.get('edges', []):
        if e.get('status') == 'computed' and e.get('score') is not None:
            tags.add(e.get('source'))
            vals.append(e['score'])
    if not vals:
        return requested, 'no-known-ranks'
    if requested == 'G0' and tags <= {'operator'} and all(T._in_domain(v, 'G0') for v in vals):
        return 'G0', 'all-operator-tagged'
    if requested in ('G0', 'nonneg') and tags <= {'operator', 'adapter'} and all(T._in_domain(v, 'nonneg') for v in vals):
        return 'nonneg', 'tagged-nonneg'
    return 'ext', 'untagged-or-out-of-domain'


def shape_domain(case):
    """Unsafe control: guesses the domain from numeric shape only."""
    vals = [e['score'] for e in case.get('edges', []) if e.get('status') == 'computed' and e.get('score') is not None]
    if vals and all(T._in_domain(v, 'G0') for v in vals):
        return 'G0'
    if vals and all(v >= 0 for v in vals):
        return 'nonneg'
    return 'ext'


# ---------------------------------------------------------------- D06
def decimal_vs_binary64_case():
    """Two JSON number literals that are different decimals but the same
    binary64 value; an exact-decimal consumer and a binary64 consumer reach
    different plans on the same text (minimal 5-object chain)."""
    import json
    from decimal import Decimal
    text = ('{"edges":[{"first":1,"second":2,"status":"computed","score":0.30000000000000001},'
            '{"first":2,"second":3,"status":"computed","score":0.3}]}')
    as_float = json.loads(text)
    as_dec = json.loads(text, parse_float=Decimal)
    return text, as_float, as_dec
