"""WP-C D3 registration (formal timing is run only by the main session via drive_formal.py).

Families (FAMILY_CANDIDATES gives the candidates per scenario; [0] = incumbent):
  struct_*    complete-information plan maintenance + point queries
              incumbent r8tree (eager tree = frontier route reproduction)
  rope_*      order changes (insert/delete) - incumbent full rebuild after every change
  diff_*      plan output after every update - incumbent full output; candidate = NEW diff API
  consumer_*  mixed point/full/prefix consumers - incumbent scan_only
  witness_*   adjacent rank derivation - incumbent OPTIMIZED_OPERATOR per pair
  coupled_*   coupled acquisition->publication runs (virtual u) - incumbent L0 policy
ok = answers identical to an exact reference computed outside timing (structure families),
identical published units and zero wrong publications (coupled family).
"""
import copy
import hashlib
import json
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
from common import roundtrip, random_case  # noqa: E402
import wpC_structures as S  # noqa: E402
import wpC_select as SEL  # noqa: E402
import wpC_output as OUT  # noqa: E402
import wpC_witness as WIT  # noqa: E402
import wpC_experiments as E  # noqa: E402

STRUCT_CANDS = ['r8tree', 'r8resync', 'prefixscan', 'lazytree', 'sparsecp', 'dirtylog', 'hybrid', 'skirental', 'skikeep']
CLASSES = dict(r8tree=(E.R8Tree, {}), r8resync=(E.R8Resync, {}), prefixscan=(S.PrefixScan, {}), lazytree=(S.LazyTree, {}),
               sparsecp=(S.SparseCheckpoints, {'K': 16}), dirtylog=(S.DirtyLogTree, {'cap': 64}),
               hybrid=(S.Hybrid, {'cap': 32, 'quiet_to_demote': 8}), skirental=(SEL.SkiRental, {'alpha': 1.0}),
               skikeep=(SEL.SkiKeep, {'alpha': 1.0}))

SCENARIOS = []
for n in (256, 1024):
    SCENARIOS += [dict(name=f'struct_n{n}_random_jump', fam='struct', n=n, kind='random', pattern='jump', q=1.0),
                  dict(name=f'struct_n{n}_random_hot', fam='struct', n=n, kind='random', pattern='hot', q=1.0),
                  dict(name=f'struct_n{n}_W03_sparse', fam='struct', n=n, kind='random', pattern='jump', q=0.02),
                  dict(name=f'struct_n{n}_alternating_short', fam='struct', n=n, kind='phases',
                       phases=[('flip', 8), ('chainlocal', 8)] * 20),
                  dict(name=f'struct_n{n}_flip_then_local', fam='struct', n=n, kind='phases',
                       phases=[('flip', 100), ('chainlocal', 200)])]
SCENARIOS += [dict(name='rope_n1024', fam='rope', n=1024), dict(name='rope_n256', fam='rope', n=256),
              dict(name='diff_n1024_local', fam='diff', n=1024, kind='local'), dict(name='diff_n1024_flip', fam='diff', n=1024, kind='flip'),
              dict(name='consumer_n512_switching', fam='consumer', n=512),
              dict(name='witness_near_fan2', fam='witness', spread=8, fan=2), dict(name='witness_far_fan2', fam='witness', spread=160, fan=2),
              dict(name='witness_mixed_fan2', fam='witness', spread=None, fan=2), dict(name='witness_near_fan0', fam='witness', spread=8, fan=0),
              dict(name='coupled_W01_n96', fam='coupled', wfam='W01', kw=dict(n=96)),
              dict(name='coupled_RP_n64_dense', fam='coupled', wfam='RP', kw=dict(n=64, pa=0.95, pe=0.95)),
              dict(name='coupled_W05_n64', fam='coupled', wfam='W05', kw=dict(n=64, holes=2)),
              dict(name='coupled_W06', fam='coupled', wfam='W06', kw={})]
CANDIDATES = STRUCT_CANDS


def FAMILY_CANDIDATES(sc):
    return dict(struct=STRUCT_CANDS, rope=['rebuild', 'rope'], diff=['fulloutput', 'diffplan'],
                consumer=['scan_only', 'dedicated', 'shared'],
                witness=['separate', 'fused_eager', 'fused_lazy', 'fused_prefix'],
                coupled=['incumbent', 'indexed', 'selector', 'gated'])[sc['fam']]


_CACHE = {}


def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str).encode()).hexdigest()


def _struct_trace(sc):
    key = sc['name']
    if key not in _CACHE:
        n = sc['n']
        if sc['kind'] == 'random':
            case = roundtrip(random_case(random.Random(n), n, p_wide=0.12, domain='G0', settings_mix=False))
            ev = E.make_events(case, random.Random(n + 7), 200, sc['q'], sc['pattern'])
        else:
            case, ev = E.phase_events(n, random.Random(n + 3), sc['phases'])
        truth = E.run(S.PrefixScan, case, ev, sample_res=False)['answers_sha']
        _CACHE[key] = (case, ev, truth)
    return _CACHE[key]


def run_one(sc, cand, rep):
    fam = sc['fam']
    if fam == 'struct':
        case, ev, truth = _struct_trace(sc)
        cls, kw = CLASSES[cand]
        r = E.run(cls, case, ev, kw, sample_res=True)
        return dict(wall_ns=int(r['wall_ms'] * 1e6), verdict_sha256=r['answers_sha'], ok=r['answers_sha'] == truth,
                    work=dict(r['raw_work'], work_units=r['work'], peak_residency=r['peak_residency']))
    if fam == 'rope':
        return _rope(sc, cand)
    if fam == 'diff':
        return _diff(sc, cand)
    if fam == 'consumer':
        return _consumer(sc, cand)
    if fam == 'witness':
        return _witness(sc, cand)
    return _coupled(sc, cand)


def _rope(sc, cand):
    import incremental as I8
    from common import fact, ref, unit_of
    n = sc['n']
    rng = random.Random(n)
    case = roundtrip(random_case(rng, n, p_wide=0.12, domain='G0', settings_mix=False))
    ops = []
    for k in range(30):
        p = rng.randrange(1, n - 1)
        if k % 2 == 0:
            ops.append(('ins', p, dict(id=f'x{k}', header=fact(), analysis=dict(status='computed', fact=fact('NARROW', 'A'), version=1)),
                        dict(status='computed', score=3.0, version=1), dict(status='computed', score=4.0, version=1)))
        else:
            ops.append(('del', p, dict(status='computed', score=2.0, version=1)))
    qs = [random.Random(k).randrange(n - 2) for k in range(len(ops))]
    ans = []
    t0 = time.perf_counter_ns()
    if cand == 'rope':
        r = S.RopePlan(case, B=32)
        for op, q in zip(ops, qs):
            (r.insert(op[1], copy.deepcopy(op[2]), op[3], op[4]) if op[0] == 'ins' else r.delete(op[1], op[2]))
            ans.append(r.unit(q))
        work = dict(r.work)
    else:
        cur = copy.deepcopy(case)
        work = {'leaf_evals': 0}
        for op, q in zip(ops, qs):
            cur = E.rope_mirror(cur, op)
            tp = I8.TreePlan(cur)
            work['leaf_evals'] += tp.work.get('leaf_evals', 0)
            ans.append(tp.unit(q))
    wall = time.perf_counter_ns() - t0
    key = 'rope_truth_' + sc['name']
    if key not in _CACHE:
        cur = copy.deepcopy(case)
        tr = []
        for op, q in zip(ops, qs):
            cur = E.rope_mirror(cur, op)
            tr.append(unit_of(ref.complete_plan(cur), q))
        _CACHE[key] = _sha(tr)
    return dict(wall_ns=wall, verdict_sha256=_sha(ans), ok=_sha(ans) == _CACHE[key], work=work)


def _diff(sc, cand):
    n = sc['n']
    case = E.chain_case(n) if sc['kind'] == 'flip' else roundtrip(random_case(random.Random(n), n, p_wide=0.12, domain='G0', settings_mix=False))
    ev = E.make_events(case, random.Random(3), 100, 0, 'jump', sc['kind'])
    t0 = time.perf_counter_ns()
    if cand == 'diffplan':
        d = OUT.DiffPlan(case)
        out = 0
        for e in ev:
            (d.set_item if e[0] == 'item' else d.set_edge)(e[1], copy.deepcopy(e[2]))
            out += len(d.last_diff)
        final = [d.cover[i] for i in range(n)]
        work = dict(d.work, output_entries=out)
    else:
        f = S.PrefixScan(case)
        out = 0
        for e in ev:
            (f.set_item if e[0] == 'item' else f.set_edge)(e[1], copy.deepcopy(e[2]))
            plan = f.plan(); out += len(plan)
        final = [next(u for u in plan if any(s['item'] == i for s in u['slots'])) for i in range(n)]
        work = dict(f.work, output_entries=out)
    wall = time.perf_counter_ns() - t0
    key = 'difftruth' + sc['name']
    if cand == 'fulloutput':
        _CACHE[key] = _sha(final)
    elif key not in _CACHE:                 # incumbent output computed outside this candidate's timing
        _diff(sc, 'fulloutput')
    return dict(wall_ns=wall, verdict_sha256=_sha(final), ok=_CACHE[key] == _sha(final), work=work)


def _consumer(sc, cand):
    n = sc['n']
    case = roundtrip(random_case(random.Random(8), n, p_wide=0.12, domain='G0', settings_mix=False))
    ev = E.mixed_consumer_events(case, random.Random(1), [('point', 100), ('full', 20), ('prefix', 60), ('point', 100)])
    cls = dict(scan_only=E.ScanOnly, dedicated=E.Dedicated, shared=E.Shared)[cand]
    t0 = time.perf_counter_ns()
    m = cls(case)
    outs = []
    for e in ev:
        if e[0] == 'item':
            m.set_item(e[1], copy.deepcopy(e[2]))
        elif e[0] == 'point':
            outs.append(m.point(e[1]))
        elif e[0] == 'full':
            outs.append(len(m.full()))
        else:
            outs.append(len(m.prefix(e[1])))
    wall = time.perf_counter_ns() - t0
    key = 'cons' + sc['name']
    if cand == 'scan_only':
        _CACHE[key] = _sha(outs)
    elif key not in _CACHE:
        _consumer(sc, 'scan_only')
    return dict(wall_ns=wall, verdict_sha256=_sha(outs), ok=_CACHE[key] == _sha(outs), work=dict(work_units=m.wu()))


def _witness(sc, cand):
    from collections import Counter
    r2 = random.Random(7)
    batches = []
    for trial in range(60):
        ws = [WIT.random_witness(r2, spread=sc['spread'] if sc['spread'] else r2.choice((8, 160))) for _ in range(6)]
        pairs = [(i, i + 1) for i in range(5)] if sc['fan'] == 2 else []
        batches.append((ws, pairs))
    c = Counter()
    t0 = time.perf_counter_ns()
    vals = []
    for ws, pairs in batches:
        if cand == 'separate':
            vals.append(WIT.separate_ranks(ws, pairs, c))
        elif cand == 'fused_prefix':
            vals.append(WIT.prefix_ranks(ws, pairs, c))
        else:
            vals.append(WIT.fused_ranks(ws, pairs, c, eager=(cand == 'fused_eager')))
    wall = time.perf_counter_ns() - t0
    v = _sha([sorted((str(k), x) for k, x in d.items()) for d in vals])
    key = 'wit' + sc['name']
    if key not in _CACHE:
        _CACHE[key] = _sha([sorted((str(k), WIT.OP.score(ws[k[0]], ws[k[1]])) for k in pairs) for ws, pairs in batches])
    return dict(wall_ns=wall, verdict_sha256=v, ok=v == _CACHE[key], work=dict(c))


def _coupled(sc, cand):
    import workloads as W
    import wpC_coupled as WC
    tr = W.FAMILIES[sc['wfam']](100, **sc['kw'])
    t0 = time.perf_counter_ns()
    r = WC.IndexedRunner(tr, policy=cand, service_u=3, q_u=0, strong=dict(kind='tree', domain='nonneg', gate='raw')).run()
    wall = time.perf_counter_ns() - t0
    work = {k: r[k] for k in ('physical_admissions', 'certification_steps', 'strong_certificates', 'total_latency_u', 'published')}
    work['index_wins'] = r.get('index_wins', 0)
    return dict(wall_ns=wall, verdict_sha256=_sha(sorted(r['latency_u'].items())), ok=r['wrong'] == 0, work=work)
