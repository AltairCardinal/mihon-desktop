"""C-I1 radius check: index gate with fixed prefix [0, t+r] (edges a <= t+r-1); count completions
whose unit(t) differs from the partial-index answer.  r=3 is the implemented gate."""
import copy, json, random
from pathlib import Path
import paths  # noqa
from common import ref, random_case, roundtrip, unit_of, fact, SIDES, rank_value
import wpC_coupled as WC


def run(r, trials=150, comps=6, seed=11):
    rng = random.Random(seed)
    bad = tot = 0
    for _ in range(trials):
        n = rng.randrange(12, 30)
        full = roundtrip(random_case(rng, n, p_wide=0.2, domain='G0', settings_mix=False))
        for it in full['items']:
            st = 'WIDE' if rng.random() < 0.2 else 'NARROW'
            it['header'] = fact(st); it['analysis'] = dict(status='computed', fact=fact(st, rng.choice(SIDES)), version=1)
        full['edges'] = [dict(first=i, second=i + 1, status='computed', score=rank_value(rng, 'G0'), version=1) for i in range(n - 1)]
        t = rng.randrange(0, n - 5)
        part = copy.deepcopy(full)
        for p in range(t + r + 1, n):
            part['items'][p]['analysis'] = dict(status='unknown')
        part['edges'] = [e for e in part['edges'] if e['first'] <= t + r - 1]
        got = WC._OwnerIndex(part).unit(t)
        for _ in range(comps):
            comp = copy.deepcopy(part)
            for p in range(t + r + 1, n):
                st = 'WIDE' if rng.random() < 0.3 else 'NARROW'
                comp['items'][p]['header'] = fact(st)
                comp['items'][p]['analysis'] = dict(status='computed', fact=fact(st, rng.choice(SIDES)), version=2)
            comp['edges'] += [dict(first=a, second=a + 1, status='computed', score=rank_value(rng, 'G0'), version=2)
                              for a in range(t + r, n - 1)]
            tot += 1
            bad += got != unit_of(ref.complete_plan(comp), t)
    return dict(radius=r, completions=tot, mismatches=bad)


if __name__ == '__main__':
    rows = [run(r) for r in (0, 1, 2, 3)]
    print(rows)
    (Path(__file__).resolve().parents[1] / 'results/raw/wpC/C_I1_radius.json').write_text(json.dumps(rows, indent=1))
