"""Coupled acquisition -> certification -> publication runner with policies.

Layer: abstract service model (virtual units `u`) + local measured compute
(ns, reported separately, never added to `u`).  Built only on the public
Session API plus StrongSession.  The controller never sees World.

Policies (controller decisions use only admitted evidence and own tasks):
  incumbent    L0 verdict; acquire every need (both endpoints of rank needs)
  proof_first  L0; if need_facts run a strong attempt that BLOCKS the controller
               for q_u virtual units; acquire needs only if it fails
  race         L0; issue the L0 acquisitions immediately AND run the strong
               attempt in parallel (q_u); on success cancel the still-running
               tasks (nonpreemptible: slots stay occupied until finish)
  gated        proof_first, but the strong attempt runs only if the gate
               predicate (current local statistics only) says so
  strong_only  strong attempt with q_u = 0 (idealised upper bound; labelled)

Events (all integer virtual time):
  exogenous: ('target', t) intent, ('tick',)
  endogenous: service completion at admit+service_u (finish+consume),
              proof completion at start+q_u
Ground truth: every publication is compared with the complete plan of the
hidden world (wrong publications are counted, never silently dropped).
"""
import heapq
from copy import deepcopy
from itertools import count

import paths  # noqa: F401
import reference as ref
from coupling import World, Witness
from strong import StrongSession


def world_case(initial, witnesses):
    """Complete case implied by the hidden witnesses under the scalar adapter."""
    c = deepcopy(initial)
    for i, w in enumerate(witnesses):
        c['items'][i]['analysis'] = deepcopy(w['analysis'])
    edges = []
    n = len(c['items'])
    for a in range(n - 1):
        wa, wb = witnesses[a], witnesses[a + 1]
        if wa['analysis'].get('status') != 'computed' or wb['analysis'].get('status') != 'computed':
            continue
        if not wa.get('available', True) or not wb.get('available', True):
            continue
        ra, rb = wa.get('raw'), wb.get('raw')
        edges.append(dict(first=a, second=a + 1, status='computed',
                          score=None if ra is None or rb is None else abs(ra - rb), version=1))
    c['edges'] = edges
    return c


def truth_units(initial, witnesses):
    plan = ref.complete_plan(world_case(initial, witnesses))
    out = {}
    for u in plan:
        for s in u['slots']:
            out[s['item']] = u
    return out


def gate_rank_only(session, target, verdict):
    """A02 gate using current admitted facts only: upgrade only when every need is
    a RANK need and every item in [0, t+3] already has a computed analysis
    (the bounded-raw-eviction pattern W05)."""
    if any(nd['kind'] != 'RANK' for nd in verdict['needs']):
        return False
    case = session.owner._case
    n = len(case['items'])
    for p in range(0, min(n - 1, target + 3) + 1):
        if case['items'][p].get('analysis', {}).get('status') != 'computed':
            return False
    return True


class Runner:
    def __init__(self, trace, *, policy='incumbent', service_u=3, q_u=0, capacity=3, raw_capacity=3,
                 strong=None, gate=gate_rank_only):
        self.trace = trace
        self.policy, self.service_u, self.q_u = policy, service_u, q_u
        self.world = World([Witness(**w) for w in trace['world']])
        self.session = StrongSession(trace['initial'], capacity=capacity, raw_capacity=raw_capacity,
                                     strong=strong)
        self.truth = truth_units(trace['initial'], trace['world'])
        self.gate = gate
        self.now = 0
        self.q = []                      # (time, seq, kind, payload)
        self.seq = count()
        self.scheduled = set()
        self.intent = {}                 # target -> intent time
        self.first_pub = {}              # target -> time of first legal publication
        self.active = None
        self.blocked_until = -1          # proof_first: controller busy
        self.proof_pending = None        # race: (target, verdict) awaiting proof completion
        self.wrong = 0
        self.log = []
        self.c = dict(proof_starts=0, proof_wins=0, race_cancels=0, gate_skips=0, retries=0)

    # ------------------------------------------------------------ helpers
    def _push(self, t, kind, payload):
        heapq.heappush(self.q, (t, next(self.seq), kind, payload))

    def _schedule_tasks(self):
        for token, task in self.session._tasks.items():
            if token not in self.scheduled and task['phase'] == 'running':
                self.scheduled.add(token)
                self._push(self.now + self.service_u, 'service', (token, task['item']))

    def _acquire_needs(self, verdict):
        for nd in verdict['needs']:
            self.session.acquire(nd['item'])
            if 'second' in nd:
                self.session.acquire(nd['second'])
        if verdict['status'] == 'blocked':
            for k in verdict['failures']:
                self.session.acquire(int(k))
        self._schedule_tasks()

    def _publish(self, target, verdict):
        r = self.session.publish(target, verdict['certificate'])
        if r == 'published' and target not in self.first_pub:
            self.first_pub[target] = self.now
            if verdict['unit'] != self.truth[target]:
                self.wrong += 1
        return r

    # ------------------------------------------------------------ control
    def drive(self):
        t = self.active
        if t is None or t in self.first_pub or self.now < self.blocked_until or self.proof_pending:
            return
        pol = self.policy
        if pol == 'incumbent':
            v = self.session.certify(t, mode='L0')
            if v['status'] == 'certified':
                self._publish(t, v)
            else:
                self._acquire_needs(v)
            return
        base = self.session.certify(t, mode='L0')
        if base['status'] == 'certified':
            self._publish(t, base)
            return
        if base['status'] == 'blocked':
            self._acquire_needs(base)
            return
        if pol == 'gated' and not self.gate(self.session, t, base):
            self.c['gate_skips'] += 1
            self._acquire_needs(base)
            return
        if pol == 'race':
            self._acquire_needs(base)                      # service starts now
        self.c['proof_starts'] += 1
        if self.q_u == 0 or pol == 'strong_only':
            self._finish_proof(t, base)
        else:
            self.proof_pending = (t, base)
            if pol in ('proof_first', 'gated'):
                self.blocked_until = self.now + self.q_u
            self._push(self.now + self.q_u, 'proof', (t,))

    def _finish_proof(self, t, base):
        self.proof_pending = None
        if t in self.first_pub:
            return
        v = self.session.certify(t, mode='S')
        if v['status'] == 'certified':
            if v.get('route', '').startswith('strong'):
                self.c['proof_wins'] += 1
            self._publish(t, v)
            if self.policy == 'race':                       # cancel now-unneeded work
                for token, task in list(self.session._tasks.items()):
                    if task['phase'] == 'running' and not task['cancelled']:
                        self.session.cancel(token)
                        self.c['race_cancels'] += 1
            return
        if self.policy in ('proof_first', 'gated', 'strong_only'):
            self._acquire_needs(v)

    # ------------------------------------------------------------ loop
    def run(self, horizon=10 ** 6):
        for ev in self.trace['events']:
            self._push(ev['at'], 'ext', ev)
        while self.q:
            t, _s, kind, payload = heapq.heappop(self.q)
            if t > horizon:
                break
            self.now = t
            if kind == 'service':
                token, i = payload
                self.scheduled.discard(token)
                if token in self.session._tasks:
                    self.session.finish(token, self.world.complete(i))
                    self.session.consume(token)
                self.drive()
            elif kind == 'proof':
                (tt,) = payload
                if self.proof_pending and self.proof_pending[0] == tt:
                    base = self.proof_pending[1]
                    self._finish_proof(tt, base)
                    self.blocked_until = -1
                    self.drive()
            else:
                ev = payload
                if ev['op'] == 'target':
                    self.active = ev['target']
                    self.intent.setdefault(ev['target'], t)
                    self.drive()
                elif ev['op'] == 'tick':
                    self.drive()
            self._schedule_tasks()
        s = self.session
        lat = {k: self.first_pub[k] - self.intent[k] for k in self.first_pub if k in self.intent}
        return dict(policy=self.policy, service_u=self.service_u, q_u=self.q_u,
                    published=len(self.first_pub), intents=len(self.intent), wrong=self.wrong,
                    latency_u=lat, total_latency_u=sum(lat.values()),
                    unserved=sorted(set(self.intent) - set(self.first_pub)),
                    physical_admissions=s.metrics['physical_admissions'],
                    physical_finishes=s.metrics['physical_finishes'],
                    discarded=s.metrics['discarded_completions'],
                    strong_attempts=s.metrics['strong_attempts'],
                    strong_certificates=s.metrics['strong_certificates'],
                    strong_evaluations=s.metrics['strong_evaluations'],
                    strong_ns=s.metrics['strong_ns'], certification_steps=s.metrics['certification_steps'],
                    rank_computations=s.metrics['rank_computations'], end_u=self.now, **self.c)
