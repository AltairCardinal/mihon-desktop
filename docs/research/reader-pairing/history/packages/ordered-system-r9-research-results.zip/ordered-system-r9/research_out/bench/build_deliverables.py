"""Assemble coverage.csv (150 rows + NH rows), hypotheses.csv, ADOPTION_MATRIX.csv and
source-manifest.json from the work-package parts, applying the main-session D3/D4 audit."""
import csv, hashlib, io, json
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]; ROOT = OUT.parent
HDR = next(csv.reader(open(ROOT / 'coverage-template.csv', encoding='utf-8')))
T = "python3 -m unittest discover -s research_out/tests -t research_out -p 'test_wpT.py'"

MAIN = [  # question_id, family, route_a, route_b, status, depth, implementation, proof, test, raw, domain, layer, assumptions, refutation, decision, remaining
 ('S01','S','local maxima (LMP)','global objective (max-cardinality matching)','limit_proved','D2','candidates/wpS_rules.py','no rule dominates on pairs/strength/locality/insertion stability; N06 triangle (WP-B)','python3 research_out/bench/run_wpS.py','results/raw/wpS/studies.json#S01_S02_structure','core (L2)','core','no quality truth','a rule dominating all four metrics','L2 pending adjudication','external quality judgments'),
 ('S02','S','worst-case ratio (maximal => >=1/2 max cardinality)','preference-universal statements (only dominance)','limit_proved','D2','candidates/wpS_rules.py metrics','all non-maxcard rules maximal; min pair ratio 0.5 (tight)','python3 research_out/bench/run_wpS.py','results/raw/wpS/studies.json#S01_S02_structure','core (L2)','core','pairs as proxy only','a non-maximal reference output','no data-free superiority claim possible','minimal adjudication = S05'),
 ('S03','S','new-context switch (republish all)','per-unit migration (re-sign common units)','conditional','D2','bench/run_wpS.py S03','both partitions => no transient overlap; authority per context never migrates','python3 research_out/bench/run_wpS.py','results/raw/wpS/studies.json#S03_migration','core (L2)','core','reference->LMP migration','visible churn equal for both','per-unit migration if L2 ever adopted (36.7% republish)','coupled migration run'),
 ('S04','S','restart at absolute/anchored boundaries','forced cuts (independent segments)','refuted','D2','candidates/wpS_rules.py seg/anchor/cut','restart rules do NOT bound influence (radius 94/31/95 on 96-chain); forced cuts bound radius (6/14) at -11%/-5% pairs','python3 research_out/bench/run_wpS.py','results/raw/wpS/studies.json#S04_locality,S04_cut_rules','core (L2)','core','absolute cuts move with insertions','a restart rule with bounded radius','drop restart rules; cut rules only with adjudication','quality of cut losses unknown'),
 ('S05','S','local disagreement motifs -> separating questions','hard constraints + exception overrides','conditional','D2','candidates/wpS_rules.py motifs','453 motif classes; 2 judgments separate all distinguishable rule pairs under a local-preference premise','python3 research_out/bench/run_wpS.py','results/raw/wpS/studies.json#S05_adjudication','core (L2)','core','preferences local over +-3 windows','a preference depending on non-local context','minimal adjudication 2..453 depending on locality premise','confirm locality premise'),
 ('S06','S','cost of quality truth vs L2 locality gain','in-semantics residual bound (T05)','conditional','D2','bench/run_wpS.py S06; candidates/wpT_bounds.py','reference lookback median 2 / p99 14 on random inputs; only chains grow linearly','python3 research_out/bench/run_wpS.py','results/raw/wpS/studies.json#S06_locality_gain; results/raw/wpT/t05.json','core','core','random/chain workloads','long-chain dominated workloads with adjudication','stop L2 now; stop condition stated','2 adjudications + chain workload counts'),
 ('T01','T','spec-implementation diff (NATIVE_OWNER.pseudo vs coupling.py)','causal mutation of implementation choices','implemented_verified','D2','tests/test_wpT.py Premises','P2 evict-before-derive, P3 unbound confirm, P6 exact-support expiry on refinement (all reproduced with package APIs)',T,'tests/test_wpT.py; results/raw/wpG/d4_k01_heldout.json; results/raw/wpH/d4.json','model','core/coupled','package API as specified','premises not reproducible','report to model owners; adopt derive_first, bound confirm, refresh','native confirmation of P2'),
 ('T02','T','adoption-value / verification-cost ranking','information-gain ordering','implemented_verified','D2','sections/wpS_T.md T02','recorded reopen/stop decisions per family with budget','-','sections/wpS_T.md','-','-','-','-','method kept','-'),
 ('T04','T','local lemmas + independent checker','full formalisation (cost estimate only)','implemented_verified','D2','candidates/wpT_checker.py','checker re-derives by exact DP (+worlds n<=7) and perturbs outside support; mutant rejected',T,'tests/test_wpT.py Checker','nonneg/beta','core','frozen rule trusted','a checker-accepted wrong unit','keep checker as hand-off artefact','formalisation of _Scan'),
 ('T05','T','critical-path share','unavoidable-physical-work reference (evaluator oracle)','implemented_verified','D2','candidates/wpT_bounds.py OracleRunner','W06 82->42, W01 33->15 admissions at the oracle point; RP 26->23; W05 3->2','python3 research_out/bench/run_wpT05.py','results/raw/wpT/t05.json','nonneg/beta','coupled u','oracle reads World (bound only)','oracle above incumbent','residual gain is concentrated in shared-variable ambiguity','true lower bound (oracle is a heuristic reference point)'),
 ('T06','T','12+ new hypotheses across paradigms','attack on top-3 adoption candidates','implemented_verified','D2','hypotheses.csv; REPORT section 7','30 deduplicated hypotheses; reversal conditions for gated_shadow/value_cache/gated index','-','hypotheses.csv; results/summary/formal/*','-','-','-','-','see REPORT','-'),
 ('X30','X','optimise current semantics first (A)','introduce L2 (B)','conditional','D2','sections/wpS_T.md X30','A and B substitute on physical work (negative interaction), complement on support size','python3 research_out/bench/run_wpS.py; python3 research_out/bench/run_wpT05.py','results/raw/wpS/studies.json; results/raw/wpT/t05.json','core','core/coupled','no quality truth','L2 locality gain exceeding residual in-semantics gain on target workloads','A first; reopen B only if S06 stop condition is overturned','adjudication data'),
]

OVERRIDE = {  # main-session completions of fork D1 rows
 'Q02': dict(status='conditional', depth='D2', implementation='candidates/wpM_q02_x12.py q02_study (main session)',
             proof_or_counterexample='direction flip: scalar store 78 reacquisitions vs witness store 40 (ranks are directional); stable direction: scalar 39 vs 40 at 1/56 of the bytes',
             test_command='python3 research_out/candidates/wpM_q02_x12.py (see REPRODUCE)', raw_evidence='results/raw/wpM/q02_x12.json#Q02',
             decision='persist scalars when direction/recipe stable; witnesses only if direction changes and reacquisition is expensive', remaining='persistence remains a hypothesis branch; no durable store measured'),
 'X12': dict(status='conditional', depth='D2', implementation='candidates/wpM_q02_x12.py x12_study/x12_cost (main session)',
             proof_or_counterexample='exact early-exit reads: spread 60 -> 17.1 of 50 elements; staged+progressive best when p(rank needed)<=0.5, progressive alone when rank always needed',
             raw_evidence='results/raw/wpM/q02_x12.json#X12', decision='combine (staged first open + in-stream early null) when p<=0.5', remaining='open/element costs unit-less; native costs unknown'),
}

FORMAL = {'bench_wpA', 'bench_wpB', 'bench_wpC', 'bench_wpG', 'bench_wpH'}
# D3/D4 audit: mechanisms without main-session 3-process formal timing are capped at D2.
NO_FORMAL = {'A04', 'A05', 'A06', 'F02', 'F03', 'F06', 'O01', 'O06', 'P02', 'X15', 'X21',
             'B02', 'B06', 'D03', 'N05', 'X02', 'X03', 'X04', 'X05', 'X10', 'P06',
             'G06', 'X11', 'X19', 'H01', 'H02', 'I04', 'J01', 'R05', 'X22', 'X29'}


def part_rows():
    rows = {}
    for p in sorted((OUT / 'coverage_parts').glob('*.csv')):
        for r in csv.DictReader(io.StringIO(p.read_text(encoding='utf-8'))):
            r['_part'] = p.stem
            rows[r['question_id']] = r
    return rows


def main():
    tmpl = list(csv.DictReader(open(ROOT / 'coverage-template.csv', encoding='utf-8')))
    rows = part_rows()
    for m in MAIN:
        q = m[0]
        rows[q] = dict(question_id=q, family=m[1], route_a=m[2], route_b=m[3], status=m[4], depth=m[5],
                       implementation=m[6], proof_or_counterexample=m[7], test_command=m[8], raw_evidence=m[9],
                       domain=m[10], cost_layer=m[11], assumptions=m[12], refutation_condition=m[13], decision=m[14],
                       remaining=m[15], prior_anchor='PRIOR_EVIDENCE_MAP.md', new_gap='see sections/wpS_T.md', _part='main')
    for q, o in OVERRIDE.items():
        rows[q].update(o)
    out = io.StringIO(); w = csv.DictWriter(out, fieldnames=HDR + ['work_package', 'audit_note'], extrasaction='ignore')
    w.writeheader()
    depth_count = {}
    for t in tmpl:
        q = t['question_id']; r = dict(rows[q]); r['title'] = t['title']
        note = ''
        if r['depth'] in ('D3', 'D4') and q in NO_FORMAL:
            note = f"claimed {r['depth']} by work package; capped at D2: no main-session 3-process formal timing of this mechanism"
            r['depth'] = 'D2'
        elif r['depth'] in ('D3', 'D4'):
            note = 'formal 3-process timing: results/summary/formal/FORMAL_TABLES.md' + (
                '; D4 = abstract coupled-chain evidence (virtual service units), not native' if r['depth'] == 'D4' else '')
        r['work_package'] = r.get('_part'); r['audit_note'] = note
        depth_count[r['depth']] = depth_count.get(r['depth'], 0) + 1
        w.writerow(r)
    # NH rows appended from hypotheses.csv ids
    (OUT / 'coverage.csv').write_text(out.getvalue(), encoding='utf-8')
    print('coverage rows', len(tmpl), depth_count)


if __name__ == '__main__':
    main()
