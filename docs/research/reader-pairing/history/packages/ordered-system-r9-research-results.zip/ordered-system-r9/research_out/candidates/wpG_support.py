"""G01/X18 support analysis: how far below the all-attempt union can R_policy go?

counterfactual_relevance(case, t): for every fact (analysis/header of a position,
edge record) referenced by the union support, enumerate alternative legal values
and check whether the PUBLIC 2/3 selection changes.  A fact that no alternative
can flip is redundant for R_policy (offline analysis; exponential in nothing but
alternatives per fact, single-fact changes only -> an upper bound on the union
size that can be dropped by single-key reasoning, NOT a joint-change proof).
"""
import copy

import paths  # noqa: F401
import reference as ref
import compact_core as core
from common import fact


def public(c, t):
    return {k: v for k, v in ref.certify_strategy(c, t)['selected'].items() if k != 'reads'}


def union_support(c, t):
    index = core.Index(c)
    b = core.certify(c, t, 2, index=index)
    atts = [b]
    if b['status'] == 'need_facts':
        atts.append(core.certify(c, t, 3, index=index))
    sup = {}
    for a in atts:
        sup.update(a['proof'][2])
    return sup, atts


def facts_of(support):
    out = set()
    for k in support:
        if k[0] in ('analysis', 'header'):
            out.add((k[0], k[1]))
        elif k[0] == 'dimension':
            out.add(('analysis', k[1]))
        elif k[0] == 'rank':
            out.add(('edge', k[1]))
    return out


def alternatives(c, f):
    kind, p = f
    it = c['items'][p] if kind != 'edge' else None
    alts = []
    if kind == 'analysis':
        cur = it.get('analysis', {'status': 'unknown'})
        hdr = it.get('header') or fact()
        for st in ('NARROW', 'WIDE'):
            for side in ('A', 'B', 'UNKNOWN'):
                alts.append(dict(status='computed', fact=dict(fact(st, side), rotation=it.get('rotation', 0),
                                                              orientation=it.get('orientation', 1)), version=7))
        alts += [{'status': 'unknown'}, dict(status='failed', reason='RESOURCE')]
        if cur.get('status') == 'computed':
            alts.append(dict(cur, version=cur.get('version', 1) + 100))   # version-only change
        return [('analysis', a) for a in alts if a != cur]
    if kind == 'header':
        cur = it.get('header')
        out = [fact('NARROW'), fact('WIDE'), dict(fact('NARROW'), state='FAILED'), None]
        return [('header', h) for h in out if h != cur]
    recs = [e for e in c.get('edges', []) if e['first'] == p and e['second'] == p + 1]
    cur = recs[0] if recs else None
    out = [None, dict(status='computed', score=None, version=3), dict(status='computed', score=0.0, version=3),
           dict(status='computed', score=7.5, version=3), dict(status='computed', score=29.0, version=3),
           dict(status='failed', failures={str(p): 'RESOURCE'})]
    if cur and cur.get('status') == 'computed':
        out.append(dict(cur, version=cur.get('version', 1) + 100))
    return [('edge', r) for r in out if r != (None if cur is None else {k: v for k, v in cur.items()})]


def apply_alt(c, f, alt):
    d = copy.deepcopy(c)
    kind, p = f
    if kind == 'analysis':
        d['items'][p]['analysis'] = alt[1]
    elif kind == 'header':
        if alt[1] is None:
            d['items'][p].pop('header', None)
        else:
            d['items'][p]['header'] = alt[1]
    else:
        d['edges'] = [e for e in d['edges'] if not (e['first'] == p and e['second'] == p + 1)]
        if alt[1] is not None:
            d['edges'].append(dict(alt[1], first=p, second=p + 1))
    return d


def counterfactual_relevance(c, t):
    sup, atts = union_support(c, t)
    base = public(c, t)
    facts = facts_of(sup)
    relevant, version_only_relevant = set(), 0
    for f in sorted(facts, key=str):
        for alt in alternatives(c, f):
            try:
                out = public(apply_alt(c, f, alt), t)
            except Exception:
                relevant.add(f)            # malformed alternative counts as relevant (conservative)
                break
            if out != base:
                relevant.add(f)
                break
    sel_only = set()
    if len(atts) == 2:
        sel_only = facts_of(dict(atts[0]['proof'][2])) - facts_of(dict(atts[1]['proof'][2]))
    return dict(union_keys=len(sup), union_facts=len(facts), dimension_keys=sum(1 for k in sup if k[0] == 'dimension'),
                relevant_facts=len(relevant), attempts=len(atts), baseline_only_facts=len(sel_only),
                baseline_only_relevant=len(sel_only & relevant), status=base['status'])
