"""A04: exhaustive interleavings of proof/service competition on the real Session API.

A small case where the L0 verdict needs one missing rank (both endpoint witnesses
must be re-served) while the strong tree certifies the target.  The race issues
both acquisitions and computes the strong certificate on the snapshot at start.
Events (every permutation is executed):
  P  commit the strong certificate (publish)
  L  L0 re-certify and publish if certified
  Fa Fb  finish+consume the two service tasks
  X  cancel all running tasks (logical; nonpreemptible)
  R  rebind with a content change of an item inside the support (invalidation)
  C  confirm the target
Invariants checked after every event (all on public Session state):
  I1 every current publication of the target equals the truth of the CURRENT context
  I2 after R, no certificate issued before R can publish or confirm
  I3 occupied == number of tasks not yet finished (cancel never frees a running slot)
  I4 confirm succeeds only if a currently valid publication exists
  I5 a cancelled or stale task never admits evidence (analysis unchanged after its finish)
  I6 at most one distinct unit is ever current for the target within one context
  I7 a certificate whose support no longer matches current evidence is never published
"""
import itertools
from copy import deepcopy

import paths  # noqa: F401
import reference as ref
from coupling import Witness
from strong import StrongSession
from coupled_runner import truth_units
import wpA_lib as A


def small_case():
    """Smallest chain found where L0 needs exactly one RANK and the tree certifies."""
    for n in range(5, 14):
        world = A._chain_world(n)
        for hole in range(1, n - 2):
            init = A.initial_from(world, set(range(n)), [a for a in range(n - 1) if a != hole])
            s = StrongSession(init, strong=dict(kind='tree', domain='nonneg', gate='raw'))
            for t in range(n):
                l0 = s.certify(t, mode='L0')
                if l0['status'] == 'need_facts' and [nd['kind'] for nd in l0['needs']] == ['RANK']:
                    st = s.certify(t, mode='S')
                    if st.get('route', '').startswith('strong'):
                        return dict(world=world, initial=init, target=t, hole=hole, n=n)
    raise RuntimeError('no small case')


EVENTS = ('P', 'L', 'Fa', 'Fb', 'X', 'R', 'C')


def run_order(sc, order, mutant=None):
    world, t, hole = sc['world'], sc['target'], sc['hole']
    s = StrongSession(sc['initial'], capacity=3, strong=dict(kind='tree', domain='nonneg', gate='raw'))
    truth = truth_units(sc['initial'], world)
    if mutant in ('publish_no_support', 'both'):
        s._certificate_current = lambda cert: True
    if mutant in ('rebind_keeps_certs', 'both'):
        orig_rebind = s.rebind

        def rebind(case, **kw):
            keep = dict(s._certs)
            orig_rebind(case, **kw)
            s._certs.update(keep)
        s.rebind = rebind
    if mutant == 'cancel_frees_slot':
        orig_cancel = s.cancel

        def cancel(token):
            r = orig_cancel(token)
            if token in s._tasks and s._tasks[token]['phase'] == 'running':
                del s._tasks[token]
            return r
        s.cancel = cancel
    base = s.certify(t, mode='L0')
    ta, tb = s.acquire(hole), s.acquire(hole + 1)
    strong = s.certify(t, mode='S')
    handle_before = strong.get('certificate')
    issued_before = set(s._certs)
    rebound = False
    units_seen = set()
    viol = []
    finished = set()
    wworld = deepcopy(world)
    for ev in order:
        if ev == 'P':
            if handle_before is not None:
                cert = s._certs.get(handle_before)
                fresh = None
                if cert is not None and not rebound:
                    idx = s.owner._index()
                    fresh = all(s.owner._read(idx, k) == v for k, v in cert['support'].items())
                r = s.publish(t, handle_before)
                if rebound and r == 'published':
                    viol.append('I2 old certificate published after rebind')
                if r == 'published' and fresh is False:
                    viol.append('I7 stale-support certificate published')
        elif ev == 'L':
            v = s.certify(t, mode='L0')
            if v['status'] == 'certified':
                s.publish(t, v['certificate'])
        elif ev in ('Fa', 'Fb'):
            tok = ta if ev == 'Fa' else tb
            item = hole if ev == 'Fa' else hole + 1
            before = deepcopy(s.owner._case['items'][item].get('analysis')) if s.owner._case else None
            if tok is not None and tok in s._tasks:
                was_cancelled = s._tasks[tok]['cancelled']
                s.finish(tok, Witness(**wworld[item]))
                r = s.consume(tok)
                finished.add(ev)
                if (was_cancelled or rebound) and r == 'accepted':
                    viol.append('I5 cancelled/stale task admitted evidence')
            finished.add(ev)
        elif ev == 'X':
            for tok in list(s._tasks):
                s.cancel(tok)
        elif ev == 'R':
            k = sc['hole'] + 1
            wworld[k] = deepcopy(wworld[k]); wworld[k]['raw'] = wworld[k]['raw'] + 997
            case = s.observe()
            case['items'][k]['content_version'] = case['items'][k].get('content_version', 0) + 1
            case['items'][k]['analysis'] = {'status': 'unknown'}
            case['edges'] = [e for e in case['edges'] if k not in (e['first'], e['second'])]
            s.rebind(case)
            truth = truth_units(case, wworld)
            rebound = True
            units_seen = set()
        elif ev == 'C':
            r = s.confirm(t)
            pub = s.published
            if r == 'confirmed' and t not in pub:
                viol.append('I4 confirmed without current publication')
            if r == 'confirmed' and rebound and s._published_handles.get(t) in issued_before:
                viol.append('I2 old certificate confirmed after rebind')
        pub = s.published
        if t in pub:
            if pub[t] != truth[t]:
                viol.append('I1 wrong current publication')
            units_seen.add(repr(pub[t]))
            if len(units_seen) > 1:
                viol.append('I6 two distinct current units in one context')
        running = sum(1 for tk, task in s._tasks.items() if task['phase'] == 'running')
        expect_running = sum(1 for e, tk in (('Fa', ta), ('Fb', tb)) if tk is not None and e not in finished)
        if mutant != 'cancel_frees_slot' and running != expect_running:
            viol.append('I3 occupancy mismatch')
        if mutant == 'cancel_frees_slot' and running != expect_running:
            viol.append('I3 occupancy mismatch')
    return viol


def exhaustive(mutant=None):
    sc = small_case()
    total, bad, examples = 0, 0, []
    for order in itertools.permutations(EVENTS):
        total += 1
        v = run_order(sc, order, mutant)
        if v:
            bad += 1
            if len(examples) < 3:
                examples.append(dict(order=order, violations=sorted(set(v))))
    return dict(case=dict(n=sc['n'], target=sc['target'], hole=sc['hole']), orders=total,
                violating_orders=bad, examples=examples, mutant=mutant)
