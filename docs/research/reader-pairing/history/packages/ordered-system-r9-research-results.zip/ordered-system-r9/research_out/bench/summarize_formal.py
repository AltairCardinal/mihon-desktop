"""Summarise results/raw/formal/<module>.jsonl (main-session formal timing).

Per (scenario, candidate, process): median wall over measured reps.
Paired ratio vs the scenario's incumbent (first candidate of that scenario's
family, as declared by the bench module) per process; reported as median
and [min, max] over processes.  Per candidate: distribution of per-scenario
median ratios.  Rows with ok=False / errors are counted, never dropped.
Writes results/summary/formal/<module>.json and FORMAL_TABLES.md.
"""
import collections, importlib, json, statistics, sys
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'bench')); sys.path.insert(0, str(OUT / 'candidates'))
import paths  # noqa


def summarize(module):
    rows = [json.loads(l) for l in (OUT / 'results/raw/formal' / f'{module}.jsonl').read_text().splitlines() if l.strip()]
    m = importlib.import_module(module)
    inc_of = {}
    for sc in m.SCENARIOS:
        cands = list(m.FAMILY_CANDIDATES(sc)) if hasattr(m, 'FAMILY_CANDIDATES') else list(m.CANDIDATES)
        inc_of[sc['name']] = cands[0]
    per = collections.defaultdict(list); meta = collections.defaultdict(lambda: dict(ok=0, notok=0, hashes=set(), pids=set()))
    child_errors = [r for r in rows if 'child_error' in r]
    for r in rows:
        if 'child_error' in r or r.get('warmup'):
            continue
        k = (r['scenario'], r['candidate'])
        mm = meta[k]; mm['pids'].add(r.get('pid'))
        if r.get('ok'): mm['ok'] += 1
        else: mm['notok'] += 1
        mm['hashes'].add(r.get('verdict_sha256'))
        if r.get('wall_ns') is not None:
            per[(r['scenario'], r['candidate'], r['process_index'])].append(r['wall_ns'])
        mm['work'] = r.get('work', {})
    med = {k: statistics.median(v) for k, v in per.items()}
    cells = []
    for (s, c) in sorted(meta):
        procs = sorted(p for (s2, c2, p) in med if (s2, c2) == (s, c))
        vals = [med[(s, c, p)] for p in procs]
        inc = inc_of.get(s)
        ratios = [med[(s, c, p)] / med[(s, inc, p)] for p in procs if (s, inc, p) in med and med[(s, inc, p)]]
        cells.append(dict(scenario=s, candidate=c, incumbent=inc, processes=len(procs),
                          wall_ms_median=round(statistics.median(vals) / 1e6, 3) if vals else None,
                          ratio=dict(median=round(statistics.median(ratios), 3), min=round(min(ratios), 3),
                                     max=round(max(ratios), 3)) if ratios and c != inc else None,
                          ok_rows=meta[(s, c)]['ok'], not_ok_rows=meta[(s, c)]['notok'],
                          distinct_verdict_hashes=len(meta[(s, c)]['hashes']), pids=len(meta[(s, c)]['pids']),
                          work=meta[(s, c)].get('work', {})))
    bycand = collections.defaultdict(list)
    for x in cells:
        if x['ratio']:
            bycand[(x['incumbent'], x['candidate'])].append(x['ratio']['median'])
    agg = [dict(incumbent=i, candidate=c, scenarios=len(v), median_of_scenario_medians=round(statistics.median(v), 3),
                min=round(min(v), 3), max=round(max(v), 3)) for (i, c), v in sorted(bycand.items())]
    res = dict(module=module, rows=len(rows), child_errors=len(child_errors), cells=cells, per_candidate=agg)
    (OUT / 'results/summary/formal').mkdir(parents=True, exist_ok=True)
    (OUT / 'results/summary/formal' / f'{module}.json').write_text(json.dumps(res, indent=1, default=str))
    return res


def main():
    mods = sys.argv[1:] or ['bench_wpA', 'bench_wpB', 'bench_wpC', 'bench_wpG', 'bench_wpH']
    lines = ['# 正式计时汇总（由 bench/summarize_formal.py 从 results/raw/formal/*.jsonl 生成）', '',
             '每个候选：各场景"逐进程配对墙钟比值的中位"的中位 [最小, 最大]（相对该场景族的 incumbent）；墙钟为整段 run_one 的本机测量。', '']
    for mod in mods:
        if not (OUT / 'results/raw/formal' / f'{mod}.jsonl').exists():
            continue
        r = summarize(mod)
        notok = sum(c['not_ok_rows'] for c in r['cells'])
        lines += [f'## {mod}（原始行 {r["rows"]}，子进程错误 {r["child_errors"]}，ok=False 行 {notok}）', '',
                  '| incumbent | 候选 | 场景数 | 比值中位 | 最小 | 最大 |', '|---|---|---|---|---|---|']
        for a in r['per_candidate']:
            lines.append(f"| {a['incumbent']} | {a['candidate']} | {a['scenarios']} | {a['median_of_scenario_medians']} | {a['min']} | {a['max']} |")
        lines.append('')
    (OUT / 'results/summary/formal/FORMAL_TABLES.md').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
