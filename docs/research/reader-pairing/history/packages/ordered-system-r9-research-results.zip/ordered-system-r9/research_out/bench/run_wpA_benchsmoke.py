"""One-rep smoke of bench_wpA (not a formal timing run): ok-flags and virtual work only.
-> results/raw/wpA/bench_smoke.jsonl, results/summary/wpA/bench_smoke.json"""
import json, sys, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent)); sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
import bench_wpA as B
ROOT = HERE.parents[1]
rows, agg = [], {}
t0 = time.time()
for sc in B.SCENARIOS:
    inc = None
    for c in B.CANDIDATES:
        r = B.run_one(sc, c)
        r.pop('latency_u')
        r.update(scenario=sc['name'], candidate=c)
        rows.append(r)
        if c == 'incumbent': inc = r
        a = agg.setdefault(c, dict(runs=0, ok=0, wrong=0, livelock=0, total_latency_u=0, physical_admissions=0,
                                   strong_evaluations=0, lane_busy_u=0, worse_latency_than_inc=0,
                                   more_admissions_than_inc=0, same_verdict_sha_as_inc=0))
        a['runs'] += 1; a['ok'] += r['ok']; a['wrong'] += r['wrong']; a['livelock'] += r['livelock']
        for k in ('total_latency_u', 'physical_admissions', 'strong_evaluations', 'lane_busy_u'):
            a[k] += r['work'][k]
        a['worse_latency_than_inc'] += r['work']['total_latency_u'] > inc['work']['total_latency_u']
        a['more_admissions_than_inc'] += r['work']['physical_admissions'] > inc['work']['physical_admissions']
        a['same_verdict_sha_as_inc'] += r['verdict_sha256'] == inc['verdict_sha256']
with open(ROOT / 'results/raw/wpA/bench_smoke.jsonl', 'w') as f:
    for r in rows: f.write(json.dumps(r) + '\n')
(ROOT / 'results/summary/wpA/bench_smoke.json').write_text(json.dumps(dict(scenarios=len(B.SCENARIOS), aggregate=agg,
    note='single rep, local wall not a formal timing result', wall_s=round(time.time() - t0, 1)), indent=1))
for c, a in agg.items(): print(c, a)
