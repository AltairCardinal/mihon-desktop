"""Import bootstrap: package root (frozen oracle), research_out/candidates and the
reproduced round-8 modules (candidates/r8).  Import this first."""
import sys
from pathlib import Path

CAND = Path(__file__).resolve().parent
OUT = CAND.parent
ROOT = OUT.parent
for p in (ROOT, CAND, CAND / 'r8'):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))
