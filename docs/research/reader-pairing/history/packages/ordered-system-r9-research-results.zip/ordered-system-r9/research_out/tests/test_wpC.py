"""WP-C tests: on-demand structures, witness pipeline, selectors, persistence branch, coupled index."""
import copy
import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
from common import ref, random_case, roundtrip, unit_of, fact, SIDES, rank_value, base_case  # noqa: E402
import theory_a as A8  # noqa: E402
import wpC_structures as S  # noqa: E402
import wpC_select as SEL  # noqa: E402
import wpC_output as OUT  # noqa: E402
import wpC_witness as WIT  # noqa: E402
import wpC_persist as PER  # noqa: E402
import wpC_reduce as RED  # noqa: E402


def mutate(rng, cur, impls, n, u):
    if rng.random() < 0.6:
        p = rng.randrange(n)
        item = copy.deepcopy(cur['items'][p])
        item['analysis'] = dict(status='computed', fact=fact(rng.choice(('NARROW', 'WIDE')), rng.choice(SIDES)), version=u + 2)
        cur['items'][p] = item
        for m in impls:
            m.set_item(p, copy.deepcopy(item))
    elif n > 1:
        a = rng.randrange(n - 1)
        rec = None if rng.random() < .2 else dict(status='computed', score=rank_value(rng, 'ext'), version=1)
        cur['edges'] = [e for e in cur['edges'] if e['first'] != a] + ([dict(rec, first=a, second=a + 1)] if rec else [])
        for m in impls:
            m.set_edge(a, copy.deepcopy(rec) if rec else None)


class Structures(unittest.TestCase):
    def test_all_structures_exact(self):
        rng = random.Random(3)
        for trial in range(60):
            n = rng.randrange(1, 30)
            c = roundtrip(random_case(rng, n, p_unknown=0.1, p_edge_unknown=0.1, p_fail=0.03))
            impls = [S.PrefixScan(c), S.LazyTree(c), S.DirtyLogTree(c, cap=3), S.SparseCheckpoints(c, K=3),
                     S.Hybrid(c, cap=3, quiet_to_demote=2), SEL.SkiRental(c, alpha=0.5), SEL.SkiQuiet(c, D=2),
                     SEL.SkiKeep(c), OUT.DiffPlan(c), OUT.ReplayLog(c, cap=4)]
            cur = copy.deepcopy(c)
            for u in range(12):
                mutate(rng, cur, impls, n, u)
                want = ref.complete_plan(cur)
                for m in impls:
                    t = rng.randrange(n)
                    self.assertEqual(m.unit(t), unit_of(want, t), (m.name, trial, u))

    def test_hybrid_never_prebuilds_and_promotes_on_flip(self):
        n = 128
        c = A8.decreasing_chain(n)
        h = S.Hybrid(c, cap=16, quiet_to_demote=4)
        self.assertEqual(h.residency(), 0)
        h.unit(10)
        self.assertLessEqual(h.residency(), 11)
        h.unit(n - 1)
        for k in range(6):
            h.set_edge(1, dict(status='computed', score=(0.25 if k % 2 == 0 else float(n - 1)), version=k + 2))
            h.unit(n - 1)
        self.assertGreaterEqual(h.work['promotions'], 1)
        for k in range(12):
            a = 60 + k
            h.set_edge(a, dict(status='computed', score=float(n - a), version=50 + k))
        self.assertGreaterEqual(h.work['demotions'], 1)
        want = ref.complete_plan(h.F.case | {'edges': [dict(h.F.records[a]) for a in sorted(h.F.records)]})
        for t in (0, 5, 77, n - 1):
            self.assertEqual(h.unit(t), unit_of(want, t))

    def test_dirtylog_bounded(self):
        c = roundtrip(random_case(random.Random(1), 200, settings_mix=False))
        d = S.DirtyLogTree(c, cap=8)
        d.unit(150)
        for k in range(50):
            d.set_edge(k, dict(status='computed', score=1.0, version=k + 2))
        self.assertLessEqual(len(d.dirty), 8)
        self.assertGreaterEqual(d.work['log_overflow_drops'], 1)

    def test_rope_exact_and_preconditions(self):
        rng = random.Random(5)
        c = roundtrip(random_case(rng, 40, settings_mix=False))
        r = S.RopePlan(c, B=4)
        cur = copy.deepcopy(c)
        import wpC_experiments as E
        for k in range(10):
            p = rng.randrange(1, len(cur['items']) - 1)
            if k % 2 == 0:
                op = ('ins', p, dict(id=f'z{k}', header=fact(), analysis=dict(status='computed', fact=fact('NARROW', 'A'), version=1)),
                      dict(status='computed', score=1.5, version=1), dict(status='computed', score=2.5, version=1))
                r.insert(op[1], copy.deepcopy(op[2]), op[3], op[4])
            else:
                op = ('del', p, dict(status='computed', score=0.5, version=1))
                r.delete(op[1], op[2])
            cur = E.rope_mirror(cur, op)
            want = ref.complete_plan(cur)
            for t in range(len(cur['items'])):
                self.assertEqual(r.unit(t), unit_of(want, t))
        c2 = base_case(10)
        c2['settings']['pinned_links'] = [4, 5]
        with self.assertRaises(ValueError):
            S.RopePlan(c2)

    def test_diffplan_cover_exact(self):
        rng = random.Random(9)
        c = roundtrip(random_case(rng, 50, settings_mix=False))
        d = OUT.DiffPlan(c)
        cur = copy.deepcopy(c)
        for u in range(30):
            before = list(d.cover)
            mutate(rng, cur, [d], 50, u)
            want = ref.complete_plan(cur)
            cov = {s['item']: x for x in want for s in x['slots']}
            self.assertEqual(d.cover, [cov[i] for i in range(50)])
            changed = {i for i in range(50) if before[i] != d.cover[i]}
            self.assertEqual(changed, {p for p, _ in d.last_diff})


class Witness(unittest.TestCase):
    def test_fused_variants_identical_and_symmetric(self):
        rng = random.Random(1)
        for t in range(40):
            ws = [WIT.random_witness(rng, spread=rng.choice((2, 10, 120)), cov_choices=(255, 100)) for _ in range(5)]
            pairs = [(i, i + 1) for i in range(4)]
            from collections import Counter
            ref_ = {p: WIT.OP.score(ws[p[0]], ws[p[1]]) for p in pairs}
            for fn in (lambda: WIT.fused_ranks(ws, pairs, Counter(), True), lambda: WIT.fused_ranks(ws, pairs, Counter(), False),
                       lambda: WIT.prefix_ranks(ws, pairs, Counter()), lambda: WIT.separate_ranks(ws, pairs, Counter())):
                self.assertEqual(fn(), ref_)
            for a, b in pairs:
                self.assertEqual(WIT.OP.score(ws[a], ws[b]), WIT.OP.score(ws[b], ws[a]))

    def test_progressive_is_exact(self):
        rng = random.Random(2)
        from collections import Counter
        for t in range(40):
            wa, wb = WIT.random_witness(rng, spread=150), WIT.random_witness(rng, spread=150)
            for seg in (5, 25):
                self.assertEqual(WIT.progressive_pair(wa, wb, seg, Counter())[0], WIT.OP.score(wa, wb))


class Selection(unittest.TestCase):
    def test_wrong_advice_only_changes_cost(self):
        n = 96
        c = A8.decreasing_chain(n)
        good = S.PrefixScan(c)
        bad = SEL.Advised(c, lambda k: 'tree' if k % 2 else 'resync', gap=1)
        rng = random.Random(4)
        for k in range(80):
            a = 1 if k % 3 == 0 else rng.randrange(2, n - 1)
            rec = dict(status='computed', score=(0.25 if k % 2 else float(n - a)), version=k + 2)
            good.set_edge(a, dict(rec)); bad.set_edge(a, dict(rec))
            t = rng.randrange(n)
            self.assertEqual(bad.unit(t), good.unit(t))
        self.assertGreater(bad.work['promotions'], 5)

    def test_offline_opt_lower_bounds_fixed(self):
        cr, ct = [1, 9, 9, 9, 1], [3, 3, 3, 3, 3]
        self.assertLessEqual(SEL.offline_opt(cr, ct, 2, 2), min(sum(cr), sum(ct) + 2))


class Persistence(unittest.TestCase):
    def test_short_hash_false_hits_strict_none(self):
        rng = random.Random(1)
        contents = [[rng.randrange(2 ** 32) for _ in range(4)] for _ in range(600)]
        for mode, bits, expect in (('strict', 16, 0), ('short', 8, None)):
            vc = PER.ValueCache(mode, bits)
            for c in contents:
                vc.get_or_compute(c, 'AB', 'v1', lambda x: sum(x))
            if expect == 0:
                self.assertEqual(vc.stats['false_hits'], 0)
            else:
                self.assertGreater(vc.stats['false_hits'], 0)

    def test_recovery_and_versions(self):
        self.assertTrue(all(r['invariant_ok'] for r in PER.crash_matrix()))
        self.assertEqual(PER.combine_certificate([(1, 'v1'), (2, 'v2')]), 'refused_mixed_versions')

    def test_cross_owner_migration(self):
        import coupling
        import workloads as WL
        tr = WL.w01_phase_chain(0)
        a = coupling.Session(tr['initial'])
        h = t = None
        for x in range(len(tr['initial']['items'])):
            v = a.certify(x, mode='L0')
            if v['status'] == 'certified':
                h, t = v['certificate'], x
                break
        a.publish(t, h); a.confirm(t)
        b = coupling.Session(copy.deepcopy(tr['initial']))
        self.assertEqual(b.publish(t, h), 'unsigned')
        h2 = PER.migrate_certificate(a, h, b)
        self.assertEqual(b.publish(t, h2), 'published')
        self.assertEqual(len(b.confirmed), 0)
        changed = copy.deepcopy(tr['initial']); changed['items'][0]['content_version'] = 3
        self.assertEqual(PER.migrate_certificate(a, h, coupling.Session(changed)), 'identity_mismatch')


class Coupled(unittest.TestCase):
    def test_indexed_runner_sound(self):
        import workloads as W
        import wpC_coupled as WC
        for fam, kw in (('W01', dict(n=40)), ('RP', dict(n=30, pa=0.9, pe=0.9)), ('W05', dict(n=30)), ('W06', {})):
            for seed in range(2):
                tr = W.FAMILIES[fam](seed, **kw)
                for pol in ('indexed', 'selector'):
                    r = WC.IndexedRunner(tr, policy=pol, service_u=2, q_u=0, strong=dict(kind='tree', domain='nonneg', gate='raw')).run()
                    self.assertEqual(r['wrong'], 0)

    def test_index_gate_completion_invariance(self):
        """Lemma C-I1: if gate(t) holds, unit(t) is the same in every completion of the unknown suffix."""
        import wpC_coupled as WC
        from common import random_case, roundtrip, rank_value
        rng = random.Random(11)
        checked = 0
        for trial in range(40):
            n = rng.randrange(12, 30)
            full = roundtrip(random_case(rng, n, p_wide=0.2, domain='G0', settings_mix=False))
            for it in full['items']:
                st = 'WIDE' if rng.random() < 0.2 else 'NARROW'
                it['header'] = fact(st); it['analysis'] = dict(status='computed', fact=fact(st, rng.choice(SIDES)), version=1)
            full['edges'] = [dict(first=i, second=i + 1, status='computed', score=rank_value(rng, 'G0'), version=1) for i in range(n - 1)]
            t = rng.randrange(0, n - 5)
            part = copy.deepcopy(full)
            for p in range(t + 4, n):
                part['items'][p]['analysis'] = dict(status='unknown')
            part['edges'] = [e for e in part['edges'] if e['first'] <= t + 2]
            idx = WC._OwnerIndex(part)
            self.assertTrue(idx.gate(t))
            got = idx.unit(t)
            for k in range(6):          # random completions of everything the gate does not fix
                comp = copy.deepcopy(part)
                for p in range(t + 4, n):
                    st = 'WIDE' if rng.random() < 0.3 else 'NARROW'
                    comp['items'][p]['header'] = fact(st)
                    comp['items'][p]['analysis'] = dict(status='computed', fact=fact(st, rng.choice(SIDES)), version=2)
                comp['edges'] += [dict(first=a, second=a + 1, status='computed', score=rank_value(rng, 'G0'), version=2)
                                  for a in range(t + 3, n - 1)]
                self.assertEqual(got, unit_of(ref.complete_plan(comp), t))
                checked += 1
        self.assertEqual(checked, 240)

    def test_index_certificate_lifecycle(self):
        import workloads as W
        import wpC_coupled as WC
        tr = W.w01_phase_chain(0, n=40, holes=0) if 'holes' in W.w01_phase_chain.__code__.co_varnames else W.w01_phase_chain(0)
        s = WC.IndexedSession(tr['initial'])
        v = s.certify(5, mode='I')
        self.assertEqual(v.get('route'), 'index')
        # update beyond the support range keeps the certificate valid
        far = len(tr['initial']['items']) - 2
        s.owner.apply(edge_updates={(far, far + 1): dict(status='computed', score=1.0, version=7)})
        self.assertEqual(s.publish(5, v['certificate']), 'published')
        # an update inside the support range makes it stale
        s.owner.apply(edge_updates={(3, 4): dict(status='computed', score=999.0, version=8)})
        self.assertEqual(s.publish(5, v['certificate']), 'stale')
        v2 = s.certify(5, mode='I')
        self.assertEqual(v2['unit'], unit_of(ref.complete_plan(s.owner.snapshot()), 5))
        # rebind resets the index
        s.rebind(copy.deepcopy(tr['initial']))
        self.assertIsNone(s._index_obj)
        self.assertEqual(s.publish(5, v2['certificate']), 'unsigned')


class Reducer(unittest.TestCase):
    def test_ddmin_preserves_predicate(self):
        n = 64
        c = A8.decreasing_chain(n)
        ev = []
        for k in range(30):
            ev.append(('edge', 1, dict(status='computed', score=(0.25 if k % 2 == 0 else float(n - 1)), version=k + 2)))
            ev.append(('query', n - 1))
        kw = ({'cap': 10 ** 9, 'quiet_to_demote': 10 ** 9}, {})
        pred = lambda e: RED.ratio(S.Hybrid, S.LazyTree, c, e, kw) > 2.0
        self.assertTrue(pred(ev))
        red, _ = RED.ddmin(ev, pred)
        self.assertTrue(pred(red))
        self.assertLess(len(red), len(ev))


if __name__ == '__main__':
    unittest.main()
