"""D04: decision-signature validation for the corrected owner memo (WP-B).

The corrected owner validates a memo entry by exact typed equality of the
union of all attempts' reads.  Theorem D-4 (proofs/wpB.md): the frozen scan
reads ranks only inside later_wins, as the pair (r(i,i+1), r(i+1,i+2)), and
uses them only through  `b is not None and (a is None or b < a)`.  Hence if
every non-rank read is typed-equal, every rank read keeps its null flag, and
for every pair of *adjacent* read ranks both strict-order bits (b<a, a<b) are
unchanged, then every attempt makes the same decisions, reads the same keys
(in the same order) and returns the same public fields (status, unit, needs,
failures, first, steps, dependent_items).  The memo may then return the stored
public result and refresh its support to the new values.

What is NOT reused: proof fingerprints (they contain values) -- the refreshed
support is rebuilt from current reads, so later exact validation stays exact.
Failed-rank evidence ('failed' with failures) and non-computed statuses are
compared exactly (failures enter public output).
"""
import paths  # noqa: F401
from corrected_owner import Owner, SAT
from current_baseline import typed


def _rank_val(v):
    # compact edge tuple: ('computed', score, version) | ('unknown',) | ('failed', ...)
    if isinstance(v, tuple) and v and v[0] == 'computed':
        return ('computed', v[1])
    return None


def signature_equal(old_support, new_reads):
    """old_support: {key: old typed-value}; new_reads: {key: current value}."""
    ranks_old, ranks_new = {}, {}
    for key, old in old_support.items():
        new = new_reads[key]
        if key[0] == 'rank':
            ro, rn = _rank_val(old), _rank_val(new)
            if ro is None or rn is None:
                if typed(old) != typed(new):
                    return False
                continue
            if (ro[1] is None) != (rn[1] is None):
                return False
            ranks_old[key[1]] = ro[1]
            ranks_new[key[1]] = rn[1]
        elif typed(old) != typed(new):
            return False
    for a in ranks_old:
        b = a + 1
        if b not in ranks_old:
            continue
        x0, y0, x1, y1 = ranks_old[a], ranks_old[b], ranks_new[a], ranks_new[b]
        if x0 is None or y0 is None:
            continue
        if (y0 < x0) != (y1 < x1) or (x0 < y0) != (x1 < y1):
            return False
    return True


class SigOwner(Owner):
    """Corrected owner + decision-signature fallback (L0: identical public output)."""

    def _valid(self, entry, index):
        if entry['guard'] != self._guard() or self._case.get('closed', False):
            return False
        if self.config.stamps and self._revision < SAT and entry['stamp'] == self._revision:
            self.metrics['stamp_hits'] += 1
            return True
        self.metrics['support_validations'] += 1
        current = {}
        exact = True
        for key, old in entry['support'].items():
            self.metrics['typed_reads_checked'] += 1
            now = self._read(index, key)
            current[key] = now
            if exact and typed(old) != typed(now):
                exact = False
        if not exact:
            if not signature_equal(entry['support'], current):
                return False
            self.metrics['signature_hits'] += 1
            entry['support'] = current          # refresh to the new exact values
        entry['stamp'] = self._revision
        return True


def _mutant_sig(old_support, new_reads):
    for key, old in old_support.items():
        new = new_reads[key]
        if key[0] == 'rank':
            ro, rn = _rank_val(old), _rank_val(new)
            if ro is None or rn is None:
                if typed(old) != typed(new):
                    return False
            elif (ro[1] is None) != (rn[1] is None):
                return False
        elif typed(old) != typed(new):
            return False
    return True


class SigMutantNoOrder(SigOwner):
    def _valid(self, entry, index):
        import wpB_sigmemo as M
        orig = M.signature_equal
        M.signature_equal = _mutant_sig
        try:
            return SigOwner._valid(self, entry, index)
        finally:
            M.signature_equal = orig
