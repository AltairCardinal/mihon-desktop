"""K02/K03/K06/X26: memo retention at equal space, with rebuild-cost estimates.

ROwner(case, policy, byte_budget, estimator)
  policy 'lru'        incumbent behaviour (entry-count capacity 4, move-to-end on hit)
         'bytes'      LRU under a byte budget; entry size = calibrated bytes/key x keys
         'gds'        GreedyDual-Size priority (L + cost/size) under the byte budget
  estimator 'steps'   rebuild cost = deterministic scan steps of the recompute
            'clock'   rebuild cost = perf_counter_ns of the recompute, refreshed every
                      `sample`-th miss (else the last estimate for that target)
Policies only change WHICH entries are kept; public results are identical (L0).
"""
import time

import paths  # noqa: F401
from corrected_owner import Config
from wpG_owner import GOwner

BYTES_PER_KEY = 220     # default; wpG_experiments.k02_calibrate measures the real value


class ROwner(GOwner):
    def __init__(self, case, config=Config(), *, policy='lru', byte_budget=None, estimator='steps', sample=1,
                 bytes_per_key=BYTES_PER_KEY):
        self.policy, self.byte_budget, self.estimator, self.sample = policy, byte_budget, estimator, sample
        self.bytes_per_key = bytes_per_key
        self._L, self._bytes, self._miss, self._last_cost = 0.0, 0, 0, {}
        if policy != 'lru':
            config = Config(memo=config.memo, stamps=config.stamps, shared_index=config.shared_index,
                            memo_capacity=10 ** 6, max_order=config.max_order, max_reads=config.max_reads)
        super().__init__(case, config)

    def _size(self, entry):
        return self.bytes_per_key * (len(entry['support']) + 2)

    def request(self, target):
        before_runs, before_steps = self.metrics['engine_runs'], self.metrics['scan_steps']
        t0 = time.perf_counter_ns()
        out = super().request(target)
        dt = time.perf_counter_ns() - t0
        if self.policy == 'lru':
            return out
        entry = self._memo.get(target)
        if entry is None:
            return out
        if self.metrics['engine_runs'] != before_runs:
            self._miss += 1
            if self.estimator == 'steps':
                cost = float(max(1, self.metrics['scan_steps'] - before_steps))
            else:
                if self._miss % self.sample == 0 or target not in self._last_cost:
                    self._last_cost[target] = float(dt)
                    self.metrics['clock_samples'] += 1
                cost = self._last_cost[target]
            entry['cost'], entry['size'] = cost, self._size(entry)
            entry['prio'] = self._L + cost / entry['size']
            self._bytes = sum(e['size'] for e in self._memo.values())
            self._enforce(target)
        elif 'prio' in entry:
            entry['prio'] = self._L + entry['cost'] / entry['size']        # GDS refresh on hit
        return out

    def _enforce(self, keep):
        while self.byte_budget is not None and self._bytes > self.byte_budget and len(self._memo) > 1:
            if self.policy == 'bytes':
                victim = next(k for k in self._memo if k != keep)
            else:
                victim = min((k for k in self._memo if k != keep), key=lambda k: self._memo[k]['prio'])
                self._L = self._memo[victim]['prio']
            e = self._memo.pop(victim)
            self._bytes -= e['size']
            self.metrics['memo_evictions'] += 1
        if self.byte_budget is not None and self._bytes > self.byte_budget:
            e = self._memo.pop(keep)                                     # oversize: bypass, never truncate
            self._bytes -= e['size']
            self.metrics['oversize_bypasses'] += 1
