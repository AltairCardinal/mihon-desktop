"""Main-session core: StrongSession + coupled runner soundness and lifecycle."""
import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import workloads as W
import coupled_runner as CR
from strong import StrongSession
from coupling import Witness


class StrongCore(unittest.TestCase):
    def test_no_wrong_publication_any_policy(self):
        for fam in ('W05', 'RP', 'W06', 'W01', 'W02'):
            for seed in range(3):
                tr = W.FAMILIES[fam](seed)
                for pol in ('incumbent', 'proof_first', 'race', 'gated', 'strong_only'):
                    for gate in ('raw', 'sound'):
                        r = CR.Runner(tr, policy=pol, service_u=2, q_u=1,
                                      strong=dict(kind='tree', domain='nonneg', gate=gate)).run()
                        self.assertEqual(r['wrong'], 0, (fam, seed, pol, gate))
                        self.assertEqual(r['published'], r['intents'], (fam, seed, pol, gate))

    def test_strong_certificate_goes_stale_on_support_change(self):
        tr = W.w01_phase_chain(0)
        s = StrongSession(tr['initial'], strong=dict(kind='tree', domain='nonneg', gate='raw'))
        hit = None
        for t in range(len(tr['initial']['items'])):
            v = s.certify(t, mode='S')
            if v.get('route', '').startswith('strong'):
                hit = (t, v); break
        self.assertIsNotNone(hit)
        t, v = hit
        a = next(e for e in s.owner._case['edges'] if e['first'] <= t + 2)
        s.owner.apply(edge_updates={(a['first'], a['second']): dict(status='computed', score=123456, version=9)})
        self.assertEqual(s.publish(t, v['certificate']), 'stale')

    def test_strong_never_rewrites_certified_or_blocked(self):
        tr = W.random_partial(1)
        s = StrongSession(tr['initial'])
        for t in range(len(tr['initial']['items'])):
            l0 = s.certify(t, mode='L0'); st = s.certify(t, mode='S')
            if l0['status'] != 'need_facts':
                self.assertEqual({k: v for k, v in st.items() if k != 'certificate'},
                                 {k: v for k, v in l0.items() if k != 'certificate'})


if __name__ == '__main__':
    unittest.main()
