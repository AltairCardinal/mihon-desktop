"""F1 route 2: settings-specialised scan (partial evaluation by closure).

Same predicate structure and callback order as reference._Scan (so reads,
needs order and short-circuits are unchanged); only settings lookups are
folded into attributes / specialised bound methods once per certify call.
compact_core.certify is reused unchanged by temporarily handing it this
class through a module-level hook (no frozen file is edited)."""
import compact_core as core
import reference as ref


_BASE = ref._Scan


class FastScan(_BASE):
    def __init__(self, n, settings, dimension, side, resolved, distance):
        super().__init__(n, settings, dimension, side, resolved, distance)
        self._auto = settings['automatic']
        self._open_auto = settings['opening'] == 'AUTO'
        self._has_starts = bool(self.starts)
        if not self._auto:
            self.side = self._side_off
            self.later_wins = self._later_off

    def _side_off(self, i):
        return 'UNKNOWN'

    def _later_off(self, i):
        near, later = self.strength(i), self.strength(i + 1)
        return later > near if later != near else False

    def manual(self, i):
        if not self._has_starts:
            return False
        return _BASE.manual(self, i)

    def wide(self, i):
        if not 0 <= i < self.n:
            return False
        f = self.dimension(i)
        return f is not None and f['state'] == 'WIDE'


def certify_fast(case, target, lookbehind=2, index=None):
    core.ref._Scan = FastScan
    try:
        return core.certify(case, target, lookbehind, index)
    finally:
        core.ref._Scan = _BASE
