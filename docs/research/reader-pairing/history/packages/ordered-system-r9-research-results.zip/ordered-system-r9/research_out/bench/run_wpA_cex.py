"""Constructive search for a race_keep latency counterexample (capacity refusal + reuse)."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import wpA_lib as A
from strong import StrongSession

found = None
for n in range(6, 16):
    for noise in (False, True):
        import random
        world = A._chain_world(n, rng=random.Random(n), step_noise=noise)
        for h in range(1, n - 2):
            init = A.initial_from(world, set(range(n)), [a for a in range(n - 1) if a != h])
            s = StrongSession(init)
            info = {}
            for t in range(n):
                l0 = s.certify(t, mode='L0')
                if l0['status'] != 'need_facts' or [x['kind'] for x in l0['needs']] != ['RANK']:
                    continue
                st = s.certify(t, mode='S')
                info[t] = str(st.get('route', '')).startswith('strong')
            As = [t for t, ok in info.items() if ok]
            Bs = [t for t, ok in info.items() if not ok]
            if not As or not Bs:
                continue
            for a in As:
                for k in (1, 2, 3):
                    ev = [dict(at=0, op='target', target=a)] + [dict(at=20, op='target', target=b) for b in Bs[:k]]
                    tr = dict(name=f'cex_n{n}_h{h}', initial=init, world=world, events=ev)
                    for q in (1, 2):
                        res = {p: A.ARunner(tr, policy=p, service_u=3, q_u=q, capacity=1).run() for p in ('incumbent', 'race_keep')}
                        if res['race_keep']['total_latency_u'] > res['incumbent']['total_latency_u']:
                            found = dict(n=n, hole=h, A=a, B=Bs[:k], q=q, service_u=3, capacity=1, trace=tr,
                                         incumbent={x: res['incumbent'][x] for x in ('total_latency_u', 'latency_u', 'physical_admissions')},
                                         race_keep={x: res['race_keep'][x] for x in ('total_latency_u', 'latency_u', 'physical_admissions')})
                            break
                    if found: break
                if found: break
            if found: break
        if found: break
    if found: break
out = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpA' / 'race_keep_counterexample.json'
out.write_text(json.dumps(found, indent=1, default=str))
print(json.dumps({k: v for k, v in (found or {}).items() if k != 'trace'}, default=str))
