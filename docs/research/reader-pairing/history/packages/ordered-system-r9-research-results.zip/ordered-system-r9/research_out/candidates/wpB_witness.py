"""E01/E02/E03/X10: witness sufficiency and realizability (WP-B).

Uses the package's independent mathematical operator OPTIMIZED_OPERATOR.py
(D_src semantics: 50 packed four-channel features, coverage normalisation,
L1 sum q, null if q >= 1500 or bright/dark/low-variance rejection).
"""
import math
import random

import paths  # noqa: F401
import OPTIMIZED_OPERATOR as OP


def pack(c, x1, x2, x3):
    return (c << 24) | (x1 << 16) | (x2 << 8) | x3


# ------------------------------------------------------------------ E01
def permuted_pair(rng):
    """Two witnesses with the same multiset of normalised elements (hence the
    same mean, variance, bright/dark counts and channel sums) but different
    L1 distance to a third witness: statistics are not sufficient."""
    base = [pack(255, 60 + 2 * k, 80 + 2 * k, 70 + 2 * k) for k in range(50)]
    perm = base[1:] + base[:1]                        # cyclic shift = same multiset
    probe = [pack(255, 61 + 2 * k, 80 + 2 * k, 70 + 2 * k) for k in range(50)]
    return base, perm, probe


def stats(vec):
    nv = [OP.normalize(v) for v in vec]
    proj = sorted(0.299 * a + 0.587 * b + 0.114 * c for a, b, c in nv)
    return (sorted(nv), sum(min(x) > 220 for x in nv), sum(max(x) < 50 for x in nv), round(OP._variance(nv), 9), tuple(proj))


def raw_many_to_one():
    """Two different raw witnesses with identical normalised vectors (coverage <
    255 folds measurements): storing the normalised vector is sufficient and
    strictly less information than raw."""
    a = [pack(1, 10, 20, 30)] * 50
    b = [pack(1, 11, 20, 30)] * 50
    return a, b, [OP.normalize(x) for x in a] == [OP.normalize(x) for x in b]


def direction_needs_both_sides():
    """AB uses R_i vs L_{i+1}, BA uses L_i vs R_{i+1}: a store keeping only the
    side used by the current direction cannot answer a direction change.
    Returns the two ranks of the same object pair under AB and BA."""
    L0 = [pack(255, 60 + 2 * k, 90 + k, 120) for k in range(50)]
    R0 = [pack(255, 64 + 2 * k, 91 + k, 121) for k in range(50)]
    L1 = [pack(255, 66 + 2 * k, 90 + k, 125) for k in range(50)]
    R1 = [pack(255, 60 + 2 * k, 95 + k, 120) for k in range(50)]
    return OP.score(R0, L1), OP.score(L0, R1)


# ------------------------------------------------------------------ E02
def row_multiplicities(h):
    counts = {}
    for k in range(50):
        r = (k * h) // 50
        counts[r] = counts.get(r, 0) + 1
    return sorted(counts.values())


def realizable_q(h1, h2):
    """Exact set of integer q < 1500 realisable as the L1 sum when the left
    witness has row multiplicities from h1 and the right from h2 (rotation 0,
    rows floor(k*h/50)); both sides see the SAME element index k, so element k
    contributes |X_k - Y_k| where X is constant on h1-rows and Y on h2-rows.
    Joint blocks = intersections of row classes; q = sum_blocks size*delta_b,
    delta_b in 0..765 independently (channels/values free inside [0,255])."""
    blocks = {}
    for k in range(50):
        key = ((k * h1) // 50, (k * h2) // 50)
        blocks[key] = blocks.get(key, 0) + 1
    sizes = list(blocks.values())
    reach = 1                                          # bitset of achievable q
    for s in sizes:
        acc = 0
        for d in range(0, 766):
            sh = s * d
            if sh >= 1500:
                break
            acc |= reach << sh
        reach = acc & ((1 << 1500) - 1)
    return reach, sorted(sizes)


def variance_zero_rows(h):
    """h == 1 makes every element identical => projection variance 0."""
    return h == 1


# ------------------------------------------------------------------ E03
def structural_impossible():
    """Combinations that the shared geometry makes impossible (necessary
    conditions usable as a narrower domain only when geometry is admitted)."""
    return [
        ('endpoint WIDE (oriented w >= h)', 'non-null rank', 'reference edge(): WIDE endpoint => computed null'),
        ('oriented w > h', 'any edge sample', 'GENERATIVE_DOMAIN: w>h produces no edge samples'),
        ('both endpoints h == 1', 'non-null rank', 'variance of each side is 0 < 100 => rejected (null)'),
        ('both endpoints h == 2', 'rank not multiple of 0.5', 'joint blocks of size 25 => q multiple of 25'),
        ('side label', 'any rank value', 'NOT transportable: side generator unpublished'),
    ]


def edge_masks_from_geometry(case):
    """X10: per-edge realizability masks from admitted geometry (heights of both
    endpoints, rotation 0 only).  Returns {edge: mask} or {} if any premise fails."""
    masks = {}
    for a in range(len(case['items']) - 1):
        hs = []
        for i in (a, a + 1):
            an = case['items'][i].get('analysis', {})
            if an.get('status') != 'computed' or an['fact'].get('rotation', 0) != 0:
                hs = None
                break
            hs.append(an['fact'].get('height'))
        if not hs or None in hs or min(hs) >= 50:
            continue
        reach, _ = realizable_q(hs[0], hs[1])
        masks[a] = reach
    return masks


def masks_consistent(case, masks):
    """Premise check: every KNOWN computed rank on a masked edge must lie in its
    mask; otherwise the geometry premise (rotation 0, row model) is violated by
    late metadata or an external value and the masks must be dropped."""
    for e in case.get('edges', []):
        a = e['first']
        if a in masks and e.get('status') == 'computed' and e.get('score') is not None:
            q = e['score'] * 50
            if abs(q - round(q)) > 1e-9 or not 0 <= round(q) < 1500 or not (masks[a] >> int(round(q))) & 1:
                return False
    return True
