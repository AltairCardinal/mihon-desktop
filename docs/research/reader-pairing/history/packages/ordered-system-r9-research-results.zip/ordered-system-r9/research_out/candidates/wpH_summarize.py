"""Aggregate WP-H raw results into results/summary/wpH/summary.json (numbers copied from raw files only)."""
import json
from pathlib import Path

RAW = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpH'
OUT = Path(__file__).resolve().parents[1] / 'results' / 'summary' / 'wpH'


def main():
    d4 = json.loads((RAW / 'd4.json').read_text())
    inc = d4['incremental']
    vc = d4['value_cache']
    bc = d4['bound_confirm']
    rs = d4['reservation']
    s = dict(
        d4_heldout=[f'{f}/{s}' for f, s in d4['held_out']],
        d4_incremental=dict(runs=len(inc), all_same_publications=all(r['same_publications'] for r in inc),
                            all_same_confirmations=all(r['same_confirmations'] for r in inc),
                            all_same_latency=all(r['same_latency'] for r in inc),
                            read_checks_full=sum(r['read_checks_full'] for r in inc),
                            read_checks_inc=sum(r['read_checks_inc'] for r in inc),
                            wrong=sum(r['wrong'] + r['wrong_current'] for r in inc),
                            occupied_end=sum(r['occupied_end'] for r in inc), unserved=sum(r['unserved'] for r in inc),
                            wall_full_ns_sum=sum(r['wall_full_ns'] for r in inc),
                            wall_inc_ns_sum=sum(r['wall_inc_ns'] for r in inc),
                            wall_note='single unrepeated local_measured runs under shared CPU; not a formal timing'),
        d4_value_cache=dict(runs=len(vc), admissions_incumbent=sum(r['incumbent_physical_admissions'] for r in vc),
                            admissions_value_cache=sum(r['value_cache_physical_admissions'] for r in vc),
                            latency_incumbent=sum(r['incumbent_latency'] for r in vc),
                            latency_value_cache=sum(r['value_cache_latency'] for r in vc),
                            latency_worse_runs=[f"{r['family']}/{r['seed']}" for r in vc
                                                if r['value_cache_latency'] > r['incumbent_latency']],
                            hits=sum(r['value_cache_hits'] for r in vc),
                            wrong=sum(r['incumbent_wrong'] + r['incumbent_wrong_current'] + r['value_cache_wrong'] +
                                      r['value_cache_wrong_current'] for r in vc),
                            old_epoch_certificates=sum(r['value_cache_old_epoch_certificates_retained'] for r in vc)),
        d4_bound_confirm=dict(runs=len(bc), late_callbacks=sum(r['package_confirm_late_callbacks'] for r in bc),
                              package_confirmed_via_expired=sum(r['package_confirm_confirmed_via_expired_callback'] for r in bc),
                              bound_confirmed_via_expired=sum(r['bound_confirm_confirmed_via_expired_callback'] for r in bc),
                              runs_with_package_defect=sum(1 for r in bc if r['package_confirm_confirmed_via_expired_callback'])),
        d4_reservation=dict(runs=len(rs), latency_none=sum(r['no_reserve_latency'] for r in rs),
                            latency_reserve1=sum(r['reserve1_latency'] for r in rs),
                            admissions_none=sum(r['no_reserve_admissions'] for r in rs),
                            admissions_reserve1=sum(r['reserve1_admissions'] for r in rs),
                            refusals=sum(r['reserve1_refusals'] for r in rs),
                            max_latency_none=max(r['no_reserve_max_latency'] for r in rs),
                            max_latency_reserve1=max(r['reserve1_max_latency'] for r in rs),
                            runs_latency_better=sum(1 for r in rs if r['reserve1_latency'] < r['no_reserve_latency']),
                            runs_latency_worse=sum(1 for r in rs if r['reserve1_latency'] > r['no_reserve_latency'])),
    )
    life = {}
    for fam in ('incremental', 'value_cache', 'bound_confirm', 'reservation'):
        for r in d4[fam]:
            for kk, v in r.items():
                if 'lifecycle' in kk:
                    t = life.setdefault(f'{fam}:{kk}', dict(runs=0, cancels=0, discarded=0, rebinds=0, reopened=0,
                                                             released_runs=0, peak_le_capacity_runs=0,
                                                             raw_le_cap_runs=0, confirmed_subset_runs=0, wrong=0,
                                                             unserved=0))
                    t['runs'] += 1
                    for f in ('cancels', 'discarded', 'rebinds', 'reopened', 'unserved'):
                        t[f] += v[f]
                    t['wrong'] += v['wrong'] + v['wrong_current']
                    t['released_runs'] += v['released']
                    t['peak_le_capacity_runs'] += v['peak_le_capacity']
                    t['raw_le_cap_runs'] += v['raw_le_cap']
                    t['confirmed_subset_runs'] += v['confirmed_subset']
    s['d4_lifecycle'] = life
    commit = json.loads((RAW / 'commit.json').read_text())
    robust = json.loads((RAW / 'robust.json').read_text())
    s['H01'] = {k: commit['H01'][k] for k in ('interleavings', 'published', 'stale', 'violations', 'mutant_guard_only',
                                               'mutant_own_items_only')}
    s['H03'] = commit['H03']
    s['H04'] = commit['H04']
    s['H05'] = {k: v for k, v in commit['H05'].items() if k != 'note'}
    s['R03'] = dict(sequences=robust['R03']['sequences'], violations=robust['R03']['n_violations'])
    s['R04'] = {k: robust['R04'][k] for k in ('configs', 'owner_public_field_mismatches', 'strong_unit_mismatches')}
    s['R05'] = robust['R05']
    s['R06'] = {k: robust['R06'][k] for k in ('injected', 'recovered', 'n_violations')}
    s['N03'] = {k: dict(states=v['states'], depth=v['depth'], violations=v['n_violations']) for k, v in robust['N03'].items()}
    extra = json.loads((RAW / 'extra.json').read_text())
    rows = extra['I04_des']['rows']
    s['I04_des'] = dict(configs=len(rows), split_wins_needed_latency=sum(r['split_wins_latency_for_needed'] for r in rows),
                        split_wins_when_p1=sum(r['split_wins_latency_for_needed'] for r in rows if r['p_need'] == 1.0))
    agg = {}
    for r in extra['J06_sim']['rows']:
        a = agg.setdefault(r['organisation'], dict(G_total=0, H_total=0, extra_work_u=0, spent_H=0, spent_G=0))
        for k in a:
            a[k] += r[k]
    s['J06_sim'] = agg
    combos = json.loads((RAW / 'combos.json').read_text())
    x23 = {}
    for r in combos['X23']['rows']:
        k = f"{r['pattern']}|{r['speculation']}|{r['reservation']}"
        x23[k] = x23.get(k, 0) + r['required_total']
    s['X23_required_total_sum_over_seeds'] = x23
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'summary.json').write_text(json.dumps(s, indent=1))
    return s


if __name__ == '__main__':
    print(json.dumps(main(), indent=1)[:6000])
