"""Writes coverage_parts/wpB.csv, hypotheses_parts/wpB.csv, adoption_parts/wpB.csv.
Every number appears in results/raw/wpB/* or results/summary/wpB/*."""
import csv
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT.parent
T = "python3 -m unittest discover -s research_out/tests -t research_out -p 'test_wpB*.py'"
ANCH = 'PRIOR_EVIDENCE_MAP.md; ALGORITHM_FRONTIER.md; COST_EVIDENCE.md'
R = 'results/raw/wpB/'


def fp(*names):
    h = hashlib.sha256()
    for n in names:
        h.update((ROOT / 'candidates' / n).read_bytes())
    return h.hexdigest()[:16]


titles = {r['question_id']: (r['title'], r['family'])
          for r in csv.DictReader(open(PKG / 'coverage-template.csv', encoding='utf-8'))}
BL, LA, DO, SG, WI, BO, CO = ('wpB_blocks.py', 'wpB_layered.py', 'wpB_domains.py', 'wpB_sigmemo.py',
                              'wpB_witness.py', 'wpB_bounds.py', 'wpB_coupled.py')
# id, new_gap, route_a, route_b, status, depth, impl, proof/cex, raw, files, domain, cost_layer, assumptions, refutation, decision, remaining
rows = [
 ('B01', 'exact boundary interface and composable block relations with incremental invalidation',
  'BlockSummary vs exact DP / world oracle with item+edge updates', 'Lemma B-1 + Theorem B-2 (proofs/wpB.md) + prune ablation',
  'implemented_verified', 'D4', 'wpB_blocks.BlockSummary; coupled wpB_coupled.BlockSession (parent: r8 omega DP)',
  '12272 checks 0 mismatch; b-1 state ablation changes 66/1500 unit sets; stale-frontier mutant killed; n96 pu0.6 B4: 647 entries 7094 exit keys',
  R + 'equiv.json; ' + R + 'prune_ablation.json; ' + R + 'studies.json#B01_blowup; ' + R + 'coupled.json', (BL, CO),
  'ext/nonneg/G0 (falls back to ext)', 'core+coupled', 'frozen scan window [i-1,i+3]', 'a world where composed blocks disagree with exact DP',
  'adopt as strong L1 kind behind raw gate', 'necessity of edge-choice/order-component retention not observed (n<=8)'),
 ('B02', 'order-type vs concrete rank summaries', 'symbolic order constraints', 'quantised K=10/50 ranks (X03)',
  'implemented_verified', 'D3', 'symbolic T.feasible (r8) vs quantised branching in run_wpB_studies',
  'ranks used only via strict order => order type exact; quantised 2.4x/29x evaluations, 0 extra certificates',
  R + 'studies.json#X03_symbolic_vs_quantized', (DO,), 'G0', 'core', 'later_wins is the only rank use',
  'a certificate only quantised ranks give', 'keep order type', 'none'),
 ('B03', 'tree-seeded exact windows', 'seeded_exact', 'exact_from_zero / tree_only', 'refuted', 'D3',
  'wpB_layered.seeded_exact', 'sound (superset entry); 14466 vs 3827 evaluations n128 pu0.3; 2-5x for single queries',
  R + 'studies.json#B03_B05_single_query', (LA,), 'ext', 'core', 'single queries', 'seeded cheaper than exact on any measured cell',
  'reject as speed-up', 'multi-query streams covered by B04'),
 ('B04', 'on-demand shared frontier with lazy block tables', 'blocks8 (lazy tables + cached prefix frontier)', 'r8 FrontierCache incumbent',
  'conditional', 'D3', 'wpB_blocks.BlockSummary(lazy=True); bench inc family',
  'n128 pu0.3 7463 vs 9627 evals (76.7 vs 98.8 ms trial); n32 loses (16.7 vs 14.3 ms; 186.2 vs 145.5 ms)',
  R + 'bench_trial.jsonl', (BL,), 'ext', 'local_measured (trial)', 'stream of updates+queries',
  'formal timing shows blocks8 slower at n>=128', 'use for long orders (n>=128); keep FrontierCache for short', 'formal timing (main session)'),
 ('B05', 'backward goal-set pruning', 'goal_pruned', 'exact_from_zero', 'refuted', 'D3', 'wpB_layered.goal_pruned',
  'sound; 11491 vs 3827 evaluations n128 pu0.3', R + 'studies.json#B03_B05_single_query', (LA,), 'ext', 'core',
  'single queries', 'goal pruning cheaper than exact anywhere', 'reject', 'none'),
 ('B06', 'precision/space/budget Pareto', 'budget sweep exact/seeded/tree on 40 cases', 'N02 state lower bound',
  'conditional', 'D3', 'wpB_layered budgets', 'exact full at 3000 (20123 evals); seeded 10000 (59264); tree 3000 (28365)',
  R + 'studies.json#B06_budget_pareto', (LA,), 'ext', 'core', 'evaluation counts as cost', 'a method dominating exact budget doubling',
  'exact DP with budget doubling', 'space axis only via table entries (B01_blowup)'),
 ('D01', 'bitset feasibility over finite masks with holes', 'feasible_bits', 'symbolic + brute force', 'implemented_verified', 'D3',
  'wpB_domains.feasible_bits/install_bitset_domain', 'Theorem D-1; 389 G0 cases 0 wrong; INT_MASK 0.1<x<0.5 infeasible; 147 vs 40 ms trial',
  R + 'domains_brute.json; ' + R + 'bench_trial.jsonl', (DO,), 'G0 + masks', 'core+local_measured', 'finite totally ordered domain',
  'bitset/symbolic disagreement', 'use only for holed masks; keep symbolic on G0', 'none'),
 ('D02', 'binary64 representative completeness', 'gap counting with nextafter', 'dense brute force', 'implemented_verified', 'D2',
  'symbolic T.feasible ext (r8)', '250 dense cases 0 mismatches', R + 'domains_brute.json', (DO,), 'ext binary64', 'core',
  'NaN excluded; -0==+0 in order', 'a gap with fewer floats than needed but reported feasible', 'keep', 'no proof assistant check'),
 ('D03', 'automatic safe domain switching', 'tag-driven select_domain + domain_ok fallback', 'shape guess (control)',
  'implemented_verified', 'D3', 'wpB_domains.select_domain; BlockSession rebuild on out-of-domain delta',
  'shape guess certifies while ext has 2 units; out-of-domain delta -> ext rebuild (test)', R + 'studies.json#D03_domain_selection', (DO, BL, CO),
  'ext/nonneg/G0', 'core+coupled', 'provenance tag names generator', 'tagged narrow domain contradicted by an admissible world',
  'tag-driven only; never shape', 'tag provenance format is package-side'),
 ('D04', 'comparison-signature memo validation', 'SigOwner', 'corrected_owner.Owner value validation', 'implemented_verified', 'D3',
  'wpB_sigmemo.SigOwner (parent: corrected_owner)', 'Theorem D-4; 0/3600 wrong, order-blind mutant 9 wrong; shuffle n64 engine runs 62->33, 164.8->82.7 ms trial',
  R + 'equiv.json; ' + R + 'bench_trial.jsonl', (SG,), 'G0', 'owner+local_measured', 'L0 public output',
  'a signature-equal state with different L0 output', 'adopt where scores churn without reordering', 'no gain when order changes (overhead 113.5 vs 81.6 ms)'),
 ('D05', 'constraint sparsity generalisation', 'width profile over 60 cases incl. pins', 'Lemma B-1 bound', 'implemented_verified', 'D2',
  'wpB_bounds.width_profile', 'max live 7, component <=2 edges, frontier <=43, pins 6', R + 'studies.json#D05_width', (BO,), 'ext', 'core',
  'generator mix', 'a case with long rank components', 'premise holds', 'adversarial long chains not generated'),
 ('D06', 'arithmetic/serialisation consistency', 'decimal vs binary64 parse', 'plan comparison', 'implemented_verified', 'D2',
  'wpB_domains.decimal_vs_binary64_case', '0.30000000000000001 vs 0.3: plans differ', R + 'studies.json#D06_decimal_vs_binary64', (DO,),
  'ext', 'core', 'JSON text input', 'n/a', 'reject non-round-trip literals', 'none'),
 ('E01', 'minimal reusable sufficient features', 'counterexample search', 'sufficiency of two-sided normalised rep', 'implemented_verified', 'D2',
  'wpB_witness', 'same stats 1.0 vs 10.8; AB 7.0 vs BA 5.0; raw many-to-one; 300 B/object', R + 'studies.json#E01', (WI,),
  'operator', 'core', 'OPTIMIZED_OPERATOR semantics', 'smaller sufficient encoding', 'keep both normalised sides', 'minimality only among tested encodings'),
 ('E02', 'joint realisability of repeated rows', 'joint-block bitset', 'lattice argument', 'implemented_verified', 'D2',
  'wpB_witness.realizable_q', 'h1=h2=1: 30 values step 50; 3/3: 1380; mixed: all', R + 'studies.json#E02_repeated_rows', (WI,),
  'operator G0', 'core', 'sound superset', 'a realisable q outside the set', 'use exclusions only', 'exactness of superset'),
 ('E03', 'common generative constraints', 'structural impossibility list', 'premise check', 'implemented_verified', 'D2',
  'wpB_witness.structural_impossible/masks_consistent', '5 impossibilities; premise violation caught by masks_consistent', R + 'studies.json#E03_structural', (WI,),
  'operator', 'core', 'GENERATIVE_DOMAIN', 'observed rank violating a listed impossibility', 'use as illegal-input checks', 'side generator unpublished'),
 ('N01', 'certificate complexity under partial evidence', 'G0 chain dependency', 'support lower-bound argument', 'limit_proved', 'D2',
  'wpB_bounds.chain_dependency', 't=6->4, 9->6, 14->10, 21->14 dependent edges => Theta(t)', R + 'studies.json#N01_chain_dependency', (BO,),
  'G0', 'core', 'support-based certificates', 'a sublinear certificate on the family', 'accept linear support', 'only one family'),
 ('N02', 'state lower bound for exact summaries', 'suffix-class counting', 'Myhill-Nerode argument', 'limit_proved', 'D2',
  'wpB_bounds.boundary_classes', 'up to 14 classes vs <=5 states; 22/40 exceed', R + 'studies.json#N02_boundary_classes', (BO,),
  'ext', 'core', 'small n exhaustive', 'state-only exact summary', 'summaries must carry assignment', 'growth rate with n not measured'),
 ('N05', 'mutation-test independence', 'shared-code mutant vs two oracles', 'oracle-independence rule', 'implemented_verified', 'D3',
  'wpB_bounds.oracle_independence', '62 active; world oracle 62; shared differential 0', R + 'studies.json#N05_oracle_independence', (BO,),
  'ext', 'core', 'n<=6 world oracle', 'shared differential catching common-mode', 'require independent oracle', 'none'),
 ('N06', 'impossibility triangle, minimal relaxation', 'chain edit radius', 'LMP/parity relaxations', 'implemented_verified', 'D2',
  'wpB_bounds (N06 study)', 'reference radius 63; LMP radius 3, 6.85% changed; parity relabels on insertion', R + 'studies.json#N06_relaxations', (BO,),
  'ext', 'core', 'frozen rule', 'exact+local+stable rule', 'no relaxation adopted', 'other relaxations'),
 ('X02', 'B01 x lazy index', 'lazy tables', 'eager build', 'implemented_verified', 'D3', 'BlockSummary(lazy)', 'far jump 1451 vs build 1453+6; sweep equal; wide-then-precise 3271',
  R + 'studies.json#X02_lazy_vs_eager', (BL,), 'ext', 'core', 'one far query', 'eager cheaper', 'lazy default', 'none'),
 ('X03', 'B02 x D01', 'symbolic', 'bitset / quantised', 'implemented_verified', 'D3', 'see B02/D01', 'identical verdicts; quantised 2.4x/29x',
  R + 'studies.json#X03_symbolic_vs_quantized', (DO,), 'G0', 'core', 'G0', 'quantised gain', 'symbolic', 'none'),
 ('X04', 'B03 x adaptive budget', 'expand_then_refine / locate_then_allocate', 'exact doubling budget', 'implemented_verified', 'D3',
  'wpB_layered budgets', '82607 / 59264 / 44773 evaluations, all 6 certified', R + 'studies.json#X04_budget_strategies', (LA,), 'ext', 'core',
  '40 cases', 'layered strategy below exact doubling', 'exact doubling', 'none'),
 ('X05', 'B04 x support DAG', 'window-dependency invalidation', 'stale-frontier mutant', 'conditional', 'D3', 'BlockSummary.update; BlockSession deltas',
  'mutant killed; coupled deltas maintain summary (wrong=0)', R + 'coupled.json', (BL, CO), 'ext/nonneg', 'core+coupled', 'owner deltas complete',
  'invalidation miss', 'keep', '0/A/B/A+B cost split not run'),
 ('X10', 'D03 x E03 geometry masks', 'G0', 'G0 + per-edge masks', 'implemented_verified', 'D3', 'wpB_witness.edge_masks_from_geometry + feasible_bits edge_masks',
  'Theorem X-10: no single-decision change; verdict unchanged; premise check needed', R + 'studies.json#X10_geometry_masks', (WI, DO), 'G0', 'core',
  'null and 0 realisable', 'a mask-induced certificate outside the i=0 chain', 'do not adopt masks', 'i=0 chain gain unmeasured'),
]

hyp = [
 ('HB1', 'B03/B05', 'QUESTIONS assume precision layering pays',
  'for single queries exact DP from position 0 beats tree-seeded and goal-pruned exact search',
  'evaluations exact/seeded/goal/tree on n in {16,64,128} x pu', 'exact cheapest in 8/9 cells; tree only at n64 pu0.6', 'D3', 'adopt exact (+budget doubling)'),
 ('HB2', 'D04', 'not in QUESTIONS: validate memo by comparison signature instead of values',
  'equal non-rank reads + null flags + compared order bits => equal L0 output',
  'SigOwner vs reference on 3600 requests; order-blind mutant', '0 wrong; mutant 9 wrong; engine runs 62->33', 'D3', 'adopt for score churn'),
 ('HB3', 'X10/E03', 'geometry masks were expected to narrow domains usefully',
  'masks never change a single later_wins decision when null and 0 are realisable', 'Theorem + G0 vs masked verdict', 'unchanged', 'D3', 'reject masks'),
 ('HB4', 'N05', 'mutation testing assumed oracle independence',
  'differential oracles sharing choice enumeration are blind to common-mode mutants', 'shared Ctx.choose mutant',
  '0/62 shared vs 62/62 independent', 'D3', 'require independent world oracle'),
 ('HB5', 'B01/N02', 'boundary interface size',
  'cursor state alone is not an exact interface; b-1 state retention is necessary', 'ablation + class counting',
  '66/1500 unit-set changes; 14 classes vs 5 states', 'D3', 'keep Lemma B-1 interface'),
]

adopt = [
 ('wpB_coupled.BlockSession (strong kind blocks)', 'L1', 'raw gate: all analyses in [0,t+3] computed and certain unit', 'L0 incumbent result',
  'admissions W01 56->34, W06 260->154, W05 17->8', 'strong evals W01 1083 (exact 2320), W06 3323', 'latency_u W01 57->77, W06 177->188',
  'W02 proof_first 52942 evals > exact 43413', 'n 32-128, service 3u, q 1u', 'when latency outweighs admissions, or updates hit many blocks/query',
  'held-out seeds 100-109', 'StrongSession strong kind', 'publish->confirm->stale; rebind->unsigned; out-of-domain rebuild', 'adopt behind gate'),
 ('wpB_blocks.BlockSummary (blocks8)', 'L1', 'n>=128 stream', 'r8 FrontierCache', 'evaluations 9627->7463 (n128 pu0.3)',
  'table maintenance', 'n32: 14.3->16.7 ms trial', 'n128 pu0.6 more evaluations (81433 vs 59671)', 'n 32-128', 'between n=32 and n=128', 'formal timing',
  'none', 'update invalidation tested', 'conditional'),
 ('wpB_sigmemo.SigOwner', 'L0', 'signature equality after exact-validation miss', 'engine run', 'engine runs 62->33 (shuffle n64)',
  'signature build per miss', 'none (falls back to engine)', 'order changes: 81.6->113.5 ms trial', 'n 16-64', 'when most misses reorder', 'formal timing',
  'Owner._valid override', 'support refreshed on hit', 'adopt for score churn'),
 ('wpB_domains.feasible_bits', 'L1', 'holed domain mask present', 'symbolic', 'none on G0', '147 vs 40 ms trial', 'n/a', '3.7x slower on G0',
  'G0 grid', 'never on G0', 'n/a', 'install_bitset_domain', 'n/a', 'reject except holed masks'),
 ('wpB_layered.seeded_exact / goal_pruned', 'L1', 'n/a', 'exact_from_zero', 'none', '2-5x evaluations', 'n/a', 'n/a', 'n16-128', 'none found', 'n/a', 'none', 'n/a', 'reject'),
]


def main():
    cov_hdr = ['question_id', 'title', 'family', 'prior_anchor', 'new_gap', 'route_a', 'route_b', 'status', 'depth', 'implementation',
               'proof_or_counterexample', 'test_command', 'raw_evidence', 'source_fingerprint', 'domain', 'cost_layer', 'assumptions',
               'refutation_condition', 'decision', 'remaining']
    with open(ROOT / 'coverage_parts' / 'wpB.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(cov_hdr)
        for (q, gap, ra, rb, st, dp, impl, pc, raw, files, dom, cl, asm, ref, dec, rem) in rows:
            title, fam = titles[q]
            w.writerow([q, title, fam, ANCH, gap, ra, rb, st, dp, impl, pc, T, raw, fp(*files), dom, cl, asm, ref, dec, rem])
    with open(ROOT / 'hypotheses_parts' / 'wpB.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['id', 'origin', 'difference_from_questions', 'prediction', 'minimal_experiment', 'result', 'depth', 'decision'])
        w.writerows(hyp)
    with open(ROOT / 'adoption_parts' / 'wpB.csv', 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(['candidate', 'route', 'gate_observable', 'fallback', 'physical_work_saved', 'extra_cost', 'first_miss_penalty',
                    'worst_case', 'parameter_range', 'reversal_point', 'min_calibration', 'interface_change', 'lifecycle_evidence', 'decision'])
        w.writerows(adopt)
    print(len(rows), len(hyp), len(adopt))


if __name__ == '__main__':
    main()
