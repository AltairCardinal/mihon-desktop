"""A3/A4/E2/E6/F3/F4 experiments on partial knowledge (abstract domains)."""
import copy
import itertools
import json
import math
import random

from common import ref, random_case, roundtrip, unit_of
import transducer as T
import omega as O


# --------------------------------------------------------------- fact model
def unknown_facts(case, domain='ext', alpha=True):
    """Unknown fact handles: ('pos', p) for an analysis, ('edge', a) for a rank."""
    F = T.Facts(case, 'omega', domain, alpha)
    out = []
    for p in range(F.n):
        if F.state[p] is None or (F.automatic and F.side[p] is None):
            out.append(('pos', p))
    for a in range(F.n - 1):
        rec = F.records.get(a)
        if not (rec and rec.get('status') == 'computed'):
            out.append(('edge', a))
    return out


def known_facts(case, domain='ext', alpha=True):
    F = T.Facts(case, 'omega', domain, alpha)
    out = []
    for p in range(F.n):
        if F.state[p] is not None and F.side[p] is not None:
            out.append(('pos', p))
    for a in range(F.n - 1):
        rec = F.records.get(a)
        if rec and rec.get('status') == 'computed':
            out.append(('edge', a))
    return out


def forget(case, handle):
    """Turn a known fact into an unknown one (counterfactual deletion)."""
    c = copy.deepcopy(case)
    kind, x = handle
    if kind == 'pos':
        c['items'][x]['analysis'] = {'status': 'unknown'}
        c['items'][x].pop('header', None)
    else:
        c['edges'] = [e for e in c.get('edges', []) if not (e['first'] == x and e['second'] == x + 1)]
    return c


def options(case, handle, domain='ext', alpha=True):
    """Finite outcome classes for revealing an unknown fact."""
    kind, x = handle
    F = T.Facts(case, 'omega', domain, alpha)
    if kind == 'pos':
        sts = (F.state[x],) if F.state[x] is not None else ('NARROW', 'WIDE')
        sds = ('A', 'B', 'UNKNOWN') if F.automatic else ('UNKNOWN',)
        return [('pos', st, sd) for st in sts for sd in sds]
    knowns = [e.get('score') for e in F.records.values() if e.get('status') == 'computed' and e.get('score') is not None]
    return [('edge', v) for v in [None] + O.ladder(domain, knowns, 2)]


def reveal(case, handle, value):
    c = copy.deepcopy(case)
    kind, x = handle
    if kind == 'pos':
        _, st, sd = value
        it = c['items'][x]
        rot, ori = it.get('rotation', 0), it.get('orientation', 1)
        w, h = (200, 200) if st == 'WIDE' else (100, 200)
        if rot in (90, 270):
            w, h = h, w
        it['analysis'] = dict(status='computed', version=1,
                              fact=dict(state=st, width=w, height=h, rotation=rot, orientation=ori, side=sd))
    else:
        c['edges'] = [e for e in c.get('edges', []) if not (e['first'] == x and e['second'] == x + 1)]
        c['edges'].append(dict(first=x, second=x + 1, status='computed', score=value[1], version=1))
    return c


def certified(case, target, domain='ext'):
    st, _u = O.certify_exact(case, target, domain)
    return st == 'certified'


# ------------------------------------------------------------------------ A3
def minimal_support(case, target, domain='ext'):
    """Greedy counterfactual-deletion minimal support (minimal, not minimum)."""
    st, unit = O.certify_exact(case, target, domain)
    if st != 'certified':
        return None
    cur = case
    support = []
    for h in sorted(known_facts(case, domain), key=lambda h: -abs((h[1]) - target)):
        trial = forget(cur, h)
        st2, u2 = O.certify_exact(trial, target, domain)
        if st2 == 'certified' and u2 == unit:
            cur = trial
        else:
            support.append(h)
    return dict(unit=unit, support=sorted(support), reduced_case=cur)


def reference_fact_reads(case, target):
    r = ref.certify(case, target)
    keys = set()
    for k in r['reads']:
        p = k.split(':')
        if p[0] in ('analysis', 'dimension', 'header'):
            keys.add(('pos', int(p[1])))
        elif p[0] == 'rank':
            keys.add(('edge', int(p[1])))
    return r, keys


# ------------------------------------------------------------------------ A4
def min_nonadaptive(case, target, domain='ext', max_size=4, cap=4000):
    """Smallest set S of unknown facts such that EVERY revelation of S certifies."""
    unk = unknown_facts(case, domain)
    budget = [cap]

    def all_certify(c, rest):
        if budget[0] <= 0:
            raise OverflowError
        if not rest:
            budget[0] -= 1
            return certified(c, target, domain)
        h = rest[0]
        return all(all_certify(reveal(c, h, v), rest[1:]) for v in options(c, h, domain))
    if certified(case, target, domain):
        return 0, ()
    for size in range(1, min(max_size, len(unk)) + 1):
        for S in itertools.combinations(unk, size):
            if all_certify(case, list(S)):
                return size, S
    return None, None


def adaptive_depth(case, target, domain='ext', max_depth=4, cap=6000):
    """Minimax number of sequential revelations needed (adversary picks values)."""
    budget = [cap]
    memo = {}

    def depth(c, d):
        key = json.dumps(c, sort_keys=True)
        if key in memo:
            return memo[key]
        budget[0] -= 1
        if budget[0] <= 0:
            raise OverflowError
        if certified(c, target, domain):
            memo[key] = 0
            return 0
        if d == 0:
            return math.inf
        best = math.inf
        for h in unknown_facts(c, domain):
            worst = 0
            for v in options(c, h, domain):
                worst = max(worst, 1 + depth(reveal(c, h, v), d - 1))
                if worst >= best:
                    break
            best = min(best, worst)
        memo[key] = best
        return best
    return depth(case, max_depth)


# ------------------------------------------------------------------------ E2
def feasible_old_representatives(constraints, domain='ext'):
    """Mutant: the earlier comparison-representative scheme (v-1 / v+1 / v)
    instead of exact adjacent doubles.  Unsound when v-1 == v (N03)."""
    vars_ = sorted({t[1] for (xy, _) in constraints for t in xy if t[0] == 'e'})
    knowns = sorted({t[1] for (xy, _) in constraints for t in xy if t[0] == 'k'})
    cands = set()
    for k in knowns:
        cands.update((k - 1, k, k + 1))
    if not knowns:
        cands.update((0, 1, 2))
    for assign in itertools.product(sorted(cands), repeat=len(vars_)):
        m = dict(zip(vars_, assign))
        val = lambda t: m[t[1]] if t[0] == 'e' else t[1]
        if all((val(xy[0]) < val(xy[1])) == out for xy, out in constraints):
            return True
    return False
