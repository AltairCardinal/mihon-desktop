"""WP-C: on-demand full-information structures (C01-C06, O02, O03, X06, X09).

All classes use complete_plan semantics (the full-information consumer) and are
verified against reference.complete_plan.  Common API:
    set_item(p, item), set_edge(a, record_or_None), unit(t), plan(), prefix(t)
    work (Counter-like dict), residency() -> structural entries currently held

Classes
  PrefixScan       incumbent for sparse point queries: scan 0..t on every query,
                   no retained structure (residency 0).
  LazyTree         C01-A: segment tree whose leaves/nodes are built only when a
                   prefix query needs them; updates invalidate leaf+ancestors.
  SparseCheckpoints C01-B: boundary states kept every K positions, created on
                   demand by linear stepping; updates drop checkpoints >= p-2.
  DirtyLogTree     C02-A: updates only append to a bounded dirty log (O(1));
                   the log is flushed by the next query; overflow drops the tree.
  Hybrid           C03: dense resync states with a propagation cap; on overflow a
                   LazyTree is promoted (never prebuilt); while promoted every
                   update asks the tree whether the boundary state at p+2 changed
                   and after D quiet updates the tree is dropped (demotion).
  RopePlan         C04: chunked rope of leaf functions supporting insert/delete;
                   chunks away from the edit keep their composed function.
"""
import bisect
from collections import Counter

import paths  # noqa: F401
import transducer as T

SKIP0, SKIP1 = T.enc(T.SKIP, 0), T.enc(T.SKIP, 1)


def _step(ctx, i, s, include):
    ctx.asg = {}
    return T.step_result(ctx, i, s, include=include)


def _unit_from_states(ctx, t, s_t, s_tm1):
    """Unit containing t given boundary states before t and before t-1."""
    if s_t >> 1 == T.SKIP:
        return _step(ctx, t - 1, s_tm1, True)[1]
    return _step(ctx, t, s_t, True)[1]


class _Base:
    def __init__(self, case):
        from copy import deepcopy
        self.F = T.Facts(deepcopy(case), 'complete')
        self.ctx = T.Ctx(self.F)
        self.n = self.F.n
        self.work = Counter()

    def _touch(self, p):            # positions whose leaves change when p changes
        return range(max(0, p - 3), min(self.n, p + 2))

    def set_item(self, p, item):
        self.F.set_item(p, item)
        self.work['updates'] += 1
        self._changed(p, p)

    def set_edge(self, a, record):
        self.F.set_edge(a, record)
        self.work['updates'] += 1
        self._changed(a, a)

    def plan(self):
        out, s, i = [], T.S0, 0
        while i < self.n:
            nxt, u = _step(self.ctx, i, s, True)
            self.work['steps'] += 1
            out.append(u)
            if nxt >> 1 == T.SKIP:
                s = _step(self.ctx, i + 1, nxt, False)[0]
                self.work['steps'] += 1
                i += 2
            else:
                s, i = nxt, i + 1
        self.work['output_units'] += len(out)
        return out

    def prefix(self, t):
        """Units covering positions 0..t (prefix consumer)."""
        out, s, i = [], T.S0, 0
        while i <= t:
            nxt, u = _step(self.ctx, i, s, True)
            self.work['steps'] += 1
            out.append(u)
            if nxt >> 1 == T.SKIP:
                s = _step(self.ctx, i + 1, nxt, False)[0]
                i += 2
            else:
                s, i = nxt, i + 1
        self.work['output_units'] += len(out)
        return out

    def residency(self):
        return 0


class PrefixScan(_Base):
    name = 'prefixscan'

    def _changed(self, lo, hi):
        pass

    def unit(self, t):
        s, prev = T.S0, None
        for i in range(t):
            prev = s
            s = _step(self.ctx, i, s, False)[0]
            self.work['steps'] += 1
        self.work['queries'] += 1
        return _unit_from_states(self.ctx, t, s, prev)


class LazyTree(_Base):
    name = 'lazytree'

    def __init__(self, case):
        super().__init__(case)
        size = 1
        while size < max(1, self.n):
            size *= 2
        self.size = size
        self.leaves = [None] * self.n
        self.nodes = [None] * (2 * size)

    def _leaf(self, i):
        f = self.leaves[i]
        if f is None:
            f = self.leaves[i] = T.leaf_fast(self.ctx, i)
            self.work['leaf_evals'] += 1
        return f

    def _node(self, v, lo, hi):
        f = self.nodes[v]
        if f is not None:
            return f
        if hi - lo == 1:
            f = self._leaf(lo) if lo < self.n else T.IDENTITY
        else:
            mid = (lo + hi) // 2
            f = T.compose(self._node(2 * v, lo, mid), self._node(2 * v + 1, mid, hi))
            self.work['node_compose'] += 1
        self.nodes[v] = f
        return f

    def _invalidate(self, i):
        if 0 <= i < self.n:
            if self.leaves[i] is not None:
                self.leaves[i] = None
            v = (self.size + i)
            # invariant: a built node has built children, so the first unbuilt
            # node on the path has only unbuilt ancestors
            while v and self.nodes[v] is not None:
                self.nodes[v] = None
                v //= 2
            self.work['invalidations'] += 1

    def _changed(self, lo, hi):
        for i in range(max(0, lo - 3), min(self.n, hi + 2)):
            self._invalidate(i)

    def state(self, t):
        states, v, lo, hi = 1 << T.S0, 1, 0, self.size
        while t > lo:
            if t >= hi:
                return T.apply(self._node(v, lo, hi), states).bit_length() - 1
            mid = (lo + hi) // 2
            if t >= mid:
                states = T.apply(self._node(2 * v, lo, mid), states)
                v, lo = 2 * v + 1, mid
            else:
                v, hi = 2 * v, mid
        return states.bit_length() - 1

    def unit(self, t):
        self.work['queries'] += 1
        s = self.state(t)
        return _unit_from_states(self.ctx, t, s, self.state(t - 1) if s >> 1 == T.SKIP else None)

    def residency(self):
        return sum(1 for x in self.leaves if x is not None) + sum(1 for x in self.nodes if x is not None)


class DirtyLogTree(LazyTree):
    """Route C02-A: O(1) updates; repairs happen at the next query."""
    name = 'dirtylog'

    def __init__(self, case, cap=64):
        super().__init__(case)
        self.cap = cap
        self.dirty = set()

    def _changed(self, lo, hi):
        self.dirty.add(lo)
        self.work['log_appends'] += 1
        if len(self.dirty) > self.cap:          # bounded log: forget everything instead of growing
            self.leaves = [None] * self.n
            self.nodes = [None] * (2 * self.size)
            self.dirty.clear()
            self.work['log_overflow_drops'] += 1

    def unit(self, t):
        for p in self.dirty:
            LazyTree._changed(self, p, p)
        self.dirty.clear()
        return super().unit(t)

    def residency(self):
        return super().residency() + len(self.dirty)


class SparseCheckpoints(_Base):
    name = 'sparsecp'

    def __init__(self, case, K=16):
        super().__init__(case)
        self.K = K
        self.keys = [0]
        self.cp = {0: T.S0}

    def _changed(self, lo, hi):
        cut = max(1, lo - 2)
        j = bisect.bisect_left(self.keys, cut)
        for k in self.keys[j:]:
            del self.cp[k]
        del self.keys[j:]
        self.work['cp_drops'] += 1

    def unit(self, t):
        self.work['queries'] += 1
        j = bisect.bisect_right(self.keys, t) - 1
        b = self.keys[j]
        s, prev = self.cp[b], None
        for i in range(b, t):
            prev = s
            s = _step(self.ctx, i, s, False)[0]
            self.work['steps'] += 1
            nb = i + 1
            if nb % self.K == 0 and nb not in self.cp:
                self.cp[nb] = s
                bisect.insort(self.keys, nb)
        if s >> 1 == T.SKIP and prev is None:      # b == t: need the state before t-1
            return self._unit_slow(t)
        return _unit_from_states(self.ctx, t, s, prev)

    def _unit_slow(self, t):
        j = bisect.bisect_right(self.keys, t - 1) - 1
        b = self.keys[j]
        s = self.cp[b]
        for i in range(b, t - 1):
            s = _step(self.ctx, i, s, False)[0]
            self.work['steps'] += 1
        return _step(self.ctx, t - 1, s, True)[1]

    def residency(self):
        return len(self.cp)


class Hybrid(_Base):
    """C03: dense resync states, capped propagation, lazy tree promotion, demotion."""
    name = 'hybrid'

    def __init__(self, case, cap=32, quiet_to_demote=8, prebuild_states=False):
        super().__init__(case)
        self.cap, self.D = cap, quiet_to_demote
        self.states = [None] * (self.n + 1)
        self.states[0] = T.S0
        self.valid = 0                 # states[0..valid] are valid
        self.tree = None
        self.quiet = 0
        if prebuild_states:
            self._extend(self.n)

    def _extend(self, upto):
        s = self.states[self.valid]
        for i in range(self.valid, min(upto, self.n)):
            s = _step(self.ctx, i, s, False)[0]
            self.work['steps'] += 1
            self.states[i + 1] = s
            self.valid = i + 1

    def _changed(self, lo, hi):
        if self.tree is not None:
            # ask the tree whether the change propagates beyond the local window
            probe = min(self.n, hi + 2)
            before = self.tree.state(probe)
            LazyTree._changed(self.tree, lo, hi)
            after = self.tree.state(probe)
            self.work['tree_probes'] += 2
            self.valid = min(self.valid, max(0, lo - 3))
            if before == after:
                self.quiet += 1
                if self.quiet >= self.D:
                    self.work['demotions'] += 1
                    self.work['tree_residency_dropped'] += self.tree.residency()
                    self.tree = None
                    self.quiet = 0
            else:
                self.quiet = 0
            return
        start = max(0, lo - 3)
        if start >= self.valid:
            return                      # beyond the materialised prefix: nothing to repair
        s = self.states[start]
        steps = 0
        i = start
        while i < self.valid:
            old_next = self.states[i + 1]
            s = _step(self.ctx, i, s, False)[0]
            steps += 1
            self.states[i + 1] = s
            if i >= hi + 1 and s == old_next:
                break
            if steps > self.cap:
                # propagation too long: promote a lazily built tree, truncate states
                self.valid = i + 1
                self.tree = LazyTree.__new__(LazyTree)
                _Base.__init__(self.tree, {'items': [], 'settings': {}})
                self.tree.F, self.tree.ctx, self.tree.n = self.F, self.ctx, self.n
                size = 1
                while size < max(1, self.n):
                    size *= 2
                self.tree.size = size
                self.tree.leaves = [None] * self.n
                self.tree.nodes = [None] * (2 * size)
                self.tree.work = self.work
                self.work['promotions'] += 1
                self.quiet = 0
                break
            i += 1
        self.work['resync_steps'] += steps

    def unit(self, t):
        self.work['queries'] += 1
        if self.tree is not None and t > self.valid:
            return self.tree.unit(t)
        if t > self.valid:
            self._extend(t)
        s = self.states[t]
        return _unit_from_states(self.ctx, t, s, self.states[t - 1] if t >= 1 else None)

    def residency(self):
        return self.valid + (self.tree.residency() if self.tree is not None else 0)


class RopePlan:
    """C04 route A: order changes on a chunked rope of leaf functions.

    Precondition (checked): settings contain no absolute ordinals (no hard
    isolates, no pinned links, opening != PAIR); then leaf i's function depends
    only on facts in [i-1, i+3] and on the predicates i==0, i==n-1, i+2>=n, so a
    leaf whose window and boundary predicates are unchanged by the edit keeps
    its function after translation (lemma C04-1 in proofs/wpC.md).
    """
    name = 'rope'

    def __init__(self, case, B=32):
        from copy import deepcopy
        s = case.get('settings', {})
        if s.get('hard_isolates') or s.get('pinned_links') or s.get('opening', 'AUTO') == 'PAIR':
            raise ValueError('rope reuse requires ordinal-free settings')
        self.case = deepcopy(case)
        self.B = B
        self.work = Counter()
        self._rebuild_facts()
        self.fns = [T.leaf_fast(self.ctx, i) for i in range(self.n)]
        self.work['leaf_evals'] += self.n
        self._rechunk()

    def _rebuild_facts(self):
        self.F = T.Facts(self.case, 'complete')
        self.ctx = T.Ctx(self.F)
        self.n = self.F.n
        self.work['fact_parse_slots'] += self.n

    def _rechunk(self):
        self.chunks = []
        for a in range(0, self.n, self.B):
            seg = list(range(a, min(self.n, a + self.B)))
            f = T.IDENTITY
            for i in seg:
                f = T.compose(f, self.fns[i])
            self.chunks.append([len(seg), f])
            self.work['node_compose'] += len(seg)

    def _recompose_chunk(self, c, start):
        f = T.IDENTITY
        for i in range(start, start + self.chunks[c][0]):
            f = T.compose(f, self.fns[i])
        self.chunks[c][1] = f
        self.work['node_compose'] += self.chunks[c][0]

    def _chunk_of(self, p):
        acc = 0
        for c, (ln, _f) in enumerate(self.chunks):
            if p < acc + ln:
                return c, acc
            acc += ln
        return len(self.chunks) - 1, acc - self.chunks[-1][0]

    def _edit(self, p, chunk_pos, fn_list_op, size_delta):
        c, _start = self._chunk_of(chunk_pos)
        fn_list_op()
        self._rebuild_facts()          # fact arrays are re-indexed (O(n) parse, counted)
        dirty = set(range(max(0, p - 4), min(self.n, p + 5))) | {0, 1} | set(range(max(0, self.n - 4), self.n))
        for i in dirty:
            self.fns[i] = T.leaf_fast(self.ctx, i)
            self.work['leaf_evals'] += 1
        self.chunks[c][0] += size_delta
        if self.chunks[c][0] <= 0:
            del self.chunks[c]
        recompute = set()
        acc = 0
        for k, (ln, _f) in enumerate(self.chunks):
            if any(acc <= i < acc + ln for i in dirty):
                recompute.add((k, acc))
            acc += ln
        for k, st in recompute:
            self._recompose_chunk(k, st)
        if max((ln for ln, _ in self.chunks), default=0) > 2 * self.B:
            self._rechunk()

    def insert(self, p, item, left_edge=None, right_edge=None):
        """Insert item at ordinal p; edges (p-1,p),(p,p+1) records supplied by caller."""
        items = self.case['items']
        old_edges = {(e['first'], e['second']): e for e in self.case.get('edges', [])}
        new_edges = []
        for (a, b), e in old_edges.items():
            if b <= p - 1:
                new_edges.append(dict(e))
            elif a >= p:
                new_edges.append(dict(e, first=a + 1, second=b + 1))
        if left_edge is not None and p > 0:
            new_edges.append(dict(left_edge, first=p - 1, second=p))
        if right_edge is not None and p < len(items):
            new_edges.append(dict(right_edge, first=p, second=p + 1))
        items.insert(p, item)
        self.case['edges'] = new_edges
        self._edit(p, p, lambda: self.fns.insert(p, None), +1)

    def delete(self, p, bridge_edge=None):
        items = self.case['items']
        old_edges = {(e['first'], e['second']): e for e in self.case.get('edges', [])}
        new_edges = []
        for (a, b), e in old_edges.items():
            if b <= p - 1:
                new_edges.append(dict(e))
            elif a >= p + 1:
                new_edges.append(dict(e, first=a - 1, second=b - 1))
        if bridge_edge is not None and 0 < p < len(items) - 1:
            new_edges.append(dict(bridge_edge, first=p - 1, second=p))
        del items[p]
        self.case['edges'] = new_edges
        self._edit(max(0, p - 1), p, lambda: self.fns.pop(p), -1)

    def state(self, t):
        s = 1 << T.S0
        acc = 0
        for ln, f in self.chunks:
            if acc + ln <= t:
                s = T.apply(f, s)
                acc += ln
                continue
            for i in range(acc, t):
                s = T.apply(self.fns[i], s)
            break
        return s.bit_length() - 1

    def unit(self, t):
        self.work['queries'] += 1
        s = self.state(t)
        return _unit_from_states(self.ctx, t, s, self.state(t - 1) if s >> 1 == T.SKIP else None)

    def residency(self):
        return self.n + len(self.chunks)


STRUCTURES = {c.name: c for c in (PrefixScan, LazyTree, DirtyLogTree, SparseCheckpoints, Hybrid)}
