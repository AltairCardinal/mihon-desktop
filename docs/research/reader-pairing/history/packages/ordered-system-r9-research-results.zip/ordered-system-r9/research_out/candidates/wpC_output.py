"""WP-C consumers and output organisation (C05, C06, O02, O03, O04, X09).

O02 DiffPlan: a NEW consumer interface - after each update it emits only the
    (position, unit) pairs whose covering unit changed.  Output-sensitive lower
    bound: any exact diff stream must emit >= |changed units| entries; on a
    phase flip that is Theta(n) (proof wpC.md O02), so the diff API only helps
    when changes are local.  Implementation: dense resync states with cover
    array; the resync range is exactly where units can change (L-S lemma).
C05 Batched: k updates buffered, one repair; intermediate versions are not
    observable (declared); replay log variant applies on the next read.
O03 Neighbour precompile and O04 background build live in wpC_coupled.py /
    the experiment driver because they need a time/budget model.
"""
from collections import Counter

import paths  # noqa: F401
import transducer as T
from wpC_structures import _Base, _step, LazyTree


class DiffPlan(_Base):
    name = 'diffplan'

    def __init__(self, case):
        super().__init__(case)
        n = self.n
        self.states = [None] * (n + 1)
        self.cover = [None] * n
        self._scan(0, T.S0, None)

    def _scan(self, start, s, stop_after):
        changed = []
        i = start
        while i < self.n:
            old_next = self.states[i + 1]
            self.states[i] = s
            nxt, unit = _step(self.ctx, i, s, True)
            self.work['steps'] += 1
            if unit is not None:
                for sl in unit['slots']:
                    if self.cover[sl['item']] != unit:
                        changed.append((sl['item'], unit))
                    self.cover[sl['item']] = unit
            if stop_after is not None and i >= stop_after and old_next == nxt:
                self.states[i + 1] = nxt
                break
            self.states[i + 1] = nxt
            s = nxt
            i += 1
        return changed

    def _changed(self, lo, hi):
        start = max(0, lo - 3)
        self.last_diff = self._scan(start, self.states[start], hi + 1)
        self.work['diff_entries'] += len(self.last_diff)

    def unit(self, t):
        return self.cover[t]


class Batched(LazyTree):
    """C05 route A: apply a batch atomically; the tree is repaired once."""
    name = 'batched'

    def apply_batch(self, item_updates=(), edge_updates=()):
        lo, hi = self.n, -1
        for p, item in item_updates:
            self.F.set_item(p, item)
            lo, hi = min(lo, p), max(hi, p)
        for a, rec in edge_updates:
            self.F.set_edge(a, rec)
            lo, hi = min(lo, a), max(hi, a)
        self.work['batches'] += 1
        touched = set()
        for p, _ in item_updates:
            touched.update(range(max(0, p - 3), min(self.n, p + 2)))
        for a, _ in edge_updates:
            touched.update(range(max(0, a - 3), min(self.n, a + 2)))
        for i in touched:
            self._invalidate(i)


class ReplayLog(LazyTree):
    """C05 route B: deltas are logged and replayed (into the facts) on the next read."""
    name = 'replaylog'

    def __init__(self, case, cap=256):
        super().__init__(case)
        self.log, self.cap = [], cap

    def set_item(self, p, item):
        self.log.append(('i', p, item)); self.work['log_appends'] += 1
        if len(self.log) > self.cap:
            self._replay()

    def set_edge(self, a, rec):
        self.log.append(('e', a, rec)); self.work['log_appends'] += 1
        if len(self.log) > self.cap:
            self._replay()

    def _replay(self):
        for kind, x, v in self.log:
            (self.F.set_item if kind == 'i' else self.F.set_edge)(x, v)
            LazyTree._changed(self, x, x)
        self.work['replays'] += 1
        self.log = []

    def unit(self, t):
        if self.log:
            self._replay()
        return super().unit(t)

    def residency(self):
        return super().residency() + len(self.log)
