"""WP-H second routes for items whose first route was analytic/arithmetic only.

I04 route B: queueing DES (C slots, FIFO) where splitting the service into acquire|derive and skipping derive
when the gate says it is not needed reduces *load*, so the queueing delay of OTHER jobs falls; the analytic
route A (wpH_exp_sched.i04) only counts per-job work and one extra hop.
J06 route B: speculative credit inside the physical simulator (wpH_sched.Sim, C=1): mispredicting hotspot H
and well-predicted G share or isolate a speculation credit; credit refunded on a useful hit ('refund') is a
third organisation.  Measures G's required latency and wasted work, not just credit counts.
"""
import heapq
import json
from pathlib import Path

import paths  # noqa: F401
from wpH_sched import Sim, latent

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpH'


def split_des(n_jobs, gap, a, d, p_need, hop, split, C=1, seed=0):
    """FIFO C-slot queue.  joint job = one phase a+d.  split job = phase a, then (iff needed, keyed latent)
    a second phase d re-enqueued after `hop` u.  Returns total/max latency and busy work."""
    need = {j: latent(seed, ('need', j), 0, 1, 1000) <= int(p_need * 1000) for j in range(n_jobs)}
    ev = []          # (time, seq, kind, job, phase)
    seq = 0
    for j in range(n_jobs):
        heapq.heappush(ev, (j * gap, seq, 'arrive', j, 1)); seq += 1
    queue, busy, now, work = [], 0, 0, 0
    done, arrive = {}, {}
    while ev:
        now, _, kind, j, ph = heapq.heappop(ev)
        if kind == 'arrive':
            arrive.setdefault(j, now)
            queue.append((j, ph))
        elif kind == 'finish':
            busy -= 1
            if split and ph == 1 and need[j]:
                heapq.heappush(ev, (now + hop, seq, 'arrive', j, 2)); seq += 1
            else:
                done[j] = now
        while busy < C and queue:
            jj, pp = queue.pop(0)
            dur = (a + d) if not split else (a if pp == 1 else d)
            work += dur
            busy += 1
            heapq.heappush(ev, (now + dur, seq, 'finish', jj, pp)); seq += 1
    lats = [done[j] - arrive[j] for j in range(n_jobs)]
    lats_needed = [done[j] - arrive[j] for j in range(n_jobs) if need[j]]
    return dict(total=sum(lats), max=max(lats), work=work, needed_max=max(lats_needed) if lats_needed else 0,
                needed_total=sum(lats_needed))


def i04_des():
    rows = []
    for a, d in ((1, 5), (2, 10), (5, 5), (5, 20)):
        for p in (0.25, 0.5, 1.0):
            for gap in (4, 8, 16):
                for hop in (1, 3):
                    j = split_des(60, gap, a, d, p, hop, False)
                    s = split_des(60, gap, a, d, p, hop, True)
                    rows.append(dict(acquire=a, derive=d, p_need=p, gap=gap, hop=hop, rho_joint=round((a + d) / gap, 3),
                                     joint_total=j['total'], split_total=s['total'], joint_needed_total=j['needed_total'],
                                     split_needed_total=s['needed_total'], joint_work=j['work'], split_work=s['work'],
                                     split_wins_latency_for_needed=s['needed_total'] < j['needed_total']))
    return dict(rows=rows, note='C=1 FIFO; need flag keyed by job identity (fixed before any policy); split pays '
                                'hop + re-queue for needed jobs but removes (1-p)*d load from the queue')


def j06_sim(seeds=range(4)):
    """Two request streams on C=1.  Hotspot H asks 3x per period and its speculation is always wrong (a
    never-used witness); G asks once per period, after H, and its speculation is right (next G witness).
    Speculation is admitted only while the credit pool allows it.  'refund_*' returns a credit to the
    requester's pool when a later required intent actually needs the speculated witness."""
    rows = []
    for seed in seeds:
        lat, ints = {}, []
        for k in range(20):
            lat[f'g{k}'] = latent(seed, f'g{k}', 0, 2, 4)
            ints.append(dict(at=12 * k + 4, id=f'G{k}', needs=[f'g{k}'], required=True))
            for m in range(3):
                lat[f'h{k}_{m}'] = latent(seed, f'h{k}_{m}', 0, 1, 2)
                lat[f'hx{k}_{m}'] = latent(seed, f'hx{k}_{m}', 0, 2, 4)
                ints.append(dict(at=12 * k + m, id=f'H{k}_{m}', needs=[f'h{k}_{m}'], required=True))
        base_work = sum(lat[x] for x in lat if not x.startswith('hx'))
        for org in ('none', 'global', 'isolated', 'refund_global', 'refund_isolated'):
            pool = {'global': 6} if org.endswith('global') else {'H': 3, 'G': 3}
            spent = {'H': 0, 'G': 0}
            issued = []

            def hook(sim, it, org=org, pool=pool, spent=spent, issued=issued):
                if org == 'none':
                    return
                who = it['id'][0]
                if org.startswith('refund'):
                    for e in list(issued):
                        if e[1] in it['needs']:
                            issued.remove(e)
                            pool['global' if org.endswith('global') else e[0]] += 1
                key = 'global' if org.endswith('global') else who
                k = int(it['id'][1:].split('_')[0])
                if pool[key] <= 0 or k + 1 >= 20:
                    return
                pool[key] -= 1
                spent[who] += 1
                ident = f'hx{it["id"][1:]}' if who == 'H' else f'g{k + 1}'
                issued.append((who, ident))
                sim.request(ident, False, f'spec_{it["id"]}')
            sim = Sim(1, lat, dict(order='required_first', retain=8))
            r = sim.run(ints, hooks=dict(on_intent=hook))
            g = [it['done'] - it['at'] for i, it in sim.intents.items() if i.startswith('G')]
            h = [it['done'] - it['at'] for i, it in sim.intents.items() if i.startswith('H')]
            rows.append(dict(seed=seed, organisation=org, spent_H=spent['H'], spent_G=spent['G'],
                             G_total=sum(g), G_max=max(g), H_total=sum(h), H_max=max(h),
                             extra_work_u=r['busy_u'] - base_work, unserved=r['unserved']))
    return dict(rows=rows, note='C=1; extra_work_u = busy work beyond the required witnesses (speculation '
                                'that was never used, plus nothing else)')


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    res = dict(I04_des=i04_des(), J06_sim=j06_sim())
    (OUT / 'extra.json').write_text(json.dumps(res, indent=1))
    return res


if __name__ == '__main__':
    r = main()
    wins = [x for x in r['I04_des']['rows'] if x['split_wins_latency_for_needed']]
    print('I04 split wins needed-latency in', len(wins), 'of', len(r['I04_des']['rows']))
    for x in r['I04_des']['rows'][:72:6]:
        print(x)
    for x in r['J06_sim']['rows']:
        print(x)
