"""WP-A D3 registration (see CONVENTIONS.md / drive_formal.py).

Every scenario is one coupled trace run end to end on coupling.Session/StrongSession
(virtual u: service_u per physical service, q_u per proof attempt on one compute lane).
CANDIDATES[0] = 'incumbent' (L0 policy on the same trace).  wall_ns = local wall of the
whole run (local_measured layer; never mixed with u).  `work` carries the virtual and
physical metrics.  ok = no wrong publication, every intent published, no livelock.

Candidates
  incumbent              L0 only (package policy, resident-aware acquisition)
  gated_shadow           KEEP: proof publishes only; physical schedule == incumbent (lemma S1)
  shadow                 same without the observable gate (gate ablation)
  gated_keep             race without cancellation, target leaves queue on proof publication
  race_keep              same, ungated
  gated_proof_first      proof blocks the target's acquisitions (physical-saving route)
  persistent_gated_shadow gated_shadow on the incremental relation tree (O01/P03 compute route)
  ski                    rent-or-buy per need signature (negative control)
  adaptive               Beta-LCB per observable class (negative control)
  race_cancel            race with cancellation of unneeded tasks (negative control: destroys reusable evidence)
"""
import hashlib, json, sys, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
import paths  # noqa
import wpA_lib as A

CANDIDATES = ['incumbent', 'gated_shadow', 'shadow', 'gated_keep', 'race_keep', 'gated_proof_first',
              'persistent_gated_shadow', 'ski', 'adaptive', 'race_cancel']
_POLICY = dict(incumbent='incumbent', gated_shadow='gated_shadow', shadow='shadow', gated_keep='gated_keep',
               race_keep='race_keep', gated_proof_first='gated', persistent_gated_shadow='gated_shadow',
               ski='ski', adaptive='adaptive', race_cancel='race')


def _traces():
    tun = {t['name']: t for t in A.tuning_traces()}
    ho2 = {t['name']: t for t in A.heldout2_traces()}
    ho = {t['name']: t for t in A.heldout_traces()}
    return tun, ho, ho2


_TUN, _HO, _HO2 = _traces()
SCENARIOS = []
for src, pool in (('tuning', _TUN), ('heldout', _HO), ('heldout2', _HO2)):
    for name in sorted(pool):
        for su, q in ((4, 1), (8, 4)):
            SCENARIOS.append(dict(name=f'{src}:{name}:su{su}:q{q}', source=src, trace=name, service_u=su, q_u=q,
                                  capacity=3))
# lifecycle scenario: rebind (content replacement inside the support) mid-trace + raw eviction
SCENARIOS.append(dict(name='lifecycle:RE_rebind_evict:su4:q1', source='lifecycle', trace=None, service_u=4, q_u=1,
                      capacity=3))
# capacity-1 scenario where an early proof publication used to suppress reused acquisitions
SCENARIOS.append(dict(name='cex:race_keep_cap1:su3:q1', source='cex', trace=None, service_u=3, q_u=1, capacity=1))


def _lifecycle_trace():
    tr = A.reserved_eviction(7, n=40, holes=(9,), pattern='sweep', count_=20, gap=10)
    from copy import deepcopy
    ev = list(tr['events'])
    w = deepcopy(tr['world'][11]); w['raw'] = w['raw'] + 5
    ev.append(dict(at=75, op='rebind', item=11, witness=w))
    ev.append(dict(at=120, op='evict_raw'))
    ev.sort(key=lambda e: e['at'])
    return dict(tr, name='RE_rebind_evict', events=ev)


def _trace(sc):
    if sc['source'] == 'lifecycle':
        return _lifecycle_trace()
    if sc['source'] == 'cex':
        return json.loads((HERE.parents[1] / 'results/raw/wpA/race_keep_counterexample.json').read_text())['trace']
    return dict(tuning=_TUN, heldout=_HO, heldout2=_HO2)[sc['source']][sc['trace']]


WORK_KEYS = ('total_latency_u', 'max_latency_u', 'physical_admissions', 'physical_finishes', 'discarded',
             'raw_insertions', 'rank_computations', 'strong_attempts', 'strong_certificates', 'strong_evaluations',
             'certification_calls', 'certification_steps', 'proof_starts', 'proof_wins', 'race_cancels',
             'gate_skips', 'lane_busy_u', 'refusals', 'publish_rejects', 'rebinds', 'end_u', 'wasted_proofs')


def run_one(sc, cand, rep=0):
    tr = _trace(sc)
    kw = dict(service_u=sc['service_u'], q_u=sc['q_u'], capacity=sc['capacity'],
              persistent=cand.startswith('persistent'))
    runner = A.make_runner(tr, _POLICY[cand], **kw)
    t0 = time.perf_counter_ns()
    r = runner.run(max_steps=40000)
    wall = time.perf_counter_ns() - t0
    pubs = sorted((int(k), repr(v)) for k, v in runner.session.published.items())
    sha = hashlib.sha256(json.dumps(dict(pubs=pubs, first=sorted(runner.first_pub)), sort_keys=True).encode()).hexdigest()
    ok = r['wrong'] == 0 and r['published'] == r['intents'] and not r['livelock']
    work = {k: r.get(k, 0) for k in WORK_KEYS}
    work['strong_ns_local'] = r.get('strong_ns', 0)
    return dict(wall_ns=wall, verdict_sha256=sha, ok=ok, work=work, wrong=r['wrong'],
                published=r['published'], intents=r['intents'], livelock=r['livelock'],
                latency_u=r['latency_u'])


if __name__ == '__main__':          # smoke: one rep, incumbent vs gated_shadow on 3 scenarios
    for sc in SCENARIOS[:1] + SCENARIOS[-2:]:
        for c in ('incumbent', 'gated_shadow', 'race_keep'):
            row = run_one(sc, c)
            print(sc['name'], c, row['ok'], row['work']['total_latency_u'], row['work']['physical_admissions'])
