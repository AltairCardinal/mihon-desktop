"""B03/B05/B06/X04: layered precision and goal-directed exact search (WP-B).

seeded_exact  (B03 route A / X04 'locate then allocate')
    tree (cheap over-approximation) first; if not a singleton, run the exact
    shared-assignment DP from boundary f = t-k whose entry frontier is the TREE
    reachable state set with an empty assignment (sound: the tree
    over-approximates reachable states and an empty assignment leaves every
    prefix-bound variable free).  k doubles until certified or f = 0 (exact).
goal_pruned   (B05)
    exact DP from 0, dropping frontier elements whose state cannot reach a
    target unit different from u0 according to backward sets computed on the
    tree relation (an over-approximation of 'can reach'), so pruning never
    removes a world whose unit differs from u0.
budgeted      (B06)  any of the above with an evaluation budget; exceeding it
    returns 'unknown' (conservative) and keeps the spent work in the counters.
"""
import paths  # noqa: F401
import transducer as T
import omega as O


class Stop(Exception):
    pass


_ACTIVE = []
_ORIG_EXPLORE = T.explore


def _counting_explore(ctx, fn, base=None):
    out = _ORIG_EXPLORE(ctx, fn, base)
    if _ACTIVE:
        _ACTIVE[-1].tick(max(1, len(out)))
    return out




class _Budget:
    def __init__(self, limit):
        self.n, self.limit = 0, limit

    def __enter__(self):
        _ACTIVE.append(self)
        return self

    def __exit__(self, *e):
        _ACTIVE.pop()
        return False

    def tick(self, k):
        self.n += k
        if self.limit is not None and self.n > self.limit:
            raise Stop()


def _budgeted(fn):
    def wrapper(*args, budget=None, counters=None, **kw):
        bud = _Budget(budget)
        _ACTIVE.append(bud)
        T.explore = _counting_explore      # installed only while a budgeted call is active
        try:
            return fn(*args, bud=bud, c=(counters if counters is not None else {}), **kw)
        finally:
            _ACTIVE.pop()
            if not _ACTIVE:
                T.explore = _ORIG_EXPLORE
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


def _dp(ctx, target, first, entry, budget, keep=None):
    """Exact DP from boundary `first` with entry frontier `entry`.
    keep(b, state) -> bool filters frontier elements at boundary b."""
    frontier = set(entry)
    units = {}
    for i in range(first, target + 1):
        include = i >= target - 1
        if keep is not None:
            frontier = {x for x in frontier if keep(i, x[0])}
        nxt = set()
        for s, asg in frontier:
            if s >> 1 == T.SKIP and i == target:
                continue
            res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=include), dict(asg))
            for (ns, unit), a in res:
                if include and unit is not None and any(sl['item'] == target for sl in unit['slots']):
                    units[T._key(unit)] = unit
                elif i < target:
                    nxt.add((ns, frozenset(O._prune(a, i).items())))
        frontier = nxt
    return units


class LazyRel:
    """Lazy independent-leaf relation (frontier route one, lazy nodes): leaves are
    built only when a prefix needs them; prefix masks are cached per boundary."""

    def __init__(self, F):
        self.F = F
        self.ctx = T.Ctx(F)
        self.leaves = {}
        self.masks = {0: 1 << T.S0}
        self.size = 0
        self.tree = self                   # duck-typing for goal_pruned (tree.tree[tree.size+b])

    def __getitem__(self, b):
        lf = self.leaves.get(b)
        if lf is None:
            lf = T.leaf_fast(self.ctx, b)
            self.leaves[b] = lf
        return lf

    def prefix(self, t):
        known = max(k for k in self.masks if k <= t)
        m = self.masks[known]
        for b in range(known, t):
            m = T.apply(self[b], m)
            self.masks[b + 1] = m
        return m

    def units(self, target):
        ctx = self.ctx
        found = {}
        before_t = self.prefix(target)
        skip = (1 << T.enc(T.SKIP, 0)) | (1 << T.enc(T.SKIP, 1))
        for s in _bits(before_t & ~skip):
            for (nxt, unit), _a in T.explore(ctx, lambda: T.step_result(ctx, target, s, include=True)):
                found[T._key(unit)] = unit
        if before_t & skip:
            for s in _bits(self.prefix(target - 1)):
                for (nxt, unit), _a in T.explore(ctx, lambda: T.step_result(ctx, target - 1, s, include=True)):
                    if nxt >> 1 == T.SKIP and unit is not None:
                        found[T._key(unit)] = unit
        return found


def _bits(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask ^= low


@_budgeted
def seeded_exact(case, target, domain='ext', alpha=True, tree=None, *, bud, c):
    F = T.Facts(case, 'omega', domain, alpha) if tree is None else tree.F
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
        tree = None
    try:
        if tree is None:
            tree = LazyRel(F)
        us = tree.units(target)
        if len(us) == 1:
            c['route'] = 'tree'
            c['evaluations'] = bud.n
            return 'certified', next(iter(us.values()))
        ctx = tree.ctx
        k = 4
        while True:
            first = max(0, target - k)
            if first == 0:
                entry = {(T.S0, frozenset())}
            else:
                entry = {(s, frozenset()) for s in _bits(tree.prefix(first))}
            units = _dp(ctx, target, first, entry, bud)
            c['windows'] = c.get('windows', 0) + 1
            if len(units) == 1:
                c['route'] = 'seeded-exact'
                c['evaluations'] = bud.n
                return 'certified', next(iter(units.values()))
            if first == 0:
                c['evaluations'] = bud.n
                return ('ambiguous', units) if units else ('contradiction', None)
            k *= 2
    except Stop:
        c['evaluations'] = bud.n
        return 'unknown', None


@_budgeted
def goal_pruned(case, target, domain='ext', alpha=True, *, bud, c):
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    try:
        tree = LazyRel(F)
        us = tree.units(target)
        if len(us) == 1:
            c['evaluations'] = bud.n
            c['route'] = 'tree'
            return 'certified', next(iter(us.values()))
        u0 = sorted(us)[0]
        ctx = tree.ctx
        # G at boundary t-1 (or t when t == 0): states that can yield a unit != u0
        b0 = max(0, target - 1)

        def yields_other(s):
            found = set()
            for (ns, unit), _a in T.explore(ctx, lambda: T.step_result(ctx, b0, s, include=True)):
                if unit is not None and any(sl['item'] == target for sl in unit['slots']):
                    found.add(T._key(unit))
                elif b0 < target:
                    if ns >> 1 == T.SKIP:
                        continue
                    for (_n2, u2), _a2 in T.explore(ctx, lambda: T.step_result(ctx, target, ns, include=True)):
                        if u2 is not None:
                            found.add(T._key(u2))
            return bool(found - {u0})
        good = {b0: {s for s in range(T.NSTATE) if yields_other(s)}}
        for b in range(b0 - 1, -1, -1):
            leaf = tree[b]
            good[b] = {s for s in range(T.NSTATE) if any(x in good[b + 1] for x in _bits(leaf[s]))}
        pruned = [0]

        def keep(i, s):
            if i > b0:
                return True
            ok = s in good[i]
            if not ok:
                pruned[0] += 1
            return ok
        units = _dp(ctx, target, 0, {(T.S0, frozenset())}, bud, keep)
        c['pruned'] = pruned[0]
        c['evaluations'] = bud.n
        others = set(units) - {u0}
        u0_real = u0 in units or pruned[0] > 0   # a pruned element can only complete to u0
        if others and (u0_real or len(others) > 1):
            return 'ambiguous', units
        if others:
            c['route'] = 'goal-pruned'
            return 'certified', units[next(iter(others))]
        if u0_real:
            c['route'] = 'goal-pruned'
            return 'certified', us[u0]
        return 'contradiction', None
    except Stop:
        c['evaluations'] = bud.n
        return 'unknown', None


@_budgeted
def exact_from_zero(case, target, domain='ext', alpha=True, *, bud, c):
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    try:
        units = _dp(T.Ctx(F), target, 0, {(T.S0, frozenset())}, bud)
    except Stop:
        c['evaluations'] = bud.n
        return 'unknown', None
    c['evaluations'] = bud.n
    if len(units) == 1:
        return 'certified', next(iter(units.values()))
    return ('ambiguous', units) if units else ('contradiction', None)


@_budgeted
def tree_only(case, target, domain='ext', alpha=True, *, bud, c):
    F = T.Facts(case, 'omega', domain, alpha)
    if not F.domain_ok:
        F = T.Facts(case, 'omega', 'ext', alpha)
    try:
        tree = T.RelTree(F)
        us = tree.units(target)
    except Stop:
        c['evaluations'] = bud.n
        return 'unknown', None
    c['evaluations'] = bud.n
    return ('certified', next(iter(us.values()))) if len(us) == 1 else ('ambiguous', us)
