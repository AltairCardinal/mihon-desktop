"""WP-H discrete-event physical-task simulator (virtual units `u` only).

Models the coupled Session's physical contract: tasks keyed by full identity,
one in-flight task per identity (sharing / required promotion), capacity C,
NONPREEMPTIBLE execution (a cancelled running task holds its slot until its
true exit), completed-but-unconsumed results that keep a slot unless a separate
bounded result buffer exists, optional cooperative exit at declared phase
boundaries.  Service latents are fixed BEFORE any policy runs and keyed by
(identity, attempt) -- never by the order of random draws (M03 / N14).

Exogenous intents: dict(at, id, needs=[identity...], required=bool,
any_of=False).  An intent completes when every need (or one need if any_of)
has a consumed result.  Policies only see the queue, their own tasks and past
events; they never read latents of unstarted tasks unless the policy is
declared 'bound-aware' and only through a declared upper bound B.
"""
import hashlib
import heapq
from itertools import count


def latent(seed, identity, attempt, lo=1, hi=10):
    """Deterministic service time keyed by full identity and attempt."""
    h = hashlib.sha256(repr((seed, identity, attempt)).encode()).digest()
    return lo + int.from_bytes(h[:4], 'big') % (hi - lo + 1)


class Task:
    __slots__ = ('ident', 'required', 'state', 'start', 'end', 'consumers', 'cancelled', 'phases',
                 'attempt', 'optional_since', 'enq', 'batch', 'exiting')

    def __init__(self, ident, required, enq):
        self.ident, self.required, self.state = ident, required, 'queued'
        self.start = self.end = None
        self.consumers = set()
        self.cancelled = False
        self.phases = None
        self.attempt = 0
        self.enq = enq
        self.batch = None
        self.exiting = False


class Sim:
    """policy keys:
       order:      'fifo' | 'required_first' | 'critical' | 'aging'
       aging_bound: max wait (u) after which an optional task is treated as required
       reserve:    slots usable only by required tasks (fixed reservation)
       dyn_reserve_bound: optional may borrow a reserved slot iff its DECLARED service
                   upper bound <= this value (bound-aware dynamic reservation)
       result_buffer: None -> completed results occupy their slot until consumed (Session);
                   int R -> completion moves the result to a buffer of size R (slot freed);
                   full buffer -> the task stays 'completed' in its slot (backpressure)
       consume_delay: virtual delay between completion and consumption (slow consumer)
       batch:      None or dict(size, max_wait, setup, per_item, barrier)
       coop_exit:  cancelled running tasks may exit at the next phase boundary
    """

    def __init__(self, capacity, latents, policy=None, bounds=None):
        self.C = capacity
        self.lat = latents                # ident -> service time (fixed in advance)
        self.bounds = bounds or {}        # ident -> declared upper bound (bound-aware policies)
        self.p = dict(order='fifo', aging_bound=None, reserve=0, dyn_reserve_bound=None,
                      result_buffer=None, consume_delay=0, batch=None, coop_exit=False,
                      phase_len=None, revive=False, mutant_cancel_releases=False, serial_consumer=False,
                      retain=None)
        self.p.update(policy or {})
        self.now = 0
        self.ev = []
        self.seq = count()
        self.tasks = {}                   # ident -> live Task
        self.queue = []                   # queued Tasks
        self.running = set()              # Tasks holding a slot (running, cancelling, completed-unconsumed)
        self.buffer = []
        self.intents = {}
        self.done_results = set()         # identities with consumed results (current)
        self.log = dict(starts=0, completions=0, wasted_u=0, busy_u=0, cancels=0, coop_exits=0,
                        max_slots=0, max_buffer=0, max_queue=0, batches=0, setups=0)
        self.batch_open = None
        self.cfree = 0
        self.phys = set()                  # mutant only: tasks physically running without a slot
        self.log['max_physical'] = 0

    # ------------------------------------------------------------- api
    def push(self, t, kind, payload):
        heapq.heappush(self.ev, (t, next(self.seq), kind, payload))

    def slots_used(self):
        return len(self.running)

    def request(self, ident, required, consumer):
        if ident in self.done_results:
            return
        t = self.tasks.get(ident)
        if t is not None and not (t.cancelled and t.state == 'running'):
            if required and not t.required:
                t.required = True          # promotion, same physical task
            t.consumers.add(consumer)
            if t.cancelled and t.state == 'queued':
                t.cancelled = False
            return
        if t is not None and t.cancelled and t.state == 'running':
            if self.p['revive'] and not t.exiting:
                # same incarnation still physically running: re-attach the consumer (D5 revive)
                t.cancelled = False
                t.consumers.add(consumer)
                if required:
                    t.required = True
                self.log['revives'] = self.log.get('revives', 0) + 1
                return
        nt = Task(ident, required, self.now)
        nt.consumers.add(consumer)
        if t is not None:
            nt.attempt = t.attempt + 1
        self.tasks[ident] = nt
        self.queue.append(nt)
        self.log['max_queue'] = max(self.log['max_queue'], len(self.queue))

    def cancel(self, ident, consumer):
        t = self.tasks.get(ident)
        if t is None:
            return
        t.consumers.discard(consumer)
        if t.consumers:
            return                         # other consumers keep it alive (D5)
        self.log['cancels'] += 1
        if t.state == 'queued':
            self.queue.remove(t)
            del self.tasks[ident]
        elif t.state == 'running':
            t.cancelled = True
            if self.p['mutant_cancel_releases']:
                self.running.discard(t)          # MUTANT: logical cancel frees the slot early
                self.phys.add(t)
            if self.p['coop_exit'] and self.p['phase_len']:
                pl = self.p['phase_len']
                k = -(-(self.now - t.start) // pl)
                exit_at = min(t.end, t.start + k * pl)
                if exit_at < t.end:
                    t.end = exit_at
                    t.exiting = True
                    self.push(exit_at, 'finish', t)
                    self.log['coop_exits'] += 1

    # ------------------------------------------------------------- policy
    def _eligible(self, t, free_unreserved, free_reserved):
        if t.required:
            return free_unreserved + free_reserved > 0
        if free_unreserved > 0:
            return True
        b = self.p['dyn_reserve_bound']
        if b is not None and free_reserved > 0:
            return self.bounds.get(t.ident, float('inf')) <= b
        return False

    def _priority(self, t):
        o = self.p['order']
        if o == 'fifo':
            return (t.enq,)
        if o == 'required_first':
            return (0 if t.required else 1, t.enq)
        if o == 'aging':
            ab = self.p['aging_bound']
            aged = (not t.required) and ab is not None and self.now - t.enq >= ab
            return (0 if (t.required or aged) else 1, t.enq)
        if o == 'smith':              # weighted shortest declared bound first (Smith's rule), required first
            req = 0 if t.required else 1
            return (req, self.bounds.get(t.ident, 10 ** 9) / max(1, len(t.consumers)), t.enq)
        if o == 'critical':           # most blocked consumers first, then declared shorter bound
            req = 0 if t.required else 1
            return (req, -len(t.consumers), self.bounds.get(t.ident, 10 ** 9), t.enq)
        raise ValueError(o)

    def _dispatch(self):
        while self.queue:
            used = self.slots_used()
            res = self.p['reserve']
            used_opt = sum(1 for t in self.running if not t.required)
            free = self.C - used
            if free <= 0:
                return
            # reserved slots: optional tasks may hold at most C-res slots
            free_unreserved = max(0, min(free, (self.C - res) - used_opt))
            free_reserved = free - free_unreserved
            cands = sorted(self.queue, key=self._priority)
            pick = next((t for t in cands if self._eligible(t, free_unreserved, free_reserved)), None)
            if pick is None:
                return
            if self.p['batch']:
                b = self.p['batch']
                oldest = min(t.enq for t in self.queue)
                mw = b.get('max_wait')
                if mw is not None and len(self.queue) < b['size'] and self.now - oldest < mw:
                    self.push(oldest + mw, 'call', lambda sim: None)    # re-dispatch when the wait bound expires
                    return
                self.queue.remove(pick)
                self._start_batch(pick)
            else:
                self.queue.remove(pick)
                self._start(pick, self.lat[pick.ident])

    def _start(self, t, dur):
        t.state = 'running'
        t.start = self.now
        t.end = self.now + dur
        self.running.add(t)
        self.log['starts'] += 1
        self.log['max_slots'] = max(self.log['max_slots'], len(self.running))
        self.log['max_physical'] = max(self.log['max_physical'],
                                       sum(1 for x in self.running if x.state == 'running') + len(self.phys))
        self.push(t.end, 'finish', t)

    def _start_batch(self, first):
        """Micro-batch: one slot runs setup + items sequentially; items complete
        individually unless barrier=True (then all complete at batch end)."""
        b = self.p['batch']
        members = [first]
        for t in sorted(self.queue, key=self._priority):
            if len(members) >= b['size']:
                break
            members.append(t)
        for t in members[1:]:
            self.queue.remove(t)
        self.log['batches'] += 1
        self.log['setups'] += 1
        tcur = self.now + b['setup']
        ends = []
        for t in members:
            tcur += self.lat[t.ident] if b.get('per_item') is None else b['per_item']
            ends.append(tcur)
        holder = members[0]
        for t, e in zip(members, ends):
            t.state = 'running'
            t.start = self.now
            t.end = ends[-1] if b.get('barrier') else e
            t.batch = holder
        holder_end = ends[-1]
        self.running.add(holder)
        holder.end = holder_end if b.get('barrier') else holder.end
        self.log['starts'] += len(members)
        self.log['max_slots'] = max(self.log['max_slots'], len(self.running))
        for t in members:
            self.push(t.end, 'finish', t)
        self.push(holder_end, 'batch_end', holder)

    # ------------------------------------------------------------- events
    def _finish(self, t):
        if t.state != 'running':
            return
        dur = t.end - t.start
        self.log['busy_u'] += dur if t.batch is None else 0
        if t.cancelled or t.exiting:
            self.log['wasted_u'] += dur
            t.state = 'gone'
            self.running.discard(t)
            self.phys.discard(t)
            if self.tasks.get(t.ident) is t:
                del self.tasks[t.ident]
            return
        self.log['completions'] += 1
        t.state = 'completed'
        rb = self.p['result_buffer']
        if t.batch is not None and t.batch is not t:
            # non-holder members of a batch never held a slot themselves
            self.push(self._consume_time(), 'consume', t)
            return
        if rb is None:
            self.push(self._consume_time(), 'consume', t)   # slot held until consumed
        else:
            self._try_buffer(t)

    def _try_buffer(self, t):
        rb = self.p['result_buffer']
        if len(self.buffer) < rb:
            self.buffer.append(t)
            self.log['max_buffer'] = max(self.log['max_buffer'], len(self.buffer))
            if t.batch is None or t.batch is t:
                if t.batch is None:
                    self.running.discard(t)
            self.push(self._consume_time(), 'consume', t)
        else:
            t.state = 'blocked'          # stays in its slot: backpressure

    def _consume_time(self):
        if not self.p['serial_consumer']:
            return self.now + self.p['consume_delay']
        self.cfree = max(self.now, self.cfree) + self.p['consume_delay']
        return self.cfree

    def _consume(self, t):
        if t in self.buffer:
            self.buffer.remove(t)
        if t.batch is None:
            self.running.discard(t)
        t.state = 'consumed'
        if self.tasks.get(t.ident) is t:
            del self.tasks[t.ident]
        self.done_results.add(t.ident)
        if self.p['retain'] is not None:
            self._lru = getattr(self, '_lru', [])
            if t.ident in self._lru:
                self._lru.remove(t.ident)
            self._lru.append(t.ident)
            while len(self._lru) > self.p['retain']:
                self.done_results.discard(self._lru.pop(0))
        for it in list(self.intents.values()):
            if it['done'] is None:
                have = [n in self.done_results for n in it['needs']]
                if (any(have) if it.get('any_of') else all(have)):
                    it['done'] = self.now
        # admit blocked completions now that buffer space exists
        if self.p['result_buffer'] is not None:
            for b in [x for x in self.running if x.state == 'blocked']:
                if len(self.buffer) < self.p['result_buffer']:
                    b.state = 'completed'
                    self._try_buffer(b)

    def run(self, intents, horizon=10 ** 7, hooks=None):
        for it in intents:
            self.push(it['at'], 'intent', it)
        while self.ev:
            t, _s, kind, payload = heapq.heappop(self.ev)
            if t > horizon:
                break
            self.now = t
            if kind == 'intent':
                it = dict(payload, done=None)
                self.intents[it['id']] = it
                for n in it['needs']:
                    self.request(n, it['required'], it['id'])
                have = [n in self.done_results for n in it['needs']]
                if it['needs'] and (any(have) if it.get('any_of') else all(have)):
                    it['done'] = self.now          # already satisfied by a consumed result
                if hooks and 'on_intent' in hooks:
                    hooks['on_intent'](self, it)
            elif kind == 'finish':
                self._finish(payload)
            elif kind == 'consume':
                self._consume(payload)
            elif kind == 'batch_end':
                self.running.discard(payload)
            elif kind == 'call':
                payload(self)
            # linearization: all events of one timestamp are applied before dispatch
            if not self.ev or self.ev[0][0] != self.now:
                self._dispatch()
        return self.summary()

    def summary(self):
        req = sorted(it['done'] - it['at'] for it in self.intents.values() if it['required'] and it['done'] is not None)
        opt = sorted(it['done'] - it['at'] for it in self.intents.values() if not it['required'] and it['done'] is not None)
        unserved = [k for k, it in self.intents.items() if it['done'] is None]

        def q(xs, f):
            return xs[min(len(xs) - 1, int(f * (len(xs) - 1)))] if xs else None
        return dict(required_n=len(req), required_total=sum(req), required_p50=q(req, .5), required_p95=q(req, .95),
                    required_max=max(req) if req else None, optional_n=len(opt), optional_max=max(opt) if opt else None,
                    optional_total=sum(opt), unserved=len(unserved), end_u=self.now, **self.log)
