"""WP-H bench registration (D3).  Formal timing ONLY via the main session:
    python3 research_out/bench/drive_formal.py bench_wpH --out results/raw/formal/wpH.jsonl

Families (FAMILY_CANDIDATES(sc)[0] = incumbent = Session/Runner default):
  revoke       : full publication revalidation (StrongSession)  vs  inc_revoke (IncSession, reverse support index)
  value_reuse  : identity-only reuse (StrongSession)           vs  value_cache (ValueCacheSession) under fresh rebinds
  confirm      : package confirm(target)                        vs  bound_confirm (handle-bound callback)
  reserve      : coupled no reservation                          vs  reserve1 (ReservingSession) with prefetch events
  sched_reserve: simulator I02 none / fixed1 / dyn_b10 (declared-bound borrowing)
  microbatch   : simulator I05 immediate / batch_peritem / batch_barrier
  spec_credit  : simulator J06 none / global / isolated / refund_isolated
wall_ns = compute wall time of the candidate run (local_measured); `work` holds virtual metrics (u never added to ns).
Bench seeds (200..) are disjoint from tuning (0..30) and D4 held-out (100..107) seeds.
"""
import hashlib
import json
import sys
import time
from copy import deepcopy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: F401,E402
import workloads as W  # noqa: E402
import wpH_runner as R  # noqa: E402
import wpH_commit as H  # noqa: E402
import wpH_d4 as D4  # noqa: E402
import wpH_exp_sched as ES  # noqa: E402
import wpH_extra as EX  # noqa: E402
from wpH_sched import Sim, latent  # noqa: E402

FAMILIES = {
    'revoke': ['full_revalidate', 'inc_revoke'],
    'value_reuse': ['identity_only', 'value_cache'],
    'confirm': ['package_confirm', 'bound_confirm'],
    'reserve': ['no_reserve', 'reserve1'],
    'sched_reserve': ['none', 'fixed1', 'dyn_b10'],
    'microbatch': ['immediate', 'batch_peritem', 'batch_barrier'],
    'spec_credit': ['none', 'global', 'isolated', 'refund_isolated'],
}
SCENARIOS = []
for fam_w, seed in (('RP', 200), ('W02', 200), ('W06', 200)):
    for fam in ('revoke', 'value_reuse', 'confirm', 'reserve'):
        SCENARIOS.append(dict(name=f'{fam}/{fam_w}/{seed}', family=fam, workload=fam_w, seed=seed))
for seed in (200, 201):
    for fam in ('sched_reserve', 'microbatch', 'spec_credit'):
        SCENARIOS.append(dict(name=f'{fam}/sim/{seed}', family=fam, seed=seed))
CANDIDATES = sorted({c for v in FAMILIES.values() for c in v}, key=lambda c: (c not in [v[0] for v in FAMILIES.values()], c))


def FAMILY_CANDIDATES(sc):
    return FAMILIES[sc['family']]


def _sha(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()


def _coupled(sc, cand):
    fam, wl, seed = sc['family'], sc['workload'], sc['seed']
    if fam == 'revoke':
        cls = R.StrongSession if cand == 'full_revalidate' else H.IncSession
        r, rr = D4.run(wl, seed, cls)
        view = dict(pub=sorted(rr.session.published.items()), conf=sorted(map(str, rr.session.confirmed)))
        ok = r['wrong'] + r['wrong_current'] == 0 and r['confirmed_subset'] and r['occupied_end'] == 0
        work = dict(publication_read_checks=r['publication_read_checks'], total_latency_u=r['total_latency_u'],
                    physical_admissions=r['physical_admissions'])
        return view, ok, work
    if fam == 'value_reuse':
        cls = R.StrongSession if cand == 'identity_only' else H.ValueCacheSession
        tr = W.FAMILIES[wl](seed)
        tr2 = D4.with_events(tr, seed, churn=False, rebind=False, confirms=True)
        end = max(e['at'] for e in tr2['events'])
        tr2['events'] = sorted(tr2['events'] + [dict(at=end // 3, op='rebind'), dict(at=2 * end // 3, op='rebind')],
                               key=lambda e: e['at'])
        rr = R.RunnerH(tr2, session_cls=cls, policy='incumbent', service_u=3)
        init, orig = deepcopy(tr['initial']), rr._custom

        def custom(ev, rr=rr, init=init, orig=orig):
            if ev['op'] == 'rebind':
                rr.session.rebind(deepcopy(init)); rr.audit['rebinds'] += 1
                for kk in list(rr.first_pub):
                    rr.first_pub.pop(kk); rr.intent[kk] = rr.now
                return
            orig(ev)
        rr._custom = custom
        r = rr.run()
        old = [h for h, c in rr.session._certs.items() if c['epoch'] != rr.session.epoch]
        ok = r['wrong'] + r['wrong_current'] == 0 and not old and not r['unserved']
        view = dict(pub=sorted(rr.session.published.items()))
        work = dict(physical_admissions=r['physical_admissions'], total_latency_u=r['total_latency_u'],
                    value_cache_hits=r['value_cache_hits'])
        return view, ok, work
    if fam == 'confirm':
        bound = cand == 'bound_confirm'
        cls = H.BoundConfirmSession if bound else R.StrongSession
        r, rr = D4.run(wl, seed, cls, churn=True, rebind=False, confirms=False, late=True, bound_confirm=bound)
        lc = r.get('late_callbacks', [])
        expired_conf = sum(1 for x in lc if x['refers_to_expired'] and x['result'] == 'confirmed')
        ok = r['wrong'] + r['wrong_current'] == 0 and expired_conf == 0
        view = dict(pub=sorted(rr.session.published.items()))
        return view, ok, dict(late_callbacks=len(lc), confirmed_via_expired_callback=expired_conf)
    if fam == 'reserve':
        cls = R.StrongSession if cand == 'no_reserve' else R.ReservingSession
        r, rr = D4.run(wl, seed, cls, churn=False, rebind=False, confirms=False, prefetch=True)
        ok = r['wrong'] + r['wrong_current'] == 0 and not r['unserved']
        view = dict(pub=sorted(rr.session.published.items()))
        lat = [rr.first_pub[k] - rr.intent[k] for k in rr.first_pub]
        return view, ok, dict(total_latency_u=r['total_latency_u'], max_latency_u=max(lat) if lat else None,
                              physical_admissions=r['physical_admissions'], refusals=r['reservation_refusals'])
    raise ValueError(fam)


def _sim(sc, cand):
    fam, seed = sc['family'], sc['seed']
    if fam == 'sched_reserve':
        ints, lat, bounds = ES.burst_workload(seed, cap=1)
        pol = dict(order='required_first')
        if cand == 'fixed1':
            pol.update(reserve=1)
        elif cand == 'dyn_b10':
            pol.update(reserve=1, dyn_reserve_bound=10)
        r = Sim(1, lat, pol, bounds).run(ints)
        return dict(required_max=r['required_max'], optional_n=r['optional_n']), r['max_physical'] <= 1, r
    if fam == 'microbatch':
        import random
        rng = random.Random(seed)
        lat, ints, t = {}, [], 0
        for k in range(40):
            t += rng.choice((1, 2, 3))
            lat[f'b{k}'] = latent(seed, f'b{k}', 0, 1, 3) if k % 9 else 25
            ints.append(dict(at=t, id=k, needs=[f'b{k}'], required=True))
        if cand == 'immediate':
            r = Sim(2, {x: v + 4 for x, v in lat.items()}, dict(order='fifo')).run(ints)
        else:
            r = Sim(2, lat, dict(order='fifo', batch=dict(size=4, setup=4, per_item=None,
                                                         barrier=cand == 'batch_barrier', max_wait=None))).run(ints)
        return dict(required_total=r['required_total'], unserved=r['unserved']), r['unserved'] == 0, r
    if fam == 'spec_credit':
        rows = [x for x in EX.j06_sim(seeds=[seed])['rows'] if x['organisation'] == cand]
        x = rows[0]
        return dict(G_total=x['G_total'], H_total=x['H_total']), x['unserved'] == 0, x
    raise ValueError(fam)


def run_one(sc, cand, rep):
    t0 = time.perf_counter_ns()
    if sc['family'] in ('revoke', 'value_reuse', 'confirm', 'reserve'):
        view, ok, work = _coupled(sc, cand)
        verdict = view
    else:
        verdict, ok, raw = _sim(sc, cand)
        work = {k: v for k, v in raw.items() if isinstance(v, (int, float)) and not isinstance(v, bool)}
    wall = time.perf_counter_ns() - t0
    return dict(wall_ns=wall, verdict_sha256=_sha(verdict), ok=bool(ok), work=work, evidence_layer='local_measured+virtual_u')


if __name__ == '__main__':      # smoke only (one rep, no timing claims)
    for sc in SCENARIOS:
        for c in FAMILY_CANDIDATES(sc):
            row = run_one(sc, c, 0)
            print(sc['name'], c, row['ok'], json.dumps(row['work'])[:160])
