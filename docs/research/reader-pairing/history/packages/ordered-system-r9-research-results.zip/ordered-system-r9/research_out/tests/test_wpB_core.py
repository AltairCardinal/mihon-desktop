"""WP-B tests: exact block summaries, layered search, domains, signature memo,
witness sufficiency, oracle independence, coupled lifecycle."""
import copy
import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa: E402,F401
from common import ref, random_case, roundtrip, base_case, fact, SIDES  # noqa: E402
import transducer as T  # noqa: E402
import omega as O  # noqa: E402
import wpB_blocks as WB  # noqa: E402
import wpB_layered as L  # noqa: E402
import wpB_domains as D  # noqa: E402
import wpB_sigmemo as SG  # noqa: E402
import wpB_witness as Wt  # noqa: E402
import wpB_bounds as Bd  # noqa: E402


def _same(a, b):
    return (a[0] == 'certified') == (b[0] == 'certified') and (a[0] != 'certified' or a[1] == b[1])


class Blocks(unittest.TestCase):
    def test_equals_exact_dp_with_updates(self):
        rng = random.Random(11)
        for _ in range(60):
            n = rng.randrange(1, 16)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.3, p_fail=0.03))
            alpha = rng.random() < .5
            bs = WB.BlockSummary(copy.deepcopy(c), 'ext', alpha, block=rng.choice((1, 3, 4)))
            for t in range(n):
                self.assertTrue(_same(O.certify_exact(c, t, 'ext', alpha), bs.certify(t)))
            for u in range(3):
                p = rng.randrange(n)
                it = copy.deepcopy(c['items'][p])
                it['analysis'] = rng.choice([{'status': 'unknown'},
                                             dict(status='computed', fact=fact('NARROW', rng.choice(SIDES)), version=u + 5)])
                c['items'][p] = it
                bs.update(items={p: copy.deepcopy(it)})
                for t in range(n):
                    self.assertTrue(_same(O.certify_exact(c, t, 'ext', alpha), bs.certify(t)))

    def test_sound_against_world_oracle(self):
        rng = random.Random(12)
        checked = 0
        for _ in range(80):
            n = rng.randrange(2, 6)
            c = roundtrip(random_case(rng, n, p_unknown=0.35, p_edge_unknown=0.35))
            t = rng.randrange(n)
            try:
                U = O.oracle_units(c, t, 'ext', True, cap=15000)
            except OverflowError:
                continue
            checked += 1
            r = WB.BlockSummary(copy.deepcopy(c), 'ext', True, block=2).certify(t)
            self.assertEqual(r[0] == 'certified', len(U) == 1)
            if r[0] == 'certified':
                self.assertEqual(set(U), {T._key(r[1])})
        self.assertGreater(checked, 40)

    def test_stale_frontier_mutant_killed(self):
        rng = random.Random(13)
        caught = False
        for _ in range(200):
            n = rng.randrange(6, 16)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.3))
            m = WB.StaleFrontierMutant(copy.deepcopy(c), 'ext', False, block=2)
            for t in range(n):
                m.certify(t)
            p = rng.randrange(n - 3)
            it = copy.deepcopy(c['items'][p])
            it['analysis'] = dict(status='computed', fact=fact('WIDE'), version=9)
            it['header'] = fact('WIDE')
            c['items'][p] = it
            m.update(items={p: copy.deepcopy(it)})
            if any(not _same(O.certify_exact(c, t, 'ext', False), m.certify(t)) for t in range(n)):
                caught = True
                break
        self.assertTrue(caught)

    def test_empty_completion_is_contradiction_not_certificate(self):
        c = base_case(4, automatic=True)
        c['items'][1]['analysis'] = {'status': 'unknown'}
        c['items'][1].pop('header')
        orig = T.Ctx.choose

        def empty(self, key, options):           # a free state with NO admissible value => empty world set
            return orig(self, key, () if key[0] == 'st' else options)
        T.Ctx.choose = empty
        try:
            r = WB.BlockSummary(copy.deepcopy(c), 'ext', False, block=2).certify(3)
        finally:
            T.Ctx.choose = orig
        self.assertEqual(r[0], 'contradiction')


class Layered(unittest.TestCase):
    def test_seeded_and_goal_agree_with_exact(self):
        rng = random.Random(14)
        for _ in range(80):
            n = rng.randrange(2, 24)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.4))
            t = rng.randrange(n)
            e = L.exact_from_zero(c, t, 'ext', False)
            for fn in (L.seeded_exact, L.goal_pruned):
                self.assertTrue(_same(e, fn(c, t, 'ext', False)))

    def test_budget_returns_unknown(self):
        rng = random.Random(15)
        c = roundtrip(random_case(rng, 40, p_unknown=0.6, p_edge_unknown=0.6, settings_mix=False))
        self.assertEqual(L.exact_from_zero(c, 39, 'ext', False, budget=10)[0], 'unknown')


class Domains(unittest.TestCase):
    def test_bitset_matches_symbolic_on_G0(self):
        rng = random.Random(16)
        for _ in range(150):
            nv = rng.randrange(1, 3)
            ks = [rng.randrange(0, 1500) / 50 for _ in range(rng.randrange(0, 3))]
            terms = [('e', v) for v in range(nv)] + [('k', k) for k in ks]
            cons = set()
            for _ in range(rng.randrange(1, 4)):
                x, y = rng.sample(terms, 2) if len(terms) > 1 else (terms[0], ('k', 1.0))
                if x[0] == 'k' and y[0] == 'k':
                    continue
                cons.add(((x, y), rng.random() < .5))
            if cons:
                self.assertEqual(D.feasible_bits(frozenset(cons)), T.feasible(frozenset(cons), 'G0'))

    def test_realizability_mask_is_stricter(self):
        cons = frozenset({((('e', 0), ('k', 0.5)), True), ((('k', 0.1), ('e', 0)), True)})
        self.assertTrue(D.feasible_bits(cons))
        self.assertFalse(D.feasible_bits(cons, D.INT_MASK))

    def test_shape_guess_is_unsafe_tag_selection_is_safe(self):
        c = base_case(5, automatic=True)
        c['edges'][1]['score'] = 0
        c['edges'] = [e for e in c['edges'] if e['first'] != 2]
        for e in c['edges']:
            e['source'] = 'external'
        self.assertEqual(T.certify_tree(c, 4, D.shape_domain(c))[0], 'certified')
        self.assertGreater(len(O.oracle_units(c, 4, 'ext')), 1)
        self.assertNotEqual(T.certify_tree(c, 4, D.select_domain(c)[0])[0], 'certified')

    def test_decimal_text_changes_plan(self):
        text, fl, dec = D.decimal_vs_binary64_case()
        self.assertEqual(fl['edges'][0]['score'], fl['edges'][1]['score'])
        self.assertNotEqual(dec['edges'][0]['score'], dec['edges'][1]['score'])


class SignatureMemo(unittest.TestCase):
    def test_l0_equal_and_mutant_killed(self):
        rng = random.Random(17)
        wrong_sig = wrong_mut = 0
        for _ in range(120):
            n = rng.randrange(3, 14)
            c = roundtrip(random_case(rng, n, p_unknown=.15, p_edge_unknown=.2, domain='G0'))
            ow = [SG.SigOwner(c), SG.SigMutantNoOrder(c)]
            cur = copy.deepcopy(c)
            for step in range(6):
                for t in [rng.randrange(n) for _ in range(3)]:
                    want = {k: v for k, v in ref.certify_strategy(cur, t)['selected'].items() if k != 'reads'}
                    wrong_sig += ow[0].request(t) != want
                    wrong_mut += ow[1].request(t) != want
                upd = {}
                for e in cur['edges']:
                    if e.get('status') == 'computed' and e.get('score') is not None:
                        e['score'] = rng.randrange(0, 1500) / 50
                        upd[(e['first'], e['second'])] = copy.deepcopy(e)
                for o in ow:
                    o.apply(edge_updates=upd)
        self.assertEqual(wrong_sig, 0)
        self.assertGreater(wrong_mut, 0)


class Witness(unittest.TestCase):
    def test_statistics_not_sufficient_and_rows(self):
        import OPTIMIZED_OPERATOR as OP
        a, b, probe = Wt.permuted_pair(random.Random(1))
        self.assertEqual(Wt.stats(a), Wt.stats(b))
        self.assertNotEqual(OP.score(a, probe), OP.score(b, probe))
        reach, _ = Wt.realizable_q(1, 1)
        self.assertEqual([q for q in range(1500) if reach >> q & 1], list(range(0, 1500, 50)))
        self.assertTrue(Wt.raw_many_to_one()[2])

    def test_mask_premise_check(self):
        c = base_case(5, automatic=True)
        for it in c['items']:
            it['analysis']['fact'].update(width=1, height=2)
        c['edges'][1]['score'] = 0.3
        m = Wt.edge_masks_from_geometry(c)
        self.assertFalse(Wt.masks_consistent(c, m))


class OracleIndependence(unittest.TestCase):
    def test_shared_mutant_invisible_to_differential(self):
        r = Bd.oracle_independence(25)
        self.assertGreater(r['mutant_active_cases'], 0)
        self.assertEqual(r['caught_by_independent_world_oracle'], r['mutant_active_cases'])
        self.assertEqual(r['caught_by_shared_code_differential'], 0)


class Coupled(unittest.TestCase):
    def test_block_session_lifecycle(self):
        import workloads as W
        import wpB_coupled as BC
        for fam in ('W01', 'W05', 'W06'):
            r = BC.BlockRunner(W.FAMILIES[fam](300), policy='gated', service_u=3, q_u=1,
                               strong=dict(kind='blocks', domain='nonneg', alpha=False, gate='raw')).run()
            self.assertEqual(r['wrong'], 0)
        tr = W.w01_phase_chain(101)
        s = BC.BlockSession(tr['initial'], strong=dict(kind='blocks', domain='nonneg', alpha=False, gate='raw'))
        for t in range(len(tr['initial']['items'])):
            v = s.certify(t, mode='S')
            if v.get('route') == 'strong-blocks':
                self.assertEqual(s.publish(t, v['certificate']), 'published')
                e = next(x for x in s.owner._case['edges'] if x['first'] <= t)
                s.owner.apply(edge_updates={(e['first'], e['second']): dict(status='computed', score=999, version=7)})
                self.assertEqual(s.confirm(t), 'stale')
                s.rebind(tr['initial'])
                self.assertEqual(s.publish(t, v['certificate']), 'unsigned')
                return
        self.fail('no strong certificate found')

    def test_out_of_domain_delta_forces_ext_rebuild(self):
        import workloads as W
        import wpB_coupled as BC
        tr = W.w01_phase_chain(102)
        s = BC.BlockSession(tr['initial'], strong=dict(kind='blocks', domain='nonneg', alpha=False, gate='raw'))
        first = s._summary()
        self.assertEqual(first.F.domain, 'nonneg')
        e = s.owner._case['edges'][0]
        s.owner.apply(edge_updates={(e['first'], e['second']): dict(status='computed', score=-1.0, version=11)})
        bs = s._summary()
        self.assertEqual(bs.F.domain, 'ext')
        self.assertEqual(s.metrics['block_rebuilds'], 2)
        for t in range(len(s.owner._case['items'])):
            self.assertTrue(_same(O.certify_exact(s.owner._case, t, 'ext', False), bs.certify(t)))


if __name__ == '__main__':
    unittest.main()
