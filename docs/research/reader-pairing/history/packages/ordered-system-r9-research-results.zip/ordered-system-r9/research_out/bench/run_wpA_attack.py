"""Adversarial search: does race_keep / gated_keep ever lose to the incumbent (latency or physical work)?"""
import json, random, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import wpA_lib as A

rng = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
budget_s = float(sys.argv[2]) if len(sys.argv) > 2 else 120
found, runs, t0 = [], 0, time.time()
while time.time() - t0 < budget_s:
    n = rng.randrange(6, 16)
    kind = rng.choice(('chain', 'rand'))
    if kind == 'chain':
        world = A._chain_world(n, side_mix=rng.random() < .5, rng=rng, step_noise=True)
    else:
        world = A._rand_world(rng, n, p_wide=rng.choice((0, .1, .3)), raw_max=rng.choice((4, 12)))
    known = {i for i in range(n) if rng.random() < rng.choice((.5, .8, 1.0))}
    edges = [a for a in range(n - 1) if rng.random() < rng.choice((.4, .7, .9))]
    init = A.initial_from(world, known, edges)
    k = rng.randrange(2, 8)
    ev = [dict(at=rng.randrange(0, 20), op='target', target=rng.randrange(n)) for _ in range(k)]
    ev.sort(key=lambda e: e['at'])
    tr = dict(name='attack', initial=init, world=world, events=ev)
    su, q = rng.choice((1, 2, 3, 5, 8)), rng.choice((0, 1, 2, 3, 6))
    cap, rawc = rng.choice((1, 2, 3)), rng.choice((2, 3))
    order = rng.choice(('fifo', 'lifo'))
    res = {}
    for pol in ('incumbent', 'race_keep', 'gated_keep'):
        r = A.ARunner(tr, policy=pol, service_u=su, q_u=q, capacity=cap, raw_capacity=rawc, order=order).run(max_steps=4000)
        res[pol] = r
    runs += 1
    inc = res['incumbent']
    shared_livelock = inc['livelock'] or inc['published'] < inc['intents']
    livelocks = locals().get('livelocks', 0) + int(shared_livelock)
    for pol in ('race_keep', 'gated_keep'):
        r = res[pol]
        inc_ok = not inc['livelock'] and inc['published'] == inc['intents']
        pol_ok = not r['livelock'] and r['published'] == r['intents']
        if r['wrong'] or (inc_ok and not pol_ok):
            found.append(dict(kind='correctness', policy=pol, trace=tr, su=su, q=q, cap=cap, raw=rawc, order=order,
                              r={x: r[x] for x in ('wrong', 'livelock', 'published', 'intents')}))
        if inc_ok and pol_ok and (r['total_latency_u'] > inc['total_latency_u'] or r['physical_admissions'] > inc['physical_admissions']):
            found.append(dict(kind='perf', policy=pol, su=su, q=q, cap=cap, raw=rawc, order=order, trace=tr,
                              lat=(r['total_latency_u'], inc['total_latency_u']),
                              work=(r['physical_admissions'], inc['physical_admissions'])))
out = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpA' / f'attack_{sys.argv[1] if len(sys.argv) > 1 else 0}.json'
out.write_text(json.dumps(dict(runs=runs, findings=len(found), incumbent_livelocks=livelocks, examples=found[:5]), indent=1))
print('runs', runs, 'incumbent livelock/unfinished', livelocks, 'findings', len(found), [ (f['kind'], f['policy'], f.get('lat'), f.get('work')) for f in found[:8]])
