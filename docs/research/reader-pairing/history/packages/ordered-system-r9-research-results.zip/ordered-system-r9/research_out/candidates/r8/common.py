"""Shared helpers for research_out candidates (standard library only).

Nothing here replaces the frozen oracle: reference.py / compact_core.py stay the
behaviour definition.  This module only builds inputs, projects results and
times things.
"""
import copy
import hashlib
import json
import math
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parents[1]

import reference as ref  # noqa: E402

STATES = ('NARROW', 'WIDE')
SIDES = ('A', 'B', 'UNKNOWN')
G0_MAX_M = 1499          # G0 numeric ranks are m/50, 0 <= m <= 1499 (GENERATIVE_DOMAIN.md)


def fact(state='NARROW', side='UNKNOWN', rotation=0, orientation=1):
    w, h = (200, 200) if state == 'WIDE' else (100, 200)
    return dict(state=state, width=w, height=h, rotation=rotation, orientation=orientation, side=side)


def base_case(n, automatic=True, direction='AB', opening='AUTO', isolates=(), pins=()):
    return dict(generation=0, order_revision=0,
                items=[dict(id=f'i{i}', header=fact(), analysis=dict(status='computed', fact=fact(), version=1))
                       for i in range(n)],
                settings=dict(automatic=automatic, direction=direction, opening=opening,
                              hard_isolates=list(isolates), pinned_links=list(pins)),
                edges=[dict(first=i, second=i + 1, status='computed', score=None, version=1) for i in range(n - 1)])


def rank_value(rng, domain):
    """One computed rank (None = computed null) from an abstract domain."""
    if rng.random() < 0.15:
        return None
    if domain == 'G0':
        return rng.randrange(0, G0_MAX_M + 1) / 50
    if domain == 'nonneg':
        return rng.choice((0, 0.0, 1, 2, 3, 5, 7.5, 29.98, 1e17))
    # extension domain: finite JSON numbers incl. negative, huge and tiny values
    return rng.choice((-3, -1, 0, 0.0, -0.0, 1, 2, 2, 3, 5, 1e17, 1e17 + 2, -1e300, 5e-324, 7.25))


def random_case(rng, n, *, p_wide=0.15, p_unknown=0.0, p_edge_unknown=0.0, p_fail=0.0,
                automatic=None, domain='ext', settings_mix=True, header_missing=0.0, side_mix=True):
    """Random case in the abstract extension domain (G2) or a narrowed rank domain."""
    automatic = rng.random() < 0.8 if automatic is None else automatic
    direction = rng.choice(('AB', 'BA'))
    opening = rng.choice(('AUTO', 'AUTO', 'PAIR', 'SINGLE')) if settings_mix else 'AUTO'
    isolates = sorted(rng.sample(range(n), k=min(n, rng.randrange(0, 3)))) if settings_mix and rng.random() < .3 else []
    pins = []
    if settings_mix and rng.random() < .3 and n > 1:
        start = rng.randrange(0, n - 1)
        pins = list(range(start, min(n - 1, start + rng.randrange(1, 5))))
    c = base_case(n, automatic, direction, opening, isolates, pins)
    for i, item in enumerate(c['items']):
        st = 'WIDE' if rng.random() < p_wide else 'NARROW'
        side = rng.choice(SIDES) if side_mix else 'UNKNOWN'
        item['header'] = fact(st)
        if rng.random() < header_missing:
            item.pop('header')
        r = rng.random()
        if r < p_fail:
            item['analysis'] = dict(status='failed', reason=rng.choice(('READ', 'RESOURCE')))
        elif r < p_fail + p_unknown:
            item['analysis'] = dict(status='unknown')
        else:
            item['analysis'] = dict(status='computed', fact=fact(st, side), version=1)
    edges = []
    for i in range(n - 1):
        r = rng.random()
        if r < p_edge_unknown * 0.85:
            continue                                   # missing record = unknown
        if r < p_edge_unknown:
            edges.append(dict(first=i, second=i + 1, status='failed', failures={str(i): 'RESOURCE'}))
            continue
        edges.append(dict(first=i, second=i + 1, status='computed', score=rank_value(rng, domain), version=1))
    c['edges'] = edges
    return c


def unit_of(plan, target):
    return next(u for u in plan if any(s['item'] == target for s in u['slots']))


def public(result):
    return {k: v for k, v in result.items() if k not in ('reads', 'proof')}


def roundtrip(case):
    """Strict JSON round trip (no NaN/Inf); used before any oracle comparison."""
    return json.loads(json.dumps(case, allow_nan=False))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode('utf-8')).hexdigest()


def next_down(x):
    return math.nextafter(x, -math.inf)


def next_up(x):
    return math.nextafter(x, math.inf)


class Stopwatch:
    def __init__(self):
        self.ns = 0

    def __enter__(self):
        self._t = time.perf_counter_ns()
        return self

    def __exit__(self, *exc):
        self.ns += time.perf_counter_ns() - self._t
        return False


def copy_case(c):
    return copy.deepcopy(c)
