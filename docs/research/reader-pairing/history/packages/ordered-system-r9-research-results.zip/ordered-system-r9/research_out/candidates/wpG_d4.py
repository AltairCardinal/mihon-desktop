"""WP-G D4 runs in the coupled chain on HELD-OUT workloads (never used for exploration):
(a) K01 derive-before-evict raw order; (b) projection R_policy x atomic reissue under a
versioned world (re-extraction carries a new evidence version)."""
import json
from pathlib import Path

import paths  # noqa: F401
import workloads as W
import wpG_coupled as GC
from wpG_owner import GOwner

OUT = Path(__file__).resolve().parents[1] / 'results' / 'raw' / 'wpG'


def heldout_traces():
    out = []
    for seed in range(6):
        out.append(('W01', W.w01_phase_chain(100 + seed)))
        out.append(('W05', W.w05_raw_eviction(100 + seed, holes=6)))
        out.append(('RPjump48', W.random_partial(100 + seed, n=48, pa=0.5, pe=0.25, pattern='jump', count=40)))
        out.append(('W02', W.w02_islands(100 + seed)))
    return out


def d4_k01():
    rows = []
    for fam, tr in heldout_traces():
        for rc in (1, 2, 3, 4):
            for name, kw in (('lru', {}), ('derive', dict(order='derive_first')),
                             ('both', dict(order='derive_first', raw_policy='useless_first'))):
                r = GC.run(tr, kw, raw_capacity=rc, horizon=3000)
                rows.append(dict(family=fam, trace=tr['name'], raw_capacity=rc, variant=name,
                                 **{k: r[k] for k in ('physical_admissions', 'total_latency_u', 'published', 'intents',
                                                      'wrong', 'horizon_hit', 'rank_computations', 'discarded')}))
    worse = []
    by = {}
    for r in rows:
        by[(r['trace'], r['raw_capacity'], r['variant'])] = r
    for (t, rc, v), r in by.items():
        if v == 'derive':
            b = by[(t, rc, 'lru')]
            if (r['published'] < b['published'] or r['physical_admissions'] > b['physical_admissions']
                    or (r['published'] == b['published'] and r['total_latency_u'] > b['total_latency_u'])):
                worse.append(dict(trace=t, rc=rc, lru=b, derive=r))
    (OUT / 'd4_k01_heldout.json').write_text(json.dumps(dict(rows=rows, derive_worse_than_lru=worse), indent=1))
    print('k01 rows', len(rows), 'derive worse cases', len(worse))


def d4_proj_reissue():
    rows = []
    for fam, tr in heldout_traces():
        for name, kw in (('plain', {}),
                         ('proj', dict(owner_factory=lambda c: GOwner(c, support='proj'))),
                         ('reissue', dict(reissue=True)),
                         ('proj_reissue', dict(reissue=True, owner_factory=lambda c: GOwner(c, support='proj')))):
            g = GC.GRunner(tr, session_kw=kw, raw_capacity=2, versioned=True)
            out = g.run(horizon=3000)
            s = g.session
            wrong_now = sum(1 for t, u in s.published.items() if u != g.truth[t])
            rows.append(dict(family=fam, trace=tr['name'], variant=name, first_publications=out['published'],
                             intents=out['intents'], wrong=out['wrong'], wrong_current=wrong_now,
                             published_at_end=len(s.published), engine_runs=s.owner.metrics['engine_runs'],
                             memo_hits=s.owner.metrics['memo_hits'], physical_admissions=out['physical_admissions'],
                             total_latency_u=out['total_latency_u'], reissued=s.metrics['reissued_publications'],
                             publication_read_checks=s.metrics['publication_read_checks']))
    (OUT / 'd4_proj_reissue.json').write_text(json.dumps(dict(rows=rows), indent=1))
    print('proj rows', len(rows))


if __name__ == '__main__':
    d4_k01()
    d4_proj_reissue()
