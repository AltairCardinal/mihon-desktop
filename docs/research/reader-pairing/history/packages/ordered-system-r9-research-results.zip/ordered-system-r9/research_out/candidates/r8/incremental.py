"""B1/B2/B3: maintaining the complete plan under point updates.

Candidates (all complete_plan semantics, verified against reference.complete_plan):
  Recompute   - frozen reference.complete_plan after every update (deep copy, O(n)).
  LinearScan  - one transducer pass per update (representation control, no copy).
  TreePlan    - segment tree of 10-state transition functions; an update touches
                <= 5 leaves (window lemma) + O(log n) nodes; a target query is a
                prefix application (O(log n)) + 1-2 local steps.
  ResyncPlan  - stored boundary states + units; after an update at p rescan from
                boundary p-3 and stop at the first boundary > p+1 whose new state
                equals the stored one (B3 convergence stop rule, proof L-S).
"""
import copy

from common import ref
import transducer as T


def _step(ctx, i, s, include):
    ctx.asg = {}
    return T.step_result(ctx, i, s, include=include)


class Recompute:
    name = 'recompute'

    def __init__(self, case):
        self.case = copy.deepcopy(case)
        self.work = {'full_scans': 0}
        self._plan = None

    def set_item(self, p, item):
        self.case['items'][p] = item
        self._plan = None

    def set_edge(self, a, record):
        self.case['edges'] = [e for e in self.case['edges'] if e['first'] != a]
        if record is not None:
            self.case['edges'].append(dict(record, first=a, second=a + 1))
        self._plan = None

    def plan(self):
        if self._plan is None:
            self._plan = ref.complete_plan(self.case)
            self.work['full_scans'] += 1
        return self._plan

    def unit(self, t):
        return next(u for u in self.plan() if any(s['item'] == t for s in u['slots']))


class LinearScan(Recompute):
    name = 'linear'

    def __init__(self, case):
        super().__init__(case)
        self.F = T.Facts(self.case, 'complete')
        self.ctx = T.Ctx(self.F)

    def set_item(self, p, item):
        self.F.set_item(p, item)
        self._plan = None

    def set_edge(self, a, record):
        self.F.set_edge(a, record)
        self._plan = None

    def plan(self):
        if self._plan is None:
            ctx, n = self.ctx, self.F.n
            out, s, i = [], T.S0, 0
            while i < n:
                nxt, unit = _step(ctx, i, s, True)
                out.append(unit)
                if nxt >> 1 == T.SKIP:
                    s = _step(ctx, i + 1, nxt, False)[0]
                    i += 2
                else:
                    s, i = nxt, i + 1
            self._plan = out
            self.work['full_scans'] += 1
        return self._plan


class TreePlan:
    name = 'tree'

    def __init__(self, case):
        self.F = T.Facts(copy.deepcopy(case), 'complete')
        self.work = {}
        self.tree = T.RelTree(self.F, self.work)
        self.ctx = self.tree.ctx

    def set_item(self, p, item):
        self.F.set_item(p, item)
        self.tree.update_leaves(T.affected_leaves(p))

    def set_edge(self, a, record):
        self.F.set_edge(a, record)
        self.tree.update_leaves((a - 1, a))

    def _state(self, t):
        mask = self.tree.prefix(t)
        return mask.bit_length() - 1          # deterministic: exactly one bit

    def unit(self, t):
        s = self._state(t)
        self.work['queries'] = self.work.get('queries', 0) + 1
        if s >> 1 == T.SKIP:
            return _step(self.ctx, t - 1, self._state(t - 1), True)[1]
        return _step(self.ctx, t, s, True)[1]

    def plan(self):
        out, s, i, n = [], T.S0, 0, self.F.n
        while i < n:
            nxt, unit = _step(self.ctx, i, s, True)
            out.append(unit)
            if nxt >> 1 == T.SKIP:
                s = _step(self.ctx, i + 1, nxt, False)[0]
                i += 2
            else:
                s, i = nxt, i + 1
        return out


class ResyncPlan:
    name = 'resync'

    def __init__(self, case):
        self.F = T.Facts(copy.deepcopy(case), 'complete')
        self.ctx = T.Ctx(self.F)
        n = self.F.n
        self.states = [None] * (n + 1)      # boundary states
        self.cover = [None] * n             # unit covering each position
        self.work = {'resync_steps': 0, 'resync_calls': 0, 'max_propagation': 0}
        self._scan_from(0, T.S0, None)

    def _scan_from(self, start, s, stop_after):
        ctx, n = self.ctx, self.F.n
        i = start
        steps = 0
        while i < n:
            old_next = self.states[i + 1]
            self.states[i] = s
            nxt, unit = _step(ctx, i, s, True)
            steps += 1
            if unit is not None:
                for sl in unit['slots']:
                    self.cover[sl['item']] = unit
            if (stop_after is not None and i >= stop_after and old_next == nxt):
                self.states[i + 1] = nxt
                break
            self.states[i + 1] = nxt
            s = nxt
            i += 1
        return steps

    def _resync(self, p_lo, p_hi):
        start = max(0, p_lo - 3)
        steps = self._scan_from(start, self.states[start], p_hi + 1)
        self.work['resync_steps'] += steps
        self.work['resync_calls'] += 1
        self.work['max_propagation'] = max(self.work['max_propagation'], steps)

    def set_item(self, p, item):
        self.F.set_item(p, item)
        self._resync(p, p)

    def set_edge(self, a, record):
        self.F.set_edge(a, record)
        self._resync(a, a)          # leaves a-1, a read edge (a, a+1)

    def unit(self, t):
        return self.cover[t]

    def plan(self):
        out, seen = [], set()
        for u in self.cover:
            if id(u) not in seen:
                seen.add(id(u))
                out.append(u)
        return out


CANDIDATES = {c.name: c for c in (Recompute, LinearScan, TreePlan, ResyncPlan)}
