"""Render results/summary/wpC/{summary.md,summary.json} from results/raw/wpC/*.json (no new numbers)."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
RAW, OUT = ROOT / 'results/raw/wpC', ROOT / 'results/summary/wpC'


def compact(v):
    if isinstance(v, dict) and 'work' in v:
        return {k: v[k] for k in ('work', 'wall_ms', 'peak_residency') if k in v}
    return v


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    md, js = ['# WP-C result summary (generated from results/raw/wpC by candidates/wpC_summarize.py)',
              'work = scan_steps + resync_steps + 5*leaf_evals (deterministic); wall_ms = single local trial (noisy, shared 2 vCPU).', ''], {}
    for f in sorted(RAW.glob('*.json')):
        if f.stem == 'N04_reduced_trace':
            continue
        d = json.loads(f.read_text())
        if f.stem == 'D4_coupled':
            d = d['summary']
        if isinstance(d, list):
            rows = [{k: compact(v) for k, v in r.items()} for r in d]
        else:
            rows = {k: ([{a: compact(b) for a, b in r.items()} if isinstance(r, dict) else r for r in v]
                        if isinstance(v, list) else v) for k, v in d.items()}
        js[f.stem] = rows
        md.append(f'## {f.stem}')
        if isinstance(rows, list):
            for r in rows:
                md.append('- ' + json.dumps(r, separators=(',', ':'), default=str))
        else:
            for k, v in rows.items():
                if isinstance(v, list):
                    md.append(f'- **{k}**')
                    md += ['  - ' + json.dumps(x, separators=(',', ':'), default=str) for x in v]
                else:
                    md.append(f'- **{k}**: ' + json.dumps(v, separators=(',', ':'), default=str))
        md.append('')
    (OUT / 'summary.md').write_text('\n'.join(md))
    (OUT / 'summary.json').write_text(json.dumps(js, indent=1, default=str))
    print('rows', {k: len(v) for k, v in js.items()})


if __name__ == '__main__':
    main()
