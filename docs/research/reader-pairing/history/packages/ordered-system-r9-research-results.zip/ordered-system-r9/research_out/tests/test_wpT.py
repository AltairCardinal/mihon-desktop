"""Main-session T-family checks: hidden-premise reproducers (T01) and the hand-off checker (T04)."""
import copy, sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
sys.path.insert(0, str(paths.ROOT / 'tests'))
from coupling import Session, Witness
from test_reference import case as ref_case, fact
import workloads as W
import wpT_checker as CK
from strong import StrongSession, strong_attempt


def partial(n=5):
    c = ref_case(n, True)
    for it in c['items']:
        it['analysis'] = {'status': 'unknown'}
    c['edges'] = []
    return c


def wit(v):
    return Witness({'status': 'computed', 'fact': fact(), 'version': 1}, v)


class Premises(unittest.TestCase):
    def test_P2_evict_before_derive_at_raw_capacity_one(self):
        """Package Session evicts the oldest raw witness BEFORE deriving adjacent ranks;
        NATIVE_OWNER.pseudo derives first.  At raw_capacity=1 no rank is ever derived."""
        s = Session(partial(), raw_capacity=1)
        for i in (1, 2):
            t = s.acquire(i); s.finish(t, wit(i)); s.consume(t)
        self.assertEqual(s.metrics['rank_computations'], 0)
        s2 = Session(partial(), raw_capacity=2)
        for i in (1, 2):
            t = s2.acquire(i); s2.finish(t, wit(i)); s2.consume(t)
        self.assertEqual(s2.metrics['rank_computations'], 1)

    def test_P3_confirm_is_not_bound_to_a_publication(self):
        """confirm(target) cannot tell which publication a (late) callback refers to."""
        tr = W.w05_raw_eviction(0, n=8, holes=0)
        s = Session(tr['initial'])
        v1 = s.certify(2)
        self.assertEqual(s.publish(2, v1['certificate']), 'published')
        e = next(x for x in s.owner._case['edges'] if x['first'] == 2)
        s.owner.apply(edge_updates={(2, 3): dict(e, version=99)})      # support change -> first publication stale
        v2 = s.certify(2)
        self.assertEqual(s.publish(2, v2['certificate']), 'published')
        # a callback meant for the expired first publication now confirms the second one
        self.assertEqual(s.confirm(2), 'confirmed')

    def test_P6_exact_support_expires_on_pure_refinement(self):
        """A strong certificate's support records unknown facts, so admitting a fact that
        does not change the truth unit still expires the publication (refresh needed)."""
        tr = W.w01_phase_chain(0, n=24, holes=2)
        s = StrongSession(tr['initial'], strong=dict(kind='tree', domain='nonneg', gate='sound'))
        hit = None
        for t in range(24):
            v = s.certify(t, mode='S')
            if v.get('route', '').startswith('strong'):
                hit = (t, v); break
        self.assertIsNotNone(hit)
        t, v = hit
        self.assertEqual(s.publish(t, v['certificate']), 'published')
        missing = [a for a in range(23) if not any(e['first'] == a for e in s.owner._case['edges'])]
        a = next(x for x in missing if x <= t + 2)
        world_edge = next(e for e in W.w01_phase_chain(0, n=24, holes=0)['initial']['edges'] if e['first'] == a)
        s.owner.apply(edge_updates={(a, a + 1): world_edge})                # true value: a refinement
        again = s.certify(t, mode='L0')
        self.assertEqual(again['unit'], v['unit'])                          # same unit, now certified by L0
        self.assertEqual(len(s.published), 0)                               # but the strong publication expired


class Checker(unittest.TestCase):
    def test_checker_accepts_issued_and_rejects_mutants(self):
        for fam in ('W01', 'W06', 'RP'):
            for seed in range(3):
                tr = W.FAMILIES[fam](seed)
                c = tr['initial']
                for t in range(len(c['items'])):
                    a = strong_attempt(c, t, 'tree', 'nonneg', False)
                    if a['status'] != 'certified':
                        continue
                    ok, why = CK.check(c, t, a['unit'])
                    self.assertTrue(ok, why)
                    self.assertTrue(CK.check_support(c, t, a['unit'], trials=5))
                    bad = copy.deepcopy(a['unit']); bad['reason'] = 'MUTANT'
                    self.assertFalse(CK.check(c, t, bad)[0])


if __name__ == '__main__':
    unittest.main()
