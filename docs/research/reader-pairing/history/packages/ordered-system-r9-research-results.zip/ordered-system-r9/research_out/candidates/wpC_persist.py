"""WP-C persistence / cross-context HYPOTHESIS BRANCH (Q01-Q06).  Never default.

Q01 content-value cache keys: strict digest key vs short hash vs producer
    capability reference.
Q02 persistent derived index break-even (simulated unit costs, labelled).
Q03 cross-owner proof migration on real Sessions: re-validate support, re-issue
    a NEW certificate in the new owner; confirmations/location/leases never move.
Q04 recovery after termination: write-ahead marker vs idempotent recompute,
    exhaustive crash points.
Q05 multi-version coexistence: certificates never combine facts of different
    algorithm versions.
Q06 observable reuse leakage across isolation domains and the isolation cost.
"""
import hashlib
import json
import random
from copy import deepcopy

import paths  # noqa: F401
from current_baseline import typed


# ------------------------------------------------------------------ Q01
def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False)


def strict_key(content, transform, algorithm, numeric_contract='binary64'):
    """Full SHA-256 of canonical content + every label the value depends on.
    Used as a LOOKUP accelerator; on hit the stored canonical content is also
    compared exactly (so even a digest collision cannot authorise reuse)."""
    blob = canonical(dict(c=content, t=transform, a=algorithm, d=numeric_contract))
    return hashlib.sha256(blob.encode()).hexdigest(), blob


class ValueCache:
    def __init__(self, mode='strict', bits=16):
        self.mode, self.bits = mode, bits
        self.store = {}
        self.stats = dict(hits=0, misses=0, false_hits=0, exact_rejects=0)

    def key(self, content, transform, algorithm, capability=None):
        if self.mode == 'strict':
            return strict_key(content, transform, algorithm)
        if self.mode == 'short':
            h = int(hashlib.sha256(canonical(content).encode()).hexdigest(), 16) & ((1 << self.bits) - 1)
            return h, None
        return capability, None                  # 'capability': producer-issued reference only

    def get_or_compute(self, content, transform, algorithm, fn, capability=None):
        k, blob = self.key(content, transform, algorithm, capability)
        if k in self.store:
            stored_blob, value, true_value_of = self.store[k]
            if self.mode == 'strict' and stored_blob != blob:
                self.stats['exact_rejects'] += 1
            else:
                self.stats['hits'] += 1
                if true_value_of != canonical(content) + transform + algorithm:
                    self.stats['false_hits'] += 1
                return value
        self.stats['misses'] += 1
        v = fn(content)
        self.store[k] = (blob, v, canonical(content) + transform + algorithm)
        return v


# ------------------------------------------------------------------ Q03
def migrate_certificate(old_session, handle, new_session):
    """Re-validate the old certificate's support against the NEW owner's
    current reads and issue a fresh certificate there.  Returns new handle or
    a refusal string.  Old publications/confirmations are never copied."""
    cert = old_session._certs.get(handle)
    if cert is None:
        return 'unsigned'
    owner = new_session.owner
    index = owner._index()
    n = len(owner._case['items'])
    for key, old in cert['support'].items():
        pos = key[1]
        if pos >= n or (key[0] == 'rank' and key[2] >= n):
            return 'support_out_of_range'
        if typed(owner._read(index, key)) != typed(old):
            return 'support_mismatch'
    # identities of all support positions must match (same content labels)
    for key in cert['support']:
        if key[0] == 'analysis':
            p = key[1]
            if typed(old_session.owner._identities.get(p)) != typed(owner._identities.get(p)):
                return 'identity_mismatch'
    new_session._next_certificate += 1
    h = new_session._next_certificate
    new_session._certs[h] = dict(target=cert['target'], unit=deepcopy(cert['unit']), guard=owner._guard(),
                                 epoch=new_session.epoch, support=dict(cert['support']))
    return h


# ------------------------------------------------------------------ Q04
STEPS = ('computed', 'bytes_written', 'marker_written', 'fact_admitted', 'published')


def recover(disk, route, epoch_now):
    """Return (admitted_fact_or_None, actions).  disk: dict of persisted records."""
    actions = []
    rec = disk.get('record')
    if route == 'marker':
        if rec is not None and disk.get('marker') == rec.get('digest') and rec.get('epoch') == epoch_now:
            return rec['value'], actions
        actions.append('discard')
        disk.pop('record', None); disk.pop('marker', None)
        return None, actions
    # idempotent recompute: never trust bytes, recompute value from inputs
    actions.append('recompute')
    disk.pop('record', None); disk.pop('marker', None)
    return None, actions


def crash_matrix():
    """Exhaustive crash points x late old completion x repeated recovery."""
    rows = []
    for route in ('marker', 'recompute'):
        for crash_after in range(len(STEPS) + 1):
            for late_old in (False, True):
                for repeats in (1, 2):
                    disk = {}
                    value = 42
                    digest = hashlib.sha256(b'42').hexdigest()
                    for k, st in enumerate(STEPS[:crash_after]):
                        if st == 'bytes_written':
                            disk['record'] = dict(value=value, digest=digest, epoch=1)
                        if st == 'marker_written':
                            disk['marker'] = digest
                    if crash_after == 2:            # half-written: bytes present, corrupt value
                        disk['record'] = dict(value=None, digest=digest, epoch=1)
                    epoch_now = 2 if late_old else 1
                    results = [recover(disk, route, epoch_now)[0] for _ in range(repeats)]
                    # invariants: never admit a corrupt/half value; never admit an old-epoch value
                    ok = all(r in (None, 42) for r in results) and not (late_old and any(r is not None for r in results))
                    ok &= len(set(map(str, results))) == 1            # idempotent recovery
                    rows.append(dict(route=route, crash_after=crash_after, late_old=late_old, repeats=repeats,
                                     admitted=results[-1], invariant_ok=ok))
    return rows


# ------------------------------------------------------------------ Q05
def combine_certificate(facts):
    """facts: list of (value, algorithm_version).  Mixed versions are refused."""
    versions = {v for _x, v in facts}
    if len(versions) != 1:
        return 'refused_mixed_versions'
    return 'ok'


# ------------------------------------------------------------------ Q06
def leakage_experiment(seed=0, trials=4000, shared=True, overlap=0.5):
    """Two isolation domains; an observer in domain B learns whether domain A
    recently used content x by timing a lookup (hit vs miss)."""
    rng = random.Random(seed)
    hits_present = hits_absent = n_present = n_absent = 0
    reuse_hits = reuse_total = 0
    for t in range(trials):
        x = rng.randrange(10 ** 9)
        present = rng.random() < 0.5
        cacheA = {x} if present else set()
        cacheB = cacheA if shared else set()
        hit = x in cacheB
        if present:
            n_present += 1; hits_present += hit
        else:
            n_absent += 1; hits_absent += hit
        # legitimate reuse: B also needs a content A computed with probability `overlap`
        y = x if rng.random() < overlap else rng.randrange(10 ** 9)
        reuse_total += 1
        reuse_hits += (y in cacheB)
    adv = abs(hits_present / max(1, n_present) - hits_absent / max(1, n_absent))
    return dict(shared=shared, distinguishing_advantage=round(adv, 3), legitimate_reuse_rate=round(reuse_hits / reuse_total, 3))
