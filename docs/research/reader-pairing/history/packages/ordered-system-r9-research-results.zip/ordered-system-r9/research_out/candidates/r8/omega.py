"""Possible-world oracle and exact relational (shared-assignment) certifier.

* worlds(case, ...)  - brute-force completions of current knowledge (tiny n only)
  under alpha header authority, with rank values drawn from an order-type
  ladder of the chosen domain.  This is the independent oracle for soundness
  checks of every early-certification candidate (reference.complete_plan is
  the plan of each complete world).
* certify_exact(...) - forward DP over (transducer state, assignment of the
  still-relevant unknown facts / rank constraints).  Assignments are shared
  between overlapping windows, so it is exact for the abstract domain when
  started from position 0; starting at first>0 with all 10 entry states is a
  sound over-approximation (finite-entry argument, relational version).
"""
import copy
import itertools
import math

from common import ref, unit_of, G0_MAX_M
import transducer as T

DBL_MAX = T.DBL_MAX


# ------------------------------------------------------------ world oracle
def _below(x, k, lo):
    out = []
    for d in (1, 2, 3):
        v = x - d
        if v < x and v >= lo and v not in out:
            out.append(v)
    v = x
    while len(out) < k:
        v = math.nextafter(float(v), -math.inf)
        if v < lo:
            break
        if v < x and v not in out:
            out.append(v)
    return out[:k]


def _above(x, k):
    out = []
    for d in (1, 2, 3):
        v = x + d
        if v > x and v <= DBL_MAX and v not in out:
            out.append(v)
    v = x
    while len(out) < k:
        v = math.nextafter(float(v), math.inf)
        if v > DBL_MAX:
            break
        if v > x and v not in out:
            out.append(v)
    return out[:k]


def ladder(domain, knowns, per_gap=3):
    """Rank values realising every order pattern of up to per_gap free values
    in each gap between known values (domain-restricted)."""
    if domain == 'G0':
        ks = sorted(set(knowns))
        ms = sorted({round(k * 50) for k in ks})
        pts = set(ms)
        bounds = [-1] + ms + [G0_MAX_M + 1]
        for a, b in zip(bounds, bounds[1:]):
            inner = list(range(a + 1, b))
            if inner:
                step = max(1, len(inner) // (per_gap + 1))
                pts.update(inner[step - 1::step][:per_gap] if len(inner) > per_gap else inner)
        return sorted(p / 50 for p in pts)
    lo = 0 if domain == 'nonneg' else -DBL_MAX
    ks = sorted(set(knowns))
    if not ks:
        return [0, 1, 2, 3, 4] if domain == 'nonneg' else [-1, 0, 1, 2, 3]
    pts = set(ks)
    pts.update(_below(ks[0], per_gap, lo))
    pts.update(_above(ks[-1], per_gap))
    for a, b in zip(ks, ks[1:]):
        cand = []
        for f in (0.25, 0.5, 0.75):
            v = a + (b - a) * f
            if a < v < b:
                cand.append(v)
        v = a
        while len(set(cand)) < per_gap:
            v = math.nextafter(float(v), math.inf)
            if not v < b:
                break
            if v > a:
                cand.append(v)
        pts.update(cand)
    return sorted(pts, key=float)


def worlds(case, domain='ext', alpha=True, cap=200000, per_gap=3):
    """Yield complete cases consistent with current knowledge (or raise if > cap)."""
    F = T.Facts(case, 'omega', domain, alpha)
    n = F.n
    pos_opts = []
    for p in range(n):
        sts = (F.state[p],) if F.state[p] is not None else ('NARROW', 'WIDE')
        sds = (F.side[p],) if F.side[p] is not None else ('A', 'B', 'UNKNOWN')
        if not F.automatic and F.side[p] is None:
            sds = ('UNKNOWN',)        # side never read when automatic is off
        pos_opts.append([(s, d) for s in sts for d in sds])
    knowns = [e.get('score') for e in F.records.values()
              if e.get('status') == 'computed' and e.get('score') is not None]
    lad = ladder(domain, knowns, per_gap)
    total = 1
    for o in pos_opts:
        total *= len(o)
    if total > cap:
        raise OverflowError('too many worlds')
    for combo in itertools.product(*pos_opts):
        free_edges = [a for a in range(n - 1)
                      if combo[a][0] == 'NARROW' and combo[a + 1][0] == 'NARROW'
                      and not (F.records.get(a, {}).get('status') == 'computed')]
        count = total * (len(lad) + 1) ** len(free_edges)
        if count > cap:
            raise OverflowError('too many worlds')
        for vals in itertools.product([None] + lad, repeat=len(free_edges)):
            w = copy.deepcopy(case)
            for p, (st, sd) in enumerate(combo):
                item = w['items'][p]
                a = item.get('analysis', {'status': 'unknown'})
                ident = F.ix.ident(p)
                if a.get('status') == 'computed' and T._valid(F.ix.analysis(p)[1], ident):
                    continue
                f = dict(state=st, width=200 if st == 'WIDE' else 100, height=200,
                         rotation=ident[2], orientation=ident[3], side=sd)
                if ident[2] in (90, 270):
                    f['width'], f['height'] = f['height'], f['width']
                item['analysis'] = dict(status='computed', fact=f, version=1)
            recs = {(e['first'], e['second']): e for e in w.get('edges', [])}
            for a, v in zip(free_edges, vals):
                recs[(a, a + 1)] = dict(first=a, second=a + 1, status='computed', score=v, version=1)
            w['edges'] = list(recs.values())
            yield w


def oracle_units(case, target, domain='ext', alpha=True, cap=200000):
    seen = {}
    for w in worlds(case, domain, alpha, cap):
        u = unit_of(ref.complete_plan(w), target)
        seen[T._key(u)] = u
    return seen


# ------------------------------------------------------- exact relational DP
def _components_touching(lts, min_edge):
    """Keep only 'lt' constraints whose connected component (via shared
    symbolic edges) contains an edge >= min_edge."""
    items = list(lts)
    if not items:
        return []
    edges_of = [{t[1] for t in key[1:] if t[0] == 'e'} for key, _ in items]
    keep = [any(e >= min_edge for e in es) for es in edges_of]
    changed = True
    while changed:
        changed = False
        live = set().union(*[es for es, k in zip(edges_of, keep) if k]) if any(keep) else set()
        for j, es in enumerate(edges_of):
            if not keep[j] and es & live:
                keep[j] = True
                changed = True
    return [it for it, k in zip(items, keep) if k]


def _prune(asg, i):
    """Keep facts still readable by steps >= i+1 (window [i, i+4])."""
    out = {}
    lts = []
    for k, v in asg.items():
        tag = k[0]
        if tag in ('st', 'sd'):
            if k[1] >= i:
                out[k] = v
        elif tag == 'rk':
            if k[1] >= i + 1:
                out[k] = v
        else:
            lts.append((k, v))
    for k, v in _components_touching(lts, i + 1):
        out[k] = v
    return out


def certify_exact(case, target, domain='ext', alpha=True, first=0, counters=None, limit=200000):
    """Return ('certified', unit) | ('ambiguous', units) | ('limit', None)."""
    F = T.Facts(case, 'omega', domain, alpha)
    ctx = T.Ctx(F)
    cnt = counters if counters is not None else {}
    if first == 0:
        frontier = {(T.S0, frozenset())}
    else:
        frontier = {(s, frozenset()) for s in range(T.NSTATE)}
    units = {}
    evals = 0
    for i in range(first, target + 1):
        nxt_frontier = set()
        for s, asg in frontier:
            if s >> 1 == T.SKIP and i == target:
                continue                   # target already covered by the pair at target-1
            res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=i >= target - 1), dict(asg))
            evals += len(res)
            for (ns, unit), a in res:
                if unit is not None and any(sl['item'] == target for sl in unit['slots']):
                    units[T._key(unit)] = unit
                elif i < target:
                    nxt_frontier.add((ns, frozenset(_prune(a, i).items())))
            if evals > limit:
                cnt['dp_evals'] = cnt.get('dp_evals', 0) + evals
                return 'limit', None
        frontier = nxt_frontier
        cnt['dp_max_frontier'] = max(cnt.get('dp_max_frontier', 0), len(frontier))
    cnt['dp_evals'] = cnt.get('dp_evals', 0) + evals
    if len(units) == 1:
        return 'certified', next(iter(units.values()))
    return 'ambiguous', units


def certify_exact_doubling(case, target, domain='ext', alpha=True, counters=None, limit=200000):
    """Relational finite-entry search: first = target-2, target-4, ... , 0."""
    d = 2
    while True:
        first = max(0, target - d)
        st, u = certify_exact(case, target, domain, alpha, first, counters, limit)
        if st == 'certified' or first == 0 or st == 'limit':
            return st, u, first
        d *= 2


class FrontierCache:
    """F5/B4: the exact forward frontier at boundary i (for i < target-1) does not
    depend on the target (include=False), so frontiers are computed once per
    knowledge state and shared by every target.  Learned 'impossible
    (state, assignment)' pairs are exactly the complement of each frontier."""

    def __init__(self, case, domain='ext', alpha=True, counters=None, limit=400000):
        self.F = T.Facts(case, 'omega', domain, alpha)
        self.ctx = T.Ctx(self.F)
        self.frontiers = [{(T.S0, frozenset())}]
        self.cnt = counters if counters is not None else {}
        self.limit = limit
        self.evals = 0

    def _extend(self, upto):
        ctx = self.ctx
        while len(self.frontiers) <= upto:
            i = len(self.frontiers) - 1
            nxt = set()
            for s, asg in self.frontiers[i]:
                res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=False), dict(asg))
                self.evals += len(res)
                for (ns, _u), a in res:
                    nxt.add((ns, frozenset(_prune(a, i).items())))
            if self.evals > self.limit:
                raise OverflowError('frontier limit')
            self.frontiers.append(nxt)
        self.cnt['dp_evals'] = self.evals

    def certify(self, target):
        """Same answer as certify_exact(first=0)."""
        start = max(0, target - 1)
        try:
            self._extend(start)
        except OverflowError:
            return 'limit', None
        ctx = self.ctx
        frontier = self.frontiers[start]
        units = {}
        for i in range(start, target + 1):
            nxt = set()
            for s, asg in frontier:
                if s >> 1 == T.SKIP and i == target:
                    continue
                res = T.explore(ctx, lambda: T.step_result(ctx, i, s, include=True), dict(asg))
                self.evals += len(res)
                for (ns, unit), a in res:
                    if unit is not None and any(sl['item'] == target for sl in unit['slots']):
                        units[T._key(unit)] = unit
                    elif i < target:
                        nxt.add((ns, frozenset(_prune(a, i).items())))
            frontier = nxt
        if len(units) == 1:
            return 'certified', next(iter(units.values()))
        return 'ambiguous', units
