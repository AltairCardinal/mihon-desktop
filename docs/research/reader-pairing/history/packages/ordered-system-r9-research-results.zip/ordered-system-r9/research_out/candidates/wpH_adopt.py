"""WP-H executable adoption gates.  Each gate reads only observables a controller has (declared bounds,
measured rates, contract flags) -- never World latents.  tests/test_wpH.py checks every gate against the
raw evidence it was derived from; the reversal points are the measured boundaries, not extrapolations."""


def gate_bound_confirm():
    """Bind confirmation callbacks to the publication handle: always (no cost but carrying the handle)."""
    return True


def gate_inc_revoke(guard_change_rate, item_write_rate):
    """Incremental revocation equals full revalidation by construction (proofs/wpH.md L2); its saving comes
    from item writes that touch few supports.  A guard/epoch change forces the full check, so the gain
    disappears when every write is a guard change."""
    return item_write_rate > 0 and guard_change_rate < item_write_rate


def gate_value_cache(knowledge_losing_rebinds, producer_label_contract):
    """Value-keyed reuse of witnesses across owner incarnations.  Requires the producer contract
    (same typed identity+version => same content); authority (certificates/publications/confirmations)
    is never reused.  Pays only when rebinds lose admitted knowledge (fresh incarnation) or equal content
    is re-acquired; with carry-over rebinds latency is unchanged (H05 carry: 3u vs 3u)."""
    return bool(producer_label_contract) and knowledge_losing_rebinds > 0


def gate_split(p_need, rho_joint):
    """I04: split acquire|derive and skip derive when not needed.  Work always falls when p_need<1 (route A);
    latency of needed jobs falls only when the joint pipeline is overloaded (route B DES: wins at
    rho_joint>=1.25, loses at rho_joint<=0.75 in every tested config, hop 1..3)."""
    return p_need < 1.0 and rho_joint > 1.0


def gate_reserve(optional_service_bound, required_tolerance_u, optional_droppable):
    """I02/X23: reserve a slot for required work only if optional services can exceed the required
    latency tolerance and optional work may be delayed/dropped.  With short optional work (coupled
    service_u=3, X23 latents 3..8) reservation gave no required gain and removed useful prefetch."""
    return optional_droppable and optional_service_bound > required_tolerance_u


def gate_dyn_borrow(declared_bound, B):
    """Optional work may borrow the reserved slot iff its declared upper bound <= B; required delay <= B."""
    return declared_bound is not None and declared_bound <= B


def gate_microbatch(setup_u, mean_service_u):
    """I05/X24: amortise a per-dispatch setup with per-item completion (never a barrier) when the setup is
    at least the mean member service; barrier batches were never better than per-item ones."""
    return setup_u >= mean_service_u


def choose_batch_mode():
    return 'per_item'


def gate_spec_credit(prediction_hit_rate_by_requester):
    """J06: isolate speculation credit per requester and refund on use; a requester whose recent hit rate
    is 0 keeps only its initial credit (cannot drain others)."""
    return {k: ('refund' if v > 0 else 'initial_only') for k, v in prediction_hit_rate_by_requester.items()}
