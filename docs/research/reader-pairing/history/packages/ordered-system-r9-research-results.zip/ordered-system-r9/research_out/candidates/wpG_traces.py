"""Frozen owner-level traces (exogenous; generated before any candidate runs).

op = ('req', t) | ('item', i, patch) | ('edge', a, record_or_None) | ('same_item', i) (a write
of the identical stored record, used by G04) ; traces are plain JSON.
"""
import copy
import json
import random

import paths  # noqa: F401
from common import fact, base_case, rank_value


def _case(rng, n, chain=False, p_unknown=0.25, p_edge_unknown=0.2):
    c = base_case(n, automatic=True, direction=rng.choice(('AB', 'BA')))
    for i, it in enumerate(c['items']):
        st = 'WIDE' if (not chain and rng.random() < 0.1) else 'NARROW'
        it['header'] = fact(st)
        if rng.random() < p_unknown:
            it['analysis'] = {'status': 'unknown'}
        else:
            it['analysis'] = dict(status='computed', fact=fact(st, rng.choice(('A', 'B', 'UNKNOWN', 'UNKNOWN')) if not chain else 'UNKNOWN'), version=1)
    edges = []
    for a in range(n - 1):
        if rng.random() < p_edge_unknown:
            continue
        s = float(n - a) if chain else (None if rng.random() < .15 else rng.randrange(0, 1500) / 50)
        edges.append(dict(first=a, second=a + 1, status='computed', score=s, version=1))
    c['edges'] = edges
    return c


def generate(seed, n=64, rounds=120, mix='dependent', chain=False, same_rate=0.0, locality='neighbor'):
    rng = random.Random(seed)
    c = _case(rng, n, chain=chain)
    cur = copy.deepcopy(c)
    ops = []
    t = rng.randrange(n)
    hot = [rng.randrange(n) for _ in range(3)]
    for r in range(rounds):
        if locality == 'neighbor':
            t = min(n - 1, max(0, t + rng.choice((-1, 0, 1))))
        elif locality == 'hot':
            t = rng.choice(hot)
        else:
            t = rng.randrange(n)
        ops.append(['req', t])
        ops.append(['req', t])
        k = {'quiet': 0, 'unrelated': 1, 'dependent': 1, 'churn': 3, 'refresh': 2}[mix]
        for _ in range(k):
            if rng.random() < same_rate:
                i = rng.randrange(n)
                ops.append(['same_item', i])
                continue
            if mix == 'unrelated':
                i = (t + n // 2 + rng.randrange(-4, 5)) % n
            else:
                i = min(n - 1, max(0, t + rng.randrange(-3, 4)))
            if mix == 'refresh' and rng.random() < 0.85:
                # re-admission of the same semantic fact with a new evidence version
                old = cur['items'][i]['analysis']
                if old.get('status') == 'computed':
                    a = dict(copy.deepcopy(old), version=r + 2)
                    cur['items'][i]['analysis'] = a
                    ops.append(['item', i, {'analysis': a}])
                    continue
                if i < n - 1:
                    recs = [e for e in cur['edges'] if e['first'] == i]
                    if recs and recs[0].get('status') == 'computed':
                        rec = dict(status='computed', score=recs[0]['score'], version=r + 2)
                        cur['edges'] = [e for e in cur['edges'] if e['first'] != i] + [dict(rec, first=i, second=i + 1)]
                        ops.append(['edge', i, rec])
                        continue
            if rng.random() < 0.6:
                a = rng.choice([dict(status='computed', fact=fact(cur['items'][i]['header']['state'], rng.choice(('A', 'B', 'UNKNOWN'))), version=r + 2),
                                {'status': 'unknown'}, dict(status='failed', reason='RESOURCE')])
                cur['items'][i]['analysis'] = a
                ops.append(['item', i, {'analysis': a}])
            elif i < n - 1:
                rec = None if rng.random() < 0.2 else dict(status='computed', score=float(n - i) if chain else rank_value(rng, 'G0'), version=r + 2)
                cur['edges'] = [e for e in cur['edges'] if e['first'] != i] + ([dict(rec, first=i, second=i + 1)] if rec else [])
                ops.append(['edge', i, rec])
    return dict(schema='wpG-trace-v1', seed=seed, n=n, mix=mix, chain=chain, same_rate=same_rate,
                initial=c, ops=ops)


def replay(trace, owner, collect=True):
    out = []
    for op in trace['ops']:
        if op[0] == 'req':
            v = owner.request(op[1])
            if collect:
                out.append(v)
        elif op[0] == 'item':
            owner.apply(item_updates={op[1]: op[2]})
        elif op[0] == 'edge':
            a = op[1]
            owner.apply(edge_updates={(a, a + 1): op[2]})
        elif op[0] == 'same_item':
            i = op[1]
            rec = owner._case['items'][i]
            if getattr(owner, 'noop', None) == 'hint':
                owner.apply(item_updates={i: copy.deepcopy(rec)}, same={('item', i)})
            else:
                owner.apply(item_updates={i: copy.deepcopy(rec)})
    return out


def truth(trace):
    import reference as ref
    c = copy.deepcopy(trace['initial'])
    out = []
    for op in trace['ops']:
        if op[0] == 'req':
            out.append({k: v for k, v in ref.certify_strategy(c, op[1])['selected'].items() if k != 'reads'})
        elif op[0] == 'item':
            c['items'][op[1]].update(copy.deepcopy(op[2]))
        elif op[0] == 'edge':
            a = op[1]
            c['edges'] = [e for e in c['edges'] if (e['first'], e['second']) != (a, a + 1)]
            if op[2] is not None:
                c['edges'].append(dict(copy.deepcopy(op[2]), first=a, second=a + 1))
    return out
