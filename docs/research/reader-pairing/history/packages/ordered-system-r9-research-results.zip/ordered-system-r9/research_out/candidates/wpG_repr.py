"""WP-G representation studies (L01 L02 L03 L04 L05, X27).

L01  five-state transition functions: tuple composition (r8 incumbent form),
     bytes.translate composition (C-level, one allocation), 3-bit packed int,
     generated straight-line code.  Equivalence: all 5^5 x 5^5 pairs.
L02  support storage: dict of typed values vs (shared key tuple, value tuple)
     with a 64-bit fingerprint fast path whose equality is ALWAYS confirmed by an
     exact compare (hash collisions detectable, never trusted).
L03  D_src operator: LUT normalisation + fused loop keeping OPTIMIZED_OPERATOR's
     exact thresholds, early-null point and binary64 evaluation order.
L05  clone-free read-only owner view vs snapshot deepcopy.
"""
import array
import itertools

import paths  # noqa: F401
from current_baseline import typed

# ------------------------------------------------------------------ L01
NS = 5


def compose_tuple(f, g):
    return tuple(g[x] for x in f)


def as_bytes(f):
    return bytes(f) + bytes(range(NS, 256))


def compose_bytes(f, g):
    """f, g as 256-byte translation tables (states in the first 5 bytes)."""
    return f.translate(g)


def pack(f):
    v = 0
    for s in range(NS - 1, -1, -1):
        v = (v << 3) | f[s]
    return v


def unpack(v):
    return tuple((v >> (3 * s)) & 7 for s in range(NS))


def compose_packed(a, b):
    out = 0
    for s in range(NS):
        x = (a >> (3 * s)) & 7
        out |= ((b >> (3 * x)) & 7) << (3 * s)
    return out


_src = 'def compose_straight(f, g):\n    return (' + ', '.join(f'g[f[{s}]]' for s in range(NS)) + ')\n'
_ns = {}
exec(_src, _ns)
compose_straight = _ns['compose_straight']


def all_functions():
    return list(itertools.product(range(NS), repeat=NS))


# ------------------------------------------------------------------ L02
class FlatSupport:
    """Keys tuple shared between entries with the same key layout + value tuple."""
    __slots__ = ('keys', 'values', 'fp')
    _key_table = {}

    def __init__(self, support):
        keys = tuple(support)
        self.keys = FlatSupport._key_table.setdefault(keys, keys)
        self.values = tuple(typed(support[k]) for k in keys)
        self.fp = hash(self.values)

    def matches(self, current_values):
        """current_values: tuple of typed current reads in self.keys order."""
        if hash(current_values) != self.fp:
            return False
        return current_values == self.values          # exact confirmation, collision-safe


class CollidingTyped(tuple):
    """Test helper: distinct values with forced equal hashes."""
    def __hash__(self):
        return 42


# ------------------------------------------------------------------ L03
_TABLE = None


def _table():
    global _TABLE
    if _TABLE is None:
        t = []
        for c in range(256):
            t.append([(x * c + 255 * (255 - c) + 127) // 255 for x in range(256)])
        _TABLE = t
    return _TABLE


def normalize_lut(value):
    if not isinstance(value, int) or not 0 <= value <= 0xffffffff:
        raise ValueError('feature value must be an unsigned 32-bit integer')
    row = _table()[value >> 24]
    return (row[(value >> 16) & 255], row[(value >> 8) & 255], row[value & 255])


def score_lut(first, second, COUNT=50):
    if len(first) != COUNT or len(second) != COUNT:
        raise ValueError('exactly 50 feature values per witness required')
    tab = _table()
    left, right, total = [], [], 0
    for x, y in zip(first, second):
        if not isinstance(x, int) or not 0 <= x <= 0xffffffff or not isinstance(y, int) or not 0 <= y <= 0xffffffff:
            raise ValueError('feature value must be an unsigned 32-bit integer')
        rx, ry = tab[x >> 24], tab[y >> 24]
        a = (rx[(x >> 16) & 255], rx[(x >> 8) & 255], rx[x & 255])
        b = (ry[(y >> 16) & 255], ry[(y >> 8) & 255], ry[y & 255])
        left.append(a)
        right.append(b)
        total += abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])
        if total >= 30 * COUNT:
            return None
    if all(sum(min(v) > 220 for v in side) >= COUNT * 0.8 for side in (left, right)):
        return None
    if all(sum(max(v) < 50 for v in side) >= COUNT * 0.8 for side in (left, right)):
        return None
    # identical expression order to OPTIMIZED_OPERATOR._variance (binary64)
    def var(features):
        values = [0.299 * f[0] + 0.587 * f[1] + 0.114 * f[2] for f in features]
        mean = sum(values) / COUNT
        return sum(z * z for z in values) / COUNT - mean * mean
    if var(left) < 100 and var(right) < 100:
        return None
    return float(total) / COUNT


# ------------------------------------------------------------------ L05
class StaleView(Exception):
    pass


class OwnerView:
    """Clone-free, read-only, version-checked view of an Owner's admitted evidence.
    Reads return immutable compact fingerprints; any owner write after creation
    makes every later read raise StaleView (no silently stale answers)."""

    def __init__(self, owner):
        self._owner = owner
        self._rev = owner._revision
        self._epoch = owner._identity_epoch
        self._index = owner._index()

    def _check(self):
        if self._owner._closed or self._owner._revision != self._rev or self._owner._identity_epoch != self._epoch:
            raise StaleView()

    def analysis(self, i):
        self._check()
        return self._index.analysis(i)

    def edge(self, a):
        self._check()
        return self._index.edge(a, a + 1)

    def __len__(self):
        self._check()
        return self._index.n
