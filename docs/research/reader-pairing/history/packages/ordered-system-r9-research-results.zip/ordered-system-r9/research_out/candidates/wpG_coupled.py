"""Run WP-G session mechanisms through the coupled runner (incumbent L0 policy)."""
import paths  # noqa: F401
import coupled_runner as CR
from wpG_session import GSession


class VersionedWorld(CR.World):
    """Each fresh extraction of the same content carries a new evidence version
    (identical analysis fact); models re-acquisition after raw eviction."""
    def __init__(self, witnesses):
        super().__init__(witnesses)
        self._calls = {}

    def complete(self, ordinal):
        w = super().complete(ordinal)
        k = self._calls[ordinal] = self._calls.get(ordinal, 0) + 1
        a = dict(w.analysis)
        if a.get('status') == 'computed':
            a['version'] = k
        return CR.Witness(a, w.raw, w.available)


class GRunner(CR.Runner):
    def __init__(self, trace, *, session_kw=None, capacity=3, raw_capacity=3, versioned=False, **kw):
        super().__init__(trace, capacity=capacity, raw_capacity=raw_capacity, **kw)
        self.session = GSession(trace['initial'], capacity=capacity, raw_capacity=raw_capacity,
                                **(session_kw or {}))
        if versioned:
            self.world = VersionedWorld([CR.Witness(**w) for w in trace['world']])


def run(trace, session_kw=None, policy='incumbent', service_u=3, capacity=3, raw_capacity=3, confirm=False, horizon=20000,
        versioned=False):
    r = GRunner(trace, session_kw=session_kw, policy=policy, service_u=service_u, capacity=capacity,
                raw_capacity=raw_capacity, versioned=versioned)
    out = r.run(horizon=horizon)
    out['horizon_hit'] = bool(r.q)
    m = r.session.metrics
    out.update(raw_evictions=m['raw_evictions'], raw_dead_evictions=m['raw_dead_evictions'],
               peak_raw=m['peak_raw'], certs_live=len(r.session._certs), certs_collected=m['certs_collected'],
               reissued=m['reissued_publications'], revoked=m['revoked_publications'],
               published_now=len(r.session.published),
               engine_runs=r.session.owner.metrics['engine_runs'], memo_hits=r.session.owner.metrics['memo_hits'])
    return out
