"""B01/D04 equivalence campaigns: BlockSummary vs exact DP (with item/edge updates); SigOwner vs reference L0."""
import sys,random,copy,os,json
os.chdir(os.path.dirname(os.path.abspath(__file__))+"/.."); sys.path.insert(0,"candidates"); import paths
RES_B={}
from common import *
import omega as O, transducer as T, wpB_blocks as WB
rng=random.Random(5); bad=0; tot=0; contra=0
for k in range(int(sys.argv[1])):
    n=rng.randrange(1,20)
    c=roundtrip(random_case(rng,n,p_unknown=0.3,p_edge_unknown=0.3,p_fail=0.03))
    alpha=rng.random()<.5; dom=rng.choice(('ext','nonneg'))
    bs=WB.BlockSummary(copy.deepcopy(c),dom,alpha,block=rng.choice((1,2,3,5,8)))
    for t in range(n):
        a=O.certify_exact(c,t,dom if T.Facts(c,'omega',dom,alpha).domain_ok else 'ext',alpha); b=bs.certify(t); tot+=1
        if b[0]=='contradiction': contra+=1
        if (a[0]=='certified')!=(b[0]=='certified') or (a[0]=='certified' and a[1]!=b[1]): bad+=1
    # updates
    for u in range(3):
        p=rng.randrange(n); it=copy.deepcopy(c['items'][p])
        it['analysis']=rng.choice([{'status':'unknown'},dict(status='computed',fact=fact(it['header']['state'] if it.get('header') else 'NARROW',rng.choice(SIDES)),version=u+3)])
        c['items'][p]=it; bs.update(items={p:copy.deepcopy(it)})
        if n>1:
            a_=rng.randrange(n-1); rec=rng.choice([None,dict(status='computed',score=rng.choice((None,0,1,2,5)),version=9)])
            c['edges']=[e for e in c['edges'] if e['first']!=a_]+([dict(rec,first=a_,second=a_+1)] if rec else [])
            bs.update(edges={a_:copy.deepcopy(rec)})
        for t in range(n):
            a=O.certify_exact(c,t,dom if T.Facts(c,'omega',dom,alpha).domain_ok else 'ext',alpha); b=bs.certify(t); tot+=1
            if (a[0]=='certified')!=(b[0]=='certified') or (a[0]=='certified' and a[1]!=b[1]): bad+=1
RES_B['B01_blocks_vs_exact']=dict(cases=int(sys.argv[1]),checks=tot,mismatch=bad,contradiction=contra)
import wpB_sigmemo as SG
rng=random.Random(18); res={'SigOwner':[0,0,0],'SigMutantNoOrder':[0,0,0]}
for _ in range(int(sys.argv[2])):
    n=rng.randrange(3,16); c=roundtrip(random_case(rng,n,p_unknown=.15,p_edge_unknown=.2,domain='G0'))
    ow={'SigOwner':SG.SigOwner(c),'SigMutantNoOrder':SG.SigMutantNoOrder(c)}; cur=copy.deepcopy(c)
    for step in range(6):
        for t in [rng.randrange(n) for _ in range(3)]:
            want={k:v for k,v in ref.certify_strategy(cur,t)['selected'].items() if k!='reads'}
            for k,o in ow.items():
                res[k][0]+=1; res[k][1]+= o.request(t)!=want
        upd={}
        for e in cur['edges']:
            if e.get('status')=='computed' and e.get('score') is not None:
                e['score']=rng.randrange(0,1500)/50; upd[(e['first'],e['second'])]=copy.deepcopy(e)
        for o in ow.values(): o.apply(edge_updates=upd)
    for k,o in ow.items(): res[k][2]+=o.metrics['signature_hits']
RES_B['D04_signature_memo']={k:dict(requests=v[0],wrong=v[1],signature_hits=v[2]) for k,v in res.items()}
RES_B['command']='python3 research_out/bench/run_wpB_equiv.py '+' '.join(sys.argv[1:])
json.dump(RES_B,open('results/raw/wpB/equiv.json','w'),indent=1); print(json.dumps(RES_B))
