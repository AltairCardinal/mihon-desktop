"""WP-G owner variants (L0: every public field identical to corrected_owner.Owner).

GOwner(case, config, *, support='union'|'fact', barrier='global'|'posrev',
       noop='typed'|'none'|'hint', instrument=True)

support='fact'   R_policy compression G01: drop derived `dimension` keys.  The
                 dimension fingerprint is a pure function of the analysis key
                 (computed) or analysis+header keys (not computed) that the same
                 attempt always records (proof wpG.md L-G1), so validation over
                 the remaining keys is equivalent to validation over the union.
barrier='posrev' G03: dense per-position last-change revision list; a memo
                 entry stores the positions its support reads; the entry is
                 reused without typed comparison iff no such position changed
                 since its stamp.  Identity/settings guard unchanged.
noop='none'      G04: no typed same-value detection on delta writes; every
                 supplied record counts as a change (revision bump, dirty).
noop='hint'      G04: producer passes `same=set(...)` of keys it knows are
                 unchanged; only those skip the bump (producer contract).
instrument=False L06: metrics updates replaced by a no-op counter.
"""
from collections import Counter, OrderedDict
from copy import deepcopy

import paths  # noqa: F401
import compact_core as core
from corrected_owner import Owner, Config, SAT, public, _UNSET
from current_baseline import typed


def _valid_fact(f, ident):
    return f is not None and core._geometry_t(f) and f[3] == ident[2] and f[4] == ident[3]


def project(key, value, ident):
    """Decision-relevant projection of a typed read (G01 'proj' support).

    compact_core.certify and reference._Scan consume a read only through:
      analysis -> status; computed: geometry validity w.r.t. identity, state, side;
                  failed: reason
      header   -> validity, state (FAILED state yields the READ failure)
      rank     -> unknown | computed numeric value (None = null) | failed failures
    Versions, widths/heights that keep validity and state, and int/float type tags
    of equal numbers are never observed by the scan or by any public field
    (proof wpG.md L-G2).  dimension keys are derived and dropped (L-G1)."""
    kind = key[0]
    if kind == 'analysis':
        if value[0] == 'computed':
            f = value[1]
            return ('c', _valid_fact(f, ident), f[0] if f else None, f[5] if f else None)
        if value[0] == 'failed':
            return ('f', value[1])
        return ('u',)
    if kind == 'header':
        return ('h', _valid_fact(value, ident), value[0] if value else None)
    if kind == 'rank':
        if value[0] == 'computed':
            return ('c', 'null') if value[1] is None else ('c', 'v', value[1])
        if value[0] == 'failed':
            return ('f', value[1])
        return value[:1] if value[0] == 'unknown' else value
    return None


class NullCounter(dict):
    def __getitem__(self, k):
        return 0

    def __setitem__(self, k, v):
        pass


class GOwner(Owner):
    def __init__(self, case, config=Config(), *, support='union', barrier='global', noop='typed',
                 instrument=True):
        self.support_mode, self.barrier, self.noop = support, barrier, noop
        self._posrev = []
        super().__init__(case, config)
        if not instrument:
            self.metrics = NullCounter()

    # ---------------------------------------------------------- lifecycle
    def replace(self, case):
        super().replace(case)
        self._posrev = [self._revision] * len(self._case['items'])

    # ---------------------------------------------------------- writes
    def apply(self, *, item_updates=None, edge_updates=None, settings=None,
              generation=_UNSET, order_revision=_UNSET, same=None):
        self._open()
        items, edges = {}, {}
        n = len(self._case['items'])
        for i, patch in (item_updates or {}).items():
            if type(i) is not int or not 0 <= i < n:
                raise ValueError('invalid item ordinal')
            item = dict(self._case['items'][i])
            item.update(deepcopy(patch))
            items[i] = item
        for key, value in (edge_updates or {}).items():
            if (len(key) != 2 or any(type(i) is not int for i in key)
                    or not 0 <= key[0] < key[1] < n):
                raise ValueError('invalid edge ordinals')
            edges[key] = dict(deepcopy(value), first=key[0], second=key[1]) if value is not None else None
        next_settings = dict(self._case.get('settings', {}))
        if settings is not None:
            next_settings.update(deepcopy(settings))
        probe = core.Index({'items': [], 'settings': next_settings}, check_ids=False)
        settings_key = core._settings_key(probe.settings)
        identity_change = False
        staged_ids = {}
        removed_ids = {self._identities[i][0] for i in items}
        for i, x in items.items():
            ident = (x.get('id', str(i)), x.get('content_version', 0),
                     x.get('rotation', 0), x.get('orientation', 1))
            item_id = ident[0]
            if item_id in staged_ids or (item_id in self._ids and item_id not in removed_ids):
                raise ValueError('item ids must be unique')
            staged_ids[item_id] = i
            identity_change |= typed(ident) != typed(self._identities[i])
        same = same or set()
        if self.noop == 'typed':
            changed_items = {i: x for i, x in items.items() if typed(x) != typed(self._case['items'][i])}
            changed_edges = {k: x for k, x in edges.items() if typed(x) != typed(self._edges.get(k))}
        elif self.noop == 'hint':
            changed_items = {i: x for i, x in items.items() if ('item', i) not in same}
            changed_edges = {k: x for k, x in edges.items() if ('edge', k) not in same}
        else:
            changed_items, changed_edges = dict(items), dict(edges)
        global_change = any(v is not _UNSET and typed(v) != typed(self._case.get(k, 0))
                            for k, v in (('generation', generation), ('order_revision', order_revision)))
        changed_settings = typed(settings_key) != typed(self._settings)
        changed = bool(changed_items or changed_edges or global_change or changed_settings)
        for item_id in removed_ids:
            del self._ids[item_id]
        self._ids.update(staged_ids)
        # with noop='hint' a wrong hint is a producer-contract violation; we still
        # store the supplied record so the owner never holds stale content.
        for i, x in items.items():
            self._case['items'][i] = x
            self._identities[i] = (x.get('id', str(i)), x.get('content_version', 0),
                                   x.get('rotation', 0), x.get('orientation', 1))
        for key, value in edges.items():
            if value is None:
                if key in self._edges:
                    self._case['edges'] = [e for e in self._case['edges'] if (e['first'], e['second']) != key]
                    self._edge_positions = {(e['first'], e['second']): p for p, e in enumerate(self._case['edges'])}
                    self._edges.pop(key, None)
                    self.metrics['edge_rebuild_slots'] += len(self._case['edges'])
            else:
                if key in self._edge_positions:
                    self._case['edges'][self._edge_positions[key]] = value
                else:
                    self._edge_positions[key] = len(self._case['edges'])
                    self._case['edges'].append(value)
                self._edges[key] = value
        if settings is not None:
            self._case['settings'] = next_settings
        self._settings = settings_key
        for k, v in (('generation', generation), ('order_revision', order_revision)):
            if v is not _UNSET:
                self._case[k] = deepcopy(v)
        if identity_change or global_change or changed_settings:
            self._identity_epoch = min(SAT, self._identity_epoch + 1)
            self._identity_ticket = object()
            self._memo.clear()
        if changed:
            self._revision = min(SAT, self._revision + 1)
            for i in changed_items:
                self._posrev[i] = self._revision
            for (a, b) in changed_edges:
                if 0 <= a < len(self._posrev):
                    self._posrev[a] = self._revision
        self.metrics['delta_calls'] += 1
        self.metrics['delta_item_slots'] += len(items)
        self.metrics['delta_edge_slots'] += len(edges)
        return changed

    # ---------------------------------------------------------- validation
    def _valid(self, entry, index):
        if entry['guard'] != self._guard() or self._case.get('closed', False):
            return False
        if self.config.stamps and self._revision < SAT and entry['stamp'] == self._revision:
            self.metrics['stamp_hits'] += 1
            return True
        if self.barrier == 'posrev' and self._revision < SAT:
            st = entry['stamp']
            pr = self._posrev
            self.metrics['posrev_checks'] += len(entry['positions'])
            if all(pr[p] <= st for p in entry['positions']):
                self.metrics['posrev_hits'] += 1
                entry['stamp'] = self._revision
                return True
        self.metrics['support_validations'] += 1
        if self.support_mode == 'proj':
            ids = self._identities
            fresh = {}
            for key, old in entry['support'].items():
                self.metrics['typed_reads_checked'] += 1
                cur = self._read(index, key)
                if old != project(key, cur, ids[key[1]]):
                    return False
                fresh[key] = cur
            # Lemma L-G3: equal projections => the recomputation reads exactly these keys,
            # so the exact (publication) support for the current evidence is these current reads.
            if 'exact' in entry:
                for key in entry['exact']:
                    if key[0] == 'dimension':
                        fresh[key] = self._read(index, key)
                entry['exact'] = fresh
        else:
            for key, old in entry['support'].items():
                self.metrics['typed_reads_checked'] += 1
                if typed(old) != typed(self._read(index, key)):
                    return False
        entry['stamp'] = self._revision
        return True

    def request(self, target):
        self._open()
        if type(target) is not int or not 0 <= target < len(self._case['items']):
            raise ValueError('invalid target ordinal')
        self.metrics['requests'] += 1
        index = self._index()
        entry = self._memo.get(target)
        if entry and self._valid(entry, index):
            self.metrics['memo_hits'] += 1
            self._memo.move_to_end(target)
            return public(entry['result'])
        self.metrics['engine_runs'] += 1
        baseline = core.certify(self._case, target, 2, index=index)
        attempts, selected = [baseline], baseline
        if baseline['status'] == 'need_facts':
            retry = core.certify(self._case, target, 3, index=index)
            attempts.append(retry)
            self.metrics['retries'] += 1
            if retry['status'] == 'certified':
                selected = retry
        support = {}
        for attempt in attempts:
            support.update(attempt['proof'][2])
        full = len(support)
        if self.support_mode == 'fact':
            support = {k: v for k, v in support.items() if k[0] != 'dimension'}
        elif self.support_mode == 'proj':
            ids = self._identities
            exact = dict(support)
            support = {k: project(k, v, ids[k[1]]) for k, v in support.items() if k[0] != 'dimension'}
        self.metrics['scan_steps'] += sum(a['steps'] for a in attempts)
        self.metrics['support_keys_built'] += len(support)
        self.metrics['support_keys_dropped'] += full - len(support)
        self._memo.pop(target, None)
        if (self.config.memo and len(self._case['items']) <= self.config.max_order
                and full + 2 <= self.config.max_reads):
            positions = None
            if self.barrier == 'posrev':
                ps = set()
                for k in support:
                    ps.add(k[1])
                    if k[0] == 'rank':
                        ps.add(k[2])
                positions = tuple(sorted(ps))
            self._memo[target] = dict(guard=self._guard(), stamp=self._revision,
                                      result=selected, support=support, positions=positions)
            if self.support_mode == 'proj':
                self._memo[target]['exact'] = exact
            while len(self._memo) > self.config.memo_capacity:
                self._memo.popitem(last=False)
                self.metrics['memo_evictions'] += 1
        elif self.config.memo:
            self.metrics['storage_bypasses'] += 1
        return public(selected)


def make(name, case, config=Config()):
    table = {
        'incumbent': lambda: Owner(case, config),
        'fact_support': lambda: GOwner(case, config, support='fact'),
        'posrev': lambda: GOwner(case, config, barrier='posrev'),
        'posrev_fact': lambda: GOwner(case, config, support='fact', barrier='posrev'),
        'noop_none': lambda: GOwner(case, config, noop='none'),
        'noop_hint': lambda: GOwner(case, config, noop='hint'),
        'no_instrument': lambda: GOwner(case, config, instrument=False),
        'proj_support': lambda: GOwner(case, config, support='proj'),
        'proj_posrev': lambda: GOwner(case, config, support='proj', barrier='posrev'),
    }
    return table[name]()
