"""E1/E3/E5: the verified G0 witness-derivation subprocess, implemented exactly
from GENERATIVE_DOMAIN.md, plus a constructive realizer for rank sequences.

Pipeline per object: tensor (w x h x 4 channels, 4th = coverage) -> L/R column
samples (50 rows) -> normalisation N(c,a) -> L1 distance /50 -> filters -> rank.
Rotation 0 only (the inverse coordinate map is the identity); this keeps the
claims inside the verified sub-process.
"""
import math
import random

U = 255
K = 50


def N(c, a):
    return (c * a + U * (U - a) + 127) // U


def sample_positions(w, h):
    if w > h:
        return None                     # oriented w>h produces no edge samples
    left, right = min(2, w - 1), max(0, w - 3)
    rows = [(k * h) // K for k in range(K)]
    return left, right, rows


def sample(tensor, w, h):
    """tensor[x][y] = (c1, c2, c3, a).  Returns (L, R) as lists of 50 (c1,c2,c3,a)."""
    pos = sample_positions(w, h)
    if pos is None:
        return None
    left, right, rows = pos
    return [tensor[left][y] for y in rows], [tensor[right][y] for y in rows]


def normalise(vec):
    return [(N(c1, a), N(c2, a), N(c3, a)) for (c1, c2, c3, a) in vec]


def l1_m(X, Y):
    """Integer m with d = m/50 (exact)."""
    return sum(abs(x - y) for xe, ye in zip(X, Y) for x, y in zip(xe, ye))


def _upper(V):
    return sum(1 for e in V if min(e) > 220) >= 40


def _lower(V):
    return sum(1 for e in V if max(e) < 50) >= 40


def _var(V):
    p = [0.299 * e[0] + 0.587 * e[1] + 0.114 * e[2] for e in V]
    mu = sum(p) / len(p)
    return sum((x - mu) ** 2 for x in p) / len(p)


def rank(Xraw, Yraw):
    """G0 rank of an ordered vector pair: m/50 or None (known null)."""
    X, Y = normalise(Xraw), normalise(Yraw)
    if (_upper(X) and _upper(Y)) or (_lower(X) and _lower(Y)) or (_var(X) < 100 and _var(Y) < 100):
        return None, 'filter'
    m = l1_m(X, Y)
    if m >= 1500:
        return None, 'far'
    return m / 50, m


def edge_rank(L, R, i, direction='AB'):
    """Rank of edge (i, i+1): AB uses d(R_i, L_{i+1}); BA uses d(L_i, R_{i+1})."""
    if direction == 'AB':
        return rank(R[i], L[i + 1])
    return rank(L[i], R[i + 1])


# --------------------------------------------------------------- construction
def _base_vector(rng):
    """Mid-range, high-variance vector (no filter can trigger on it alone)."""
    v = []
    for k in range(K):
        g = 60 + (k * 37) % 120          # 60..179, spread => projection variance >> 100
        v.append([g, (g + 23) % 120 + 60, (g + 51) % 120 + 60, U])
    return v


def _shift(vec, m, rng):
    """Copy of vec whose normalised L1 distance to vec is exactly m (0<=m<=1500*?).
    Channels stay inside [20, 235] so no saturation filter can trigger."""
    out = [list(e) for e in vec]
    slots = [(k, j) for k in range(K) for j in range(3)]
    rng.shuffle(slots)
    left = m
    for k, j in slots:
        if left == 0:
            break
        c = out[k][j]
        up = 235 - c
        down = c - 20
        d = min(left, max(up, down))
        if up >= down:
            out[k][j] = c + d
        else:
            out[k][j] = c - d
        left -= d
    if left:
        raise ValueError('target distance not reachable')
    return out


def realise_chain(targets, widths, h=60, seed=0, direction='AB'):
    """Build tensors so that edge (i,i+1) has G0 rank targets[i] (value m/50 or
    None).  Returns (tensors, L, R).  None targets are realised by distance >= 30."""
    rng = random.Random(seed)
    n = len(widths)
    L, R = [None] * n, [None] * n
    for i in range(n):
        w = widths[i]
        left, right, _ = sample_positions(w, h)
        same = left == right
        if i == 0:
            base = _base_vector(rng)
            L[0] = base
            R[0] = base if same else _shift(base, rng.randrange(0, 300), rng)
            continue
        t = targets[i - 1]
        m = 1600 if t is None else round(t * 50)
        prev = R[i - 1] if direction == 'AB' else L[i - 1]
        new = _shift(prev, m, rng)
        if direction == 'AB':
            L[i] = new
            R[i] = new if same else _shift(new, rng.randrange(0, 300), rng)
        else:
            R[i] = new
            L[i] = new if same else _shift(new, rng.randrange(0, 300), rng)
    tensors = []
    for i in range(n):
        w = widths[i]
        left, right, rows = sample_positions(w, h)
        filler = [60, 90, 120, U]
        tens = [[list(filler) for _ in range(h)] for _ in range(w)]
        for k, y in enumerate(rows):
            tens[left][y] = list(L[i][k])
            tens[right][y] = list(R[i][k])
        tensors.append(tens)
    return tensors, L, R


def derive_ranks(tensors, widths, h=60, direction='AB'):
    """Independent re-derivation through the full sampling pipeline."""
    Ls, Rs = [], []
    for tens, w in zip(tensors, widths):
        s = sample(tens, w, h)
        Ls.append(s[0])
        Rs.append(s[1])
    return [edge_rank(Ls, Rs, i, direction)[0] for i in range(len(widths) - 1)]


# ------------------------------------------------------------------- E5 bounds
def progressive_compare(X, Y, Z, W, order=None, step=5):
    """Decide d(X,Y) < d(Z,W) (normalised vectors) by processing elements in
    blocks; sound interval bounds per pair: partial sum S_k <= m <= S_k + 765*(50-k)
    (each remaining element contributes 0..3*255).  Returns (decision, elements_used)
    or (None, 50) when undecidable before full precision (exact fallback)."""
    order = order or list(range(K))
    s1 = s2 = 0
    for done in range(0, K, step):
        for k in order[done:done + step]:
            s1 += sum(abs(a - b) for a, b in zip(X[k], Y[k]))
            s2 += sum(abs(a - b) for a, b in zip(Z[k], W[k]))
        rem = K - min(K, done + step)
        lo1, hi1 = s1, s1 + 765 * rem
        lo2, hi2 = s2, s2 + 765 * rem
        if hi1 < lo2:
            return True, min(K, done + step)
        if lo1 >= hi2:
            return False, min(K, done + step)
    return s1 < s2, K


def subsample_estimate_compare(X, Y, Z, W, stride=5):
    """Unsound 'multi-level witness' shortcut: compare distances on a subsample.
    Kept only as a refuted route (E5 route 2)."""
    a = sum(abs(p - q) for k in range(0, K, stride) for p, q in zip(X[k], Y[k]))
    b = sum(abs(p - q) for k in range(0, K, stride) for p, q in zip(Z[k], W[k]))
    return a < b


def early_null_elements(Xn, Yn):
    """Elements (in index order) after which a pair is PROVABLY a known null by
    distance (partial L1 >= 1500), or None if it never is.  Sound: partial sums
    only grow.  (Filters need their own bounds; variance lower bound
    var_total >= (k/50) * var_partial lets the 'no variance filter' side stop
    early, but a filter *trigger* needs all 50 elements.)"""
    s = 0
    for k in range(K):
        s += sum(abs(a - b) for a, b in zip(Xn[k], Yn[k]))
        if s >= 1500:
            return k + 1
    return None
