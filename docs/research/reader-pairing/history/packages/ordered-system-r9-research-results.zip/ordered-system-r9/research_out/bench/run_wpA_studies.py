"""WP-A studies (sections selectable): gate budget solvers acq inflight complexity minimax joint islands adapter.
Writes results/summary/wpA/<section>.json."""
import json, math, sys, time, collections, random, copy
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import paths  # noqa
import wpA_lib as A
from strong import strong_attempt
OUT = Path(__file__).resolve().parents[1] / 'results' / 'summary' / 'wpA'


def wilson(k, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (round(max(0, c - h), 3), round(min(1, c + h), 3))


def sec_gate():
    """A02: label every L0 need_facts verdict met on the incumbent path with the
    (evaluation-only) strong outcome; compare gates on observable features."""
    res = {}
    GATES = {
        'none': lambda s, t, v: True,
        'rank_only': A.gate_rank_only,
        'all_analyses': lambda s, t, v: A.window_all_analyses(s, t),
        'single_need': lambda s, t, v: len(v['needs']) == 1,
        'rank_single': lambda s, t, v: len(v['needs']) == 1 and v['needs'][0]['kind'] == 'RANK',
    }
    for setname, fn in (('tuning', A.tuning_traces), ('heldout', A.heldout_traces), ('heldout2', A.heldout2_traces)):
        obs = []
        for tr in fn():
            r = A.ARunner(tr, policy='incumbent', service_u=3)
            sess = r.session
            orig = sess.certify

            def hooked(target, mode='L0', budget=None, _orig=orig, _sess=sess):
                v = _orig(target, mode=mode, budget=budget)
                if mode == 'L0' and v['status'] == 'need_facts':
                    att = strong_attempt(_sess.owner._case, target, 'tree', 'nonneg', False, None)
                    ok = att['status'] == 'certified' and att['unit']['certain'] and \
                        A.window_all_analyses(_sess, target)
                    row = dict(trace=tr['name'], target=target, ok=bool(ok), cls=repr(A.feature_class(_sess, target, v)),
                               ns=att['ns'], evaluations=att['evaluations'])
                    for g, gf in GATES.items():
                        row['g_' + g] = bool(gf(_sess, target, v))
                    obs.append(row)
                return v
            sess.certify = hooked
            r.run()
        per = {}
        for g in GATES:
            sel = [o for o in obs if o['g_' + g]]
            k = sum(o['ok'] for o in sel)
            per[g] = dict(attempts=len(sel), successes=k, precision=round(k / len(sel), 3) if sel else None,
                          precision_ci=wilson(k, len(sel)), missed=sum(o['ok'] and not o['g_' + g] for o in obs),
                          wasted=len(sel) - k, mean_ns=round(sum(o['ns'] for o in sel) / len(sel)) if sel else 0)
        cls = collections.defaultdict(lambda: [0, 0])
        for o in obs:
            cls[o['cls']][0] += o['ok']; cls[o['cls']][1] += 1
        res[setname] = dict(need_facts_events=len(obs), successes=sum(o['ok'] for o in obs), gates=per,
                            classes={c: dict(successes=a, n=b, ci=wilson(a, b)) for c, (a, b) in cls.items()})
    return res


class BudgetRunner(A.ARunner):
    """P02: per-observable-class budget doubling (start b0, x2 after each stop, cap)."""
    def __init__(self, *a, b0=20, cap=1000, schedule='double', **kw):
        super().__init__(*a, **kw)
        self.b0, self.cap, self.schedule = b0, cap, schedule
        self.cls_budget = {}

    def _start_proof(self, t, base, cls):
        b = self.cls_budget.get(cls, self.b0)
        self.session.strong['budget'] = b
        before = self.session.metrics['strong_stops']
        super()._start_proof(t, base, cls)
        stopped = self.session.metrics['strong_stops'] > before
        if self.schedule == 'double' and stopped:
            self.cls_budget[cls] = min(self.cap, b * 2)


def sec_budget():
    out = []
    traces = A.tuning_traces() + A.heldout2_traces()
    for label, mk in [('fixed_%s' % b, (lambda tr, b=b: A.ARunner(tr, policy='gated_keep', service_u=4, q_u=1, q_model='eval',
                                                                     q_eval=0.02, strong=dict(budget=b))))
                      for b in (10, 30, 100, 300, None)] + \
                     [('double_10', lambda tr: BudgetRunner(tr, policy='gated_keep', service_u=4, q_u=1, q_model='eval',
                                                           q_eval=0.02, b0=10, cap=1000))]:
        agg = collections.Counter()
        for tr in traces:
            r = mk(tr).run()
            for f in ('total_latency_u', 'physical_admissions', 'strong_attempts', 'strong_certificates', 'strong_stops',
                      'strong_evaluations', 'wrong', 'published', 'intents', 'lane_busy_u'):
                agg[f] += r[f]
        out.append(dict(config=label, **agg))
    return dict(note='gated_keep, service_u=4, proof time = ceil(0.02*evaluations) u; tuning+heldout2', rows=out)


def sec_solvers():
    out = []
    for setname, fn in (('tuning', A.tuning_traces), ('heldout2', A.heldout2_traces)):
        for pol in ('proof_first', 'gated_keep'):
            for kind, pers in (('tree', False), ('exact', False), ('portfolio', False), ('tree', True)):
                agg = collections.Counter()
                for tr in fn():
                    r = A.ARunner(tr, policy=pol, service_u=4, q_u=1, strong=dict(kind=kind), persistent=pers).run()
                    for f in ('total_latency_u', 'physical_admissions', 'strong_attempts', 'strong_certificates',
                              'proof_wins', 'strong_ns', 'wrong'):
                        agg[f] += r[f]
                out.append(dict(set=setname, policy=pol, solver=kind + ('-persistent' if pers else ''), **agg,
                                ns_per_attempt=round(agg['strong_ns'] / max(1, agg['strong_attempts']))))
    return dict(note='service_u=4, q_u=1 fixed per attempt (virtual); ns are local measured Python', rows=out)


def sec_acq():
    out = []
    for setname, fn in (('tuning', A.tuning_traces), ('heldout_pm', lambda: [t for t in A.heldout_traces() if t['name'].startswith('PM')][:2])):
        for pol in ('incumbent', 'gated_keep'):
            for acq in ('all', 'one', 'witness', 'analysis_first'):
                agg = collections.Counter()
                for tr in fn():
                    r = A.ARunner(tr, policy=pol, acq=acq, service_u=4, q_u=1).run()
                    for f in ('total_latency_u', 'physical_admissions', 'rank_computations', 'wrong', 'published',
                              'intents', 'refusals', 'max_latency_u'):
                        agg[f] += r[f]
                out.append(dict(set=setname, policy=pol, acq=acq, **agg))
    return dict(rows=out)


def sec_inflight():
    """F04: the needed endpoints are already in flight (optional prefetch) when the intent arrives."""
    out = []
    for s in range(4):
        tr = A.reserved_eviction(s, n=40, holes=(9,), count_=8, gap=20)
        tr = copy.deepcopy(tr)
        first = tr['events'][0]['at']
        tr['events'] = [dict(at=0, op='prefetch', item=9), dict(at=0, op='prefetch', item=10)] + \
            [dict(e, at=e['at'] + 1) for e in tr['events']]
        for su in (2, 8):
            for pol in ('incumbent', 'proof_first', 'race', 'race_keep', 'when_waiting'):
                r = A.ARunner(tr, policy=pol, service_u=su, q_u=1).run()
                out.append(dict(trace=tr['name'], service_u=su, policy=pol, latency=r['total_latency_u'],
                                admissions=r['physical_admissions'], discarded=r['discarded'], wins=r['proof_wins'],
                                wrong=r['wrong']))
    return dict(rows=out)


def sec_complexity():
    """F05/X17: choosing the next fact by identifiability vs by resulting DP work."""
    import omega as O, relational_exp as X
    from common import random_case, roundtrip
    rng = random.Random(7)
    rows = []
    while len(rows) < 30:
        n = rng.randrange(4, 8)
        c = roundtrip(random_case(rng, n, p_unknown=0.4, p_edge_unknown=0.5, settings_mix=False, domain='nonneg'))
        t = rng.randrange(n)
        if O.certify_exact(c, t, 'nonneg')[0] == 'certified':
            continue
        facts = X.unknown_facts(c, 'nonneg')[:6]
        stats = []
        for h in facts:
            opts = X.options(c, h, 'nonneg')
            cert = evals = 0
            for v in opts:
                cnt = {}
                st, _u = O.certify_exact(X.reveal(c, h, v), t, 'nonneg', counters=cnt)
                cert += st == 'certified'; evals += cnt.get('dp_evals', 0)
            stats.append(dict(fact=h, p_cert=round(cert / len(opts), 3), mean_dp_evals=round(evals / len(opts), 1)))
        if not stats:
            continue
        by_id = max(stats, key=lambda x: (x['p_cert'], -x['mean_dp_evals']))
        by_cost = min(stats, key=lambda x: (x['mean_dp_evals'], -x['p_cert']))
        rows.append(dict(n=n, target=t, facts=len(stats), ident_choice=by_id, cost_choice=by_cost,
                         evals_ratio_max_min=round(max(s['mean_dp_evals'] for s in stats) /
                                                   max(1, min(s['mean_dp_evals'] for s in stats)), 2)))
    same = sum(r['ident_choice']['fact'] == r['cost_choice']['fact'] for r in rows)
    return dict(cases=len(rows), same_choice=same, max_ratio=max(r['evals_ratio_max_min'] for r in rows),
                rows=rows, note='uniform weights over abstract outcome classes; evaluation-only study (no controller)')


def sec_minimax():
    rows = []
    for setname in ('tuning', 'heldout', 'heldout2'):
        raw = [json.loads(l) for l in open(OUT.parents[1] / 'raw' / 'wpA' / f'grid_{setname}.jsonl')]
        cells = collections.defaultdict(dict)
        for r in raw:
            cells[(r['trace'], r['service_u'], r['q_u'])][r['policy']] = r
            if r['policy'] in ('incumbent', 'strong_only'):
                for q in (1, 2, 4, 8):
                    cells[(r['trace'], r['service_u'], q)][r['policy']] = r
        reg = collections.defaultdict(list)
        for key, d in cells.items():
            if 'incumbent' not in d:
                continue
            best_l = min(v['total_latency_u'] for p, v in d.items() if p != 'strong_only')
            best_w = min(v['physical_admissions'] for p, v in d.items() if p != 'strong_only')
            for p, v in d.items():
                if p == 'strong_only':
                    continue
                reg[p].append((v['total_latency_u'] - best_l, v['physical_admissions'] - best_w))
        for p, lst in reg.items():
            rows.append(dict(set=setname, policy=p, cells=len(lst), max_latency_regret=max(a for a, b in lst),
                             mean_latency_regret=round(sum(a for a, b in lst) / len(lst), 2),
                             max_work_regret=max(b for a, b in lst), mean_work_regret=round(sum(b for a, b in lst) / len(lst), 2)))
    return dict(rows=rows, note='regret per (trace, service_u, q_u) cell vs best non-idealised policy in that cell')


def sec_joint():
    out = []
    for s in range(4):
        for base in (A.reserved_eviction(s, n=40, holes=(9,), count_=24), A.decisive_holes(s, n=32, holes=6, kind='chain')):
            tr = copy.deepcopy(base)
            ts = [e['target'] for e in tr['events']]
            tr['events'] = [dict(at=k * 10, op='targets', targets=ts[j:j + 4]) for k, j in enumerate(range(0, len(ts), 4))]
            for pers in (False, True):
                for pol in ('incumbent', 'gated_keep', 'proof_first'):
                    r = A.ARunner(tr, policy=pol, service_u=4, q_u=1, persistent=pers).run()
                    lat = sorted(r['latency_u'].values())
                    out.append(dict(trace=tr['name'], policy=pol, persistent=pers, published=r['published'],
                                    intents=r['intents'], wrong=r['wrong'], total_latency=r['total_latency_u'],
                                    median_latency=lat[len(lat) // 2] if lat else 0, max_latency=r['max_latency_u'],
                                    admissions=r['physical_admissions'], attempts=r['strong_attempts'],
                                    strong_ms=round(r['strong_ns'] / 1e6, 2)))
    return dict(rows=out, note='batches of 4 targets per intent event; first-ready publication per target')


def sec_islands():
    """O05: two fully known islands are not independently composable."""
    import omega as O
    import workloads as W
    from strong import StrongSession
    rows = []
    for seed in range(8):
        tr = W.w02_islands(seed)
        s = StrongSession(tr['initial'], strong=dict(kind='tree', domain='nonneg', gate='sound'))
        n = len(tr['initial']['items'])
        known = [i for i in range(n) if tr['initial']['items'][i]['analysis']['status'] == 'computed']
        l0 = st = 0
        for t in known:
            a = s.certify(t, mode='L0'); b = s.certify(t, mode='S')
            l0 += a['status'] == 'certified'; st += b['status'] == 'certified'
        rows.append(dict(trace=tr['name'], island_targets=len(known), l0_certified=l0, strong_certified=st))
    # minimal counterexample: island 2 unit depends on bridge facts
    from common import base_case, fact
    cex = None
    for n in range(5, 9):
        c = base_case(n, automatic=True)
        c['items'][1]['analysis'] = {'status': 'unknown'}; c['items'][1]['header'] = fact('NARROW')
        c['edges'] = [e for e in c['edges'] if e['first'] not in (0, 1)]
        for e in c['edges']:
            e['score'] = float(n - e['first'])
        for t in range(2, n):
            U = O.oracle_units(c, t, 'nonneg', alpha=False, cap=20000)
            if len(U) > 1:
                cex = dict(case=c, target=t, distinct_units=len(U), note='items 2..n-1 fully known (island), '
                           'bridge = item 1 analysis + edges (0,1),(1,2) unknown; target unit differs by bridge completion')
                break
        if cex:
            break
    return dict(rows=rows, counterexample=cex)


def sec_adapter():
    """O06: overhead of the S adapter where it never triggers and per need_facts call."""
    import workloads as W
    from strong import StrongSession
    rows = []
    for fam in ('W05', 'RP', 'W01'):
        tr = W.FAMILIES[fam](0)
        n = len(tr['initial']['items'])
        for mode in ('L0', 'S'):
            s = StrongSession(tr['initial'])
            t0 = time.perf_counter_ns()
            for rep in range(5):
                for t in range(n):
                    s.certify(t, mode=mode)
            rows.append(dict(trace=tr['name'], mode=mode, wall_ms=round((time.perf_counter_ns() - t0) / 1e6, 2),
                             strong_attempts=s.metrics['strong_attempts'], certs=s.metrics['strong_certificates']))
    return dict(rows=rows, note='single process local timing, 5 sweeps; interface: certify(target, mode="S") '
                                'returns the L0 verdict unchanged unless need_facts and a gated strong proof exists')





def sec_x01():
    """X01: proof race (A=race_keep) x critical-path admission (B=newest-first pending order),
    two combination organisations: parallel race + priority (A+B), staged 'prove only when blocked' (A|B)."""
    out = []
    cfgs = {'0': dict(policy='incumbent', order='fifo'), 'A': dict(policy='gated_keep', order='fifo'),
            'B': dict(policy='incumbent', order='lifo'), 'A+B': dict(policy='gated_keep', order='lifo'),
            'A|B_staged': dict(policy='gated_keep', order='lifo', proof_when_blocked=True)}
    for setname, fn in (('tuning', A.tuning_traces), ('heldout2', A.heldout2_traces)):
        for cap in (1, 2):
            for q in (1, 4):
                for name, cfg in cfgs.items():
                    agg = collections.Counter()
                    for tr in fn():
                        r = A.ARunner(tr, service_u=4, q_u=q, capacity=cap, **cfg).run()
                        for f in ('total_latency_u', 'max_latency_u', 'physical_admissions', 'discarded', 'refusals',
                                  'strong_attempts', 'proof_wins', 'wrong', 'published', 'intents'):
                            agg[f] += r[f] if f != 'max_latency_u' else 0
                        agg['max_latency_u'] = max(agg['max_latency_u'], r['max_latency_u'])
                    out.append(dict(set=setname, capacity=cap, q_u=q, group=name, **agg))
    return dict(rows=out, note='service_u=4')


def sec_x15():
    out = []
    groups = {'0': 'all', 'A_single_fact': 'one', 'B_witness_cover': 'witness', 'A+B_single_best_witness': 'one_witness'}
    for setname, fn in (('tuning', A.tuning_traces),
                        ('heldout_pm', lambda: [t for t in A.heldout_traces() if t['name'].startswith('PM')][:2])):
        for g, acq in groups.items():
            agg = collections.Counter()
            for tr in fn():
                r = A.ARunner(tr, policy='incumbent', acq=acq, service_u=4).run()
                for f in ('total_latency_u', 'physical_admissions', 'rank_computations', 'wrong', 'published', 'intents'):
                    agg[f] += r[f]
                agg['livelock'] += int(r['livelock'])
            out.append(dict(set=setname, group=g, acq=acq, **agg))
    return dict(rows=out, note='incumbent certifier, service_u=4; organisation 1 = one best witness per round, '
                               'organisation 2 = full witness cover per round')


def sec_x21():
    """X21: joint batch proof x cross-version composition with a rebind in the middle of batches."""
    out = []
    for s in range(4):
        base = A.reserved_eviction(s, n=40, holes=(9,), count_=24)
        tr = copy.deepcopy(base)
        ts = [e['target'] for e in tr['events']]
        tr['events'] = [dict(at=k * 10, op='targets', targets=ts[j:j + 4]) for k, j in enumerate(range(0, len(ts), 4))]
        w = copy.deepcopy(tr['world'][12]); w['raw'] += 1000
        tr['events'].append(dict(at=25, op='rebind', item=12, witness=w))
        tr['events'].sort(key=lambda e: e['at'])
        for name, pol, pers in (('0_independent', 'incumbent', False), ('A_batch_shared_tree', 'gated_keep', True),
                                ('B_independent_strong', 'gated_keep', False), ('A+B', 'gated_keep', True)):
            r = A.ARunner(tr, policy=pol, service_u=4, q_u=1, persistent=pers).run()
            out.append(dict(trace=tr['name'], group=name, wrong=r['wrong'], published=r['published'], intents=r['intents'],
                            publish_rejects=r['publish_rejects'], republished=r.get('republished', 0),
                            total_latency=r['total_latency_u'], admissions=r['physical_admissions'],
                            strong_ms=round(r['strong_ns'] / 1e6, 2), rebinds=r['rebinds']))
    return dict(rows=out, note='A and A+B share one persistent tree across the batch; every publication is '
                               'revalidated against current support (stale certificates are refused)')




SECTIONS = dict(gate=sec_gate, budget=sec_budget, solvers=sec_solvers, acq=sec_acq, inflight=sec_inflight,
                complexity=sec_complexity, minimax=sec_minimax, joint=sec_joint, islands=sec_islands, adapter=sec_adapter,
                x01=sec_x01, x15=sec_x15, x21=sec_x21)

if __name__ == '__main__':
    for name in sys.argv[1:]:
        t0 = time.time()
        res = SECTIONS[name]()
        res['seconds'] = round(time.time() - t0, 1)
        (OUT / f'{name}.json').write_text(json.dumps(res, indent=1, default=str))
        print(name, 'done', res['seconds'], 's')
