"""S family (L2, separate from the frozen rule): alternative partition rules,
their structural metrics, disagreement motifs and adjudication counts.

Nothing here is an equivalence claim.  All rules use the frozen _Scan
predicates (allowed / strength / side / reasons) so that legality constraints
(WIDE, isolates, pins, opening, sides) are identical; only the pairing choice
differs.
  reference   frozen complete_plan
  lmp         round-8 local-maxima + parity passes (radius ~4 edges + pin runs)
  maxcard     maximum-cardinality matching on allowed edges, ties broken by
              (strength sum, rank preference, leftmost)   [global objective]
  seg(L)      reference scan restarted at absolute multiples of L (opening=False)
  anchor      reference scan restarted at every non-allowed boundary and at every
              strict local rank maximum (content anchored)
"""
import copy
import random
from functools import lru_cache

import paths  # noqa: F401
import reference as ref
from theory_h import lmp_plan, plan_members


def _scan(case):
    data = ref._Input(case)
    n = len(data.items)

    def dim(i):
        return data.effective(i)

    def side(i):
        f = dim(i)
        return f['side'] if f else 'UNKNOWN'

    def rank(a, b):
        e = data.edge(a, b)
        return e.get('score') if e['status'] == 'computed' else None
    return ref._Scan(n, data.settings, dim, side, side, rank), n, rank


def _single(sc, i, n, opening=False):
    unit, _ = sc.step((i, opening, -1), include_single=True, include_pair=False)
    return unit


def _assemble(sc, n, pairs):
    units, i = [], 0
    while i < n:
        if i in pairs:
            units.append(dict(slots=[dict(item=i, slot=sc.leading), dict(item=i + 1, slot=sc.trailing)],
                              certain=sc.known(i) and sc.known(i + 1), reason=None))
            i += 2
        else:
            u = _single(sc, i, n)
            if u is None:
                u = dict(slots=[dict(item=i, slot='ALL')], certain=sc.known(i), reason='UNRESOLVED')
            units.append(u)
            i += 1
    return units


def maxcard_plan(case):
    sc, n, rank = _scan(case)
    allowed = [sc.allowed(i) for i in range(n - 1)]

    def w(i):
        r = rank(i, i + 1)
        return (1, sc.strength(i), 0 if r is None else 1, -(r if isinstance(r, (int, float)) else 0))

    # DP over positions: best (score tuple, pairs) choosing non-adjacent allowed edges
    best = [((0, 0, 0, 0), ())] * (n + 2)
    for i in range(n - 2, -1, -1):
        skip = best[i + 1]
        cand = skip
        if allowed[i]:
            sc2, pr = best[i + 2]
            wi = w(i)
            take = (tuple(a + b for a, b in zip(sc2, wi)), (i,) + pr)
            if take[0] > skip[0] or (take[0] == skip[0] and take[1] < skip[1]):
                cand = take
        best[i] = cand
    return _assemble(sc, n, set(best[0][1]))


def restart_plan(case, restarts):
    """Reference scan, but the cursor is reset to a fresh normal state at every
    position in `restarts` that the scan reaches as a boundary."""
    sc, n, _ = _scan(case)
    out, cur = [], (0, True, -1)
    while cur[0] < n:
        i = cur[0]
        if i in restarts and i > 0:
            cur = (i, False, -1)
        unit, cur = sc.step(cur)
        out.append(unit)
    return out


def seg_plan(case, L):
    n = len(case['items'])
    return restart_plan(case, set(range(L, n, L)))


def anchor_plan(case):
    sc, n, rank = _scan(case)
    rs = set()
    for i in range(1, n):
        if not sc.allowed(i - 1):
            rs.add(i)
    for i in range(1, n - 2):
        a, b, c = rank(i - 1, i), rank(i, i + 1), rank(i + 1, i + 2)
        if all(isinstance(x, (int, float)) for x in (a, b, c)) and b > a and b > c:
            rs.add(i + 1)
    return restart_plan(case, rs)


RULES = {
    'reference': ref.complete_plan,
    'lmp': lmp_plan,
    'maxcard': maxcard_plan,
    'seg8': lambda c: seg_plan(c, 8),
    'seg16': lambda c: seg_plan(c, 16),
    'anchor': anchor_plan,
}


def legal(plan, n):
    m = plan_members(plan)
    return sorted(m) == list(range(n)) and all(len(u['slots']) in (1, 2) for u in plan)


def metrics(plan, case):
    sc, n, rank = _scan(case)
    pairs = [u for u in plan if len(u['slots']) == 2]
    allowed = sum(sc.allowed(i) for i in range(n - 1))
    strength = sum(sc.strength(u['slots'][0]['item']) for u in pairs)
    unmatched_allowed = sum(1 for i in range(n - 1) if sc.allowed(i)
                            and all(len(u['slots']) == 1 for u in plan
                                    if any(s['item'] in (i, i + 1) for s in u['slots'])))
    ranks = [rank(u['slots'][0]['item'], u['slots'][1]['item']) for u in pairs]
    rk = [r for r in ranks if isinstance(r, (int, float))]
    return dict(pairs=len(pairs), singles=len(plan) - len(pairs), allowed_edges=allowed, strength=strength,
                maximal=unmatched_allowed == 0, mean_pair_rank=(sum(rk) / len(rk)) if rk else None)


def edit_radius(rule, case, rng, trials=40):
    n = len(case['items'])
    worst = 0
    for _ in range(trials):
        d = copy.deepcopy(case)
        a = rng.randrange(n - 1)
        for e in d['edges']:
            if e['first'] == a:
                e['score'] = rng.randrange(0, 1500) / 50
        m0, m1 = plan_members(rule(case)), plan_members(rule(d))
        ch = [i for i in range(n) if m0[i] != m1[i]]
        worst = max(worst, max((abs(i - a) for i in ch), default=0))
    return worst


def insertion_relabel(rule, case):
    """Fraction of items (after the insertion point) whose partner changes when a
    neutral WIDE item is inserted at the front (order change -> new context)."""
    d = copy.deepcopy(case)
    w = copy.deepcopy(d['items'][0])
    w['id'] = 'ins'
    w['analysis'] = dict(status='computed', fact=dict(state='WIDE', width=200, height=200, rotation=0,
                                                      orientation=1, side='UNKNOWN'), version=1)
    w['header'] = dict(w['analysis']['fact'])
    d['items'].insert(0, w)
    d['edges'] = [dict(e, first=e['first'] + 1, second=e['second'] + 1) for e in d['edges']]
    s = d.get('settings', {})
    s['hard_isolates'] = [i + 1 for i in s.get('hard_isolates', [])]
    s['pinned_links'] = [i + 1 for i in s.get('pinned_links', [])]
    m0 = plan_members(rule(case))
    m1 = plan_members(rule(d))
    n = len(case['items'])
    changed = 0
    for i in range(n):
        a = tuple(x for x in m0[i])
        b = tuple(x - 1 for x in m1[i + 1])
        changed += a != b
    return changed / n


def motifs(plan_a, plan_b, case, radius=3):
    """Canonical local windows around disagreement positions (structure only)."""
    sc, n, rank = _scan(case)
    ma, mb = plan_members(plan_a), plan_members(plan_b)
    out = set()
    for i in range(n):
        if ma[i] != mb[i]:
            lo, hi = max(0, i - radius), min(n - 1, i + radius)
            sig = []
            for p in range(lo, hi + 1):
                al = sc.allowed(p) if p < n - 1 else None
                st = sc.strength(p) if p < n - 1 else None
                r = rank(p, p + 1) if p < n - 1 else None
                sig.append((p - i, sc.wide(p), al, st, None if r is None else 'v'))
            # order pattern of ranks in the window (comparison bits only)
            rs = [rank(p, p + 1) for p in range(lo, min(hi, n - 2) + 1)]
            bits = tuple((rs[k + 1] is not None and (rs[k] is None or rs[k + 1] < rs[k]))
                         for k in range(len(rs) - 1))
            out.add((tuple(sig), bits))
    return out


def seg_cut_plan(case, L):
    """Bounded-influence variant: every segment [kL,(k+1)L) is planned as an
    independent sub-sequence (no pair crosses a cut).  Influence radius <= L by
    construction; price: cross-cut pairs are lost and the frozen first-position
    rules (FIRST reason, opening restriction) apply at every segment head."""
    n = len(case['items'])
    s = case.get('settings', {})
    out = []
    for lo in range(0, n, L):
        hi = min(n, lo + L)
        sub = copy.deepcopy(case)
        sub['items'] = sub['items'][lo:hi]
        sub['edges'] = [dict(e, first=e['first'] - lo, second=e['second'] - lo) for e in case.get('edges', [])
                        if lo <= e['first'] and e['second'] < hi]
        ss = dict(s)
        ss['hard_isolates'] = [i - lo for i in s.get('hard_isolates', []) if lo <= i < hi]
        ss['pinned_links'] = [i - lo for i in s.get('pinned_links', []) if lo <= i < hi - 1]
        sub['settings'] = ss
        for u in ref.complete_plan(sub):
            u = copy.deepcopy(u)
            for sl in u['slots']:
                sl['item'] += lo
            out.append(u)
    return out


RULES['cut8'] = lambda c: seg_cut_plan(c, 8)
RULES['cut16'] = lambda c: seg_cut_plan(c, 16)
