"""WP-B studies (non-timing): writes results/raw/wpB/studies.json.
Bounded: every loop has explicit case counts; total ~3-4 minutes on 1 core."""
import copy, json, math, random, statistics, sys, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
import paths  # noqa
from common import ref, random_case, roundtrip, base_case, fact, unit_of
import transducer as T, omega as O, theory_a as A
import wpB_blocks as WB, wpB_layered as L, wpB_domains as D, wpB_witness as Wt, wpB_bounds as Bd

OUT = HERE.parents[1] / 'results' / 'raw' / 'wpB'
OUT.mkdir(parents=True, exist_ok=True)
res = {}
t_start = time.time()

# ---------------- B01 blow-up: table entries / exits vs block size and unknown density
rows = []
for n in (32, 96):
    for pu in (0.1, 0.3, 0.6):
        for B in (4, 8, 16):
            rng = random.Random(n * 100 + int(pu * 10))
            ent = ex = runs = ev = mk = 0
            for k in range(3):
                c = roundtrip(random_case(rng, n, p_unknown=pu, p_edge_unknown=pu, settings_mix=True))
                cnt = {}
                bs = WB.BlockSummary(copy.deepcopy(c), 'ext', False, block=B, intern=True, counters=cnt)
                for t in range(0, n, 3):
                    bs.certify(t)
                sz = bs.size()
                ent += sz['entries']; ex += sz['exit_keys']; ev += cnt['evaluations']; mk = max(mk, cnt['max_key_vars'])
                runs += sz['unique_tables'] or 0
            rows.append(dict(n=n, p_unknown=pu, block=B, table_entries=ent, exit_keys=ex, unique_exit_sets=runs,
                             evaluations=ev, max_key_vars=mk))
res['B01_blowup'] = rows

# ---------------- B06 / X04: budget Pareto and budget strategies
rng = random.Random(61)
cases = [roundtrip(random_case(rng, rng.randrange(16, 64), p_unknown=rng.choice((0.2, 0.4, 0.6)),
                               p_edge_unknown=rng.choice((0.2, 0.4, 0.6)), settings_mix=False)) for _ in range(40)]
targets = [rng.randrange(len(c['items']) // 2, len(c['items'])) for c in cases]
pareto = []
for name, fn in (('exact', L.exact_from_zero), ('seeded', L.seeded_exact), ('tree', L.tree_only)):
    for budget in (100, 300, 1000, 3000, 10000, None):
        cert = unk = ev = 0
        for c, t in zip(cases, targets):
            cc = {}
            r = fn(c, t, 'ext', False, budget=budget, counters=cc)
            cert += r[0] == 'certified'; unk += r[0] == 'unknown'; ev += cc['evaluations']
        pareto.append(dict(method=name, budget=budget, certified=cert, unknown=unk, evaluations=ev, cases=len(cases)))
res['B06_budget_pareto'] = pareto
# X04: (a) expand-budget-then-refine (restart tree then exact with doubling budget, failed attempts charged)
#      (b) locate-then-allocate (seeded windows, single budget growth)
strat = {'expand_then_refine': 0, 'locate_then_allocate': 0, 'exact_doubling_budget': 0}
dec = {k: 0 for k in strat}
for c, t in zip(cases, targets):
    tot = 0; b = 100
    while True:
        cc = {}; r = L.tree_only(c, t, 'ext', False, budget=b, counters=cc); tot += cc['evaluations']
        if r[0] == 'unknown':
            b *= 2; continue
        if r[0] != 'certified':
            cc = {}; r = L.exact_from_zero(c, t, 'ext', False, budget=None, counters=cc); tot += cc['evaluations']
        break
    strat['expand_then_refine'] += tot; dec['expand_then_refine'] += r[0] == 'certified'
    cc = {}; r = L.seeded_exact(c, t, 'ext', False, counters=cc)
    strat['locate_then_allocate'] += cc['evaluations']; dec['locate_then_allocate'] += r[0] == 'certified'
    tot = 0; b = 100
    while True:
        cc = {}; r = L.exact_from_zero(c, t, 'ext', False, budget=b, counters=cc); tot += cc['evaluations']
        if r[0] == 'unknown':
            b *= 2; continue
        break
    strat['exact_doubling_budget'] += tot; dec['exact_doubling_budget'] += r[0] == 'certified'
res['X04_budget_strategies'] = dict(total_evaluations=strat, certified=dec, cases=len(cases))

# ---------------- B03/B05 cost vs exact (single query, no reuse)
rows = []
for n in (16, 64, 128):
    for pu in (0.1, 0.3, 0.6):
        rng = random.Random(n * 10 + int(pu * 10))
        acc = {k: [0, 0] for k in ('exact', 'seeded', 'goal', 'tree')}
        for k in range(5):
            c = roundtrip(random_case(rng, n, p_unknown=pu, p_edge_unknown=pu, settings_mix=False))
            t = rng.randrange(n // 2, n)
            for name, fn in (('exact', L.exact_from_zero), ('seeded', L.seeded_exact), ('goal', L.goal_pruned), ('tree', L.tree_only)):
                cc = {}
                r = fn(c, t, 'ext', False, budget=400000, counters=cc)
                acc[name][0] += cc['evaluations']; acc[name][1] += r[0] == 'certified'
        rows.append(dict(n=n, p_unknown=pu, **{f'{k}_evaluations': v[0] for k, v in acc.items()},
                         **{f'{k}_certified': v[1] for k, v in acc.items()}))
res['B03_B05_single_query'] = rows

# ---------------- X02: lazy vs eager block tables; first far-jump and reuse
rows = []
for n in (64, 192):
    rng = random.Random(n)
    c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.3, settings_mix=False))
    for lazy in (True, False):
        cnt = {}
        t0 = time.perf_counter_ns(); bs = WB.BlockSummary(copy.deepcopy(c), 'ext', False, block=8, lazy=lazy, counters=cnt)
        build = time.perf_counter_ns() - t0; ev_build = cnt['evaluations']
        t0 = time.perf_counter_ns(); bs.certify(n - 2); first = time.perf_counter_ns() - t0; ev_first = cnt['evaluations'] - ev_build
        ev0 = cnt['evaluations']
        for t in range(0, n, 2):
            bs.certify(t)
        rows.append(dict(n=n, lazy=lazy, build_evaluations=ev_build, far_jump_evaluations=ev_first,
                         sweep_evaluations=cnt['evaluations'] - ev0, table_entries=bs.size()['entries']))
    # wide-then-precise: lazy relation first, exact blocks only where the relation is ambiguous
    cnt = {}; rel = L.LazyRel(T.Facts(c, 'omega', 'ext', False)); bs = WB.BlockSummary(copy.deepcopy(c), 'ext', False, block=8, counters=cnt)
    evr = 0; cert = 0
    import wpB_layered as LL
    for t in range(0, n, 2):
        bud = LL._Budget(None); LL._ACTIVE.append(bud)
        try:
            us = rel.units(t)
        finally:
            LL._ACTIVE.pop()
        evr += bud.n
        if len(us) == 1:
            cert += 1
        else:
            cert += bs.certify(t)[0] == 'certified'
    rows.append(dict(n=n, lazy='wide_then_precise', relation_evaluations=evr, block_evaluations=cnt['evaluations'], certified=cert))
res['X02_lazy_vs_eager'] = rows

# ---------------- X03: symbolic order + bitset vs complete quantized branching
rows = []
rng = random.Random(33)
for k in range(12):
    n = rng.randrange(4, 9)
    c = roundtrip(random_case(rng, n, p_unknown=0.2, p_edge_unknown=0.5, domain='G0', settings_mix=False))
    t = rng.randrange(n)
    cc = {}; a = L.exact_from_zero(c, t, 'G0', False, counters=cc)
    saved = D.install_bitset_domain(name='G0bits')
    try:
        cb = {}; b = L.exact_from_zero(c, t, 'G0bits', False, counters=cb)
    finally:
        D.uninstall(saved)
    # complete quantized branching: unknown non-null rank branches over K grid values
    for K in (10, 50):
        vals = [round(q * 1499 / (K - 1)) / 50 for q in range(K)]
        orig_rank = T.Ctx._rank

        def qrank(self, a_, b_, vals=vals):
            if self._state(a_) == 'WIDE' or self._state(b_) == 'WIDE':
                return None
            e = self.F.records.get(a_)
            if e is not None and e.get('status') == 'computed':
                return e.get('score', None)
            ch = self.choose(('rk', a_), ('NULL',) + tuple(range(len(vals))))
            return None if ch == 'NULL' else vals[ch]
        T.Ctx._rank = qrank
        try:
            cq = {}; q = L.exact_from_zero(c, t, 'G0', False, counters=cq)
        finally:
            T.Ctx._rank = orig_rank
        rows.append(dict(n=n, target=t, K=K, symbolic_evaluations=cc['evaluations'], bitset_evaluations=cb['evaluations'],
                         quantized_evaluations=cq['evaluations'], symbolic=a[0], bitset=b[0], quantized=q[0],
                         quantized_certifies_but_symbolic_not=(q[0] == 'certified' and a[0] != 'certified')))
res['X03_symbolic_vs_quantized'] = rows

# ---------------- D03: tag-driven vs shape-driven domain selection
c = base_case(5, automatic=True)
c['edges'][1]['score'] = 0
c['edges'] = [e for e in c['edges'] if e['first'] != 2]
for e in c['edges']:
    e['source'] = 'external'
shape = D.shape_domain(c); tag = D.select_domain(c)
st_shape = T.certify_tree(c, 4, shape)[0]; st_tag = T.certify_tree(c, 4, tag[0])[0]
units_ext = len(O.oracle_units(c, 4, 'ext'))
res['D03_domain_selection'] = dict(shape_guess=shape, shape_verdict=st_shape, tagged=tag, tagged_verdict=st_tag,
                                   ext_world_units=units_ext,
                                   verdict='shape-guess certifies a unit that an admissible ext world contradicts'
                                   if st_shape == 'certified' and units_ext > 1 else 'no counterexample')

# ---------------- D06: decimal literal vs binary64
text, fl, dec = D.decimal_vs_binary64_case()
cf = base_case(5, automatic=True); cd = base_case(5, automatic=True)
for cc_, src in ((cf, fl), (cd, dec)):
    recs = {e['first']: e for e in src['edges']}
    for e in cc_['edges']:
        if e['first'] in recs:
            e['score'] = recs[e['first']]['score']
pf = [[s['item'] for s in u['slots']] for u in ref.complete_plan(cf)]
pd = [[s['item'] for s in u['slots']] for u in ref.complete_plan(cd)]
res['D06_decimal_vs_binary64'] = dict(text=text, binary64_plan=pf, exact_decimal_plan=pd, differ=pf != pd,
                                      rule='reject numeric literals whose decimal text does not round-trip through binary64')

# ---------------- E01/E02/E03
import OPTIMIZED_OPERATOR as OP
a_, b_, probe = Wt.permuted_pair(random.Random(1))
res['E01'] = dict(same_statistics=Wt.stats(a_) == Wt.stats(b_), score_a=OP.score(a_, probe), score_b=OP.score(b_, probe),
                  raw_many_to_one=Wt.raw_many_to_one()[2], AB_vs_BA_same_pair=Wt.direction_needs_both_sides(),
                  storage_bytes=dict(raw_per_side=200, normalised_per_side=150, both_sides=300, scalar_rank_per_edge=8))
e2 = []
for h1, h2 in ((1, 1), (2, 2), (2, 200), (3, 3), (5, 5), (7, 9), (10, 10), (25, 25), (49, 49)):
    r, sizes = Wt.realizable_q(h1, h2)
    vals = [q for q in range(1500) if r >> q & 1]
    e2.append(dict(h_left=h1, h_right=h2, joint_blocks=len(sizes), achievable_q=len(vals),
                   smallest_nonzero_q=vals[1] if len(vals) > 1 else None))
res['E02_repeated_rows'] = e2
res['E03_structural'] = [dict(premise=p, impossible=i, reason=r) for p, i, r in Wt.structural_impossible()]

# ---------------- X10: geometry-derived per-edge masks
c = base_case(5, automatic=True)
for i, it in enumerate(c['items']):
    it['analysis']['fact'].update(width=1, height=2)
    it['header'].update(width=1, height=2)
c['edges'][1]['score'] = 0.3            # (1,2) known: not a multiple of 0.5 -> premise violated (late metadata)
masks = Wt.edge_masks_from_geometry(c)
good = copy.deepcopy(c); good['edges'][1]['score'] = 0.5
good['edges'] = [e for e in good['edges'] if e['first'] != 2]
gm = Wt.edge_masks_from_geometry(good)
saved = D.install_bitset_domain(name='geo', edge_masks=gm)
try:
    geo = T.certify_tree(good, 4, 'geo')[0]
    illegal = not T.Facts(c, 'omega', 'geo', False).domain_ok
finally:
    D.uninstall(saved)
res['X10_geometry_masks'] = dict(edges_with_masks=sorted(gm), verdict_G0=T.certify_tree(good, 4, 'G0')[0], verdict_geo=geo,
                                 note='all objects w=1,h=2 (L=R column, rows 25/25): ranks are multiples of 0.5; a known 0.3 '
                                      'would contradict the premise and must force a wider domain',
                                 premise_violation_detected_as_illegal=illegal)

# ---------------- N01 chain dependency (G0-realised)
res['N01_chain_dependency'] = [Bd.chain_dependency(n, t) for n in (8, 12, 16, 24) for t in (n - 2, n - 3)]
# ---------------- N02 boundary classes
rng = random.Random(72); rows = []
for k in range(40):
    n = rng.randrange(6, 10)
    c = roundtrip(random_case(rng, n, p_unknown=0.5, p_edge_unknown=0.5))
    b = rng.randrange(2, n - 2)
    keys, classes, states = Bd.boundary_classes(c, b)
    rows.append(dict(n=n, b=b, frontier_keys=keys, distinct_future_behaviours=classes, distinct_states=states))
res['N02_boundary_classes'] = dict(rows=rows, max_classes=max(r['distinct_future_behaviours'] for r in rows),
                                   max_states=max(r['distinct_states'] for r in rows),
                                   cases_classes_gt_states=sum(r['distinct_future_behaviours'] > r['distinct_states'] for r in rows))
# ---------------- D05 width profile incl. pins/opening
rng = random.Random(75); prof = []
for k in range(60):
    n = rng.randrange(8, 40)
    c = roundtrip(random_case(rng, n, p_unknown=rng.choice((0.2, 0.5)), p_edge_unknown=rng.choice((0.2, 0.5)), settings_mix=True))
    p = Bd.width_profile(c)
    p.update(n=n, pins=bool(c['settings'].get('pinned_links')), opening=c['settings'].get('opening'))
    prof.append(p)
res['D05_width'] = dict(rows=prof, max_live_vars=max(r['max_live_vars'] for r in prof),
                        max_component_edges=max(r['max_rank_component_edges'] for r in prof),
                        max_frontier=max(r['max_frontier'] for r in prof),
                        pins_max_live=max([r['max_live_vars'] for r in prof if r['pins']] or [0]))
# ---------------- N05
res['N05_oracle_independence'] = Bd.oracle_independence(40)
# ---------------- N06: LMP relaxation numbers (r8 L2 rule reproduced)
import theory_h as H
rng = random.Random(41); diff = tot = 0
for k in range(300):
    n = rng.randrange(2, 30); c = roundtrip(random_case(rng, n, domain='G0'))
    mp, mq = H.plan_members(ref.complete_plan(c)), H.plan_members(H.lmp_plan(c))
    tot += n; diff += sum(mp[i] != mq[i] for i in range(n))
ch = A.decreasing_chain(64); d = copy.deepcopy(ch); d['edges'][1]['score'] = 0.1
far_ref = max([i for i in range(64) if H.plan_members(ref.complete_plan(ch))[i] != H.plan_members(ref.complete_plan(d))[i]] or [0])
far_lmp = max([i for i in range(64) if H.plan_members(H.lmp_plan(ch))[i] != H.plan_members(H.lmp_plan(d))[i]] or [0])
# absolute-parity relaxation: inserting one object at the front shifts every parity decision
ins = A.decreasing_chain(65)
res['N06_relaxations'] = dict(lmp_positions_changed_pct=round(100 * diff / tot, 2), chain64_edit_farthest_reference=far_ref,
                              chain64_edit_farthest_lmp=far_lmp,
                              parity_insertion_note='LMP decisions use i%2: a front insertion relabels all parities (identity change => full reissue)')
res['seconds'] = round(time.time() - t_start, 1)
(OUT / 'studies.json').write_text(json.dumps(res, indent=1, default=str))
print(json.dumps({k: (v if not isinstance(v, list) or len(json.dumps(v)) < 600 else f'{len(v)} rows') for k, v in res.items()}, indent=1, default=str)[:6000])
