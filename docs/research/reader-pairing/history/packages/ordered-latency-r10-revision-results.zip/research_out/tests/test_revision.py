"""Tests added in the R10 revision: T01 counterexample/revised rule, T07 integrity checker negatives and the
self-contained neutral plan checker (lab/gamma_ref2.py, which does not call gamma.py's logic).
Run:  python3 -B research_out/tests/test_revision.py
"""
import json
import random
import shutil
import subprocess
import sys
import tempfile
import unittest
from fractions import Fraction
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]
PKG = OUT.parent
sys.path.insert(0, str(OUT / "lab"))
sys.path.insert(0, str(OUT))
import common  # noqa: E402,F401
import check_integrity as CI  # noqa: E402
import evidence as E  # noqa: E402
import gamma as G  # noqa: E402
import gamma_ref2 as R2  # noqa: E402
import obsworlds as OW  # noqa: E402


class T01(unittest.TestCase):
    def test_counterexample_refutes_old_rule(self):
        ce = OW.t01_counterexample()
        P = ce["P_phase_locked"]
        self.assertAlmostEqual(P["old_median_U_minus_C_ms"], 125.19685)
        self.assertTrue(P["old_rule_says_no_go"])
        self.assertEqual(P["candidate_median_ms"], 4.0)
        self.assertTrue(P["candidate_passes"])
        self.assertTrue(ce["old_proposition_refuted"])

    def test_same_C_U_different_world(self):
        ce = OW.t01_counterexample()
        self.assertTrue(ce["same_observation_with_C_i"])
        self.assertFalse(ce["S_required_service"]["candidate_passes"])
        self.assertAlmostEqual(ce["S_required_service"]["candidate_U_ms"], 128.19685)

    def test_revised_rule_not_refuted_by_either_world(self):
        r = OW.t01_check()
        self.assertTrue(r["revised_rule_consistent_with_P"])
        self.assertTrue(r["revised_rule_consistent_with_S"])

    def test_revised_rule_monotone_bound(self):
        # supporting lemma only (not the rule itself): if every L'_i >= s_i then median(L') >= median(s)
        rng = random.Random(3)
        for _ in range(200):
            s = [Fraction(rng.randint(0, 200)) for _ in range(50)]
            extra = [Fraction(rng.randint(0, 50)) for _ in range(50)]
            L = [a + b for a, b in zip(s, extra)]
            self.assertGreaterEqual(OW.median(L), OW.median(s))


class NeutralPlanChecker(unittest.TestCase):
    def test_golden_examples(self):
        for spec, exp in R2.GOLDEN:
            sides = spec.get("sides", [R2.U] * spec["n"])
            objs = [{"state": c, "side": sd, "analysed": True} for c, sd in zip(spec["states"], sides)]
            self.assertEqual([u[0] for u in R2.plan(objs, {}, spec["settings"])], exp, spec)

    def test_gamma_agrees_with_golden(self):
        for spec, exp in R2.GOLDEN:
            case = G.make_case(["SHAPE_X" if c == "X" else "SHAPE_Y" for c in spec["states"]], spec.get("sides"), settings=spec["settings"])
            self.assertEqual([u["slots"] for u in G.plan(case)], exp, spec)

    def test_differential_random(self):
        rng, bad = random.Random(20261027), 0
        for _ in range(2000):
            n = rng.randint(1, 10)
            w = E.random_world(n, rng, p_y=0.15, p_side=0.2, p_null=0.3, smax=5)
            st = {"direction": rng.choice(["LTR", "RTL"]), "automatic": rng.random() < 0.7,
                  "forced": rng.sample(range(n), min(n, rng.choice([0, 0, 1]))),
                  "manual": rng.sample(range(n), min(n, rng.choice([0, 1, 2, 3]))),
                  "opening": rng.choice(["AUTO", "FIRST_DOUBLE", "FIRST_SINGLE"])}
            known = {i for i in range(n) if rng.random() < 0.8}
            ek = {i for i in range(n - 1) if rng.random() < 0.8}
            desc = {i: G.fact(w[0][i]) for i in range(n) if i not in known and rng.random() < 0.5}
            case = G.make_case(*w, st, known=known, edge_known=ek, descriptors=desc)
            a = [(u["slots"], u["certain"], u["reason"]) for u in G.plan(case)]
            bad += a != R2.plan(*R2.from_gamma_case(case))
        self.assertEqual(bad, 0)

    def test_checker_is_independent(self):
        import ast
        tree = ast.parse((OUT / "lab/gamma_ref2.py").read_text(encoding="utf-8"))
        names = [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
        names += [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
        self.assertEqual(names, [], "the neutral checker must not import anything (in particular not gamma)")


class SelfFound(unittest.TestCase):
    def test_sf2_domain_signature_separates_settings(self):
        import omega as O
        a = O.Domain(3, False, {"direction": "RTL"})
        b = O.Domain(3, False, {"direction": "LTR", "forced": [1]})
        self.assertNotEqual(O.dom_signature(a), O.dom_signature(b))
        know = (("full",) * 3, (False, False))
        ta, tb = O.proj_table(a, know, 1), O.proj_table(b, know, 1)
        self.assertIsNot(ta, tb)

    def test_sf1_remaining_gap_is_oracle_domain_artefact(self):
        import omega as O
        w = (("SHAPE_Y", "SHAPE_X", "SHAPE_X", "SHAPE_X"), ("RIGHT", "RIGHT", "UNKNOWN", "LEFT"), (None, 1, 2))
        know = (("none", "full", "full", "full"), (True, True, False))
        narrow = O.Domain(4, True, {"direction": "RTL"})
        wide = O.Domain(4, True, {"direction": "RTL"}, scores=(None, 0, 1, 2, 3))
        self.assertEqual(len(narrow.projections(w, know, 1)), 1)
        self.assertEqual(len(wide.projections(w, know, 1)), 2)


class PrunedEntries(unittest.TestCase):
    """Q053 route B': pruned certification must stay sound and never certify earlier than the information boundary."""

    def test_full_knowledge_sound(self):
        rng = random.Random(53)
        st = {"direction": "RTL", "automatic": True}
        for _ in range(25):
            w = E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40)
            case = G.make_case(*w, st)
            t = rng.randrange(25, 55)
            b = G.certify(case, t, prune=True)
            self.assertEqual(b["unit"], G.unit_of(G.plan(case), t))
            self.assertGreaterEqual(b["first"], G.certify(case, t)["first"])

    def test_default_unchanged(self):
        rng = random.Random(54)
        st = {"direction": "RTL", "automatic": True}
        for _ in range(25):
            w = E.random_world(30, rng)
            case = G.make_case(*w, st, known=set(range(25)))
            t = rng.randrange(5, 28)
            a, b = G.certify(case, t), G.certify(case, t, prune=False)
            self.assertEqual((a["status"], a["unit"], a["first"], a["needs"]), (b["status"], b["unit"], b["first"], b["needs"]))


class Integrity(unittest.TestCase):
    """T07: path rule unit tests run here on Linux; native Windows execution was NOT run (no Windows host)."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.pkg = self.tmp / "pkg"
        (self.pkg / "code").mkdir(parents=True)
        (self.pkg / "research_out" / "lab").mkdir(parents=True)
        (self.pkg / "code" / "a.py").write_text("print(1)\n", encoding="utf-8")
        (self.pkg / "B.md").write_text("b\n", encoding="utf-8")
        (self.pkg / "research_out" / "lab" / "x.py").write_text("x\n", encoding="utf-8")
        self.write_manifest([("code/a.py",), ("B.md",)])

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def write_manifest(self, entries, raw=None):
        files = raw if raw is not None else [{"path": p[0], "bytes": (self.pkg / p[0]).stat().st_size, "sha256": CI.sha(self.pkg / p[0])}
                                             for p in entries]
        (self.pkg / "MANIFEST.json").write_text(json.dumps({"files": files}), encoding="utf-8")

    def test_clean_package_ok(self):
        self.assertTrue(CI.verify_manifest(self.pkg)["ok"])

    def test_windows_separators_in_manifest_are_normalised(self):
        raw = [{"path": "code\\a.py", "bytes": 9, "sha256": CI.sha(self.pkg / "code/a.py")},
               {"path": "B.md", "bytes": 2, "sha256": CI.sha(self.pkg / "B.md")}]
        self.write_manifest(None, raw)
        self.assertTrue(CI.verify_manifest(self.pkg)["ok"])

    def test_path_rule(self):
        self.assertEqual(CI.norm_rel("research_out\\lab\\x.py"), "research_out/lab/x.py")
        self.assertEqual(CI.norm_rel("./code/a.py"), "code/a.py")
        for badp in ("../x", "/etc/passwd", "C:\\x\\y", "a//b", "code/../../x"):
            with self.assertRaises(ValueError, msg=badp):
                CI.norm_rel(badp)

    def test_walk_rel_is_posix(self):
        self.assertIn("research_out/lab/x.py", CI.walk_rel(self.pkg))
        self.assertTrue(all("\\" not in r for r in CI.walk_rel(self.pkg)))

    def test_hash_mismatch_fails(self):
        (self.pkg / "code/a.py").write_text("print(2)\n", encoding="utf-8")   # same length, different bytes
        r = CI.verify_manifest(self.pkg)
        self.assertFalse(r["ok"])
        self.assertEqual(r["hash_or_size_mismatch"], ["code/a.py"])

    def test_length_mismatch_fails(self):
        (self.pkg / "B.md").write_text("bb\n", encoding="utf-8")
        self.assertFalse(CI.verify_manifest(self.pkg)["ok"])

    def test_missing_file_fails(self):
        (self.pkg / "B.md").unlink()
        r = CI.verify_manifest(self.pkg)
        self.assertFalse(r["ok"])
        self.assertEqual(r["missing_listed_files"], ["B.md"])

    def test_unlisted_original_fails(self):
        (self.pkg / "code/extra.py").write_text("", encoding="utf-8")
        r = CI.verify_manifest(self.pkg)
        self.assertEqual(r["unlisted_original_files"], ["code/extra.py"])
        self.assertFalse(r["ok"])

    def test_unsafe_manifest_path_fails(self):
        raw = [{"path": "../outside", "bytes": 0, "sha256": "0" * 64}]
        self.write_manifest(None, raw)
        self.assertFalse(CI.verify_manifest(self.pkg)["ok"])

    def test_checksum_verify_negatives(self):
        text = "\n".join(CI.checksum_lines(self.pkg)) + "\n"
        self.assertTrue(CI.verify_checksums(self.pkg, text)["ok"])
        (self.pkg / "research_out/lab/x.py").write_text("y\n", encoding="utf-8")
        self.assertEqual(CI.verify_checksums(self.pkg, text)["hash_mismatch"], ["research_out/lab/x.py"])
        (self.pkg / "research_out/lab/x.py").unlink()
        self.assertEqual(CI.verify_checksums(self.pkg, text)["missing"], ["research_out/lab/x.py"])
        (self.pkg / "research_out/lab/new.py").write_text("", encoding="utf-8")
        self.assertIn("research_out/lab/new.py", CI.verify_checksums(self.pkg, text)["unlisted"])
        (self.pkg / "research_out/lab/new.py").unlink()
        (self.pkg / "research_out/lab/x.py").write_text("x\n", encoding="utf-8")
        win = text.replace("research_out/lab/x.py", "research_out\\lab\\x.py")
        self.assertTrue(CI.verify_checksums(self.pkg, win)["ok"])              # Windows separators are normalised
        dup = text + text.splitlines()[0] + "\n"
        self.assertFalse(CI.verify_checksums(self.pkg, dup)["ok"])            # duplicate entries are rejected

    def test_script_exit_code_on_real_package_copy(self):
        dst = self.tmp / "copy"
        shutil.copytree(PKG, dst, ignore=shutil.ignore_patterns("__pycache__"))
        r = subprocess.run([sys.executable, "-B", str(dst / "research_out/check_integrity.py")], capture_output=True)
        self.assertEqual(r.returncode, 0, r.stdout[-400:])          # regenerate checksums in the copy
        r = subprocess.run([sys.executable, "-B", str(dst / "research_out/check_integrity.py"), "--verify"], capture_output=True)
        self.assertEqual(r.returncode, 0, r.stdout[-400:])
        p = dst / "code/lab.py"
        p.write_bytes(p.read_bytes().replace(b"a", b"b", 1))
        r = subprocess.run([sys.executable, "-B", str(dst / "research_out/check_integrity.py"), "--verify"], capture_output=True)
        self.assertEqual(r.returncode, 1)                           # modified original -> exit 1


if __name__ == "__main__":
    unittest.main()
