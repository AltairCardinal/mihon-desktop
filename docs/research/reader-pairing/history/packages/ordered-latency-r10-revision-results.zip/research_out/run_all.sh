#!/bin/sh
# Re-run every R10 experiment from the package root (R10 revision). Order matters (some steps read earlier outputs).
# Expected wall time on 2 CPUs: about 75-90 minutes (exp_certificates ~6 min, exp_q053 ~10 min, exp_q119 ~30 min,
# exp_joint ~12 min). Every step is listed; a failing step stops the script (set -e).
set -e
cd "$(dirname "$0")/.."
P="python3 -B"
$P research_out/lab/reach.py > /dev/null
$P research_out/lab/n0_structure.py > /dev/null
$P research_out/lab/obsworlds.py > /dev/null
# Historical only: needs the previous package's reference.py (R9_REFERENCE); prints NOT_RUN when absent.
$P research_out/lab/gamma_xcheck.py 20000
$P research_out/bench/exp_certificates.py
$P research_out/bench/exp_evidence.py
$P research_out/bench/exp_gamma2.py > /dev/null
$P research_out/bench/exp_q097.py > /dev/null
$P research_out/bench/exp_q097b.py > /dev/null
$P research_out/bench/exp_summarytree.py > /dev/null
$P research_out/bench/exp_cache.py > /dev/null
$P research_out/bench/exp_sched.py > /dev/null
$P research_out/bench/exp_mailbox.py > /dev/null
$P research_out/bench/exp_lifecycle.py > /dev/null
$P research_out/bench/exp_stats.py > /dev/null
$P research_out/bench/exp_misc.py > /dev/null
$P research_out/bench/exp_combos.py > /dev/null
$P research_out/bench/exp_workloads.py > /dev/null
$P research_out/bench/exp_q053.py > /dev/null
$P research_out/bench/exp_q119.py > /dev/null
$P research_out/bench/exp_joint.py > /dev/null
$P research_out/bench/bench_micro.py drive
$P research_out/bench/bench_prune.py drive
$P research_out/records/build.py
$P research_out/tests/test_r10.py
$P research_out/tests/test_regressions.py
$P research_out/tests/test_revision.py
$P research_out/check_report_consistency.py
$P research_out/check_integrity.py
$P research_out/check_integrity.py --verify
echo "done"
