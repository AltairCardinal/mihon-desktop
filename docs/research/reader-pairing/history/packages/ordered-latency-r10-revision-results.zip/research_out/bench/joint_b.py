"""Joint-design studies C06-C10 (R10 revision, T06). See joint_core.py for the protocol."""
import copy
import itertools
import random
import sys
from collections import OrderedDict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cachemodel as CM
import evidence as E
import gamma as G
import gamma_tools as GT
import summarytree as STR
from joint_core import study

ST = {"direction": "RTL", "automatic": True}


# ================================================================================================ C06
COST6 = {"a": 1, "b": 1, "c": 2, "x": 20, "y": 8}


def _greedydual():
    return {"H": {}, "L": 0}


def sim6(seq, k, evict, prefetch, gate=False, horizon=2):
    """seq: list of (visible, prefetch-or-None). evict: 'lru' | 'gd'. prefetch: 'always' | set of allowed step indices.
    gate (II's B): prefetch only if it does not evict an object demanded within the next `horizon` visible steps
    and only if cost(prefetch) >= cost(victim)."""
    cache = OrderedDict()
    gd = _greedydual()
    lat = work = hits = 0

    def victim():
        if evict == "lru":
            return next(iter(cache))
        return min(cache, key=lambda o: (gd["H"][o], list(cache).index(o)))

    def insert(o):
        nonlocal work
        work += COST6[o]
        if len(cache) >= k:
            v = victim()
            if evict == "gd":
                gd["L"] = gd["H"][v]
            del cache[v]
        cache[o] = True
        gd["H"][o] = gd["L"] + COST6[o]

    for i, (v, p) in enumerate(seq):
        if v in cache:
            hits += 1
            cache.move_to_end(v)
            gd["H"][v] = gd["L"] + COST6[v]
        else:
            lat += COST6[v]
            insert(v)
        if p is None or p in cache:
            continue
        if prefetch != "always" and i not in prefetch:
            continue
        if gate and len(cache) >= k:
            vv = victim()
            upcoming = {s[0] for s in seq[i + 1:i + 1 + horizon]}
            if vv in upcoming or COST6[p] < COST6[vv]:
                continue
        insert(p)
    return lat, work, hits


def opt6(seq, k, choose_victim, choose_prefetch):
    """Exact offline optimum (I): DP over cache contents. choose_victim: optimise eviction (else LRU order is not
    representable -> only used with choose_victim=True); choose_prefetch: optimise prefetch decisions (else always)."""
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def f(i, cache):
        if i == len(seq):
            return (0, 0)
        v, p = seq[i]
        best = None
        opts = []
        if v in cache:
            opts.append((0, 0, cache))
        else:
            if len(cache) < k:
                opts.append((COST6[v], COST6[v], cache | {v}))
            else:
                for x in cache:
                    opts.append((COST6[v], COST6[v], (cache - {x}) | {v}))
        for lat, w, c2 in opts:
            nexts = []
            if p is None or p in c2:
                nexts.append((0, c2))
            else:
                if choose_prefetch:
                    nexts.append((0, c2))
                if len(c2) < k:
                    nexts.append((COST6[p], c2 | {p}))
                else:
                    for x in c2:
                        if x != v:                      # never evict the object being shown now
                            nexts.append((COST6[p], (c2 - {x}) | {p}))
                if not nexts:
                    nexts.append((0, c2))
            for pw, c3 in nexts:
                r = f(i + 1, frozenset(c3))
                cand = (lat + r[0], w + pw + r[1])
                if best is None or cand < best:
                    best = cand
        return best
    return f(0, frozenset())


def c06():
    rng = random.Random(606)
    inputs = {"v1_sequence_k2": ([(o, None) for o in "xababab"] + [("x", None)], 2),
              "prefetch_pollution_k2": ([("a", "y"), ("b", "y"), ("a", None), ("b", "y"), ("x", None), ("a", "y"), ("b", None), ("x", None)], 2)}
    for s in range(3):
        objs = list(COST6)
        seq = [(rng.choice(objs), rng.choice(objs + [None, None])) for _ in range(9)]
        inputs[f"random{s}_k3"] = (seq, 3)

    def run(inp, d, a, b):
        seq, k = inp
        if d == "I" and a:
            lat, work = opt6(seq, k, True, b)
            # hits are not tracked by the DP; recompute hit count of the optimal visible-miss pattern is not unique -> omit
            return {"m": lat, "cost": {"work": work}, "ok": True}
        if d == "I" and b:  # exact prefetch decisions with LRU eviction: brute force over subsets
            steps = [i for i, (_, p) in enumerate(seq) if p is not None]
            best = None
            for r in range(len(steps) + 1):
                for sub in itertools.combinations(steps, r):
                    lat, work, hits = sim6(seq, k, "lru", set(sub))
                    if best is None or (lat, work) < best[:2]:
                        best = (lat, work, hits)
            return {"m": best[0], "cost": {"work": best[1]}, "ok": True}
        evict = "gd" if (d == "II" and a) else "lru"
        lat, work, hits = sim6(seq, k, evict, "always", gate=(d == "II" and b))
        return {"m": lat, "cost": {"work": work}, "ok": True}
    hit_note = {pol: sim6(inputs["v1_sequence_k2"][0], 2, pol, "always")[::2] for pol in ("lru", "gd")}
    return study("C06", "visible rebuild latency over the demand sequence", "lower", inputs, run,
                 {"I": "exact offline joint optimum of eviction and prefetch (small domain, needs the future demand)",
                  "II": "online cost-aware eviction (GreedyDual) + visible-demand-first prefetch gate"},
                 "I is an offline oracle-style optimiser (not deployable without the future sequence; a bound), "
                 "II is an online layered policy",
                 notes={"hit_rate_counterexample_v1_sequence_(latency,hits)": hit_note})


# ================================================================================================ C07
def c07():
    rng = random.Random(7)
    ws = [E.random_world(16, rng) for _ in range(20)]

    def hist(w, kind):
        s = CM.unit_starts(w, ST)
        if kind == "far_jumps":
            return s[: len(s) // 2] + [s[-1], s[1], s[len(s) // 2]]
        if kind == "revisits":
            return [s[-1], s[1], s[-1], s[2], s[-1], s[1]]
        return s

    def run(inp, d, a, b):
        kw = dict(mat=7, smp=2, prefetch=False, fact_cap=24, strong_leaf_cap=256)
        if d == "I":
            if a:
                kw["fact_cap"] = None          # scalar facts kept separately and persistently
            if b:
                kw["strong"] = True            # minimal-support (branch) certificate
        if d == "II":
            if a:
                kw["smp_policy"] = "heat"      # keep the samples that certificate supports use most
            if b:
                kw["memo"] = True              # re-certify on demand: reuse a certificate whose support is still held
        tot = {"transforms": 0, "probes": 0, "rounds": 0, "memo_hits": 0}
        for w in ws:
            r = CM.run_history(w, ST, hist(w, inp), **kw)
            for k in tot:
                tot[k] += r[k]
        return {"m": tot["transforms"], "cost": {k: v for k, v in tot.items() if k != "transforms"}, "ok": True}
    livelock = {}
    for cap in (20, 24):
        bad = 0
        for w in ws:
            for kind in ("far_jumps", "revisits", "forward"):
                try:
                    CM.run_history(w, ST, hist(w, kind), mat=7, smp=2, prefetch=False, fact_cap=cap)
                except AssertionError:
                    bad += 1
        livelock[cap] = {"histories": 3 * len(ws), "livelocked": bad}
    return study("C07", "materialisations over 20 worlds (prefetch OFF; facts bounded to 24 unless A_I; branch leaf cap 256)", "lower",
                 {"far_jumps": "far_jumps", "revisits": "revisits", "forward": "forward"}, run,
                 {"I": "persistent scalar-fact store separate from samples + branch certificate",
                  "II": "support-heat sample retention + certificate reuse when its exact support is still held"},
                 "I keeps the facts themselves; II keeps rebuild material and re-validates certificates",
                 notes={"fact_store_livelock_boundary": livelock,
                        "meaning": "a bounded fact store smaller than one certificate's simultaneous need set livelocks "
                                   "(evicts facts the same certification still needs)"})


# ================================================================================================ C08
def c08():
    """Query sequences over 60-object worlds; metric = total scan work (certification steps + checkpoint/tree work),
    reads reported as cost. Updates flip one fact left of the next target (identity validation must catch it)."""
    def worlds(kind, k=12, seed=808):
        rng = random.Random(seed)
        if kind == "long_chain":
            return [E.random_world(60, rng, p_y=0.0, p_side=0.0, p_null=0.0, smax=40) for _ in range(k)], rng
        return [E.random_world(60, rng, p_y=0.03, p_side=0.04, p_null=0.1, smax=40) for _ in range(k)], rng

    def plan_queries(kind, rng):
        if kind == "forward":
            return [("q", t) for t in range(20, 56, 3)]
        if kind == "early_update":
            q = []
            for t in range(20, 56, 6):
                q += [("q", t), ("flip", rng.randrange(max(1, t - 12), t - 2)), ("q", t + 3)]
            return q
        return [("q", rng.randrange(12, 58)) for _ in range(12)]

    def flip_case(case, pos):
        c = GT.flip(case, ("dim", pos))
        return c if c is not None else case

    def run(inp, d, a, b):
        kind = inp
        ws, rng = worlds("long_chain" if kind == "long_chain" else "sparse")
        work = reads = wrong = maint = 0
        for w in ws:
            case = G.make_case(*w, ST)
            queries = plan_queries("random" if kind == "long_chain" else kind, rng)
            cps = {}            # I: position -> (normalised cursor set, {obj: fact snapshot})
            tree = None         # II: summary relation
            memo = {}           # II-B: target -> certificate
            for op, x in queries:
                if op == "flip":
                    case = flip_case(case, x)
                    if tree is not None:
                        tree.ops = {"leaf_steps": 0, "compositions": 0}
                        tree.update(case, x)
                        maint += tree.ops["leaf_steps"] + tree.ops["compositions"]
                    continue
                t = x
                truth = G.unit_of(G.plan(case), t)
                if d == "II" and b and t in memo and G.is_current(memo[t], case):
                    unit = memo[t]["unit"]
                    work += len(memo[t]["dependent_objects"])     # currency check reads the support
                    wrong += unit != truth
                    continue
                if d == "I" and a:
                    cands = [c for c in cps if t - 8 <= c <= t]
                    used = False
                    for c in sorted(cands, reverse=True):
                        cur_set, snap = cps[c]
                        ok = all(G.Case(case).effective(o) == f for o, f in snap.items())
                        maint += len(snap)                         # identity validation per object
                        if not ok:
                            del cps[c]
                            continue
                        c_ = G.Case(case)
                        sc = G.Scan(60, c_.settings, *G.snapshot_queries(c_))
                        units = set()
                        steps = 0
                        for (i, op_, rh) in cur_set:
                            cur = (i, op_, i if rh else -1)
                            while cur[0] <= t:
                                u, cur = sc.step(cur)
                                steps += 1
                                if any(o == t for o, _ in u["slots"]):
                                    units.add(str(u))
                                    unit = u
                                    break
                        work += steps
                        reads += t + 3 - c
                        if len(units) == 1:
                            wrong += unit != truth
                            used = True
                            break
                    if used:
                        continue
                if d == "II" and a:
                    if tree is None:
                        tree = STR.SummaryTree(case, 8)
                        maint += tree.ops["leaf_steps"] + tree.ops["compositions"]
                    tree.ops = {"leaf_steps": 0, "compositions": 0}
                    unit = tree.unit(t)
                    work += tree.ops["leaf_steps"] + tree.ops["compositions"]
                    reads += 8
                    wrong += unit != truth
                    if b:
                        cert = G.certify(case, t)       # re-certification at query time attaches a checkable support
                        memo[t] = cert
                        work += cert["steps"]
                    continue
                cert = G.certify(case, t, prune=(d == "I" and b))
                work += cert["steps"]
                reads += len(cert["dependent_objects"])
                wrong += cert["unit"] != truth
                if d == "II" and b:
                    memo[t] = cert
                if d == "I" and a and len(cert["unit"]["slots"]) == 2:
                    i2 = cert["unit"]["slots"][1][0] + 1
                    if i2 < 60:
                        c_ = G.Case(case)
                        cps[i2] = ({(i2, False, False)}, {o: c_.effective(o) for o in cert["dependent_objects"]})
        return {"m": work, "cost": {"reads": reads, "maintenance": maint, "wrong_units": wrong}, "ok": wrong == 0}
    return study("C08", "scan work over the query sequence (certification/tree steps; maintenance in cost)", "lower",
                 {"forward": "forward", "random_targets": "random", "early_update": "early_update", "long_chain_no_reset": "long_chain"},
                 run,
                 {"I": "exact cursor checkpoints harvested after certified pairs (identity-validated) + pruned entry relation",
                  "II": "summary relation (tree) composed at query + certificate reuse with C12 currency check"},
                 "I keeps exact states and validates object identities; II keeps composable transfer relations and "
                 "re-certifies")


# ================================================================================================ C09
class ChunkedLazy:
    """II: persistent chunked unit sequence. On a change, chunks from the change become SUSPECT but keep their
    content; a query re-expands suspect chunks left to right and stops as soon as a recomputed chunk's exit cursor
    equals its stored exit cursor (convergence): every later suspect chunk is valid again without work."""

    def __init__(self, case, chunk=8, lazy=True):
        self.case, self.chunk, self.lazy = case, chunk, lazy
        self.n = len(case["items"])
        self.ops = 0
        self.chunks = {}      # k -> (entry cursor, units, exit cursor, manual cache)
        self.suspect_from = 0
        self.nk = -(-self.n // chunk)

    def _expand(self, k, entry):
        c = G.Case(self.case)
        sc = G.Scan(self.n, c.settings, *G.snapshot_queries(c))
        a, b = k * self.chunk, min(self.n, (k + 1) * self.chunk)
        cur, units = entry, []
        while cur[0] < b:
            u, cur = sc.step(cur)
            self.ops += 1
            units.append(u)
        return (entry, units, cur)

    def _norm(self, cur):
        return (cur[0], cur[1], cur[2] == cur[0])

    def ensure(self, kmax):
        k = self.suspect_from
        entry = (0, True, -1) if k == 0 else self.chunks[k - 1][2]
        while k <= min(kmax if self.lazy else self.nk - 1, self.nk - 1):
            old = self.chunks.get(k)
            new = self._expand(k, entry)
            self.chunks[k] = new
            k += 1
            self.suspect_from = k
            if old is not None and self._norm(old[2]) == self._norm(new[2]) and self.lazy:
                self.suspect_from = self.nk          # converged: later chunks valid again
                return
            entry = new[2]

    def unit(self, t):
        k = t // self.chunk
        if self.suspect_from <= k:
            self.ensure(k)
        for kk in (k, k - 1):
            if kk in self.chunks:
                for u in self.chunks[kk][1]:
                    if any(o == t for o, _ in u["slots"]):
                        return u
        raise AssertionError("unit not found")

    def update(self, case, pos):
        self.case = case
        self.suspect_from = min(self.suspect_from, max(0, (pos - 2) // self.chunk))


def c09():
    """Navigation after one change: obtain the target unit and the next 3 units; metric = scan work."""
    def mk(kind, seed):
        rng = random.Random(seed)
        if kind == "long_chain":
            w = E.random_world(176, rng, p_y=0.0, p_side=0.0, p_null=0.0, smax=40)
        else:
            w = E.random_world(176, rng)
        return w, rng

    inputs = {"early_change_far_target": ("sparse", 3, 120), "change_near_target": ("sparse", 115, 120),
              "long_chain_early_change": ("long_chain", 3, 120), "no_change": ("sparse", None, 120)}

    def run(inp, d, a, b):
        kind, pos, t = inp
        tot, wrong = 0, 0
        for seed in range(5):
            w, rng = mk(kind, 900 + seed)
            case = G.make_case(*w, ST)
            if d == "I" and a:
                st_ = STR.SummaryTree(case, 8)
            elif d == "II" and a:
                st_ = ChunkedLazy(case, 8, lazy=b)
                st_.ensure(st_.nk - 1)
            else:
                st_ = None
            st_ops0 = 0
            if pos is not None:
                s2 = list(w[0])
                s2[pos] = "SHAPE_Y" if s2[pos] == "SHAPE_X" else "SHAPE_X"
                case = G.make_case(s2, w[1], w[2], ST)
            plan = G.plan(case)
            targets = [t]
            u = G.unit_of(plan, t)
            nxt = max(o for o, _ in u["slots"]) + 1
            for _ in range(3):
                if nxt >= 176:
                    break
                targets.append(nxt)
                nxt = max(o for o, _ in G.unit_of(plan, nxt)["slots"]) + 1
            if d == "I" and a:
                st_.ops = {"leaf_steps": 0, "compositions": 0}
                if pos is not None:
                    st_.update(case, pos)
                if b:
                    got = [st_.unit(x) for x in targets]
                    work = st_.ops["leaf_steps"] + st_.ops["compositions"]
                else:                      # eager consumer: materialise the whole new plan from the tree
                    got = [st_.unit(x) for x in targets]
                    work = st_.ops["leaf_steps"] + st_.ops["compositions"] + 176
            elif d == "II" and a:
                st_.ops = 0
                if pos is not None:
                    st_.update(case, pos)
                got = [st_.unit(x) for x in targets]
                work = st_.ops
            elif b:                         # lazy consumer without a structure: rescan from 0 to the last target
                c_ = G.Case(case)
                sc = G.Scan(176, c_.settings, *G.snapshot_queries(c_))
                cur, work, got = (0, True, -1), 0, []
                want = set(targets)
                found = {}
                while cur[0] <= max(targets) + 1 and cur[0] < 176:
                    uu, cur = sc.step(cur)
                    work += 1
                    for o, _ in uu["slots"]:
                        if o in want:
                            found[o] = uu
                    if len(found) == len(want):
                        break
                got = [found[x] for x in targets]
            else:                           # eager full rebuild
                got = [G.unit_of(plan, x) for x in targets]
                work = len(plan)
            tot += work
            wrong += sum(gg != G.unit_of(plan, x) for gg, x in zip(got, targets))
        return {"m": tot, "cost": {"wrong_units": wrong}, "ok": wrong == 0}
    return study("C09", "scan work for one change + target unit + 3 following units (5 worlds, n=176)", "lower", inputs, run,
                 {"I": "balanced summary tree; lazy consumer queries only the needed units",
                  "II": "persistent chunked sequence; suspect chunks re-expanded lazily with exit-cursor convergence check"},
                 "I recomputes O(log n) summaries per change and answers any target; II re-expands from the change "
                 "until the scan state converges and is sequential")


# ================================================================================================ C10
def c10():
    """Memo of certified target units under fact changes. Stamps are k-bit counters per fact (wrap-around).
    A_I = memo validated by k-bit stamps of the SELECTED-PATH reads (first C08 entry);
    B_I = dependency set = union of all reads of all attempts + saturation fallback (a wrapped stamp disables the fast path);
    A_II = memo validated by value re-check of the selected-path reads (no stamps);
    B_II = validation by the certificate's complete logical support (C12 is_current on the proof support)."""
    def mk(seed, n=24):
        rng = random.Random(seed)
        return [E.random_world(n, rng, p_side=0.08, p_null=0.2) for _ in range(30)], rng

    def all_reads(cert):
        out = set()
        for k in cert["reads"]:
            if k.startswith("Analysis:"):
                out.add(("an", int(k.split(":")[1])))
                out.add(("dim", int(k.split(":")[1])))
            elif k.startswith("Dimension:") or k.startswith("Descriptor:"):
                out.add(("dim", int(k.split(":")[1])))
            elif k.startswith("Edge:"):
                out.add(("edge", int(k.split(":")[1])))
        return out

    def run(inp, d, a, b):
        cap, kbits, flips_kind = inp
        ws, rng = mk(1010)
        stale = recompute = validate = false_inval = 0
        for w in ws:
            case = G.make_case(*w, ST)
            stamps = {}
            wraps = {}
            memo = OrderedDict()
            ops = []
            for _ in range(14):
                if rng.random() < 0.5:
                    ops.append(("q", rng.randrange(6, 20)))
                else:
                    ops.append(("f", None))
            for op, t in ops:
                if op == "f":
                    # choose a fact: from a memoised certificate's attempt reads (negative facts) or anywhere
                    pool = []
                    for e in memo.values():
                        pool += sorted(e["attempt_only"] if flips_kind == "negative" else e["all"])
                    if not pool:
                        pool = [("dim", rng.randrange(24))]
                    f = rng.choice(pool)
                    reps = (2 ** kbits) if flips_kind == "overflow" else 1
                    for _ in range(reps):
                        c2 = GT.flip(case, f)
                        if c2 is None:
                            break
                        case = c2
                        stamps[f] = (stamps.get(f, 0) + 1) % (2 ** kbits)
                        if stamps[f] == 0:
                            wraps[f] = wraps.get(f, 0) + 1
                    continue
                truth = G.unit_of(G.plan(case), t)
                if a and t in memo:
                    e = memo[t]
                    memo.move_to_end(t)
                    if d == "I":
                        deps = e["all"] if b else e["selected"]
                        validate += len(deps)
                        fast_ok = all(stamps.get(f, 0) == e["stamps"].get(f, 0) for f in deps)
                        if b and any(wraps.get(f, 0) != e["wraps"].get(f, 0) for f in deps):
                            fast_ok = False                        # saturation fallback
                        hit = fast_ok
                    else:
                        if b:
                            validate += len(e["cert"]["dependent_objects"])
                            hit = G.is_current(e["cert"], case)
                        else:
                            validate += len(e["selected"])
                            c_ = G.Case(case)
                            hit = all(_val(c_, f) == e["values"][f] for f in e["selected"])
                    if hit:
                        stale += e["unit"] != truth
                        continue
                    false_inval += e["unit"] == truth
                cert = G.certify(case, t)
                recompute += cert["steps"]
                if a:
                    reads1, _ = GT.first_entry_support(case, t)
                    sel = reads1 or set()
                    allr = all_reads(cert) | sel
                    c_ = G.Case(case)
                    memo[t] = {"unit": cert["unit"], "cert": cert, "selected": sel, "all": allr,
                               "attempt_only": allr - GT.support_facts(cert),
                               "stamps": {f: stamps.get(f, 0) for f in allr}, "wraps": {f: wraps.get(f, 0) for f in allr},
                               "values": {f: _val(c_, f) for f in sel}}
                    while len(memo) > cap:
                        memo.popitem(last=False)
        return {"m": stale, "cost": {"recompute_steps": recompute, "validation_reads": validate, "false_invalidations": false_inval},
                "ok": stale == 0}
    inputs = {"random_flips_cap8": (8, 8, "any"), "small_cap2": (2, 8, "any"),
              "negative_fact_flips_cap8": (8, 8, "negative"), "stamp_overflow_k2": (8, 2, "overflow")}
    return study("C10", "stale memo hits (wrong units served)", "lower", inputs, run,
                 {"I": "identity stamps over the union of all attempts' reads + saturation fallback",
                  "II": "value-level validation of the certificate's logical support (proof), no stamps"},
                 "I validates by cheap stamps over a larger read set and must handle wrap-around; II validates the "
                 "smaller proof support by value and is immune to stamp overflow")


def _val(c_, f):
    kind, i = f
    if kind == "dim":
        e = c_.effective(i)
        return None if e is None else e["state"]
    if kind == "an":
        a = c_.analysis(i)
        return a.get("fact", {}).get("side") if a["status"] == "Computed" else None
    e = c_.edge(i, i + 1)
    return e.get("score") if e["status"] == "Computed" else "?"
