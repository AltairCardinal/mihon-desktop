"""Joint-design studies C12, C21-C30 (R10 revision, T06). See joint_core.py for the protocol.
Statistical and decision studies (C21, C23-C25, C30) are ablations on ONE fixed world/sample set; they never claim a
latency gain of the product."""
import itertools
import json
import random
import statistics
import sys
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lab"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import evidence as E
import features as F
import gamma as G
import sched as S
from common import PKG, RAW, T_CEIL, formal_rows, load_jsonl, median
from joint_core import study

ST = {"direction": "RTL", "automatic": True}
T_MS = Fraction(30196850, 10 ** 6)


# ================================================================================================ C12
def _grey_pair(rng, near=False):
    """Realizable facing-strip pair (50 raw points each) from the declared generator; 'near' = variance close to 100."""
    if near:   # 25/25 split with a grey step of 20: luma variance is exactly 100 in exact arithmetic
        g = rng.randrange(30, 200)
        a = [(g, g, g, 255)] * 25 + [(g + 20, g + 20, g + 20, 255)] * 25
        if rng.random() < 0.5:
            rng.shuffle(a)
        return a, list(a)
    oa = F.make_object(rng, rng.choice(["white", "dark", "textured", "grey"]), rng.choice(["white", "dark", "textured", "grey"]))
    ob = F.make_object(rng, rng.choice(["white", "dark", "textured", "grey"]), rng.choice(["white", "dark", "textured", "grey"]))
    return F.facing(oa, "left"), F.facing(ob, "right")


def c12():
    """Edge decision for a pair of facing strips; reference = features.distance (float, forward order).
    A = cheap screening, B = exact handling near the threshold.
    I : A_I = cheap certificate from metadata class (both sides 'white' or both 'dark' -> null without pixels) used
        ONLY if the metadata is bound to the content (verified flag); B_I = everything else on the original
        reference path (no alternative arithmetic at all).
    II: A_II = interval fast path (exact-rational variance; decide when clearly away from 100);
        B_II = near-threshold fallback to the reference float sequence (|v-100| < eps)."""
    rng = random.Random(1212)
    inputs = {"realizable_mixed": [(_grey_pair(rng), True) for _ in range(150)],
              "near_threshold_grey": [(_grey_pair(rng, near=True), True) for _ in range(150)],
              "bad_metadata": [(_grey_pair(rng), False) for _ in range(150)]}

    def meta_class(pts, truthful):
        flat_w = sum(min(F.normalize(p)) > 220 for p in pts) >= 40
        flat_d = sum(max(F.normalize(p)) < 50 for p in pts) >= 40
        cls = "white" if flat_w else "dark" if flat_d else "other"
        if not truthful:
            cls = {"white": "other", "dark": "other", "other": "white"}[cls]   # corrupted metadata
        return cls

    def run(inp, d, a, b):
        flips = pixels = fallback = 0
        for (pa, pb), truthful in inp:
            ref = F.distance(pa, pb)
            got = None
            if a and d == "I":
                bound = truthful        # metadata carries a content binding only when it is truthful (verified flag)
                ca, cb = meta_class(pa, truthful), meta_class(pb, truthful)
                if (not b or bound) and ca == cb and ca in ("white", "dark"):
                    got = ("null", "flat_extreme")
                elif not b and ca == cb == "white":
                    got = ("null", "flat_extreme")
            if got is None and a and d == "II":
                r, used = F.distance_fast_with_fallback(pa, pb, eps=(1e-6 if b else -1), fast="exact")
                got = r
                fallback += used
                pixels += 100
            if got is None:
                got = ref
                pixels += 100
            flips += (got[0] != ref[0]) or (got[0] == "score" and float(got[1]) != float(ref[1]))
        return {"m": flips, "cost": {"pixels_read": pixels, "fallbacks": fallback}, "ok": flips == 0}
    return study("C12", "decision flips vs the reference float evaluation (150 pairs)", "lower", inputs, run,
                 {"I": "cheap metadata certificate only where content-bound (proven sufficient), else the original path",
                  "II": "exact-rational interval fast path with near-threshold fallback to the reference sequence"},
                 "I skips pixel work entirely in a proven domain; II computes with different arithmetic and refines "
                 "only near the threshold")


# ================================================================================================ C21
def c21():
    """Compatible-world set for 50 samples (synthetic; built from the frozen T01 counterexample family).
    Each world gives per-sample (C, B, U) where B = start of post-authorisation busy service and the GO/NO-GO answer
    for the intervention 'pre-authorisation work shortened to 3 ms'. Observables: U always; probes C (cost 1),
    B (cost 2), opportunity schedule O (cost 2). A = probe selection, B = bound-first gating.
    I : A_I = decision-relevant probe (the one that best splits GO/NO-GO over the current compatible set);
        B_I = worst-case compatible interval computed after probing (decide when it does not straddle T).
    II: A_II = pairwise set cover (cheapest probe set separating every pair of worlds);
        B_II = bound first: probe only if the interval from current observations straddles T."""
    families = {
        "T01_family_same_U": {
            "P_phase": {"C": 5, "B": 130.19685, "U": 130.19685, "O": (4, 130.19685), "go": True},
            "S_service": {"C": 5, "B": 5, "U": 130.19685, "O": None, "go": False},
            "Q_queue": {"C": 5, "B": 100, "U": 130.19685, "O": None, "go": False},
            "P2_phase_short": {"C": 25, "B": 130.19685, "U": 130.19685, "O": (28, 130.19685), "go": True},
            "S2_service_C25": {"C": 25, "B": 25, "U": 130.19685, "O": None, "go": False}},
        "mixed_U_family": {   # some worlds are already below the ceiling: the bound decides them with no probe
            "fast_already": {"C": 5, "B": 5, "U": 20.0, "O": None, "go": True},
            "fast_phase": {"C": 3, "B": 20.0, "U": 20.0, "O": (4, 20.0), "go": True},
            "P_phase": {"C": 5, "B": 130.19685, "U": 130.19685, "O": (4, 130.19685), "go": True},
            "S_service": {"C": 5, "B": 5, "U": 130.19685, "O": None, "go": False}},
    }
    probes = {"C": 1, "B": 2, "O": 2}

    worlds = {}

    def obs(w, P):
        return (("U", worlds[w]["U"]),) + tuple((p, worlds[w][p]) for p in sorted(P))

    def compatible(truth, P):
        return [w for w in worlds if obs(w, P) == obs(truth, P)]

    def interval(truth, P):
        """Worst-case candidate median interval (ms) over worlds compatible with the observations."""
        vals = []
        for w in compatible(truth, P):
            x = worlds[w]
            if x["U"] <= float(T_MS):
                vals.append(x["U"])                        # already passes; pre-authorisation shortening cannot hurt here
            else:
                vals.append(min(x["U"], 4 if x["go"] else x["U"] - x["B"] + 3))
        return min(vals), max(vals)

    def decided(truth, P):
        lo, hi = interval(truth, P)
        return lo > float(T_MS) or hi <= float(T_MS)

    def run(inp, d, a, b):
        worlds.clear()
        worlds.update(families[inp])
        amb = cost = 0
        width = 0.0
        for truth in worlds:
            P = set()
            if a:
                if d == "I":
                    while not len({worlds[w]["go"] for w in compatible(truth, P)}) == 1:
                        best = min((p for p in probes if p not in P),
                                   key=lambda p: (max(sum(1 for w in compatible(truth, P | {p}) if worlds[w]["go"]),
                                                      sum(1 for w in compatible(truth, P | {p}) if not worlds[w]["go"])), probes[p]))
                        P.add(best)
                        if len(P) == len(probes):
                            break
                else:
                    if not (b and decided(truth, P)):
                        best = None
                        for r in range(1, 4):
                            for sub in itertools.combinations(sorted(probes), r):
                                ok = all(obs(w1, set(sub)) != obs(w2, set(sub)) for w1, w2 in itertools.combinations(worlds, 2)
                                         if worlds[w1]["go"] != worlds[w2]["go"])
                                if ok and (best is None or sum(probes[p] for p in sub) < sum(probes[p] for p in best)):
                                    best = sub
                            if best:
                                break
                        P |= set(best)
            cost += sum(probes[p] for p in P)
            if b:
                undecided = not decided(truth, P)
            else:
                undecided = len({worlds[w]["go"] for w in compatible(truth, P)}) > 1
            amb += undecided
            lo, hi = interval(truth, P)
            width += hi - lo
        return {"m": amb, "cost": {"probe_cost": cost, "interval_width_sum_ms": round(width, 5)}, "ok": True}
    return study("C21", "true worlds whose GO/NO-GO stays undecided", "lower", {k: k for k in families}, run,
                 {"I": "decision-relevant probe choice + post-hoc worst-case interval",
                  "II": "pairwise set-cover probe set + bound-first gating"},
                 "I chooses probes adaptively per decision; II fixes a separating probe set in advance and skips probing "
                 "when the bound already decides",
                 notes={"not_a_latency_claim": True, "families": families})


# ================================================================================================ C22
def c22():
    """Synthetic 6-stage service per sample (stage durations vary per sample), 200 samples per run.
    Observer cost model: fixed 0.2 per recorded event + a flush stall of 5 when more than 4 events are buffered in a
    frame (contention). A = buffer/sampling observer, B = stage association / calibration.
    I : A_I = fixed anchors (start/end) always + non-critical stage events sampled at 10% of samples (fixed seed);
        B_I = association of sampled stage events to samples through the anchors (per-sample DAG for sampled samples).
    II: A_II = phased complementary probes: run ph records stages {2ph, 2ph+1} for every sample (3 runs);
        B_II = controlled calibration run with a known per-event delay, used to subtract the fixed per-event cost.
    Identification is COMPUTED: a stage is 'per-sample identified' if >= 20 samples have that stage's event associated
    to the sample's own anchors in ONE run; 'marginally identified' if >= 20 samples recorded it in some run.
    Real runs: NOT_RUN (no product execution in this task)."""
    base_rng = random.Random(2222)
    base = [[base_rng.randint(2, 20) for _ in range(6)] for _ in range(200)]

    def perturbation(mask, per_event=0.2, stall=5, buffer=4):
        out = []
        for i in range(len(base)):
            k = sum(mask(i, st) for st in range(6)) + 2
            out.append(per_event * k + (stall if k > buffer else 0))
        return out

    def run(inp, d, a, b):
        if not a:
            runs = [lambda i, st: True]
        elif d == "I":
            sampled = set(random.Random(7).sample(range(200), 20))
            runs = [lambda i, st, S_=sampled: i in S_]
        else:
            runs = [lambda i, st, ph=ph: st in (2 * ph, 2 * ph + 1) for ph in range(3)]
        perts = [perturbation(m) for m in runs]
        pert = [max(x) for x in zip(*perts)]
        assoc = (not a) or (d == "I" and b)          # full recording associates trivially; I needs its anchors
        per_sample = sum(1 for st in range(6) if any(sum(m(i, st) for i in range(200)) >= 20 for m in runs)) if assoc else 0
        if a and d == "II":
            per_sample = 0                            # no single run carries all stages of a sample
        marginal = sum(1 for st in range(6) if any(sum(m(i, st) for i in range(200)) >= 20 for m in runs))
        resid = statistics.mean(pert)
        if b and d == "II":                           # calibration removes the fixed part, not the contention stall
            resid = statistics.mean(p - 0.2 * (sum(m(i, st) for m in runs[:1] for st in range(6)) + 2) for i, p in enumerate(pert))
            resid = max(0.0, resid)
        return {"m": round(statistics.mean(pert), 3),
                "cost": {"stages_identified_per_sample_DAG": per_sample, "stages_identified_marginal": marginal,
                         "uncorrected_perturbation": round(resid, 3), "runs": len(runs) + (1 if (b and d == "II") else 0)},
                "ok": True}

    # observation-equivalent worlds and the discriminating threshold sweep (Q012)
    def world_cost(kind, k):
        return 0.2 * k + (5 if (kind == "contention" and k > 4) else 0)
    sweep = {k: {"fixed_only": world_cost("fixed", k), "contention": world_cost("contention", k)} for k in range(1, 9)}
    equivalent_upto = max(k for k in sweep if sweep[k]["fixed_only"] == sweep[k]["contention"])
    return study("C22", "observer perturbation per sample (model units, synthetic)", "lower", {"synthetic_6_stage": None}, run,
                 {"I": "anchors always + sparse sampling; per-sample DAG for sampled samples",
                  "II": "phased complementary probes + calibration run; marginals only"},
                 "I keeps per-sample joint structure for a subsample; II covers every stage for every sample but only "
                 "marginally (no single DAG)",
                 notes={"real_product_run": "NOT_RUN", "threshold_sweep_events_per_frame": sweep,
                        "worlds_observationally_equivalent_up_to_events_per_frame": equivalent_upto,
                        "discriminating_experiment": "raise events per frame past the buffer threshold in one run; a fixed-cost "
                                                     "world grows linearly, a contention world jumps"})


# ================================================================================================ C23
def c23():
    """Frozen F0 (50 samples). Mechanism: each sample can lose at most R ns (A, per-sample reach bound); B = the
    reduction must be one common deployable policy: it applies only to the 'advance' scenario and costs +2 ms on the
    other samples; the 16 ms group-median guard is checked. Metric: smallest R (ms, grid 0.5 ms) for which the
    candidate median passes (None = impossible at any R).
    I : A_I = order-statistic reach bound (sort per-sample floors, Lemma R1); B_I = scenario restriction applied to
        the per-sample floors (each sample may still take its own best reduction).
    II: A_II = one common reduction parameter theta (every applicable sample loses min(theta, R));
        B_II = the same theta for all groups + guard check, solved exactly on the grid."""
    rows = [r for r in formal_rows() if r["group"] == "F0"]
    T = T_CEIL

    def passes_with(R, d, a, b):
        R_ns = int(R * 1_000_000)
        vals, guard_ok = [], True
        for r in rows:
            x = r["unit_latency_ns"]
            applicable = (r["scenario"] == "advance") if b else True
            if applicable:
                vals.append(max(0, x - R_ns))
            else:
                vals.append(x + (2_000_000 if (b and d == "II") else 0))
        if b and d == "II":
            for sc in ("new_start", "reopen"):
                ref = median([r["unit_latency_ns"] for r in rows if r["scenario"] == sc])
                cand = median([v for v, r in zip(vals, rows) if r["scenario"] == sc])
                guard_ok &= cand - ref <= 16_000_000
        return median(vals) <= T and guard_ok

    def q093_passes(R, d):
        """Synthetic Q093 construction: 50 samples at 120 ms; policy P1 can reduce samples 0..23, P2 samples 24..47.
        Per-sample best-of-policies (I) vs one common policy (II)."""
        R_ns = int(R * 1_000_000)
        base = [120_000_000] * 50
        p1 = [x - R_ns if i < 24 else x for i, x in enumerate(base)]
        p2 = [x - R_ns if 24 <= i < 48 else x for i, x in enumerate(base)]
        if d == "II":
            return min(median(p1), median(p2)) <= T
        return median([min(x, y) for x, y in zip(p1, p2)]) <= T

    def run(inp, d, a, b):
        if not a:
            return {"m": None, "cost": {"passes_without_reduction": False}, "ok": True}
        for k in range(0, 400):
            R = k * 0.5
            ok = passes_with(R, d, a, b) if inp == "F0" else q093_passes(R, d)
            if ok:
                return {"m": R, "cost": {}, "ok": True}
        return {"m": None, "cost": {"impossible_below_ms": 200}, "ok": True}
    return study("C23", "smallest per-sample reduction R (ms) that passes the frozen median gate (None = never)", "lower",
                 {"F0_frozen": "F0", "q093_two_policies_synthetic": "Q093"}, run,
                 {"I": "order-statistic floors (Lemma R1), scenario restriction on floors",
                  "II": "single common parameter theta, same for all groups, guard checked"},
                 "I allows sample-wise optimum within the bound; II forbids per-sample cherry-picking",
                 notes={"hypothetical_mechanism": "R is a parameter, not an estimate of any real gain"})


# ================================================================================================ C24
def c24():
    """Null generator: zero true effect, stratified F0 noise, a cold/warm carry-over of 8 ms for whichever arm runs
    second, 5 candidate parameter settings (all null). Gate: candidate median gain >= 15 ms. 2000 simulated studies.
    A = exploration (pick the best of 5 on an exploration run), B = order/carry-over handling.
    I : A_I = exploration inside randomised blocks, verdict frozen on a held-out block; B_I = ABBA blocks.
    II: A_II = sequential testing over 5 candidates and 3 looks with a pre-registered threshold calibrated to a 5%
        family-wise null pass rate (calibration draws separate from study data);
        B_II = carry-over modelled and subtracted using a calibration pair (OFF-OFF)."""
    rows = [r for r in formal_rows() if r["group"] == "F0"]
    strata = {}
    for r in rows:
        strata.setdefault(r["scenario"], []).append(r["unit_latency_ns"])
    WARM, GATE = 8_000_000, 15_000_000

    def arm(rng, warm=0):
        return [rng.choice(v) - warm for v in strata.values() for _ in range(len(v))]

    def compare(rng, d, b, counter):
        counter[0] += 2
        if b and d == "I":     # ABBA: carry-over cancels inside the block
            off = arm(rng)[:25] + arm(rng, WARM)[:25]
            on = arm(rng, WARM)[:25] + arm(rng)[:25]
            return median(off) - median(on)
        if b and d == "II":    # model carry-over: OFF-OFF calibration pair in the same order, subtract
            off, on = arm(rng), arm(rng, WARM)
            c_off, c_on = arm(rng), arm(rng, WARM)
            counter[0] += 2
            return (median(off) - median(on)) - (median(c_off) - median(c_on))
        off, on = arm(rng), arm(rng, WARM)  # fixed OFF -> ON order: ON benefits from the warm state
        return median(off) - median(on)

    def calibrated_threshold(d, b):
        """Pre-registered: the 95th percentile of max-gain over 5 candidates x 3 looks under the null, computed on
        separate calibration draws (never on study data)."""
        rng = random.Random(9999)
        mx = []
        for _ in range(300):
            mx.append(max(compare(rng, d, b, [0]) for _ in range(15)))
        mx.sort()
        return mx[int(0.95 * len(mx))]

    def run(inp, d, a, b):
        rng = random.Random(2424)
        passes = 0
        counter = [0]
        sims = 1000
        h = calibrated_threshold(d, b) if (a and d == "II") else None
        for _ in range(sims):
            if not a:
                passes += compare(rng, d, b, counter) >= GATE
            elif d == "I":
                gains = [compare(rng, d, b, counter) for _ in range(5)]   # exploration picks the best candidate
                passes += compare(rng, d, b, counter) >= GATE              # verdict frozen on a fresh held-out block
            else:
                ok = False
                for _look in range(3):
                    g = [compare(rng, d, b, counter) for _ in range(5)]
                    if max(g) >= max(GATE, h):
                        ok = True
                        break
                passes += ok
        return {"m": round(passes / sims, 4), "cost": {"runs_per_study": round(counter[0] / sims, 2),
                                                       "calibrated_threshold_ms": None if h is None else round(h / 1e6, 3)}, "ok": True}
    return study("C24", "false pass rate under a null (zero true effect)", "lower", {"null_with_carryover_8ms": None}, run,
                 {"I": "randomised exploration + frozen held-out verdict, ABBA blocks",
                  "II": "sequential test with alpha split over candidates and looks, carry-over subtracted by calibration"},
                 "I removes selection and order bias by design; II models them and corrects statistically",
                 notes={"not_a_product_gain": True})


# ================================================================================================ C25
def c25():
    """R0 rejected samples (with failures) as the baseline arm; a synthetic candidate arm converts the slowest
    successful samples into failures (timeouts) -> success-only statistics look faster without any real gain.
    Metric: apparent P95 improvement (ms) claimed by the report (0 = no fake claim).
    A = tail reporting, B = timeout/failure handling.
    I : A_I = nearest-rank P95 on valid samples; B_I = correctness/validity hard gate first (any failure -> no claim;
        failures listed with the full denominator).
    II: A_II = P95 with censoring (failures as right-censored at the 15 s timeout); B_II = group gate on the full
        denominator (failure counts compared before any duration claim)."""
    rej = load_jsonl(PKG / "data/rejected_samples.jsonl")
    base = [(r["unit_latency_ns"], bool(r["failure"])) for r in rej]
    succ = sorted(x for x, f in base if not f)
    slow = set(succ[-6:])
    cand = [(x, f or x in slow) for x, f in base]

    def p95(v):
        v = sorted(v)
        return v[-(-95 * len(v) // 100) - 1]

    def report(arm, d, a, b):
        ok = [x for x, f in arm if not f]
        if not a:
            return median(ok)
        if d == "II":
            return p95([15_000_000_000 if f else x for x, f in arm])
        return p95(ok)

    def run(inp, d, a, b):
        fb = sum(f for _, f in base)
        fc = sum(f for _, f in cand)
        if b and (d == "I") and (fb or fc):
            return {"m": 0.0, "cost": {"claim": "withheld: failures present (full denominator listed)", "failures": [fb, fc]}, "ok": True}
        if b and d == "II" and fc > fb:
            return {"m": 0.0, "cost": {"claim": "rejected by group gate: more failures in candidate", "failures": [fb, fc]}, "ok": True}
        imp = (report(base, d, a, b) - report(cand, d, a, b)) / 1e6
        return {"m": round(float(imp), 3), "cost": {"claim": "duration statistic compared", "failures": [fb, fc]}, "ok": imp <= 0}
    return study("C25", "apparent improvement claimed (ms; >0 is a fake gain created by dropped failures)", "lower",
                 {"R0_with_synthetic_failure_shift": None}, run,
                 {"I": "validity hard gate first; durations described only for valid runs, full denominator listed",
                  "II": "censored-tail statistics + full-denominator group gate"},
                 "I refuses any duration claim when failures exist; II keeps failures in the statistic as censored values")


# ================================================================================================ C26
def c26():
    """Variance-gated edge decision (D05) on realizable strips. A = batch/early-reject computation (fast path),
    B = exact proof verification. Reference = features.distance (float, forward order).
    I : A_I = exact-rational evaluation with early reject (integer sums); B_I = output the decisive check as a minimal
        support and verify it with the REFERENCE float sequence before use.
    II: A_II = reversed-order float batch with an error interval, deciding away from 100;
        B_II = proof-carrying output: near-threshold cases fall back to the reference sequence."""
    rng = random.Random(2626)
    inputs = {"near_threshold_grey": [_grey_pair(rng, near=True) for _ in range(200)],
              "realizable_mixed": [_grey_pair(rng) for _ in range(200)]}

    def run(inp, d, a, b):
        flips = verified = fallback = 0
        for pa, pb in inp:
            ref = F.distance(pa, pb)
            if not a:
                got = ref
            elif d == "I":
                got = F.distance(pa, pb, exact=True)
                if b:
                    verified += 1
                    if got[0] != ref[0]:
                        got = ref                     # verification with reference semantics rejects the fast result
            else:
                r, used = F.distance_fast_with_fallback(pa, pb, eps=(1e-6 if b else -1), fast="float_rev")
                got, fallback = r, fallback + used
            flips += got[0] != ref[0]
        return {"m": flips, "cost": {"verifications": verified, "fallbacks": fallback}, "ok": flips == 0}
    return study("C26", "decision flips vs the reference float evaluation (200 strip pairs)", "lower", inputs, run,
                 {"I": "exact-rational early-reject fast path + minimal support verified with reference semantics",
                  "II": "reversed-order float batch + near-threshold fallback (proof-carrying)"},
                 "I always verifies the decisive check; II verifies only inside an eps band around the threshold")


# ================================================================================================ C27
def c27():
    """Trajectory of 12 navigation steps every 20 units; required work 10 for the target unless already prepared.
    2 workers. A = prediction-driven preparation, B = robust protection.
    I : A_I = speculation: prepare the predicted NEXT target (service s); B_I = hard physical reserve of 1 worker.
    II: A_II = retention: keep the previous target prepared (no extra work, uses the cache slot);
        B_II = service-bound + drift gate: speculative work only if s <= 10 and not after 2 consecutive misses."""
    def traj(kind):
        if kind == "stable_forward":
            return list(range(12))
        if kind == "back_and_forth":
            return [0, 1, 0, 1, 2, 1, 2, 3, 2, 3, 4, 3]
        return [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1][::1]

    def run(inp, d, a, b):
        kind, s = inp
        tr = traj(kind)
        prepared = set()
        lat = wasted = 0
        busy = [0, 0]
        misses = 0
        for k, tgt in enumerate(tr):
            now = 20 * k
            tau = now
            if tgt not in prepared:
                i = min(range(2), key=lambda j: max(now, busy[j]))
                st = max(now, busy[i])
                busy[i] = st + 10
                lat += st + 10 - now
                tau = st + 10                      # speculation decisions are taken when the required work ends
            prepared = {tgt}
            if a and d == "II" and k > 0:
                prepared.add(tr[k - 1])            # retention: keep the previous target prepared (no extra work)
            spec = a and d == "I"
            if d == "II" and b and a:
                spec = s <= 10 and misses < 2      # service-bound + drift gate (II also speculates when allowed)
            if spec:
                free = [j for j in range(2) if busy[j] <= tau]
                if d == "I" and b and len(free) < 2:
                    free = []                      # hard reserve: never take the last free worker
                if free:
                    j = free[0]
                    busy[j] = tau + s
                    hit = k + 1 < len(tr) and tr[k + 1] == tgt + 1 and tau + s <= now + 20
                    if hit:
                        prepared.add(tgt + 1)
                        misses = 0
                    else:
                        wasted += s
                        misses += 1
        return {"m": lat, "cost": {"wasted_work": wasted}, "ok": True}
    inputs = {"stable_forward_s10": ("stable_forward", 10), "back_and_forth_s10": ("back_and_forth", 10),
              "reversal_adversary_s10": ("reversal", 10), "stable_forward_s50_no_bound": ("stable_forward", 50)}
    return study("C27", "total required latency over the trajectory (model units)", "lower", inputs, run,
                 {"I": "predictive speculation of the next target + hard reserve of one worker",
                  "II": "predictive retention of the previous target + service/drift-gated speculation"},
                 "I spends work ahead and protects by capacity; II spends cache space and protects by declared service "
                 "bounds and drift detection")


# ================================================================================================ C28
def c28():
    """Fixed alternative rule Γ'_local (exp_gamma2.gamma_prime_local; never compared as a Route A gain). Facts are
    acquired by an adaptive loop until the target's Γ' unit is fixed. A = target-projection certificate construction,
    B = query strategy.
    I : A_I = certificate = the bounded decision window of Γ'_local (objects t-2..t+3) ; B_I = adaptive: acquire one
        distinguishing fact at a time (the window object nearest t first).
    II: A_II = boundary message: the decision for pair i needs strengths s_{i-1}, s_i, s_{i+1}: acquire exactly those
        objects' facts; B_II = parallel batch of all still-missing window facts per round (4 workers).
    0 = recompute Γ' globally (all facts)."""
    from exp_gamma2 import gamma_prime_local
    rng = random.Random(2828)
    ws = [(E.random_world(30, rng), rng.randrange(5, 25)) for _ in range(60)]

    def gp_unit(case, t):
        for u in gamma_prime_local(case):
            if any(o == t for o, *_ in u):
                return u
        raise KeyError

    def run(inp, d, a, b):
        facts = rounds = wrong = 0
        for w, t in ws:
            case = G.make_case(*w, ST)
            truth = gp_unit(case, t)
            if not a:
                facts += 30
                rounds += 1 if b else 30
                continue
            if d == "I":
                need = list(range(max(0, t - 2), min(30, t + 4)))
            else:
                need = sorted({o for i in (t - 2, t - 1, t, t + 1) for o in (i - 1, i, i + 1, i + 2) if 0 <= o < 30})
            facts += len(need)
            if b:
                rounds += -(-len(need) // 4) if d == "II" else len(need)
            else:
                rounds += len(need)
            known = set(need)
            states, sides, scores = w
            sub = G.make_case(states, sides, scores, ST, known=known, edge_known={i for i in known if i + 1 in known})
            try:
                got = gp_unit(sub, t)
            except KeyError:
                got = None
            wrong += got != truth
        return {"m": facts, "cost": {"rounds": rounds, "wrong_units_vs_full_Gamma_prime": wrong}, "ok": wrong == 0}
    return study("C28", "facts acquired to fix the target under fixed Γ'_local (60 targets)", "lower", {"gamma_prime_local": None}, run,
                 {"I": "window certificate + one-at-a-time adaptive acquisition",
                  "II": "boundary-message support (strength neighbourhood) + parallel batches"},
                 "I certifies with a fixed window; II with the exact neighbourhood the Γ' decision uses",
                 notes={"route": "B (alternative rule); no claim about Γ"})


# ================================================================================================ C29
def c29():
    """Two layout versions coexist with an old frame. Resources (units): decoded low-level object 12, per-version
    adaptation work 2 and residency 4, high-level adapted result 6 (valid only if the adaptation parameters are equal).
    A = sharing level, B = stable layout snapshot (old version kept until its frame retires).
    I : A_I = share the low-level decode, adapt per version; B_I = per-version authorisation with snapshot kept.
    II: A_II = share the immutable high-level result, versions hold leases + mapping; B_II = lease-held snapshot."""
    scen = {"orientation_same": True, "direction_changed": False}

    def run(inp, d, a, b):
        same = scen[inp]
        work = resident = 0
        late_release = 0
        if not a:
            work = 2 * (12 + 2)
            resident = 2 * (12 + 4)
        elif d == "I":
            work = 12 + 2 * 2
            resident = 12 + 2 * 4
        else:
            if same:
                work = 12 + 2
                resident = 12 + 6
            else:                          # high-level result not shareable across different adaptation parameters
                work = 12 + 2 + 12 + 2
                resident = 2 * (12 + 6)
        if not b:
            resident -= (4 if (a and d == "I") else 6 if (a and d == "II" and same) else 16)  # old version dropped early
            late_release = 1                 # old frame still references a released version -> unsafe
        return {"m": resident, "cost": {"transform_work": work, "unsafe_early_release": late_release}, "ok": late_release == 0}
    return study("C29", "peak resident units with two coexisting layout versions", "lower", {k: k for k in scen}, run,
                 {"I": "low-level shared, per-version adaptation and authorisation",
                  "II": "high-level immutable result shared, versions hold leases and mappings"},
                 "I duplicates adaptations; II duplicates nothing when parameters agree and everything when they differ")


# ================================================================================================ C30
def c30():
    """Decision over three candidate domains, using artifacts of this package only:
      D1 main gate (30.19685 ms median) - relaxation bound raw/pass1/reach.json;
      D2 bounded result pool (C05/Q028) - model benefit only, no product timing;
      D3 pruned entry relation (Q053 route B') - model benefit only.
    A = narrow-domain enable candidate (shadow-checked trial in a closed domain), B = headroom/risk verdict.
    I : A_I = shadow refinement check before a closed-domain trial; B_I = verdict after the shadow evidence.
    II: A_II = trial design only for domains not excluded; B_II = relaxation lower bound applied FIRST.
    Metric: number of domains for which an engineering trial is (wrongly) proposed for the MAIN gate."""
    reach = json.load(open(RAW / "pass1/reach.json", encoding="utf-8"))
    minred = reach["F0_min_reduction"]["min_total_reduction_ns"]
    domains = {"D1_main_gate": {"headroom_possible": minred <= 0, "shadow_cost": 3},
               "D2_result_pool": {"headroom_possible": None, "shadow_cost": 1},
               "D3_pruned_entries": {"headroom_possible": None, "shadow_cost": 2}}

    def run(inp, d, a, b):
        proposed_main = 0
        cost = 0
        trials = []
        for name, x in domains.items():
            if b and d == "II" and x["headroom_possible"] is False:
                continue                                   # excluded before any trial work
            if a:
                cost += x["shadow_cost"]
                if b and d == "I" and x["headroom_possible"] is False:
                    continue                               # excluded after shadow evidence
                trials.append(name)
                proposed_main += name == "D1_main_gate"
            elif not b:
                trials.append(name)
                proposed_main += name == "D1_main_gate"
        return {"m": proposed_main, "cost": {"shadow_cost": cost, "trials": trials}, "ok": proposed_main == 0}
    return study("C30", "engineering trials proposed for the MAIN 30.19685 ms gate (should be 0)", "lower", {"package_artifacts": None}, run,
                 {"I": "shadow refinement first, verdict after evidence",
                  "II": "relaxation lower bound first, trials only for non-excluded domains"},
                 "I spends shadow work before excluding; II excludes by bound and spends nothing on D1",
                 notes={"min_total_reduction_ns": minred})
