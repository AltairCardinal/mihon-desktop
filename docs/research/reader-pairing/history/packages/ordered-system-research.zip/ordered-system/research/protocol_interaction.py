"""E7: D_proof shrink vs D_work, on the synthetic protocol slice (protocol.py).

Situation: a certificate stops depending on fact b while the acquisition task
for b is in flight (support shrink from a branching certifier or a widened
window).  Policies:
  CANCEL  cancel the task for b as soon as it leaves the proof support;
  KEEP    leave it running; consume it when it finishes (H8: prompt accept).
Afterwards another consumer requires b again.  We enumerate every interleaving
of the remaining events and count task admissions (physical work starts),
'cancelling' refusals, 'full' refusals and peak occupancy.  Synthetic slice
only: no time, no real scheduler.
"""
import itertools
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from protocol import run_event_trace  # noqa: E402


def scenario(policy, order, capacity):
    """order: permutation of the three asynchronous happenings
       F = the original task for b finishes,
       R = second consumer requests b (required),
       C = unrelated task c requested (required).
    Capacity >= 2 so that b is actually in flight (with capacity 1 the first
    request for b is refused and the question does not arise)."""
    ev = [dict(op='request', key='a', required=True), dict(op='request', key='b', required=True),
          dict(op='finish', key='a'), dict(op='consume', key='a')]
    if policy == 'CANCEL':
        ev.append(dict(op='cancel', key='b'))
    finished = False
    for x in order:
        if x == 'F':
            finished = True
            ev.append(dict(op='finish', key='b'))
            if policy == 'KEEP':
                ev.append(dict(op='consume', key='b'))   # prompt acceptance (H8)
        elif x == 'R':
            # the request event is always issued; under KEEP after F it is
            # classified below as a knowledge hit (b already consumed into K)
            ev.append(dict(op='request', key='b', required=True))
        else:
            ev.append(dict(op='request', key='c', required=True))
    out = run_event_trace(dict(capacity=capacity, events=ev))
    outcomes = [o['outcome'] for o in out]
    assert outcomes[1] == 'admitted', 'b must be in flight'
    # b is in K at the time of R only if its completion was actually consumed
    known_at = {}
    b_known = False
    for idx, (e, o) in enumerate(zip(ev, outcomes)):
        if e['op'] == 'consume' and e['key'] == 'b' and o == 'consumed':
            b_known = True
        known_at[idx] = b_known
    starts = 1                      # the original task for b
    refused = 0
    rr = [i for i, e in enumerate(ev) if e['op'] == 'request' and e['key'] == 'b' and i > 1][0]
    if known_at[rr]:
        hit = 'knowledge'           # the consumer reads b from K; the issued request is not needed
        assert finished
    elif outcomes[rr] == 'reused':
        hit = 'reused'
    elif outcomes[rr] == 'admitted':
        hit = 'restarted'
        starts += 1
    else:                            # 'cancelling' or 'full': must retry after the old task exits
        hit = 'refused_then_restart'
        refused += 1
        starts += 1
    return dict(policy=policy, order=''.join(order), capacity=capacity, outcomes=outcomes,
                rerequest=hit, b_task_starts=starts, refused=refused,
                peak_occupancy=max(o['occupied'] for o in out))


def run():
    rows = []
    for capacity in (2, 3):
        for order in itertools.permutations('FRC'):
            for policy in ('CANCEL', 'KEEP'):
                rows.append(scenario(policy, order, capacity))
    agg = {}
    for policy in ('CANCEL', 'KEEP'):
        rs = [r for r in rows if r['policy'] == policy]
        agg[policy] = dict(traces=len(rs), b_task_starts=sum(r['b_task_starts'] for r in rs),
                           duplicate_b_work=sum(1 for r in rs if r['b_task_starts'] > 1),
                           refusals=sum(r['refused'] for r in rs),
                           peak_occupancy_max=max(r['peak_occupancy'] for r in rs))
    # paired dominance check
    worse = []
    for c in rows:
        if c['policy'] != 'KEEP':
            continue
        other = next(r for r in rows if r['policy'] == 'CANCEL' and r['order'] == c['order']
                     and r['capacity'] == c['capacity'])
        if c['b_task_starts'] > other['b_task_starts'] or c['refused'] > other['refused'] \
                or c['peak_occupancy'] > other['peak_occupancy']:
            worse.append((c['order'], c['capacity']))
    agg['keep_worse_than_cancel'] = worse
    return dict(aggregate=agg, rows=rows)


if __name__ == '__main__':
    res = run()
    out = Path(__file__).resolve().parent / 'results'
    out.mkdir(exist_ok=True)
    (out / 'E7.json').write_text(json.dumps(res, indent=1))
    print(json.dumps(res['aggregate'], indent=1))
    for r in res['rows']:
        if r['capacity'] == 2:
            print(r['policy'], r['order'], r['outcomes'], 'b_starts', r['b_task_starts'], 'peak', r['peak_occupancy'])
