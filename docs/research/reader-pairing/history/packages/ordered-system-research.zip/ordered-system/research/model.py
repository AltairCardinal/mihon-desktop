"""Independent possible-world model for the ordered-system research package.

This module does NOT reuse certify().  Its only dependency on the reference is
complete_plan(), which README designates as the full-information semantic
oracle.  Everything here is research code (new file), Python 3.10+, stdlib only.

World model (branch alpha, default):
  * a computed analysis whose geometry is valid and whose rotation/orientation
    match the item identity is exact;
  * otherwise, a header whose geometry is valid and matches identity fixes the
    occupancy state (header geometry is authoritative);  side stays unknown;
  * otherwise the state is free in {NARROW, WIDE}; side free in {A,B,UNKNOWN};
  * an edge between two NARROW items is free in {null} U R (or R>=0 when
    nonneg=True) unless it is visible as computed through two valid analyses;
    an edge touching a WIDE item is the known null.
Branch beta (header_authoritative=False) lets a header-backed state be wrong.
"""
from fractions import Fraction
import itertools
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402

STATES = ('NARROW', 'WIDE')
SIDES = ('A', 'B', 'UNKNOWN')


# ----------------------------------------------------------------- facts ----
def make_fact(state, side='UNKNOWN', rotation=0, orientation=1):
    if state == 'FAILED':
        return dict(state='FAILED', width=0, height=0, rotation=rotation,
                    orientation=orientation, side=side)
    w, h = (200, 100) if state == 'WIDE' else (100, 200)
    if rotation in (90, 270):
        w, h = h, w
    return dict(state=state, width=w, height=h, rotation=rotation,
                orientation=orientation, side=side)


def _valid_for(fact, ident):
    f = ref._fact(fact)
    return (f is not None and ref._geometry(f) and f['rotation'] == ident['rotation']
            and f['orientation'] == ident['orientation'])


def canon(unit):
    return json.dumps(unit, sort_keys=True)


# ------------------------------------------------------------ knowledge ----
class Knowledge:
    """Parsed view of a case: what is fixed and what is free (world model)."""

    def __init__(self, case, header_authoritative=True):
        self.case = case
        self.items = case['items']
        self.n = len(self.items)
        s = case.get('settings', {})
        self.automatic = s.get('automatic', False)
        self.ident = [dict(id=x.get('id', str(i)), rotation=x.get('rotation', 0),
                           orientation=x.get('orientation', 1))
                      for i, x in enumerate(self.items)]
        self.state, self.side, self.valid = [], [], []
        for i, it in enumerate(self.items):
            a = it.get('analysis', {'status': 'unknown'})
            ok = a.get('status') == 'computed' and _valid_for(a.get('fact'), self.ident[i])
            self.valid.append(ok)
            if ok:
                f = ref._fact(a['fact'])
                self.state.append(f['state'])
                self.side.append(f['side'])
                continue
            h = it.get('header')
            if header_authoritative and h is not None and _valid_for(h, self.ident[i]):
                self.state.append(ref._fact(h)['state'])
            else:
                self.state.append(None)
            self.side.append(None)
        edges = {(e['first'], e['second']): e for e in case.get('edges', [])}
        self.rank = {}          # j -> ('known', value) | ('free',)
        for j in range(self.n - 1):
            e = edges.get((j, j + 1))
            if self.valid[j] and self.valid[j + 1] and e is not None and e.get('status') == 'computed' \
                    and self.state[j] == 'NARROW' and self.state[j + 1] == 'NARROW':
                self.rank[j] = ('known', e.get('score', None))
            else:
                self.rank[j] = ('free',)
        self.known_scores = sorted({x[1] for x in self.rank.values()
                                    if x[0] == 'known' and x[1] is not None})


def rank_grid(known, k, nonneg=False):
    """Representative values: every order type of k unknowns versus knowns."""
    k = max(k, 1)
    vals = [Fraction(v).limit_denominator(10**6) if not isinstance(v, Fraction) else v for v in known]
    pts = set(vals)
    if not vals:
        pts.update(Fraction(i) for i in range(k))
        return sorted(pts)
    lo, hi = vals[0], vals[-1]
    if nonneg:
        if lo > 0:
            pts.add(Fraction(0))
            pts.update(lo * Fraction(i + 1, k + 1) for i in range(k))
    else:
        pts.update(lo - 1 - i for i in range(k))
    pts.update(hi + 1 + i for i in range(k))
    for a, b in zip(vals, vals[1:]):
        pts.update(a + (b - a) * Fraction(i + 1, k + 1) for i in range(k))
    return sorted(pts)


def _as_number(v):
    if isinstance(v, Fraction):
        return float(v) if v.denominator != 1 else int(v)
    return v


def build_world_case(case, states, sides, ranks):
    """A complete case: every analysis computed and every edge computed."""
    items = []
    for i, it in enumerate(case['items']):
        rot, ori = it.get('rotation', 0), it.get('orientation', 1)
        items.append(dict(id=it.get('id', str(i)), content_version=it.get('content_version', 0),
                          rotation=rot, orientation=ori,
                          analysis=dict(status='computed', version=1,
                                        fact=make_fact(states[i], sides[i], rot, ori))))
    edges = []
    for j in range(len(items) - 1):
        edges.append(dict(first=j, second=j + 1, status='computed', version=1,
                          score=_as_number(ranks.get(j))))
    out = dict(items=items, edges=edges, settings=dict(case.get('settings', {})),
               generation=case.get('generation', 0), order_revision=case.get('order_revision', 0))
    return out


def target_unit(plan, target):
    return next(u for u in plan if any(s['item'] == target for s in u['slots']))


def _norm_settings(settings):
    return ref._Input(dict(items=[], settings=settings)).settings


def fast_unit(n, settings_norm, states, sides, ranks, target):
    """Same driver as reference.complete_plan, without deep copies; stops at the
    target's unit.  Cross-checked against complete_plan in test_research.py."""
    def dim(i):
        return dict(state=states[i])

    def side(i):
        return sides[i]

    def rank(a, b):
        if states[a] == 'WIDE' or states[b] == 'WIDE':
            return None
        v = ranks.get(a)
        return _as_number(v) if v is not None else None
    scan = ref._Scan(n, settings_norm, dim, side, side, rank)
    cursor = (0, True, -1)
    while cursor[0] < n:
        unit, cursor = scan.step(cursor)
        if any(s['item'] == target for s in unit['slots']):
            return unit
    raise AssertionError('target not covered')


def possible_units(case, target, nonneg=False, header_authoritative=True,
                   stop_at=None, horizon=3, cap=200000):
    """Exact set of target projections over Omega(K) (finite representatives).

    Facts beyond target+horizon are fixed (locality lemma: step(i) reads only
    items i-1..i+3 and edges (i,i+1),(i+1,i+2); left-going manual chains only).
    Returns (set_of_canonical_units, worlds_enumerated, truncated_flag).
    """
    K = Knowledge(case, header_authoritative)
    n = K.n
    lim = min(n - 1, target + horizon) if horizon is not None else n - 1
    free_items = [i for i in range(lim + 1) if K.state[i] is None]
    free_sides = [i for i in range(lim + 1) if K.side[i] is None] if K.automatic else []
    free_ranks = [j for j in range(min(n - 1, lim + 1)) if K.rank[j][0] == 'free'] if K.automatic else []
    grid = [None] + rank_grid(K.known_scores, len(free_ranks), nonneg)
    base_states = [s if s is not None else 'NARROW' for s in K.state]
    base_sides = [s if s is not None else 'UNKNOWN' for s in K.side]
    base_ranks = {j: (K.rank[j][1] if K.rank[j][0] == 'known' else None) for j in range(n - 1)}
    out, count = set(), 0
    sn = _norm_settings(case.get('settings', {}))
    for st in itertools.product(STATES, repeat=len(free_items)):
        states = list(base_states)
        for i, v in zip(free_items, st):
            states[i] = v
        live_ranks = [j for j in free_ranks if states[j] == 'NARROW' and states[j + 1] == 'NARROW']
        for sd in itertools.product(SIDES, repeat=len(free_sides)):
            sides = list(base_sides)
            for i, v in zip(free_sides, sd):
                sides[i] = v
            for rk in itertools.product(grid, repeat=len(live_ranks)):
                ranks = dict(base_ranks)
                for j in free_ranks:
                    ranks[j] = None
                for j, v in zip(live_ranks, rk):
                    ranks[j] = v
                count += 1
                if count > cap:
                    return out, count, True
                out.add(canon(fast_unit(n, sn, states, sides, ranks, target)))
                if stop_at is not None and len(out) >= stop_at:
                    return out, count, False
    return out, count, False


def sampled_units(case, target, rng, samples=200, nonneg=False, header_authoritative=True):
    """Monte-Carlo falsification: target units of random worlds in Omega(K).
    Used only where the exact enumeration is truncated (never a proof)."""
    K = Knowledge(case, header_authoritative)
    n = K.n
    free_ranks = [j for j in range(n - 1) if K.rank[j][0] == 'free']
    grid = [None] + rank_grid(K.known_scores, len(free_ranks), nonneg)
    sn = _norm_settings(case.get('settings', {}))
    out = set()
    for _ in range(samples):
        states = [s if s is not None else rng.choice(STATES) for s in K.state]
        sides = [s if s is not None else rng.choice(SIDES) for s in K.side]
        ranks = {j: (K.rank[j][1] if K.rank[j][0] == 'known' else rng.choice(grid)) for j in range(n - 1)}
        out.add(canon(fast_unit(n, sn, states, sides, ranks, target)))
    return out


# ------------------------------------------------------------ generators ----
def legal_settings(s, n):
    """Caller-side precondition check (research definition, see report)."""
    iso = set(s.get('hard_isolates', []))
    pins = sorted(set(s.get('pinned_links', [])))
    if any(not 0 <= x < n for x in iso):
        return False
    if any(not 0 <= p < n - 1 for p in pins):
        return False
    if any(b - a < 2 for a, b in zip(pins, pins[1:])):
        return False
    if any(p in iso or p + 1 in iso for p in pins):
        return False
    if s.get('opening', 'AUTO') == 'PAIR':
        if n < 2 or 1 in pins or 0 in iso or 1 in iso:
            return False
    return True


def random_world(rng, n, legal=True, nonneg=True, p_wide=0.25, automatic=None, side_bias=0.5):
    """A complete abstract world (extension domain; realizability not claimed)."""
    while True:
        k_iso = min(n, rng.choice([0, 0, 0, 1, 1, 2]))
        k_pin = min(max(0, n - 1), rng.choice([0, 0, 0, 1, 1, 2]))
        settings = dict(direction=rng.choice(['AB', 'BA']),
                        automatic=rng.random() < 0.6 if automatic is None else automatic,
                        hard_isolates=sorted(rng.sample(range(n), k_iso)),
                        pinned_links=sorted(rng.sample(range(n - 1), k_pin)) if n > 1 else [],
                        opening=rng.choice(['AUTO', 'AUTO', 'SINGLE', 'PAIR']), revision=0)
        if n < 2:
            settings['pinned_links'] = []
        if not legal or legal_settings(settings, n):
            break
    states = ['WIDE' if rng.random() < p_wide else 'NARROW' for _ in range(n)]
    sides = [rng.choice(SIDES) if rng.random() < side_bias else 'UNKNOWN' for _ in range(n)]
    pool = [None, 0, 1, 2] if nonneg else [None, -1, 0, 1, 2]
    ranks = {j: rng.choice(pool) for j in range(n - 1)}
    return dict(n=n, settings=settings, states=states, sides=sides, ranks=ranks)


def mask_world(rng, world, p_analysis=0.6, p_header=0.5, p_edge=0.7, p_fail=0.08, p_stale=0.03):
    """Partial knowledge K drawn from a world: hides, fails or staleness."""
    n = world['n']
    items = []
    for i in range(n):
        it = dict(id=f'i{i}', content_version=0, rotation=0, orientation=1)
        st, sd = world['states'][i], world['sides'][i]
        r = rng.random()
        if r < p_fail:
            it['analysis'] = dict(status='failed', reason=rng.choice(['READ', 'RESOURCE']))
        elif r < p_fail + p_stale:
            stale = make_fact(st, sd, 0, 1)
            stale['rotation'] = 90          # stale transform -> invalid evidence
            it['analysis'] = dict(status='computed', version=1, fact=stale)
        elif r < p_fail + p_stale + p_analysis:
            it['analysis'] = dict(status='computed', version=1, fact=make_fact(st, sd))
        else:
            it['analysis'] = dict(status='unknown')
        if rng.random() < p_header:
            it['header'] = make_fact(st, 'UNKNOWN')
        items.append(it)
    edges = []
    for j in range(n - 1):
        r = rng.random()
        if r < p_fail:
            edges.append(dict(first=j, second=j + 1, status='failed', failures={str(j): 'RESOURCE'}))
        elif r < p_fail + p_edge:
            edges.append(dict(first=j, second=j + 1, status='computed', version=1,
                              score=world['ranks'][j]))
    return dict(items=items, edges=edges, settings=dict(world['settings']), generation=0, order_revision=0)


def full_case(world):
    """The complete case of a world (all evidence computed)."""
    stub = dict(items=[dict(id=f'i{i}', content_version=0, rotation=0, orientation=1)
                       for i in range(world['n'])], settings=world['settings'])
    return build_world_case(stub, world['states'], world['sides'], world['ranks'])


def reveal(case, world, kind, a):
    """Acquire one fact of the true world into case (returns new case)."""
    import copy
    c = copy.deepcopy(case)
    if kind == 'ANALYSIS':
        c['items'][a]['analysis'] = dict(status='computed', version=1,
                                         fact=make_fact(world['states'][a], world['sides'][a]))
    elif kind == 'RANK':
        c['edges'] = [e for e in c['edges'] if (e['first'], e['second']) != (a, a + 1)]
        c['edges'].append(dict(first=a, second=a + 1, status='computed', version=1,
                               score=world['ranks'][a]))
    else:
        raise ValueError(kind)
    return c


if __name__ == '__main__':
    rng = random.Random(1)
    w = random_world(rng, 5)
    c = mask_world(rng, w)
    print(possible_units(c, 2))
