"""Research prototypes for the ordered-system package (new files only)."""
