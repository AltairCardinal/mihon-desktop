"""Reproducible experiments.  Usage:
    python research/experiments.py E1 [--quick]
    python research/experiments.py all [--quick]
Writes research/results/<name>.json and prints a summary.  All seeds fixed.
Instances are ABSTRACT EXTENSION-DOMAIN worlds (scalar labels/ranks chosen
directly); counts are construction-domain frequencies, not workload rates.
"""
import copy
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402
from research import model as M  # noqa: E402
from research.branching import certify_pw, certify_sl, certify_contract  # noqa: E402
from research import validity as V  # noqa: E402

OUT = Path(__file__).resolve().parent / 'results'
QUICK = '--quick' in sys.argv


def pct(xs, q):
    if not xs:
        return None
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * (len(xs) - 1) + 0.5))]


def summary(xs):
    if not xs:
        return dict(n=0)
    return dict(n=len(xs), sum=sum(xs), mean=round(statistics.mean(xs), 3),
                p50=pct(xs, .5), p90=pct(xs, .9), max=max(xs))


def save(name, obj):
    OUT.mkdir(exist_ok=True)
    (OUT / f'{name}.json').write_text(json.dumps(obj, indent=1, sort_keys=True, default=str))


# ------------------------------------------------------------------ E1 ----
DOMAINS = {
    # name: (legal_settings, nonneg_ranks, rank interpretation for oracle/engines)
    'legal_nonneg': (True, True),
    'interface_signed': (False, False),
}


def e1(seed=11, per_n=None):
    """Certification gap: reference / H-G strategy / C-PW / C-SL / wrapper vs oracle."""
    per_n = per_n or (60 if QUICK else 400)
    report = {}
    for dname, (legal, nonneg) in DOMAINS.items():
        rng = M.random.Random(seed)
        rows = []
        skipped = 0
        for n in range(2, 8):
            made = 0
            while made < per_n:
                w = M.random_world(rng, n, legal=legal, nonneg=nonneg)
                c = M.mask_world(rng, w)
                t = rng.randrange(n)
                U, cnt, tr = M.possible_units(c, t, nonneg=nonneg, cap=40000)
                if tr:
                    skipped += 1
                    continue
                made += 1
                uniq = len(U) == 1
                truth = next(iter(U)) if uniq else None
                r = ref.certify(c, t)
                s = ref.certify_strategy(c, t)
                p = certify_pw(c, t, nonneg=nonneg)
                p0 = certify_pw(c, t, nonneg=nonneg, extension='budget', budget=0)
                ph = certify_pw(c, t, nonneg=nonneg, extension='heuristic')
                sl = certify_sl(c, t, nonneg=nonneg)
                sl0 = certify_sl(c, t, nonneg=nonneg, extension='budget', budget=0)
                wr = certify_contract(c, t, engine=certify_sl, nonneg=nonneg)
                wrp = certify_contract(c, t, engine=certify_pw, nonneg=nonneg)

                def ok(x):
                    return x['status'] == 'certified'

                def sound(x):
                    return (not ok(x)) or (uniq and M.canon(x['unit']) == truth)
                rows.append(dict(
                    n=n, uniq=uniq, worlds=cnt,
                    ref=r['status'], ref_steps=r['steps'], ref_reads=len(r['reads']),
                    strat=s['selected']['status'], strat_steps=s['total_steps'],
                    pw=ok(p), pw_steps=p['steps'], pw_nodes=p['branch_nodes'], pw_windows=p['windows'],
                    pw0=ok(p0), pwh=ok(ph), pwh_steps=ph['steps'],
                    sl=ok(sl), sl_steps=sl['steps'], sl_nodes=sl['branch_nodes'], sl_windows=sl['windows'],
                    sl0=ok(sl0), sl0_steps=sl0['steps'],
                    wr=ok(wr['selected']), wr_steps=wr['total_steps'],
                    wrp=ok(wrp['selected']), wrp_steps=wrp['total_steps'],
                    sound=dict(ref=sound(r), strat=sound(s['selected']), pw=sound(p), pw0=sound(p0),
                               pwh=sound(ph), sl=sound(sl), sl0=sound(sl0), wr=sound(wr['selected']),
                               wrp=sound(wrp['selected'])),
                    pw_support=len(p['support']) if ok(p) else None,
                    pw_extra_fail=bool(p['extra_failures']) if ok(p) else None,
                    wr_extra_fail=bool(wr['selected'].get('extra_failures')),
                ))
        report[dname] = dict(rows=rows, skipped_truncated=skipped, seed=seed, per_n=per_n)
    agg = {}
    for dname, d in report.items():
        rows = d['rows']
        N = len(rows)
        cnt = lambda f: sum(1 for x in rows if f(x))  # noqa: E731
        agg[dname] = dict(
            instances=N, skipped=d['skipped_truncated'], seed=seed,
            oracle_unique=cnt(lambda x: x['uniq']),
            ref_certified=cnt(lambda x: x['ref'] == 'certified'),
            ref_blocked=cnt(lambda x: x['ref'] == 'blocked'),
            ref_blocked_but_unique=cnt(lambda x: x['ref'] == 'blocked' and x['uniq']),
            ref_need_but_unique=cnt(lambda x: x['ref'] == 'need_facts' and x['uniq']),
            strategy_certified=cnt(lambda x: x['strat'] == 'certified'),
            pw_exhaustive=cnt(lambda x: x['pw']), pw_no_extension=cnt(lambda x: x['pw0']),
            pw_heuristic=cnt(lambda x: x['pwh']),
            sl_exhaustive=cnt(lambda x: x['sl']), sl_no_extension=cnt(lambda x: x['sl0']),
            wrapper_sl=cnt(lambda x: x['wr']), wrapper_pw=cnt(lambda x: x['wrp']),
            wrapper_sl_extra_failure_reported=cnt(lambda x: x['wr_extra_fail']),
            unsound={k: cnt(lambda x, k=k: not x['sound'][k]) for k in rows[0]['sound']},
            dominance_violations=dict(
                pw=cnt(lambda x: x['ref'] == 'certified' and not x['pw']),
                sl=cnt(lambda x: x['ref'] == 'certified' and not x['sl']),
                sl_vs_strategy=cnt(lambda x: x['strat'] == 'certified' and not x['sl']),
                wr_vs_strategy=cnt(lambda x: x['strat'] == 'certified' and not x['wr'])),
            cost=dict(ref_steps=summary([x['ref_steps'] for x in rows]),
                      strategy_steps=summary([x['strat_steps'] for x in rows]),
                      wrapper_sl_steps=summary([x['wr_steps'] for x in rows]),
                      wrapper_pw_steps=summary([x['wrp_steps'] for x in rows]),
                      sl_steps=summary([x['sl_steps'] for x in rows]),
                      sl_nodes=summary([x['sl_nodes'] for x in rows]),
                      sl0_steps=summary([x['sl0_steps'] for x in rows]),
                      pw_steps=summary([x['pw_steps'] for x in rows]),
                      pw_nodes=summary([x['pw_nodes'] for x in rows]),
                      pwh_steps=summary([x['pwh_steps'] for x in rows]),
                      sl_windows=summary([x['sl_windows'] for x in rows])),
            need_rows=dict(
                count=cnt(lambda x: x['ref'] == 'need_facts'),
                strategy_steps=summary([x['strat_steps'] for x in rows if x['ref'] == 'need_facts']),
                wrapper_sl_steps=summary([x['wr_steps'] for x in rows if x['ref'] == 'need_facts']),
                strategy_adopted=cnt(lambda x: x['ref'] == 'need_facts' and x['strat'] == 'certified'),
                wrapper_sl_adopted=cnt(lambda x: x['ref'] == 'need_facts' and x['wr']),
                wrapper_sl_steps_when_adopted=summary([x['wr_steps'] for x in rows if x['ref'] == 'need_facts' and x['wr']]),
                wrapper_sl_steps_when_not_adopted=summary([x['wr_steps'] for x in rows if x['ref'] == 'need_facts' and not x['wr']]),
                truly_undetermined=cnt(lambda x: x['ref'] == 'need_facts' and not x['uniq'])),
            by_n={n: dict(N=cnt(lambda x, n=n: x['n'] == n),
                          uniq=cnt(lambda x, n=n: x['n'] == n and x['uniq']),
                          ref=cnt(lambda x, n=n: x['n'] == n and x['ref'] == 'certified'),
                          strat=cnt(lambda x, n=n: x['n'] == n and x['strat'] == 'certified'),
                          wr_sl=cnt(lambda x, n=n: x['n'] == n and x['wr']))
                  for n in range(2, 8)})
    save('E1', dict(aggregate=agg))
    return agg


# ------------------------------------------------------------------ E2 ----
def _apply_needs(case, world, needs):
    """One parallel acquisition round.  RANK needs whose endpoints lack a valid
    analysis at round start acquire the endpoints instead (dependency)."""
    K = M.Knowledge(case)
    items, ranks = set(), set()
    for nd in needs:
        i = nd['item']
        if nd['kind'] in ('ANALYSIS', 'DIMENSIONS'):
            if not K.valid[i]:
                items.add(i)
        else:
            if K.valid[i] and K.valid[i + 1]:
                if K.rank[i][0] != 'known':
                    ranks.add(i)
            else:
                items.update(x for x in (i, i + 1) if not K.valid[x])
    c = case
    for i in sorted(items):
        c = M.reveal(c, world, 'ANALYSIS', i)
    for j in sorted(ranks):
        c = M.reveal(c, world, 'RANK', j)
    return c, len(items), len(ranks)


def _pol_ref(c, t, nonneg):
    r = ref.certify(c, t)
    return r['status'], r['needs'], r['steps']


def _pol_strat(c, t, nonneg):
    s = ref.certify_strategy(c, t)
    return s['selected']['status'], s['selected']['needs'], s['total_steps']


def _pol_wr(engine, **kw):
    def f(c, t, nonneg):
        w = certify_contract(c, t, engine=engine, nonneg=nonneg, **kw)
        if w['selected']['status'] == 'certified':
            return 'certified', [], w['total_steps']
        e = w['engine']
        needs = e['needs'] if e is not None else w['baseline']['needs']
        # proof-relevant needs first; fall back to the reference needs
        return w['baseline']['status'], needs or w['baseline']['needs'], w['total_steps']
    return f


def _pol_wr_near(c, t, nonneg):
    """Wrapper certification, but acquire only the reference-window needs."""
    w = certify_contract(c, t, engine=certify_sl, nonneg=nonneg)
    if w['selected']['status'] == 'certified':
        return 'certified', [], w['total_steps']
    return w['baseline']['status'], w['baseline']['needs'], w['total_steps']


def min_certificate(case, world, t, nonneg, limit=6, cap=20000, call_budget=1500):
    """Smallest acquisition set making the target unique (exhaustive search).
    Returns (size, rounds) or (None, None) when unresolved: no set within
    `limit`, a smaller-size check was truncated, or the oracle-call budget ran out (deterministic, machine independent)
    (an unresolved world is excluded from lower-bound comparisons)."""
    import itertools
    calls = 0
    K = M.Knowledge(case)
    lim = min(K.n - 1, t + 3)
    cand = [('ANALYSIS', i) for i in range(lim + 1) if not K.valid[i]]
    if K.automatic:
        cand += [('RANK', j) for j in range(min(K.n - 1, lim + 1)) if K.rank[j][0] != 'known'
                 and world['states'][j] == 'NARROW' and world['states'][j + 1] == 'NARROW']
    for size in range(0, min(limit, len(cand)) + 1):
        truncated_here = False
        for combo in itertools.combinations(cand, size):
            if calls >= call_budget:
                return None, None
            items = {a for k, a in combo if k == 'ANALYSIS'}
            okdep = all(k != 'RANK' or ((K.valid[a] or a in items) and (K.valid[a + 1] or a + 1 in items))
                        for k, a in combo)
            if not okdep:
                continue
            c = case
            for k, a in sorted(combo):
                c = M.reveal(c, world, k, a)
            calls += 1
            U, _, tr = M.possible_units(c, t, nonneg=nonneg, stop_at=2, cap=cap)
            if tr and len(U) < 2:
                truncated_here = True
                continue
            if len(U) == 1:
                rounds = 2 if any(k == 'RANK' and not (K.valid[a] and K.valid[a + 1]) for k, a in combo) else (1 if combo else 0)
                return size, rounds
        if truncated_here:
            return None, None
    return None, None


def e2(seed=23, worlds=None, hard=False):
    """Cold-start acquisition: rounds and acquisitions until certification.
    easy: n 3..6, headers 70%, random settings.  hard: n 4..7, headers 20%,
    automatic on with few side labels (rank comparisons matter)."""
    worlds = worlds or (40 if QUICK else 240)
    rng = M.random.Random(seed)
    policies = dict(reference=_pol_ref, strategy=_pol_strat,
                    wrapper_sl_engineneeds=_pol_wr(certify_sl, early_exit=False),
                    wrapper_sl_refneeds=_pol_wr_near)
    res = {k: dict(rounds=[], analyses=[], ranks=[], steps=[], fail=0) for k in policies}
    lb, rows = [], []
    for _ in range(worlds):
        if hard:
            n = rng.randint(4, 7)
            w = M.random_world(rng, n, legal=True, nonneg=True, automatic=True, side_bias=0.2, p_wide=0.15)
            c0 = M.mask_world(rng, w, p_analysis=0.0, p_header=0.2, p_edge=0.0, p_fail=0.0, p_stale=0.0)
        else:
            n = rng.randint(3, 6)
            w = M.random_world(rng, n, legal=True, nonneg=True)
            c0 = M.mask_world(rng, w, p_analysis=0.0, p_header=0.7, p_edge=0.0, p_fail=0.0, p_stale=0.0)
        t = rng.randrange(n)
        row = dict(n=n, t=t)
        for name, pol in policies.items():
            c, rounds, na, nr, steps = c0, 0, 0, 0, 0
            while True:
                status, needs, st = pol(c, t, True)
                steps += st
                if status == 'certified':
                    break
                if not needs or rounds > 12:
                    res[name]['fail'] += 1
                    break
                c2, a, r = _apply_needs(c, w, needs)
                if a + r == 0:
                    res[name]['fail'] += 1
                    break
                c, rounds, na, nr = c2, rounds + 1, na + a, nr + r
            res[name]['rounds'].append(rounds)
            res[name]['analyses'].append(na)
            res[name]['ranks'].append(nr)
            res[name]['steps'].append(steps)
            row[name] = (rounds, na + nr)
        size, rnd = min_certificate(c0, w, t, True)
        lb.append(size)
        row['lower_bound'] = size
        rows.append(row)
    agg = {k: dict(rounds=summary(v['rounds']), analyses=summary(v['analyses']), ranks=summary(v['ranks']),
                   acquisitions=summary([a + b for a, b in zip(v['analyses'], v['ranks'])]),
                   steps=summary(v['steps']), failures=v['fail']) for k, v in res.items()}
    known_lb = [x for x in lb if x is not None]
    agg['lower_bound_min_acquisitions'] = dict(summary(known_lb), unresolved=len(lb) - len(known_lb))
    # paired comparison of acquisitions against the lower bound
    for k in policies:
        excess = [r[k][1] - r['lower_bound'] for r in rows if r['lower_bound'] is not None]
        agg[k]['excess_over_lower_bound'] = summary(excess)
        agg[k]['at_lower_bound'] = sum(1 for e in excess if e == 0)
    agg['seed'], agg['worlds'], agg['variant'] = seed, worlds, 'hard' if hard else 'easy'
    save('E2H' if hard else 'E2', agg)
    return agg


def e2h():
    return e2(seed=29, worlds=(30 if QUICK else 160), hard=True)


# ------------------------------------------------------------------ E3 ----
def _events(case, rng, res):
    """Yield (class, new_case, world_changed_positions, same_version)."""
    n = len(case['items'])
    reads_pos = set()
    for k in res['reads']:
        reads_pos.update(V._positions(k))
    far = [i for i in range(n) if i not in reads_pos]
    near = sorted(reads_pos)
    if far:
        i = rng.choice(far)
        c = copy.deepcopy(case)
        c['items'][i]['content_version'] = c['items'][i].get('content_version', 0) + 1
        c['items'][i]['analysis'] = dict(status='unknown')
        c['edges'] = [e for e in c['edges'] if i not in (e['first'], e['second'])]
        yield 'unrelated_content_change', c, {i}, False
        c = copy.deepcopy(case)
        c['items'][i]['header'] = M.make_fact('WIDE')
        yield 'unrelated_header_change', c, set(), True
    unknown_reads = [k for k, v in res['reads'].items() if k.startswith('analysis:') and isinstance(v, dict) and v.get('status') == 'unknown']
    if unknown_reads:
        i = int(rng.choice(unknown_reads).split(':')[1])
        yield 'refine_read_unknown_to_known', ('REFINE', i), set(), True
        yield 'refine_with_other_dimensions', ('REFINE_DIMS', i), set(), True
    if near:
        i = rng.choice(near)
        c = copy.deepcopy(case)
        c['items'][i]['content_version'] = c['items'][i].get('content_version', 0) + 1
        yield 'dependent_content_change', c, {i}, False
        c = copy.deepcopy(case)
        c['items'][i]['id'] = c['items'][i]['id'] + '_new'
        yield 'dependent_new_identity', c, {i}, False
        c = copy.deepcopy(case)
        a = c['items'][i].get('analysis', {})
        if a.get('status') == 'computed':
            a['version'] = a.get('version', 1) + 1
            yield 'dependent_algorithm_version', c, {i}, False
    c = copy.deepcopy(case)
    c['generation'] = c.get('generation', 0) + 1
    yield 'generation', c, set(), False
    c = copy.deepcopy(case)
    c.setdefault('settings', {})['revision'] = c['settings'].get('revision', 0) + 1
    yield 'rule_revision', c, set(), False


def e3(seed=31, count=None):
    """Validity scoping: invalidations and storage, with exact safety check."""
    count = count or (150 if QUICK else 1200)
    rng = M.random.Random(seed)
    stats, storage = {}, dict(reference=[], scoped=[])
    unsafe_keep = 0
    made = 0
    while made < count:
        n = rng.randint(4, 12)
        w = M.random_world(rng, n, legal=True, nonneg=True)
        c = M.mask_world(rng, w, p_analysis=0.75, p_header=0.6, p_edge=0.85, p_fail=0.0, p_stale=0.0)
        t = rng.randrange(n)
        res = ref.certify(c, t)
        if res['status'] != 'certified':
            continue
        made += 1
        snap = V.scoped_snapshot(res)
        storage['reference'].append(V.reference_cost(res))
        storage['scoped'].append(V.snapshot_cost(snap))
        for cls, newc, changed, same_version in _events(c, rng, res):
            if isinstance(newc, tuple):
                i = newc[1]
                newc = M.reveal(c, w, 'ANALYSIS', i)
                if cls == 'refine_with_other_dimensions':
                    f = newc['items'][i]['analysis']['fact']
                    f['width'], f['height'] = f['width'] * 3, f['height'] * 3   # same state, other size
            old_inv = ref.first_changed_read(res, newc) is not None
            new_inv = V.scoped_changed(snap, newc) is not None
            st = stats.setdefault(cls, dict(events=0, reference_invalidated=0, scoped_invalidated=0,
                                             kept_exact_verified=0, kept_sampled_only=0,
                                             scoped_kept_but_target_changed=0))
            st['events'] += 1
            st['reference_invalidated'] += old_inv
            st['scoped_invalidated'] += new_inv
            if not new_inv:
                # safety: the certified unit must remain the unique answer;
                # exact enumeration, or random-world falsification if truncated
                U, _, tr = M.possible_units(newc, t, nonneg=True, cap=40000)
                if tr:
                    U = M.sampled_units(newc, t, rng, samples=300, nonneg=True)
                    st['kept_sampled_only'] += 1
                else:
                    st['kept_exact_verified'] += 1
                if len(U) != 1 or next(iter(U)) != M.canon(res['unit']):
                    st['scoped_kept_but_target_changed'] += 1
                    unsafe_keep += 1
    # C-SL certificates adopted by the contract wrapper, validated through
    # support_snapshot (same events, same safety check)
    wstats, wmade, wunsafe = {}, 0, 0
    while wmade < (40 if QUICK else 300):
        n = rng.randint(4, 9)
        w = M.random_world(rng, n, legal=True, nonneg=True)
        c = M.mask_world(rng, w, p_analysis=0.6, p_header=0.5, p_edge=0.7, p_fail=0.0, p_stale=0.0)
        t = rng.randrange(n)
        wr = certify_contract(c, t, engine=certify_sl, nonneg=True)
        if not wr['adopted']:
            continue
        wmade += 1
        snap = wr['selected']['snapshot']
        pseudo = dict(reads=snap['reads'])
        for cls, newc, changed, same_version in _events(c, rng, pseudo):
            if isinstance(newc, tuple):
                newc = M.reveal(c, w, 'ANALYSIS', newc[1])
            inv = V.scoped_changed(snap, newc) is not None
            st = wstats.setdefault(cls, dict(events=0, invalidated=0, kept_but_target_changed=0))
            st['events'] += 1
            st['invalidated'] += inv
            if not inv:
                U, _, tr = M.possible_units(newc, t, nonneg=True, cap=40000)
                if tr:
                    U = M.sampled_units(newc, t, rng, samples=300, nonneg=True)
                if len(U) != 1 or next(iter(U)) != M.canon(wr['selected']['unit']):
                    st['kept_but_target_changed'] += 1
                    wunsafe += 1

    # scaling of per-certificate snapshot/validation units with n
    scaling = {}
    for n in (16, 64, 256):
        refc, scc, cut = [], [], 0
        for _ in range(20):
            w = M.random_world(rng, n, legal=True, nonneg=True)
            c = M.full_case(w)
            for t in rng.sample(range(n), 5):
                r = ref.certify(c, t)
                refc.append(V.reference_cost(r))
                scc.append(V.snapshot_cost(V.scoped_snapshot(r)))
        scaling[n] = dict(reference=summary(refc), scoped=summary(scc))
    out = dict(seed=seed, certificates=made, events=stats, unsafe_keep=unsafe_keep,
               storage=dict(reference=summary(storage['reference']), scoped=summary(storage['scoped'])),
               scaling_complete_knowledge=scaling,
               wrapper_certificates=dict(count=wmade, events=wstats, unsafe_keep=wunsafe))
    save('E3', out)
    return out


# ------------------------------------------------------------------ E4 ----
def lb_family(d, flip):
    """Lower-bound family: NARROW run, automatic off, opening AUTO, no
    constraints.  Item 1 is NARROW or WIDE (flip); the target is item 1+d."""
    n = d + 4
    states = ['NARROW'] * n
    if flip:
        states[1] = 'WIDE'
    return dict(n=n, settings=dict(direction='AB', automatic=False, hard_isolates=[], pinned_links=[],
                                   opening='AUTO', revision=0),
                states=states, sides=['UNKNOWN'] * n, ranks={j: None for j in range(n - 1)})


def e4(max_d=None):
    """Distance-d dependence (lower bound) and certifier work growth."""
    max_d = max_d or (12 if QUICK else 40)
    rows = []
    for d in range(1, max_d + 1):
        t = 1 + d
        w0, w1 = lb_family(d, False), lb_family(d, True)
        u0 = M.target_unit(ref.complete_plan(M.full_case(w0)), t)
        u1 = M.target_unit(ref.complete_plan(M.full_case(w1)), t)
        k = M.full_case(w0)
        k['items'][1]['analysis'] = dict(status='unknown')       # only item 1 unknown
        r = ref.certify(k, t)
        p = certify_sl(k, t)
        kfull = M.full_case(w0)
        rf = ref.certify(kfull, t)
        sf = certify_sl(kfull, t)
        pivotal = []
        for j in range(1, t):
            wj = lb_family(d, False)
            wj['states'][j] = 'WIDE'
            if j != t and M.canon(M.target_unit(ref.complete_plan(M.full_case(wj)), t)) != M.canon(u0):
                pivotal.append(j)
        rows.append(dict(d=d, units_differ=M.canon(u0) != M.canon(u1), single_flip_pivotal_items=pivotal,
                         certificate_lower_bound=len(pivotal),
                         ref_item1_unknown=r['status'], sl_item1_unknown=p['status'],
                         ref_needs=[x['item'] for x in r['needs']],
                         ref_full_first=rf['first'], ref_full_read_keys=len(rf['reads']) - 2,
                         ref_full_steps=rf['steps'], sl_full_first=sf['first'], sl_full_steps=sf['steps'],
                         sl_full_support=len(sf['support'])))
    save('E4', rows)
    return rows


# ------------------------------------------------------------------ E5 ----
def batch_forward(case, nonneg=False):
    """D5: certify every target in one forward C-SL pass from the exact start.
    Returns {target: unit or None} and total step count."""
    import heapq
    from research.branching import _local_outcomes, Counter, _local_grid
    data = ref._Input(case)
    K = M.Knowledge(case)
    settings = data.settings
    counter = Counter()
    reads, branched, failed = set(), set(), {}
    units = {}
    frontier, seen = [(0, False, False)], set()
    while frontier:
        i, no, r = heapq.heappop(frontier)
        if (i, no, r) in seen or i >= K.n:
            continue
        seen.add((i, no, r))
        cursor = (i, not no, i if r else -1)

        def one(scan, cursor=cursor):
            counter.steps += 1
            return scan.step(cursor)
        for unit, nxt in _local_outcomes(K, settings, _local_grid(K, (i, i + 1), nonneg), one,
                                         counter, reads, branched, failed):
            for s in unit['slots']:
                units.setdefault(s['item'], set()).add(M.canon(unit))
            heapq.heappush(frontier, (nxt[0], not nxt[1], nxt[2] == nxt[0]))
    return {t: (json.loads(next(iter(u))) if len(u) == 1 else None) for t, u in units.items()}, counter.steps


def e5(seed=41, count=None):
    count = count or (40 if QUICK else 200)
    rng = M.random.Random(seed)
    rows = []
    for _ in range(count):
        n = rng.choice([8, 16, 32, 64])
        w = M.random_world(rng, n, legal=True, nonneg=True)
        for label, kw in (('complete', dict(p_analysis=1.0, p_header=1.0, p_edge=1.0, p_fail=0.0, p_stale=0.0)),
                          ('partial', dict(p_analysis=0.8, p_header=0.5, p_edge=0.85, p_fail=0.0, p_stale=0.0))):
            c = M.mask_world(rng, w, **kw)
            per = [ref.certify(c, t) for t in range(n)]
            ref_steps = sum(x['steps'] for x in per)
            ref_cert = sum(1 for x in per if x['status'] == 'certified')
            units, bsteps = batch_forward(c, nonneg=True)
            b_cert = sum(1 for t in range(n) if units.get(t) is not None)
            agree = all(units.get(t) is None or x['status'] != 'certified' or units[t] == x['unit']
                        for t, x in enumerate(per))
            rows.append(dict(n=n, knowledge=label, ref_steps=ref_steps, ref_certified=ref_cert,
                             batch_steps=bsteps, batch_certified=b_cert, agree=agree))
    agg = {}
    for label in ('complete', 'partial'):
        for n in (8, 16, 32, 64):
            rs = [r for r in rows if r['n'] == n and r['knowledge'] == label]
            if rs:
                agg[f'{label}_n{n}'] = dict(cases=len(rs), ref_steps=summary([r['ref_steps'] for r in rs]),
                                            batch_steps=summary([r['batch_steps'] for r in rs]),
                                            ref_certified=sum(r['ref_certified'] for r in rs),
                                            batch_certified=sum(r['batch_certified'] for r in rs),
                                            disagreements=sum(not r['agree'] for r in rs))
    agg['seed'] = seed
    save('E5', agg)
    return agg


# ------------------------------------------------------------------ E6 ----
def e6():
    """Golden fixtures: generation-derived (G002/G005/G006) vs interface rows."""
    rows = []
    for line in (Path(__file__).resolve().parent.parent / 'fixtures' / 'golden.jsonl').open(encoding='utf-8'):
        g = json.loads(line)
        c, t = g['case'], g['target']
        U, cnt, tr = M.possible_units(c, t, nonneg=True, cap=200000)
        Us, _, _ = M.possible_units(c, t, nonneg=False, cap=200000)
        r = ref.certify(c, t)
        s = ref.certify_strategy(c, t)
        wr = certify_contract(c, t, engine=certify_sl, nonneg=False)
        wrn = certify_contract(c, t, engine=certify_sl, nonneg=True)
        pw = certify_pw(c, t)
        rows.append(dict(id=g['id'], origin='generation' if g['id'] in ('G002', 'G005', 'G006') else 'interface',
                         target=t, oracle_unique_nonneg=len(U) == 1, oracle_unique_signed=len(Us) == 1,
                         worlds=cnt, truncated=tr, ref=r['status'], ref_steps=r['steps'],
                         strategy=s['selected']['status'], strategy_steps=s['total_steps'],
                         wrapper_sl_signed=wr['selected']['status'], wrapper_sl_signed_steps=wr['total_steps'],
                         wrapper_sl_nonneg=wrn['selected']['status'],
                         pw_signed=pw['status'], pw_support=len(pw['support']),
                         unit_matches_full=(wr['selected']['status'] != 'certified' or
                                            wr['selected']['unit'] == M.target_unit(ref.complete_plan(g['full_case']), t))))
    save('E6', rows)
    return rows


# ------------------------------------------------------------------ E8 ----
def e8(seed=53, count=None):
    """Rank-focused domain (automatic on, few side labels/WIDE items, legal,
    non-negative ranks): marginal value of the non-negativity premise (H-C)
    once branching certification is in place."""
    count = count or (150 if QUICK else 1200)
    rng = M.random.Random(seed)
    rows, skipped = [], 0
    while len(rows) < count:
        n = rng.randint(3, 7)
        w = M.random_world(rng, n, legal=True, nonneg=True, automatic=True, side_bias=0.1, p_wide=0.1)
        c = M.mask_world(rng, w, p_analysis=0.75, p_header=0.5, p_edge=0.6, p_fail=0.0, p_stale=0.0)
        t = rng.randrange(n)
        Un, _, tr1 = M.possible_units(c, t, nonneg=True, cap=40000)
        Us, _, tr2 = M.possible_units(c, t, nonneg=False, cap=40000)
        if tr1 or tr2:
            skipped += 1
            continue
        r = ref.certify(c, t)
        s = ref.certify_strategy(c, t)
        ws = certify_contract(c, t, engine=certify_sl, nonneg=False)
        wn = certify_contract(c, t, engine=certify_sl, nonneg=True)
        rows.append(dict(uniq_nonneg=len(Un) == 1, uniq_signed=len(Us) == 1, ref=r['status'] == 'certified',
                         strat=s['selected']['status'] == 'certified', wr_signed=ws['selected']['status'] == 'certified',
                         wr_nonneg=wn['selected']['status'] == 'certified',
                         unsound_nonneg=wn['selected']['status'] == 'certified' and (len(Un) != 1 or M.canon(wn['selected']['unit']) != next(iter(Un))),
                         ref_steps=r['steps'], strat_steps=s['total_steps'], ws_steps=ws['total_steps'],
                         wn_steps=wn['total_steps']))
    cnt = lambda f: sum(1 for x in rows if f(x))  # noqa: E731
    out = dict(seed=seed, instances=len(rows), skipped=skipped,
               oracle_unique_nonneg=cnt(lambda x: x['uniq_nonneg']), oracle_unique_signed=cnt(lambda x: x['uniq_signed']),
               ref_certified=cnt(lambda x: x['ref']), strategy_certified=cnt(lambda x: x['strat']),
               wrapper_signed=cnt(lambda x: x['wr_signed']), wrapper_nonneg=cnt(lambda x: x['wr_nonneg']),
               unsound_nonneg=cnt(lambda x: x['unsound_nonneg']),
               steps=dict(ref=summary([x['ref_steps'] for x in rows]), strategy=summary([x['strat_steps'] for x in rows]),
                          wrapper_signed=summary([x['ws_steps'] for x in rows]),
                          wrapper_nonneg=summary([x['wn_steps'] for x in rows])))
    save('E8', out)
    return out


# ------------------------------------------------------------------ E9 ----
def e9(seed=61, count=None):
    """Branch beta exposure: how many reference certificates rely on header
    geometry that a later analysis could contradict (same input version)."""
    count = count or (200 if QUICK else 1500)
    rng = M.random.Random(seed)
    made = cert = beta_unstable = header_used = skipped = 0
    sl_beta = sl_alpha = 0
    while made < count:
        n = rng.randint(2, 7)
        w = M.random_world(rng, n, legal=True, nonneg=True)
        c = M.mask_world(rng, w, p_analysis=0.5, p_header=0.8, p_edge=0.7, p_fail=0.0, p_stale=0.0)
        t = rng.randrange(n)
        Ub, _, tr = M.possible_units(c, t, nonneg=True, header_authoritative=False, cap=40000)
        if tr:
            skipped += 1
            continue
        made += 1
        r = ref.certify(c, t)
        if r['status'] == 'certified':
            cert += 1
            used = any(k.startswith('header:') for k in r['reads'])
            header_used += used
            if len(Ub) != 1:
                beta_unstable += 1
        sl_alpha += certify_sl(c, t, nonneg=True)['status'] == 'certified'
        sb = certify_sl(c, t, nonneg=True, header_authoritative=False)
        if sb['status'] == 'certified':
            sl_beta += 1
            assert len(Ub) == 1 and M.canon(sb['unit']) == next(iter(Ub))
    out = dict(seed=seed, instances=made, skipped_truncated=skipped, ref_certified=cert, ref_cert_reading_header=header_used,
               ref_cert_not_stable_under_beta=beta_unstable, sl_alpha_certified=sl_alpha,
               sl_beta_certified=sl_beta, oracle_beta_note='sl_beta certificates checked against beta oracle')
    save('E9', out)
    return out


if __name__ == '__main__':
    which = [a for a in sys.argv[1:] if not a.startswith('--')] or ['all']
    fns = dict(E1=e1, E2=e2, E2H=e2h, E3=e3, E4=e4, E5=e5, E6=e6, E8=e8, E9=e9)
    for name in (fns if which == ['all'] else which):
        t0 = time.time()
        out = fns[name]()
        print(f'== {name} ({time.time() - t0:.1f}s)')
        print(json.dumps(out, indent=1, default=str)[:6000])
