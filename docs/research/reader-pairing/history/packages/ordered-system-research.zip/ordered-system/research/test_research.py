"""Adversarial tests for the research prototypes (new file; the original
test_reference.py / test_protocol.py are untouched and still run).

Run from the package root:
    python -m unittest discover -s research -p "test_*.py" -v
Each soundness check is also run against a deliberately wrong variant
(MutantChecks) to show the check can fail.
"""
import copy
import json
import random
import sys
import unittest
from fractions import Fraction
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import reference as ref  # noqa: E402
from research import model as M  # noqa: E402
from research import branching as B  # noqa: E402
from research import validity as V  # noqa: E402
from research.experiments import lb_family  # noqa: E402


def fact(state='NARROW', side='UNKNOWN'):
    return M.make_fact(state, side)


def case(n=6, automatic=False):
    return dict(items=[dict(id=f'i{i}', header=fact(), analysis=dict(status='computed', fact=fact(), version=1))
                       for i in range(n)], settings=dict(automatic=automatic),
                edges=[dict(first=i, second=i + 1, status='computed', score=None, version=1)
                       for i in range(n - 1)])


def soundness_violations(engine, seed=5, count=250, nonneg=True, legal=True, rank_focus=False, **kw):
    """Instances where `engine` certifies something the oracle does not prove.
    rank_focus: automatic on, few side labels, few WIDE items, so that rank
    comparisons decide units (the default generator rarely reaches them)."""
    rng = random.Random(seed)
    bad = []
    made = 0
    while made < count:
        n = rng.randint(2, 6)
        if rank_focus:
            w = M.random_world(rng, n, legal=legal, nonneg=nonneg, automatic=True, side_bias=0.1, p_wide=0.1)
        else:
            w = M.random_world(rng, n, legal=legal, nonneg=nonneg)
        c = M.mask_world(rng, w)
        t = rng.randrange(n)
        U, _, tr = M.possible_units(c, t, nonneg=nonneg, cap=20000)
        if tr:
            continue
        made += 1
        r = engine(c, t, **kw)
        if r['status'] == 'certified' and (len(U) != 1 or M.canon(r['unit']) != next(iter(U))):
            bad.append((c, t))
    return bad


class OracleInfrastructure(unittest.TestCase):
    def test_fast_unit_matches_complete_plan(self):
        rng = random.Random(1)
        for _ in range(300):
            n = rng.randint(1, 9)
            w = M.random_world(rng, n, legal=rng.random() < .5, nonneg=False)
            plan = ref.complete_plan(M.full_case(w))
            sn = M._norm_settings(w['settings'])
            for t in range(n):
                self.assertEqual(M.fast_unit(n, sn, w['states'], w['sides'], w['ranks'], t),
                                 M.target_unit(plan, t))

    def test_locality_horizon_lemma(self):
        rng = random.Random(2)
        checked = 0
        while checked < 120:
            n = rng.randint(4, 6)
            c = M.mask_world(rng, M.random_world(rng, n, legal=False, nonneg=False))
            t = rng.randrange(n - 3)
            a, _, ta = M.possible_units(c, t, horizon=3, cap=20000)
            b, _, tb = M.possible_units(c, t, horizon=None, cap=40000)
            if ta or tb:
                continue
            checked += 1
            self.assertEqual(a, b)

    def test_rank_grid_covers_dense_sampling(self):
        """Grid representatives realise every unit reachable by random reals."""
        rng = random.Random(3)
        for nonneg in (False, True):
            for _ in range(40):
                n = 5
                w = M.random_world(rng, n, legal=True, nonneg=nonneg, p_wide=0.0, automatic=True)
                c = M.mask_world(rng, w, p_analysis=1.0, p_edge=0.3, p_fail=0, p_stale=0)
                t = rng.randrange(n)
                U, _, tr = M.possible_units(c, t, nonneg=nonneg)
                self.assertFalse(tr)
                K = M.Knowledge(c)
                free = [j for j in range(n - 1) if K.rank[j][0] == 'free']
                sn = M._norm_settings(c['settings'])
                for _ in range(300):
                    ranks = {j: K.rank[j][1] for j in range(n - 1) if K.rank[j][0] == 'known'}
                    for j in free:
                        ranks[j] = None if rng.random() < .2 else rng.uniform(0 if nonneg else -3, 4)
                    u = M.fast_unit(n, sn, K.state, [s or 'UNKNOWN' for s in K.side], ranks, t)
                    self.assertIn(M.canon(u), U)


class Soundness(unittest.TestCase):
    def test_reference_is_sound_under_alpha(self):
        self.assertEqual(soundness_violations(lambda c, t: ref.certify(c, t)), [])

    def test_sl_is_sound_and_dominates_reference(self):
        self.assertEqual(soundness_violations(B.certify_sl), [])
        self.assertEqual(soundness_violations(B.certify_sl, seed=7, nonneg=False, rank_focus=True), [])
        self.assertEqual(soundness_violations(B.certify_sl, seed=6, nonneg=False, legal=False), [])
        rng = random.Random(9)
        for _ in range(200):
            n = rng.randint(2, 7)
            c = M.mask_world(rng, M.random_world(rng, n, legal=False, nonneg=False))
            t = rng.randrange(n)
            r = ref.certify(c, t)
            if r['status'] == 'certified':
                s = B.certify_sl(c, t)
                self.assertEqual(s['status'], 'certified')
                self.assertEqual(s['unit'], r['unit'])

    def test_pw_is_exact_on_sample(self):
        rng = random.Random(4)
        made = 0
        while made < 150:
            n = rng.randint(2, 6)
            c = M.mask_world(rng, M.random_world(rng, n, legal=True, nonneg=False))
            t = rng.randrange(n)
            U, _, tr = M.possible_units(c, t, nonneg=False, cap=20000)
            if tr:
                continue
            made += 1
            p = B.certify_pw(c, t)
            self.assertEqual(p['status'] == 'certified', len(U) == 1)

    def test_golden_rows_selected_units_match_full_plan(self):
        for line in (ROOT / 'fixtures' / 'golden.jsonl').read_text(encoding='utf-8').splitlines():
            g = json.loads(line)
            w = B.certify_contract(g['case'], g['target'], engine=B.certify_sl)
            if w['selected']['status'] == 'certified' and g['id'] in ('G002', 'G005', 'G006'):
                self.assertEqual(w['selected']['unit'],
                                 M.target_unit(ref.complete_plan(g['full_case']), g['target']))

    def test_g002_certified_with_less_scan_work_than_hg_retry(self):
        g = [json.loads(x) for x in (ROOT / 'fixtures' / 'golden.jsonl').read_text(encoding='utf-8').splitlines()][1]
        self.assertEqual(g['id'], 'G002')
        w = B.certify_contract(g['case'], g['target'], engine=B.certify_sl)
        s = ref.certify_strategy(g['case'], g['target'])
        self.assertTrue(w['adopted'])
        self.assertLess(w['total_steps'], s['total_steps'])


class FailureContract(unittest.TestCase):
    def he_case(self):
        """H-E minimal shape: near edge failed, competing later edge known null."""
        c = case(5, True)
        c['edges'][1] = dict(first=1, second=2, status='failed', failures={'1': 'RESOURCE'})
        c['edges'][2]['score'] = None
        return c

    def test_wrapper_never_swallows_reference_failures(self):
        c = self.he_case()
        r = ref.certify(c, 2)
        self.assertEqual(r['status'], 'blocked')
        w = B.certify_contract(c, 2, engine=B.certify_sl)
        self.assertEqual(w['selected'], r)

    def test_raw_engine_would_change_contract(self):
        """Documents the route-B' contract change: value is determined."""
        c = self.he_case()
        raw = B.certify_sl(c, 2)
        U, _, _ = M.possible_units(c, 2)
        self.assertEqual(len(U), 1)
        self.assertEqual(raw['status'], 'certified')
        self.assertIn('edge:1', raw['extra_failures'])

    def test_extra_failures_are_reported_not_hidden(self):
        rng = random.Random(12)
        seen = 0
        for _ in range(600):
            n = rng.randint(3, 7)
            c = M.mask_world(rng, M.random_world(rng, n), p_fail=.25)
            t = rng.randrange(n)
            w = B.certify_contract(c, t, engine=B.certify_sl)
            if w['adopted'] and w['engine']['extra_failures']:
                seen += 1
                self.assertEqual(w['selected']['extra_failures'], w['engine']['extra_failures'])
                self.assertEqual(w['baseline']['failures'], {})
        self.assertGreater(seen, 0)


class LowerBound(unittest.TestCase):
    def test_distance_d_dependence(self):
        for d in (1, 4, 9, 16):
            t = 1 + d
            u0 = M.target_unit(ref.complete_plan(M.full_case(lb_family(d, False))), t)
            u1 = M.target_unit(ref.complete_plan(M.full_case(lb_family(d, True))), t)
            self.assertNotEqual(u0, u1)
            k = M.full_case(lb_family(d, False))
            k['items'][1]['analysis'] = dict(status='unknown')
            self.assertNotEqual(B.certify_pw(k, t)['status'], 'certified')
            self.assertNotEqual(B.certify_sl(k, t)['status'], 'certified')


class Validity(unittest.TestCase):
    def certified(self):
        c = case(12, True)
        c['settings']['hard_isolates'] = [6]
        r = ref.certify(c, 9)
        self.assertEqual(r['status'], 'certified')
        return c, r, V.scoped_snapshot(r)

    def test_unrelated_content_change_keeps_certificate(self):
        c, r, s = self.certified()
        c2 = copy.deepcopy(c)
        c2['items'][1]['content_version'] = 5
        self.assertEqual(ref.first_changed_read(r, c2), 'identity')
        self.assertIsNone(V.scoped_changed(s, c2))
        self.assertEqual(ref.certify(c2, 9)['unit'], r['unit'])

    def test_dependent_identity_and_version_changes_invalidate(self):
        c, r, s = self.certified()
        dep = r['dependent_items'][0]
        for mutate in (lambda x: x['items'][dep].__setitem__('id', 'new'),
                       lambda x: x['items'][dep].__setitem__('content_version', 9),
                       lambda x: x['items'][dep]['analysis'].__setitem__('version', 2),
                       lambda x: x.__setitem__('generation', 1),
                       lambda x: x['settings'].__setitem__('revision', 1)):
            c2 = copy.deepcopy(c)
            mutate(c2)
            self.assertIsNotNone(V.scoped_changed(s, c2))

    def test_same_position_new_identity_with_header_only_evidence(self):
        c = case(6, False)
        c['items'][3]['analysis'] = dict(status='unknown')
        r = ref.certify(c, 3)
        self.assertEqual(r['status'], 'certified')
        s = V.scoped_snapshot(r)
        c2 = copy.deepcopy(c)
        c2['items'][3]['id'] = 'replacement'          # same header values
        self.assertIsNotNone(V.scoped_changed(s, c2))

    def test_refinement_kept_eviction_rejected_by_default(self):
        c = case(6, True)
        c['items'][4]['analysis'] = dict(status='unknown')
        c['items'][4]['header'] = fact()
        c['items'][3]['analysis']['fact']['side'] = 'B'   # leading=A: B on 3 blocks (3,4)
        r = ref.certify(c, 3)
        if r['status'] != 'certified':
            self.skipTest('shape not certified by reference')
        s = V.scoped_snapshot(r)
        c2 = copy.deepcopy(c)
        c2['items'][4]['analysis'] = dict(status='computed', version=1, fact=fact())
        self.assertIsNotNone(ref.first_changed_read(r, c2))
        self.assertIsNone(V.scoped_changed(s, c2))
        c3 = copy.deepcopy(c)
        c3['items'][3]['analysis'] = dict(status='unknown')
        self.assertIsNotNone(V.scoped_changed(s, c3))
        self.assertIsNone(V.scoped_changed(s, c3, allow_eviction=True))

    def test_refinement_with_other_dimensions_same_state_is_kept(self):
        """Header-backed dimension refined by an analysis with the same state
        but other width/height: scan-equivalent, must not invalidate."""
        c = case(6, False)
        c['items'][3]['analysis'] = dict(status='unknown')
        r = ref.certify(c, 3)
        self.assertEqual(r['status'], 'certified')
        s = V.scoped_snapshot(r)
        c2 = copy.deepcopy(c)
        f = fact()
        f['width'], f['height'] = 300, 600
        c2['items'][3]['analysis'] = dict(status='computed', version=1, fact=f)
        self.assertIsNone(V.scoped_changed(s, c2))
        self.assertEqual(ref.certify(c2, 3)['unit'], r['unit'])
        c3 = copy.deepcopy(c)
        c3['items'][3]['analysis'] = dict(status='computed', version=1, fact=fact('WIDE'))
        self.assertIsNotNone(V.scoped_changed(s, c3))      # state changed: invalidate

    def test_wrapper_certificate_snapshot(self):
        """Adopted C-SL certificates carry a scoped snapshot that keeps
        unrelated changes and catches dependent ones."""
        g = [json.loads(x) for x in (ROOT / 'fixtures' / 'golden.jsonl').read_text(encoding='utf-8').splitlines()][1]
        w = B.certify_contract(g['case'], g['target'])          # default engine: C-SL
        self.assertTrue(w['adopted'])
        snap = w['selected']['snapshot']
        self.assertIsNone(V.scoped_changed(snap, g['case']))
        dep = sorted(snap['positions'])[0]
        c2 = copy.deepcopy(g['case'])
        c2['items'][dep]['content_version'] += 1
        self.assertIsNotNone(V.scoped_changed(snap, c2))
        far = [i for i in range(len(g['case']['items'])) if i not in snap['positions']]
        if far:
            c3 = copy.deepcopy(g['case'])
            c3['items'][far[0]]['content_version'] += 1
            self.assertIsNone(V.scoped_changed(snap, c3))

    def test_branch_beta_header_contradiction_is_detected(self):
        """Reference H2 risk if header geometry is not authoritative."""
        c = case(5, False)
        c['items'][2]['analysis'] = dict(status='unknown')
        r = ref.certify(c, 2)
        c2 = copy.deepcopy(c)
        c2['items'][2]['analysis'] = dict(status='computed', version=1, fact=fact('WIDE'))
        self.assertNotEqual(ref.certify(c2, 2)['unit'], r['unit'])
        self.assertIsNotNone(V.scoped_changed(V.scoped_snapshot(r), c2))
        U, _, _ = M.possible_units(c, 2, header_authoritative=False)
        self.assertGreater(len(U), 1)


class MutantChecks(unittest.TestCase):
    """The checks above must reject deliberately wrong variants."""

    def test_unknown_rank_as_null_is_caught(self):
        orig = B.View.rank

        def wrong(self, j):
            try:
                return orig(self, j)
            except B.Branch:
                return None                     # 'unknown means no rank' fallacy
        with mock.patch.object(B.View, 'rank', wrong):
            bad = soundness_violations(B.certify_sl, seed=21, count=300, nonneg=False, rank_focus=True)
            c = case(5, True)
            c['edges'][1] = dict(first=1, second=2, status='unknown')
            c['edges'][2]['score'] = 1
            targeted = B.certify_sl(c, 2)['status']
        self.assertGreater(len(bad), 0)
        self.assertEqual(targeted, 'certified')            # wrong certificate
        self.assertEqual(len(M.possible_units(c, 2)[0]), 2)  # oracle: two answers

    def test_missing_paired_entry_is_caught(self):
        orig = B._structural_entries

        def wrong(first, target, isolated, forced):
            return [e for e in orig(first, target, isolated, forced) if e[3] != 'paired']
        with mock.patch.object(B, '_structural_entries', wrong):
            bad = soundness_violations(B.certify_sl, seed=22, count=400, nonneg=False, legal=False)
        self.assertGreater(len(bad), 0)

    def test_wrapper_without_baseline_is_caught(self):
        def wrong(c, t, engine=B.certify_sl, **kw):
            res = engine(c, t)
            return dict(selected=res if res['status'] == 'certified' else ref.certify(c, t))
        c = FailureContract().he_case()
        self.assertNotEqual(wrong(c, 2)['selected']['status'], ref.certify(c, 2)['status'])

    def test_scoped_validation_without_identity_is_caught(self):
        c = case(6, False)
        c['items'][3]['analysis'] = dict(status='unknown')
        r = ref.certify(c, 3)
        s = V.scoped_snapshot(r)
        s['positions'] = {}                   # mutant: drop per-position identity
        c2 = copy.deepcopy(c)
        c2['items'][3]['id'] = 'replacement'
        self.assertIsNone(V.scoped_changed(s, c2))   # mutant misses H5 replacement

    def test_grid_without_null_is_caught(self):
        """Dropping the known-null option from unknown ranks loses worlds."""
        real = M.rank_grid
        orig_view_rank = B.View.rank

        def no_null(self, j):
            try:
                return orig_view_rank(self, j)
            except B.Branch as b:
                raise B.Branch(b.key, [v for v in b.options if v is not None])
        c = case(5, True)
        c['edges'][1]['score'] = None                         # near edge known null
        c['edges'][2] = dict(first=2, second=3, status='unknown')  # later edge unknown
        self.assertEqual(len(M.possible_units(c, 2)[0]), 2)
        with mock.patch.object(B.View, 'rank', no_null):
            self.assertEqual(B.certify_sl(c, 2)['status'], 'certified')   # wrong
        self.assertNotEqual(B.certify_sl(c, 2)['status'], 'certified')    # right
        self.assertIs(M.rank_grid, real)


class ComparisonDisjointness(unittest.TestCase):
    """Lemma R: along one scan path, rank comparisons use pairwise disjoint
    edge pairs.  Hence ranks never correlate across steps, and step-local
    enumeration loses no precision in the rank dimension."""

    def test_lemma_r_on_complete_worlds(self):
        rng = random.Random(14)
        compared_paths = 0
        for _ in range(1500):
            n = rng.randint(2, 10)
            w = M.random_world(rng, n, legal=rng.random() < .5, nonneg=False,
                               automatic=True, side_bias=rng.choice([0.0, 0.2, 0.6]),
                               p_wide=rng.choice([0.0, 0.2]))
            sn = M._norm_settings(w['settings'])
            calls = []

            def dim(i):
                return dict(state=w['states'][i])

            def side(i):
                return w['sides'][i]

            def rank(a, b):
                calls.append(a)
                if 'WIDE' in (w['states'][a], w['states'][b]):
                    return None
                return w['ranks'].get(a)
            scan = ref._Scan(n, sn, dim, side, side, rank)
            original = scan.later_wins
            starts = []

            def later_wins(i):
                before = len(calls)
                out = original(i)
                if len(calls) > before:
                    starts.append(i)
                return out
            scan.later_wins = later_wins
            cursor = (0, True, -1)
            while cursor[0] < n:
                _, cursor = scan.step(cursor)
            distinct = sorted(set(starts))
            if distinct:
                compared_paths += 1
            for a, b in zip(distinct, distinct[1:]):
                self.assertGreaterEqual(b - a, 2, (w, distinct))
            self.assertNotIn(0, distinct)
        self.assertGreater(compared_paths, 100)


if __name__ == '__main__':
    unittest.main()
