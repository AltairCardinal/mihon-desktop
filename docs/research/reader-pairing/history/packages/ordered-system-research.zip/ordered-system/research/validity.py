"""D3: position-scoped, refinement-tolerant certificate validation.

reference.first_changed_read() snapshots the WHOLE identity (all items) and
requires every read to be byte-equal.  Consequences:
  * an unrelated item's content change invalidates every certificate (O(n)
    validation per certificate, O(n) snapshot storage per certificate);
  * a read that was unknown and becomes known (knowledge refinement inside the
    same input version) invalidates, although the certificate held for every
    value of that read.
scoped_snapshot/scoped_changed keep: global context (generation,
order_revision, n, full settings), the identity of every position whose
evidence was read, and each typed read.  A read may refine unknown/failed ->
anything; a known read must stay equal.  Optional eviction tolerance
(known -> unknown) is only sound under precondition P_ver (an analysis
algorithm-version change is visible outside the evidence record); it is off by
default.
"""
import sys
from copy import deepcopy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402


def _positions(key):
    parts = key.split(':')
    if parts[0] in ('analysis', 'header', 'dimension'):
        return [int(parts[1])]
    if parts[0] == 'rank':
        return [int(parts[1]), int(parts[2])]
    return []


def _current(data, case, key):
    parts = key.split(':')
    if parts[0] == 'analysis':
        return data.analysis(int(parts[1]))
    if parts[0] == 'header':
        return ref._fact(data.items[int(parts[1])].get('header'))
    if parts[0] == 'dimension':
        f = data.effective(int(parts[1]))
        return dict(f, side='UNKNOWN') if f else None
    return data.edge(int(parts[1]), int(parts[2]))


def _is_unknownish(v):
    """Evidence that carries no value: unknown or failed record, or None."""
    if v is None:
        return True
    return isinstance(v, dict) and v.get('status') in ('unknown', 'failed')


def _dimension_equivalent(old, new):
    """The scan consumes a dimension read only through its validity and its
    occupancy state (rotation/orientation are covered by position identity).
    Two valid dimension facts with equal state are therefore equivalent."""
    if old is None or new is None:
        return False
    return (ref._geometry(old) and ref._geometry(new) and old['state'] == new['state']
            and old['rotation'] == new['rotation'] and old['orientation'] == new['orientation'])


def scoped_snapshot(result):
    """Build a scoped snapshot from a reference certify() result."""
    reads = result['reads']
    ident = reads['identity']
    keys = [k for k in reads if k not in ('identity', 'settings')]
    pos = sorted({p for k in keys for p in _positions(k)})
    return dict(context=dict(generation=ident['generation'], order_revision=ident['order_revision'],
                             n=len(ident['items'])),
                settings=deepcopy(reads['settings']),
                positions={p: deepcopy(ident['items'][p]) for p in pos},
                reads={k: deepcopy(reads[k]) for k in keys})


def scoped_changed(snap, case, allow_eviction=False):
    """First violated component or None.  Work is O(|reads|), not O(n)."""
    if case.get('closed', False):
        return 'identity'
    data = ref._Input(case)
    ident = data.identity
    ctx = snap['context']
    if (ident['generation'], ident['order_revision'], len(ident['items'])) != \
            (ctx['generation'], ctx['order_revision'], ctx['n']):
        return 'context'
    if data.settings != snap['settings']:
        return 'settings'
    for p, old in snap['positions'].items():
        if ident['items'][p] != old:
            return f'position:{p}'
    for key, old in snap['reads'].items():
        new = _current(data, case, key)
        if new == old or _is_unknownish(old):
            continue
        if key.startswith('dimension:') and _dimension_equivalent(old, new):
            continue
        if allow_eviction and _is_unknownish(new) and not (isinstance(new, dict) and new.get('status') == 'failed'):
            continue
        return key
    return None


def snapshot_cost(snap):
    """Stored comparison units (positions + reads + constant context)."""
    return 3 + len(snap['positions']) + len(snap['reads'])


def reference_cost(result):
    return 2 + len(result['reads']['identity']['items']) + len(result['reads'])


def support_snapshot(case, support):
    """Scoped snapshot for a branching-certifier certificate.

    support: iterable of ('S', i) | ('D', i) | ('R', j) keys actually read in
    the certifying window.  Maps them onto the reference read vocabulary so
    scoped_changed() applies unchanged."""
    data = ref._Input(case)
    keys = set()
    for kind, x in support:
        if kind in ('S', 'D'):
            keys.update((f'analysis:{x}', f'header:{x}', f'dimension:{x}'))
        else:
            keys.add(f'rank:{x}:{x + 1}')
            keys.update((f'analysis:{x}', f'analysis:{x + 1}'))
    pos = sorted({p for k in keys for p in _positions(k)})
    ident = data.identity
    return dict(context=dict(generation=ident['generation'], order_revision=ident['order_revision'],
                             n=len(ident['items'])),
                settings=deepcopy(data.settings),
                positions={p: deepcopy(ident['items'][p]) for p in pos},
                reads={k: deepcopy(_current(data, case, k)) for k in sorted(keys)})
