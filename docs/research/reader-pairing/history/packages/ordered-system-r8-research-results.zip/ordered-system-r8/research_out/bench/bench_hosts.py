"""Serial benchmark for the host caching / invalidation family.

Steps (formal campaign is run only by the main session):
  python3 research_out/bench/bench_hosts.py --freeze              # freeze exogenous traces + truth hashes
  python3 research_out/bench/bench_hosts.py --processes 3 --out research_out/results/hosts/formal.jsonl
  python3 research_out/bench/bench_hosts.py --quick --processes 1 --out research_out/results/hosts/trial.jsonl

Every candidate replays the SAME frozen trace; verdicts are hashed and compared
with the reference strategy hash computed at freeze time (ok=false rows kept).
Allocation peak is a separate tracemalloc pass (--alloc).  Wall time covers
host construction, updates, validation, recomputation, preparation and close.
"""
import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import tracemalloc

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))
import common  # noqa: E402,F401
from host_traces import generate, freeze  # noqa: E402
from host_driver import replay, truth, make  # noqa: E402

TRACE_DIR = HERE.parent / 'fixtures' / 'host_traces' / 'bench'

SCENARIOS = [
    dict(name='s16_neighbor_relevant', n=16, pattern='neighbor', mix='relevant', rounds=60),
    dict(name='s64_neighbor_irrelevant_r4', n=64, pattern='neighbor', mix='irrelevant', rounds=60, rpr=4),
    dict(name='s64_repeat_quiet_r4', n=64, pattern='repeat', mix='quiet', rounds=60, rpr=4),
    dict(name='s64_ws5_quiet', n=64, pattern='ws5', mix='quiet', rounds=60),
    dict(name='s64_ws3_relevant', n=64, pattern='ws3', mix='relevant', rounds=60),
    dict(name='s64_jump_churn', n=64, pattern='jump', mix='churn', rounds=60),
    dict(name='s64_neighbor_fail', n=64, pattern='neighbor', mix='fail', rounds=60),
    dict(name='s256_neighbor_irrelevant_r4', n=256, pattern='neighbor', mix='irrelevant', rounds=40, rpr=4),
    dict(name='s256_roundtrip_growth', n=256, pattern='roundtrip', mix='growth', rounds=40),
    dict(name='s512_neighbor_irrelevant_r4', n=512, pattern='neighbor', mix='irrelevant', rounds=25, rpr=4),
    dict(name='s512_jump_relevant', n=512, pattern='jump', mix='relevant', rounds=25),
    dict(name='s64_idle_neighbor_growth', n=64, pattern='neighbor', mix='growth', rounds=60, idle=2),
    dict(name='s64_batch_neighbor_relevant', n=64, pattern='neighbor', mix='relevant', rounds=40, batch=3),
    dict(name='c5_retry_support_trace', constructed='mutant_revdep_no_reregister.json'),
    dict(name='c6_rare_expensive', builder='rare_expensive'),
]
X5 = ['s64_ws5_quiet', 's64_ws3_relevant', 's64_jump_churn', 's256_neighbor_irrelevant_r4', 'c6_rare_expensive']
X5_CANDS = ['current', 'x_fix_stamp', 'x_gds', 'x_bytes200', 'x_gdsbytes200', 'x_bytes', 'x_gdsbytes']
QUICK = ['s16_neighbor_relevant', 'c6_rare_expensive', 's64_neighbor_irrelevant_r4', 's64_ws5_quiet', 's256_neighbor_irrelevant_r4',
         's64_idle_neighbor_growth', 'c5_retry_support_trace']

CANDIDATES = ['current', 'x_fix_stamp', 'x_union', 'x_posrev', 'x_log', 'x_revdep', 'x_bitmap', 'x_carry',
              'x_interned', 'x_gds', 'x_bytes200', 'x_gdsbytes200', 'x_bytes', 'x_gdsbytes',
              'x_delta_stamp', 'x_delta_posrev', 'x_delta_revdep', 'x_carry_delta_stamp', 'x_delta_interned',
              'x_fix_stamp_prep', 'x_side2_prep']


def _digest(v):
    return hashlib.sha256(json.dumps(v, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def trace_path(name):
    return TRACE_DIR / f'{name}.json'


def do_freeze():
    TRACE_DIR.mkdir(parents=True, exist_ok=True)
    meta = {}
    for sc in SCENARIOS:
        if 'constructed' in sc:
            tr = json.loads((TRACE_DIR.parent / sc['constructed']).read_text(encoding='utf-8'))
        elif 'builder' in sc:
            import host_traces
            tr = getattr(host_traces, sc['builder'])()
        else:
            tr = generate(17, sc['n'], sc['rounds'], sc['pattern'], sc['mix'], requests_per_round=sc.get('rpr', 2),
                          idle_budget=sc.get('idle', 0), batch=sc.get('batch', 0))
        freeze(tr, trace_path(sc['name']))
        meta[sc['name']] = dict(trace_sha256=_digest(tr), truth_sha256=_digest(truth(tr)),
                                requests=sum(1 for e in tr['events'] if e['op'] == 'request') +
                                sum(len(e['targets']) for e in tr['events'] if e['op'] == 'batch'),
                                updates=sum(1 for e in tr['events'] if e['op'] in ('analysis', 'header', 'edge', 'identity', 'snapshot')))
    (TRACE_DIR / 'meta.json').write_text(json.dumps(meta, indent=1), encoding='utf-8')
    print(json.dumps(meta, indent=1))


def run_one(scenario, candidate, rep, alloc=False):
    name = scenario['name'] if isinstance(scenario, dict) else scenario
    tr = json.loads(trace_path(name).read_text(encoding='utf-8'))
    meta = json.loads((TRACE_DIR / 'meta.json').read_text(encoding='utf-8'))[name]
    prep = candidate.endswith('_prep')
    factory, delta = make(candidate[:-5] if prep else candidate)
    t0 = time.perf_counter_ns()
    verdicts, host = replay(tr, factory, delta, collect=True, prepare=prep)
    wall = time.perf_counter_ns() - t0
    row = dict(scenario=name, candidate=candidate, rep=rep, wall_ns=wall, verdict_sha256=_digest(verdicts),
               ok=_digest(verdicts) == meta['truth_sha256'], trace_sha256=meta['trace_sha256'],
               work={k: v for k, v in host.metrics.items()})
    if alloc:
        tracemalloc.start()
        replay(tr, factory, delta, collect=True, prepare=prep)
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        row['alloc_peak_bytes'] = peak
    return row


def process_run(names, cands, reps, warmup, rotate, out, alloc):
    pid = os.getpid()
    rows = []
    order = cands[rotate % len(cands):] + cands[:rotate % len(cands)]
    for name in names:
        for c in order:
            for _ in range(warmup):
                run_one(name, c, -1)
            for r in range(reps):
                row = run_one(name, c, r, alloc=alloc and r == 0)
                row.update(pid=pid, utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), rotate=rotate)
                rows.append(row)
    with open(out, 'a', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, allow_nan=False) + '\n')
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--freeze', action='store_true')
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--processes', type=int, default=1)
    ap.add_argument('--child', type=int, default=None)
    ap.add_argument('--reps', type=int, default=3)
    ap.add_argument('--warmup', type=int, default=1)
    ap.add_argument('--alloc', action='store_true')
    ap.add_argument('--only', default='')
    ap.add_argument('--cands', default='')
    ap.add_argument('--out', default=str(HERE.parent / 'results' / 'hosts' / 'bench.jsonl'))
    a = ap.parse_args()
    if a.freeze:
        do_freeze()
        return
    names = [s['name'] for s in SCENARIOS if (not a.quick or s['name'] in QUICK) and a.only in s['name']]
    cands = a.cands.split(',') if a.cands else CANDIDATES
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    if a.child is not None:
        process_run(names, cands, a.reps, a.warmup, a.child, a.out, a.alloc)
        return
    for k in range(a.processes):              # serial, independent interpreter processes
        cmd = [sys.executable, str(Path(__file__).resolve()), '--child', str(k), '--reps', str(a.reps),
               '--warmup', str(a.warmup), '--out', a.out, '--only', a.only]
        if a.quick:
            cmd.append('--quick')
        if a.alloc:
            cmd.append('--alloc')
        if a.cands:
            cmd += ['--cands', a.cands]
        subprocess.run(cmd, check=True)
    print('wrote', a.out)


if __name__ == '__main__':
    main()
