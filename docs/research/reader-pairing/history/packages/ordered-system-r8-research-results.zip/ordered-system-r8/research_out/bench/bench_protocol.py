"""Protocol-family benchmark registration (see CONVENTIONS.md).

Only two families are timing-meaningful (local_measured, Python 3):
  guard_*     publication entitlement check: ScanGuard (baseline: check against every
              publication) vs OwnerTable (item -> unit occupancy table)            [G5]
  identity_*  per-replace context identity comparison: typed(full identity dict)
              (what current_baseline.Host.replace does) vs a type-tagged identity tuple
              with interning (fallback to typed() for non-scalar ids)               [C3]
Simulator / checker outputs are synthetic and live in results/protocol/*.json; they are
not timed here.

Usage (main session, serial, one process per call):
  python3 research_out/bench/bench_protocol.py --scenario guard_n1000 --candidate owner_table --rep 0
  python3 research_out/bench/bench_protocol.py --list
"""
import argparse
import hashlib
import json
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))
sys.path.insert(0, str(HERE.parents[1]))

from common import ref, base_case  # noqa: E402
from current_baseline import typed  # noqa: E402
import proto_publication as PUB  # noqa: E402

CANDIDATES = ['scan_guard', 'owner_table', 'typed_full', 'typed_tuple_intern']
SCENARIOS = ([dict(name=f'guard_n{n}', family='guard', n=n, events=4 * n) for n in (10, 100, 1000)] +
             [dict(name=f'identity_n{n}', family='identity', n=n, replaces=200) for n in (16, 64, 256, 512)])
FAMILY_CANDIDATES = {'guard': ['scan_guard', 'owner_table'], 'identity': ['typed_full', 'typed_tuple_intern']}


def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def guard_events(sc, rep):
    rng = random.Random(1000 + sc['n'])          # exogenous, identical for every candidate
    ev = []
    for _ in range(sc['events']):
        t = rng.randrange(0, 2 * sc['n'])
        ms = [t] if rng.random() < .5 else [t, t + 1]
        ev.append((t, {'slots': ms}))
    return ev


def identity_cases(sc):
    rng = random.Random(2000 + sc['n'])
    cases = []
    c = base_case(sc['n'])
    for k in range(sc['replaces']):
        c = json.loads(json.dumps(c))
        r = rng.random()
        if r < .3:
            it = c['items'][rng.randrange(sc['n'])]
            it['content_version'] = it.get('content_version', 0) + 1           # real identity change
        elif r < .4:
            i = rng.randrange(sc['n'])
            v = c['items'][i].get('content_version', 0)
            c['items'][i]['content_version'] = float(v) if isinstance(v, int) else int(v)   # type-only change
        else:
            c['items'][rng.randrange(sc['n'])]['header']['width'] += 1          # evidence-only change
        cases.append(c)
    return cases


def _typed_tuple(case):
    out = []
    for i, x in enumerate(case['items']):
        vals = (x.get('id', str(i)), x.get('content_version', 0), x.get('rotation', 0), x.get('orientation', 1))
        for v in vals:
            if not isinstance(v, (str, int, float, bool)) and v is not None:
                return ('fallback', typed(ref._Input(case).identity))
        out.append(tuple((type(v).__name__, v) for v in vals))
    g, o = case.get('generation', 0), case.get('order_revision', 0)
    return ((type(g).__name__, g), (type(o).__name__, o), tuple(out))


def _identity_dict(case):
    # exactly the identity record reference._Input builds, without its whole-case deepcopy
    return dict(generation=case.get('generation', 0), order_revision=case.get('order_revision', 0),
                items=[dict(id=x.get('id', str(i)), content_version=x.get('content_version', 0),
                            rotation=x.get('rotation', 0), orientation=x.get('orientation', 1))
                       for i, x in enumerate(case['items'])])


def run_identity(sc, cand):
    cases = identity_cases(sc)
    decisions = []
    t0 = time.perf_counter_ns()
    if cand == 'typed_full':
        prev = None
        for c in cases:
            cur = typed(_identity_dict(c))
            decisions.append(cur == prev)
            prev = cur
    else:
        table = {}
        prev = None
        for c in cases:
            key = _typed_tuple(c)
            canon = table.setdefault(key, key)
            decisions.append(canon is prev)
            prev = canon
            if len(table) > 64:                     # bounded interning (G6): drop all but current
                table = {key: canon}
    wall = time.perf_counter_ns() - t0
    return wall, decisions


def run_guard(sc, cand):
    ev = guard_events(sc, 0)
    g = PUB.ScanGuard(require_member=True) if cand == 'scan_guard' else PUB.OwnerTable(require_member=True)
    t0 = time.perf_counter_ns()
    decisions = [g.publish(t, u) for t, u in ev]
    return time.perf_counter_ns() - t0, decisions


def run_one(scenario, candidate, rep):
    fam = scenario['family']
    if candidate not in FAMILY_CANDIDATES[fam]:
        raise ValueError('candidate not registered for family')
    runner = run_guard if fam == 'guard' else run_identity
    base = FAMILY_CANDIDATES[fam][0]
    _, want = runner(scenario, base)                 # reference decisions, outside the timed region
    wall, got = runner(scenario, candidate)
    return dict(scenario=scenario['name'], candidate=candidate, rep=rep, wall_ns=wall,
                verdict_sha256=_sha(got), ok=got == want,
                work=dict(events=len(got), accepted_or_same=sum(got)), layer='local_measured')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scenario')
    ap.add_argument('--candidate')
    ap.add_argument('--rep', type=int, default=0)
    ap.add_argument('--list', action='store_true')
    a = ap.parse_args()
    if a.list:
        print(json.dumps(dict(scenarios=SCENARIOS, family_candidates=FAMILY_CANDIDATES)))
        return
    sc = next(s for s in SCENARIOS if s['name'] == a.scenario)
    print(json.dumps(run_one(sc, a.candidate, a.rep)))


if __name__ == '__main__':
    main()
