"""Serial 3-process driver for the protocol family's timing-meaningful candidates (G5, C3)."""
import argparse, json, os, subprocess, sys, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent))


def child(reps, warmup):
    import bench_protocol as BP
    pid = os.getpid(); utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    for sc in BP.SCENARIOS:
        cands = BP.FAMILY_CANDIDATES[sc['family']][:]
        for rep in range(warmup + reps):
            cands = cands[1:] + cands[:1]
            for c in cands:
                row = BP.run_one(sc, c, rep)
                row.update(pid=pid, utc=utc, warmup=rep < warmup)
                print(json.dumps(row), flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--child', action='store_true'); ap.add_argument('--out')
    ap.add_argument('--reps', type=int, default=3); ap.add_argument('--warmup', type=int, default=1)
    a = ap.parse_args()
    if a.child:
        child(a.reps, a.warmup)
    else:
        with open(a.out, 'w') as fh:
            for proc in range(3):
                res = subprocess.run([sys.executable, str(HERE), '--child', '--reps', str(a.reps), '--warmup', str(a.warmup)],
                                     capture_output=True, text=True, check=True)
                for line in res.stdout.splitlines():
                    r = json.loads(line); r['process_index'] = proc; fh.write(json.dumps(r) + '\n')
