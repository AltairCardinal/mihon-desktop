"""D1/D2/D3/D6/NH5/X2/X4 acquisition simulation sweep -> results/acqsim.json (SIMULATED layer)."""
import json, sys, time, itertools
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
import acqsim as S

SEEDS = range(12)
CONFIGS = []
for pattern in ('sweep', 'roundtrip', 'jump', 'reverse_once'):
    for cert in ('ref', 'tree', 'exact'):
        CONFIGS.append(dict(pattern=pattern, certifier=cert, work='fact', select='all', R=4, prefetch=0))
    for work in ('witness', 'witness_eager'):
        for R in (2, 4, 16):
            CONFIGS.append(dict(pattern=pattern, certifier='tree', work=work, select='all', R=R, prefetch=0))
    for sel in ('one', 'analysis_first'):
        CONFIGS.append(dict(pattern=pattern, certifier='tree', work='witness', select=sel, R=4, prefetch=0))
    for pf in (1, 2, 3):
        CONFIGS.append(dict(pattern=pattern, certifier='tree', work='witness', select='all', R=4, prefetch=pf))
    CONFIGS.append(dict(pattern=pattern, certifier='ref', work='witness', select='all', R=4, prefetch=0))
rows = []
t0 = time.time()
for cfg in CONFIGS:
    tot = {}
    for seed in SEEDS:
        r = S.run(seed, n=24, count=24, **cfg)
        for k, v in r.items():
            tot[k] = tot.get(k, 0) + v
    rows.append(dict(cfg, **tot, seeds=len(SEEDS)))
    print(cfg, {k: tot[k] for k in ('acquisitions', 'derivations', 'rounds', 'early', 'wrong', 'served', 'prefetch_wasted')}, flush=True)
Path(__file__).resolve().parents[1].joinpath('results', 'acqsim.json').write_text(json.dumps(dict(
    layer='simulated', n=24, requests_per_seed=24, seeds=len(SEEDS), rows=rows, seconds=round(time.time() - t0, 1)), indent=1))
