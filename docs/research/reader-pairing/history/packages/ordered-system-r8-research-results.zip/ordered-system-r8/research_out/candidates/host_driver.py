"""Replay a frozen host-trace-v2 through any host (frozen Host or XHost)."""
from copy import deepcopy
from dataclasses import replace as dc_replace

import reference as ref
from current_baseline import Host, Config
from hosts import XHost, XConfig
from host_traces import apply_event, predict


def make(candidate):
    """Candidate name -> (factory, delta?)."""
    if candidate == 'current':
        return (lambda c: Host(c, config=Config.current())), False
    if candidate == 'strict':
        return (lambda c: Host(c, config=Config.strict())), False
    if candidate == 'cold':
        return (lambda c: Host(c, config=Config.cold())), False
    cfg, delta = CANDIDATE_CONFIGS[candidate]
    return (lambda c: XHost(c, config=cfg)), delta


B = XConfig()            # attempts + stamp + compact + request view + fifo(4) + replace
CANDIDATE_CONFIGS = {
    'x_fix_stamp':     (B, False),                                            # C5/B4 fix only
    'x_selected':      (dc_replace(B, support='selected'), False),            # frozen semantics re-impl
    'x_union':         (dc_replace(B, support='union'), False),               # C5 route B
    'x_exact':         (dc_replace(B, invalidation='exact'), False),
    'x_posrev':        (dc_replace(B, invalidation='posrev'), False),         # C1 A
    'x_log':           (dc_replace(B, invalidation='log'), False),            # C1 B (cap 64)
    'x_log_nocap':     (dc_replace(B, invalidation='log', log_cap=None), False),
    'x_revdep':        (dc_replace(B, invalidation='revdep'), False),         # C2 A
    'x_bitmap':        (dc_replace(B, invalidation='bitmap'), False),         # C2 B
    'x_delta_stamp':   (B, True),                                             # owner API, global stamp
    'x_delta_posrev':  (dc_replace(B, invalidation='posrev'), True),          # C1 complete barrier
    'x_delta_revdep':  (dc_replace(B, invalidation='revdep'), True),
    'x_delta_log':     (dc_replace(B, invalidation='log'), True),
    'x_delta_bitmap':  (dc_replace(B, invalidation='bitmap'), True),
    'x_delta_exact':   (dc_replace(B, invalidation='exact'), True),
    'x_delta_interned': (dc_replace(B, proof='interned'), True),
    'x_snap_delta_stamp': (dc_replace(B, view='snapshot'), True),
    'x_snap_delta_posrev': (dc_replace(B, view='snapshot', invalidation='posrev'), True),
    'x_delta_selected': (dc_replace(B, support='selected'), True),
    'x_delta_union':   (dc_replace(B, support='union'), True),
    'x_delta_gds':     (dc_replace(B, cache='gds'), True),
    'x_delta_gdsbytes': (dc_replace(B, cache='gdsbytes'), True),
    'x_delta_bytes':   (dc_replace(B, cache='bytes'), True),
    'x_interned':      (dc_replace(B, proof='interned'), False),              # C4 A
    'x_snapshot':      (dc_replace(B, view='snapshot'), False),               # C4 B / B5 view
    'x_snap_delta_revdep': (dc_replace(B, view='snapshot', invalidation='revdep'), True),
    'x_gds':           (dc_replace(B, cache='gds'), False),                   # C6 A
    'x_bytes':         (dc_replace(B, cache='bytes'), False),                 # C6 B / G6
    'x_gdsbytes':      (dc_replace(B, cache='gdsbytes'), False),              # X5
    'x_bytes200':      (dc_replace(B, cache='bytes', byte_budget=200), False),  # equal-space byte budget
    'x_gdsbytes200':   (dc_replace(B, cache='gdsbytes', byte_budget=200), False),
    'x_side2':         (dc_replace(B, prep_side=2), False),                   # B6 route B (use with _prep)
    'x_delta_side2':   (dc_replace(B, prep_side=2), True),
    'x_carry':         (dc_replace(B, view='carry'), False),                  # C4 route B+
    'x_carry_delta_stamp': (dc_replace(B, view='carry'), True),
    'x_carry_delta_revdep': (dc_replace(B, view='carry', invalidation='revdep'), True),
    'x_cap8':          (dc_replace(B, capacity=8), False),
}


def replay(trace, factory, delta=False, collect=True, prepare=True):
    case = deepcopy(trace['initial'])
    host = factory(case)
    n = len(case['items'])
    verdicts, history = [], []
    closed = False
    for ev in trace['events']:
        op = ev['op']
        if op == 'request':
            v = host.request(ev['target'])
            history.append(ev['target'])
            if collect:
                verdicts.append(v)
        elif op == 'batch':
            vs = host.request_many(ev['targets']) if hasattr(host, 'request_many') else \
                [host.request(t) for t in ev['targets']]
            history.extend(ev['targets'])
            if collect:
                verdicts.extend(vs)
        elif op == 'idle':
            if prepare and hasattr(host, 'prepare'):
                host.prepare(predict(history, n), ev['budget'])
        elif op in ('analysis', 'header', 'edge', 'identity', 'snapshot'):
            case = apply_event(case, ev, inplace=True)
            if delta and op not in ('identity', 'snapshot'):
                if op == 'analysis':
                    host.set_analysis(ev['item'], ev['value'])
                elif op == 'header':
                    host.set_header(ev['item'], case['items'][ev['item']]['header'])
                else:
                    host.set_edge(ev['first'], ev['second'], ev['record'])
            else:
                host.replace(case)
        elif op == 'rebind':
            host.rebind(case)
        elif op == 'close_rebind':
            host.close()
            host.rebind(case)
        elif op == 'close':
            host.close()
            closed = True
        else:
            raise ValueError(op)
    if not closed:
        host.close()
    return verdicts, host


def truth(trace):
    """Reference verdicts (certify_strategy per request on the current snapshot)."""
    case = deepcopy(trace['initial'])
    out = []
    for ev in trace['events']:
        op = ev['op']
        if op == 'request':
            out.append({k: v for k, v in ref.certify_strategy(case, ev['target'])['selected'].items() if k != 'reads'})
        elif op == 'batch':
            for t in ev['targets']:
                out.append({k: v for k, v in ref.certify_strategy(case, t)['selected'].items() if k != 'reads'})
        elif op in ('analysis', 'header', 'edge', 'identity', 'snapshot'):
            case = apply_event(case, ev, inplace=True)
    return out
