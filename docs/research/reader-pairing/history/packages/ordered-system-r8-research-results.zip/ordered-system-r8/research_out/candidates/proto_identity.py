"""C3 / X8: context identity - epoch label vs owner ticket vs content value identity.

Scenario traces run on protocol2 and are judged against environment truth
(the content each instance computed on).  The microbenchmark is a short local
exploratory measurement (not a formal 3-process campaign).
"""
import sys
import timeit
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from protocol2 import Proto  # noqa: E402
import proto_check as C  # noqa: E402
from common import ref  # noqa: E402
from current_baseline import typed  # noqa: E402


def lossy(c):
    return 0            # every content collides: 'hash equal' treated as identity


SCENARIOS = {
    # request on X, input goes X->Y->X while the instance runs, then it finishes
    'aba_inflight': [dict(op='request', key='a'), dict(op='replace', content='Y', label=1),
                     dict(op='replace', content='X', label=2), dict(op='finish', key='a'),
                     dict(op='consume', key='a')],
    # caller keeps its label although the content changed (epoch precondition broken, N12)
    'relabel': [dict(op='request', key='a'), dict(op='replace', content='Y', label=0),
                dict(op='finish', key='a'), dict(op='consume', key='a')],
    # X -> Y -> Z: a 1-bit incarnation counter wraps back to the starting number
    # (old knowledge keyed by a reused incarnation number is picked up by certification)
    'wrap3': [dict(op='request', key='a'), dict(op='finish', key='a'), dict(op='exit', key='a'),
              dict(op='consume', key='a'), dict(op='replace', content='Y', label=1),
              dict(op='replace', content='Z', label=2), dict(op='certify', target=0),
              dict(op='publish', target=0)],
}

MODES = {
    'epoch': dict(mode='epoch'),
    'ticket_unbounded': dict(mode='ticket'),
    'ticket_1bit_wrap': dict(mode='ticket', inc_bits=1, inc_overflow='wrap'),
    'ticket_1bit_saturate': dict(mode='ticket', inc_bits=1, inc_overflow='saturate'),
    'content_exact': dict(mode='content'),
    'content_lossy_hash': dict(mode='content', content_key=lossy),
}


def run_scenario(name, mode_kw):
    p = Proto(capacity=1, certifier=C.sound_certifier, **mode_kw)
    outs = []
    task_content = None
    for e in SCENARIOS[name]:
        if e['op'] == 'request' and task_content is None:
            task_content = p.content
        outs.append(p.step(e)['outcome'])
    if SCENARIOS[name][-1]['op'] == 'publish':
        accepted = outs[-1] == 'published'
        safe = (not accepted) or C.members(p.published[0]) == C.PLAN[p.content][0]
    else:
        accepted = outs[-1] == 'consumed'
        safe = (not accepted) or task_content == p.content
    return dict(outcomes=outs, accepted=accepted, safe=safe, starts=p.counters['starts'],
                extra_starts_to_obtain_fact=0 if accepted or name == 'wrap3' else 1,
                truth_now=p.content, computed_on=task_content)


def confirmation_after_aba(mode_kw):
    """X: certify/publish/confirm target 0; then X->Y->X.  Which confirmations count as current?"""
    p = Proto(capacity=1, certifier=C.sound_certifier, **mode_kw)
    for e in [dict(op='request', key='a'), dict(op='finish', key='a'), dict(op='exit', key='a'),
              dict(op='consume', key='a'), dict(op='certify', target=0), dict(op='publish', target=0),
              dict(op='confirm', target=0), dict(op='replace', content='Y', label=1),
              dict(op='replace', content='X', label=2)]:
        p.step(e)
    return dict(current_confirmations=len(p.current_confirmations()), history=len(p.confirmed),
                published_now=sorted(p.published))


def identity_tuple(case):
    return tuple((x.get('id', str(i)), x.get('content_version', 0), x.get('rotation', 0), x.get('orientation', 1))
                 for i, x in enumerate(case['items']))


def microbench(quick):
    from common import base_case
    rows = []
    sizes = (16, 64, 256) if quick else (16, 64, 256, 512, 2048)
    for n in sizes:
        c1 = base_case(n)
        c2 = base_case(n)
        number = max(20, 20000 // n)
        d1 = ref._Input(c1).identity
        d2 = ref._Input(c2).identity
        t1, t2 = identity_tuple(c1), identity_tuple(c2)
        table = {}
        canon1 = table.setdefault(t1, object())

        def typed_compare():
            return typed(d1) == typed(d2)

        def tuple_compare():
            return t1 == t2

        def intern_on_replace():
            return table.setdefault(identity_tuple(c2), object()) is canon1

        def build_tuple():
            return identity_tuple(c2)

        def build_typed_tuple():
            # keeps the Host's typed contract (1 vs 1.0 vs True stay distinct)
            return tuple((type(a).__name__, a, type(b).__name__, b, type(r).__name__, r, type(o).__name__, o)
                         for a, b, r, o in identity_tuple(c2))

        def counter_compare(a=12345, b=12345):
            return a == b
        r = dict(n=n)
        for name, fn in [('typed_full_compare', typed_compare), ('tuple_equal_compare', tuple_compare),
                         ('identity_tuple_build', build_tuple),
                         ('typed_tuple_build', build_typed_tuple), ('intern_build_hash_lookup', intern_on_replace),
                         ('counter_compare', counter_compare)]:
            reps = timeit.repeat(fn, number=number, repeat=5)
            r[name + '_ns'] = round(min(reps) / number * 1e9, 1)
        rows.append(r)
    # interning table growth under churn without reclamation (G6 hazard)
    table = {}
    for v in range(2000):
        c = base_case(8)
        c['items'][0]['content_version'] = v
        table.setdefault(identity_tuple(c), object())
    # semantic check: plain tuple equality conflates numeric types that typed() separates
    a, b = base_case(2), base_case(2)
    b['items'][0]['content_version'] = 0.0
    conflation = dict(tuple_equal=identity_tuple(a) == identity_tuple(b),
                      typed_equal=typed(ref._Input(a).identity) == typed(ref._Input(b).identity))
    return dict(timings=rows, intern_entries_after_2000_distinct_replaces=len(table), type_conflation=conflation,
                note='local exploratory timeit (min of 5); not a formal measurement')


def experiments(quick=False):
    scen = []
    for s in SCENARIOS:
        for m, kw in MODES.items():
            r = run_scenario(s, kw)
            scen.append(dict(scenario=s, mode=m, **r))
    conf = {m: confirmation_after_aba(kw) for m, kw in MODES.items() if m in ('ticket_unbounded', 'content_exact')}
    return dict(scenarios=scen, confirmations_after_aba=conf, microbench=microbench(quick))
