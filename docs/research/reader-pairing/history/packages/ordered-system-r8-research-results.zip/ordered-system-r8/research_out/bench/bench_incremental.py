"""B1/B2/B3 serial benchmark: plan maintenance under point updates.

Exogenous events (updates + query targets) are generated from a fixed seed
BEFORE any candidate runs and are identical for all candidates; the verdict
hash covers every query answer.  CANDIDATES[0] is the frozen behaviour.
"""
import argparse, copy, hashlib, json, os, random, subprocess, sys, time
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
from common import *          # noqa
import incremental as I
import theory_a as A

CANDIDATES = ['recompute', 'linear', 'tree', 'resync']


def make_trace(kind, n, updates, queries_per_update, seed, plan_out=False):
    rng = random.Random(seed)
    if kind in ('chain', 'chainfront'):
        case = A.decreasing_chain(n)
    else:
        case = roundtrip(random_case(rng, n, p_wide=0.12, domain='G0', settings_mix=False))
    events = []
    for u in range(updates):
        if kind == 'chainfront':
            a = 1                                   # phase toggle at the front: worst case for resync
            events.append(dict(op='edge', a=a, record=dict(status='computed', score=(0.25 if u % 2 == 0 else float(n - 1)), version=u + 2)))
        elif kind == 'chain':
            a = rng.randrange(n - 1)
            events.append(dict(op='edge', a=a, record=dict(status='computed', score=float(rng.choice((n - a, n - a + 0.5, 0.25))), version=u + 2)))
        elif rng.random() < 0.6:
            p = rng.randrange(n)
            item = copy.deepcopy(case['items'][p])
            st = 'WIDE' if rng.random() < 0.12 else 'NARROW'
            item['analysis'] = dict(status='computed', fact=fact(st, rng.choice(SIDES)), version=u + 2)
            item['header'] = fact(st)
            events.append(dict(op='item', p=p, item=item))
        else:
            a = rng.randrange(n - 1)
            events.append(dict(op='edge', a=a, record=dict(status='computed', score=rng.randrange(0, 1500) / 50, version=u + 2)))
        if plan_out:
            events.append(dict(op='plan'))
        q = queries_per_update
        whole, frac = int(q), q - int(q)
        for _ in range(whole + (1 if rng.random() < frac else 0)):
            events.append(dict(op='query', t=rng.randrange(n)))
    return dict(case=case, events=events)


SCENARIOS = []
for n in (64, 256, 1024):
    SCENARIOS.append(dict(name=f'random_n{n}_q1', kind='random', n=n, updates=200, q=1, seed=n))
    SCENARIOS.append(dict(name=f'chain_n{n}_q1', kind='chain', n=n, updates=200, q=1, seed=n + 1))
for n in (256, 1024):
    SCENARIOS.append(dict(name=f'chainfront_n{n}_q1', kind='chainfront', n=n, updates=200, q=1, seed=n + 2))
for q in (0.1, 8):
    SCENARIOS.append(dict(name=f'random_n256_q{q}', kind='random', n=256, updates=200, q=q, seed=7))
    SCENARIOS.append(dict(name=f'chain_n256_q{q}', kind='chain', n=256, updates=200, q=q, seed=8))
SCENARIOS.append(dict(name='random_n256_plan', kind='random', n=256, updates=100, q=0, seed=9, plan=True))
SCENARIOS.append(dict(name='random_n1024_queryonly', kind='random', n=1024, updates=0, q=0, seed=10, extra_queries=300))


def trace_for(sc):
    tr = make_trace(sc['kind'], sc['n'], sc['updates'], sc['q'], sc['seed'], sc.get('plan', False))
    rng = random.Random(sc['seed'] + 99)
    for _ in range(sc.get('extra_queries', 0)):
        tr['events'].append(dict(op='query', t=rng.randrange(sc['n'])))
    return tr


def run_one(sc, cand, rep=0, trace=None):
    tr = trace or trace_for(sc)
    case = tr['case']
    cls = I.CANDIDATES[cand]
    answers = []
    t0 = time.perf_counter_ns()
    impl = cls(case)
    for ev in tr['events']:
        op = ev['op']
        if op == 'item':
            impl.set_item(ev['p'], copy.deepcopy(ev['item']))
        elif op == 'edge':
            impl.set_edge(ev['a'], dict(ev['record']))
        elif op == 'query':
            answers.append(impl.unit(ev['t']))
        else:
            answers.append(len(impl.plan()))
    wall = time.perf_counter_ns() - t0
    return dict(scenario=sc['name'], candidate=cand, rep=rep, wall_ns=wall, verdict_sha256=digest(answers),
                work=dict(getattr(impl, 'work', {})), events=len(tr['events']))


def verify(sc):
    """Outside timing: every query answer equals reference.complete_plan."""
    tr = trace_for(sc)
    cur = copy.deepcopy(tr['case'])
    impls = {c: I.CANDIDATES[c](tr['case']) for c in CANDIDATES}
    bad = 0
    for ev in tr['events'][:400]:
        if ev['op'] == 'item':
            cur['items'][ev['p']] = copy.deepcopy(ev['item'])
            for m in impls.values(): m.set_item(ev['p'], copy.deepcopy(ev['item']))
        elif ev['op'] == 'edge':
            a = ev['a']
            cur['edges'] = [e for e in cur['edges'] if e['first'] != a] + [dict(ev['record'], first=a, second=a + 1)]
            for m in impls.values(): m.set_edge(a, dict(ev['record']))
        elif ev['op'] == 'query':
            want = unit_of(ref.complete_plan(cur), ev['t'])
            bad += sum(m.unit(ev['t']) != want for m in impls.values())
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--processes', type=int, default=1)
    ap.add_argument('--reps', type=int, default=3)
    ap.add_argument('--warmup', type=int, default=1)
    ap.add_argument('--only', default='')
    ap.add_argument('--out')
    ap.add_argument('--child', action='store_true')
    args = ap.parse_args()
    if args.processes > 1 and not args.child:
        with open(args.out, 'w') as fh:
            for proc in range(args.processes):
                cmd = [sys.executable, str(HERE), '--child', '--reps', str(args.reps), '--warmup', str(args.warmup)]
                if args.only: cmd += ['--only', args.only]
                res = subprocess.run(cmd, capture_output=True, text=True, check=True)
                for line in res.stdout.splitlines():
                    row = json.loads(line); row['process_index'] = proc
                    fh.write(json.dumps(row) + '\n')
        return
    pid = os.getpid(); utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    src = hashlib.sha256(Path(I.__file__).read_bytes()).hexdigest()[:16]
    for sc in SCENARIOS:
        if args.only and args.only not in sc['name']:
            continue
        tr = trace_for(sc)
        bad = verify(sc)
        order = CANDIDATES[:]
        for rep in range(args.warmup + args.reps):
            order = order[1:] + order[:1]          # rotate configuration order
            for cand in order:
                if cand == 'recompute' and sc['n'] >= 1024:
                    continue          # frozen full recompute at n=1024 costs 25-40 s per pass; reported from n<=256
                row = run_one(sc, cand, rep, tr)
                row.update(pid=pid, utc=utc, warmup=rep < args.warmup, verify_mismatch=bad, source_sha16=src,
                           trace_sha256=digest(tr))
                print(json.dumps(row), flush=True)


if __name__ == '__main__':
    main()
