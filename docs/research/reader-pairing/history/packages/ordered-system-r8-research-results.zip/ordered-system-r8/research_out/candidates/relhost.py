"""L1 early-certification hosts: a strong L0 host first, a relational
certifier only when the L0 verdict is need_facts (never when blocked, so the
failure scope of H4 is the L0 one).

  RelHost(mode='tree')   independent-leaf relational segment tree, maintained
                         lazily from positional diffs (O(changed * log n)).
  RelHost(mode='exact')  exact forward-frontier DP (FrontierCache), frontiers
                         truncated at the first changed boundary.
Extra certificates hold over every completion of current knowledge under
alpha header authority in the extension rank domain (proofs L-R1, L-R2).
Their public fields: needs=[], failures={}, first=0 (proof from the exact
start state), steps=relational evaluations, dependent_items = positions
0..min(n-1, target+3) (conservative: every leaf before the target).
"""
import copy

import transducer as T
import omega as O


def _ctx_key(case):
    s = case.get('settings', {})
    return (case.get('generation', 0), case.get('order_revision', 0), len(case['items']),
            tuple((x.get('id', str(i)), x.get('content_version', 0), x.get('rotation', 0), x.get('orientation', 1))
                  for i, x in enumerate(case['items'])),
            repr(sorted(s.items())), bool(case.get('closed', False)))


class RelHost:
    def __init__(self, case, base_factory, mode='tree', domain='ext'):
        self.base = base_factory(case)
        self.mode, self.domain = mode, domain
        self.metrics = self.base.metrics
        self._mirror = copy.deepcopy(case)
        self._key = _ctx_key(case)
        self._facts = None
        self._tree = None
        self._fc = None
        self._dirty_items, self._dirty_edges = set(), set()

    # ---- lifecycle --------------------------------------------------
    def _reset(self, case):
        self._mirror = copy.deepcopy(case)
        self._key = _ctx_key(case)
        self._facts = self._tree = self._fc = None
        self._dirty_items.clear(); self._dirty_edges.clear()

    def replace(self, case):
        self.base.replace(case)
        key = _ctx_key(case)
        if key != self._key or self._facts is None:
            self._reset(case)
            return
        old = self._mirror
        for p, (a, b) in enumerate(zip(old['items'], case['items'])):
            if a != b:
                self._dirty_items.add(p)
        oe = {(e['first'], e['second']): e for e in old.get('edges', [])}
        ne = {(e['first'], e['second']): e for e in case.get('edges', [])}
        for k in set(oe) | set(ne):
            if oe.get(k) != ne.get(k):
                self._dirty_edges.add(k[0])
        self.metrics['rel_diff_calls'] += 1
        self._mirror = copy.deepcopy(case)

    def rebind(self, case):
        self.base.rebind(case)
        self._reset(case)

    def close(self):
        self.base.close()
        self._facts = self._tree = self._fc = None

    def locate(self, item_id, sequence):
        self.base.locate(item_id, sequence)

    # ---- relational structures --------------------------------------
    def _sync(self):
        if self._facts is None:
            self._facts = T.Facts(copy.deepcopy(self._mirror), 'omega', self.domain)
            self._dirty_items.clear(); self._dirty_edges.clear()
            if self.mode in ('tree', 'portfolio'):
                self._tree = T.RelTree(self._facts, self.metrics)
                self.metrics['rel_builds'] += 1
            return
        if not (self._dirty_items or self._dirty_edges):
            return
        F = self._facts
        leaves = set()
        lo = F.n
        for p in self._dirty_items:
            F.refresh_item(p, copy.deepcopy(self._mirror['items'][p]))
            leaves.update(T.affected_leaves(p)); lo = min(lo, p)
        recs = {(e['first'], e['second']): e for e in self._mirror.get('edges', [])}
        for a in self._dirty_edges:
            r = recs.get((a, a + 1))
            if r is None:
                F.records.pop(a, None)
            else:
                F.records[a] = r
            leaves.update((a - 1, a)); lo = min(lo, a)
        F.ix._edges = None
        self._dirty_items.clear(); self._dirty_edges.clear()
        if self._tree is not None:
            self._tree.update_leaves(sorted(leaves))
        if self._fc is not None:
            keep = max(1, lo - 2)
            del self._fc.frontiers[keep:]
            self._fc.F, self._fc.ctx = F, T.Ctx(F)

    def request(self, target):
        v = self.base.request(target)
        if v['status'] != 'need_facts':
            return v
        self.metrics['rel_attempts'] += 1
        self._sync()
        if self.mode in ('tree', 'portfolio'):
            units = self._tree.units(target)
            ok = len(units) == 1
            unit = next(iter(units.values())) if ok else None
            if not ok and self.mode == 'portfolio':      # F6: escalate to the exact DP
                self.metrics['rel_escalations'] += 1
                if self._fc is None:
                    self._fc = O.FrontierCache(self._facts.case, self.domain)
                    self._fc.F, self._fc.ctx = self._facts, T.Ctx(self._facts)
                st, unit = self._fc.certify(target)
                ok = st == 'certified'
        else:
            if self._fc is None:
                self._fc = O.FrontierCache(self._facts.case, self.domain)
                self._fc.F, self._fc.ctx = self._facts, T.Ctx(self._facts)
            st, unit = self._fc.certify(target)
            ok = st == 'certified'
        if not ok:
            return v
        self.metrics['rel_certified'] += 1
        n = self._facts.n
        return dict(status='certified', unit=unit, needs=[], failures={}, first=0,
                    steps=0, dependent_items=list(range(0, min(n - 1, target + 3) + 1)))


class RelHostDelta(RelHost):
    """X1 (B2 x C1): owner-method updates.  The base host is a delta-capable
    XHost (fine-grained per-position revisions); the relational tree gets its
    dirty positions from the same owner calls, so no mirror copy / diff."""

    def set_analysis(self, i, analysis):
        self.base.set_analysis(i, analysis)
        self._mirror['items'][i]['analysis'] = copy.deepcopy(analysis)
        self._dirty_items.add(i)

    def set_header(self, i, header):
        self.base.set_header(i, header)
        self._mirror['items'][i]['header'] = copy.deepcopy(header)
        self._dirty_items.add(i)

    def set_edge(self, a, b, record):
        self.base.set_edge(a, b, record)
        recs = [e for e in self._mirror.get('edges', []) if (e['first'], e['second']) != (a, b)]
        if record is not None:
            r = copy.deepcopy(record); r['first'], r['second'] = a, b
            recs.append(r)
        self._mirror['edges'] = recs
        if b == a + 1:
            self._dirty_edges.add(a)
