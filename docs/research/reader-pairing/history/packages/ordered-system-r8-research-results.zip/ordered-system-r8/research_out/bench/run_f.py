"""F2/F4 studies -> results/f_family.json."""
import copy, json, random, sys, time, math, itertools
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import *
import transducer as T, omega as O, relational_exp as X, theory_a as A

out = {}; t0 = time.time()
# F2 route 1: 'optimisation encoding' (max-weight matching on the path) is NOT the rule (N01 regression)
def mwm_plan_members(c):
    data = ref._Input(c); n = len(data.items)
    dim = lambda i: data.effective(i)
    side = lambda i: (dim(i) or {}).get('side', 'UNKNOWN')
    rank = lambda a, b: (lambda e: e.get('score') if e['status'] == 'computed' else None)(data.edge(a, b))
    sc = ref._Scan(n, data.settings, dim, side, side, rank)
    w = []
    for i in range(n - 1):
        if not sc.allowed(i): w.append(None); continue
        r = rank(i, i + 1)
        w.append(sc.strength(i) * 1e6 + 1e3 - (min(r, 999) if isinstance(r, (int, float)) else 999))
    best = [0.0] * (n + 1); choice = [False] * (n + 1)
    for i in range(n - 2, -1, -1):
        skip = best[i + 1]
        take = (w[i] + best[i + 2]) if w[i] is not None else -1
        best[i] = max(skip, take); choice[i] = take > skip
    m, i = {}, 0
    while i < n:
        if i < n - 1 and choice[i]: m[i] = m[i + 1] = (i, i + 1); i += 2
        else: m[i] = (i,); i += 1
    return m
rng = random.Random(51); diff = cases = 0; cex = None
for k in range(2000):
    c = roundtrip(random_case(rng, rng.randrange(2, 14), domain='G0'))
    mref = {}
    for u in ref.complete_plan(c):
        it = tuple(s['item'] for s in u['slots'])
        for x in it: mref[x] = it
    mm = mwm_plan_members(c); cases += 1
    if mm != mref:
        diff += 1
        if cex is None or len(c['items']) < len(cex['items']): cex = c
out['F2_mwm_not_equivalent'] = dict(cases=cases, member_mismatch=diff, smallest_counterexample=cex,
    note='a unique maximum-weight matching is a different rule (phase/reservation semantics are lost)')
# F2 route 2: exact path DP vs world-enumeration 'solver' (backtracking over all completions)
rows = []
rng = random.Random(52)
for k in range(120):
    n = rng.randrange(3, 8)
    c = roundtrip(random_case(rng, n, p_unknown=0.35, p_edge_unknown=0.35))
    t = rng.randrange(n)
    t1 = time.perf_counter_ns(); st, _ = O.certify_exact(c, t); dp = time.perf_counter_ns() - t1
    try:
        t1 = time.perf_counter_ns(); U = O.oracle_units(c, t, cap=30000); en = time.perf_counter_ns() - t1
        nworlds = sum(1 for _ in O.worlds(c, cap=30000))
    except OverflowError:
        en, nworlds, U = None, None, None
    rows.append(dict(n=n, dp_ms=round(dp / 1e6, 3), enum_ms=None if en is None else round(en / 1e6, 3), worlds=nworlds,
                     agree=None if U is None else ((st == 'certified') == (len(U) == 1))))
done = [r for r in rows if r['enum_ms'] is not None]
out['F2_dp_vs_enumeration'] = dict(cases=len(rows), enumerated=len(done), agree=sum(bool(r['agree']) for r in done),
    median_dp_ms=sorted(r['dp_ms'] for r in done)[len(done) // 2], median_enum_ms=sorted(r['enum_ms'] for r in done)[len(done) // 2],
    max_worlds=max(r['worlds'] for r in done), over_cap=len(rows) - len(done))
# F4: optimal adaptive decision tree (minimax) vs one-round needs, size of the compiled DAG
def strategy_size(c, t, d, memo):
    key = (json.dumps(c, sort_keys=True), d)
    if key in memo: return memo[key]
    if X.certified(c, t): memo[key] = (0, 1); return memo[key]
    if d == 0: memo[key] = (math.inf, 1); return memo[key]
    best = (math.inf, 0)
    for h in X.unknown_facts(c):
        worst, size = 0, 1
        for v in X.options(c, h):
            dd, ss = strategy_size(X.reveal(c, h, v), t, d - 1, memo)
            worst = max(worst, dd + 1); size += ss
            if worst > best[0]: break
        if (worst, size) < best: best = (worst, size)
    memo[key] = best; return best
rng = random.Random(53); rows = []
for k in range(300):
    if len(rows) >= 25: break
    n = rng.randrange(3, 6)
    c = roundtrip(random_case(rng, n, p_unknown=0.35, p_edge_unknown=0.35))
    t = rng.randrange(n)
    r = ref.certify_strategy(c, t)['selected']
    if r['status'] != 'need_facts': continue
    t1 = time.perf_counter_ns(); depth, size = strategy_size(c, t, 3, {}); ms = (time.perf_counter_ns() - t1) / 1e6
    rows.append(dict(n=n, unknown=len(X.unknown_facts(c)), reference_needs=len(r['needs']), adaptive_depth=depth,
                     dag_nodes=size, compile_ms=round(ms, 1)))
out['F4_decision_dag'] = dict(rows=rows, note='minimax over abstract outcome classes; compile cost grows with outcome '
                                             'classes^depth and is invalidated by any knowledge change')
out['seconds'] = round(time.time() - t0, 1)
Path(__file__).resolve().parents[1].joinpath('results', 'f_family.json').write_text(json.dumps(out, indent=1, default=str))
print(json.dumps({k: v for k, v in out.items() if k not in ('F4_decision_dag',)}, default=str)[:1500])
print([(r['unknown'], r['reference_needs'], r['adaptive_depth'], r['dag_nodes'], r['compile_ms']) for r in rows])
