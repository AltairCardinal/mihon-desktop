"""NH-2: unconditional revision bump.  Identical to the frozen Host except that
replace() advances the global evidence revision on EVERY call instead of first
comparing typed(whole old case) with typed(whole new case).  Safety: a bump
only turns potential stamp hits into exact read validations (never the
reverse), so verdicts are unchanged (L0 w.r.t. the frozen host, including its
C5 defect); the saved work is the two whole-case typed() constructions."""
import copy

import reference as ref
from current_baseline import Host, typed


class AlwaysBump(Host):
    def replace(self, case):
        if self._closed:
            raise ValueError('closed host requires rebind')
        next_case = copy.deepcopy(case)
        data = ref._Input(next_case)
        identity, settings = typed(data.identity), typed(data.settings)
        self._revision = min(self._revision + 1, (1 << 63) - 1)
        self.metrics['evidence_updates'] += 1
        if getattr(self, '_identity', None) != identity:
            self._structure = None
        self._case, self._identity, self._settings = next_case, identity, settings
        self.metrics['update_calls'] += 1
        self.metrics['update_item_slots'] += len(next_case['items'])
