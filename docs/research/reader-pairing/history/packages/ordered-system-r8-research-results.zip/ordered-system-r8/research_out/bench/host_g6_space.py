"""G6 / X5 whole-lifecycle space study (structural units + tracemalloc retained bytes).

python3 research_out/bench/host_g6_space.py  -> research_out/results/hosts/g6_space.json
Retained bytes = tracemalloc current traced memory of the host object graph's
allocations while the host is alive (measured in a dedicated pass; timing not taken).
"""
from copy import deepcopy
import json
import sys
import tracemalloc
from dataclasses import replace as R
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))
import common  # noqa: E402,F401
from current_baseline import Host, Config  # noqa: E402
from hosts import XHost, XConfig, HostMutant as M  # noqa: E402
from host_traces import generate, apply_event  # noqa: E402

B = XConfig()
CONFIGS = {
    'current': lambda c: Host(c, config=Config.current()),
    'x_fix_stamp': lambda c: XHost(c, config=B),
    'x_revdep': lambda c: XHost(c, config=R(B, invalidation='revdep')),
    'x_revdep_noderegister(mutant)': lambda c: XHost(c, config=R(B, invalidation='revdep'), mutant=M.REVDEP_NO_DEREGISTER),
    'x_log64': lambda c: XHost(c, config=R(B, invalidation='log')),
    'x_log_nocap': lambda c: XHost(c, config=R(B, invalidation='log', log_cap=None)),
    'x_interned': lambda c: XHost(c, config=R(B, proof='interned')),
    'x_interned_noprune(mutant)': lambda c: XHost(c, config=R(B, proof='interned'), mutant=M.INTERN_NO_PRUNE),
    'x_snapshot_view': lambda c: XHost(c, config=R(B, view='snapshot')),
    'x_cap8': lambda c: XHost(c, config=R(B, capacity=8)),
    'x_bytes640': lambda c: XHost(c, config=R(B, cache='bytes')),
    'x_gds': lambda c: XHost(c, config=R(B, cache='gds')),
    'x_gdsbytes640': lambda c: XHost(c, config=R(B, cache='gdsbytes')),
}


def frozen_size(h):
    reads = sum(len(e['result']['proof'][2]) for e in h._memo.values())
    return dict(entries=len(h._memo), read_keys=reads, structure_slots=len(h._structure or {}), snapshots=1)


def run(name, factory, tr, sample=60):
    tracemalloc.start()
    base = tracemalloc.get_traced_memory()[0]
    c = deepcopy(tr['initial'])
    h = factory(c)
    out = []
    for k, ev in enumerate(tr['events']):
        op = ev['op']
        if op == 'request':
            h.request(ev['target'])
        elif op in ('analysis', 'header', 'edge', 'identity'):
            c = apply_event(c, ev); h.replace(c)
        elif op in ('rebind', 'close_rebind'):
            h.rebind(c)
        if k % sample == 0 or k == len(tr['events']) - 2:
            del_c = None
            cur = tracemalloc.get_traced_memory()[0] - base
            st = h.structural_size() if hasattr(h, 'structural_size') else frozen_size(h)
            out.append(dict(event=k, retained_bytes_incl_driver_case=cur, **st))
    peak = tracemalloc.get_traced_memory()[1] - base
    tracemalloc.stop()
    return dict(config=name, samples=out, peak_bytes=peak)


def main():
    res = {}
    for label, drop in (('long_session_no_rebind', True), ('with_rebinds', False)):
        tr = generate(9, 32, 200, 'jump', 'churn')
        if drop:
            tr['events'] = [e for e in tr['events'] if e['op'] not in ('rebind', 'close_rebind', 'identity')]
        res[label] = [run(n, f, tr) for n, f in CONFIGS.items()]
    p = HERE.parent / 'results' / 'hosts' / 'g6_space.json'
    p.write_text(json.dumps(res, indent=1), encoding='utf-8')
    for label, rows in res.items():
        print(label)
        for r in rows:
            last = r['samples'][-1]
            mx = {k: max(s[k] for s in r['samples']) for k in ('entries', 'read_keys')}
            print(f"  {r['config']:32s} peak={r['peak_bytes']/1024:8.1f}KiB last_retained={last['retained_bytes_incl_driver_case']/1024:8.1f}KiB "
                  f"max_entries={mx['entries']} max_reads={mx['read_keys']} "
                  + ' '.join(f"{k}={last.get(k)}" for k in ('revdep_edges', 'log_len', 'intern_values') if k in last))


if __name__ == '__main__':
    main()
