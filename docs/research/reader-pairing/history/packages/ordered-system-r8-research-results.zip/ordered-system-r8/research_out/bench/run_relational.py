"""Partial-knowledge experiments (A3 A4 E2 E6 F3 F5 X10); writes results/relational.json."""
import copy, json, random, sys, time, collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import *
import transducer as T, omega as O, relational_exp as X

out = {}; t0 = time.time()
# 1. paired domain comparison on identical cases with G0-valued known ranks (all domains valid)
rng = random.Random(21); st = collections.Counter()
for k in range(1500):
    n = rng.randrange(3, 13)
    c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.4, p_fail=0.05, domain='G0'))
    t = rng.randrange(n); st['cases'] += 1
    r = ref.certify_strategy(c, t)['selected']; st['reference_strategy'] += r['status'] == 'certified'
    st['reference_blocked'] += r['status'] == 'blocked'
    for d in ('ext', 'nonneg', 'G0'):
        st['tree_' + d] += T.certify_tree(c, t, d)[0] == 'certified'
        st['exact_' + d] += O.certify_exact(c, t, d)[0] == 'certified'
    st['exact_ext_but_reference_blocked'] += (r['status'] == 'blocked' and O.certify_exact(c, t, 'ext')[0] == 'certified')
out['paired_domains'] = dict(st)
# 2. E6: smallest case where the independent-leaf tree is ambiguous but the exact DP certifies
rng = random.Random(22); e6 = None; e6_count = 0; total = 0
for k in range(6000):
    n = rng.randrange(2, 8)
    c = roundtrip(random_case(rng, n, p_unknown=0.4, p_edge_unknown=0.4))
    t = rng.randrange(n); total += 1
    a = T.certify_tree(c, t)[0]; b = O.certify_exact(c, t)
    if a != 'certified' and b[0] == 'certified':
        e6_count += 1
        if e6 is None or n < len(e6['case']['items']):
            e6 = dict(case=c, target=t, exact_unit=b[1], tree_units=list(T.RelTree(T.Facts(c, 'omega')).units(t).keys()))
out['E6_tree_too_wide'] = dict(trials=total, tree_ambiguous_exact_certified=e6_count, smallest=e6)
# 3. E6 negative: DP frontier growth when many facts unknown
rows = []
for n in (8, 16, 32, 64):
    for pu in (0.2, 0.5, 0.8):
        rr = random.Random(n * 100 + int(pu * 10))
        c = roundtrip(random_case(rr, n, p_unknown=pu, p_edge_unknown=pu, settings_mix=False))
        cnt = {}
        tt = time.perf_counter_ns(); res = O.certify_exact(c, n - 1, 'ext', counters=cnt, limit=300000)
        rows.append(dict(n=n, p_unknown=pu, status=res[0], dp_evals=cnt.get('dp_evals'), max_frontier=cnt.get('dp_max_frontier'),
                         ms=round((time.perf_counter_ns() - tt) / 1e6, 2)))
out['E6_frontier_growth'] = rows
# 4. E2: old representative scheme vs exact adjacent doubles
cs = frozenset({((('e', 2), ('k', 1e17)), True)})
out['E2_old_vs_exact'] = dict(constraint='x < 1e17 (x unknown rank)', exact=O.T.feasible(cs, 'ext'),
                              old_representatives=X.feasible_old_representatives(cs))
cs2 = frozenset({((('e', 2), ('k', -1.7976931348623157e308)), True)})
out['E2_below_min'] = dict(constraint='x < -DBL_MAX', exact=O.T.feasible(cs2, 'ext'))
# concrete unsound certificate under the old scheme: patch feasibility and certify
c = base_case(5, automatic=True)
c['edges'][1]['score'] = 1e17
c['edges'] = [e for e in c['edges'] if e['first'] != 2]
orig = T.feasible
T.feasible = lambda cons, dom: X.feasible_old_representatives(cons, dom)
try:
    old_status = T.certify_tree(c, 4)
finally:
    T.feasible = orig
new_status = T.certify_tree(c, 4)
units = O.oracle_units(c, 4)
out['E2_concrete'] = dict(case=c, target=4, old_scheme=[old_status[0], old_status[1]], exact_scheme=[new_status[0], new_status[1]],
                          oracle_units=len(units),
                          verdict='old scheme UNSOUND' if old_status[0] == 'certified' and len(units) > 1 else 'no unsoundness shown')
# 5. A3 minimal support vs reference reads (tiny/medium cases, certified by exact DP)
rng = random.Random(23); rows = []
for k in range(250):
    n = rng.randrange(3, 10)
    c = roundtrip(random_case(rng, n, p_unknown=0.15, p_edge_unknown=0.15))
    t = rng.randrange(n)
    r, keys = X.reference_fact_reads(c, t)
    if r['status'] != 'certified':
        continue
    ms = X.minimal_support(c, t)
    if ms is None:
        continue
    # active refutation of every dropped fact: sample worlds of the reduced case
    viol = 0
    try:
        U = O.oracle_units(ms['reduced_case'], t, cap=20000)
        viol = int(len(U) != 1 or T._key(ms['unit']) not in U)
        checked = True
    except OverflowError:
        checked = False
    rows.append(dict(n=n, ref_fact_reads=len(keys), minimal_support=len(ms['support']), oracle_checked=checked, violation=viol))
agg = dict(cases=len(rows), mean_ref_reads=round(sum(r['ref_fact_reads'] for r in rows) / len(rows), 2),
           mean_min_support=round(sum(r['minimal_support'] for r in rows) / len(rows), 2),
           oracle_checked=sum(r['oracle_checked'] for r in rows), violations=sum(r['violation'] for r in rows))
out['A3_minimal_support'] = dict(summary=agg, rows=rows[:40])
# 6. A4: information lower bounds on tiny need_facts cases
rng = random.Random(24); rows = []
for k in range(400):
    if len(rows) >= 40: break
    n = rng.randrange(3, 7)
    c = roundtrip(random_case(rng, n, p_unknown=0.35, p_edge_unknown=0.35))
    t = rng.randrange(n)
    r = ref.certify_strategy(c, t)['selected']
    if r['status'] != 'need_facts':
        continue
    try:
        size, S = X.min_nonadaptive(c, t, max_size=3, cap=3000)
        depth = X.adaptive_depth(c, t, max_depth=3, cap=3000)
    except OverflowError:
        continue
    exact_now = O.certify_exact(c, t)[0] == 'certified'
    rows.append(dict(n=n, target=t, reference_needs=len(r['needs']), certified_now_by_exact=exact_now,
                     min_nonadaptive=size, adaptive_depth=None if depth == float('inf') else depth,
                     unknown_facts=len(X.unknown_facts(c))))
out['A4_lower_bounds'] = dict(rows=rows, summary=dict(
    cases=len(rows), exact_certifies_without_any_new_fact=sum(r['certified_now_by_exact'] for r in rows),
    mean_reference_needs=round(sum(r['reference_needs'] for r in rows) / max(1, len(rows)), 2),
    mean_min_nonadaptive=round(sum(r['min_nonadaptive'] or 0 for r in rows if r['min_nonadaptive'] is not None) / max(1, sum(1 for r in rows if r['min_nonadaptive'] is not None)), 2),
    unresolved_within_3=sum(1 for r in rows if r['min_nonadaptive'] is None)))
# 7. F3: genuine ambiguity by world sampling before running the exact DP
rng = random.Random(25); f3 = collections.Counter()
for k in range(600):
    n = rng.randrange(4, 14)
    c = roundtrip(random_case(rng, n, p_unknown=0.35, p_edge_unknown=0.35))
    t = rng.randrange(n)
    if T.certify_tree(c, t)[0] == 'certified':
        f3['tree_certified'] += 1; continue
    f3['tree_ambiguous'] += 1
    # sample up to 8 random consistent completions (cheap, exact plans of complete worlds)
    seen = set(); genuine = False
    try:
        ws = list(O.worlds(c, cap=5000))
    except OverflowError:
        ws = None
    if ws:
        for w in rng.sample(ws, min(8, len(ws))):
            seen.add(T._key(unit_of(ref.complete_plan(w), t)))
            if len(seen) > 1:
                genuine = True; break
    if genuine:
        f3['genuine_by_sampling'] += 1
    else:
        ex = O.certify_exact(c, t)[0]
        f3['dp_needed'] += 1
        f3['dp_certified_after_tree_ambiguous'] += ex == 'certified'
out['F3_cegar'] = dict(f3)
out['seconds'] = round(time.time() - t0, 1)
Path(__file__).resolve().parents[1].joinpath('results', 'relational.json').write_text(json.dumps(out, indent=1, allow_nan=False, default=str))
print(json.dumps({k: (v if k not in ('A3_minimal_support', 'A4_lower_bounds', 'E6_tree_too_wide', 'E2_concrete') else '...') for k, v in out.items()}, indent=1, default=str)[:4000])
print(json.dumps(out['A3_minimal_support']['summary']), json.dumps(out['A4_lower_bounds']['summary']))
print(out['E2_concrete']['verdict'], out['E6_tree_too_wide']['tree_ambiguous_exact_certified'])
