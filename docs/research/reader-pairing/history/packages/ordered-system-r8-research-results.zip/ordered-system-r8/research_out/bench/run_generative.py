"""E1/E3/E5 checks on the exact G0 sub-process; writes results/generative.json."""
import json, random, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import *
import generative as G
import theory_a as A

out = {}; t0 = time.time(); rng = random.Random(11)
# E1: constructive realizability of rank sequences on NARROW chains (rotation 0, h>=50)
ok = bad = 0; examples = []
for trial in range(300):
    n = rng.randrange(2, 9)
    widths = [rng.choice((1, 2, 3, 4, 5, 6, 7, 8, 12)) for _ in range(n)]
    targets = [None if rng.random() < .2 else rng.randrange(0, 1500) / 50 for _ in range(n - 1)]
    d = rng.choice(('AB', 'BA'))
    tens, L, R = G.realise_chain(targets, widths, h=60, seed=trial, direction=d)
    got = G.derive_ranks(tens, widths, h=60, direction=d)
    if got == targets: ok += 1
    else:
        bad += 1
        if len(examples) < 3: examples.append(dict(targets=targets, got=got, widths=widths))
out['E1_realise_chain'] = dict(trials=300, exact=ok, mismatch=bad, mismatch_examples=examples,
    scope='rotation 0, h=60 (distinct rows), widths incl. 1 and 5 (L/R share a column), both directions')
# E1 consequence: an abstract rank-only lower-bound pair transported to G0 (decreasing chain vs perturbed)
n = 10
t1 = [ (n - j) * 0.5 for j in range(n - 1)]
t2 = list(t1); t2[1] = 0.1                                    # one early rank differs
w = [4] * n
real = []
for tg in (t1, t2):
    tens, L, R = G.realise_chain(tg, w, h=60, seed=3)
    ranks = G.derive_ranks(tens, w, h=60)
    c = A.chain_case(n, ranks)
    real.append((ranks, ref.complete_plan(c)))
out['E1_transport_example'] = dict(ranks_world1=real[0][0], ranks_world2=real[1][0],
    plan_world1=[[s['item'] for s in u['slots']] for u in real[0][1]],
    plan_world2=[[s['item'] for s in u['slots']] for u in real[1][1]],
    last_target_differs=unit_of(real[0][1], n - 1) != unit_of(real[1][1], n - 1),
    note='two G0-realised worlds that agree on every fact except edge (1,2): the unit of the LAST item differs, '
         'so any certificate for item n-1 must depend on edge (1,2) (distance n-3) in the generative domain too')
# E3: AB and BA ranks of the same object pair are independent (different vector pairs)
pairs = []
for trial in range(50):
    ta, tb = rng.randrange(0, 1500) / 50, rng.randrange(0, 1500) / 50
    # objects 0,1: AB uses R0,L1 ; BA uses L0,R1 -> build both explicitly
    base = G._base_vector(random.Random(trial))
    R0 = base; L1 = G._shift(base, round(ta * 50), random.Random(trial + 1))
    L0 = G._shift(base, 200, random.Random(trial + 2)); R1 = G._shift(L0, round(tb * 50), random.Random(trial + 3))
    pairs.append((G.rank(R0, L1)[0] == ta) and (G.rank(L0, R1)[0] == tb))
out['E3_direction_independence'] = dict(trials=50, both_hit=sum(pairs))
# E5: progressive bounds (sound) vs subsample shortcut (unsound)
used = []; unsound_prog = 0; sub_wrong = 0; sub_cex = None
for trial in range(2000):
    r = random.Random(trial)
    base = G._base_vector(r)
    X = G.normalise(base)
    m1 = r.randrange(0, 1500); m2 = m1 + r.choice((-3, -1, 0, 1, 3, 50, 400, -400)) if trial % 2 else r.randrange(0, 1500)
    m2 = max(0, min(1499, m2))
    Y = G.normalise(G._shift(base, m1, r)); W = G.normalise(G._shift(base, m2, r))
    exact = G.l1_m(X, Y) < G.l1_m(X, W)
    dec, k = G.progressive_compare(X, Y, X, W)
    unsound_prog += dec != exact
    used.append(k)
    s = G.subsample_estimate_compare(X, Y, X, W)
    if s != exact:
        sub_wrong += 1
        if sub_cex is None: sub_cex = dict(m1=m1, m2=m2, exact=exact, subsample=s, seed=trial)
used.sort()
out['E5_progressive'] = dict(comparisons=2000, wrong=unsound_prog,
    elements_used_quantiles={q: used[int(q * (len(used) - 1))] for q in (0.1, 0.25, 0.5, 0.75, 0.9, 1.0)},
    full_precision_needed=sum(1 for u in used if u == 50))
out['E5_subsample_shortcut'] = dict(comparisons=2000, wrong=sub_wrong, first_counterexample=sub_cex)
out['seconds'] = round(time.time() - t0, 1)
Path(__file__).resolve().parents[1].joinpath('results', 'generative.json').write_text(json.dumps(out, indent=1, allow_nan=False))
print(json.dumps(out, indent=1)[:2500])
