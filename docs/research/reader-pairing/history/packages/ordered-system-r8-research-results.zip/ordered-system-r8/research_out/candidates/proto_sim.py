"""Synthetic discrete-event simulator (G2/G3/G4/D4/D5/X3).  Time unit `u` is NOT calibrated.

Exogenous inputs (request targets + arrival times, service times keyed by task
identity, update times) are frozen before any policy runs; policies only see
events that already happened.  Nonpreemptible tasks: a cancelled instance keeps
its slot until its own finish time.

Request for target t needs task identities {t, t+1} (a fact of the target and of
its right neighbour), so adjacent requests share work.  Knowledge never expires
unless an update touches the identity (G4).
"""
import hashlib
import heapq
import json
import statistics


def slow_factor(seed, ident, frac, factor):
    h = int.from_bytes(hashlib.sha256(json.dumps([seed, ident]).encode()).digest()[:8], 'big')
    return factor if (h % 10000) < frac * 10000 else 1


def needs(t):
    return (t, t + 1)


class Inst:
    __slots__ = ('ident', 'start', 'end', 'cls', 'cancelled', 'cancel_at', 'version', 'batch')

    def __init__(self, ident, start, end, cls, version, batch=None):
        self.ident, self.start, self.end, self.cls = ident, start, end, cls
        self.cancelled, self.cancel_at, self.version, self.batch = False, None, version, batch


def simulate(work, policy):
    """work: dict(requests=[(time, target)], service={ident: u} or default, capacity, updates=[(time, idents)])
    policy: dict(admission='per_completion'|'barrier'|'priority'|'aging', prefetch=k, reserve=r,
                 cancel='none'|'queued'|'all', admit_cancelled=bool, revive='revive'|'restart'|'duplicate',
                 aging=u, churn='global'|'fine', debounce=u)"""
    C = work['capacity']
    svc = work.get('service', {})
    base = work.get('base', 1.0)
    adm = policy.get('admission', 'per_completion')
    k = policy.get('prefetch', 0)
    reserve = policy.get('reserve', 0)
    cancel = policy.get('cancel', 'none')
    admit_cancelled = policy.get('admit_cancelled', False)
    revive = policy.get('revive', 'revive')
    aging = policy.get('aging', 20.0)
    churn = policy.get('churn', 'fine')
    debounce = policy.get('debounce', 0.0)

    def service(ident):
        return svc.get(str(ident), base) if isinstance(svc, dict) else base

    ev = []
    seq = 0

    def push(t, kind, data):
        nonlocal seq
        heapq.heappush(ev, (t, seq, kind, data))
        seq += 1

    for i, (t, target) in enumerate(work['requests']):
        push(t, 'req', (i, target))
    for t, idents in work.get('updates', []):
        push(t, 'upd', tuple(idents))
    for t, ident in work.get('background', []):
        push(t, 'bg', ident)
    gate = policy.get('prefetch_max_service')      # precondition: service time known and bounded

    known = {}                # ident -> version admitted
    version = {}              # ident -> current version
    queue = {}                # ident -> dict(cls, enq, consumers)
    running = []              # Inst
    pending = {}              # request -> dict(t, arrival, needs)
    stats = dict(starts=0, busy=0.0, wasted=0.0, cancel_occupancy=0.0, duplicate=0, latencies=[],
                 used=set(), produced=[], optional_wait=[], dropped_queued=0, quiet_until=0.0)
    last_target = [None]
    batch_open = [None]
    now = 0.0
    hold = {}                 # barrier: results held until batch completes

    def cur(ident):
        return version.get(ident, 0)

    def is_known(ident):
        return known.get(ident) == cur(ident)

    def running_for(ident):
        # held (barrier) results are still in flight: they must not be restarted
        held = hold.get('b', [])
        return [r for r in running + held if r.ident == ident and r.version == cur(ident)]

    def enqueue(ident, cls, rid):
        if is_known(ident):
            return
        live = running_for(ident)
        if live:
            r = live[0]
            if r.cancelled and cls == 'req':
                if revive == 'revive':
                    r.cancelled = False
                    r.cancel_at = None
                elif revive == 'duplicate':
                    stats['duplicate'] += 1
                    q = queue.setdefault(ident, dict(cls=cls, enq=now, consumers=set()))
                    q['consumers'].add(rid)
                    return
                else:   # restart after exit: queue a new task, held until old exits
                    q = queue.setdefault(ident, dict(cls=cls, enq=now, consumers=set(), after=r.end))
                    q['consumers'].add(rid)
                    return
            if cls == 'req':
                r.cls = 'req'
            return
        q = queue.get(ident)
        if q is None:
            queue[ident] = dict(cls=cls, enq=now, consumers={rid} if rid is not None else set())
        else:
            if cls == 'req':
                q['cls'] = 'req'
            if rid is not None:
                q['consumers'].add(rid)

    def prio(ident):
        q = queue[ident]
        if adm == 'aging':
            bonus = (now - q['enq']) / aging
            return (-(1 if q['cls'] == 'req' else 0) - bonus, q['enq'])
        if adm in ('priority', 'barrier', 'per_completion'):
            if adm == 'per_completion':
                return (q['enq'],)
            return (0 if q['cls'] == 'req' else 1, q['enq'])
        return (q['enq'],)

    def dispatch():
        if now < stats['quiet_until']:
            return
        if adm == 'barrier' and running:
            return
        started = []
        while len(running) < C and queue:
            cands = [i for i in queue if queue[i].get('after', -1) <= now]
            if not cands:
                break
            ident = min(cands, key=prio)
            q = queue[ident]
            free = C - len(running)
            if q['cls'] == 'opt' and free <= reserve:
                optional_only = all(queue[i]['cls'] == 'opt' for i in cands)
                if optional_only:
                    break
                ident = min((i for i in cands if queue[i]['cls'] == 'req'), key=prio)
                q = queue[ident]
            del queue[ident]
            if q['cls'] == 'opt':
                stats['optional_wait'].append(now - q['enq'])
            r = Inst(ident, now, now + service(ident), q['cls'], cur(ident))
            running.append(r)
            stats['starts'] += 1
            stats['busy'] += r.end - r.start
            push(r.end, 'fin', r)
            started.append(r)

    def check_ready():
        for rid in list(pending):
            p = pending[rid]
            if all(is_known(x) for x in p['needs']):
                stats['latencies'].append(now - p['arrival'])
                stats['used'].update((x, cur(x)) for x in p['needs'])
                del pending[rid]

    def admit(r):
        if r.version != cur(r.ident):
            stats['wasted'] += r.end - r.start
            return
        if r.cancelled and not admit_cancelled:
            stats['wasted'] += r.end - r.start
            return
        known[r.ident] = r.version
        stats['produced'].append((r.ident, r.version, r.end))

    while ev:
        now, _s, kind, data = heapq.heappop(ev)
        if kind == 'req':
            rid, target = data
            prev = last_target[0]
            direction = 1 if prev is None or target >= prev else -1
            last_target[0] = target
            pending[rid] = dict(t=target, arrival=now, needs=needs(target))
            wanted = set(needs(target))
            preds = set()
            for j in range(1, k + 1):
                preds.update(needs(target + direction * j))
            if cancel in ('queued', 'all'):
                for ident in list(queue):
                    q = queue[ident]
                    if q['cls'] == 'opt' and ident not in wanted and ident not in preds:
                        del queue[ident]
                        stats['dropped_queued'] += 1
            if cancel == 'all':
                for r in running:
                    if r.cls == 'opt' and r.ident not in wanted and r.ident not in preds and not r.cancelled:
                        r.cancelled = True
                        r.cancel_at = now
            for ident in needs(target):
                enqueue(ident, 'req', rid)
            for ident in sorted(preds - wanted):
                if ident >= 0 and (gate is None or service(ident) <= gate):
                    enqueue(ident, 'opt', None)
            check_ready()
            dispatch()
        elif kind == 'fin':
            r = data
            running.remove(r)
            if r.cancelled and r.cancel_at is not None:
                stats['cancel_occupancy'] += r.end - r.cancel_at
            if adm == 'barrier':
                hold.setdefault('b', []).append(r)
                if not running:
                    for x in hold.pop('b'):
                        admit(x)
            else:
                admit(r)
            check_ready()
            dispatch()
        elif kind == 'upd':
            idents = data
            if churn == 'global':
                touched = set(version) | set(known) | {r.ident for r in running} | set(idents)
            else:
                touched = set(idents)
            for ident in touched:
                version[ident] = cur(ident) + 1
            for r in running:
                if r.ident in touched:
                    r.cancelled = True
                    r.cancel_at = now if r.cancel_at is None else r.cancel_at
            for p in pending.values():
                for x in p['needs']:
                    if x in touched:
                        enqueue(x, 'req', None)
            for ident in touched:
                if ident in queue:
                    queue[ident]['enq'] = now
            if debounce:
                stats['quiet_until'] = now + debounce
                push(now + debounce, 'wake', None)
            dispatch()
        elif kind == 'wake':
            dispatch()
        elif kind == 'bg':
            enqueue(data, 'opt', None)
            dispatch()
        # requeue anything pending that is neither known, queued nor running (after updates)
        for p in pending.values():
            for x in p['needs']:
                if not is_known(x) and x not in queue and not running_for(x):
                    enqueue(x, 'req', None)
        if queue and len(running) < C and kind != 'wake':
            dispatch()
        if queue and not running and not ev:
            # nothing left to wake us: wake at the earliest time a queued item may start
            nxt = max(min(q.get('after', now) for q in queue.values()), stats['quiet_until'])
            if nxt > now:
                push(nxt, 'wake', None)

    lat = stats['latencies']
    used = stats['used']
    useless = sum(service(i) for (i, v, _t) in stats['produced'] if (i, v) not in used)
    return dict(requests=len(work['requests']), completed=len(lat), unfinished=len(pending),
                p50=statistics.median(lat) if lat else None,
                p95=sorted(lat)[max(0, int(0.95 * len(lat)) - 1)] if lat else None,
                max=max(lat) if lat else None, mean=statistics.fmean(lat) if lat else None,
                starts=stats['starts'], busy_u=stats['busy'], wasted_u=stats['wasted'] + useless,
                discarded_u=stats['wasted'], unused_admitted_u=useless,
                cancel_occupancy_u=stats['cancel_occupancy'], duplicates=stats['duplicate'],
                dropped_queued=stats['dropped_queued'],
                optional_wait_max=max(stats['optional_wait']) if stats['optional_wait'] else None,
                produced_current=sum(1 for (i, v, _t) in stats['produced'] if v == version.get(i, 0)))


# ------------------------------------------------------------ workloads
def workload(kind, n_req=40, gap=1.5, C=2, seed=11, slow_frac=0.0, slow=10, base=1.0):
    if kind == 'forward':
        targets = list(range(n_req))
    elif kind == 'reversal':
        h = n_req // 2
        targets = list(range(h)) + list(range(h - 1, h - 1 - (n_req - h), -1))
        targets = [t + n_req for t in targets]
    elif kind == 'jump':
        import random
        rng = random.Random(seed)
        targets = [rng.randrange(0, 4 * n_req) for _ in range(n_req)]
    elif kind == 'zigzag':
        targets = [(i // 2) * 3 + (i % 2) * 6 for i in range(n_req)]
        targets = []
        t = 50
        for i in range(n_req):
            t += 3 if i % 2 == 0 else -2
            targets.append(t)
    else:
        raise ValueError(kind)
    reqs = [(i * gap, t) for i, t in enumerate(targets)]
    idents = set()
    for t in targets:
        for d in range(-4, 6):
            idents.add(t + d)
    service = {str(i): base * slow_factor(seed, i, slow_frac, slow) for i in idents}
    return dict(requests=reqs, service=service, capacity=C, base=base)


# ------------------------------------------------------------ D4 two-stage pipeline
def pipeline(acq, der, setup, policy, k=4, tau=None):
    """Acquire stage (1 resource, `setup` u per batch/start) then derive stage (1 resource).
    policy: 'per_item'  every acquisition pays setup; derive starts at each item's own completion
            'barrier'   fixed batches of k share one setup; derive of a batch starts only after
                        the whole batch was acquired (whole-batch barrier)
            'dynamic'   batches of <=k share one setup, but each item's derive starts at its
                        own acquisition completion (partial admission); with tau, a batch is
                        closed after the first item whose cumulative acquisition exceeds tau
    Returns first-result time, all-ready time, busy work and per-item ready times."""
    m = len(acq)
    acq_done = [0.0] * m
    t = 0.0
    work = 0.0
    batches = []
    if policy == 'per_item':
        for i in range(m):
            t += setup + acq[i]
            work += setup + acq[i]
            acq_done[i] = t
        avail = acq_done[:]
    else:
        i = 0
        while i < m:
            j = i
            t += setup
            work += setup
            elapsed = 0.0
            while j < m and j - i < k:
                t += acq[j]
                work += acq[j]
                elapsed += acq[j]
                acq_done[j] = t
                j += 1
                if policy == 'dynamic' and tau is not None and elapsed > tau:
                    break
            batches.append((i, j))
            i = j
        if policy == 'barrier':
            avail = [0.0] * m
            for (a, b) in batches:
                for x in range(a, b):
                    avail[x] = acq_done[b - 1]
        else:
            avail = acq_done[:]
    ready = [0.0] * m
    d_free = 0.0
    for i in sorted(range(m), key=lambda x: (avail[x], x)):
        start = max(avail[i], d_free)
        d_free = start + der[i]
        work += der[i]
        ready[i] = d_free
    return dict(first=min(ready), all=max(ready), mean=sum(ready) / m, work=work, ready=ready)


# ------------------------------------------------------------ failure keying (adversarial item 12)
def failure_assignment(idents_in_order, seed, keyed=True):
    """keyed: failure decided by (seed, physical identity, attempt) - independent of the
    policy's processing order.  keyed=False is the defect: one shared RNG stream consumed
    in policy order, so two policies see different failures for the same identity."""
    import random
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from trace_generator import failure_for
    out = {}
    rng = random.Random(seed)
    attempts = {}
    for ident in idents_in_order:
        a = attempts.get(ident, 0)
        attempts[ident] = a + 1
        out[(ident, a)] = failure_for(seed, [ident], a) if keyed else (rng.random() < 1 / 11)
    return out
