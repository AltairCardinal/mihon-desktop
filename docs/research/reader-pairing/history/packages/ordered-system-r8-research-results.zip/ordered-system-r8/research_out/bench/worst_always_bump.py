"""Worst case for NH-2 (unconditional bump): only no-op replaces, long-chain proofs
with large read sets, so every request after a bump needs a full read validation."""
import copy, json, statistics, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import *
import theory_a as A
from nh_hosts import AlwaysBump
from current_baseline import Host, Config

rows = []
for n in (16, 64, 256):
    c = A.decreasing_chain(n)
    for label, cls in (('current', Host), ('always_bump', AlwaysBump)):
        walls = []
        for rep in range(5):
            h = cls(c, config=Config.current()); h.request(n - 1)
            t0 = time.perf_counter_ns()
            for k in range(50):
                h.replace(c); h.request(n - 1)
            walls.append(time.perf_counter_ns() - t0)
        rows.append(dict(n=n, candidate=label, median_ms=round(statistics.median(walls) / 1e6, 2),
                         stamp_hits=h.metrics.get('stamp_hits', 0), read_validations=h.metrics.get('read_validations', 0),
                         typed_reads_checked=h.metrics.get('typed_reads_checked', 0)))
for r in rows: print(r)
Path(__file__).resolve().parents[1].joinpath('results', 'worst_always_bump.json').write_text(json.dumps(dict(
    rows=rows, layer='local_measured single process, 5 reps (median)',
    note='50 x (no-op replace + request of the last item of a decreasing chain)'), indent=1))
