"""A6 / G5 / X7 / X12: composing per-target certificates into a consistent publication.

Real units come from the frozen reference (reference.certify / complete_plan) on
small random cases from common.random_case (abstract extension domain).
Possible-world checks sample completions; they are evidence, not a proof - the
proof is Lemma A6-1 in proofs/protocol.md.
"""
import copy
import itertools
import random
import sys
import timeit
from collections import deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import ref, random_case, unit_of, fact, rank_value, roundtrip  # noqa: E402
import compact_core as core  # noqa: E402
from protocol2 import Proto, members  # noqa: E402
import proto_check as C  # noqa: E402


# --------------------------------------------------------------- guards (G5)
class ScanGuard:
    """Same-target stability + cross-target equal-or-disjoint by scanning all publications."""

    def __init__(self, require_member=False):
        self.pub = {}
        self.require_member = require_member

    def publish(self, target, unit):
        ms = members(unit)
        if self.require_member and target not in ms:
            return False
        if target in self.pub and self.pub[target] != ms:
            return False
        for m2 in self.pub.values():
            if set(m2) & set(ms) and m2 != ms:
                return False
        self.pub[target] = ms
        return True

    def revoke_all(self):
        self.pub.clear()


class OwnerTable:
    """Occupancy table item -> unit members; O(|unit|) per publication."""

    def __init__(self, require_member=False):
        self.pub, self.owner = {}, {}
        self.require_member = require_member

    def publish(self, target, unit):
        ms = members(unit)
        if self.require_member and target not in ms:
            return False
        if target in self.pub and self.pub[target] != ms:
            return False
        for m in ms:
            o = self.owner.get(m)
            if o is not None and o != ms:
                return False
        self.pub[target] = ms
        for m in ms:
            self.owner[m] = ms
        return True

    def revoke_all(self):
        self.pub.clear()
        self.owner.clear()


class StagedCommit(OwnerTable):
    """prepare/commit with the certificate incarnation; a new incarnation aborts prepared entries."""

    def __init__(self):
        super().__init__(require_member=True)
        self.inc = 0
        self.prepared = {}

    def prepare(self, target, unit, inc):
        if inc != self.inc:
            return False
        self.prepared[target] = (unit, inc)
        return True

    def commit(self, target):
        p = self.prepared.pop(target, None)
        if p is None or p[1] != self.inc:
            return False
        return self.publish(target, p[0])

    def new_incarnation(self):
        self.inc += 1
        self.prepared.clear()
        self.revoke_all()


# ------------------------------------------------------------ completions
def _valid(f, ident):
    return f is not None and core._geometry_t(f) and f[3] == ident[2] and f[4] == ident[3]


def complete_world(case, rng, beta=False, domain='ext'):
    """A random completion.  alpha: unknown analysis keeps a valid header's state;
    beta: the state is redrawn (header not authoritative)."""
    w = copy.deepcopy(case)
    ix = core.Index(case)
    states = []
    for p, item in enumerate(w['items']):
        a = ix.analysis(p)
        ident = ix.ident(p)
        if a[0] == 'computed' and _valid(a[1], ident):
            states.append(a[1][0])
            continue
        h = ix.header(p)
        st = h[0] if (_valid(h, ident) and not beta) else rng.choice(('NARROW', 'WIDE'))
        f = fact(st, rng.choice(('A', 'B', 'UNKNOWN')), rotation=ident[2], orientation=ident[3])
        if ident[2] in (90, 270):
            f['width'], f['height'] = f['height'], f['width']
        item['analysis'] = dict(status='computed', fact=f, version=1)
        states.append(st)
    recs = {(e['first'], e['second']): e for e in w.get('edges', [])}
    for a in range(len(states) - 1):
        e = recs.get((a, a + 1))
        if e is None or e.get('status') != 'computed':
            recs[(a, a + 1)] = dict(first=a, second=a + 1, status='computed',
                                    score=rank_value(rng, domain), version=1)
    w['edges'] = list(recs.values())
    return w


def local_start_unit(case, target):
    """Mutant certifier (adversarial list item 5): the window start max(0,t-2) is taken
    as the sequence start; returns the complete-plan unit of the suffix case."""
    first = max(0, target - 2)
    sub = copy.deepcopy(case)
    sub['items'] = sub['items'][first:]
    s = sub.get('settings', {})
    s['hard_isolates'] = [i - first for i in s.get('hard_isolates', []) if i >= first]
    s['pinned_links'] = [i - first for i in s.get('pinned_links', []) if i >= first]
    sub['edges'] = [dict(e, first=e['first'] - first, second=e['second'] - first)
                    for e in sub.get('edges', []) if e['first'] >= first]
    u = unit_of(ref.complete_plan(sub), target - first)
    return dict(u, slots=[dict(sl, item=sl['item'] + first) for sl in u['slots']])


def cert_map(case, mutant=False):
    out = {}
    for t in range(len(case['items'])):
        r = ref.certify(case, t)
        if r['status'] == 'certified':
            out[t] = local_start_unit(case, t) if mutant else r['unit']
    return out


def pairwise_ok(certs):
    for t, u in certs.items():
        if t not in members(u):
            return False
    us = list(certs.values())
    for a, b in itertools.combinations(us, 2):
        ma, mb = set(members(a)), set(members(b))
        if ma & mb and a != b:
            return False
    return True


def a6_composition(trials, seed=1):
    rng = random.Random(seed)
    st = dict(cases=0, certified_units=0, pairwise_violations=0, sampled_worlds=0, unsound_alpha=0,
              unsound_beta=0, beta_cases_with_unsound=0, mutant_pairwise_violations=0,
              mutant_order_dependent_cases=0, mutant_orders_with_conflict=0, mutant_orders_total=0,
              mutant_example=None)
    for _ in range(trials):
        n = rng.randrange(3, 8)
        c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.3, header_missing=0.1))
        certs = cert_map(c)
        st['cases'] += 1
        st['certified_units'] += len(certs)
        if not pairwise_ok(certs):
            st['pairwise_violations'] += 1
        bad_beta = False
        for _k in range(4):
            for beta in (False, True):
                w = complete_world(c, rng, beta)
                plan = ref.complete_plan(w)
                st['sampled_worlds'] += 1
                for t, u in certs.items():
                    if unit_of(plan, t) != u:
                        st['unsound_beta' if beta else 'unsound_alpha'] += 1
                        bad_beta |= beta
        st['beta_cases_with_unsound'] += bad_beta
        mcerts = cert_map(c, mutant=True)
        if not pairwise_ok(mcerts):
            st['mutant_pairwise_violations'] += 1
            ts = sorted(mcerts)[:6]
            finals = set()
            for order in itertools.permutations(ts):
                g = OwnerTable(require_member=True)
                conflict = False
                for t in order:
                    if not g.publish(t, mcerts[t]):
                        conflict = True
                finals.add(tuple(sorted(g.pub.items())))
                st['mutant_orders_total'] += 1
                st['mutant_orders_with_conflict'] += conflict
            if len(finals) > 1:
                st['mutant_order_dependent_cases'] += 1
                if st['mutant_example'] is None:
                    st['mutant_example'] = dict(case=c, certs={str(t): members(u) for t, u in mcerts.items()},
                                                distinct_final_publications=len(finals))
    return st


def a6_refinement(trials, seed=2):
    """Reveal unknown facts one by one toward an alpha completion inside one version;
    certify all targets at each step and publish through the guard."""
    rng = random.Random(seed)
    st = dict(sequences=0, steps=0, publications=0, conflicts=0, wrong_vs_final=0,
              nonmonotone_need_after_cert=0)
    for _ in range(trials):
        n = rng.randrange(3, 9)
        c = roundtrip(random_case(rng, n, p_unknown=0.4, p_edge_unknown=0.4, header_missing=0.1))
        w = complete_world(c, rng)
        final = ref.complete_plan(w)
        cur = copy.deepcopy(c)
        reveal = [('a', p) for p in range(n)] + [('e', a) for a in range(n - 1)]
        rng.shuffle(reveal)
        g = OwnerTable(require_member=True)
        ever = set()
        st['sequences'] += 1
        for kind, p in reveal:
            if kind == 'a':
                cur['items'][p]['analysis'] = copy.deepcopy(w['items'][p]['analysis'])
            else:
                rec = next((e for e in w['edges'] if e['first'] == p), None)
                cur['edges'] = [e for e in cur.get('edges', []) if e['first'] != p] + ([copy.deepcopy(rec)] if rec else [])
            st['steps'] += 1
            for t in range(n):
                r = ref.certify(cur, t)
                if r['status'] == 'certified':
                    ever.add(t)
                    if r['unit'] != unit_of(final, t):
                        st['wrong_vs_final'] += 1
                    if g.publish(t, r['unit']):
                        st['publications'] += 1
                    else:
                        st['conflicts'] += 1
                elif t in ever:
                    st['nonmonotone_need_after_cert'] += 1
    return st


# --------------------------------------------------------------- X7
def phase_shift_case(n=12):
    from common import base_case
    c = base_case(n, automatic=True)
    return c


def x7(trials, seed=3):
    rng = random.Random(seed)
    radii = (1, 2, 4, 8)
    st = dict(changes=0, units_before=0, kept_exact_diff=0, changed_units=0, max_change_distance=0,
              radius_wrong_keeps={str(r): 0 for r in radii}, radius_kept={str(r): 0 for r in radii},
              partial_kept=0, partial_kept_recertified_same=0, partial_kept_need_facts=0,
              partial_kept_blocked=0)
    for _ in range(trials):
        n = rng.randrange(10, 30)
        c = roundtrip(random_case(rng, n))
        old = ref.complete_plan(c)
        j = rng.randrange(n)
        c2 = copy.deepcopy(c)
        kind = rng.choice(('state', 'side', 'edge'))
        f = c2['items'][j]['analysis']['fact']
        if kind == 'state':
            st_new = 'WIDE' if f['state'] == 'NARROW' else 'NARROW'
            c2['items'][j]['analysis']['fact'] = fact(st_new, f['side'])
            c2['items'][j]['header'] = fact(st_new)
        elif kind == 'side':
            c2['items'][j]['analysis']['fact']['side'] = rng.choice([s for s in ('A', 'B', 'UNKNOWN') if s != f['side']])
        else:
            a = min(j, n - 2)
            c2['edges'] = [e for e in c2['edges'] if e['first'] != a] + [
                dict(first=a, second=a + 1, status='computed', score=rank_value(rng, 'ext'), version=1)]
        new = ref.complete_plan(c2)
        st['changes'] += 1
        olds = {members(u): u for u in old}
        news = {members(u): u for u in new}
        st['units_before'] += len(old)
        for ms, u in olds.items():
            same = news.get(ms) == u
            if same:
                st['kept_exact_diff'] += 1
            else:
                st['changed_units'] += 1
                st['max_change_distance'] = max(st['max_change_distance'], min(abs(m - j) for m in ms))
            for r in radii:
                near = any(abs(m - j) <= r for m in ms)
                if not near:
                    st['radius_kept'][str(r)] += 1
                    if not same:
                        st['radius_wrong_keeps'][str(r)] += 1
        # partial knowledge after the change: can kept units be re-entitled without new facts?
        part = copy.deepcopy(c2)
        for p in range(n):
            if rng.random() < 0.25:
                part['items'][p]['analysis'] = dict(status='unknown')
        for ms, u in olds.items():
            if news.get(ms) == u:
                t = ms[0]
                st['partial_kept'] += 1
                r = ref.certify(part, t)
                if r['status'] == 'certified' and r['unit'] == u:
                    st['partial_kept_recertified_same'] += 1
                elif r['status'] == 'need_facts':
                    st['partial_kept_need_facts'] += 1
                else:
                    st['partial_kept_blocked'] += 1
    return st


def x7_explicit(n=14):
    """Explicit long-range counterexample to radius-based revocation."""
    from common import base_case
    c = base_case(n, automatic=False)
    old = ref.complete_plan(c)
    c2 = copy.deepcopy(c)
    c2['items'][1]['analysis']['fact'] = fact('WIDE')
    c2['items'][1]['header'] = fact('WIDE')
    new = ref.complete_plan(c2)
    o = [members(u) for u in old]
    nw = [members(u) for u in new]
    changed = [m for m in o if m not in nw]
    return dict(old=o, new=nw, changed_units=changed, change_at=1,
                farthest_changed=max(min(abs(x - 1) for x in m) for m in changed))


# --------------------------------------------------------------- X12
def _bfs(proto_kw, prefix, alphabet, goal, depth, monitor_truth=True, cap=60000, viol=lambda s: True):
    model = Proto(**proto_kw)
    mon = C.Monitor(proto_kw.get('capacity', 2), check_truth=monitor_truth)
    for e in prefix:
        ce = C.concretize(e, model, mon)
        out = model.step(ce)
        bad = mon.observe(ce, out)
        assert bad is None, bad
    seen = {(model.canon(), mon.canon())}
    q = deque([((model, mon), [])])
    first_violation = None
    while q:
        (m, mo), tr = q.popleft()
        if len(tr) >= depth:
            continue
        for e in alphabet:
            ce = C.concretize(e, m, mo)
            if ce is None:
                continue
            m2, mo2 = copy.deepcopy(m), copy.deepcopy(mo)
            out = m2.step(ce)
            bad = mo2.observe(ce, out)
            if bad and viol(bad) and first_violation is None:
                first_violation = (bad, tr + [ce])
            if goal(ce, out) and not bad:
                return dict(goal_reached=True, steps=len(tr) + 1, violation=first_violation and first_violation[0])
            k = (m2.canon(), mo2.canon())
            if k in seen or bad:
                continue
            seen.add(k)
            if len(seen) > cap:
                break
            q.append(((m2, mo2), tr + [ce]))
    return dict(goal_reached=False, steps=None, violation=first_violation and first_violation[0])


def coarse_certifier(target, facts):
    if not all(k in facts for k in ('a', 'b')):
        return None
    return C.sound_certifier(target, facts)


def x12():
    prefix = [dict(op='request', key='a', consumer='c1', required=True),
              dict(op='request', key='b', consumer='c1', required=False)]
    base_alpha = [e for e in C.alphabet(relabel=False) if not (e['op'] in ('finish', 'exit') and e.get('key') == 'b')
                  and e['op'] != 'replace']
    guesses = [dict(op='publish', target=t, unit={'slots': list(ms)}) for t in range(3)
               for ms in {C.PLAN['X'][t], C.PLAN['Y'][t]}]
    groups = {
        'baseline_nocert_barrier': dict(kw=dict(capacity=2, require_cert=False, mutants=('barrier',),
                                                certifier=C.sound_certifier), guesses=True),
        'A_cert_barrier': dict(kw=dict(capacity=2, mutants=('barrier',), certifier=C.sound_certifier), guesses=False),
        'B_nocert_per_completion': dict(kw=dict(capacity=2, require_cert=False, certifier=C.sound_certifier),
                                        guesses=True),
        'AB_cert_per_completion': dict(kw=dict(capacity=2, certifier=C.sound_certifier), guesses=False),
        'AB_coarse_certificate': dict(kw=dict(capacity=2, certifier=coarse_certifier), guesses=False),
    }
    out = {}
    for name, g in groups.items():
        alpha = base_alpha + (guesses if g['guesses'] else [])
        # progress: publish target 0 (support {a}) while unrelated b never finishes
        prog = _bfs(g['kw'], prefix, alpha,
                    lambda ce, o: ce['op'] == 'publish' and ce['target'] == 0 and o['outcome'] == 'published',
                    depth=6, monitor_truth=False)
        # safety: is a publication that differs from the truth reachable?
        safety = _bfs(g['kw'], prefix, alpha, lambda ce, o: False, depth=4, monitor_truth=True, cap=40000,
                      viol=lambda s: s.startswith(('H1', 'H2', 'H10')))
        out[name] = dict(progress_publish_target0_without_b=prog['goal_reached'], progress_steps=prog['steps'],
                         wrong_publication_reachable=safety['violation'] is not None,
                         first_violation=safety['violation'])
    return out


# --------------------------------------------------------------- G5 differential + microbench
def g5_guards(trials, seed=4, quick=False):
    rng = random.Random(seed)
    mism = 0
    malformed_counterexample = None
    for _ in range(trials):
        gs = [ScanGuard(), OwnerTable()]
        seq = []
        for _k in range(rng.randrange(1, 10)):
            t = rng.randrange(6)
            a = rng.randrange(0, 7)
            ms = [a] if rng.random() < .5 else [a, a + 1]
            if rng.random() < .7 and t not in ms:
                ms = [t] if rng.random() < .5 else [t, t + 1]
            u = {'slots': ms}
            seq.append((t, ms))
            res = [g.publish(t, u) for g in gs]
            if res[0] != res[1]:
                mism += 1
    # N11 malformed same-target replacement: overlap-only check accepts, member+overlap rejects
    class OverlapOnly(ScanGuard):
        def publish(self, target, unit):
            ms = members(unit)
            for m2 in self.pub.values():
                if set(m2) & set(ms) and m2 != ms:
                    return False
            self.pub[target] = ms
            return True
    o = OverlapOnly()
    a1 = o.publish(2, {'slots': [2, 3]})
    a2 = o.publish(2, {'slots': [4, 5]})
    m = OwnerTable(require_member=True)
    b1 = m.publish(2, {'slots': [2, 3]})
    b2 = m.publish(2, {'slots': [4, 5]})
    # staged commit: version change between prepare and commit aborts
    sc = StagedCommit()
    p1 = sc.prepare(0, {'slots': [0, 1]}, 0)
    sc.new_incarnation()
    c1 = sc.commit(0)
    timings = []
    for npub in ((10, 100) if quick else (10, 100, 1000)):
        for cls in (ScanGuard, OwnerTable):
            g = cls()
            for i in range(npub):
                g.publish(3 * i, {'slots': [3 * i, 3 * i + 1]})
            u = {'slots': [3 * npub, 3 * npub + 1]}
            number = 2000

            def probe():
                gg_pub = g.pub
                g.pub = dict(gg_pub)
                if isinstance(g, OwnerTable):
                    own = g.owner
                    g.owner = dict(own)
                r = g.publish(3 * npub, u)
                g.pub = gg_pub
                if isinstance(g, OwnerTable):
                    g.owner = own
                return r
            # measure the check only (copying excluded via a separate baseline)
            def copy_only():
                d = dict(g.pub)
                if isinstance(g, OwnerTable):
                    d2 = dict(g.owner)
                return d
            tp = min(timeit.repeat(probe, number=number, repeat=5)) / number
            tc = min(timeit.repeat(copy_only, number=number, repeat=5)) / number
            timings.append(dict(published=npub, guard=cls.__name__, check_ns=round((tp - tc) * 1e9, 1)))
    return dict(differential_trials=trials, scan_vs_owner_mismatch=mism,
                n11_overlap_only=dict(first=a1, disjoint_same_target_replacement_accepted=a2),
                n11_member_plus_overlap=dict(first=b1, replacement_accepted=b2),
                staged_commit=dict(prepared=p1, commit_after_new_incarnation=c1),
                timings=timings, timing_note='local exploratory timeit, check cost = probe - copy baseline')


def experiments(quick=False):
    k = 1 if quick else 4
    return dict(a6_composition=a6_composition(60 * k), a6_refinement=a6_refinement(30 * k),
                x7=x7(100 * k), x7_explicit=x7_explicit(),
                x7_chain_sweep=[dict(n=n, changed=len(x7_explicit(n)['changed_units']),
                                     farthest=x7_explicit(n)['farthest_changed']) for n in (16, 32, 64, 128)], x12=x12(), g5=g5_guards(300 * k, quick=quick))
