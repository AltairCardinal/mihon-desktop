"""Host caching / invalidation family: differential, counterexample and mutant tests.

Run: cd <package root> && python3 -m unittest discover -s research_out/tests -t research_out -p 'test_hosts*.py'
"""
import copy
import json
import sys
import unittest
from dataclasses import replace as R
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))

import common  # noqa: E402,F401  (puts package root on sys.path)
import reference as Ref  # noqa: E402
from current_baseline import Host, Config  # noqa: E402
from hosts import XHost, XConfig, HostMutant as M, SAT, share_pair_answer  # noqa: E402
from host_traces import generate, PATTERNS, MIXES  # noqa: E402
from host_driver import replay, truth, make, CANDIDATE_CONFIGS  # noqa: E402

FIX = HERE.parent / 'fixtures' / 'host_traces'
B = XConfig()


def F(st='NARROW', side='UNKNOWN'):
    return dict(state=st, width=200 if st == 'WIDE' else 100, height=200, rotation=0, orientation=1, side=side)


def case(n=6, auto=False):
    return dict(items=[dict(id=f'i{i}', header=F(), analysis=dict(status='computed', fact=F(), version=1))
                       for i in range(n)], settings=dict(automatic=auto),
                edges=[dict(first=i, second=i + 1, status='computed', score=None, version=1) for i in range(n - 1)])


def strategy(c, t):
    return {k: v for k, v in Ref.certify_strategy(c, t)['selected'].items() if k != 'reads'}


def load(name):
    return json.loads((FIX / name).read_text(encoding='utf-8'))


class C5RetrySupport(unittest.TestCase):
    """A need_facts strategy verdict depends on the discarded retry's reads."""

    def test_frozen_host_is_stale_and_fix_is_not(self):
        fx = load('c5_retry_support_cex.json')
        c, c2, t = fx['case'], fx['changed'], fx['target']
        before = Ref.certify_strategy(c, t)
        self.assertEqual((before['baseline']['status'], before['retry']['status']), ('need_facts', 'need_facts'))
        self.assertTrue(Ref.reads_current(before['selected'], c2))       # selected support unchanged ...
        self.assertEqual(strategy(c2, t)['status'], 'certified')          # ... yet the strategy verdict changed
        for cfg in (Config.current(), Config.strict()):
            h = Host(c, config=cfg); h.request(t); h.replace(c2)
            self.assertNotEqual(h.request(t), strategy(c2, t))           # frozen virtual host: stale
        h = Host(c, config=Config.cold()); h.request(t); h.replace(c2)
        self.assertEqual(h.request(t), strategy(c2, t))
        for support in ('attempts', 'union'):
            for inv in ('stamp', 'posrev', 'log', 'revdep', 'bitmap', 'exact'):
                h = XHost(c, config=R(B, support=support, invalidation=inv)); h.request(t); h.replace(c2)
                self.assertEqual(h.request(t), strategy(c2, t), (support, inv))

    def test_adopted_variant(self):
        fx = load('c5_adopted_variant_cex.json')
        c, c2, t = fx['case'], fx['changed'], fx['target']
        self.assertTrue(Ref.certify_strategy(c, t)['adopted'])
        self.assertTrue(Ref.reads_current(Ref.certify_strategy(c, t)['selected'], c2))
        self.assertFalse(Ref.certify_strategy(c2, t)['adopted'])
        h = Host(c, config=Config.current()); h.request(t); h.replace(c2)
        self.assertNotEqual(h.request(t), strategy(c2, t))
        for support in ('attempts', 'union'):
            x = XHost(c, config=R(B, support=support)); x.request(t); x.replace(c2)
            self.assertEqual(x.request(t), strategy(c2, t))

    def test_selected_support_mutant_reproduces_bug(self):
        tr = load('mutant_selected_support.json')
        got, _ = replay(tr, lambda c: XHost(c, config=B, mutant=M.SELECTED_SUPPORT))
        self.assertNotEqual(got, truth(tr))

    def test_second_trace_frozen_host_wrong(self):
        tr = load('mutant_revdep_no_reregister.json')
        got, _ = replay(tr, lambda c: Host(c, config=Config.current()))
        self.assertNotEqual(got, truth(tr))
        got, _ = replay(tr, lambda c: XHost(c, config=B))
        self.assertEqual(got, truth(tr))


class Differential(unittest.TestCase):
    def test_all_candidates_match_strategy_on_generated_traces(self):
        names = list(CANDIDATE_CONFIGS)
        for seed in (0, 1):
            for pat in PATTERNS:
                for mix in MIXES:
                    tr = generate(seed, 9, 14, pat, mix, idle_budget=2 if seed else 0)
                    want = truth(tr)
                    for name in names:
                        f, d = make(name)
                        got, _ = replay(tr, f, d)
                        self.assertEqual(got, want, (seed, pat, mix, name))

    def test_batch_trace(self):
        tr = generate(3, 12, 10, 'neighbor', 'relevant', batch=3)
        want = truth(tr)
        for name in ('x_fix_stamp', 'x_snapshot', 'x_revdep'):
            f, d = make(name)
            self.assertEqual(replay(tr, f, d)[0], want)


class Mutants(unittest.TestCase):
    """Each named mutant must produce a wrong public verdict on a frozen trace."""
    TABLE = [
        ('mutant_barrier_skips_header_constructed.json', R(B, invalidation='posrev'), M.BARRIER_SKIPS_HEADER, False),
        ('mutant_barrier_skips_header_constructed.json', R(B, invalidation='revdep'), M.BARRIER_SKIPS_HEADER, False),
        ('mutant_barrier_skips_header.json', R(B, invalidation='posrev'), M.BARRIER_SKIPS_HEADER, False),
        ('mutant_barrier_skips_edge_constructed.json', R(B, invalidation='posrev'), M.BARRIER_SKIPS_EDGE, False),
        ('mutant_barrier_skips_edge.json', R(B, invalidation='posrev'), M.BARRIER_SKIPS_EDGE, False),
        ('mutant_revdep_no_reregister.json', R(B, invalidation='revdep'), M.REVDEP_NO_REREGISTER, False),
        ('mutant_unknown_eq_null.json', R(B, invalidation='exact'), M.UNKNOWN_EQ_NULL, False),
        ('mutant_unknown_eq_null.json', R(B, invalidation='stamp'), M.UNKNOWN_EQ_NULL, False),
        ('mutant_drop_pruned_reads.json', R(B, invalidation='exact'), M.DROP_PRUNED_READS, False),
        ('mutant_hash_only.json', R(B, proof='interned', invalidation='exact'), M.HASH_ONLY, False),
    ]

    def test_mutants_killed_and_clean_passes(self):
        for name, cfg, mut, delta in self.TABLE:
            with self.subTest(name=name, mutant=mut):
                tr = load(name)
                want = truth(tr)
                self.assertEqual(replay(tr, lambda c: XHost(c, config=cfg), delta)[0], want)
                self.assertNotEqual(replay(tr, lambda c: XHost(c, config=cfg, mutant=mut), delta)[0], want)

    def test_delta_api_header_barrier(self):
        c = case(6, False); c['items'][2]['analysis'] = {'status': 'unknown'}
        for mut, expect_ok in ((None, True), (M.BARRIER_SKIPS_HEADER, False)):
            h = XHost(c, config=R(B, invalidation='posrev'), mutant=mut)
            h.request(2)
            h.set_header(2, F('WIDE'))
            c2 = copy.deepcopy(c); c2['items'][2]['header'] = F('WIDE')
            self.assertEqual(h.request(2) == strategy(c2, 2), expect_ok)

    def test_budget_checked_before_attempt(self):
        c = case(7, True); c['settings']['opening'] = 'SINGLE'
        c['edges'][1]['score'] = 15; c['edges'][2]['score'] = 6
        c['edges'][3] = dict(first=3, second=4, status='unknown'); c['edges'][4]['score'] = 15
        h = XHost(c, config=B)
        used = h.prepare([3], 1)
        self.assertLessEqual(used, 1)
        self.assertLessEqual(h.metrics['engine_runs'], 1)
        hm = XHost(c, config=B, mutant=M.BUDGET_AFTER)
        self.assertGreater(hm.prepare([3], 1), 1)                        # mutant exceeds the budget

    def test_budget_abort_cache_harmless_only_with_attempt_support(self):
        c = case(7, True); c['settings']['opening'] = 'SINGLE'
        c['edges'][1]['score'] = 15; c['edges'][2]['score'] = 6
        c['edges'][3] = dict(first=3, second=4, status='unknown'); c['edges'][4]['score'] = 15
        want = strategy(c, 3)
        self.assertEqual(want['status'], 'certified')
        for support, ok in (('attempts', True), ('selected', False)):
            h = XHost(c, config=R(B, support=support), mutant=M.BUDGET_ABORT_CACHED)
            h.prepare([3], 1)
            self.assertEqual(h.request(3) == want, ok, support)
            h = XHost(c, config=R(B, support=support))
            h.prepare([3], 1)
            self.assertEqual(h.request(3), want)


class Bounds(unittest.TestCase):
    def test_posrev_saturation_falls_back_to_exact(self):
        c = case(6, True)
        h = XHost(c, config=R(B, invalidation='posrev'))
        h.request(2)
        h._item_rev = [SAT] * len(h._item_rev)
        h.request(2); h.request(2)
        self.assertEqual(h.metrics['read_validations'], 2)
        self.assertEqual(h.metrics.get('posrev_hits', 0), 0)

    def test_log_truncation_falls_back(self):
        c = case(8, True)
        h = XHost(c, config=R(B, invalidation='log', log_cap=2))
        h.request(2)
        for w in range(5):
            c2 = copy.deepcopy(c); c2['items'][7]['header']['width'] = 101 + w
            h.replace(c2)
        self.assertEqual(h.request(2), strategy(c, 2))
        self.assertGreaterEqual(h.metrics['log_truncated_fallbacks'], 1)
        self.assertLessEqual(len(h._log), 2)

    def _churn(self, cfg, mutant=None, rounds=300, drop_rebind=False):
        tr = generate(5, 32, rounds, 'jump', 'churn')
        if drop_rebind:
            tr['events'] = [e for e in tr['events'] if e['op'] not in ('rebind', 'close_rebind', 'identity')]
        sizes = []
        f = lambda c: XHost(c, config=cfg, mutant=mutant)
        # replay manually to sample sizes
        from host_traces import apply_event
        c = copy.deepcopy(tr['initial']); h = f(c)
        for k, ev in enumerate(tr['events']):
            op = ev['op']
            if op == 'request':
                h.request(ev['target'])
            elif op in ('analysis', 'header', 'edge', 'identity'):
                c = apply_event(c, ev); h.replace(c)
            elif op in ('rebind', 'close_rebind'):
                h.rebind(c)
            if k % 50 == 0:
                sizes.append(h.structural_size())
        return sizes

    def test_bounded_structures_under_churn(self):
        cap = B.capacity
        for cfg in (R(B, invalidation='revdep'), R(B, invalidation='log'), R(B, proof='interned')):
            for s in self._churn(cfg):
                self.assertLessEqual(s['entries'], cap)
                self.assertLessEqual(s['revdep_edges'], s['read_keys'] * 2 + 1)
                self.assertLessEqual(s['log_len'], 64)
                self.assertLessEqual(s['intern_values'], 2 * max(16, s['read_keys']) + s['read_keys'] + 64)

    def test_unbounded_variants_grow(self):
        log = [s['log_len'] for s in self._churn(R(B, invalidation='log', log_cap=None), drop_rebind=True)]
        self.assertGreater(log[-1], 200)
        capped = [s['log_len'] for s in self._churn(R(B, invalidation='log'), drop_rebind=True)]
        self.assertLessEqual(max(capped), 64)
        intern = [s['intern_values'] for s in self._churn(R(B, proof='interned'), M.INTERN_NO_PRUNE, drop_rebind=True)]
        bounded = [s['intern_values'] for s in self._churn(R(B, proof='interned'), drop_rebind=True)]
        self.assertGreater(intern[-1], 3 * max(bounded))
        stale = self._churn(R(B, invalidation='revdep'), M.REVDEP_NO_DEREGISTER, drop_rebind=True)
        self.assertTrue(any(s['revdep_edges'] > s['read_keys'] * 2 + 1 for s in stale))

    def test_byte_budget_respected(self):
        cfg = R(B, cache='bytes', byte_budget=200)
        tr = generate(2, 16, 40, 'jump', 'quiet')
        got, h = replay(tr, lambda c: XHost(c, config=cfg))
        self.assertEqual(got, truth(tr))


class Ownership(unittest.TestCase):
    def test_caller_mutation_does_not_reach_host(self):
        c = case(6, True)
        h = XHost(c, config=R(B, invalidation='revdep', view='snapshot'))
        want = h.request(2)
        c['items'][2]['analysis'] = {'status': 'unknown'}
        snap = h.snapshot(); snap['items'][2]['analysis'] = {'status': 'unknown'}
        self.assertEqual(h.request(2), want)

    def test_global_guards(self):
        c = case(6, True)
        for inv in ('posrev', 'revdep', 'bitmap', 'log'):
            h = XHost(c, config=R(B, invalidation=inv)); h.request(2)
            c2 = copy.deepcopy(c); c2['settings']['direction'] = 'BA'; h.replace(c2)
            self.assertEqual(h.request(2), strategy(c2, 2))
            c3 = copy.deepcopy(c2); c3['items'][5]['content_version'] = 1; h.replace(c3)
            runs = h.metrics['engine_runs']; h.request(2)
            self.assertGreater(h.metrics['engine_runs'], runs)          # identity change: recompute
            h.locate('i3', 1); runs = h.metrics['engine_runs']; h.request(2)
            self.assertGreater(h.metrics['engine_runs'], runs)
            h.close()
            with self.assertRaises(ValueError):
                h.request(2)


class PairSharing(unittest.TestCase):
    def test_b5_pair_sharing_is_not_L0(self):
        """Answering t+1 from t's certified pair unit gives the right unit but
        different public fields: it can only be an L1 route."""
        diffs = 0
        same_unit = 0
        for n in (6, 8):
            c = case(n, False)
            for t in range(n - 1):
                r = strategy(c, t)
                if r['status'] != 'certified' or len(r['unit']['slots']) != 2:
                    continue
                partner = r['unit']['slots'][1]['item'] if r['unit']['slots'][0]['item'] == t else r['unit']['slots'][0]['item']
                shared = share_pair_answer(None, partner, r)
                want = strategy(c, partner)
                same_unit += shared['unit'] == want['unit']
                diffs += shared != want
        self.assertGreater(same_unit, 0)
        self.assertGreater(diffs, 0)


if __name__ == '__main__':
    unittest.main()
