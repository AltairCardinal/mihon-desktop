"""Exogenous trace generator v2 for the host family (frozen before any profile runs).

Failures are keyed by stable (seed, identity, attempt) exactly like
trace_generator.failure_for, so no candidate can change which attempt fails.
Requests never depend on candidate behaviour; idle-time prediction (B6) is
computed by the driver from PAST request events only.
"""
from copy import deepcopy
import json
import random
from pathlib import Path

from trace_generator import failure_for

PATTERNS = ('repeat', 'neighbor', 'roundtrip', 'jump', 'ws5', 'ws3')
MIXES = ('quiet', 'irrelevant', 'relevant', 'churn', 'fail', 'growth')


def _fact(state='NARROW', side='UNKNOWN'):
    return dict(state=state, width=200 if state == 'WIDE' else 100, height=200, rotation=0, orientation=1, side=side)


def initial_case(rng, n, unknown=0.2, edge_unknown=0.2):
    items, edges = [], []
    for i in range(n):
        st = 'WIDE' if rng.random() < 0.1 else 'NARROW'
        side = rng.choice(('A', 'B', 'UNKNOWN', 'UNKNOWN'))
        an = dict(status='unknown') if rng.random() < unknown else dict(status='computed', fact=_fact(st, side), version=1)
        items.append(dict(id=f'i{i}', header=_fact(st), analysis=an))
    for a in range(n - 1):
        if rng.random() < edge_unknown:
            continue
        edges.append(dict(first=a, second=a + 1, status='computed',
                          score=None if rng.random() < 0.15 else rng.randrange(0, 1500) / 50, version=1))
    return dict(generation=0, order_revision=0, items=items,
                settings=dict(automatic=True, direction=rng.choice(('AB', 'BA'))), edges=edges)


def _targets(rng, n, pattern, rounds):
    out, t = [], rng.randrange(n)
    ws5 = [(j * max(1, n // 5)) % n for j in range(5)]
    ws3 = ws5[:3]
    d = 1
    for k in range(rounds):
        if pattern == 'repeat':
            pass
        elif pattern == 'neighbor':
            t = min(n - 1, max(0, t + rng.choice((-1, 1))))
        elif pattern == 'roundtrip':
            if t + d < 0 or t + d >= n:
                d = -d
            t = t + d
        elif pattern == 'jump':
            t = rng.randrange(n)
        elif pattern == 'ws5':
            t = ws5[k % 5]
        elif pattern == 'ws3':
            t = ws3[k % 3]
        out.append(t)
    return out


def generate(seed, n, rounds, pattern, mix, requests_per_round=2, idle_budget=0, batch=0):
    rng = random.Random(f'{seed}/{n}/{pattern}/{mix}')
    case = initial_case(rng, n)
    targets = _targets(rng, n, pattern, rounds)
    events = []
    attempt = {}
    rate = dict(quiet=0.05, irrelevant=0.6, relevant=0.6, churn=1.0, fail=0.5, growth=0.5)[mix]
    for k, t in enumerate(targets):
        if batch:
            events.append(dict(op='batch', targets=sorted({min(n - 1, max(0, t + d)) for d in range(batch)})))
        else:
            for _ in range(requests_per_round):
                events.append(dict(op='request', target=t))
        if idle_budget:
            events.append(dict(op='idle', budget=idle_budget))
        changes = 0
        while rng.random() < rate and changes < 3:
            changes += 1
            if mix == 'irrelevant':
                far = (t + n // 2 + rng.randrange(-2, 3)) % n
                events.append(dict(op='header', item=far, width=101 + rng.randrange(50)))
            elif mix in ('relevant', 'churn', 'growth', 'quiet'):
                p = min(n - 1, max(0, t + rng.randrange(-4, 3))) if mix != 'quiet' else rng.randrange(n)
                kind = rng.random()
                if kind < 0.5:
                    st = 'WIDE' if rng.random() < 0.1 else 'NARROW'
                    if mix == 'growth' or rng.random() < 0.8:
                        val = dict(status='computed', fact=_fact(st, rng.choice(('A', 'B', 'UNKNOWN'))), version=2 + k)
                    else:
                        val = dict(status='unknown')
                    events.append(dict(op='analysis', item=p, value=val))
                elif kind < 0.9 and p < n - 1:
                    rec = None if (mix != 'growth' and rng.random() < 0.2) else dict(
                        status='computed', score=None if rng.random() < 0.15 else rng.randrange(0, 1500) / 50, version=2 + k)
                    events.append(dict(op='edge', first=p, second=p + 1, record=rec))
                else:
                    events.append(dict(op='header', item=p, width=101 + rng.randrange(50)))
            elif mix == 'fail':
                p = min(n - 1, max(0, t + rng.randrange(-3, 3)))
                attempt[p] = attempt.get(p, 0) + 1
                failed = failure_for(seed, [f'i{p}', 0, 0, 1], attempt[p]) or rng.random() < 0.3
                val = dict(status='failed', reason='RESOURCE') if failed else dict(
                    status='computed', fact=_fact('NARROW', rng.choice(('A', 'B', 'UNKNOWN'))), version=2 + k)
                events.append(dict(op='analysis', item=p, value=val))
        if mix == 'churn' and k % 9 == 4:
            events.append(dict(op='identity', item=rng.randrange(n)))
        if k % 23 == 11:
            events.append(dict(op='rebind'))
        if k % 41 == 29:
            events.append(dict(op='close_rebind'))
    events.append(dict(op='close'))
    return dict(schema='host-trace-v2', seed=seed, n=n, pattern=pattern, mix=mix, rounds=rounds,
                idle_budget=idle_budget, batch=batch, initial=case, events=events,
                service_profile=dict(kind='synthetic_parameter_only', per_task_ns=None))


def apply_event(case, ev, inplace=False):
    """Update of a full snapshot (pure by default; drivers use inplace=True on their
    own copy because every host deep-copies on replace)."""
    c = case if inplace else deepcopy(case)
    op = ev['op']
    if op == 'analysis':
        c['items'][ev['item']]['analysis'] = deepcopy(ev['value'])
    elif op == 'header':
        c['items'][ev['item']]['header']['width'] = ev['width']
    elif op == 'edge':
        c['edges'] = [e for e in c['edges'] if (e['first'], e['second']) != (ev['first'], ev['second'])]
        if ev['record'] is not None:
            r = dict(ev['record'], first=ev['first'], second=ev['second'])
            c['edges'].append(r)
    elif op == 'snapshot':
        c = deepcopy(ev['case'])
    elif op == 'identity':
        it = c['items'][ev['item']]
        it['content_version'] = it.get('content_version', 0) + 1
    else:
        raise ValueError(op)
    return c


def predict(history, n, k=2):
    """B6 predictor: neighbours of the last requested target (past events only)."""
    if not history:
        return []
    t = history[-1]
    out = []
    for d in (1, -1, 2, -2)[:k * 2]:
        if 0 <= t + d < n:
            out.append(t + d)
    return out


def freeze(trace, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(trace, allow_nan=False, separators=(',', ':')), encoding='utf-8')


def rare_expensive(n=128, rounds=60, seed=17):
    """C6 workload: a long decreasing-rank chain makes far targets expensive
    (certification must reach position 0); five cheap targets cycle (> capacity 4)
    and one expensive target recurs every 6th request.  Rare header-only updates."""
    rng = random.Random(seed)
    items = [dict(id=f'i{i}', header=_fact(), analysis=dict(status='computed', fact=_fact(), version=1)) for i in range(n)]
    edges = [dict(first=i, second=i + 1, status='computed', score=(n - i) / 10, version=1) for i in range(n - 1)]
    case = dict(generation=0, order_revision=0, items=items, settings=dict(automatic=True, direction='AB'), edges=edges)
    cheap = [5, 6, 7, 8, 9]
    events = []
    k = 0
    for r in range(rounds):
        t = (n - 8) if r % 6 == 5 else cheap[k % 5]
        if r % 6 != 5:
            k += 1
        events.append(dict(op='request', target=t))
        if rng.random() < 0.05:
            events.append(dict(op='header', item=rng.randrange(n), width=101 + rng.randrange(50)))
    events.append(dict(op='close'))
    return dict(schema='host-trace-v2', seed=seed, n=n, pattern='rare_expensive', mix='quiet', rounds=rounds,
                idle_budget=0, batch=0, initial=case, events=events,
                service_profile=dict(kind='synthetic_parameter_only', per_task_ns=None))
