"""Markdown tables for REPORT.md, generated only from results/formal/*.json(l)."""
import json
import statistics
from pathlib import Path

R = Path(__file__).resolve().parents[1] / 'results' / 'formal'


def fmt_ratio(r):
    if not r:
        return '—'
    return f"{r['median']:.3f} [{r['min']:.3f}, {r['max']:.3f}]"


def family_table(rows, cands, base_key, title):
    scen = []
    for r in rows:
        if r['scenario'] not in scen:
            scen.append(r['scenario'])
    out = [f'### {title}', '', '| 场景 | ' + ' | '.join(cands) + ' |', '|' + '---|' * (len(cands) + 1)]
    for s in scen:
        cells = []
        for c in cands:
            r = next((x for x in rows if x['scenario'] == s and x['candidate'] == c), None)
            if r is None:
                cells.append('—')
                continue
            ratio = r.get(base_key)
            extra = f" ({r['certified']})" if 'certified' in r else ''
            cells.append((f"{r['wall_ms_median']:.1f} ms" if ratio is None else fmt_ratio(ratio)) + extra)
        out.append(f'| {s} | ' + ' | '.join(cells) + ' |')
    return out


def main():
    S = json.loads((R / 'formal_summary.json').read_text())
    parts = ['# 正式计时表（由 bench/report_tables.py 从 results/formal 生成）', '',
             '格式：基线列为三进程中位数的中位（ms）；其他列为"逐进程配对比值的中位 [最小, 最大]"；括号内为已认证判决数。', '']
    if 'rel' in S:
        parts += family_table(S['rel'], ['x_fix_stamp', 'current', 'always_bump', 'rel_tree', 'rel_exact', 'rel_portfolio',
                                         'x_delta_posrev', 'rel_tree_dposrev'], 'ratio_vs_x_fix_stamp',
                              'L1 关系认证 / X1 / NH-2（虚拟宿主，宿主族冻结轨迹）')
        parts += ['', 'always_bump 的比值是相对 current（冻结宿主）：', '']
        parts += family_table(S['rel'], ['current', 'always_bump'], 'ratio_vs_current', 'NH-2 无条件推进 vs 冻结宿主')
    if 'incremental' in S:
        parts += [''] + family_table(S['incremental'], ['linear', 'recompute', 'tree', 'resync'], 'ratio_vs_linear',
                                     'B1–B3 计划维护（比值相对线性转换器扫描）')
    if 'protocol' in S:
        rows = S['protocol']
        g = [r for r in rows if r['scenario'].startswith('guard')]
        i = [r for r in rows if r['scenario'].startswith('identity')]
        parts += [''] + family_table(g, ['scan_guard', 'owner_table'], 'ratio_vs_scan_guard', 'G5 发布权限检查')
        parts += [''] + family_table(i, ['typed_full', 'typed_tuple_intern'], 'ratio_vs_typed_full', 'C3 身份比较')
    hs = R / 'hosts_summary.json'
    if hs.exists():
        parts += ['', '### 宿主族（见 hosts_summary.json；由 summarize_hosts.py 生成）', '']
        parts.append('```')
        parts.append(hs.read_text()[:6000])
        parts.append('```')
    (R / 'TABLES.md').write_text('\n'.join(parts) + '\n', encoding='utf-8')
    print('\n'.join(parts)[:4000])


if __name__ == '__main__':
    main()
