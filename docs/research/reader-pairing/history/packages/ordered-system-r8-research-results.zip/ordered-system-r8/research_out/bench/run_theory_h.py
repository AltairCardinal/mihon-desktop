"""H1/H2/H3/H4/H5 studies -> results/theory_h.json."""
import copy, json, random, sys, time, statistics
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import *
import theory_h as H, theory_a as A, incremental as I
from current_baseline import Host, Config

out = {}; t0 = time.time()
# H4 -------------------------------------------------------------
out['H4_projection_power'] = H.projection_power(1200)
# H5 -------------------------------------------------------------
rng = random.Random(41); diff_pos = tot_pos = 0; pairs_ref = pairs_lmp = 0; maximal_viol = 0
for k in range(1500):
    n = rng.randrange(2, 30)
    c = roundtrip(random_case(rng, n, p_wide=0.12, domain='G0'))
    p, q = ref.complete_plan(c), H.lmp_plan(c)
    mp, mq = H.plan_members(p), H.plan_members(q)
    assert sorted(mq) == list(range(n))
    tot_pos += n; diff_pos += sum(mp[i] != mq[i] for i in range(n))
    pairs_ref += sum(len(u['slots']) == 2 for u in p); pairs_lmp += sum(len(u['slots']) == 2 for u in q)
chain = A.decreasing_chain(64)
cp, cq = ref.complete_plan(chain), H.lmp_plan(chain)
# locality: flip one fact and record the farthest changed unit position
def far_change(planner, c, rng, trials=200):
    worst = []
    for _ in range(trials):
        n = len(c['items']); d = copy.deepcopy(c)
        a = rng.randrange(n - 1)
        for e in d['edges']:
            if e['first'] == a: e['score'] = rng.randrange(0, 1500) / 50
        m0, m1 = H.plan_members(planner(c)), H.plan_members(planner(d))
        ch = [i for i in range(n) if m0[i] != m1[i]]
        worst.append(max((abs(i - a) for i in ch), default=0))
    return max(worst), statistics.mean(worst)
loc = {}
for name, planner in (('reference', ref.complete_plan), ('lmp', H.lmp_plan)):
    rr = random.Random(5)
    loc[name] = dict(chain=far_change(planner, A.decreasing_chain(96), rr, 150),
                     random=far_change(planner, roundtrip(random_case(random.Random(6), 96, domain='G0', settings_mix=False)), rr, 150))
out['H5_lmp_rule'] = dict(cases=1500, positions=tot_pos, positions_with_different_unit=diff_pos,
    pair_units_reference=pairs_ref, pair_units_lmp=pairs_lmp,
    chain64_pairs=dict(reference=sum(len(u['slots']) == 2 for u in cp), lmp=sum(len(u['slots']) == 2 for u in cq)),
    farthest_change_after_one_rank_edit=loc,
    status='L2 pending adjudication: different outputs; no external quality truth')
# H3 -------------------------------------------------------------
seqs = {'cyclic5': [j % 5 for j in range(200)], 'cyclic4': [j % 4 for j in range(200)]}
r = random.Random(3); loc_seq = []; t = 0
for _ in range(400):
    t = max(0, min(63, t + r.choice((-1, 0, 1)))); loc_seq.append(t)
seqs['neighbor_walk'] = loc_seq
drift = [r.randrange(8) for _ in range(200)] + [8 + r.randrange(8) for _ in range(200)]
seqs['drift'] = drift
seqs['adversary_k4'] = []
for j in range(50): seqs['adversary_k4'] += [0, 1, 2, 3, 4 + (j % 2)]
out['H3_cache'] = {name: {pol: H.cache_misses(s, 4, pol) for pol in ('fifo', 'lru', 'opt')} | {'len': len(s)} for name, s in seqs.items()}
# H2 -------------------------------------------------------------
import bench_incremental as BI
sc = dict(name='chainfront_n128_q1', kind='chainfront', n=128, updates=40, q=1, seed=5)
tr = BI.trace_for(sc)
def work_ratio(events):
    t = dict(case=tr['case'], events=events)
    rs = BI.run_one(sc, 'resync', 0, t)['work']; tw = BI.run_one(sc, 'tree', 0, t)['work']
    resync = rs.get('resync_steps', 0) - 128            # exclude the common initial scan
    tree = tw.get('leaf_evals', 0) * 5 - 128 * 5 + tw.get('queries', 0) * 2
    return (resync + 1) / (tree + 1)
start_ratio = work_ratio(tr['events'])
red = H.ddmin(tr['events'], work_ratio, 3.0)
out['H2_reducer'] = dict(scenario=sc, start_events=len(tr['events']), start_work_ratio=round(start_ratio, 2),
                         reduced_events=red, reduced_work_ratio=round(work_ratio(red), 2),
                         note='cost = deterministic step-evaluation counts (resync vs tree) beyond the shared initial build')
# H1 (N16): revision-counter maintenance vs whole-case comparison inside Host.replace
class NoRevision(Host):
    def replace(self, case):
        if self._closed:
            raise ValueError('closed host requires rebind')
        import reference as R2
        from current_baseline import typed
        next_case = copy.deepcopy(case); data = R2._Input(next_case)
        identity, settings = typed(data.identity), typed(data.settings)
        if getattr(self, '_identity', None) != identity:
            self._structure = None
        self._case, self._identity, self._settings = next_case, identity, settings
c = roundtrip(random_case(random.Random(9), 256, domain='G0', settings_mix=False))
def time_replace(cls, reps=30):
    h = cls(c, config=Config.strict()); ts = []
    for k in range(reps):
        d = copy.deepcopy(c); d['items'][k % 256]['analysis']['version'] = k + 5
        t1 = time.perf_counter_ns(); h.replace(d); ts.append(time.perf_counter_ns() - t1)
    return statistics.median(ts)
from current_baseline import typed
d = copy.deepcopy(c)
t1 = time.perf_counter_ns(); typed(d) != typed(c); t_cmp = time.perf_counter_ns() - t1
t1 = time.perf_counter_ns(); copy.deepcopy(c); t_copy = time.perf_counter_ns() - t1
t1 = time.perf_counter_ns()
for _ in range(1000): x = min(5 + 1, (1 << 63) - 1)
t_inc = (time.perf_counter_ns() - t1) / 1000
out['H1_factor_ledger_n256'] = dict(replace_with_revision_ns=time_replace(Host), replace_without_revision_ns=time_replace(NoRevision),
    typed_whole_case_compare_ns=t_cmp, deepcopy_ns=t_copy, counter_increment_ns=round(t_inc, 1),
    note='single process, local_measured; the frozen replace pays deepcopy + typed whole-case compare; '
         'the counter itself is ~1e-4 of replace; the compare that DECIDES whether to bump it is the real maintenance cost')
out['seconds'] = round(time.time() - t0, 1)
Path(__file__).resolve().parents[1].joinpath('results', 'theory_h.json').write_text(json.dumps(out, indent=1, default=str))
print(json.dumps({k: v for k, v in out.items() if k != 'H2_reducer'}, indent=1, default=str)[:5000])
print('H2', out['H2_reducer']['start_events'], out['H2_reducer']['start_work_ratio'], len(out['H2_reducer']['reduced_events']), out['H2_reducer']['reduced_work_ratio'])
