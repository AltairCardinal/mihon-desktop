"""Aggregate formal 3-process JSONL records (rel / incremental / protocol).

Per (scenario, candidate, process): median wall over non-warmup reps.
Ratio vs the family baseline is computed per process (paired by process and
scenario), then reported as median and [min, max] over the 3 processes.
Every number here is recomputable from the raw JSONL; nothing is dropped
(rows with ok == False are counted and reported).
"""
import collections
import json
import statistics
import sys
from pathlib import Path

BASE = {'rel': 'x_fix_stamp', 'incremental': 'linear', 'protocol': None}


def load(path):
    return [json.loads(l) for l in Path(path).read_text().splitlines() if l.strip()]


def summarize(rows, baseline_of):
    per = collections.defaultdict(list)
    meta = collections.defaultdict(dict)
    pids = collections.defaultdict(set)
    for r in rows:
        if r.get('warmup'):
            continue
        k = (r['scenario'], r['candidate'], r.get('process_index', 0))
        per[k].append(r['wall_ns'])
        pids[(r['scenario'], r['candidate'])].add(r.get('pid'))
        m = meta[(r['scenario'], r['candidate'])]
        m.setdefault('verdicts', set()).add(r.get('verdict_sha256'))
        if r.get('ok') is False:
            m['not_ok'] = m.get('not_ok', 0) + 1
        for key in ('certified', 'requests', 'verify_mismatch'):
            if key in r:
                m[key] = r[key]
        if 'alloc_peak_bytes' in r:
            m.setdefault('alloc', []).append(r['alloc_peak_bytes'])
        if 'work' in r:
            m['work'] = r['work']
    med = {k: statistics.median(v) for k, v in per.items()}
    out = []
    scen_cands = sorted({(s, c) for (s, c, _p) in med})
    for s, c in scen_cands:
        procs = sorted(p for (s2, c2, p) in med if (s2, c2) == (s, c))
        vals = [med[(s, c, p)] for p in procs]
        row = dict(scenario=s, candidate=c, processes=len(procs), pids=sorted(x for x in pids[(s, c)] if x),
                   wall_ms_process_medians=[round(v / 1e6, 3) for v in vals],
                   wall_ms_median=round(statistics.median(vals) / 1e6, 3))
        b = baseline_of(s, c)
        if b and b != c:
            ratios = [med[(s, c, p)] / med[(s, b, p)] for p in procs if (s, b, p) in med]
            if ratios:
                row['ratio_vs_' + b] = dict(median=round(statistics.median(ratios), 3),
                                            min=round(min(ratios), 3), max=round(max(ratios), 3))
        m = meta[(s, c)]
        row['distinct_verdict_hashes'] = len(m.get('verdicts', ()))
        for key in ('certified', 'requests', 'verify_mismatch', 'not_ok'):
            if key in m:
                row[key] = m[key]
        if 'alloc' in m:
            row['alloc_peak_kib_median'] = round(statistics.median(m['alloc']) / 1024, 1)
        out.append(row)
    return out


def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'results' / 'formal'
    res = {}
    if (root / 'rel.jsonl').exists():
        res['rel'] = summarize(load(root / 'rel.jsonl'), lambda s, c: 'x_fix_stamp' if c not in ('always_bump',) else 'current')
    if (root / 'incremental.jsonl').exists():
        res['incremental'] = summarize(load(root / 'incremental.jsonl'), lambda s, c: 'linear')
    if (root / 'protocol.jsonl').exists():
        res['protocol'] = summarize(load(root / 'protocol.jsonl'),
                                    lambda s, c: 'scan_guard' if s.startswith('guard') else 'typed_full')
    (root / 'formal_summary.json').write_text(json.dumps(res, indent=1))
    for fam, rows in res.items():
        print('==', fam)
        for r in rows:
            ratio = next((v for k, v in r.items() if k.startswith('ratio_vs_')), None)
            print(f"{r['scenario']:28s} {r['candidate']:18s} {r['wall_ms_median']:10.2f} ms  procs={r['processes']} "
                  f"ratio={ratio}  cert={r.get('certified', '')} hashes={r['distinct_verdict_hashes']}")


if __name__ == '__main__':
    main()
