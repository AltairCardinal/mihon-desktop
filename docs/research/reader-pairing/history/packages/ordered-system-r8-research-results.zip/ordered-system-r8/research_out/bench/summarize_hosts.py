"""Aggregate bench_hosts JSONL: per (scenario, candidate) median wall per process, then
median and range across processes; ratios vs 'current' and vs 'x_fix_stamp' (paired by process)."""
import json, statistics, sys
from collections import defaultdict


def load(path):
    return [json.loads(l) for l in open(path, encoding='utf-8') if l.strip()]


def aggregate(rows):
    per = defaultdict(list)
    for r in rows:
        if r['rep'] >= 0:
            per[(r['scenario'], r['candidate'], r['pid'])].append(r)
    med = {k: statistics.median(x['wall_ns'] for x in v) for k, v in per.items()}
    work = {k: v[0]['work'] for k, v in per.items()}
    ok = {k: all(x['ok'] for x in v) for k, v in per.items()}
    out = defaultdict(dict)
    pids = sorted({k[2] for k in med})
    for (s, c, p), m in med.items():
        out[(s, c)][p] = m
    table = []
    for (s, c), byp in out.items():
        ratios_cur = [byp[p] / out[(s, 'current')][p] for p in byp if p in out.get((s, 'current'), {})]
        ratios_fix = [byp[p] / out[(s, 'x_fix_stamp')][p] for p in byp if p in out.get((s, 'x_fix_stamp'), {})]
        w = work[(s, c, next(iter(byp)))]
        table.append(dict(scenario=s, candidate=c, processes=len(byp), median_ms=statistics.median(byp.values()) / 1e6,
                          range_ms=[min(byp.values()) / 1e6, max(byp.values()) / 1e6],
                          ratio_vs_current_median=statistics.median(ratios_cur) if ratios_cur else None,
                          ratio_vs_current_range=[min(ratios_cur), max(ratios_cur)] if ratios_cur else None,
                          ratio_vs_fix_median=statistics.median(ratios_fix) if ratios_fix else None,
                          ok=all(ok[(s, c, p)] for p in byp), engine_runs=w.get('engine_runs'),
                          memo_hits=w.get('memo_hits'), read_validations=w.get('read_validations', 0),
                          typed_reads_checked=w.get('typed_reads_checked', 0)))
    return table


def main():
    rows = load(sys.argv[1])
    table = aggregate(rows)
    if len(sys.argv) > 2:
        open(sys.argv[2], 'w').write(json.dumps(table, indent=1))
    scen = []
    for t in table:
        if t['scenario'] not in scen:
            scen.append(t['scenario'])
    for s in scen:
        print(s)
        for t in sorted((x for x in table if x['scenario'] == s), key=lambda x: x['median_ms']):
            rc = t['ratio_vs_current_median']; rf = t['ratio_vs_fix_median']
            print(f"   {t['candidate']:26s} {t['median_ms']:9.2f}ms" + (f"  vs_cur={rc:.3f}" if rc else '') + (f" vs_fix={rf:.3f}" if rf else '') +
                  f" runs={t['engine_runs']} hits={t['memo_hits']} val={t['read_validations']} ok={t['ok']}")


if __name__ == '__main__':
    main()
