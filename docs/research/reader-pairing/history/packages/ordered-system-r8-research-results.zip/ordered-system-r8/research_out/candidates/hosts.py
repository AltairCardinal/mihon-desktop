"""Host variants for the caching / invalidation family (C1 C2 C4 C5 C6 B4 B5 B6 G6).

Evidence layer: virtual_host.  The frozen current_baseline.Host is NOT edited;
XHost is an independent re-implementation of the same request contract:

    XHost(case, config=XConfig(...)).request(t)
        == {k: v for k, v in reference.certify_strategy(case, t)['selected'].items() if k != 'reads'}

for every mechanism except those explicitly labelled L1 (B5 'share_pair').

Mechanism switches (one XConfig, single-control ablations by dataclasses.replace):

  support       'selected'  cache only the selected attempt's proof (frozen Host behaviour,
                            shown UNSOUND by fixtures/host_traces/c5_retry_support_cex.json)
                'attempts'  B4/C5 route A: per-attempt entries; each attempt validated and
                            recomputed independently (sub-problem reuse across retries)
                'union'     C5 route B: selected verdict, support = reads of every attempt run
  invalidation  'exact'     typed read validation on every hit (Config.current minus stamps)
                'stamp'     global (binding, revision) stamp, exact fallback (frozen behaviour)
                'posrev'    C1 route A: per-item / per-edge revision vector via write barrier
                'log'       C1 route B: global revision + change log (log_cap None = unbounded)
                'revdep'    C2 route A: reverse dependency index, push dirty marks
                'bitmap'    C2 route B: per-entry dependency bitmask, replace sweeps entries
  proof         'compact'   compact_core fingerprints
                'interned'  C4 route A: (key, typed value) interned to shared ids
  view          'request'   fresh dynamic Index per request (frozen behaviour)
                'snapshot'  C4 route B / B5: dynamic Index reused until the next write; unchanged
                            positions keep tuple identity, so validation can use `is` first
  cache         'fifo'      capacity entries, insertion order (frozen behaviour)
                'gds'       C6 route A: GreedyDual-Size (rebuild cost / size), entry capacity
                'bytes'     C6 route B / G6: FIFO under a structural byte budget
                'gdsbytes'  X5 combination
  update        'replace'   whole snapshot + diff (write barrier = diff of owned snapshots)
                'delta'     owner methods set_analysis/set_header/set_edge (complete barrier)
"""
from collections import OrderedDict, Counter
from copy import deepcopy
from dataclasses import dataclass
import heapq
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import reference as ref  # noqa: E402
import compact_core as core  # noqa: E402
from current_baseline import typed, public  # noqa: E402

SAT = (1 << 63) - 1
ENTRY_OVERHEAD = 16       # structural units per cached attempt (guard, stamps, metadata)


@dataclass(frozen=True)
class XConfig:
    support: str = 'attempts'
    invalidation: str = 'stamp'
    proof: str = 'compact'
    view: str = 'request'
    cache: str = 'fifo'
    capacity: int = 4
    byte_budget: int = 4 * 160
    log_cap: object = 64
    max_order: int = 4096
    max_reads: int = 4096
    exact_fallback: bool = True      # after a dependency change, try exact validation before recompute
    prep_side: int = 0               # B6 route B: prepared entries live in a separate side cache


class HostMutant:
    """Named mutants used by tests (each must be killed)."""
    NONE = None
    BARRIER_SKIPS_HEADER = 'barrier_skips_header'          # mutant 1
    BARRIER_SKIPS_EDGE = 'barrier_skips_edge'              # mutant 1
    REVDEP_NO_REREGISTER = 'revdep_no_reregister'          # replaced dependency set not registered (C2)
    REVDEP_NO_DEREGISTER = 'revdep_no_deregister'          # stale registrations never removed (C2/G6)
    UNKNOWN_EQ_NULL = 'unknown_eq_null'                    # mutant 2
    DROP_PRUNED_READS = 'drop_pruned_reads'                # mutant 7
    BUDGET_AFTER = 'budget_after'                          # mutant 8
    BUDGET_ABORT_CACHED = 'budget_abort_cached'            # C5
    HASH_ONLY = 'hash_only'                                # C4
    INTERN_NO_PRUNE = 'intern_no_prune'                    # G6 unbounded table
    SELECTED_SUPPORT = 'selected_support'                  # C5 frozen behaviour


def _deps_of(proof):
    items, edges = set(), set()
    for key, _ in proof[2]:
        if key[0] == 'rank':
            items.add(key[1]); items.add(key[2])
            if key[2] == key[1] + 1:
                edges.add(key[1])
        else:
            items.add(key[1])
    return frozenset(items), frozenset(edges)


def _edge_index(case):
    out = {}
    for e in case.get('edges', []):
        out[(e['first'], e['second'])] = e
    return out


def _settings_norm(case):
    s = case.get('settings', {})
    return (s.get('direction', 'AB'), s.get('automatic', False), tuple(sorted(set(s.get('hard_isolates', [])))),
            tuple(sorted(set(s.get('pinned_links', [])))), s.get('opening', 'AUTO'), s.get('revision', 0))


def _identity(case):
    items = case['items']
    return (case.get('generation', 0), case.get('order_revision', 0),
            tuple((x.get('id', str(i)), x.get('content_version', 0), x.get('rotation', 0), x.get('orientation', 1))
                  for i, x in enumerate(items)))


class Interner:
    """C4 route A: exact interning; equality never rests on hash alone."""

    def __init__(self, mutant=None):
        self.table = {}
        self.values = []
        self.mutant = mutant

    def intern(self, key, value):
        tv = (key, typed(value))
        if self.mutant == HostMutant.HASH_ONLY:
            tv = (key, hash(typed(value)))
        got = self.table.get(tv)
        if got is None:
            got = len(self.values)
            self.table[tv] = got
            self.values.append(tv)
        return got

    def lookup(self, key, value):
        tv = (key, typed(value)) if self.mutant != HostMutant.HASH_ONLY else (key, hash(typed(value)))
        return self.table.get(tv)

    def clear(self):
        self.table.clear()
        self.values.clear()

    def prune(self, live_ids):
        """Rebuild keeping only ids referenced by live entries (ids are remapped)."""
        keep = sorted(live_ids)
        remap = {}
        values, table = [], {}
        for old in keep:
            remap[old] = len(values)
            tv = self.values[old]
            values.append(tv)
            table[tv] = remap[old]
        self.values, self.table = values, table
        return remap


class XHost:
    def __init__(self, case, *, config=XConfig(), mutant=None):
        if config.capacity < 1:
            raise ValueError('invalid storage bound')
        self.config = config
        self.mutant = mutant
        self.metrics = Counter()
        self._cache = OrderedDict()      # target -> entry
        self._binding = 0
        self._closed = False
        self._location = (None, 0)
        self._case = None
        self._identity = None
        self._settings = None
        self._revision = 0
        self._item_rev = []
        self._edge_rev = {}
        self._log = []                   # (revision, frozenset(('i',p)|('e',a)))
        self._log_floor = 0              # revisions <= floor are no longer in the log
        self._revdep = {}                # dep -> set((target, attempt))
        self._view = None
        self._structure = None
        self._interner = Interner(mutant)
        self._side = OrderedDict()
        if config.prep_side and config.invalidation in ('revdep', 'bitmap'):
            raise ValueError('side cache requires snapshot-validated invalidation (stamp/posrev/log/exact)')
        self._gds_L = 0.0
        self._bytes = 0
        self._item_fp = []
        self._edge_fp = {}
        self.replace(case)

    # ------------------------------------------------------------ ownership
    def snapshot(self):
        return deepcopy(self._case)

    @property
    def memo_size(self):
        return len(self._cache)

    def locate(self, item_id, sequence):
        self._location = (item_id, sequence)

    def _guard(self):
        return (self._binding, self._identity, self._settings, self._location)

    def close(self):
        self._side.clear()
        self._cache.clear()
        self._revdep.clear()
        self._log.clear()
        self._interner.clear()
        self._view = None
        self._structure = None
        self._case = None
        self._bytes = 0
        self._closed = True
        self.metrics['closes'] += 1

    def rebind(self, case):
        self.close()
        self._binding += 1
        self._closed = False
        self._location = (None, 0)
        self._identity = None
        self.replace(case)
        self.metrics['rebinds'] += 1

    # --------------------------------------------------------- write barrier
    def _bump(self, changed_items, changed_edges, global_change):
        """Single choke point: every owned-state write passes here."""
        old_view, self._view = self._view, None
        if (self.config.view == 'carry' and old_view is not None and not global_change
                and -1 not in changed_items and self._structure is not None):
            # C4 route B+: keep parsed tuples of unchanged positions (identity => `is` validation)
            v = core.Index(self._case, check_ids=False)
            v._ident = self._structure
            v._analysis = {k: t for k, t in old_view._analysis.items() if k not in changed_items}
            v._header = {k: t for k, t in old_view._header.items() if k not in changed_items}
            self._view = v
            self.metrics['view_carries'] += 1
        if not (changed_items or changed_edges or global_change):
            return
        self._revision = min(self._revision + 1, SAT)
        self.metrics['evidence_updates'] += 1
        for p in changed_items:
            if 0 <= p < len(self._item_rev):
                self._item_rev[p] = min(self._item_rev[p] + 1, SAT)
        for a in changed_edges:
            self._edge_rev[a] = min(self._edge_rev.get(a, 0) + 1, SAT)
        inv = self.config.invalidation
        deps = {('i', p) for p in changed_items} | {('e', a) for a in changed_edges}
        if inv == 'log':
            self._log.append((self._revision, frozenset(deps)))
            self.metrics['log_appends'] += 1
            cap = self.config.log_cap
            if cap is not None and len(self._log) > cap:
                drop = len(self._log) - cap
                self._log_floor = self._log[drop - 1][0]
                del self._log[:drop]
        elif inv == 'revdep':
            for d in deps:
                for key in self._revdep.get(d, ()):
                    t, att = key
                    e = self._cache.get(t)
                    if e is not None and e['att'][att] is not None:
                        e['att'][att]['dirty'] = True
                        self.metrics['push_marks'] += 1
        elif inv == 'bitmap':
            mask = 0
            n = len(self._item_rev)
            for p in changed_items:
                mask |= 1 << p
            for a in changed_edges:
                mask |= 1 << (n + a)
            for e in self._cache.values():
                for a in e['att']:
                    if a is not None and a['mask'] & mask:
                        a['dirty'] = True
                self.metrics['bitmap_sweeps'] += 1

    def replace(self, case):
        if self._closed:
            raise ValueError('closed host requires rebind')
        new = deepcopy(case)
        ref._Input(new)                               # same validation errors as the frozen host
        ident, sett = _identity(new), _settings_norm(new)
        n = len(new['items'])
        self.metrics['update_calls'] += 1
        self.metrics['update_item_slots'] += n
        if self._case is None or ident != self._identity:
            # identity change anywhere: global invalidation (structure, revisions reset)
            self._structure = None
            self._item_rev = [0] * n
            self._edge_rev = {}
            self._item_fp, self._edge_fp = [], {}      # lazy: built by the next replace() diff
            first = self._case is None
            self._case, self._identity, self._settings = new, ident, sett
            if not first:
                self._cache.clear(); self._revdep.clear(); self._bytes = 0; self._side.clear()
                if self.mutant != HostMutant.INTERN_NO_PRUNE:
                    self._interner.clear()
            self._bump(set(range(n)), set(), True)
            return
        old = self._case
        glob = sett != self._settings or new.get('closed', False) != old.get('closed', False)
        changed_items, changed_edges = set(), set()
        if self.config.invalidation in ('exact', 'stamp'):
            # frozen behaviour: whole typed comparison; no per-position information needed
            if typed(old) != typed(new):
                changed_items = {-1}
            self.metrics['diff_item_typed'] += 2 * n
        else:
            if not self._item_fp and n:
                self._item_fp = [typed(x) for x in old['items']]
                self._edge_fp = {k: typed(v) for k, v in _edge_index(old).items()}
                self.metrics['diff_item_typed'] += n
            fps = []
            for i, x in enumerate(new['items']):
                fp = typed(x)
                fps.append(fp)
                if fp != self._item_fp[i]:
                    if not (self.mutant == HostMutant.BARRIER_SKIPS_HEADER and
                            typed({k: v for k, v in x.items() if k != 'header'}) ==
                            typed({k: v for k, v in old['items'][i].items() if k != 'header'})):
                        changed_items.add(i)
            self._item_fp = fps
            self.metrics['diff_item_typed'] += n
            new_edges = {k: typed(v) for k, v in _edge_index(new).items()}
            for k in set(new_edges) | set(self._edge_fp):
                if new_edges.get(k) != self._edge_fp.get(k):
                    a, b = k
                    if b == a + 1 and 0 <= a < n - 1 and self.mutant != HostMutant.BARRIER_SKIPS_EDGE:
                        changed_edges.add(a)
                    # non-adjacent records are never read (compact_core.Index.edge, lemma H-E)
            self._edge_fp = new_edges
            self.metrics['diff_edge_typed'] += len(new_edges)
            if typed({k: v for k, v in new.items() if k not in ('items', 'edges')}) != \
               typed({k: v for k, v in old.items() if k not in ('items', 'edges')}) and not glob:
                glob = True     # other top-level fields: conservative global bump
        self._case, self._settings = new, sett
        if glob:
            self._cache.clear(); self._revdep.clear(); self._bytes = 0; self._side.clear()
        self._bump(changed_items, changed_edges, glob)

    # owner delta API (complete write-barrier entrances, no whole-snapshot copy)
    def set_analysis(self, i, analysis):
        self._check_open()
        self._case['items'][i]['analysis'] = deepcopy(analysis)
        if self._item_fp:
            self._item_fp[i] = typed(self._case['items'][i])
        self.metrics['delta_updates'] += 1
        self._bump({i}, set(), False)

    def set_header(self, i, header):
        self._check_open()
        self._case['items'][i]['header'] = deepcopy(header)
        if self._item_fp:
            self._item_fp[i] = typed(self._case['items'][i])
        self.metrics['delta_updates'] += 1
        self._bump(set() if self.mutant == HostMutant.BARRIER_SKIPS_HEADER else {i}, set(), False)

    def set_edge(self, a, b, record):
        self._check_open()
        recs = [e for e in self._case.get('edges', []) if (e['first'], e['second']) != (a, b)]
        if record is not None:
            r = deepcopy(record); r['first'], r['second'] = a, b
            recs.append(r)
        self._case['edges'] = recs
        if self._item_fp:
            if record is None:
                self._edge_fp.pop((a, b), None)
            else:
                self._edge_fp[(a, b)] = typed(recs[-1])
        self.metrics['delta_updates'] += 1
        n = len(self._case['items'])
        edge = {a} if (b == a + 1 and 0 <= a < n - 1 and self.mutant != HostMutant.BARRIER_SKIPS_EDGE) else set()
        self._bump(set(), edge, False)

    def _check_open(self):
        if self._closed:
            raise ValueError('closed host')

    # ------------------------------------------------------------- views
    def _index(self):
        if self.config.view in ('snapshot', 'carry') and self._view is not None:
            self.metrics['view_reuses'] += 1
            return self._view
        reuse = self._structure is not None
        index = core.Index(self._case, check_ids=not reuse)
        self.metrics['index_views'] += 1
        if not reuse:
            self._structure = {i: index.ident(i) for i in range(index.n)}
            self.metrics['input_index_builds'] += 1
            self.metrics['identity_slots_built'] += len(self._structure)
        index._ident = self._structure
        if self.config.view in ('snapshot', 'carry'):
            self._view = index
        return index

    def _now(self, index, key):
        kind = key[0]
        if kind == 'analysis':
            return index.analysis(key[1])
        if kind == 'header':
            return index.header(key[1])
        if kind == 'dimension':
            fact = index.effective(key[1])
            return fact[:5] + ('UNKNOWN',) if fact else None
        now = index.edge(key[1], key[2])
        if self.mutant == HostMutant.UNKNOWN_EQ_NULL and now in (('unknown',), ('computed', None, 1)):
            return ('nullish',)
        return now

    def _exact(self, att, index):
        self.metrics['read_validations'] += 1
        reads = att['reads']
        if self.config.proof == 'interned':
            for key, rid in reads:
                self.metrics['typed_reads_checked'] += 1
                if self._interner.lookup(key, self._now(index, key)) != rid:
                    return False
            return True
        for key, old in reads:
            now = self._now(index, key)
            self.metrics['typed_reads_checked'] += 1
            if old is now:
                self.metrics['identity_hits'] += 1
                continue
            if self.mutant == HostMutant.UNKNOWN_EQ_NULL:
                old = ('nullish',) if old in (('unknown',), ('computed', None, 1)) else old
            if typed(old) != typed(now):
                return False
        return True

    def _snap(self, att):
        inv = self.config.invalidation
        if inv == 'posrev':
            return tuple(self._item_rev[p] for p in att['items']) + tuple(self._edge_rev.get(a, 0) for a in att['edges'])
        return (self._binding, self._revision)

    def _valid(self, att, index):
        """Is a stored attempt still exactly current?"""
        if self._case.get('closed', False) or att['guard'] != self._guard():
            return False
        inv = self.config.invalidation
        if inv == 'stamp':
            if self._revision < SAT and att['snap'] == (self._binding, self._revision):
                self.metrics['stamp_hits'] += 1
                return True
        elif inv == 'posrev':
            if self._revision < SAT and max(self._item_rev, default=0) < SAT and att['snap'] == self._snap(att):
                self.metrics['posrev_hits'] += 1
                return True
        elif inv == 'log':
            r0 = att['snap'][1]
            if self._revision < SAT and r0 == self._revision:
                self.metrics['stamp_hits'] += 1
                return True
            if self._revision < SAT and r0 >= self._log_floor:
                touched = set()
                for rev, deps in self._log:
                    if rev > r0:
                        touched |= deps
                        self.metrics['log_scanned'] += 1
                if not (touched & att['depset']):
                    att['snap'] = (self._binding, self._revision)
                    self.metrics['log_hits'] += 1
                    return True
            else:
                self.metrics['log_truncated_fallbacks'] += 1
        elif inv in ('revdep', 'bitmap'):
            if not att['dirty']:
                self.metrics['clean_hits'] += 1
                return True
        if not self.config.exact_fallback and inv != 'exact':
            return False
        if self._exact(att, index):
            att['snap'] = self._snap(att)
            att['dirty'] = False
            return True
        return False

    # ----------------------------------------------------------- requests
    def _attempt(self, target, window, index):
        self.metrics['engine_runs'] += 1
        r = core.certify(self._case, target, window, index=index)
        self.metrics['scan_steps'] += r['steps']
        return r

    def _make_att(self, result, target, extra_reads=()):
        proof = result['proof']
        reads = list(proof[2]) + list(extra_reads)
        if self.mutant == HostMutant.DROP_PRUNED_READS and result.get('unit'):
            keep = {s['item'] for s in result['unit']['slots']}
            reads = [(k, v) for k, v in reads if k[1] in keep]
        if self.config.proof == 'interned':
            reads = [(k, self._interner.intern(k, v)) for k, v in reads]
        items, edges = set(), set()
        for key, _ in reads:
            if key[0] == 'rank':
                items.update((key[1], key[2]))
                if key[2] == key[1] + 1:
                    edges.add(key[1])
            else:
                items.add(key[1])
        n = len(self._item_rev)
        mask = 0
        for p in items:
            mask |= 1 << p
        for a in edges:
            mask |= 1 << (n + a)
        att = dict(result=result, reads=reads, items=tuple(sorted(items)), edges=tuple(sorted(edges)),
                   depset=frozenset({('i', p) for p in items} | {('e', a) for a in edges}),
                   mask=mask, guard=self._guard(), dirty=False)
        att['snap'] = self._snap(att)
        return att

    def request(self, target):
        if self._closed:
            raise ValueError('closed host')
        self.metrics['requests'] += 1
        index = self._index()
        entry = self._cache.get(target)
        if entry is None and target in self._side:
            entry = self._side.pop(target)            # promote a prepared entry (validated below)
            self._insert(target, entry)
            entry = self._cache.get(target)
        support = 'selected' if self.mutant == HostMutant.SELECTED_SUPPORT else self.config.support
        a2, a3 = entry['att'] if entry is not None else (None, None)
        v2 = a2 is not None and self._valid(a2, index)
        if support != 'attempts':
            if v2:
                self.metrics['memo_hits'] += 1
                self._on_hit(target, entry)
                return public(entry['selected'])
            r2 = self._attempt(target, 2, index)
            r3 = None
            if r2['status'] == 'need_facts':
                self.metrics['confluence_retries'] += 1
                r3 = self._attempt(target, 3, index)
            selected = r3 if (r3 is not None and r3['status'] == 'certified') else r2
            self._store(target, r2, r3, selected, None, None)
            return public(selected)
        # B4/C5 route A: attempts are independent sub-problems
        if v2 and a2['result']['status'] != 'need_facts':
            self.metrics['memo_hits'] += 1
            self._on_hit(target, entry)
            return public(a2['result'])
        att2 = a2 if v2 else None
        r2 = a2['result'] if v2 else self._attempt(target, 2, index)
        att3, r3 = None, None
        if r2['status'] == 'need_facts':
            self.metrics['confluence_retries'] += 1
            if a3 is not None and self._valid(a3, index):
                att3, r3 = a3, a3['result']
            else:
                r3 = self._attempt(target, 3, index)
        selected = r3 if (r3 is not None and r3['status'] == 'certified') else r2
        if att2 is not None and att3 is not None:
            self.metrics['memo_hits'] += 1
            self._on_hit(target, entry)
            return public(selected)
        if att2 is not None or att3 is not None:
            self.metrics['subproblem_reuse'] += 1
        self._store(target, r2, r3, selected, att2, att3)
        return public(selected)

    # --------------------------------------------------------------- store
    def _build_entry(self, target, r2, r3, selected, att2, att3):
        support = 'selected' if self.mutant == HostMutant.SELECTED_SUPPORT else self.config.support
        if support == 'attempts':
            a2 = att2 if att2 is not None else self._make_att(r2, target)
            a3 = None
            if r3 is not None:
                a3 = att3 if att3 is not None else self._make_att(r3, target)
            atts = [a2, a3]
        elif support == 'union':
            extra = ()
            if r3 is not None:
                extra = r2['proof'][2] if selected is r3 else r3['proof'][2]
            atts = [self._make_att(selected, target, extra), None]
        else:
            atts = [self._make_att(selected, target), None]
        size = sum(len(a['reads']) + ENTRY_OVERHEAD for a in atts if a is not None)
        cost = sum(a['result']['steps'] + len(a['reads']) for a in atts if a is not None)
        return dict(att=atts, selected=selected, size=size, cost=cost, prio=0.0, reused2=att2 is not None)

    def _store(self, target, r2, r3, selected, att2, att3):
        self._insert(target, self._build_entry(target, r2, r3, selected, att2, att3))

    def _insert(self, target, entry):
        cfg = self.config
        size = entry['size']
        if len(self._case['items']) > cfg.max_order or size - ENTRY_OVERHEAD > cfg.max_reads:
            self._evict_key(target)
            self.metrics['oversized_bypasses'] += 1
            return
        self._evict_key(target)
        if cfg.cache in ('gds', 'gdsbytes'):
            entry['prio'] = self._gds_L + entry['cost'] / size
        self._cache[target] = entry
        self._bytes += size
        atts = entry['att']
        self.metrics['stored_read_keys'] += size - ENTRY_OVERHEAD * sum(a is not None for a in atts)
        if cfg.invalidation == 'revdep':
            for ai, a in enumerate(atts):
                if a is None:
                    continue
                if self.mutant == HostMutant.REVDEP_NO_REREGISTER and ai == 0 and entry.get('reused2'):
                    continue
                for d in a['depset']:
                    self._revdep.setdefault(d, set()).add((target, ai))
                    self.metrics['revdep_edges_added'] += 1
        self._enforce()

    def _evict_key(self, target):
        e = self._cache.pop(target, None)
        if e is None:
            return
        if e.get('prepared'):
            self.metrics['prepared_discarded'] += 1
        self._bytes -= e['size']
        if self.config.invalidation == 'revdep' and self.mutant != HostMutant.REVDEP_NO_DEREGISTER:
            for ai, a in enumerate(e['att']):
                if a is None:
                    continue
                for d in a['depset']:
                    s = self._revdep.get(d)
                    if s is not None:
                        s.discard((target, ai))
                        if not s:
                            del self._revdep[d]

    def _maybe_prune_interner(self):
        live = set()
        for e in self._cache.values():
            for a in e['att']:
                if a is not None:
                    live.update(rid for _, rid in a['reads'])
        if len(self._interner.values) > 2 * max(16, len(live)):
            remap = self._interner.prune(live)
            for e in self._cache.values():
                for a in e['att']:
                    if a is not None:
                        a['reads'] = [(k, remap[r]) for k, r in a['reads']]
            self.metrics['intern_prunes'] += 1

    def _victim(self):
        if self.config.cache in ('gds', 'gdsbytes'):
            t = min(self._cache, key=lambda k: self._cache[k]['prio'])
            self._gds_L = self._cache[t]['prio']
            return t
        return next(iter(self._cache))

    def _enforce(self):
        cfg = self.config
        while True:
            over_entries = cfg.cache in ('fifo', 'gds') and len(self._cache) > cfg.capacity
            over_bytes = cfg.cache in ('bytes', 'gdsbytes') and self._bytes > cfg.byte_budget and len(self._cache) > 1
            if not (over_entries or over_bytes):
                break
            self._evict_key(self._victim())
            self.metrics['memo_evictions'] += 1
        if cfg.proof == 'interned' and self.mutant != HostMutant.INTERN_NO_PRUNE:
            self._maybe_prune_interner()

    def _on_hit(self, target, entry):
        if entry.get('prepared'):
            entry['prepared'] = False
            self.metrics['prepared_hits'] += 1
        if self.config.cache in ('gds', 'gdsbytes'):
            entry['prio'] = self._gds_L + entry['cost'] / entry['size']

    # ------------------------------------------------- B5 / B6 extensions
    def request_many(self, targets):
        """B5 route A (L0): one view/guard for a batch; identical per-target verdicts."""
        return [self.request(t) for t in targets]

    def prepare(self, targets, budget):
        """B6: background preparation; budget counts engine attempts and is checked
        BEFORE each attempt.  Prepared entries carry no publication right; an
        exhausted budget never stores a partial (budget-aborted) verdict."""
        if self._closed:
            return 0
        used = 0
        index = self._index()
        for t in targets:
            if not 0 <= t < len(self._case['items']):
                continue
            e = self._cache.get(t) or self._side.get(t)
            if e is not None and e['att'][0] is not None and self._valid(e['att'][0], index):
                continue
            if self.mutant != HostMutant.BUDGET_AFTER and used + 1 > budget:
                break
            before = self.metrics['engine_runs']
            r2 = self._attempt(t, 2, index)
            used += 1
            r3 = None
            if r2['status'] == 'need_facts':
                if self.mutant != HostMutant.BUDGET_AFTER and used + 1 > budget:
                    # budget abort: do NOT cache r2 as final strategy verdict
                    if self.mutant == HostMutant.BUDGET_ABORT_CACHED:
                        self._store(t, r2, None, r2, None, None)
                    self.metrics['prepare_aborted'] += 1
                    self.metrics['prepare_wasted_runs'] += 1
                    break
                r3 = self._attempt(t, 3, index)
                used += 1
            sel = r3 if (r3 is not None and r3['status'] == 'certified') else r2
            if self.config.prep_side:
                pe = self._build_entry(t, r2, r3, sel, None, None)
                pe['prepared'] = True
                self._side.pop(t, None)
                self._side[t] = pe
                while len(self._side) > self.config.prep_side:
                    self._side.popitem(last=False)
                    self.metrics['prepared_discarded'] += 1
            else:
                self._store(t, r2, r3, sel, None, None)
                pe = self._cache.get(t)
                if pe is not None:
                    pe['prepared'] = True
            self.metrics['prepared_runs'] += self.metrics['engine_runs'] - before
            if self.mutant == HostMutant.BUDGET_AFTER and used >= budget:
                break
        self.metrics['prepare_calls'] += 1
        return used

    def structural_size(self):
        """G6: structural units retained by this host."""
        ents = len(self._cache)
        reads = sum(len(a['reads']) for e in self._cache.values() for a in e['att'] if a is not None)
        revdep = sum(len(s) for s in self._revdep.values())
        log = sum(len(d) for _, d in self._log)
        return dict(entries=ents, read_keys=reads, revdep_edges=revdep, log_deps=log, log_len=len(self._log),
                    intern_values=len(self._interner.values), item_revs=len(self._item_rev),
                    edge_revs=len(self._edge_rev), structure_slots=len(self._structure or {}),
                    snapshots=1 if self._case is not None else 0)


def share_pair_answer(host, target, partner_result):
    """B5 route B (L1 only): answer a pair partner from a certified pair unit.
    Same unit as the reference, but first/steps/dependent_items differ: see
    tests (test_b5_pair_sharing_is_not_L0)."""
    u = partner_result['unit']
    if partner_result['status'] != 'certified' or not any(s['item'] == target for s in u['slots']):
        return None
    return dict(partner_result)
