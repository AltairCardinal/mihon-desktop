"""Runs A1/A5/E3/E4 checks and writes results/theory_a.json."""
import json, random, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import *
import theory_a as A
import transducer as T

out = {}
t0 = time.time()
sep = A.separation_table(max_len=6, samples=300)
out['A1_separation'] = [dict(pair=[A.MODES[x], A.MODES[y]], shortest_suffix=L,
                             witness=c) for (x, y), (L, c) in sorted(sep.items())]
out['A1_unseparated_pairs'] = [[A.MODES[x], A.MODES[y]] for x in range(5) for y in range(x + 1, 5) if (x, y) not in sep]
out['A1_unbounded'] = A.unbounded_separation()
out['A1_reference_lookback'] = A.reference_lookback_cost()
# A5: order compression preserves the plan; signature equality implies plan equality
rng = random.Random(5); bad = 0; tot = 0; sig_collisions = 0
for k in range(4000):
    c = roundtrip(random_case(rng, rng.randrange(2, 12), p_unknown=0.1, p_edge_unknown=0.2, domain='ext'))
    p = ref.complete_plan(c); q = ref.complete_plan(A.compress_ranks(c)); tot += 1
    bad += p != q
out['A5_compression'] = dict(cases=tot, plan_mismatch=bad)
# A5 converse: same order signature + same non-rank facts => same plan (random value re-draws)
mism = 0; trials = 0
for k in range(3000):
    c = roundtrip(random_case(rng, rng.randrange(3, 10), domain='ext'))
    sig = A.order_signature(c)
    d = json.loads(json.dumps(c))
    for e in d['edges']:
        if e.get('status') == 'computed' and e.get('score') is not None:
            e['score'] = rng.choice((-5, 0.5, 2, 3, 9, 1e9))
    if A.order_signature(d) == sig:
        trials += 1
        mism += ref.complete_plan(c) != ref.complete_plan(d)
out['A5_signature_sufficiency'] = dict(trials_with_equal_signature=trials, plan_mismatch=mism)
# E3: label-swap equivariance (rank values held fixed) and reversal counterexample
bad = 0; tot = 0; rev_cex = None
for k in range(3000):
    c = roundtrip(random_case(rng, rng.randrange(1, 12), p_unknown=0.1, domain='ext'))
    tot += 1
    if ref.complete_plan(A.swap_sides(c)) != A.swap_unit_labels(ref.complete_plan(c)):
        bad += 1
    if rev_cex is None:
        r = A.reversed_case(c); n = len(c['items'])
        pr = ref.complete_plan(r)
        mapped = sorted(tuple(sorted(n - 1 - s['item'] for s in u['slots'])) for u in pr)
        orig = sorted(tuple(sorted(s['item'] for s in u['slots'])) for u in ref.complete_plan(c))
        if mapped != orig:
            rev_cex = c
out['E3_label_swap'] = dict(cases=tot, mismatches=bad)
out['E3_reversal_counterexample'] = rev_cex
# automatic=off direction toggle: plan reusable by relabelling (ranks unread)
bad = 0
for k in range(1000):
    c = roundtrip(random_case(rng, rng.randrange(1, 12), automatic=False))
    d = json.loads(json.dumps(c)); d['settings']['direction'] = 'BA' if c['settings']['direction'] == 'AB' else 'AB'
    for e in d['edges']:
        if e.get('status') == 'computed': e['score'] = rng.choice((None, 1, 2))
    bad += ref.complete_plan(d) != A.swap_unit_labels(ref.complete_plan(c))
out['E3_autooff_toggle_relabel'] = dict(cases=1000, mismatches=bad,
    note='automatic=False: sides and ranks are never read, so a direction toggle only relabels slots')
# E4 numeric boundaries
rows = []
for label, c, note in A.e4_cases():
    rt = roundtrip(c)
    p = ref.complete_plan(rt); q = ref.complete_plan(A.as_double_interface(rt))
    rows.append(dict(label=label, note=note, python_plan=[[s['item'] for s in u['slots']] for u in p],
                     double_plan=[[s['item'] for s in u['slots']] for u in q], differ=p != q,
                     signature=A.order_signature(rt)[1]))
out['E4_boundaries'] = rows
out['seconds'] = round(time.time() - t0, 1)
Path(__file__).resolve().parents[1].joinpath('results', 'theory_a.json').write_text(json.dumps(out, indent=1, allow_nan=False))
print(json.dumps({k: v for k, v in out.items() if k not in ('A1_separation', 'E3_reversal_counterexample')}, indent=0)[:3000])
print([(r['pair'], r['shortest_suffix']) for r in out['A1_separation']])
