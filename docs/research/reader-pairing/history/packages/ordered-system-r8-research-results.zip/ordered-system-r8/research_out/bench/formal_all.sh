#!/bin/sh
# Serial formal timing: one benchmark at a time, 3 independent processes each.
set -e
cd "$(dirname "$0")/.."
R=results/formal
mkdir -p $R
date -u +%FT%TZ > $R/started_utc.txt
python3 bench/bench_rel.py --verify --out $R/rel_verify.json > /dev/null
python3 bench/bench_rel.py --processes 3 --reps 3 --warmup 1 --out $R/rel.jsonl
date -u +%FT%TZ > $R/rel_done_utc.txt
python3 bench/bench_incremental.py --processes 3 --reps 3 --warmup 1 --out $R/incremental.jsonl
date -u +%FT%TZ > $R/incremental_done_utc.txt
python3 bench/drive_protocol.py --out $R/protocol.jsonl --reps 3 --warmup 1
date -u +%FT%TZ > $R/protocol_done_utc.txt
python3 bench/bench_hosts.py --processes 3 --reps 3 --warmup 1 --alloc --out $R/hosts.jsonl
python3 bench/summarize_hosts.py $R/hosts.jsonl $R/hosts_summary.json
date -u +%FT%TZ > $R/finished_utc.txt
