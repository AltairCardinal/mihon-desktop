"""L1 early-certification hosts on the host family's frozen exogenous traces.

Candidates: current (frozen Host, Config.current()), x_fix_stamp (L0 host with
the C5 support fix), rel_tree / rel_exact (x_fix_stamp + relational
certification only on need_facts).  Verdict hashes differ by design for L1
candidates; correctness is checked per request:
  * whenever the L1 host returns the base verdict it must equal the reference
    verdict (truth) - same as L0;
  * every extra certificate is cross-checked by the other relational
    certifier (tree-certified => exact-certified, same unit) and against any
    later reference certificate for the same target in the same context.
"""
import argparse, copy, hashlib, json, os, subprocess, sys, time, tracemalloc
from pathlib import Path
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[1] / 'candidates'))
import common  # noqa
from host_driver import replay, truth, make
from host_traces import apply_event
import relhost as RH
import omega as O
import transducer as T
import reference as ref

TRACE_DIR = HERE.parents[1] / 'fixtures' / 'host_traces' / 'bench'
SCEN = ['s16_neighbor_relevant', 's64_neighbor_irrelevant_r4', 's64_repeat_quiet_r4', 's64_ws5_quiet', 's64_ws3_relevant',
        's64_jump_churn', 's64_neighbor_fail', 's256_neighbor_irrelevant_r4', 's256_roundtrip_growth',
        's512_neighbor_irrelevant_r4', 's512_jump_relevant']
CANDIDATES = ['current', 'x_fix_stamp', 'rel_tree', 'rel_exact', 'rel_portfolio', 'x_delta_posrev', 'rel_tree_dposrev', 'always_bump']


def factory_for(cand):
    if cand in ('current', 'x_fix_stamp', 'x_delta_posrev'):
        return make(cand)[0]
    if cand == 'always_bump':
        from nh_hosts import AlwaysBump
        from current_baseline import Config
        return lambda c: AlwaysBump(c, config=Config.current())
    if cand == 'rel_tree_dposrev':
        base = make('x_delta_posrev')[0]
        return lambda c: RH.RelHostDelta(c, base, 'tree')
    base = make('x_fix_stamp')[0]
    mode = cand.split('_', 1)[1]
    return lambda c: RH.RelHost(c, base, mode)


def load(name):
    return json.loads((TRACE_DIR / f'{name}.json').read_text(encoding='utf-8'))


def run_one(name, cand, rep=0, alloc=False):
    tr = load(name)
    f = factory_for(cand)
    t0 = time.perf_counter_ns()
    delta = cand in ('x_delta_posrev', 'rel_tree_dposrev')
    verdicts, host = replay(tr, f, delta, collect=True, prepare=False)
    wall = time.perf_counter_ns() - t0
    row = dict(scenario=name, candidate=cand, rep=rep, wall_ns=wall,
               verdict_sha256=hashlib.sha256(json.dumps(verdicts, sort_keys=True).encode()).hexdigest(),
               certified=sum(v['status'] == 'certified' for v in verdicts), requests=len(verdicts),
               work={k: v for k, v in host.metrics.items()})
    if alloc:
        tracemalloc.start(); replay(tr, f, delta, collect=True, prepare=False)
        row['alloc_peak_bytes'] = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    return row, verdicts


def verify(name):
    tr = load(name)
    want = truth(tr)
    out = {}
    vt = run_one(name, 'rel_tree')[1]
    ve = run_one(name, 'rel_exact')[1]
    vb = run_one(name, 'x_fix_stamp')[1]
    vd = run_one(name, 'rel_tree_dposrev')[1]
    vdp = run_one(name, 'x_delta_posrev')[1]
    out['delta_tree_equal'] = vd == vt
    out['delta_posrev_l0_mismatch'] = sum(b != w for b, w in zip(vdp, want))
    out['always_bump_equals_current'] = run_one(name, 'always_bump')[1] == run_one(name, 'current')[1]
    l0_bad = sum(b != w for b, w in zip(vb, want))
    tree_extra = exact_extra = l1_bad = 0
    for a, e, w in zip(vt, ve, want):
        if w['status'] == 'certified':
            l1_bad += (a != w) + (e != w)
            continue
        if a['status'] == 'certified':
            tree_extra += 1
            l1_bad += not (e['status'] == 'certified' and e['unit'] == a['unit'])
        if e['status'] == 'certified':
            exact_extra += 1
        if a['status'] != 'certified' and a != w:
            l1_bad += 1
    # later-agreement check (same context, same target)
    case = copy.deepcopy(tr['initial']); key = RH._ctx_key(case)
    early = {}; later_agree = later_conflict = 0; k = 0; nonrefine = 0
    for ev in tr['events']:
        if ev['op'] == 'request':
            t = ev['target']; e = ve[k]; w = want[k]; k += 1
            if w['status'] == 'certified' and (key, t) in early:
                if early[(key, t)] == w['unit']: later_agree += 1
                else: later_conflict += 1
            if w['status'] != 'certified' and e['status'] == 'certified':
                early[(key, t)] = e['unit']
        elif ev['op'] in ('analysis', 'header', 'edge', 'identity', 'snapshot'):
            before = copy.deepcopy(case)
            case = apply_event(case, ev, inplace=True); key = RH._ctx_key(case)
            if not _pure_refinement(before, case):
                early.clear(); nonrefine += 1
        elif ev['op'] == 'batch':
            k += len(ev['targets'])
    return dict(out, scenario=name, requests=len(want), l0_mismatch=l0_bad, l1_mismatch=l1_bad, tree_extra=tree_extra,
                exact_extra=exact_extra, later_agree=later_agree, later_conflict=later_conflict,
                non_refinement_events=nonrefine)


def _pure_refinement(a, b):
    """True iff b only turns unknown facts of a into known ones (same context,
    no known fact changed): the only case in which an earlier Omega(K)
    certificate must agree with later certificates."""
    if RH._ctx_key(a) != RH._ctx_key(b):
        return False
    for x, y in zip(a['items'], b['items']):
        if x == y:
            continue
        ax, ay = x.get('analysis', {}), y.get('analysis', {})
        if ax.get('status') == 'computed' or x.get('header') != y.get('header'):
            return False
        if ay.get('status') == 'computed' and x.get('header') and \
                ay['fact'].get('state') != x['header'].get('state'):
            return False            # alpha header authority violated by the trace
    ea = {(e['first'], e['second']): e for e in a.get('edges', [])}
    eb = {(e['first'], e['second']): e for e in b.get('edges', [])}
    for k2, e in ea.items():
        if e.get('status') == 'computed' and eb.get(k2) != e:
            return False
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--processes', type=int, default=1)
    ap.add_argument('--reps', type=int, default=3)
    ap.add_argument('--warmup', type=int, default=1)
    ap.add_argument('--out')
    ap.add_argument('--child', action='store_true')
    ap.add_argument('--verify', action='store_true')
    args = ap.parse_args()
    if args.verify:
        rows = [verify(s) for s in SCEN]
        for r in rows: print(json.dumps(r))
        if args.out:
            Path(args.out).write_text(json.dumps(rows, indent=1))
        return
    if args.processes > 1 and not args.child:
        with open(args.out, 'w') as fh:
            for proc in range(args.processes):
                cmd = [sys.executable, str(HERE), '--child', '--reps', str(args.reps), '--warmup', str(args.warmup)]
                res = subprocess.run(cmd, capture_output=True, text=True, check=True)
                for line in res.stdout.splitlines():
                    row = json.loads(line); row['process_index'] = proc; fh.write(json.dumps(row) + '\n')
        return
    pid = os.getpid(); utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    order = CANDIDATES[:]
    for name in SCEN:
        for rep in range(args.warmup + args.reps):
            order = order[1:] + order[:1]
            for cand in order:
                row, _ = run_one(name, cand, rep, alloc=(rep == args.warmup))
                row.update(pid=pid, utc=utc, warmup=rep < args.warmup)
                print(json.dumps(row), flush=True)


if __name__ == '__main__':
    main()
