"""X2/X6/X9/X10 combination checks and NH-1..NH-7 new hypotheses -> results/combos_new.json."""
import copy, json, random, sys, time, statistics, collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import *
import transducer as T, omega as O, relational_exp as X, theory_a as A, acqsim as S, incremental as I, generative as G
from current_baseline import Host, Config, typed

out = {}; t0 = time.time()
# ---------------- X2: joint targets x shared witness (simulated)
rows = []
for joint in (1, 3):
    for work in ('fact', 'witness'):
        tot = collections.Counter()
        for seed in range(12):
            r = S.run(seed, n=24, count=24, pattern='sweep', certifier='ref', work=work, batch=joint, R=4)
            tot.update({k: v for k, v in r.items() if isinstance(v, int)})
        rows.append(dict(joint=joint, work=work, **dict(tot)))
for joint in (1, 3):                                        # conflict probe: random jumps, tiny residency
    for work in ('fact', 'witness'):
        tot = collections.Counter()
        for seed in range(12):
            r = S.run(seed, n=24, count=24, pattern='jump', certifier='ref', work=work, batch=joint, R=2)
            tot.update({k: v for k, v in r.items() if isinstance(v, int)})
        rows.append(dict(joint=joint, work=work, pattern='jump', R=2, **dict(tot)))
out['X2_joint_x_witness'] = rows
# ---------------- X6: minimal support x relational abstraction
rng = random.Random(61); rows = []
for k in range(60):
    n = rng.randrange(10, 18)
    c = roundtrip(random_case(rng, n, p_unknown=0.15, p_edge_unknown=0.15, settings_mix=False))
    t = rng.randrange(n // 2, n)
    if O.certify_exact(c, t)[0] != 'certified' or T.certify_tree(c, t)[0] != 'certified':
        continue
    t1 = time.perf_counter_ns(); ms = X.minimal_support(c, t); tsup = time.perf_counter_ns() - t1
    t1 = time.perf_counter_ns(); T.certify_tree(c, t); ttree = time.perf_counter_ns() - t1
    support = {h[1] if h[0] == 'pos' else h[1] for h in ms['support']}
    # survival under random single-fact changes elsewhere
    surv_min = surv_tree = trials = 0
    for _ in range(30):
        p = rng.randrange(n)
        trials += 1
        touched = {('pos', p)}
        if not (touched & set(ms['support'])): surv_min += 1
        if p > t + 3: surv_tree += 1                       # tree certificate depends on leaves 0..t+3
    rows.append(dict(n=n, target=t, min_support=len(ms['support']), support_ms=round(tsup / 1e6, 1),
                     tree_query_ms=round(ttree / 1e6, 2), survive_min=surv_min / trials, survive_tree=surv_tree / trials))
out['X6_support_x_relational'] = dict(rows=rows, summary=dict(
    cases=len(rows), median_support_ms=statistics.median(r['support_ms'] for r in rows),
    median_tree_ms=statistics.median(r['tree_query_ms'] for r in rows),
    mean_survive_min=round(statistics.mean(r['survive_min'] for r in rows), 3),
    mean_survive_tree=round(statistics.mean(r['survive_tree'] for r in rows), 3)))
# ---------------- X9: progressive features x pipeline batches (synthetic units u)
def x9(policy, edges, C=2):
    """edges: list of element counts needed (50 full precision, k for early-null).
    Each element costs 1u; batch barrier = all items of a batch finish before next batch."""
    work = sum(e if 'prog' in policy else 50 for e in edges)
    if 'pipe' in policy:                                   # per-item admission onto C workers
        slots = [0] * C; done = []
        for e in edges:
            d = e if 'prog' in policy else 50
            j = min(range(C), key=lambda q: slots[q]); slots[j] += d; done.append(slots[j])
        return work, max(slots), statistics.mean(done)
    t = 0; done = []                                      # batches of C with a barrier
    for b in range(0, len(edges), C):
        ds = [(e if 'prog' in policy else 50) for e in edges[b:b + C]]
        for d in ds: done.append(t + d)
        t += max(ds)
    return work, t, statistics.mean(done)
rng = random.Random(62); rows = []
for frac_null in (0.0, 0.3, 0.7):
    edges = [rng.choice((9, 13, 17, 27)) if rng.random() < frac_null else 50 for _ in range(40)]
    for pol in ('single', 'prog', 'pipe', 'prog+pipe'):
        w, mk, mean_done = x9(pol, edges)
        rows.append(dict(null_fraction=frac_null, policy=pol, element_work_u=w, makespan_u=mk, mean_ready_u=round(mean_done, 1)))
out['X9_progressive_x_pipeline'] = dict(rows=rows, note='early-null element counts from results/generative.json E5_early_null medians (m=3000..9000)')
# ---------------- X10: constraint domain x generative correlations
c = base_case(5, automatic=True)
c['edges'][1]['score'] = 0                                 # known rank 0 at edge (1,2)
c['edges'] = [e for e in c['edges'] if e['first'] != 2]   # edge (2,3) unknown
res = {d: T.certify_tree(c, 4, d)[0] for d in ('ext', 'nonneg', 'G0')}
bad = copy.deepcopy(c); bad['edges'].append(dict(first=3, second=4, status='computed', score=-1, version=1))
F = T.Facts(bad, 'omega', 'nonneg')
out['X10_domain'] = dict(case=c, target=4, verdict_by_domain=res, oracle_units_ext=len(O.oracle_units(c, 4, 'ext')),
    oracle_units_G0=len(O.oracle_units(c, 4, 'G0')),
    illegal_domain_detected=not F.domain_ok,
    note='with a known 0 the unknown neighbour cannot be strictly smaller in nonneg/G0, so the target is decided; '
         'a negative known rank makes the nonneg domain illegal and the host must fall back to ext')
# ---------------- NH-1: hidden alpha (header authority) precondition
rng = random.Random(71); st = collections.Counter()
for k in range(400):
    n = rng.randrange(2, 6)
    cc = roundtrip(random_case(rng, n, p_unknown=0.4, p_edge_unknown=0.3))
    t = rng.randrange(n)
    r = ref.certify(cc, t)
    try:
        Ub = O.oracle_units(cc, t, alpha=False, cap=30000)
    except OverflowError:
        continue
    st['cases'] += 1
    if r['status'] == 'certified':
        st['ref_certified'] += 1
        st['ref_unsound_beta'] += (len(Ub) != 1)
    st['tree_alpha'] += T.certify_tree(cc, t, 'ext', True)[0] == 'certified'
    tb = T.certify_tree(cc, t, 'ext', False)
    st['tree_beta'] += tb[0] == 'certified'
    if tb[0] == 'certified': st['tree_beta_unsound'] += (len(Ub) != 1)
out['NH1_header_authority'] = dict(st)
# ---------------- NH-2: unconditional revision bump vs no-op detection
import bench_hosts as BH
from host_driver import replay, make
noop = total = 0
for name in ('s64_neighbor_irrelevant_r4', 's64_jump_churn', 's256_neighbor_irrelevant_r4', 's512_jump_relevant'):
    tr = json.loads(BH.trace_path(name).read_text())
    case = copy.deepcopy(tr['initial'])
    from host_traces import apply_event
    for ev in tr['events']:
        if ev['op'] in ('analysis', 'header', 'edge', 'identity', 'snapshot'):
            before = typed(case); case = apply_event(case, ev, inplace=True); total += 1
            noop += typed(case) == before
class AlwaysBump(Host):
    def replace(self, case):
        if self._closed:
            raise ValueError('closed host requires rebind')
        next_case = copy.deepcopy(case); data = ref._Input(next_case)
        identity, settings = typed(data.identity), typed(data.settings)
        self._revision = min(self._revision + 1, (1 << 63) - 1); self.metrics['evidence_updates'] += 1
        if getattr(self, '_identity', None) != identity:
            self._structure = None
        self._case, self._identity, self._settings = next_case, identity, settings
        self.metrics['update_calls'] += 1; self.metrics['update_item_slots'] += len(next_case['items'])
rows = []
for name in ('s64_neighbor_irrelevant_r4', 's64_jump_churn', 's256_neighbor_irrelevant_r4', 's512_jump_relevant'):
    tr = json.loads(BH.trace_path(name).read_text())
    meta = json.loads((BH.TRACE_DIR / 'meta.json').read_text())[name]
    res = {}
    for label, fac in (('current', lambda c: Host(c, config=Config.current())), ('always_bump', lambda c: AlwaysBump(c, config=Config.current()))):
        t1 = time.perf_counter_ns(); v, h = replay(tr, fac, False); w = time.perf_counter_ns() - t1
        res[label] = dict(wall_ms=round(w / 1e6, 1), verdict_sha=digest(v), stamp_hits=h.metrics.get('stamp_hits', 0),
                          read_validations=h.metrics.get('read_validations', 0))
    res['same_verdicts'] = res['current']['verdict_sha'] == res['always_bump']['verdict_sha']
    rows.append(dict(scenario=name, **res))
out['NH2_unconditional_bump'] = dict(noop_updates=noop, total_updates=total, rows=rows,
    note='single-process trial; the frozen host itself has the C5 support defect, so verdicts are compared host-to-host')
# ---------------- NH-4: certification lookback vs distance to the last reset boundary
rng = random.Random(73); pairs = []
for k in range(800):
    n = rng.randrange(8, 40)
    cc = roundtrip(random_case(rng, n, p_wide=0.08, settings_mix=False))
    t = rng.randrange(2, n)
    r = ref.certify(cc, t)
    if r['status'] != 'certified': continue
    data = ref._Input(cc)
    dim = lambda i: data.effective(i); side = lambda i: (dim(i) or {}).get('side', 'UNKNOWN')
    rank = lambda a, b: (lambda e: e.get('score') if e['status'] == 'computed' else None)(data.edge(a, b))
    sc = ref._Scan(n, data.settings, dim, side, side, rank)
    reset = max([i + 1 for i in range(0, t) if not sc.allowed(i)] or [0])
    pairs.append((t - r['first'], t - reset))
agree = sum(1 for a, b in pairs if a <= max(2, b))
out['NH4_reset_locality'] = dict(cases=len(pairs), lookback_le_reset_distance_or_2=agree,
    median_lookback=statistics.median(a for a, b in pairs), median_reset_distance=statistics.median(b for a, b in pairs),
    max_lookback=max(a for a, b in pairs))
# ---------------- NH-5: 5-state transducer (L-M2) speed-up for tree maintenance
class Tree5(I.TreePlan):
    pass
def bench_tree(cls, n=512, updates=300, seed=3):
    rng = random.Random(seed)
    cc = roundtrip(random_case(rng, n, domain='G0', settings_mix=False))
    tp = cls(cc); t1 = time.perf_counter_ns()
    for u in range(updates):
        p = rng.randrange(n); item = copy.deepcopy(cc['items'][p])
        item['analysis'] = dict(status='computed', fact=fact(rng.choice(('NARROW', 'WIDE')), rng.choice(SIDES)), version=u + 2)
        tp.set_item(p, item); tp.unit(rng.randrange(n))
    return (time.perf_counter_ns() - t1) / 1e6
orig_compose, orig_apply, orig_N = T.compose, T.apply, T.NSTATE
ten = bench_tree(I.TreePlan)
def compose5(f, g):
    out_ = []
    for s in range(T.NSTATE):
        if s % 2:                       # m=1 states are unreachable at-states (L-M2): skip
            out_.append(0); continue
        mask, acc = f[s], 0
        while mask:
            low = mask & -mask; acc |= g[low.bit_length() - 1]; mask ^= low
        out_.append(acc)
    return tuple(out_)
T.compose = compose5
try:
    five = bench_tree(I.TreePlan)
    rngc = random.Random(4); ok = True
    for k in range(200):
        cc = roundtrip(random_case(rngc, rngc.randrange(1, 20)))
        tp = I.TreePlan(cc)
        want = ref.complete_plan(cc)
        ok &= all(tp.unit(t) == unit_of(want, t) for t in range(len(cc['items'])))
finally:
    T.compose = orig_compose
out['NH5_state_merge'] = dict(ten_state_ms=round(ten, 1), five_state_compose_ms=round(five, 1), still_exact=ok,
    note='m=1 rows dropped from compositions; exactness re-checked; skip-state rows (m carried) keep m=0/1 via leaf outputs')
# ---------------- NH-6: int-vs-double interface divergence frequency
rng = random.Random(76); diff = tot = 0
for k in range(3000):
    n = rng.randrange(3, 12); cc = base_case(n, automatic=True)
    for e in cc['edges']:
        e['score'] = rng.choice((2 ** 53, 2 ** 53 + 1, 2 ** 53 + 2, float(2 ** 53), 10 ** 17, 10 ** 17 + 1, 1e17))
    cc = roundtrip(cc); tot += 1
    diff += ref.complete_plan(cc) != ref.complete_plan(A.as_double_interface(cc))
out['NH6_int_double'] = dict(cases=tot, plans_differ=diff,
    note='large-integer ranks are legal JSON but a double-only runtime reads a different input; canonicalise at ingestion '
         '(contract decision) or reject; affects H1 cross-runtime determinism, not Python-internal determinism')
# ---------------- NH-7: plan-diff locality distribution after one fact change
rng = random.Random(77); lens = collections.Counter(); chainlens = collections.Counter()
for k in range(1500):
    n = 64
    cc = roundtrip(random_case(rng, n, domain='G0', settings_mix=False))
    p = rng.randrange(n); d = copy.deepcopy(cc)
    st = d['items'][p]['analysis']['fact']['state']
    d['items'][p]['analysis']['fact'] = fact('WIDE' if st == 'NARROW' else 'NARROW', 'UNKNOWN'); d['items'][p]['header'] = fact(d['items'][p]['analysis']['fact']['state'])
    a, b = ref.complete_plan(cc), ref.complete_plan(d)
    ma, mb = {}, {}
    for u, m in ((a, ma), (b, mb)):
        for x in u:
            it = tuple(s['item'] for s in x['slots'])
            for y in it: m[y] = it
    ch = [i for i in range(n) if ma[i] != mb[i]]
    span = (max(ch) - p) if ch else 0
    lens[min(span, 40) // 4 * 4] += 1
out['NH7_diff_locality'] = dict(random_n64_span_hist={str(k): v for k, v in sorted(lens.items())},
    note='span = farthest changed position to the right of the edited item, bucketed by 4 (40 = >=40)')
out['seconds'] = round(time.time() - t0, 1)
Path(__file__).resolve().parents[1].joinpath('results', 'combos_new.json').write_text(json.dumps(out, indent=1, default=str))
print(json.dumps({k: v for k, v in out.items() if k not in ('X6_support_x_relational',)}, indent=1, default=str)[:7000])
print(out['X6_support_x_relational']['summary'])
