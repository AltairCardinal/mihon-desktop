"""Protocol family tests (synthetic layer).  Each test can fail on a meaningful defect."""
import random
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))
sys.path.insert(0, str(HERE.parents[1]))

import protocol  # noqa: E402  frozen
import protocol2 as P  # noqa: E402
import proto_check as C  # noqa: E402
import proto_sim as S  # noqa: E402
import proto_identity as ID  # noqa: E402
import proto_publication as PUB  # noqa: E402


def random_trace(rng):
    ev, v = [], 0
    for _ in range(rng.randrange(1, 14)):
        op = rng.choice(['request', 'request', 'cancel', 'finish', 'consume', 'version', 'publish'])
        e = dict(op=op)
        if op == 'version':
            e['version'] = rng.choice([v - 1, v, v + 1])
            v = max(v, e['version'])
        elif op == 'publish':
            t = rng.randrange(4)
            e.update(target=t, unit={'slots': rng.choice([[t], [t, t + 1], [t - 1, t] if t else [t], [t + 2]])})
            if rng.random() < .2:
                e['version'] = rng.choice([v - 1, v])
        else:
            e['key'] = rng.choice('ab')
            if op == 'request':
                e['required'] = rng.random() < .5
            if rng.random() < .2:
                e['version'] = rng.choice([v - 1, v, v + 1])
        ev.append(e)
    return dict(capacity=rng.choice([1, 2, 3]), events=ev)


class CompatDifferential(unittest.TestCase):
    def test_compat_mode_equals_frozen_protocol(self):
        rng = random.Random(5)
        for _ in range(3000):
            tr = random_trace(rng)
            self.assertEqual(protocol.run_event_trace(tr), P.run_trace(tr, compat=True))

    def test_frozen_regressions_hold_in_extended_mode(self):
        # completed-unconsumed keeps capacity; cancel does not release a running instance
        p = P.Proto(capacity=1)
        self.assertEqual(p.step(dict(op='request', key='a'))['outcome'], 'admitted')
        self.assertEqual(p.step(dict(op='finish', key='a'))['outcome'], 'completed')
        self.assertEqual(p.step(dict(op='exit', key='a'))['outcome'], 'exited')
        self.assertEqual(p.step(dict(op='request', key='b'))['outcome'], 'full')
        self.assertEqual(p.step(dict(op='consume', key='a'))['outcome'], 'consumed')
        self.assertEqual(p.step(dict(op='request', key='b'))['outcome'], 'admitted')
        p = P.Proto(capacity=1)
        p.step(dict(op='request', key='a'))
        self.assertEqual(p.step(dict(op='cancel', key='a'))['outcome'], 'cancelling')
        self.assertEqual(p.step(dict(op='request', key='b'))['outcome'], 'full')

    def test_finish_is_not_exit(self):
        p = P.Proto(capacity=1)
        p.step(dict(op='request', key='a'))
        p.step(dict(op='cancel', key='a'))
        self.assertEqual(p.step(dict(op='finish', key='a'))['outcome'], 'discarded')
        self.assertEqual(p.occupied(), 1)          # worker has not exited yet
        p.step(dict(op='exit', key='a'))
        self.assertEqual(p.occupied(), 0)


class ConsumersAndRevive(unittest.TestCase):
    def test_per_consumer_cancel_and_revive(self):
        p = P.Proto(capacity=1)
        p.step(dict(op='request', key='a', consumer='c1'))
        self.assertEqual(p.step(dict(op='request', key='a', consumer='c2', required=True))['outcome'], 'reused')
        self.assertEqual(p.step(dict(op='cancel', key='a', consumer='c1'))['outcome'], 'detached')
        self.assertEqual(p.step(dict(op='cancel', key='a', consumer='c2'))['outcome'], 'cancelling')
        self.assertEqual(p.step(dict(op='request', key='a', consumer='c3'))['outcome'], 'revived')
        self.assertEqual(p.counters['starts'], 1)
        q = P.Proto(capacity=1, mutants=('no_revive',))
        q.step(dict(op='request', key='a'))
        q.step(dict(op='cancel', key='a'))
        self.assertEqual(q.step(dict(op='request', key='a'))['outcome'], 'cancelling')


class Checker(unittest.TestCase):
    def test_unmutated_model_is_clean_in_bounded_space(self):
        r = C.search(1, depth=5, cap=100000)
        self.assertIsNone(r['violation'])
        self.assertTrue(r['complete'])

    def test_every_safety_mutant_is_killed(self):
        expect = {
            'accept_stale': 'H5', 'cancel_releases': 'H7', 'finish_releases': 'H7', 'dup_on_promote': 'H6',
            'cancel_kills_all': 'D5', 'publish_confirms': 'H9', 'stale_cert': 'H1/H5', 'barrier': 'H8'}
        for m, tag in expect.items():
            cap = 2 if m in ('barrier', 'dup_on_promote') else 1
            r = C.search(cap, mutants=(m,), depth=6, cap=100000)
            self.assertIsNotNone(r['violation'], m)
            self.assertTrue(r['violation'].startswith(tag), (m, r['violation']))
            self.assertIsNone(C.replay(r['trace'], cap, mutants=()), m)   # fixed model passes the same trace

    def test_epoch_precondition_violation_vs_ticket(self):
        r = C.search(1, mode='epoch', depth=5)
        self.assertTrue(r['violation'].startswith('H5'))
        self.assertIsNone(C.search(1, mode='epoch', relabel=False, depth=5)['violation'])
        self.assertIsNone(C.replay(r['trace'], 1, mode='ticket'))

    def test_guards_only_matter_for_unsound_certificates(self):
        self.assertIsNone(C.search(1, certifier=C.eager_certifier, depth=6, check_truth=False)['violation'])
        r = C.search(1, certifier=C.eager_certifier, mutants=('publish_same_target_only',), depth=7,
                     check_truth=False)
        self.assertTrue(r['violation'].startswith('H2 cross'))
        self.assertTrue(C.search(1, certifier=C.eager_certifier, depth=6)['violation'].startswith('H1'))
        self.assertTrue(C.search(1, certifier=C.local_start_certifier, depth=6)['violation'].startswith('H1'))


class Identity(unittest.TestCase):
    def test_identity_scenarios(self):
        res = {(s, m): ID.run_scenario(s, kw) for s in ID.SCENARIOS for m, kw in ID.MODES.items()}
        self.assertFalse(res[('relabel', 'epoch')]['safe'])
        self.assertTrue(res[('relabel', 'ticket_unbounded')]['safe'])
        self.assertFalse(res[('wrap3', 'ticket_1bit_wrap')]['safe'])
        self.assertTrue(res[('wrap3', 'ticket_1bit_saturate')]['safe'])
        self.assertFalse(res[('relabel', 'content_lossy_hash')]['safe'])
        self.assertTrue(res[('aba_inflight', 'content_exact')]['accepted'])     # value identity reuses work
        self.assertTrue(res[('aba_inflight', 'content_exact')]['safe'])
        self.assertFalse(res[('aba_inflight', 'ticket_unbounded')]['accepted'])
        conf_t = ID.confirmation_after_aba(ID.MODES['ticket_unbounded'])
        conf_c = ID.confirmation_after_aba(ID.MODES['content_exact'])
        self.assertEqual(conf_t['current_confirmations'], 0)
        self.assertEqual(conf_c['current_confirmations'], 1)                    # X8 conflict

    def test_tuple_identity_conflates_numeric_types(self):
        from common import base_case
        a, b = base_case(2), base_case(2)
        b['items'][0]['content_version'] = 0.0
        self.assertEqual(ID.identity_tuple(a), ID.identity_tuple(b))


class Publication(unittest.TestCase):
    def test_n11_and_member_lemma(self):
        g = PUB.g5_guards(200, quick=True)
        self.assertEqual(g['scan_vs_owner_mismatch'], 0)
        self.assertTrue(g['n11_overlap_only']['disjoint_same_target_replacement_accepted'])
        self.assertFalse(g['n11_member_plus_overlap']['replacement_accepted'])
        self.assertFalse(g['staged_commit']['commit_after_new_incarnation'])

    def test_alpha_composition_and_beta_failure(self):
        r = PUB.a6_composition(25, seed=1)
        self.assertEqual(r['pairwise_violations'], 0)
        self.assertEqual(r['unsound_alpha'], 0)
        self.assertGreater(r['unsound_beta'], 0)
        self.assertGreater(r['mutant_pairwise_violations'], 0)
        ref_ = PUB.a6_refinement(10, seed=2)
        self.assertEqual(ref_['conflicts'], 0)
        self.assertEqual(ref_['wrong_vs_final'], 0)

    def test_radius_revocation_counterexample(self):
        e = PUB.x7_explicit(32)
        self.assertGreaterEqual(e['farthest_changed'], 28)

    def test_x12_groups(self):
        r = PUB.x12()
        self.assertTrue(r['AB_cert_per_completion']['progress_publish_target0_without_b'])
        self.assertFalse(r['AB_cert_per_completion']['wrong_publication_reachable'])
        self.assertFalse(r['A_cert_barrier']['progress_publish_target0_without_b'])
        self.assertTrue(r['B_nocert_per_completion']['wrong_publication_reachable'])
        self.assertFalse(r['AB_coarse_certificate']['progress_publish_target0_without_b'])


class Simulator(unittest.TestCase):
    def test_no_unconditional_bound_and_reserve(self):
        lat = []
        for s_opt in (10, 100, 1000):
            w = dict(capacity=1, base=1.0, requests=[(0.0, 0), (2.5, 10)], service={'2': float(s_opt)})
            a = S.simulate(w, dict(admission='priority', prefetch=1, cancel='all'))
            b = S.simulate(w, dict(admission='priority', prefetch=1, reserve=1))
            lat.append(a['max'])
            self.assertEqual(b['max'], 2.0)
            self.assertGreater(a['cancel_occupancy_u'], s_opt - 2)   # cancel does not free the slot
        self.assertTrue(lat[0] < lat[1] < lat[2])

    def test_strict_priority_starves_at_saturation_aging_does_not(self):
        out = {}
        for H in (100, 400):
            gap = 2.0
            reqs = [(i * gap, 2 * i) for i in range(int(H / gap))]
            w = dict(capacity=1, base=1.0, requests=reqs, background=[(0.5, 10_000)])
            out[H] = (S.simulate(w, dict(admission='priority'))['optional_wait_max'],
                      S.simulate(w, dict(admission='aging', aging=20.0))['optional_wait_max'])
        self.assertGreater(out[400][0], 3 * out[100][0] * 0.9)
        self.assertEqual(out[100][1], out[400][1])

    def test_revive_saves_a_start(self):
        w = dict(capacity=3, base=10.0, requests=[(0.0, 0), (1.0, 20), (3.0, 1)])
        r = {n: S.simulate(w, dict(admission='priority', prefetch=1, cancel='all', revive=n))
             for n in ('revive', 'restart', 'duplicate')}
        self.assertLess(r['revive']['starts'], r['restart']['starts'])
        self.assertEqual(r['duplicate']['duplicates'], 1)
        self.assertLess(r['revive']['p95'], r['restart']['p95'])

    def test_barrier_delays_first_result(self):
        acq = [1.0] * 8
        acq[1] = 100.0
        b = S.pipeline(acq, [1.0] * 8, 0.5, 'barrier', k=4)
        d = S.pipeline(acq, [1.0] * 8, 0.5, 'dynamic', k=4)
        self.assertGreater(b['first'], 100)
        self.assertLess(d['first'], 3)
        self.assertEqual(b['work'], d['work'])

    def test_failure_keyed_by_identity_not_rng_order(self):
        order1 = list(range(40))
        order2 = list(reversed(order1))
        k1 = S.failure_assignment(order1, 7, keyed=True)
        k2 = S.failure_assignment(order2, 7, keyed=True)
        self.assertEqual(k1, k2)
        u1 = S.failure_assignment(order1, 7, keyed=False)
        u2 = S.failure_assignment(order2, 7, keyed=False)
        self.assertNotEqual(u1, u2)


if __name__ == '__main__':
    unittest.main()
