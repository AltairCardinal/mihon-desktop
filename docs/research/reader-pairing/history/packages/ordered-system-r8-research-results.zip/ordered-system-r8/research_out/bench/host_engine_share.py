"""B4 route B / B5 upper bound: share of host wall time spent inside compact_core.certify
(the only work a step-level / cross-target scan cache could remove). Local measurement, 1 process."""
import json, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))
import common  # noqa
import compact_core as core
import hosts
from host_driver import replay, make

TR = HERE.parent / 'fixtures' / 'host_traces' / 'bench'
acc = {'ns': 0, 'calls': 0, 'steps': 0}
orig = core.certify


def timed(*a, **k):
    t = time.perf_counter_ns()
    r = orig(*a, **k)
    acc['ns'] += time.perf_counter_ns() - t
    acc['calls'] += 1
    acc['steps'] += r['steps']
    return r


hosts.core.certify = timed
out = []
for name in ('s16_neighbor_relevant', 's64_neighbor_irrelevant_r4', 's64_ws5_quiet', 's256_roundtrip_growth',
             's64_batch_neighbor_relevant', 'c6_rare_expensive'):
    tr = json.loads((TR / f'{name}.json').read_text())
    for cand in ('x_fix_stamp', 'x_delta_stamp'):
        f, d = make(cand)
        acc.update(ns=0, calls=0, steps=0)
        t = time.perf_counter_ns(); replay(tr, f, d); wall = time.perf_counter_ns() - t
        out.append(dict(scenario=name, candidate=cand, wall_ns=wall, engine_ns=acc['ns'], engine_calls=acc['calls'],
                        steps=acc['steps'], engine_share=acc['ns'] / wall))
        print(f"{name:30s} {cand:14s} wall={wall/1e6:8.1f}ms engine={acc['ns']/1e6:7.1f}ms share={acc['ns']/wall:.2f} calls={acc['calls']} steps={acc['steps']}")
(HERE.parent / 'results' / 'hosts' / 'engine_share.json').write_text(json.dumps(out, indent=1))
