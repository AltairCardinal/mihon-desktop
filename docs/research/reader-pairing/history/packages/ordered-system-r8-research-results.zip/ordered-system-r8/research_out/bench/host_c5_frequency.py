"""How often does the frozen Host's selected-only support return a stale verdict on generated traces?
(counts only; python3 research_out/bench/host_c5_frequency.py SEEDS)"""
import json, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))
import common  # noqa
from host_traces import generate, PATTERNS, MIXES
from host_driver import replay, make, truth
seeds = int(sys.argv[1]) if len(sys.argv) > 1 else 6
res = dict(traces=0, requests=0, stale_current=0, stale_traces=0, stale_fix=0, by_mix={})
for seed in range(seeds):
    for pat in PATTERNS:
        for mix in MIXES:
            tr = generate(100 + seed, 16, 40, pat, mix)
            want = truth(tr)
            got, _ = replay(tr, make('current')[0])
            fix, _ = replay(tr, make('x_fix_stamp')[0])
            bad = sum(a != b for a, b in zip(got, want))
            res['traces'] += 1; res['requests'] += len(want); res['stale_current'] += bad
            res['stale_traces'] += bad > 0; res['stale_fix'] += sum(a != b for a, b in zip(fix, want))
            res['by_mix'][mix] = res['by_mix'].get(mix, 0) + bad
print(res)
(HERE.parent / 'results' / 'hosts' / 'c5_frequency.json').write_text(json.dumps(res, indent=1))
