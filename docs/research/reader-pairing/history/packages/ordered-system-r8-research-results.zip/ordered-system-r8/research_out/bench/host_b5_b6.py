"""B5 (pair-sharing potential, L1) and B6 (background preparation economics) counters.
Counts only (no timing claims); python3 research_out/bench/host_b5_b6.py"""
import json, sys
from copy import deepcopy
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidates'))
import common  # noqa
import reference as Ref
from host_driver import replay, make
from host_traces import generate, apply_event

TR = HERE.parent / 'fixtures' / 'host_traces' / 'bench'
out = {}
# B6: preparation economics on the idle scenario and two more idle traces
rows = []
for name, tr in (('s64_idle_neighbor_growth', json.loads((TR / 's64_idle_neighbor_growth.json').read_text())),
                 ('s64_idle_jump_quiet', generate(17, 64, 60, 'jump', 'quiet', idle_budget=2)),
                 ('s64_idle_roundtrip_quiet', generate(17, 64, 60, 'roundtrip', 'quiet', idle_budget=2)),
                 ('s64_idle_neighbor_churn', generate(17, 64, 60, 'neighbor', 'churn', idle_budget=2))):
    for cand in ('x_fix_stamp', 'x_side2'):
        f, d = make(cand)
        _, h0 = replay(tr, f, d, prepare=False)
        _, h1 = replay(tr, f, d, prepare=True)
        m0, m1 = h0.metrics, h1.metrics
        fg0 = m0['engine_runs']; fg1 = m1['engine_runs'] - m1['prepared_runs']
        rows.append(dict(trace=name, candidate=cand, foreground_runs_without=fg0, foreground_runs_with=fg1,
                         prepared_runs=m1['prepared_runs'], prepared_hits=m1['prepared_hits'],
                         prepared_discarded=m1['prepared_discarded'], aborted=m1['prepare_aborted'],
                         total_runs_without=fg0, total_runs_with=m1['engine_runs']))
        print(rows[-1])
out['b6'] = rows
# B5: in batch traces, how many requested targets are the partner of a certified pair unit of an
# earlier target in the same batch (answerable by L1 pair sharing), and what public fields differ
tr = json.loads((TR / 's64_batch_neighbor_relevant.json').read_text())
case = deepcopy(tr['initial'])
tot = shareable = same_public = 0
fields = {}
for ev in tr['events']:
    if ev['op'] == 'batch':
        done = {}
        for t in ev['targets']:
            r = {k: v for k, v in Ref.certify_strategy(case, t)['selected'].items() if k != 'reads'}
            tot += 1
            hit = next((p for p in done.values() if p['status'] == 'certified'
                        and any(s['item'] == t for s in p['unit']['slots'])), None)
            if hit is not None:
                shareable += 1
                same_public += hit == r
                for k in r:
                    if hit[k] != r[k]:
                        fields[k] = fields.get(k, 0) + 1
            done[t] = r
    elif ev['op'] in ('analysis', 'header', 'edge', 'identity', 'snapshot'):
        case = apply_event(case, ev, inplace=True)
out['b5'] = dict(batch_requests=tot, shareable_by_pair_unit=shareable, identical_public_verdict=same_public,
                 differing_fields=fields)
print(out['b5'])
(HERE.parent / 'results' / 'hosts' / 'b5_b6_counts.json').write_text(json.dumps(out, indent=1))
