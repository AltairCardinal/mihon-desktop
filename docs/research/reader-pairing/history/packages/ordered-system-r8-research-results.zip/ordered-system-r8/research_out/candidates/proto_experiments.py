"""Runs every protocol-family experiment and writes raw JSON records.

python3 research_out/candidates/proto_experiments.py [--quick]
Outputs research_out/results/protocol/{checker,sim,identity,publication}.json
All clocks in the simulator are synthetic units `u`; microbench timings in
identity.json are local exploratory measurements (Python 3, this machine),
not a formal 3-process campaign.
"""
import argparse
import json
import os
import random
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
OUT = HERE.parent / 'results' / 'protocol'

import proto_check as C  # noqa: E402
import proto_sim as S  # noqa: E402
import proto_identity as ID  # noqa: E402
import proto_publication as PUB  # noqa: E402
from protocol2 import MUTANTS  # noqa: E402


def meta():
    return dict(pid=os.getpid(), utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                python=sys.version.split()[0], layer='protocol (synthetic)')


def short(trace):
    out = []
    for e in trace:
        d = {k: v for k, v in e.items() if k != 'op'}
        out.append(e['op'] + (json.dumps(d, sort_keys=True) if d else ''))
    return out


def checker(quick):
    rows = []
    d1, d2 = (6, 5) if quick else (7, 6)
    configs = [('base_ticket_cap1', dict(capacity=1, depth=d1)),
               ('base_ticket_cap2', dict(capacity=2, depth=d2)),
               ('epoch_honest_labels', dict(capacity=1, mode='epoch', relabel=False, depth=d1)),
               ('epoch_relabel_precondition_broken', dict(capacity=1, mode='epoch', depth=d1)),
               ('content_identity', dict(capacity=1, mode='content', depth=d1))]
    for m in MUTANTS:
        cap = 2 if m in ('barrier', 'dup_on_promote') else 1
        configs.append(('mutant_' + m, dict(capacity=cap, mutants=(m,), depth=d1)))
    configs += [('certifier_local_start', dict(capacity=1, certifier=C.local_start_certifier, depth=d1)),
                ('certifier_eager_guarded_stability_only', dict(capacity=1, certifier=C.eager_certifier,
                                                                 depth=d1, check_truth=False)),
                ('certifier_eager_guarded_truth', dict(capacity=1, certifier=C.eager_certifier, depth=d1)),
                ('certifier_eager_same_target_only', dict(capacity=1, certifier=C.eager_certifier, depth=d1,
                                                          mutants=('publish_same_target_only',),
                                                          check_truth=False)),
                ('certifier_eager_overlap_only', dict(capacity=1, certifier=C.eager_certifier, depth=d1,
                                                      mutants=('publish_overlap_only',), check_truth=False))]
    for name, kw in configs:
        t0 = time.perf_counter()
        r = C.search(cap=250000, **kw)
        rows.append(dict(config=name, kwargs={k: (v.__name__ if callable(v) else v) for k, v in kw.items()},
                         violation=r['violation'], trace=short(r.get('trace', [])),
                         length=len(r.get('trace', [])), states=r['states'], explored=r['explored'],
                         exhaustive_to_depth=r['complete'], seconds=round(time.perf_counter() - t0, 3)))
        print(name, r['violation'], len(r.get('trace', [])), r['states'], flush=True)
    return rows


def run_groups(work, groups):
    return {name: S.simulate(work, pol) for name, pol in groups}


def sim(quick):
    out = {}
    # X3 / G2 / D3: prefetch x nonpreemptible cancellation; four groups (+ only-useful-part)
    groups = [('baseline', dict(admission='priority')),
              ('A_prefetch2', dict(admission='priority', prefetch=2)),
              ('B_cancel_only', dict(admission='priority', cancel='all')),
              ('AB_prefetch2_cancel', dict(admission='priority', prefetch=2, cancel='all')),
              ('ABR_prefetch2_cancelqueued_reserve1', dict(admission='priority', prefetch=2, cancel='queued',
                                                           reserve=1)),
              ('AB_keep_cancelled_results', dict(admission='priority', prefetch=2, cancel='all',
                                                 admit_cancelled=True)),
              ('A_gated_service_le2', dict(admission='priority', prefetch=2, prefetch_max_service=2))]
    x3 = []
    kinds = ('forward', 'reversal', 'zigzag', 'jump')
    for kind in kinds:
        for Cap in (1, 2, 4):
            for slow_frac, slow in ((0.0, 1), (0.15, 10), (0.15, 100)):
                w = S.workload(kind, n_req=30 if quick else 60, gap=4.0, C=Cap, slow_frac=slow_frac, slow=slow)
                res = run_groups(w, groups)
                x3.append(dict(workload=kind, C=Cap, slow_frac=slow_frac, slow=slow, gap=4.0, results=res))
    out['x3_prefetch_cancel'] = x3

    # no unconditional bound: C=1, one speculative task of service S right before a required request
    nob = []
    for Sopt in (1, 10, 100, 1000):
        w = dict(capacity=1, base=1.0, requests=[(0.0, 0), (2.5, 10)], service={'2': float(Sopt)})
        for name, pol in [('prefetch1', dict(admission='priority', prefetch=1)),
                          ('prefetch1_cancel_all', dict(admission='priority', prefetch=1, cancel='all')),
                          ('prefetch1_reserve1', dict(admission='priority', prefetch=1, reserve=1)),
                          ('prefetch1_gated_le10', dict(admission='priority', prefetch=1, prefetch_max_service=10)),
                          ('no_prefetch', dict(admission='priority'))]:
            r = S.simulate(w, pol)
            nob.append(dict(S_opt=Sopt, policy=name, second_request_latency=r['max'], busy_u=r['busy_u'],
                            cancel_occupancy_u=r['cancel_occupancy_u'], wasted_u=r['wasted_u']))
    out['no_unconditional_bound'] = nob

    # G3 fairness: required utilisation rho vs optional starvation
    fair = []
    for rho in (0.5, 0.9, 1.0, 1.25):
        gap = 2.0 / rho
        for H in (100, 400):
            n = int(H / gap)
            reqs = [(i * gap, 2 * i) for i in range(n)]
            bg = [(0.5 + j * 0.01, 10_000 + j) for j in range(5)]
            w = dict(capacity=1, base=1.0, requests=reqs, background=bg)
            for name, pol in [('fifo', dict(admission='per_completion')), ('strict_priority', dict(admission='priority')),
                              ('aging20', dict(admission='aging', aging=20.0))]:
                r = S.simulate(w, pol)
                fair.append(dict(rho=rho, horizon=H, policy=name, optional_wait_max=r['optional_wait_max'],
                                 required_p95=r['p95'], required_max=r['max'], completed=r['completed'],
                                 unfinished=r['unfinished'], starts=r['starts']))
    out['g3_fairness'] = fair

    # G4 progress under churn
    churn = []
    for scope in ('relevant', 'irrelevant'):
        for period in (2.0, 5.0):
            ups = [(1.0 + j * period, (0,) if scope == 'relevant' else (50,)) for j in range(int(30 / period))]
            w = dict(capacity=1, base=3.0, requests=[(0.0, 0)], updates=ups)
            for name, pol in [('fine', dict(churn='fine')), ('global', dict(churn='global')),
                              ('fine_debounce4', dict(churn='fine', debounce=4.0)),
                              ('global_debounce4', dict(churn='global', debounce=4.0))]:
                r = S.simulate(w, pol)
                churn.append(dict(update_scope=scope, period=period, last_update=ups[-1][0], service=3.0,
                                  policy=name, latency=r['max'], starts=r['starts'], wasted_u=r['wasted_u'],
                                  busy_u=r['busy_u'], completed=r['completed']))
    out['g4_churn'] = churn

    # D5 revive vs restart vs duplicate after cancel-then-return (designed: the speculative
    # instance for ident 2 is cancelled by a jump and needed again while still running)
    rev = []
    for Cap in (3, 4):
        for svc in (1.0, 10.0, 100.0):
            w = dict(capacity=Cap, base=svc, requests=[(0.0, 0), (0.1 * svc, 20), (0.3 * svc, 1)])
            for name in ('revive', 'restart', 'duplicate'):
                r = S.simulate(w, dict(admission='priority', prefetch=1, cancel='all', revive=name))
                rev.append(dict(C=Cap, service=svc, policy=name, p95=r['p95'], max=r['max'], starts=r['starts'],
                                busy_u=r['busy_u'], wasted_u=r['wasted_u'], duplicates=r['duplicates'],
                                cancel_occupancy_u=r['cancel_occupancy_u']))
    # the same three policies on the generic zigzag workload (no re-request of a cancelled
    # running instance happens there: expected no difference)
    for name in ('revive', 'restart', 'duplicate'):
        w = S.workload('zigzag', n_req=40, gap=4.0, C=2, slow_frac=0.15, slow=10)
        r = S.simulate(w, dict(admission='priority', prefetch=1, cancel='all', revive=name))
        rev.append(dict(C=2, service='zigzag_mix', policy=name, p95=r['p95'], max=r['max'], starts=r['starts'],
                        busy_u=r['busy_u'], wasted_u=r['wasted_u'], duplicates=r['duplicates'],
                        cancel_occupancy_u=r['cancel_occupancy_u']))
    out['d5_revive'] = rev

    # D4 batching / pipelining
    pipe = []
    for slow in (None, 100.0):
        acq = [1.0] * 8
        if slow:
            acq[1] = slow
        der = [1.0] * 8
        for setup in (0.5, 5.0):
            for name, kw in [('per_item', {}), ('barrier_k4', dict(k=4)), ('dynamic_k4', dict(k=4)),
                             ('dynamic_k4_tau3', dict(k=4, tau=3.0))]:
                pol = name.split('_k')[0]
                r = S.pipeline(acq, der, setup, pol, **kw)
                pipe.append(dict(slow_item=slow, setup=setup, policy=name, first=r['first'], all=r['all'],
                                 mean=r['mean'], work=r['work']))
    out['d4_pipeline'] = pipe
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--only', default='')
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    jobs = dict(checker=lambda: checker(a.quick), sim=lambda: sim(a.quick),
                identity=lambda: ID.experiments(a.quick), publication=lambda: PUB.experiments(a.quick))
    for name, fn in jobs.items():
        if a.only and a.only != name:
            continue
        t0 = time.perf_counter()
        data = fn()
        rec = dict(meta=meta(), quick=a.quick, seconds=round(time.perf_counter() - t0, 2), data=data)
        (OUT / f'{name}.json').write_text(json.dumps(rec, indent=1, allow_nan=False), encoding='utf-8')
        print('wrote', name, rec['seconds'], 's', flush=True)


if __name__ == '__main__':
    main()
