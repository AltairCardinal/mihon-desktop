"""Stage 0: bind package fingerprints, environment, frozen tests and smoke output."""
import hashlib, json, os, platform, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / 'results' / 'stage0.json'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    m = json.loads((ROOT / 'MANIFEST.json').read_text(encoding='utf-8'))
    files = m['files']
    entries = files.items() if isinstance(files, dict) else [(f['path'], f) for f in files]
    mismatch = []
    for path, meta in entries:
        want = meta['sha256'] if isinstance(meta, dict) else meta
        if sha(ROOT / path) != want:
            mismatch.append(path)
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    t0 = time.time()
    tests = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py'],
                           cwd=ROOT, env=env, capture_output=True, text=True)
    smoke = subprocess.run([sys.executable, 'benchmark.py', '--smoke'], cwd=ROOT, env=env,
                           capture_output=True, text=True)
    rec = dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), python=sys.version,
               platform=platform.platform(), cpu_count=os.cpu_count(),
               manifest_files=len(list(entries)), manifest_mismatch=mismatch,
               frozen_sources={p: sha(ROOT / p) for p in ('reference.py', 'compact_core.py', 'current_baseline.py',
                                                          'protocol.py', 'trace_generator.py', 'benchmark.py')},
               tests_rc=tests.returncode, tests_tail=tests.stderr.strip().splitlines()[-3:],
               smoke_rc=smoke.returncode,
               smoke=[dict(profile=r['profile'], verdict_sha256=r['verdict_sha256'], host_elapsed_ns=r['host_elapsed_ns'],
                           work=r['work']) for r in json.loads(smoke.stdout)['results']] if smoke.returncode == 0 else smoke.stderr,
               seconds=round(time.time() - t0, 2))
    OUT.write_text(json.dumps(rec, indent=1), encoding='utf-8')
    print(json.dumps({k: rec[k] for k in ('manifest_files', 'manifest_mismatch', 'tests_rc', 'tests_tail', 'smoke_rc')}))

if __name__ == '__main__':
    main()
