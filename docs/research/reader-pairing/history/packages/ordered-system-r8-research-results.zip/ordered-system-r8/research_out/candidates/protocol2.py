"""Extended synthetic protocol model (G1/G2/G5/D5/C3 family).  NOT a real scheduler.

Separates the events that protocol.py merges (N17):
    request      consumer attaches to a task identity (optional / required)
    cancel       ONE consumer detaches; cancel intent only when no consumer is left
    finish       physical instance produced its result (completion notice)
    exit         physical instance terminated (worker gone)
    consume      result admitted as a fact (knowledge); never a user confirmation
    certify      a certificate for the CURRENT full context (support keys must be admitted facts)
    publish      entitlement: needs a current certificate, same-target stability and
                 cross-target consistency (owner table, N10/N11)
    confirm      the only event that can add to the confirmation history (H9)
    replace      new full input content; identity source is selectable:
                   mode='ticket' owner-issued incarnation (the model increments it on every
                                 content change, caller labels are not trusted)
                   mode='epoch'  caller-supplied monotone label (protocol.py precondition;
                                 equal label => 'unchanged' even if content changed: N12)
A capacity slot is held from admission until the instance has exited AND its result is
resolved (consumed or discarded); a completed-but-unconsumed result keeps its slot (H7).

compat=True reproduces protocol.py outcome-for-outcome on the events protocol.py models
(request/cancel/finish/consume/version/publish; finish == finish+exit, cancel by token).

`mutants` injects named defects for the adversarial checker (see MUTANTS).
"""
from copy import deepcopy

MUTANTS = {
    'accept_stale': 'no incarnation guard at all: running work not marked stale, finish/consume skip the check',
    'cancel_releases': 'cancel intent frees the slot before the instance exits',
    'finish_releases': 'completion notice frees the slot although the result is unconsumed',
    'dup_on_promote': 'optional->required promotion starts a second instance',
    'cancel_kills_all': 'one consumer cancelling removes every consumer',
    'publish_overlap_only': 'publication checks cross-target overlap only (misses same-target disjoint replacement)',
    'publish_same_target_only': 'publication checks same target only (misses cross-target conflict)',
    'publish_confirms': 'publication is written into the confirmation history',
    'stale_cert': 'certificates survive a new incarnation and publication skips the incarnation check',
    'barrier': 'a ready result is admitted only when every live task is ready (batch barrier)',
    'no_revive': 're-request of a cancelling task is refused (protocol.py behaviour) - not a safety defect',
}


def members(unit):
    return tuple(sorted(s['item'] if isinstance(s, dict) else s for s in unit['slots']))


def _conflicts(a, b):
    return bool(set(members(a)) & set(members(b))) and a != b


class Task:
    __slots__ = ('inst', 'key', 'inc', 'consumers', 'cancel', 'exited', 'ready', 'resolved',
                 'freed_early', 'value')

    def __init__(self, inst, key, inc, consumer, required, value):
        self.inst, self.key, self.inc = inst, key, inc
        self.consumers = {consumer: required}
        self.cancel = False
        self.exited = False
        self.ready = False
        self.resolved = None          # None | 'consumed' | 'discarded'
        self.freed_early = False
        self.value = value            # content the instance computes on (environment truth)

    def occupies(self):
        if self.freed_early:
            return False
        return not (self.exited and self.resolved is not None)

    def live(self):
        return self.resolved is None or not self.exited

    def canon(self):
        return (self.inst, self.key, self.inc, tuple(sorted(self.consumers.items())), self.cancel,
                self.exited, self.ready, self.resolved, self.freed_early, self.value)


class Proto:
    def __init__(self, capacity=2, mode='ticket', compat=False, mutants=(), certifier=None,
                 content='X', label=0, inc_bits=None, inc_overflow='wrap', content_key=None,
                 require_cert=True):
        if capacity < 1:
            raise ValueError('capacity must be positive')
        if mode not in ('ticket', 'epoch', 'content'):
            raise ValueError('mode')
        # inc_bits: finite incarnation counter (C3 overflow study); 'wrap' reuses numbers (ABA),
        # 'saturate' falls back to exact content comparison once the counter is exhausted.
        self.inc_bits, self.inc_overflow = inc_bits, inc_overflow
        # content_key: identity derivation for mode='content' (default exact value; a lossy
        # hash here reproduces the 'hash equality is not identity' defect).
        self.content_key = content_key or (lambda c: c)
        # require_cert=False: publication of a client-supplied unit (protocol.py style), guards only
        self.require_cert = require_cert
        self.capacity, self.mode, self.compat = capacity, mode, compat
        self.mut = frozenset(mutants)
        unknown = self.mut - set(MUTANTS)
        if unknown:
            raise ValueError(f'unknown mutants {unknown}')
        if compat:
            self.mode = 'epoch'            # protocol.py identity = caller version number
        self.certifier = certifier
        self.content = content          # environment truth of the current input
        self.label = label              # caller label (epoch mode identity)
        self.inc = 0                    # owner-issued incarnation (ticket mode identity)
        self.tasks = []                 # instances, oldest first (resolved+exited are pruned)
        self.next_inst = 0
        self.knowledge = {}             # (ident, key) -> value
        self.certs = {}                 # target -> (ident, unit, support)
        self.published = {}             # target -> unit (current identity only)
        self.confirmed = []             # history of (ident, target, members)
        self.counters = dict(starts=0, reuse=0, revive=0, discard=0, consumed=0)

    # -- identity -----------------------------------------------------------
    def ident(self):
        if self.mode == 'epoch':
            return self.label
        if self.mode == 'content':
            return self.content_key(self.content)
        if self.inc_bits is not None and self.inc_overflow == 'saturate' and self.inc >= (1 << self.inc_bits) - 1:
            return ('saturated', self.content)
        return self.inc

    def _new_identity(self):
        for t in self.tasks:
            if 'accept_stale' in self.mut:
                continue
            if self.mode == 'content':
                # value identity: work on the old content stays valid for that content; it is
                # not cancelled (it may become current again after A->B->A) and keeps its slot
                continue
            if not t.exited:
                t.cancel = True                  # stale running work keeps its slot
            elif t.resolved is None:
                t.resolved = 'discarded'         # completed-unconsumed stale result dropped
                self.counters['discard'] += 1
        if 'stale_cert' not in self.mut:
            self.certs.clear()
        self.published.clear()
        self._prune()

    def _prune(self):
        self.tasks = [t for t in self.tasks if t.occupies() or (t.resolved is None)]

    def occupied(self):
        return sum(t.occupies() for t in self.tasks)

    def _find(self, key, ident=None):
        ident = self.ident() if ident is None else ident
        for t in self.tasks:
            if t.key == key and t.inc == ident and t.live() and t.resolved is None:
                return t
        return None

    def _inst(self, inst):
        for t in self.tasks:
            if t.inst == inst:
                return t
        return None

    # -- events -------------------------------------------------------------
    def step(self, e):
        op = e['op']
        handler = getattr(self, '_' + op, None)
        if handler is None:
            raise ValueError('unknown event')
        outcome = handler(e)
        self._prune()
        if self.compat:
            required = sum(any(t.consumers.values()) for t in self.tasks if t.occupies())
        else:
            required = sum(any(t.consumers.values()) for t in self.tasks
                           if t.resolved is None and not t.cancel)
        out = dict(outcome=outcome, occupied=self.occupied(), version=self.ident(), required=required,
                   published=deepcopy(self.published))
        if not self.compat:
            out['confirmed'] = list(self.confirmed)
            out['inst'] = getattr(self, '_last_inst', None)
        return out

    def _replace(self, e):
        content, label = e.get('content', self.content), e.get('label', self.label)
        if self.mode == 'epoch':
            if label < self.label:
                return 'stale'
            self.content = content               # environment truth changes regardless
            if label == self.label:
                return 'unchanged'               # N12: relabelled content is not detected
            self.label = label
            self._new_identity()
            return 'advanced'
        if content == self.content:
            return 'unchanged'
        self.content = content
        self.label = max(self.label, label)
        if self.mode == 'ticket':
            if self.inc_bits is None:
                self.inc += 1
            elif self.inc_overflow == 'wrap':
                self.inc = (self.inc + 1) % (1 << self.inc_bits)
            else:
                self.inc = min(self.inc + 1, (1 << self.inc_bits) - 1)
        self._new_identity()
        return 'advanced'

    def _version(self, e):                       # protocol.py compatibility event
        if e['version'] < self.label:
            return 'stale'
        if e['version'] == self.label:
            return 'unchanged'
        self.label = e['version']
        self.inc += 1
        self._new_identity()
        return 'advanced'

    def _request(self, e):
        self._last_inst = None
        key, consumer, required = e.get('key'), e.get('consumer', 'c'), e.get('required', False)
        if self.compat and e.get('version', self.label) != self.label:
            return 'stale'
        t = self._find(key)
        if t is not None:
            if t.cancel and not t.exited:
                if self.compat or 'no_revive' in self.mut:
                    return 'cancelling'
                t.cancel = False
                t.consumers[consumer] = required
                self.counters['revive'] += 1
                self._last_inst = t.inst
                return 'revived'
            if t.cancel:
                return 'cancelling'
            if required and not any(t.consumers.values()) and 'dup_on_promote' in self.mut:
                pass                                 # defect: fall through and start a duplicate
            else:
                t.consumers[consumer] = t.consumers.get(consumer, False) or required
                self.counters['reuse'] += 1
                self._last_inst = t.inst
                return 'reused'
        if self.occupied() >= self.capacity:
            return 'full'
        t = Task(self.next_inst, key, self.ident(), consumer, required, self.content)
        self.next_inst += 1
        self.tasks.append(t)
        self.counters['starts'] += 1
        self._last_inst = t.inst
        return 'admitted'

    def _target_task(self, e):
        if 'inst' in e:
            return self._inst(e['inst'])
        ident = e.get('version', self.label) if self.compat else self.ident()
        for t in self.tasks:
            if t.key == e.get('key') and t.inc == ident and t.resolved is None:
                return t
        if self.compat or e['op'] != 'finish':
            return None     # client events (cancel/consume) address the CURRENT identity only
        for t in self.tasks:                          # physical finish: oldest live instance of the key
            if t.key == e.get('key') and t.resolved is None:
                return t
        return None

    def _cancel(self, e):
        t = self._target_task(e)
        if t is None:
            return 'absent'
        if self.compat:
            if t.ready:
                t.resolved = 'discarded'
                self.counters['discard'] += 1
                return 'discarded'
            t.cancel = True
            return 'cancelling'
        if 'cancel_kills_all' in self.mut:
            t.consumers.clear()
        else:
            t.consumers.pop(e.get('consumer', 'c'), None)
        if t.consumers:
            return 'detached'
        if t.ready:
            t.resolved = 'discarded'
            self.counters['discard'] += 1
            return 'discarded'
        t.cancel = True
        if 'cancel_releases' in self.mut:
            t.freed_early = True
        return 'cancelling'

    def _finish(self, e):
        t = self._target_task(e)
        if t is None:
            return 'absent'
        if t.ready:
            if self.compat and not t.cancel and t.inc == self.ident():
                return 'completed'           # protocol.py re-marks a completed task
            return 'absent'
        t.ready = True
        if self.compat:
            t.exited = True
        stale = t.inc != self.ident() and 'accept_stale' not in self.mut
        if stale or (t.cancel and 'accept_stale' not in self.mut):
            t.resolved = 'discarded'
            self.counters['discard'] += 1
            return 'discarded'
        if 'finish_releases' in self.mut:
            t.freed_early = True
        return 'completed'

    def _exit(self, e):
        if 'inst' in e:
            t = self._inst(e['inst'])
        else:   # physical exit may follow a discarded result: look at every unexited instance
            t = next((x for x in self.tasks if x.key == e.get('key') and x.ready and not x.exited), None)
        if t is None or t.exited or not t.ready:
            return 'absent'
        t.exited = True
        return 'exited'

    def _consume(self, e):
        t = self._target_task(e)
        if t is None or not t.ready or t.resolved is not None:
            return 'unavailable'
        if t.inc != self.ident() and 'accept_stale' not in self.mut:
            t.resolved = 'discarded'
            return 'discarded'
        if 'barrier' in self.mut and any(not x.ready for x in self.tasks if x.resolved is None):
            return 'waiting'
        t.resolved = 'consumed'
        self.knowledge[(self.ident(), t.key)] = t.value
        self.counters['consumed'] += 1
        return 'consumed'

    def _certify(self, e):
        target = e['target']
        if self.certifier is None:
            return 'no_certifier'
        facts = {k: v for (i, k), v in self.knowledge.items() if i == self.ident()}
        res = self.certifier(target, facts)
        if res is None:
            return 'need_facts'
        unit, support = res
        self.certs[target] = (self.ident(), unit, tuple(sorted(support)))
        return 'certified'

    def _entitled(self, target, unit):
        if target in self.published and self.published[target] != unit:
            if 'publish_overlap_only' not in self.mut:
                return False
        if 'publish_same_target_only' not in self.mut:
            if any(_conflicts(u, unit) for u in self.published.values()):
                return False
        return True

    def _publish(self, e):
        target = e['target']
        if self.compat:
            if e.get('version', self.label) != self.label:
                return 'stale'
            unit = e['unit']
            if (target in self.published and self.published[target] != unit) or \
                    any(_conflicts(x, unit) for x in self.published.values()):
                return 'conflict'
            self.published[target] = deepcopy(unit)
            return 'published'
        if not self.require_cert and 'unit' in e:
            ident, unit = self.ident(), e['unit']
        else:
            cert = self.certs.get(target)
            if cert is None:
                return 'no_certificate'
            ident, unit, support = cert
        if ident != self.ident() and 'stale_cert' not in self.mut:
            return 'stale'
        if not self._entitled(target, unit):
            return 'conflict'
        self.published[target] = deepcopy(unit)
        if 'publish_confirms' in self.mut:
            self.confirmed.append((self.ident(), target, members(unit)))
        return 'published'

    def _confirm(self, e):
        target = e['target']
        if target not in self.published:
            return 'rejected'
        self.confirmed.append((self.ident(), target, members(self.published[target])))
        return 'confirmed'

    def current_confirmations(self):
        return [c for c in self.confirmed if c[0] == self.ident()]

    # -- canonical state for exhaustive search --------------------------------
    def canon(self):
        return (self.content, self.label, self.inc, tuple(t.canon() for t in self.tasks),
                tuple(sorted(self.knowledge.items())),
                tuple(sorted((k, (v[0], members(v[1]), v[2])) for k, v in self.certs.items())),
                tuple(sorted((k, members(v)) for k, v in self.published.items())),
                tuple(self.confirmed))


def run_trace(trace, **kw):
    p = Proto(capacity=trace.get('capacity', 2), label=trace.get('version', 0), **kw)
    return [p.step(e) for e in trace['events']]
