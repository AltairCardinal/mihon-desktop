"""Bounded exhaustive interleaving checker for protocol2 (H2/H5/H6/H7/H8/H9/H10, D5).

The monitor is independent of the model: it derives physical occupancy, consumers,
environment content and the true plan from the events and from the *outcomes* the
model reports, never from model internals.  Breadth-first search over a small
alphabet returns a shortest violating trace (= a minimal counterexample in event
count) for every injected mutant; the unmutated model is explored exhaustively up
to the depth bound / state cap and must produce no violation.

Small system: keys a,b; consumers c1,c2; contents X,Y; targets 0..2.
"""
from collections import deque
import copy

from protocol2 import Proto, members

PLAN = {'X': {0: (0, 1), 1: (0, 1), 2: (2,)}, 'Y': {0: (0,), 1: (1, 2), 2: (1, 2)},
        'Z': {0: (0,), 1: (1, 2), 2: (1, 2)}}
NEEDS = {0: ('a',), 1: ('a', 'b'), 2: ('b',)}
OTHER = {'X': 'Y', 'Y': 'X'}


def unit(ms):
    return {'slots': list(ms)}


def sound_certifier(target, facts):
    need = NEEDS[target]
    if not all(k in facts for k in need):
        return None
    vals = {facts[k] for k in need}
    if len(vals) != 1:
        return None
    c = vals.pop()
    return unit(PLAN[c][target]), need


def local_start_certifier(target, facts):
    """Mutant certifier: treats a local window start as the sequence start, so
    target 2 under X is answered with the unit a phase-shifted scan would give."""
    res = sound_certifier(target, facts)
    if res is None:
        return None
    c = facts[NEEDS[target][0]]
    if c == 'X' and target == 2:
        return unit((1, 2)), NEEDS[target]
    return res


class Monitor:
    def __init__(self, capacity, content='X', check_truth=True, value_identity=False):
        # value_identity: identity = content value (A->B->A returns to the same identity)
        self.value_identity = value_identity
        self.capacity = capacity
        self.check_truth = check_truth
        self.content = content
        self.epoch = 0
        self.insts = {}       # inst -> dict
        self.published = {}
        self.confirmed = []

    def canon(self):
        return (self.content, self.epoch,
                tuple(sorted((i, d['key'], d['content'], d['epoch'], d['ready'], d['exited'], d['resolved'],
                              tuple(sorted(d['consumers']))) for i, d in self.insts.items())),
                tuple(sorted(self.published.items())), tuple(self.confirmed))

    def _current(self, d):
        return d['content'] == self.content if self.value_identity else d['epoch'] == self.epoch

    def occupancy(self):
        return sum(1 for d in self.insts.values() if not (d['exited'] and d['resolved']))

    def pick(self, key, want):
        cands = [i for i, d in sorted(self.insts.items()) if d['key'] == key]
        for i in cands:
            d = self.insts[i]
            if want == 'finish' and not d['ready']:
                return i
            if want == 'exit' and d['ready'] and not d['exited']:
                return i
            if want == 'consume' and d['ready'] and not d['resolved']:
                return i
        return None

    def observe(self, e, out):
        """Update and return a violation string or None."""
        op, oc = e['op'], out['outcome']
        if op == 'replace':
            if e['content'] != self.content:
                self.content = e['content']
                self.epoch += 1
                self.published = {}
                for d in self.insts.values():
                    if d['ready'] and not d['resolved'] and oc == 'advanced':
                        d['resolved'] = 'discarded'
        elif op == 'request':
            if oc == 'admitted':
                for d in self.insts.values():
                    if (d['key'] == e['key'] and self._current(d) and not d['exited']
                            and not d['resolved'] and d['consumers']):
                        return 'H6 duplicate start of a live identity'
                self.insts[out['inst']] = dict(key=e['key'], content=self.content, epoch=self.epoch,
                                               ready=False, exited=False, resolved=None,
                                               consumers={e['consumer']})
            elif oc in ('reused', 'revived'):
                self.insts[out['inst']]['consumers'].add(e['consumer'])
        elif op == 'cancel':
            live = [d for d in self.insts.values() if d['key'] == e['key'] and not d['resolved']
                    and self._current(d)]
            if live:
                d = live[0]
                d['consumers'].discard(e['consumer'])
                if oc in ('cancelling', 'discarded') and d['consumers']:
                    return 'D5 another consumer lost its work'
                if oc == 'discarded':
                    d['resolved'] = 'discarded'
        elif op == 'finish':
            d = self.insts[e['inst']]
            d['ready'] = True
            if oc == 'discarded':
                d['resolved'] = 'discarded'
        elif op == 'exit':
            self.insts[e['inst']]['exited'] = True
        elif op == 'consume':
            d = self.insts[e['inst']]
            if oc == 'consumed':
                if d['content'] != self.content:
                    return 'H5 stale completion admitted as a current fact'
                d['resolved'] = 'consumed'
            elif oc == 'discarded':
                d['resolved'] = 'discarded'
            elif d['content'] == self.content and not d['resolved']:
                return 'H8 ready current result not admitted (barrier)'
        elif op == 'publish':
            t = e['target']
            if oc == 'published':
                ms = members(out['published'][t])
                if self.check_truth and ms != PLAN[self.content][t]:
                    return 'H1/H5 published unit is not the true unit of the current input'
                if t in self.published and self.published[t] != ms:
                    return 'H2 same-target replacement'
                for t2, m2 in self.published.items():
                    if set(m2) & set(ms) and m2 != ms:
                        return 'H2 cross-target conflicting publication'
                self.published[t] = ms
        elif op == 'confirm':
            t = e['target']
            if oc == 'confirmed':
                if t not in self.published:
                    return 'H9 confirmation of an unpublished unit'
                self.confirmed.append((t, self.published[t]))
        # global checks
        if self.occupancy() > self.capacity:
            return 'H7 physical occupancy exceeds capacity'
        for t, u in out['published'].items():
            if self.check_truth and members(u) != PLAN[self.content][t]:
                return 'H10 stale publication visible after a real input change'
        mine = [(t, ms) for (_i, t, ms) in out['confirmed']]
        if mine != self.confirmed:
            return 'H9 confirmation history differs from explicit confirm events'
        return None


def alphabet(relabel=True):
    ev = [dict(op='request', key='a', consumer='c1', required=False),
          dict(op='request', key='a', consumer='c1', required=True),
          dict(op='request', key='a', consumer='c2', required=False),
          dict(op='request', key='b', consumer='c1', required=False),
          dict(op='cancel', key='a', consumer='c1'), dict(op='cancel', key='a', consumer='c2'),
          dict(op='cancel', key='b', consumer='c1'),
          dict(op='finish', key='a'), dict(op='finish', key='b'),
          dict(op='exit', key='a'), dict(op='exit', key='b'),
          dict(op='consume', key='a'), dict(op='consume', key='b'),
          dict(op='replace', bump=1)]
    if relabel:
        ev.append(dict(op='replace', bump=0))    # caller keeps its label (epoch precondition broken)
    for t in range(3):
        ev += [dict(op='certify', target=t), dict(op='publish', target=t), dict(op='confirm', target=t)]
    return ev


def concretize(e, model, mon):
    """Bind physical instance / content for environment events; None = not enabled."""
    op = e['op']
    if op in ('finish', 'exit', 'consume'):
        i = mon.pick(e['key'], op)
        if i is None:
            return None
        return dict(op=op, inst=i)
    if op == 'replace':
        return dict(op='replace', content=OTHER[mon.content], label=model.label + e['bump'])
    return dict(e)


def search(capacity=1, mode='ticket', mutants=(), certifier=sound_certifier, depth=8, cap=300000,
           relabel=True, check_truth=True):
    root = (Proto(capacity=capacity, mode=mode, mutants=mutants, certifier=certifier),
            Monitor(capacity, check_truth=check_truth, value_identity=(mode == 'content')))
    seen = {(root[0].canon(), root[1].canon())}
    q = deque([(root, [])])
    alpha = alphabet(relabel)
    explored = 0
    while q:
        (model, mon), trace = q.popleft()
        if len(trace) >= depth:
            continue
        for e in alpha:
            ce = concretize(e, model, mon)
            if ce is None:
                continue
            m2, mon2 = copy.deepcopy(model), copy.deepcopy(mon)
            out = m2.step(ce)
            explored += 1
            bad = mon2.observe(ce, out)
            if bad:
                return dict(violation=bad, trace=trace + [ce], outcome=out['outcome'], explored=explored,
                            states=len(seen), complete=False)
            key = (m2.canon(), mon2.canon())
            if key in seen:
                continue
            seen.add(key)
            if len(seen) > cap:
                return dict(violation=None, explored=explored, states=len(seen), complete=False,
                            reason='state cap')
            q.append(((m2, mon2), trace + [ce]))
    return dict(violation=None, explored=explored, states=len(seen), complete=True, depth=depth)


def eager_certifier(target, facts):
    """Unsound certifier: answers target 1 from 'b' alone with a guessed unit."""
    if target == 1 and 'b' in facts and 'a' not in facts:
        return unit((1, 2)), ('b',)
    return sound_certifier(target, facts)


def replay(trace, capacity=1, mode='ticket', mutants=(), certifier=sound_certifier):
    model, mon = (Proto(capacity=capacity, mode=mode, mutants=mutants, certifier=certifier),
                  Monitor(capacity, value_identity=(mode == 'content')))
    for e in trace:
        out = model.step(e)
        bad = mon.observe(e, out)
        if bad:
            return bad
    return None
