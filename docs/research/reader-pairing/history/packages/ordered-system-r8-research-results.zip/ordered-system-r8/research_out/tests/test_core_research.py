"""Main-session families (A/B1-3/E/F/H + relational hosts): differential,
oracle and mutant tests.  Run:
  python -m unittest discover -s research_out/tests -t research_out -p 'test_core_research.py'
"""
import copy
import json
import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'candidates'))
from common import ref, random_case, roundtrip, unit_of, base_case, fact, SIDES, rank_value  # noqa: E402
import transducer as T  # noqa: E402
import omega as O  # noqa: E402
import incremental as I  # noqa: E402
import theory_a as A  # noqa: E402
import theory_h as H  # noqa: E402
import generative as G  # noqa: E402
import relational_exp as X  # noqa: E402
import relhost as RH  # noqa: E402
from current_baseline import Host, Config  # noqa: E402

FIX = Path(__file__).resolve().parents[1] / 'fixtures'


class Transducer(unittest.TestCase):
    def test_complete_plan_equivalence(self):
        rng = random.Random(1)
        for _ in range(600):
            n = rng.randrange(1, 16)
            c = roundtrip(random_case(rng, n, p_unknown=0.15, p_edge_unknown=0.15, p_fail=0.05, header_missing=0.05))
            want = ref.complete_plan(c)
            self.assertEqual(T.complete_plan_tree(c), want)
            tr = T.RelTree(T.Facts(c, 'complete'))
            for t in range(n):
                us = tr.units(t)
                self.assertEqual(list(us.values()), [unit_of(want, t)])

    def test_manual_bit_merge_lemma(self):
        """Lemma L-M2: in every reachable at-state at i, manual(i-1) is False, so
        zeroing the carried bit is EQUIVALENT (a proven state merge 10 -> 5)."""
        orig = T.set_manual

        def zero(ctx, i, m_in):
            orig(ctx, i, 0)
        rng = random.Random(12)
        cases = []
        for _ in range(500):
            n = rng.randrange(2, 14)
            c = roundtrip(random_case(rng, n))
            s0 = rng.randrange(0, n - 1)
            c['settings']['pinned_links'] = list(range(s0, min(n - 1, s0 + rng.randrange(1, 6))))
            cases.append(c)
        T.set_manual = zero
        try:
            got = [T.complete_plan_tree(c) for c in cases]
        finally:
            T.set_manual = orig
        self.assertEqual(got, [ref.complete_plan(c) for c in cases])

    def test_manual_alternation_mutant(self):
        """Mutant: manual(o) = B(o) without alternation is detected."""
        orig = T.set_manual

        def no_alt(ctx, i, m_in):
            ctx.m = {i - 1: bool(m_in)}
            for o in (i, i + 1, i + 2):
                ctx.m[o] = T._B(ctx, o)
        c = base_case(5)
        c['settings']['pinned_links'] = [1, 2]
        T.set_manual = no_alt
        try:
            got = T.complete_plan_tree(c)
        finally:
            T.set_manual = orig
        self.assertNotEqual(got, ref.complete_plan(c))
        self.assertEqual(T.complete_plan_tree(c), ref.complete_plan(c))

    def test_window_lemma_mutant(self):
        """Mutant: an update footprint narrower than [p-3, p+1] is detected."""
        orig = T.affected_leaves
        T.affected_leaves = lambda p: range(p - 1, p + 1)
        caught = False
        try:
            rng = random.Random(7)
            for _ in range(300):
                n = rng.randrange(4, 14)
                c = roundtrip(random_case(rng, n))
                tp = I.TreePlan(c)
                cur = copy.deepcopy(c)
                p = rng.randrange(n)
                item = copy.deepcopy(cur['items'][p])
                item['analysis'] = dict(status='computed', fact=fact('WIDE'), version=9)
                item['header'] = fact('WIDE')
                cur['items'][p] = item
                tp.set_item(p, copy.deepcopy(item))
                if tp.plan() != ref.complete_plan(cur) or any(tp.unit(t) != unit_of(ref.complete_plan(cur), t) for t in range(n)):
                    caught = True
                    break
        finally:
            T.affected_leaves = orig
        self.assertTrue(caught)


class Omega(unittest.TestCase):
    def test_soundness_against_world_oracle(self):
        rng = random.Random(3)
        checked = 0
        for _ in range(200):
            n = rng.randrange(2, 6)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.35, p_fail=0.05))
            t = rng.randrange(n)
            try:
                U = O.oracle_units(c, t, cap=20000)
            except OverflowError:
                continue
            checked += 1
            for st, u in (T.certify_tree(c, t), O.certify_exact(c, t)):
                if st == 'certified':
                    self.assertEqual(set(U), {T._key(u)})
            self.assertEqual(O.certify_exact(c, t)[0] == 'certified', len(U) == 1)   # exact from 0
            r = ref.certify(c, t)
            if r['status'] == 'certified':
                self.assertEqual(set(U), {T._key(r['unit'])})
        self.assertGreater(checked, 100)

    def test_old_representatives_mutant_is_unsound(self):
        d = json.loads((Path(__file__).resolve().parents[1] / 'results' / 'relational.json').read_text()) \
            if (Path(__file__).resolve().parents[1] / 'results' / 'relational.json').exists() else None
        c = base_case(5, automatic=True)
        c['edges'][1]['score'] = 1e17
        c['edges'] = [e for e in c['edges'] if e['first'] != 2]
        orig = T.feasible
        T.feasible = lambda cons, dom: X.feasible_old_representatives(cons, dom)
        try:
            bad = T.certify_tree(c, 4)
        finally:
            T.feasible = orig
        self.assertEqual(bad[0], 'certified')
        self.assertGreater(len(O.oracle_units(c, 4)), 1)
        self.assertNotEqual(T.certify_tree(c, 4)[0], 'certified')

    def test_frontier_cache_equals_exact(self):
        rng = random.Random(9)
        for _ in range(60):
            n = rng.randrange(2, 14)
            c = roundtrip(random_case(rng, n, p_unknown=0.3, p_edge_unknown=0.3))
            fc = O.FrontierCache(c)
            for t in range(n):
                a, b = O.certify_exact(c, t), fc.certify(t)
                self.assertEqual(a[0], b[0])
                if a[0] == 'certified':
                    self.assertEqual(a[1], b[1])

    def test_header_authority_assumption(self):
        """beta worlds (analysis may contradict a valid header) break the frozen certifier."""
        c = base_case(4, automatic=False)
        c['items'][2]['analysis'] = {'status': 'unknown'}
        r = ref.certify(c, 2)
        self.assertEqual(r['status'], 'certified')        # relies on the header's NARROW
        w = copy.deepcopy(c)
        w['items'][2]['analysis'] = dict(status='computed', fact=fact('WIDE'), version=1)
        self.assertNotEqual(unit_of(ref.complete_plan(w), 2), r['unit'])
        self.assertEqual(T.certify_tree(c, 2, header_authority=False)[0], 'ambiguous')


class Incremental(unittest.TestCase):
    def test_all_candidates_track_reference(self):
        rng = random.Random(4)
        for _ in range(80):
            n = rng.randrange(1, 20)
            c = roundtrip(random_case(rng, n, p_unknown=0.1, p_edge_unknown=0.1))
            impls = [cls(c) for cls in I.CANDIDATES.values()]
            cur = copy.deepcopy(c)
            for u in range(8):
                p = rng.randrange(n)
                item = copy.deepcopy(cur['items'][p])
                item['analysis'] = dict(status='computed', fact=fact(rng.choice(('NARROW', 'WIDE')), rng.choice(SIDES)), version=u + 2)
                cur['items'][p] = item
                for m in impls:
                    m.set_item(p, copy.deepcopy(item))
                want = ref.complete_plan(cur)
                for m in impls:
                    self.assertEqual(m.plan(), want)

    def test_resync_stop_rule_mutant(self):
        """Stopping at the first equal state BEFORE passing the changed leaves is wrong."""
        orig = I.ResyncPlan._resync

        def early(self, lo, hi):
            start = max(0, lo - 3)
            self._scan_from(start, self.states[start], start)      # mutant: stop_after = start
        I.ResyncPlan._resync = early
        caught = False
        try:
            rng = random.Random(5)
            for _ in range(300):
                n = rng.randrange(5, 16)
                c = roundtrip(random_case(rng, n))
                rp = I.ResyncPlan(c)
                cur = copy.deepcopy(c)
                p = rng.randrange(n)
                item = copy.deepcopy(cur['items'][p])
                item['analysis'] = dict(status='computed', fact=fact('WIDE'), version=5)
                cur['items'][p] = item
                rp.set_item(p, copy.deepcopy(item))
                if rp.plan() != ref.complete_plan(cur):
                    caught = True
                    break
        finally:
            I.ResyncPlan._resync = orig
        self.assertTrue(caught)


class RelationalHost(unittest.TestCase):
    def test_base_verdict_preserved_and_extra_sound(self):
        rng = random.Random(3)
        extra = 0
        for _ in range(60):
            n = rng.randrange(3, 10)
            c = roundtrip(random_case(rng, n, p_unknown=0.35, p_edge_unknown=0.35, p_fail=0.03))
            hs = [RH.RelHost(c, lambda x: Host(x, config=Config.current()), m) for m in ('tree', 'exact', 'portfolio')]
            cur = copy.deepcopy(c)
            for step in range(6):
                t = rng.randrange(n)
                want = {k: v for k, v in ref.certify_strategy(cur, t)['selected'].items() if k != 'reads'}
                for h in hs:
                    v = h.request(t)
                    if want['status'] != 'need_facts':
                        self.assertEqual(v, want)
                    elif v['status'] == 'certified':
                        extra += 1
                        self.assertEqual(O.certify_exact(cur, t)[1], v['unit'])
                    else:
                        self.assertEqual(v, want)
                p = rng.randrange(n)
                cur['items'][p]['analysis'] = dict(status='computed', fact=fact(cur['items'][p]['header']['state'], rng.choice(SIDES)), version=2)
                for h in hs:
                    h.replace(cur)
        self.assertGreater(extra, 0)


class TheoryChecks(unittest.TestCase):
    def test_unbounded_phase_separation(self):
        for row in A.unbounded_separation((16, 64)):
            self.assertGreaterEqual(row['last_differing'], row['n'] - 3)

    def test_int_vs_double_interfaces_differ(self):
        label, c, _ = A.e4_cases()[0]
        c = roundtrip(c)
        self.assertNotEqual(ref.complete_plan(c), ref.complete_plan(A.as_double_interface(c)))

    def test_order_compression_preserves_plan(self):
        rng = random.Random(5)
        for _ in range(300):
            c = roundtrip(random_case(rng, rng.randrange(2, 12)))
            self.assertEqual(ref.complete_plan(c), ref.complete_plan(A.compress_ranks(c)))

    def test_label_swap_equivariance(self):
        rng = random.Random(6)
        for _ in range(300):
            c = roundtrip(random_case(rng, rng.randrange(1, 12)))
            self.assertEqual(ref.complete_plan(A.swap_sides(c)), A.swap_unit_labels(ref.complete_plan(c)))

    def test_generative_chain_realisation(self):
        rng = random.Random(11)
        for k in range(40):
            n = rng.randrange(2, 7)
            widths = [rng.choice((1, 2, 4, 5, 8)) for _ in range(n)]
            tg = [None if rng.random() < .2 else rng.randrange(0, 1500) / 50 for _ in range(n - 1)]
            tens, L, R = G.realise_chain(tg, widths, seed=k)
            self.assertEqual(G.derive_ranks(tens, widths), tg)

    def test_projection_weakness_regression(self):
        """The exported host-projection fields cannot see reason-only mutants."""
        res = H.projection_power(300, seed=31)
        self.assertGreater(res['active']['reason'], 0)
        self.assertEqual(res['killed']['reason']['host_fixture'], 0)
        self.assertEqual(res['killed']['reason']['public_full'], res['active']['reason'])

    def test_lmp_partition_and_locality(self):
        rng = random.Random(8)
        for _ in range(200):
            n = rng.randrange(1, 25)
            c = roundtrip(random_case(rng, n))
            m = H.plan_members(H.lmp_plan(c))
            self.assertEqual(sorted(m), list(range(n)))
        c = A.decreasing_chain(40)
        d = copy.deepcopy(c)
        d['edges'][1]['score'] = 0.1
        m0, m1 = H.plan_members(H.lmp_plan(c)), H.plan_members(H.lmp_plan(d))
        self.assertLessEqual(max(i for i in range(40) if m0[i] != m1[i]), 6)


if __name__ == '__main__':
    unittest.main()
