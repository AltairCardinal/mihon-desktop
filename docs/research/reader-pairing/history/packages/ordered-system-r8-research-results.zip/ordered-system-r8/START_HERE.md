# 从这里开始：有序系统的深度自主研究

这是一个完整、自包含、匿名的研究委托。你无需知道它的应用领域，也不应尝试寻找原始项目。目标是发现可靠、成本合算的新机制或替代算法。

本轮范围为 **48 个主课题 + 12 个组合挑战**。上一轮已经实现并测量了一批方案；本轮必须以当前保留机制为基线，避免重复证明旧结论或只打败过时实现。

## 开始方式

1. 完整阅读 `OPUS_PROMPT.md`、`RESEARCH_BRIEF.md`。
2. 阅读 `FORMAL_PROBLEM.md`、`CONTRACTS.md`、`MODEL_API.md`、`GENERATIVE_DOMAIN.md`，理解参考、模型、见证子域和真实覆盖之间的区别。
3. 按 `RUNNING.md` 运行测试和小 smoke；先记录真实基线，再开展研究。
4. 阅读 `BASELINE_EVIDENCE.md`、`NEGATIVE_RESULTS.md`，将已经否定的假设作为回归条件。
5. 按 `ROADMAP.md` 执行 `RESEARCH_QUESTIONS.md` 的 48 题，以及 `COMBINATION_CHALLENGES.md` 的 12 题。
6. 使用 `ADVERSARIAL_SUITE.md`、`EXPERIMENT_PROTOCOL.md` 和 `DELIVERY_TEMPLATE.md` 自查深度与证据。

所有新增研究写入 `research_out/`。保留参考规则、原始夹具和本包原文件；可建立新候选模块，不得替换 oracle 使候选通过。研究结果使用包内中性术语和相对路径。

**两小时不是完成条件，长时间运行也不是完成证据。**建议为完整委托安排 8–16 小时有效研究预算；平台允许时可更长。时间只是容量规划：不休眠凑时长，不用重复同一穷举填预算。完成以课题覆盖、证据深度和剩余问题是否诚实登记为准。预算不足就明确交付未完成项与可恢复入口，不得把概览写成全题完成。

运行本包只需要标准 Python 与标准库。没有联网、外部求解器或多代理时继续使用可用方法，不要求提供者补充账户、仓库或业务资料。
