import unittest
from generator import make_witness
from runtime import Session


class RuntimeContracts(unittest.TestCase):
    def test_memo_checks_and_recomputes_after_metadata(self):
        s=Session(make_witness(count=6))
        for i in range(6): s.apply(dict(op='observe',item=i))
        s.request(2); s.request(2)
        self.assertEqual(s.metrics['memo_hits'],1)
        s.apply(dict(op='metadata',item=5,orientation=3))
        s.request(2)
        self.assertEqual(s.metrics['engine_runs'],2)
        self.assertEqual(s.metrics['memo_misses'],2)

    def test_rebind_clears_memo_preserves_flags_rejects_old_completion(self):
        s=Session(make_witness(count=4),work_capacity=1)
        s.apply(dict(op='flag',item=2,read=True,settled=True))
        s.request(2)
        token=s.work_tokens()[0]
        s.apply(dict(op='rebind',item=1))
        self.assertFalse(s.memo)
        self.assertIn(2,s.flags['read'])
        self.assertEqual(s.apply(dict(op='finish',token=token))['outcome'],'discarded')

    def test_navigation_clears_memo_and_nonpreemptible_work(self):
        s=Session(make_witness(count=5),work_capacity=1)
        s.request(3)
        token=s.work_tokens()[0]
        s.apply(dict(op='navigate',target=1))
        self.assertFalse(s.memo)
        self.assertEqual(len(s.tasks),1)
        self.assertEqual(s.apply(dict(op='finish',token=token))['outcome'],'discarded')

    def test_promotion_reuses_and_completion_retains_capacity(self):
        s=Session(make_witness(count=4),work_capacity=1)
        s.apply(dict(op='prefetch',item=1))
        token=s.work_tokens()[0]
        s.apply(dict(op='demand',item=1))
        self.assertTrue(s.tasks[token]['required'])
        s.apply(dict(op='demand',item=2))
        s.apply(dict(op='finish',token=token))
        self.assertEqual(len(s.tasks),1)
        self.assertIn(2,s.pending)
        s.apply(dict(op='consume',token=token))
        self.assertEqual(len(s.tasks),1)
        self.assertEqual(next(iter(s.tasks.values()))['item'],2)

    def test_missing_reads_never_reuses_candidate(self):
        def candidate(case,target):
            return dict(status='need_facts',unit=None,needs=[],failures={},steps=0)
        s=Session(make_witness(count=2),candidate=candidate)
        s.request(0); s.request(0)
        self.assertEqual(s.metrics['memo_hits'],0)
        self.assertEqual(s.metrics['engine_runs'],2)

    def test_metadata_revokes_completed_unconsumed_work(self):
        s=Session(make_witness(count=2),work_capacity=1)
        s.apply(dict(op='prefetch',item=1)); token=s.work_tokens()[0]
        s.apply(dict(op='finish',token=token))
        s.apply(dict(op='metadata',item=1,orientation=3))
        self.assertEqual(s.apply(dict(op='consume',token=token))['outcome'],'discarded')
        self.assertNotIn(1,s.knowledge.analyses)

    def test_cancelling_completed_work_refills_released_slot(self):
        s=Session(make_witness(count=3),work_capacity=1)
        s.apply(dict(op='prefetch',item=1)); token=s.work_tokens()[0]
        s.apply(dict(op='demand',item=2)); s.apply(dict(op='finish',token=token))
        s.apply(dict(op='cancel',token=token))
        self.assertEqual(len(s.tasks),1)
        self.assertEqual(next(iter(s.tasks.values()))['item'],2)

    def test_publish_requires_current_certificate_and_keeps_unit(self):
        s=Session(make_witness(count=1))
        self.assertEqual(s.apply(dict(op='publish',target=0))['outcome'],'unproved')
        s.apply(dict(op='observe',item=0)); s.request(0)
        self.assertEqual(s.apply(dict(op='publish',target=0))['outcome'],'published')
        self.assertEqual(s.apply(dict(op='rebind',item=0))['outcome'],'visible_conflict')
        self.assertEqual(s.apply(dict(op='rebind',item=0,reload=True))['outcome'],'rebound')


if __name__ == '__main__': unittest.main()
