"""Synthetic contract simulator, NOT a transplant of a real scheduler.

Events are serial. A version denotes the entire immutable logical identity.
Capacity bounds admitted running plus completed/unconsumed tasks; acquisition
demand and certificate dependencies are intentionally separate concepts.
This model proves no wall-clock, cancellation latency, extraction or native
publication property. Optional/required is a demand label, never a new identity.
"""
from copy import deepcopy


def run_event_trace(trace):
    capacity = trace.get('capacity', 2)
    if capacity < 1:
        raise ValueError('capacity must be positive')
    version, tasks, published, output = trace.get('version', 0), {}, {}, []
    for event in trace['events']:
        op = event['op']
        token = (event.get('version', version), event.get('key'))
        task = tasks.get(token)
        if op == 'version':
            if event['version'] == version:
                outcome = 'unchanged'
            else:
                version = event['version']
                # Stale running tasks retain capacity until they truly finish.
                tasks = {k: v for k, v in tasks.items() if v['phase'] != 'completed'}
                for value in tasks.values():
                    value['cancelled'] = True
                published.clear()
                outcome = 'advanced'
        elif op == 'request':
            if token[0] != version:
                outcome = 'stale'
            elif task is not None:
                if not task['cancelled']:
                    task['required'] |= event.get('required', False)
                    outcome = 'reused'
                else:
                    outcome = 'cancelling'
            elif len(tasks) >= capacity:
                outcome = 'full'
            else:
                tasks[token] = dict(phase='running', required=event.get('required', False), cancelled=False)
                outcome = 'admitted'
        elif op == 'cancel':
            if task is None:
                outcome = 'absent'
            elif task['phase'] == 'completed':
                del tasks[token]
                outcome = 'discarded'
            else:
                task['cancelled'] = True
                outcome = 'cancelling'
        elif op == 'finish':
            if task is None:
                outcome = 'absent'
            elif token[0] != version or task['cancelled']:
                del tasks[token]
                outcome = 'discarded'
            else:
                task['phase'] = 'completed'
                outcome = 'completed'
        elif op == 'consume':
            if task is None or task['phase'] != 'completed':
                outcome = 'unavailable'
            else:
                del tasks[token]
                outcome = 'consumed'
        elif op == 'publish':
            target, unit = event['target'], event['unit']
            if event.get('version', version) != version:
                outcome = 'stale'
            elif target in published and published[target] != unit:
                outcome = 'conflict'
            else:
                published[target] = deepcopy(unit)
                outcome = 'published'
        else:
            raise ValueError('unknown event')
        output.append(dict(outcome=outcome, occupied=len(tasks), version=version,
                           required=sum(t['required'] for t in tasks.values()),
                           published=deepcopy(published)))
    return output
