import unittest
from unittest.mock import patch
from generator import Knowledge, make_witness, sample_item, score


class GeneratorContracts(unittest.TestCase):
    def test_case_projection_does_not_resample_latent_pixels(self):
        k=Knowledge(make_witness(count=3))
        with patch('generator.pixel_at',side_effect=AssertionError('unexpected latent sample')):
            self.assertEqual(len(k.case()['items']),3)

    def test_common_witness_determines_neighbors(self):
        w = make_witness(count=3)
        w['items'] = [dict(width=256, height=384, pattern='stripe', offset=x) for x in (0, 5, 7)]
        a, b, c = [sample_item(x) for x in w['items']]
        self.assertEqual(score(a['edges'], b['edges']), 15)
        self.assertEqual(score(b['edges'], c['edges']), 6)

    def test_known_null_and_lru_loss_are_different(self):
        w = make_witness(count=4)
        w['items'] = [dict(width=256,height=384,pattern='flat',offset=0)] * 4
        k = Knowledge(w, capacity=2)
        k.observe(0); k.observe(1); k.observe(2)
        self.assertEqual(k.case()['edges'][0]['status'], 'computed')
        self.assertIsNone(k.case()['edges'][0]['score'])
        self.assertNotIn(0, k.samples)
        self.assertEqual(k.case()['edges'][2]['status'], 'unknown')
        self.assertEqual(k.case()['items'][0]['analysis']['status'], 'computed')

    def test_missing_endpoint_and_failure(self):
        k = Knowledge(make_witness(count=3), capacity=2)
        k.fail(1, 'READ')
        self.assertEqual(k.case()['items'][1]['analysis']['status'], 'failed')
        self.assertEqual(k.case()['edges'][0]['status'], 'unknown')
        k.observe(0); k.observe(1); k.evict(1); k.fail(1, 'RESOURCE')
        self.assertEqual(k.case()['items'][1]['analysis']['status'], 'computed')

    def test_side_is_derived_from_same_raster(self):
        self.assertEqual(sample_item(dict(width=256,height=384,pattern='margin_A'))['fact']['side'], 'B')
        self.assertEqual(sample_item(dict(width=256,height=384,pattern='margin_B'))['fact']['side'], 'A')

    def test_orientations_have_in_bounds_points(self):
        for orientation in range(1,9):
            for rotation in (0,90,180,270):
                s = sample_item(dict(width=80,height=120,pattern='stripe',orientation=orientation,rotation=rotation))
                for side in ('left','right'):
                    self.assertTrue(all(0 <= x < 80 and 0 <= y < 120 for x,y in s['points'][side]))


if __name__ == '__main__':
    unittest.main()
