"""Correlated physical-raster witness domain with exact bounded sample formulas.

Raster patterns form a strict subset of all 8-bit straight-alpha sRGB rasters.
Geometry, side evidence and adjacent ranks derive from the SAME latent raster;
independently chosen rank tables are never labeled physically generated.
No encoded format, decoder, I/O, worker timing or persistence is represented.
"""
from collections import OrderedDict
from copy import deepcopy
import random


_ORIENTATION = {1:(0,False),2:(0,True),3:(2,False),4:(2,True),
                5:(1,True),6:(1,False),7:(3,True),8:(3,False)}


def geometry_fact(spec):
    """Metadata-only geometry; projecting knowledge never samples hidden pixels."""
    w,h=spec['width'],spec['height']
    orientation,rotation=spec.get('orientation',1),spec.get('rotation',0)
    if w<=0 or h<=0 or orientation not in _ORIENTATION or rotation not in (0,90,180,270):
        raise ValueError('invalid geometry')
    turns,mirror=_ORIENTATION[orientation]
    nw,nh=(h,w) if turns%2 else (w,h)
    display_turns=(turns+(-rotation//90 if mirror else rotation//90))%4
    ow,oh=(h,w) if display_turns%2 else (w,h)
    return dict(state='WIDE' if ow>=oh else 'NARROW',width=nw,height=nh,
                rotation=rotation,orientation=orientation,side='UNKNOWN')


def pixel_at(spec, x, y):
    pattern = spec.get('pattern', 'stripe')
    value = 70 + (110 if ((y + spec.get('phase', 0)) // spec.get('band', 7)) % 2 else 0)
    if pattern == 'flat':
        value = 128
    elif pattern == 'margin_A' and x < spec['width'] * .05:
        value = 255
    elif pattern == 'margin_B' and x >= spec['width'] * .95:
        value = 255
    elif pattern not in ('stripe', 'margin_A', 'margin_B'):
        raise ValueError('unsupported raster pattern')
    value = min(255, max(0, value + spec.get('offset', 0)))
    return (spec.get('alpha',255) << 24) | (value << 16) | (value << 8) | value


def sample_item(spec):
    w, h = spec['width'], spec['height']
    if w <= 0 or h <= 0 or spec.get('band',7) <= 0:
        raise ValueError('positive extents and band required')
    orientation, rotation = spec.get('orientation',1), spec.get('rotation',0)
    if orientation not in _ORIENTATION or rotation not in (0,90,180,270):
        raise ValueError('invalid orientation or rotation')
    turns, mirror = _ORIENTATION[orientation]
    source_turns = turns
    turns = (turns + (-rotation//90 if mirror else rotation//90)) % 4
    ow, oh = (h,w) if turns % 2 else (w,h)
    nw, nh = (h,w) if source_turns % 2 else (w,h)
    def original(x,y):
        x = ow-1-x if mirror else x
        return ((x,y),(y,h-1-x),(w-1-x,h-1-y),(w-1-y,x))[turns]
    points = {'left':[], 'right':[]}
    side_count = 0
    if ow >= 64 and oh >= 64 and ow < oh:
        for side in ('left','right'):
            for offset in (.002,.015,.035):
                x = min(ow-2, max(1, int(ow*offset)))
                for index in range(48):
                    y = min(oh-1,max(0,int(oh*(.04+.90*index/47))))
                    points[side].append(original(ow-1-x if side=='right' else x,y))
        side_count = 144
    has_edges = ow <= oh
    if has_edges:
        for side,x in (('left',min(2,ow-1)),('right',max(0,ow-3))):
            points[side] += [original(x,index*oh//50) for index in range(50)]
    colors = {s:[pixel_at(spec,x,y) for x,y in values] for s,values in points.items()}
    def white(c):
        return (c >> 24) >= 240 and all(((c >> shift)&255) >= 242 for shift in (16,8,0))
    side = 'UNKNOWN'
    if side_count:
        ratios = {s:[sum(white(x) for x in colors[s][b:b+48])/48 for b in (0,48,96)]
                  for s in ('left','right')}
        a,b = ratios['left'],ratios['right']
        if all(x >= .90 for x in a) and all(x <= .75 for x in b) and all(x-y >= .25 for x,y in zip(a,b)):
            side = 'B'
        elif all(x >= .90 for x in b) and all(x <= .75 for x in a) and all(y-x >= .25 for x,y in zip(a,b)):
            side = 'A'
    edges = {s:colors[s][side_count:] for s in ('left','right')} if has_edges else None
    return dict(fact=dict(state='WIDE' if ow >= oh else 'NARROW',width=nw,height=nh,
                          rotation=rotation,orientation=orientation,side=side), edges=edges,points=points)


def score(earlier, later, direction='AB'):
    if direction not in ('AB','BA'):
        raise ValueError('direction must be AB or BA')
    if earlier is None or later is None:
        return None
    def normalize(c):
        alpha = c >> 24
        return tuple(((((c>>shift)&255)*alpha + 255*(255-alpha)+127)//255) for shift in (16,8,0))
    a = [normalize(c) for c in earlier['right' if direction=='AB' else 'left']]
    b = [normalize(c) for c in later['left' if direction=='AB' else 'right']]
    if len(a) != 50 or len(b) != 50:
        raise ValueError('exactly fifty samples required per edge')
    distance = sum(sum(abs(x-y) for x,y in zip(c,d)) for c,d in zip(a,b))/50
    def bright(e): return sum(min(c)>220 for c in e) >= 40
    def dark(e): return sum(max(c)<50 for c in e) >= 40
    def variance(e):
        values = [.299*c[0]+.587*c[1]+.114*c[2] for c in e]
        mean = sum(values)/50
        return sum(x*x for x in values)/50-mean*mean
    if distance >= 30 or (bright(a) and bright(b)) or (dark(a) and dark(b)) or (variance(a)<100 and variance(b)<100):
        return None
    return distance


def make_witness(seed=731, count=24):
    if count < 1:
        raise ValueError('positive count required')
    rng = random.Random(seed)
    return dict(level='physical-raster-v1', seed=seed,
                items=[dict(width=256,height=384,pattern=rng.choice(('stripe','flat','margin_A','margin_B')),
                            offset=rng.choice((0,2,5,7)),phase=rng.randrange(7),band=7,
                            orientation=1,rotation=0,alpha=255) for _ in range(count)],
                settings=dict(direction='AB',automatic=True,opening='SINGLE',hard_isolates=[],pinned_links=[]))


class Knowledge:
    """Serial bounded raw-sample knowledge; analyses and computed ranks persist.

    Explicit evict is a synthetic capacity-control event. Normal observe uses
    insertion order, computes adjacent ranks BEFORE eviction, and never fetches
    missing endpoints implicitly. Failures do not erase a computed analysis.
    """
    def __init__(self,witness,capacity=16):
        if not 2 <= capacity <= 16:
            raise ValueError('capacity must be between two and sixteen')
        self.witness = deepcopy(witness)
        self.capacity,self.samples,self.analyses,self.ranks,self.failures = capacity,OrderedDict(),{},{},{}
        self.versions = [0]*len(witness['items'])
        self.generation,self.order_revision = 0,0

    def observe(self,index):
        result = sample_item(self.witness['items'][index])
        edges = result['edges']
        if edges is not None:
            self.samples.pop(index,None)
            self.samples[index] = edges
            for a in (index-1,index):
                if a >= 0 and a in self.samples and a+1 in self.samples:
                    self.ranks[a] = {d:score(self.samples[a],self.samples[a+1],d) for d in ('AB','BA')}
            while len(self.samples)>self.capacity:
                self.samples.popitem(last=False)
        self.analyses[index] = dict(status='computed',fact=result['fact'],version=1)
        self.failures.pop(index,None)
        return result

    def fail(self,index,reason='READ'):
        self.failures[index] = reason
        if self.analyses.get(index,{}).get('status') != 'computed':
            self.analyses[index] = dict(status='failed',reason=reason)

    def evict(self,index):
        self.samples.pop(index,None)

    def invalidate(self,index,spec=None):
        if spec is not None:
            self.witness['items'][index] = deepcopy(spec)
        self.versions[index] += 1
        self.samples.pop(index,None)
        self.analyses.pop(index,None)
        self.failures.pop(index,None)
        for a in (index-1,index): self.ranks.pop(a,None)

    def case(self):
        items=[]
        for i,spec in enumerate(self.witness['items']):
            f=geometry_fact(spec)
            items.append(dict(id=f'i{i}',content_version=self.versions[i],rotation=f['rotation'],
                              orientation=f['orientation'],header=dict(f,side='UNKNOWN'),
                              analysis=deepcopy(self.analyses.get(i,dict(status='unknown')))))
        direction=self.witness['settings'].get('direction','AB')
        edges=[]
        for a in range(len(items)-1):
            evidence=dict(first=a,second=a+1,status='unknown')
            aa,bb=[self.analyses.get(i,{}) for i in (a,a+1)]
            if aa.get('status') == bb.get('status') == 'computed':
                if aa['fact']['state']=='WIDE' or bb['fact']['state']=='WIDE':
                    evidence.update(status='computed',score=None,version=1)
                elif a in self.ranks:
                    evidence.update(status='computed',score=self.ranks[a][direction],version=1)
                else:
                    failures={str(i):self.failures[i] for i in (a,a+1) if i in self.failures}
                    if failures: evidence.update(status='failed',failures=failures)
            edges.append(evidence)
        return dict(items=items,edges=edges,settings=deepcopy(self.witness['settings']),
                    generation=self.generation,order_revision=self.order_revision)


def observe(witness,events,capacity=16):
    knowledge=Knowledge(witness,capacity)
    for event in events:
        getattr(knowledge,event['op'])(event['item'],**event.get('args',{}))
    return knowledge.case()
