"""Bounded stdlib engineering benchmark; all times are fresh local Python ns.

CLI: python benchmark.py --quick --output run.json
Candidate: --candidate candidate_module:build
build() returns {certify: callable(case,target)->proof,
                validate: optional callable(proof,case)->bool,
                metrics: optional mutable JSON-compatible dict}.
A proof without standard reads needs a custom validator; absent one it never
hits the memo or authorizes publication. The builder runs once per scenario;
its time is reported. Candidate scope construction and validation are counted.
Candidate code is trusted local research code, not a sandboxed plugin.

Request path wall time includes constructing current knowledge, validation,
necessary recertification, demand mapping and model acquisition/publication.
Operator costs below are independent micro-measurements, not runtime speedups.
Injected service time is SIMULATED, is not slept, and is never added to observed
Python wall time. No historical observations or native latency are inferred.
"""
import argparse
from copy import deepcopy
import importlib
import json
from pathlib import Path
from time import perf_counter_ns
from generator import Knowledge,make_witness,sample_item,score
from runtime import Session
import reference


def build_scoped():
    """Certified-only scoped validator; pending verdicts retain strict reads.

    Stable ordinal identity and truthful generation/order revisions are input
    preconditions. Eviction tolerance is OFF. This is an experimental validator
    under this generated domain, not a native session optimization.
    """
    from prior.validity import scoped_snapshot,scoped_changed,ScopedWork
    metrics=dict(scope_builds=0,scope_build_ns=0,scope_checks=0,scope_check_ns=0,
                 items_touched=0,edge_records_scanned=0,reads_compared=0)
    def certify(case,target):
        result=reference.certify(case,target)
        if result['status']=='certified':
            started=perf_counter_ns()
            result['_scope']=scoped_snapshot(result)
            metrics['scope_build_ns']+=perf_counter_ns()-started
            metrics['scope_builds']+=1
        return result
    def validate(result,case):
        started=perf_counter_ns(); metrics['scope_checks']+=1
        if result.get('status')=='certified' and '_scope' in result:
            work=ScopedWork()
            valid=scoped_changed(result['_scope'],case,allow_eviction=False,work=work) is None
            for key in ('items_touched','edge_records_scanned','reads_compared'):
                metrics[key]+=getattr(work,key)
        else:
            valid=isinstance(result.get('reads'),dict) and reference.reads_current(result,case)
        metrics['scope_check_ns']+=perf_counter_ns()-started
        return valid
    return dict(certify=certify,validate=validate,metrics=metrics)


def build_conservative():
    """Whole-case equality control, deliberately invalidates unread metadata."""
    metrics=dict(scope_builds=0,scope_build_ns=0,scope_checks=0,scope_check_ns=0)
    current,serial=None,0
    def certify(case,target):
        nonlocal current,serial
        started=perf_counter_ns()
        if current!=case:
            current=deepcopy(case); serial+=1; metrics['scope_builds']+=1
        metrics['scope_build_ns']+=perf_counter_ns()-started
        result=reference.certify(case,target)
        result['_scope_serial']=serial
        return result
    def validate(result,case):
        started=perf_counter_ns(); metrics['scope_checks']+=1
        valid=result.get('_scope_serial')==serial and current==case
        metrics['scope_check_ns']+=perf_counter_ns()-started
        return valid
    return dict(certify=certify,validate=validate,metrics=metrics)


def _drain(session,limit):
    for _ in range(limit):
        tokens=session.work_tokens()
        if not tokens: break
        token=tokens[0]
        if session.tasks[token]['phase']=='running': session.apply(dict(op='finish',token=token))
        if token in session.tasks: session.apply(dict(op='consume',token=token))


def _exercise(name,builder,scenario,count,steps,rate,service_ns):
    started=perf_counter_ns()
    bundle=builder() if builder else {}
    build_ns=perf_counter_ns()-started
    if bundle and not callable(bundle.get('certify')):
        raise ValueError('candidate builder must provide certify callback')
    witness=make_witness(seed=731,count=count)
    # A correlated, nontrivial domain with real numeric matches and known nulls.
    for i,spec in enumerate(witness['items']):
        spec.update(pattern='flat' if i%7==0 else 'stripe',phase=0,offset=(0,5,7)[i%3])
    session=Session(witness,strategy='E' if name=='E' else 'baseline',
                    candidate=bundle.get('certify'),validator=bundle.get('validate'))
    started=perf_counter_ns()
    publish_attempts,metadata_events=0,0
    if scenario!='opening':
        for i in range(count): session.apply(dict(op='observe',item=i))
    for step in range(steps):
        target=(step*7+2)%count if scenario=='jump' else min(2,count-1)
        if scenario=='jump': session.apply(dict(op='navigate',target=target))
        # Exact fixed rates over 100 requests in full mode. Quick is a bounded
        # representative prefix; report actual mutation counts separately.
        if scenario=='mixed' and (step*rate)//100 != ((step+1)*rate)//100:
            metadata_events+=1
            session.apply(dict(op='metadata',item=count-1,orientation=3 if metadata_events%2 else 1))
        response=session.request(target)
        _drain(session,count*2)
        if response['proof']['status']!='certified': response=session.request(target)
        if response['proof']['status']=='certified':
            session.apply(dict(op='publish',target=target)); publish_attempts+=1
    elapsed=perf_counter_ns()-started
    return dict(strategy=name,scenario=scenario,metadata_rate_percent=rate,
                metadata_events=metadata_events,
                python_wall_ns=elapsed,builder_ns=build_ns,metrics=deepcopy(session.metrics),
                candidate_metrics=deepcopy(bundle.get('metrics',{})),publish_attempts=publish_attempts,
                simulated_service_ns=session.metrics['acquisition_units']*service_ns,
                simulated_service_per_unit_ns=service_ns)


def _operator_costs(count):
    witness=make_witness(seed=731,count=count)
    started=perf_counter_ns(); samples=[sample_item(x) for x in witness['items']]
    sampling=perf_counter_ns()-started
    started=perf_counter_ns()
    ranks=[score(a['edges'],b['edges']) for a,b in zip(samples,samples[1:])]
    scoring=perf_counter_ns()-started
    k=Knowledge(witness)
    for i in range(count): k.observe(i)
    case=k.case()
    started=perf_counter_ns(); units=reference.complete_plan(case)
    planning=perf_counter_ns()-started
    return dict(level='independent_python_operators',sampling_ns=sampling,scoring_ns=scoring,
                planning_ns=planning,items=count,adjacent_ranks=len(ranks),units=len(units))


def run_benchmark(candidate=None,quick=True,service_ns=1_000_000):
    """candidate is a no-argument builder with the module-level contract."""
    if service_ns<0: raise ValueError('nonnegative simulated service time required')
    count,steps=(12,10) if quick else (48,100)
    rates=[0,20,100] if quick else [0,1,5,20,100]
    strategies=[('baseline',None),('E',None),('scoped',build_scoped),('conservative',build_conservative)]
    if candidate: strategies.append(('candidate',candidate))
    runs=[]
    for name,builder in strategies:
        for scenario in ('opening','hot','jump'):
            runs.append(_exercise(name,builder,scenario,count,steps,0,service_ns))
        for rate in rates:
            runs.append(_exercise(name,builder,'mixed',count,steps,rate,service_ns))
    return dict(schema='ordered-engineering-benchmark-v1',quick=quick,seed=731,
                items=count,steps_per_scenario=steps,metadata_rates=rates,
                timing_unit='nanoseconds',service_model='injected-not-measured-not-added-to-wall',
                runs=runs,operator_costs=_operator_costs(count))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick',action='store_true')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--candidate')
    parser.add_argument('--service-ns',type=int,default=1_000_000)
    args=parser.parse_args()
    builder=None
    if args.candidate:
        module,attribute=args.candidate.split(':',1)
        builder=getattr(importlib.import_module(module),attribute)
    result=run_benchmark(builder,quick=args.quick,service_ns=args.service_ns)
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(runs=len(result['runs']),quick=args.quick)))


if __name__=='__main__': main()
