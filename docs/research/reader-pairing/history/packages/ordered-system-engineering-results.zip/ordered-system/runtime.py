"""Executable SERIAL lifecycle contract model, not a native runtime transplant.

The proof engine is the frozen reference. Knowledge uses raster-derived facts.
Task admission, promotion/refill, metadata, flags and publication below are an
explicit engineering model: no native leases, threads, codecs, persistence,
restoration transaction, memory bytes, physical cancellation or I/O are tested.
Rebind advances a logical session number in this Python object; it models a
replacement session, not pointer identity or platform ownership transfer. The
read/settled sets are a simplified logical progress projection, never task
states or proof facts. They do not claim to reproduce native progress policy.
"""
from collections import OrderedDict
from copy import deepcopy
from time import perf_counter_ns
from generator import Knowledge
import reference


class Session:
    def __init__(self,witness,strategy='baseline',capacity=16,work_capacity=2,
                 memo_capacity=4,candidate=None,validator=None):
        if work_capacity<1 or memo_capacity<1: raise ValueError('positive capacities required')
        self.knowledge=Knowledge(witness,capacity)
        self.strategy,self.candidate,self.validator=strategy,candidate,validator
        self.work_capacity,self.memo_capacity=work_capacity,memo_capacity
        self.memo,self.tasks,self.pending=OrderedDict(),OrderedDict(),OrderedDict()
        self.flags={'read':set(),'settled':set()}
        self.published={}
        self.location,self.sequence,self.session,self.serial=0,0,0,0
        self.metrics=dict(requests=0,memo_hits=0,memo_misses=0,engine_runs=0,scan_steps=0,
                          check_ns=0,recompute_ns=0,admitted=0,promoted=0,refilled=0,
                          completed=0,consumed=0,discarded=0,published=0,conflicts=0,
                          acquisition_units=0,rebinds=0)

    def _valid(self,result,case):
        if self.validator is not None: return bool(self.validator(result,case))
        reads=result.get('reads')
        return bool(isinstance(reads,dict) and 'identity' in reads and 'settings' in reads
                    and reference.reads_current(result,case))

    def _refill(self):
        while self.pending and len(self.tasks)<self.work_capacity:
            item,required=self.pending.popitem(last=False)
            self.serial+=1
            token=f'{self.session}:{self.sequence}:{self.serial}'
            self.tasks[token]=dict(item=item,required=required,phase='running',cancelled=False,
                                   session=self.session,sequence=self.sequence,
                                   version=self.knowledge.versions[item])
            self.metrics['admitted']+=1
            self.metrics['refilled']+=1

    def _demand(self,item,required=True):
        for task in self.tasks.values():
            if task['item']==item and not task['cancelled']:
                if required and not task['required']: self.metrics['promoted']+=1
                task['required'] |= required
                return
        self.pending[item]=self.pending.get(item,False) or required
        self._refill()

    def _needs(self,result):
        for need in result.get('needs',[]):
            if need['kind']=='RANK':
                for i in (need['item'],need['second']):
                    if i not in self.knowledge.samples: self._demand(i)
            elif need['kind'] in ('DIMENSIONS','ANALYSIS'): self._demand(need['item'])

    def request(self,target,strategy=None):
        self.metrics['requests']+=1
        case=self.knowledge.case()
        stored=self.memo.get(target)
        started=perf_counter_ns()
        valid=stored is not None and self._valid(stored,case)
        self.metrics['check_ns']+=perf_counter_ns()-started
        if valid:
            self.metrics['memo_hits']+=1
            result=deepcopy(stored)
        else:
            self.metrics['memo_misses']+=1
            started=perf_counter_ns()
            if self.candidate:
                result=self.candidate(case,target)
                work=result.get('steps',0)
            elif (strategy or self.strategy)=='E':
                pair=reference.certify_strategy(case,target)
                result,work=pair['selected'],pair['total_steps']
            else:
                result=reference.certify(case,target)
                work=result['steps']
            self.metrics['recompute_ns']+=perf_counter_ns()-started
            self.metrics['engine_runs']+=1
            self.metrics['scan_steps']+=work
            self.memo.pop(target,None)
            self.memo[target]=deepcopy(result)
            while len(self.memo)>self.memo_capacity: self.memo.popitem(last=False)
        self._needs(result)
        return dict(proof=deepcopy(result),memo_hit=valid,work=self.work_snapshot(),
                    publishable=result.get('status')=='certified' and self._valid(result,case))

    def work_tokens(self): return list(self.tasks)

    def work_snapshot(self):
        return dict(active={k:deepcopy(v) for k,v in self.tasks.items()},pending=dict(self.pending))

    def _cancel_all(self):
        self.pending.clear()
        for token,task in list(self.tasks.items()):
            if task['phase']=='completed': del self.tasks[token]
            else: task['cancelled']=True

    def apply(self,event):
        op=event['op']
        outcome='applied'
        if op=='request': return self.request(event.get('target',self.location),event.get('strategy'))
        if op in ('prefetch','demand'):
            self._demand(event['item'],op=='demand')
        elif op in ('finish','consume','cancel'):
            token=event['token']; task=self.tasks.get(token)
            if task is None: outcome='absent'
            elif op=='cancel':
                if task['phase']=='completed':
                    del self.tasks[token]; self._refill()
                else: task['cancelled']=True
                outcome='cancelling'
            elif op=='finish':
                if task['cancelled'] or task['session']!=self.session or task['sequence']!=self.sequence or task['version']!=self.knowledge.versions[task['item']]:
                    del self.tasks[token]; self.metrics['discarded']+=1; outcome='discarded'
                    self._refill()
                else:
                    task['phase']='completed'; task['failure']=event.get('failure')
                    self.metrics['completed']+=1; outcome='completed'
            elif task['phase']!='completed': outcome='unavailable'
            elif task['cancelled'] or task['session']!=self.session or task['sequence']!=self.sequence or task['version']!=self.knowledge.versions[task['item']]:
                del self.tasks[token]; self.metrics['discarded']+=1; self._refill(); outcome='discarded'
            else:
                if task.get('failure'): self.knowledge.fail(task['item'],task['failure'])
                else: self.knowledge.observe(task['item'])
                self.metrics['acquisition_units']+=1
                self.metrics['consumed']+=1
                del self.tasks[token]; self._refill(); outcome='consumed'
        elif op=='observe':
            self.knowledge.observe(event['item']); self.metrics['acquisition_units']+=1
        elif op=='fail': self.knowledge.fail(event['item'],event.get('reason','READ'))
        elif op=='evict': self.knowledge.evict(event['item'])
        elif op=='flag':
            for flag in ('read','settled'):
                if flag in event:
                    if event[flag]: self.flags[flag].add(event['item'])
                    else: self.flags[flag].discard(event['item'])
        elif op=='navigate':
            self.location=event['target']; self.sequence+=1; self.memo.clear(); self._cancel_all()
            outcome='navigated'
        elif op=='metadata':
            item=event['item']
            # Same underlying content version; metadata alters typed identity.
            spec=self.knowledge.witness['items'][item]
            for key in ('orientation','rotation'):
                if key in event: spec[key]=event[key]
            self.knowledge.samples.pop(item,None); self.knowledge.analyses.pop(item,None)
            self.knowledge.failures.pop(item,None)
            for a in (item-1,item): self.knowledge.ranks.pop(a,None)
            for task in self.tasks.values():
                if task['item']==item: task['cancelled']=True
            # Publication is immutable: metadata cannot revise an exposed unit.
            outcome='metadata_confirmed'
        elif op=='rebind':
            item=event['item']
            visible=any(any(slot['item']==item for slot in unit['slots']) for unit in self.published.values())
            if visible and not event.get('reload',False): outcome='visible_conflict'
            else:
                self._cancel_all(); self.knowledge.invalidate(item,event.get('spec'))
                self.session+=1; self.memo.clear(); self.metrics['rebinds']+=1
                if event.get('reload',False): self.published.clear()
                outcome='rebound'
        elif op=='publish':
            target=event['target']; result=self.memo.get(target)
            case=self.knowledge.case()
            if result is None or result.get('status')!='certified' or not self._valid(result,case): outcome='unproved'
            else:
                unit=result['unit']
                previous=self.published.get(target)
                overlap=[u for u in self.published.values() if any(a['item']==b['item'] for a in u['slots'] for b in unit['slots'])]
                if (previous is not None and previous!=unit) or any(u!=unit for u in overlap):
                    self.metrics['conflicts']+=1; outcome='conflict'
                else:
                    self.published[target]=deepcopy(unit); self.metrics['published']+=1; outcome='published'
        else: raise ValueError('unknown lifecycle event')
        return dict(outcome=outcome,session=self.session,work=self.work_snapshot())
