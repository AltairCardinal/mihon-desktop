"""Turn lowcost/results/*.json into markdown tables (lowcost/results/TABLES.md)."""
import json
from pathlib import Path

R = Path(__file__).resolve().parent / 'results'


def ms(x):
    return f'{x / 1e6:.2f}'


def ext_tables():
    d = json.loads((R / 'ext_full.json').read_text())
    rows = d['rows']
    scen = []
    for r in rows:
        if r['scenario'] not in scen:
            scen.append(r['scenario'])
    strategies = ['baseline', 'E', 'scoped', 'fast_global', 'fast', 'bx', 'bx_pivot', 'bx_beta', 'prior_sl']
    out = ['### 会话总成本（本机实测墙钟中位数，ms；3 次重复）', '',
           '| 场景 | ' + ' | '.join(strategies) + ' |', '|' + '---|' * (len(strategies) + 1)]
    for s in scen:
        cells = []
        for st in strategies:
            r = next((x for x in rows if x['scenario'] == s and x['strategy'] == st), None)
            cells.append(ms(r['wall_ns_median']) if r else 'N/A')
        out.append(f'| {s} | ' + ' | '.join(cells) + ' |')
    out += ['', '### 引擎重算 + 校验（本机实测中位数，ms）', '',
            '| 场景 | ' + ' | '.join(strategies) + ' |', '|' + '---|' * (len(strategies) + 1)]
    for s in scen:
        cells = []
        for st in strategies:
            r = next((x for x in rows if x['scenario'] == s and x['strategy'] == st), None)
            cells.append(f"{ms(r['recompute_ns_median'])}+{ms(r['check_ns_median'])}" if r else 'N/A')
        out.append(f'| {s} | ' + ' | '.join(cells) + ' |')
    out += ['', '### 取证、轮次与模拟等待（模型计数；sim_wait 为注入的 1 ms/批，未计入墙钟）', '',
            '| 场景 | 策略 | 取证 | 轮次 | 模拟等待 ms | 发布 | 错发 | 冲突 | 未决 | 命中/引擎运行 | BX 尝试/采纳/驳倒/超预算 |',
            '|---|---|---|---|---|---|---|---|---|---|---|']
    for s in scen:
        for st in strategies:
            r = next((x for x in rows if x['scenario'] == s and x['strategy'] == st), None)
            if not r:
                continue
            c = r['candidate']
            bx = (f"{c.get('bx_attempts', 0)}/{c.get('bx_adopted', 0)}/{c.get('bx_refuted', 0)}/{c.get('bx_budget', 0)}"
                  if 'bx_attempts' in c else '-')
            out.append(f"| {s} | {st} | {r['acquisitions']} | {r['rounds_total']} | {ms(r['sim_wait_ns'])} | "
                       f"{r['published']} | {r['wrong']} | {r['conflicts']} | {r['undecided']} | "
                       f"{r['memo_hits']}/{r['engine_runs']} | {bx} |")
    return out


def std_tables():
    pb, pf = R / 'std_full_bx.json', R / 'std_full_fast.json'
    if not pb.exists():
        return []
    rows = []
    for r in json.loads(pb.read_text())['runs']:
        rows.append(('build_bx' if r['strategy'] == 'candidate' else r['strategy'], r))
    if pf.exists():
        rows += [('build_fast', r) for r in json.loads(pf.read_text())['runs'] if r['strategy'] == 'candidate']
    out = ['', '### 包内固定基准 benchmark.py 完整配置（48 对象 × 100 步；本机实测，ms）', '',
           '默认四策略取自 build_bx 那次运行；build_fast 是单独一次运行的候选行。', '',
           '| 策略 | 场景 | 元数据% | 墙钟 | 校验 | 重算 | 命中 | 引擎运行 | 取证 | 发布 |',
           '|---|---|---|---|---|---|---|---|---|---|']
    for name, r in rows:
        m = r['metrics']
        out.append(f"| {name} | {r['scenario']} | {r['metadata_rate_percent']} | {ms(r['python_wall_ns'])} | "
                   f"{ms(m['check_ns'])} | {ms(m['recompute_ns'])} | {m['memo_hits']} | {m['engine_runs']} | "
                   f"{m['acquisition_units']} | {m['published']} |")
    return out


def verify_tables():
    p = R / 'verify.json'
    if not p.exists():
        return []
    d = json.loads(p.read_text())
    c = d['core']
    out = ['', '### 有限域验证', '',
           f"- 编译核心 vs reference.certify：扩展域 {c['extension']} 组、生成域 {c['generator']} 组、golden {c['golden']} 组；"
           f"不一致 {c['extension_mismatch'] + c['generator_mismatch'] + c['golden_mismatch']}。", '',
           '| 种子 | 域 | 模式 | 非负 | 秩聚焦 | 实例 | 截断跳过 | oracle 唯一 | 参考 | 旧 C-SL | BX | 错签 | 驳倒 | 错误驳倒 | 超预算 | 支配违例 | BX 步 | 旧 C-SL 步 |',
           '|' + '---|' * 18]
    for s in d['bx']:
        out.append(f"| {s['seed']} | {'合法' if s['legal'] else '接口'} | {s['mode']} | {s['nonneg']} | {s['focus']} | {s['n']} | "
                   f"{s['truncated']} | {s['oracle_unique']} | {s['ref']} | {s['prior_sl']} | {s['bx']} | {s['unsound']} | "
                   f"{s['refuted']} | {s['wrong_refutation']} | {s['budget']} | {s['dominance_ref'] + s['dominance_sl']} | "
                   f"{s['bx_steps']} | {s['prior_sl_steps']} |")
    return out


def scale_tables():
    p = R / 'scale.json'
    if not p.exists():
        return []
    d = json.loads(p.read_text())
    out = ['', '### 长输入证明失败成本（本机实测，单次调用：最小墙钟 ms / tracemalloc 峰值 KiB / 结论）', '',
           '| 族 | n | reference | fastcore | 旧 C-SL | BX |', '|---|---|---|---|---|---|']
    for r in d:
        cells = []
        for k in ('ref', 'fast', 'priorSL', 'BX'):
            v = r.get(k)
            cells.append('N/A（无预算，未跑）' if v is None else f"{v['ms']:.2f} / {v['kib']:.0f} / {v['status']}")
        out.append(f"| {r['kind']} | {r['n']} | " + ' | '.join(cells) + ' |')
    return out


def stamp_tables():
    p = R / 'stamps.json'
    if not p.exists():
        return []
    d = json.loads(p.read_text())
    out = ['', '### 单请求重验成本（本机实测中位数，µs；热知识、已认证目标）', '',
           '| n | 证明位置/读 | 构建 case | 参考校验 | 指纹校验 | 戳快路径 | 参考认证 | 编译认证 |',
           '|---|---|---|---|---|---|---|---|']
    for r in d:
        out.append(f"| {r['n']} | {r['proof_positions']}/{r['proof_reads']} | {r['case_build_ns']/1e3:.0f} | "
                   f"{r['ref_validate_ns']/1e3:.0f} | {r['fp_validate_ns']/1e3:.1f} | {r['stamp_check_ns']/1e3:.2f} | "
                   f"{r['ref_certify_ns']/1e3:.0f} | {r['fast_certify_ns']/1e3:.0f} |")
    return out


def acq_tables():
    p = R / 'acq.json'
    if not p.exists():
        return []
    d = json.loads(p.read_text())
    s = d['summary']
    names = ('REF', 'BX_REF', 'BX_PIVOT', 'BX_PIVOT1')
    out = ['', f"### 取证策略（抽象域冷启动，{d['worlds']} 个世界，种子 {d['seed']}；模型计数）", '',
           '| 策略 | 轮次 | 分析 | 秩 | 认证 | 超出下界（已解世界） |', '|---|---|---|---|---|---|']
    for n in names:
        x = s[n]
        out.append(f"| {n} | {x['rounds']} | {x['analyses']} | {x['ranks']} | {x['certified']} | "
                   f"{x['excess_over_lb']}（{x['lb_resolved']}） |")
    out += ['', '成本 J = 分析 + cR·秩 + L·轮次（cA=1）下的最优策略：', '',
            '| cR | L | ' + ' | '.join(names) + ' | 最优 |', '|---|---|' + '---|' * (len(names) + 1)]
    for g in s['sensitivity_cA_1']:
        out.append(f"| {g['cR']} | {g['L']} | " + ' | '.join(f"{g['costs'][n]:.0f}" for n in names) + f" | {g['best']} |")
    return out


if __name__ == '__main__':
    parts = ['# 结果表（由 lowcost/summarize.py 从 results/*.json 生成）', '']
    for fn in (verify_tables, scale_tables, stamp_tables, ext_tables, std_tables, acq_tables):
        try:
            parts += fn()
        except FileNotFoundError:
            pass
    (R / 'TABLES.md').write_text('\n'.join(parts) + '\n', encoding='utf-8')
    print('\n'.join(parts)[:3000])
