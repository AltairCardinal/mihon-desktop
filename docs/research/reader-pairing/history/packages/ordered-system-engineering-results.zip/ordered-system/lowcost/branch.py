"""Branching certification v2 (BX): stronger proofs at bounded, linear cost.

Differences from prior/branching.certify_sl (same decision rule, reference._Scan):

1. Comparison-level rank branching.  By Lemma R (rank comparisons along one
   scan path use pairwise disjoint edge pairs and a step consumes ranks only
   through the boolean of one comparison), an unknown rank is branched over at
   most two representatives that realise the two comparison outcomes, instead
   of a value grid.
2. No per-state read-set accumulation.  Reachability memoises only the set of
   target units reachable from a state, capped at "ambiguous"; the support of
   a certificate is collected once, for the certifying window only.  This
   removes the O(t^2) set copying that dominated the historical cost.
3. One scan object per expansion attempt is replaced by one reusable scan with
   a cleared manual cache; branching restarts only the current step.
4. Exact refutation.  When a window is ambiguous, an anchored path-sensitive
   probe fixes unknown facts left of an anchor to a default world and branches
   the rest; two different units found there are two genuine worlds, so the
   request is provably not certifiable now and window extension stops.  With
   the anchor at 0 the probe is the exact path-sensitive certifier.
5. A deterministic operation budget counts every step attempt, including
   attempts aborted by a branch.  Exhaustion returns need_facts with
   reason='budget' and never a certificate.

Modes: 'alpha' (valid headers fix the occupancy state) or 'beta' (headers
ignored for items without a valid analysis).  Non-negative rank premise is an
explicit flag (default off).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402
from lowcost.fastcore import Index, _geometry_t  # noqa: E402

STATES = ('NARROW', 'WIDE')
SIDES = ('A', 'B', 'UNKNOWN')


class Branch(Exception):
    __slots__ = ('key', 'options')

    def __init__(self, key, options):
        self.key, self.options = key, options


class BudgetExhausted(Exception):
    pass


class Work:
    """Operation counts of one call (all attempts, accepted or not)."""
    __slots__ = ('steps', 'branch_nodes', 'leaves', 'expansions', 'windows', 'probe_steps',
                 'probes', 'budget', 'support')

    def __init__(self, budget):
        self.steps = self.branch_nodes = self.leaves = self.expansions = 0
        self.windows = self.probe_steps = self.probes = self.support = 0
        self.budget = budget

    def tick(self, k=1):
        self.steps += k
        if self.budget is not None and self.steps > self.budget:
            raise BudgetExhausted()

    def as_dict(self):
        return {k: getattr(self, k) for k in self.__slots__}


class Facts:
    """Known facts under a mode, parsed lazily from an Index."""
    __slots__ = ('ix', 'mode', 'nonneg', '_state', '_side', '_rank', '_valid')

    def __init__(self, ix, mode='alpha', nonneg=False):
        self.ix, self.mode, self.nonneg = ix, mode, nonneg
        self._state, self._side, self._rank, self._valid = {}, {}, {}, {}

    def valid(self, i):
        v = self._valid.get(i)
        if v is None:
            a = self.ix.analysis(i)
            ident = self.ix.ident(i)
            v = (a[0] == 'computed' and a[1] is not None and _geometry_t(a[1])
                 and a[1][3] == ident[2] and a[1][4] == ident[3])
            self._valid[i] = v
        return v

    def state(self, i):
        """Known occupancy state or None."""
        if i in self._state:
            return self._state[i]
        s = None
        if self.valid(i):
            s = self.ix.analysis(i)[1][0]
        elif self.mode == 'alpha':
            h = self.ix.header(i)
            ident = self.ix.ident(i)
            if h is not None and _geometry_t(h) and h[3] == ident[2] and h[4] == ident[3]:
                s = h[0]
        self._state[i] = s
        return s

    def side(self, i):
        if i not in self._side:
            self._side[i] = self.ix.analysis(i)[1][5] if self.valid(i) else None
        return self._side[i]

    def rank(self, j):
        """('known', value) when visible through two valid NARROW analyses."""
        r = self._rank.get(j)
        if r is None:
            r = ('free',)
            if self.valid(j) and self.valid(j + 1):
                e = self.ix.edge(j, j + 1)
                if e[0] == 'computed' and self.state(j) == 'NARROW' and self.state(j + 1) == 'NARROW':
                    r = ('known', e[1])
            self._rank[j] = r
        return r

    def failed(self, kind, x):
        if kind == 'item':
            a = self.ix.analysis(x)
            return a[1] if a[0] == 'failed' else None
        e = self.ix.edge(x, x + 1) if self.valid(x) and self.valid(x + 1) else None
        return e[1] if e is not None and e[0] == 'failed' else None


class View:
    """Fact access with a path assignment; branches lazily on unknowns."""
    __slots__ = ('F', 'asg', 'reads', 'cmp_base')

    def __init__(self, F, reads):
        self.F, self.asg, self.reads, self.cmp_base = F, {}, reads, None

    def state(self, i):
        self.reads.add(('S', i))
        s = self.F.state(i)
        if s is not None:
            return s
        v = self.asg.get(('S', i))
        if v is None:
            raise Branch(('S', i), STATES)
        return v

    def side(self, i):
        self.reads.add(('D', i))
        s = self.F.side(i)
        if s is not None:
            return s
        v = self.asg.get(('D', i))
        if v is None:
            raise Branch(('D', i), SIDES)
        return v

    def _value(self, j):
        r = self.F.rank(j)
        if r[0] == 'known':
            return True, r[1]
        key = ('R', j)
        if key in self.asg:
            return True, self.asg[key]
        return False, None

    def rank(self, j):
        a, b = self.state(j), self.state(j + 1)
        self.reads.add(('R', j))
        if 'WIDE' in (a, b):
            return None
        known, v = self._value(j)
        if known:
            return v
        # Representatives realising both outcomes of the single comparison
        # (later edge b=j' strictly below near edge a) this edge takes part in.
        base = self.cmp_base
        if base is not None and j == base:            # near operand a (read first)
            okb, vb = self._value(j + 1)
            if okb:
                opts = (None,) if vb is None else (None, vb)   # None -> later wins; vb -> it does not
            else:
                opts = (None, 1)                      # b branches next, relative to this value
        elif base is not None and j == base + 1:      # later operand b
            oka, va = self._value(j - 1)
            if not oka or va is None:
                opts = (None, 0)                      # a is null: outcome is "b is not null"
            elif self.F.nonneg:
                opts = (None, va / 2) if va > 0 else (None,)
            else:
                opts = (None, va - 1)
        else:                                         # never reached (Lemma R); conservative
            opts = (None, 0, 1, 2)
        raise Branch(('R', j), opts)


def _make_scan(n, settings, view):
    def dimension(i):
        return {'state': view.state(i)} if 0 <= i < n else None

    def side(i):
        return view.side(i)

    def distance(a, b):
        return view.rank(a)
    return ref._Scan(n, settings, dimension, side, side, distance)


def _expand(F, settings, n, fn, work, reads, cmp_base):
    """All results of fn(scan) over lazily branched local assignments."""
    outs, stack = [], [{}]
    view = View(F, reads)
    view.cmp_base = cmp_base
    scan = _make_scan(n, settings, view)
    while stack:
        asg = stack.pop()
        view.asg = asg
        scan.manual_cache.clear()
        try:
            outs.append(fn(scan))
            work.leaves += 1
        except Branch as b:
            work.branch_nodes += 1
            for v in b.options:
                child = dict(asg)
                child[b.key] = v
                stack.append(child)
    work.expansions += 1
    return outs


def _entries(first, target, isolated, forced):
    if first == 0:
        return [((0, True, False), None)]
    if isolated and first == target:
        return [((first, True, False), None), ((first, False, False), None)]
    out = []
    boundary_free = first - 1 not in forced and first not in forced
    for opening in ([True] if first == 1 else [True, False]):
        out.append(((first, opening, False), None))
        if first > 1 and boundary_free:
            out.append(((first, opening, True), 'reserved'))
    if boundary_free:
        out.append(((first + 1, False, False), 'paired'))
    return out


def _unit_key(unit):
    return repr(sorted((k, repr(v)) for k, v in unit.items()))


AMBIG = 'AMBIG'


class Engine:
    """State graph of one (case, target); shared by all windows and probes."""

    def __init__(self, case, target, mode='alpha', nonneg=False, budget=None, index=None):
        self.ix = index if index is not None else Index(case)
        self.F = Facts(self.ix, mode, nonneg)
        self.n, self.target = self.ix.n, target
        self.settings = self.ix.settings
        self.forced = set(self.settings['hard_isolates'])
        self.work = Work(budget)
        self.succ = {}        # state -> (frozenset unit keys, tuple successors)
        self.reads_of = {}    # state -> frozenset of reads of its expansion
        self.units = {}       # unit key -> unit
        self.reach = {}       # state -> frozenset(unit keys) | AMBIG
        self.pre = {}

    # -- one state ----------------------------------------------------------
    def expand(self, state):
        got = self.succ.get(state)
        if got is not None:
            return got
        i, opening, reserved = state
        target, work = self.target, self.work

        def one(scan):
            work.tick()
            return scan.step((i, opening, i if reserved else -1),
                             include_single=i == target, include_pair=i + 1 >= target)
        reads = set()
        outs = _expand(self.F, self.settings, self.n, one, work, reads, cmp_base=i)
        found, nxt = set(), set()
        for unit, cur in outs:
            if unit is not None and any(s['item'] == target for s in unit['slots']):
                k = _unit_key(unit)
                self.units[k] = unit
                found.add(k)
            else:
                nxt.add((cur[0], cur[1], cur[2] == cur[0]))
        got = (frozenset(found), tuple(sorted(nxt)))
        self.succ[state] = got
        self.reads_of[state] = frozenset(reads)
        return got

    def prereq(self, first, kind):
        key = (first, kind)
        if key not in self.pre:
            reads = set()

            def fn(scan):
                self.work.tick()
                if not scan.allowed(first - 1):
                    return False
                return scan.later_wins(first - 1) if kind == 'reserved' else True
            outs = _expand(self.F, self.settings, self.n, fn, self.work, reads, cmp_base=first - 1)
            self.pre[key] = (any(outs), frozenset(reads))
        return self.pre[key]

    def reach_units(self, state):
        """Target units reachable from state ('NONE' if the target is skipped),
        or AMBIG once two are known.  Iterative, memoised, O(1) per state."""
        if state in self.reach:
            return self.reach[state]
        stack, order = [state], []
        while stack:
            s = stack.pop()
            if s in self.reach:
                continue
            order.append(s)
            for t in self.expand(s)[1]:
                if t[0] <= self.target and t not in self.reach:
                    stack.append(t)
        for s in sorted(set(order), key=lambda x: -x[0]):
            found, nxt = self.expand(s)
            acc = set(found)
            for t in nxt:
                if t[0] > self.target:
                    acc.add('NONE')
                else:
                    sub = self.reach[t]
                    if sub is AMBIG:
                        acc = AMBIG
                        break
                    acc |= sub
                if len(acc) > 1:
                    acc = AMBIG
                    break
            self.reach[s] = AMBIG if acc is AMBIG or len(acc) > 1 else frozenset(acc)
        return self.reach[state]

    def window(self, first, isolated):
        """(unit key or None, live entries)."""
        units, live = set(), []
        for state, pre in _entries(first, self.target, isolated, self.forced):
            if pre is not None and not self.prereq(first, pre)[0]:
                continue
            live.append((state, pre))
            got = self.reach_units(state)
            if got is AMBIG:
                return None, live
            units |= got
            if len(units) > 1:
                return None, live
        if len(units) == 1 and 'NONE' not in units:
            return next(iter(units)), live
        return None, live

    def support(self, first, live, isolated):
        """Every fact the window certificate depends on, collected once:

        * the occupancy state of the target (it decides `isolated`, i.e. which
          entry set is used);
        * the prerequisite reads of EVERY entry of the window, including the
          entries that were pruned -- the facts that made an entry impossible
          are part of the proof (review finding: dropping them let a changed
          item left of the window keep a stale certificate);
        * the expansion reads of every state reachable from a live entry.
        """
        reads, seen = {('S', self.target)}, set()
        for state, pre in _entries(first, self.target, isolated, self.forced):
            if pre is not None:
                reads |= self.pre[(first, pre)][1]
        for state, pre in live:
            stack = [state]
            while stack:
                s = stack.pop()
                if s in seen or s[0] > self.target:
                    continue
                seen.add(s)
                reads |= self.reads_of[s]
                stack.extend(self.succ[s][1])
        return reads


# ------------------------------------------------------------- refutation ----
def _default_world(F, n, i):
    s = F.state(i)
    return s if s is not None else 'NARROW'


def probe(engine, anchor, limit=2, cap=None):
    """Anchored path-sensitive probe from the exact start.

    Unknown facts at positions < anchor are fixed to a default world; unknown
    facts at positions >= anchor are branched lazily with path memory.  Returns
    (set of unit keys found, leaves explored, pivot keys) and stops after
    `limit` distinct units.  Every leaf is a complete world consistent with K,
    so two distinct units are an exact refutation; with anchor == 0 an
    exhaustive run with one unit is an exact path-sensitive certificate.
    """
    F, n, target, work = engine.F, engine.n, engine.target, engine.work
    work.probes += 1
    reads = set()
    view = View(F, reads)
    defaults = {}

    def fixed(key):
        kind, x = key
        if kind == 'S':
            return 'NARROW'
        if kind == 'D':
            return 'UNKNOWN'
        return None
    scan = _make_scan(n, engine.settings, view)
    found, leaves, witnesses = {}, 0, {}
    # stack entries: (assignment, cursor to restart from).  A branch raised in
    # step k leaves steps < k unaffected (they never read the new key), so the
    # children restart at step k instead of at position 0.
    stack = [({}, (0, True, -1))]
    local = 0
    cap = cap if cap is not None else 16 * (target + 6)
    complete = True
    while stack:
        if local > cap:
            complete = False
            break
        asg, cursor = stack.pop()
        view.asg = asg
        result = None
        try:
            while cursor[0] <= target:
                i = cursor[0]
                view.cmp_base = i
                scan.manual_cache.clear()
                work.tick()
                work.probe_steps += 1
                local += 1
                unit, nxt = scan.step(cursor, include_single=i == target, include_pair=i + 1 >= target)
                cursor = nxt
                if unit is not None and any(s['item'] == target for s in unit['slots']):
                    result = unit
                    break
        except Branch as b:
            work.branch_nodes += 1
            pos = b.key[1]
            if pos < anchor:
                child = dict(asg)
                child[b.key] = fixed(b.key)
                defaults[b.key] = child[b.key]
                stack.append((child, cursor))
            else:
                for v in b.options:
                    child = dict(asg)
                    child[b.key] = v
                    stack.append((child, cursor))
            continue
        leaves += 1
        k = _unit_key(result) if result is not None else 'NONE'
        if k not in found:
            found[k] = result
            witnesses[k] = dict(asg)
        if len(found) >= limit:
            break
    pivots = set()
    if len(witnesses) >= 2:
        (k1, a1), (k2, a2) = list(witnesses.items())[:2]
        for key in set(a1) | set(a2):
            if a1.get(key) != a2.get(key):
                pivots.add(key)
    return found, leaves, pivots, reads, complete


def sample_refute(engine, samples=6, seed=0):
    """Random complete-world probes (concrete scans with lazily drawn values).

    Each sample is one world consistent with K, so two different target units
    are an exact refutation.  Inconclusive results prove nothing."""
    import random
    F, n, target, work = engine.F, engine.n, engine.target, engine.work
    rng = random.Random(seed * 1000003 + target)
    reads = set()
    view = View(F, reads)
    scan = _make_scan(n, engine.settings, view)
    found, witnesses = {}, {}
    for _ in range(samples):
        view.asg = asg = {}
        cursor = (0, True, -1)
        result = None
        while cursor[0] <= target:
            i = cursor[0]
            view.cmp_base = i
            while True:
                scan.manual_cache.clear()
                work.tick()
                work.probe_steps += 1
                try:
                    unit, nxt = scan.step(cursor, include_single=i == target, include_pair=i + 1 >= target)
                    break
                except Branch as b:
                    asg[b.key] = rng.choice(b.options)
            cursor = nxt
            if unit is not None and any(s_['item'] == target for s_ in unit['slots']):
                result = unit
                break
        k = _unit_key(result) if result is not None else 'NONE'
        if k not in found:
            found[k], witnesses[k] = result, dict(asg)
        if len(found) >= 2:
            break
    pivots = set()
    if len(witnesses) >= 2:
        (k1, a1), (k2, a2) = list(witnesses.items())[:2]
        pivots = {key for key in set(a1) | set(a2) if a1.get(key) != a2.get(key)}
    work.probes += 1
    return found, pivots, reads


# ---------------------------------------------------------------- driver ----
def certify(case, target, lookbehind=2, mode='alpha', nonneg=False, budget=4000,
            refute=True, samples=4, index=None):
    """Branching certification under `mode`.

    Order of work for an ambiguous request:
      1. window proof at the reference start window (C-SL style, memoised);
      2. on ambiguity, once: near-anchored exact probe (anchor = start-1,
         capped), then `samples` random-world probes; two different units from
         either is an exact refutation and stops the call;
      3. otherwise extend the window (each extension expands only new states);
      4. at first == 0 and still ambiguous: anchor-0 path-sensitive probe,
         which is an exact certificate when it completes under its cap.
    Returns status certified | need_facts with reason window | probe |
    refuted | exhausted_windows | budget."""
    engine = Engine(case, target, mode, nonneg, budget, index)
    F, work = engine.F, engine.work
    isolated = F.state(target) == 'WIDE' or target in engine.forced
    first = target if isolated else max(0, target - lookbehind)
    pivots, sampled = set(), False
    extra_reads = set()
    try:
        if refute:
            # 1. cheap exact refutation near the target: the prefix left of the
            #    anchor is one default path (checkpointed), only the window
            #    region is branched; capped.
            anchor = max(0, first - 1)
            found, _, piv, preads, complete = probe(engine, anchor=anchor,
                                                    cap=(anchor + 1) + 8 * (target - anchor + 4))
            extra_reads |= preads
            if len(found) >= 2:
                return _out('need_facts', None, first, work, extra_reads, engine, piv, 'refuted')
            if anchor == 0 and complete and len(found) == 1 and 'NONE' not in found:
                k = next(iter(found))
                work.support = len(preads)
                return _out('certified', found[k], 0, work, preads, engine, pivots, 'probe')
        while True:
            work.windows += 1
            key, live = engine.window(first, isolated)
            if key is not None:
                reads = engine.support(first, live, isolated)
                work.support = len(reads)
                return _out('certified', engine.units[key], first, work, reads, engine, pivots, 'window')
            if refute and samples and not sampled:
                # 2. random complete worlds (all unknowns drawn lazily)
                sampled = True
                found, piv, sreads = sample_refute(engine, samples)
                extra_reads |= sreads
                if len(found) >= 2:
                    return _out('need_facts', None, first, work, extra_reads | _all_reads(engine), engine,
                                piv, 'refuted')
            if first == 0:
                if refute:
                    # 3. exact path-sensitive run from the exact start (capped)
                    found, _, piv, preads, complete = probe(engine, anchor=0)
                    extra_reads |= preads
                    if len(found) >= 2:
                        return _out('need_facts', None, 0, work, extra_reads | _all_reads(engine), engine,
                                    piv, 'refuted')
                    if len(found) == 1 and complete and 'NONE' not in found:
                        k = next(iter(found))
                        work.support = len(preads)
                        return _out('certified', found[k], 0, work, preads, engine, pivots, 'probe')
                return _out('need_facts', None, 0, work, extra_reads | _all_reads(engine), engine,
                            pivots, 'exhausted_windows')
            first -= 1
    except BudgetExhausted:
        return _out('need_facts', None, first, work, extra_reads | _all_reads(engine), engine,
                    pivots, 'budget')


def _all_reads(engine):
    out = set()
    for r in engine.reads_of.values():
        out |= r
    for _, r in engine.pre.values():
        out |= r
    return out


def _out(status, unit, first, work, reads, engine, pivots, reason):
    return dict(status=status, unit=unit, first=first, reason=reason, work=work.as_dict(),
                support=sorted(reads), pivots=sorted(pivots),
                extra_failures=_failures(engine, reads))


def _failures(engine, reads):
    out = {}
    for kind, x in reads:
        if kind in ('S', 'D'):
            f = engine.F.failed('item', x)
            if f is not None:
                out[f'item:{x}'] = f
        else:
            f = engine.F.failed('edge', x)
            if f is not None:
                out[f'edge:{x}'] = f
    return out
