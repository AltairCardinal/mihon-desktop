"""Candidate adapters for benchmark.py (`--candidate lowcost.candidates:<builder>`).

Builders (each returns dict(certify, validate, metrics)):

  build_fast_global   compiled exact core; validation compares the WHOLE identity
                      list plus every read fingerprint (same strictness as the
                      reference read set).  Isolates the representation gain.
  build_fast          compiled exact core + scoped fingerprint proof
                      (certified: scoped, refinement tolerant; pending: strict).
  build_bx            build_fast + BX branching stage on need_facts, under the
                      reference failure contract (blocked/certified returned
                      unchanged; only a BX certificate is adopted).
  build_bx_beta       same, header-non-authoritative mode (branch beta).
  build_bx_pivot      build_bx, but a refuted request demands only the pivot
                      facts of the refutation (acquisition-policy experiment).

Mode statement: build_fast*, build_bx and build_bx_pivot are valid only where
header geometry is authoritative (alpha).  The generator domain satisfies
alpha by construction (header and analysis derive from the same geometry);
no host claim is made.  build_bx_beta never relies on headers.
"""
from time import perf_counter_ns
from lowcost import fastcore, proof, branch


def _metrics():
    return dict(certify_calls=0, certify_ns=0, validate_calls=0, validate_ns=0,
                validate_positions=0, validate_reads=0, invalid=0,
                bx_attempts=0, bx_adopted=0, bx_refuted=0, bx_budget=0, bx_exhausted=0,
                bx_ns=0, bx_steps=0, bx_probe_steps=0, proof_reads_total=0, proof_build_ns=0)


def _strip_headers(case):
    """Branch beta view: headers cannot stand in for missing/invalid analyses."""
    items = []
    for i, item in enumerate(case['items']):
        a = item.get('analysis', {'status': 'unknown'})
        keep = False
        if a.get('status') == 'computed' and a.get('fact') is not None:
            f = fastcore._fact_tuple(a['fact'])
            keep = (fastcore._geometry_t(f) and f[3] == item.get('rotation', 0)
                    and f[4] == item.get('orientation', 1))
        if keep or 'header' not in item:
            items.append(item)
        else:
            items.append({k: v for k, v in item.items() if k != 'header'})
    out = dict(case)
    out['items'] = items
    return out


def _bx_proof(index, support, mode, extra_reads=None):
    reads = {}
    for kind, x in support:
        if kind == 'S':
            a = index.analysis(x)
            reads[('analysis', x)] = a
            if mode == 'alpha':
                # alpha may take the state from the header even when a computed
                # analysis exists but is stale/invalid, so the header is always
                # part of the proof (review finding).
                reads[('header', x)] = index.header(x)
                f = index.effective(x)
                reads[('dimension', x)] = (f[:5] + ('UNKNOWN',)) if f else None
        elif kind == 'D':
            reads[('analysis', x)] = index.analysis(x)
        else:
            reads[('rank', x, x + 1)] = index.edge(x, x + 1)
            reads[('analysis', x)] = index.analysis(x)
            reads[('analysis', x + 1)] = index.analysis(x + 1)
    if extra_reads:
        for k, v in extra_reads:
            reads.setdefault(k, v)
    return reads


def _build(branching, mode='alpha', needs_policy='reference', budget=4000, global_identity=False):
    metrics = _metrics()

    def certify(case, target):
        started = perf_counter_ns()
        view = case if mode == 'alpha' else _strip_headers(case)
        index = fastcore.Index(view)
        result = fastcore.certify(view, target, index=index)
        metrics['certify_calls'] += 1
        if branching and result['status'] == 'need_facts':
            metrics['bx_attempts'] += 1
            t0 = perf_counter_ns()
            bx = branch.certify(view, target, mode=mode, budget=budget, index=index)
            metrics['bx_ns'] += perf_counter_ns() - t0
            metrics['bx_steps'] += bx['work']['steps']
            metrics['bx_probe_steps'] += bx['work']['probe_steps']
            result['bx'] = dict(status=bx['status'], reason=bx['reason'], work=bx['work'])
            t1 = perf_counter_ns()
            if bx['status'] == 'certified':
                metrics['bx_adopted'] += 1
                reads = _bx_proof(index, bx['support'], mode)
                result = dict(status='certified', unit=bx['unit'], needs=[], failures={},
                              first=bx['first'], steps=result['steps'] + bx['work']['steps'],
                              dependent_items=sorted({k[1] for k in bx['support']}),
                              extra_failures=bx['extra_failures'],
                              proof=fastcore.make_proof(index, reads, 'certified', mode))
            else:
                metrics['bx_refuted'] += bx['reason'] == 'refuted'
                metrics['bx_budget'] += bx['reason'] == 'budget'
                metrics['bx_exhausted'] += bx['reason'] == 'exhausted_windows'
                # pending verdict: strict over everything either stage read
                old = dict(result['proof'][2])
                reads = _bx_proof(index, bx['support'], mode, extra_reads=old.items())
                result['proof'] = fastcore.make_proof(index, reads, 'need_facts', mode)
                result['steps'] += bx['work']['steps']
                if needs_policy == 'pivot' and bx['reason'] == 'refuted' and bx['pivots']:
                    result['needs'] = _pivot_needs(bx['pivots'])
            metrics['proof_build_ns'] += perf_counter_ns() - t1
        metrics['proof_reads_total'] += len(result['proof'][2])
        metrics['certify_ns'] += perf_counter_ns() - started
        return result

    def validate(result, case):
        started = perf_counter_ns()
        metrics['validate_calls'] += 1
        pr = result.get('proof')
        if pr is None:
            ok = False
        else:
            view = case if mode == 'alpha' else _strip_headers(case)
            work = proof.CheckWork()
            index = fastcore.Index(view, check_ids=False) if not case.get('closed', False) else None
            ok = proof.first_violation(pr, view, index=index, work=work) is None
            if ok and global_identity:
                ok = _global_identity(index) == result.get('_identity')
            metrics['validate_positions'] += work.positions
            metrics['validate_reads'] += work.reads
        metrics['invalid'] += not ok
        metrics['validate_ns'] += perf_counter_ns() - started
        return ok

    if global_identity:
        inner = certify

        def certify(case, target):  # noqa: F811
            r = inner(case, target)
            r['_identity'] = _global_identity(fastcore.Index(case))
            # strict on certified too: same strictness as the reference read set
            p = r['proof']
            r['proof'] = (p[0], p[1], p[2], False, p[4])
            return r

    return dict(certify=certify, validate=validate, metrics=metrics)


def _global_identity(index):
    return tuple(index.ident(i) for i in range(index.n))


def _pivot_needs(pivots):
    out = {}
    for kind, x in pivots:
        if kind == 'S':
            out[(x, 'DIMENSIONS')] = dict(item=x, kind='DIMENSIONS')
        elif kind == 'D':
            out[(x, 'ANALYSIS')] = dict(item=x, kind='ANALYSIS')
        else:
            out[(x, 'RANK')] = dict(item=x, kind='RANK', second=x + 1)
    return list(out.values())


def build_fast_global():
    return _build(False, global_identity=True)


def build_fast():
    return _build(False)


def build_bx():
    return _build(True)


def build_bx_beta():
    return _build(True, mode='beta')


def build_bx_pivot():
    return _build(True, needs_policy='pivot')
