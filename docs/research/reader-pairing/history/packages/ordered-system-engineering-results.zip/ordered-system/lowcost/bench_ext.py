"""Extended session benchmark (fresh local Python measurements + synthetic service).

Every request is driven to a legal outcome through runtime.Session:
request -> demand needs -> simulated service rounds (finish/consume; optional
injected failures) -> re-request, up to `max_rounds`, then publish when
certified.  Reported per (scenario, strategy):

  wall_ns            whole scenario on this machine (median of reps)
  certify/validate   candidate-internal ns (when the candidate reports them)
  check/recompute    session validation and engine time
  acquisitions       physical acquisition units actually consumed
  rounds             service rounds needed before each legal outcome
  sim_wait_ns        SIMULATED: sum over rounds of ceil(units/work_capacity) * service_ns
                     (never added to wall)
  published / wrong  published units; wrong = published unit differs from the
                     complete-information plan of the same input version
  conflicts          runtime publication conflicts
  undecided          requests still not certified after max_rounds

Usage: python lowcost/bench_ext.py [--quick] --output lowcost/results/ext.json
"""
import argparse
import json
import random
import statistics
import sys
from copy import deepcopy
from pathlib import Path
from time import perf_counter_ns

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference  # noqa: E402
from generator import Knowledge, make_witness  # noqa: E402
from runtime import Session  # noqa: E402
import benchmark  # noqa: E402
from lowcost import candidates  # noqa: E402


def build_prior_sl():
    """Prior C-SL contract wrapper (no budget) with its scoped snapshot."""
    from prior.branching import certify_contract
    from prior.validity import scoped_changed
    metrics = dict(certify_ns=0, validate_ns=0)

    def certify(case, target):
        t0 = perf_counter_ns()
        out = certify_contract(case, target)
        sel = out['selected']
        sel = dict(sel)
        sel['steps'] = out['total_steps']
        metrics['certify_ns'] += perf_counter_ns() - t0
        return sel

    def validate(result, case):
        t0 = perf_counter_ns()
        if 'snapshot' in result:
            ok = scoped_changed(result['snapshot'], case) is None
        else:
            ok = isinstance(result.get('reads'), dict) and reference.reads_current(result, case)
        metrics['validate_ns'] += perf_counter_ns() - t0
        return ok
    return dict(certify=certify, validate=validate, metrics=metrics)


STRATEGIES = [
    ('baseline', None), ('E', None), ('scoped', benchmark.build_scoped),
    ('fast_global', candidates.build_fast_global), ('fast', candidates.build_fast),
    ('bx', candidates.build_bx), ('bx_pivot', candidates.build_bx_pivot),
    ('bx_beta', candidates.build_bx_beta), ('prior_sl', build_prior_sl),
]


def make_world(seed, n, kind):
    w = make_witness(seed=seed, count=n)
    rng = random.Random(seed)
    if kind == 'uniform':
        for i, spec in enumerate(w['items']):
            spec.update(pattern='flat' if i % 7 == 0 else 'stripe', phase=0, offset=(0, 5, 7)[i % 3])
    elif kind == 'mixed':
        for spec in w['items']:
            if rng.random() < .15:
                spec['width'], spec['height'] = 384, 256          # WIDE items
    if kind == 'auto_off':
        w['settings'].update(automatic=False, opening='AUTO')
    return w


def truth_unit(session, target):
    """Complete-information unit of the same input version (alpha domain)."""
    k = Knowledge(session.knowledge.witness, 16)
    k.versions = list(session.knowledge.versions)
    for i in range(len(k.witness['items'])):
        k.observe(i)
    plan = reference.complete_plan(k.case())
    return next(u for u in plan if any(s['item'] == target for s in u['slots']))


_TRUTH = {}


def _truth_plan(witness, versions):
    """Complete-information plan of one input version (cached; outside timing)."""
    key = json.dumps([witness, versions], sort_keys=True)
    plan = _TRUTH.get(key)
    if plan is None:
        k = Knowledge(witness, 16)
        k.versions = list(versions)
        for i in range(len(witness['items'])):
            k.observe(i)
        plan = reference.complete_plan(k.case())
        _TRUTH[key] = plan
    return plan


def run_scenario(cfg, name, builder, rep):
    rng = random.Random(cfg['seed'] * 31 + rep)
    w = make_world(cfg['seed'], cfg['n'], cfg['world'])
    bundle = builder() if builder else {}
    session = Session(w, strategy='E' if name == 'E' else 'baseline', capacity=cfg.get('capacity', 16),
                      work_capacity=cfg.get('work_capacity', 2),
                      candidate=bundle.get('certify'), validator=bundle.get('validate'))
    n = cfg['n']
    stats = dict(rounds=[], acquisitions=0, sim_wait_ns=0, published=0, wrong=0, undecided=0,
                 requests=0, failures_injected=0, metadata_events=0, evictions=0)
    checks = []
    started = perf_counter_ns()
    for i in range(n):
        if rng.random() < cfg['observed']:
            session.apply(dict(op='observe', item=i))
    targets = []
    for step in range(cfg['requests']):
        if cfg['pattern'] == 'sweep':
            targets.append(step % n)
        elif cfg['pattern'] == 'repeat':
            targets.append(min(2, n - 1))
        else:
            targets.append(rng.randrange(n))
    for step, target in enumerate(targets):
        if cfg['pattern'] == 'jump':
            session.apply(dict(op='navigate', target=target))
        if cfg.get('metadata_rate', 0) and rng.random() < cfg['metadata_rate']:
            item = rng.randrange(n) if cfg.get('metadata_where') == 'any' else n - 1
            session.apply(dict(op='metadata', item=item, orientation=rng.choice((1, 3))))
            stats['metadata_events'] += 1
        if cfg.get('evict_rate', 0) and rng.random() < cfg['evict_rate']:
            session.apply(dict(op='evict', item=rng.randrange(n)))
            stats['evictions'] += 1
        rounds = 0
        while True:
            stats['requests'] += 1
            response = session.request(target)
            if response['proof'].get('status') == 'certified' or rounds >= cfg['max_rounds']:
                break
            tokens = session.work_tokens()
            if not tokens:
                break
            units = 0
            for _ in range(4 * n):
                tokens = session.work_tokens()
                if not tokens:
                    break
                token = tokens[0]
                if session.tasks[token]['phase'] == 'running':
                    fail = 'READ' if rng.random() < cfg.get('fail_rate', 0) else None
                    stats['failures_injected'] += fail is not None
                    session.apply(dict(op='finish', token=token, failure=fail))
                if token in session.tasks:
                    out = session.apply(dict(op='consume', token=token))
                    units += out['outcome'] == 'consumed'
            rounds += 1
            stats['sim_wait_ns'] += -(-units // session.work_capacity) * cfg['service_ns']
        stats['rounds'].append(rounds)
        if response['proof'].get('status') == 'certified':
            out = session.apply(dict(op='publish', target=target))
            if out['outcome'] == 'published':
                stats['published'] += 1
                # verified after the timed region (truth needs full sampling)
                checks.append((target, deepcopy(session.published[target]),
                               deepcopy(session.knowledge.witness), list(session.knowledge.versions)))
        else:
            stats['undecided'] += 1
    wall = perf_counter_ns() - started
    for target, unit, witness, versions in checks:
        plan = _truth_plan(witness, versions)
        if unit != next(u for u in plan if any(s['item'] == target for s in u['slots'])):
            stats['wrong'] += 1
    m = session.metrics
    cm = bundle.get('metrics', {})
    return dict(wall_ns=wall, check_ns=m['check_ns'], recompute_ns=m['recompute_ns'],
                engine_runs=m['engine_runs'], memo_hits=m['memo_hits'], requests=stats['requests'],
                acquisitions=m['acquisition_units'], rounds_total=sum(stats['rounds']),
                rounds_max=max(stats['rounds'] or [0]), sim_wait_ns=stats['sim_wait_ns'],
                published=stats['published'], wrong=stats['wrong'], conflicts=m['conflicts'],
                undecided=stats['undecided'], failures_injected=stats['failures_injected'],
                metadata_events=stats['metadata_events'], evictions=stats['evictions'],
                admitted=m['admitted'], discarded=m['discarded'],
                candidate={k: v for k, v in cm.items() if isinstance(v, (int, float))})


def scenarios(quick):
    base = dict(seed=7, world='mixed', pattern='sweep', requests=24, max_rounds=6, service_ns=1_000_000,
                observed=1.0)
    out = []
    sizes = (12, 48) if quick else (12, 48, 128)
    for n in sizes:
        req = n if not quick else min(n, 24)
        out += [
            dict(base, name=f'hot_n{n}', n=n, requests=req),
            dict(base, name=f'cold_n{n}', n=n, requests=req, observed=0.0),
            dict(base, name=f'lowmiss_n{n}', n=n, requests=req, observed=0.8),
            dict(base, name=f'highmiss_n{n}', n=n, requests=req, observed=0.3),
            dict(base, name=f'jump_n{n}', n=n, requests=req, pattern='jump', observed=0.6),
            dict(base, name=f'meta_sparse_n{n}', n=n, requests=req, metadata_rate=0.05, metadata_where='any'),
            dict(base, name=f'meta_dense_n{n}', n=n, requests=req, metadata_rate=0.5, metadata_where='any'),
            dict(base, name=f'meta_unread_n{n}', n=n, requests=req, pattern='repeat', metadata_rate=0.5),
            dict(base, name=f'fail_n{n}', n=n, requests=req, observed=0.5, fail_rate=0.2),
            dict(base, name=f'evict_n{n}', n=n, requests=req, observed=0.7, capacity=2, evict_rate=0.3),
            dict(base, name=f'autooff_n{n}', n=n, requests=req, world='auto_off', observed=0.5),
            dict(base, name=f'uniform_n{n}', n=n, requests=req, world='uniform', observed=0.5),
        ]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--reps', type=int, default=3)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--only', default='')
    args = ap.parse_args()
    rows = []
    for cfg in scenarios(args.quick):
        if args.only and args.only not in cfg['name']:
            continue
        for name, builder in STRATEGIES:
            if name == 'prior_sl' and cfg['n'] > 48:
                continue          # no operation budget: excluded on long inputs (reported as N/A)
            reps = [run_scenario(cfg, name, builder, r) for r in range(args.reps)]
            first = reps[0]
            row = dict(scenario=cfg['name'], strategy=name, n=cfg['n'], config=cfg,
                       wall_ns_median=statistics.median(r['wall_ns'] for r in reps),
                       wall_ns_all=[r['wall_ns'] for r in reps],
                       check_ns_median=statistics.median(r['check_ns'] for r in reps),
                       recompute_ns_median=statistics.median(r['recompute_ns'] for r in reps))
            row.update({k: v for k, v in first.items() if k not in ('wall_ns', 'check_ns', 'recompute_ns')})
            rows.append(row)
            print(f"{cfg['name']:18s} {name:12s} wall={row['wall_ns_median']/1e6:8.2f}ms "
                  f"recomp={row['recompute_ns_median']/1e6:7.2f}ms check={row['check_ns_median']/1e6:6.2f}ms "
                  f"acq={row['acquisitions']:4d} rounds={row['rounds_total']:3d} pub={row['published']:3d} "
                  f"wrong={row['wrong']} undec={row['undecided']} conf={row['conflicts']}", flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(dict(schema='lowcost-ext-v1', quick=args.quick, reps=args.reps,
                                           rows=rows), indent=1))


if __name__ == '__main__':
    main()
