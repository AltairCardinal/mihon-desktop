"""Fingerprint validation for fast proofs (one-time scope, O(|reads|) checks).

A proof is (context, position identities, read fingerprints, scoped, mode),
built during certification from tuples that were parsed anyway, so the scope
costs no extra pass over the input.

Validation rules (same contract as the prior scoped validator, re-proved in
the report):
  * context (generation, order_revision, n, normalized settings incl. rule
    revision) must be equal;
  * every read position keeps its identity (id, content_version, rotation,
    orientation);
  * pending proofs (need_facts / blocked): every read fingerprint equal (strict,
    so a cached pending verdict is recomputed as soon as anything it read
    changes, including unknown -> known);
  * certified proofs: a read whose old value carried no value (unknown or
    failed analysis, unknown/failed edge, absent header, invalid dimension)
    may change arbitrarily (refinement); a valid dimension may change only in
    fields the scan does not consume; everything else must be equal.
  * eviction tolerance (known -> unknown) is NOT granted.
"""
from lowcost.fastcore import Index, _geometry_t


class CheckWork:
    __slots__ = ('positions', 'reads')

    def __init__(self):
        self.positions = 0
        self.reads = 0


def _unknownish(key, fp):
    kind = key[0]
    if fp is None:
        return True
    if kind == 'analysis':
        return fp[0] in ('unknown', 'failed')
    if kind == 'rank':
        return fp[0] in ('unknown', 'failed')
    return False


def _current(index, key):
    kind = key[0]
    if kind == 'analysis':
        return index.analysis(key[1])
    if kind == 'header':
        return index.header(key[1])
    if kind == 'dimension':
        f = index.effective(key[1])
        return (f[:5] + ('UNKNOWN',)) if f else None
    return index.edge(key[1], key[2])


def _dimension_equivalent(old, new):
    return (old is not None and new is not None and _geometry_t(old) and _geometry_t(new)
            and old[0] == new[0] and old[3] == new[3] and old[4] == new[4])


def first_violation(proof, case, index=None, work=None):
    """None if the proof is still valid for `case`, else a short reason."""
    if case.get('closed', False):
        return 'closed'
    context, positions, reads, scoped, _mode = proof
    try:
        index = index if index is not None else Index(case, check_ids=False)
    except ValueError:
        return 'invalid_input'
    if index.context != context:
        return 'context'
    for p, ident in positions:
        if work is not None:
            work.positions += 1
        if p >= index.n or index.ident(p) != ident:
            return ('position', p)
    for key, old in reads:
        if work is not None:
            work.reads += 1
        new = _current(index, key)
        if new == old:
            continue
        if scoped:
            if _unknownish(key, old):
                continue
            if key[0] == 'dimension' and _dimension_equivalent(old, new):
                continue
        return key
    return None


def valid(result, case, work=None):
    proof = result.get('proof')
    if proof is None:
        return False
    return first_violation(proof, case, work=work) is None
