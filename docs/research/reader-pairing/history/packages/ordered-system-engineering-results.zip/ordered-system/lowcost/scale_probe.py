"""Long-input proof-failure cost: reference vs prior C-SL vs BX (local run)."""
import sys, time, tracemalloc, random
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref
from generator import Knowledge, make_witness
from prior import branching as PB
from lowcost import fastcore as F, branch as BX

def family(kind, n, seed=731):
    w = make_witness(seed=seed, count=n)
    for i, spec in enumerate(w['items']):
        spec.update(pattern='flat' if i % 7 == 0 else 'stripe', phase=0, offset=(0, 5, 7)[i % 3])
    k = Knowledge(w)
    rng = random.Random(seed + n)
    t = n - 3
    if kind == 'scattered':      # 20% of items never analysed
        miss = {i for i in range(n) if rng.random() < .2}
    elif kind == 'near':         # the target's own neighbourhood missing
        miss = {t - 1, t, t + 1}
    elif kind == 'prefix':       # long missing stretch far left
        miss = set(range(1, n // 2))
    else:
        miss = set()
    for i in range(n):
        if i not in miss:
            k.observe(i)
    return k.case(), t

def measure(fn, reps=3):
    best = None
    for _ in range(reps):
        tracemalloc.start()
        t0 = time.perf_counter_ns()
        r = fn()
        dt = time.perf_counter_ns() - t0
        cur, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        if best is None or dt < best[0]:
            best = (dt, peak, r)
    return best

if __name__ == '__main__':
    import json
    sizes = [int(x) for x in sys.argv[1:]] or [16, 64, 256, 512]
    rows = []
    for kind in ('scattered', 'near', 'prefix', 'complete'):
        for n in sizes:
            case, t = family(kind, n)
            row = dict(kind=kind, n=n, target=t)
            for name, fn in (('ref', lambda: ref.certify(case, t)),
                             ('fast', lambda: F.certify(case, t)),
                             ('priorSL', lambda: PB.certify_sl(case, t)),
                             ('BX', lambda: BX.certify(case, t))):          # default budget 4000
                if name == 'priorSL' and n > 256:
                    row[name] = None
                    continue
                dt, peak, r = measure(fn, 1 if name == 'priorSL' else 3)
                st = r['status'] + ('/' + r.get('reason', '') if name == 'BX' else '')
                row[name] = dict(ms=dt / 1e6, kib=peak / 1024, status=st,
                                 steps=r['work']['steps'] if name == 'BX' else r.get('steps'))
            rows.append(row)
            print(json.dumps(row), flush=True)
    out = Path(__file__).resolve().parent / 'results' / 'scale.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(rows, indent=1))
