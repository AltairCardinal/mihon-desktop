"""Per-request revalidation cost: reference vs fingerprint vs stamp fast path.

Local Python ns (median of repeats); hot knowledge, certified target; the case
dictionary is rebuilt per request as runtime.Session does.
"""
import json, statistics, sys
from pathlib import Path
from time import perf_counter_ns
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref
from generator import make_witness
from lowcost.stamps import StampedKnowledge
from lowcost import fastcore as F, proof as P

def world(n):
    w = make_witness(seed=731, count=n)
    for i, spec in enumerate(w['items']):
        spec.update(pattern='flat' if i % 7 == 0 else 'stripe', phase=0, offset=(0, 5, 7)[i % 3])
    return w

def med(fn, reps=200):
    xs = []
    for _ in range(reps):
        t = perf_counter_ns(); fn(); xs.append(perf_counter_ns() - t)
    return statistics.median(xs)

rows = []
for n in (12, 48, 128, 512):
    k = StampedKnowledge(world(n))
    for i in range(n): k.observe(i)
    case = k.case()
    t = n // 2
    r = ref.certify(case, t); f = F.certify(case, t)
    positions = [p for p, _ in f['proof'][1]]
    snap = k.snapshot(positions)
    reps = 50 if n >= 512 else 200
    row = dict(n=n, target=t, proof_positions=len(positions), proof_reads=len(f['proof'][2]),
               case_build_ns=med(k.case, reps),
               ref_validate_ns=med(lambda: ref.reads_current(r, case), reps),
               fp_validate_ns=med(lambda: P.valid(f, case), reps),
               stamp_check_ns=med(lambda: k.unchanged(snap), reps),
               ref_certify_ns=med(lambda: ref.certify(case, t), max(5, reps // 10)),
               fast_certify_ns=med(lambda: F.certify(case, t), reps))
    row['request_ref_ns'] = row['case_build_ns'] + row['ref_validate_ns']
    row['request_fp_ns'] = row['case_build_ns'] + row['fp_validate_ns']
    row['request_stamp_ns'] = row['stamp_check_ns']
    rows.append(row)
    print(json.dumps(row), flush=True)
out = Path(__file__).resolve().parent / 'results' / 'stamps.json'
out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps(rows, indent=1))
