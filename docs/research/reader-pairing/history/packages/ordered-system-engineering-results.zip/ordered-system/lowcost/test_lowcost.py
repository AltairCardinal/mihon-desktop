"""Adversarial tests for lowcost/ (new files only; originals untouched).

python -m unittest discover -s lowcost -t . -p "test_*.py" -v

Each key check is also run against a deliberately wrong variant and must fail
there (class Mutants), so the tests are not isomorphic to the implementation.
"""
import copy
import json
import random
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import reference as ref  # noqa: E402
from generator import Knowledge, make_witness  # noqa: E402
from prior import model as M  # noqa: E402
from prior import branching as PB  # noqa: E402
from lowcost import fastcore as F, proof as P, branch as BX, candidates as C  # noqa: E402

KEYS = ('status', 'unit', 'needs', 'failures', 'first', 'steps', 'dependent_items')


def fact(state='NARROW', side='UNKNOWN'):
    return M.make_fact(state, side)


def case(n=6, automatic=False):
    return dict(items=[dict(id=f'i{i}', header=fact(), analysis=dict(status='computed', fact=fact(), version=1))
                       for i in range(n)], settings=dict(automatic=automatic),
                edges=[dict(first=i, second=i + 1, status='computed', score=None, version=1)
                       for i in range(n - 1)])


def random_cases(seed, count, n_max=8):
    rng = random.Random(seed)
    for _ in range(count):
        n = rng.randint(1, n_max)
        w = M.random_world(rng, n, legal=rng.random() < .5, nonneg=rng.random() < .5)
        c = M.mask_world(rng, w, p_analysis=rng.random(), p_header=rng.random(), p_edge=rng.random(),
                         p_fail=rng.choice([0, .15]), p_stale=rng.choice([0, .1]))
        if rng.random() < .2:
            for x in c['items']:
                x['rotation'] = rng.choice([0, 90, 180, 270])
        yield c, rng.randrange(n), rng.choice([0, 1, 2, 3])


def equivalent(c, t, lb=2, engine=F.certify):
    try:
        r = ref.certify(c, t, lb)
    except ValueError as e:
        try:
            engine(c, t, lb)
        except ValueError:
            return True
        return False
    f = engine(c, t, lb)
    reads = {k for k in r['reads'] if k not in ('identity', 'settings')}
    return all(r[k] == f[k] for k in KEYS) and reads == F.read_keys(f)


def unsound(engine, seed, count, mode='alpha', nonneg=False, rank_focus=False):
    rng = random.Random(seed)
    bad, made = [], 0
    while made < count:
        n = rng.randint(2, 6)
        if rank_focus:
            w = M.random_world(rng, n, legal=True, nonneg=nonneg, automatic=True, side_bias=0.1, p_wide=0.1)
        else:
            w = M.random_world(rng, n, legal=rng.random() < .6, nonneg=nonneg)
        c = M.mask_world(rng, w)
        t = rng.randrange(n)
        U, _, tr = M.possible_units(c, t, nonneg=nonneg, header_authoritative=mode == 'alpha', cap=15000)
        if tr:
            continue
        made += 1
        r = engine(c, t)
        if r['status'] == 'certified' and (len(U) != 1 or M.canon(r['unit']) != next(iter(U))):
            bad.append(('cert', c, t))
        if r.get('reason') == 'refuted' and len(U) == 1:
            bad.append(('refute', c, t))
    return bad


class FastCoreEquivalence(unittest.TestCase):
    def test_random_extension_domain(self):
        for c, t, lb in random_cases(101, 1500):
            self.assertTrue(equivalent(c, t, lb), json.dumps(c)[:300])

    def test_generator_domain_with_events(self):
        rng = random.Random(7)
        for _ in range(60):
            n = rng.randint(2, 16)
            w = make_witness(seed=rng.randrange(10 ** 6), count=n)
            w['settings'].update(opening=rng.choice(['AUTO', 'SINGLE', 'PAIR']),
                                 direction=rng.choice(['AB', 'BA']), automatic=rng.random() < .8)
            for spec in w['items']:
                if rng.random() < .2:
                    spec['orientation'], spec['rotation'] = rng.randint(1, 8), rng.choice([0, 90, 180, 270])
            k = Knowledge(w, capacity=rng.randint(2, 16))
            for _ in range(rng.randint(0, 3 * n)):
                getattr(k, rng.choice(['observe', 'observe', 'fail', 'evict', 'invalidate']))(rng.randrange(n))
            c = k.case()
            for t in range(n):
                self.assertTrue(equivalent(c, t))

    def test_golden_and_errors(self):
        for line in (ROOT / 'fixtures' / 'golden.jsonl').read_text(encoding='utf-8').splitlines():
            g = json.loads(line)
            for c in (g['case'], g['full_case']):
                for t in range(len(c['items'])):
                    self.assertTrue(equivalent(c, t))
        c = case(3)
        for bad in (dict(c, settings=dict(direction='XY')), dict(c, closed=True)):
            self.assertTrue(equivalent(bad, 0))
        dup = copy.deepcopy(c)
        dup['items'][1]['id'] = 'i0'
        self.assertTrue(equivalent(dup, 0))
        self.assertTrue(equivalent(c, 5))


class ProofValidity(unittest.TestCase):
    def setUp(self):
        self.c = case(12, True)
        self.c['settings']['hard_isolates'] = [6]
        self.r = F.certify(self.c, 9)
        self.assertEqual(self.r['status'], 'certified')

    def test_unread_change_kept_read_change_rejected(self):
        c2 = copy.deepcopy(self.c)
        c2['items'][1]['content_version'] = 3
        self.assertTrue(P.valid(self.r, c2))
        self.assertFalse(ref.reads_current(ref.certify(self.c, 9), c2))   # baseline invalidates
        dep = self.r['dependent_items'][0]
        for mutate in (lambda x: x['items'][dep].__setitem__('id', 'new'),
                       lambda x: x['items'][dep].__setitem__('content_version', 9),
                       lambda x: x['items'][dep]['analysis'].__setitem__('version', 2),
                       lambda x: x['items'][dep]['analysis']['fact'].__setitem__('state', 'WIDE'),
                       lambda x: x.__setitem__('generation', 1),
                       lambda x: x.__setitem__('order_revision', 1),
                       lambda x: x['settings'].__setitem__('revision', 1),
                       lambda x: x['settings'].__setitem__('pinned_links', [0]),
                       lambda x: x['items'].pop()):
            c2 = copy.deepcopy(self.c)
            mutate(c2)
            self.assertFalse(P.valid(self.r, c2))

    def test_pending_is_strict_certified_tolerates_refinement(self):
        c = case(6, True)
        c['items'][3]['analysis'] = dict(status='unknown')
        r = F.certify(c, 3)
        self.assertEqual(r['status'], 'need_facts')
        c2 = copy.deepcopy(c)
        c2['items'][3]['analysis'] = dict(status='computed', version=1, fact=fact())
        self.assertFalse(P.valid(r, c2))          # cached need_facts must be recomputed
        # certified result with an unknown, value-irrelevant read
        c = case(6, True)
        c['items'][4]['analysis'] = dict(status='unknown')
        c['items'][3]['analysis']['fact']['side'] = 'B'
        r = F.certify(c, 3)
        if r['status'] == 'certified' and any(k == ('analysis', 4) for k, _ in r['proof'][2]):
            c2 = copy.deepcopy(c)
            c2['items'][4]['analysis'] = dict(status='computed', version=1, fact=fact())
            self.assertTrue(P.valid(r, c2))
            self.assertFalse(ref.reads_current(ref.certify(c, 3), c2))

    def test_eviction_is_not_tolerated(self):
        c2 = copy.deepcopy(self.c)
        dep = self.r['dependent_items'][-1]
        c2['items'][dep]['analysis'] = dict(status='unknown')
        self.assertFalse(P.valid(self.r, c2))

    def test_header_only_replacement_detected(self):
        c = case(6, False)
        c['items'][3]['analysis'] = dict(status='unknown')
        r = F.certify(c, 3)
        self.assertEqual(r['status'], 'certified')
        c2 = copy.deepcopy(c)
        c2['items'][3]['id'] = 'replacement'
        self.assertFalse(P.valid(r, c2))
        c3 = copy.deepcopy(c)
        f = fact()
        f['width'], f['height'] = 300, 600
        c3['items'][3]['analysis'] = dict(status='computed', version=1, fact=f)
        self.assertTrue(P.valid(r, c3))           # same state: scan-equivalent refinement
        c4 = copy.deepcopy(c)
        c4['items'][3]['analysis'] = dict(status='computed', version=1, fact=fact('WIDE'))
        self.assertFalse(P.valid(r, c4))


class BranchingSoundness(unittest.TestCase):
    def test_bx_sound_and_refutations_exact(self):
        for mode, nonneg, rank_focus, seed in (('alpha', True, False, 11), ('alpha', False, True, 12),
                                               ('beta', False, False, 13)):
            bad = unsound(lambda c, t: BX.certify(c, t, mode=mode, nonneg=nonneg, budget=None),
                          seed, 150, mode=mode, nonneg=nonneg, rank_focus=rank_focus)
            self.assertEqual(bad, [], (mode, nonneg, rank_focus))

    def test_bx_dominates_reference_and_prior_sl(self):
        for c, t, _ in random_cases(202, 300, 7):
            r = ref.certify(c, t)
            s = PB.certify_sl(c, t)
            b = BX.certify(c, t, budget=None)
            if r['status'] == 'certified':
                self.assertEqual((b['status'], b['unit']), ('certified', r['unit']))
            if s['status'] == 'certified':
                self.assertEqual((b['status'], b['unit']), ('certified', s['unit']))

    def test_budget_exhaustion_never_certifies(self):
        for c, t, _ in random_cases(303, 200, 7):
            b = BX.certify(c, t, budget=3)
            if b['reason'] == 'budget':
                self.assertEqual(b['status'], 'need_facts')
                self.assertIsNone(b['unit'])

    def test_contract_wrapper_keeps_failures(self):
        c = case(5, True)
        c['edges'][1] = dict(first=1, second=2, status='failed', failures={'1': 'RESOURCE'})
        c['edges'][2]['score'] = None
        bundle = C.build_bx()
        r = bundle['certify'](c, 2)
        self.assertEqual((r['status'], r['failures']), ('blocked', {'1': 'RESOURCE'}))
        raw = BX.certify(c, 2)
        self.assertEqual(raw['status'], 'certified')              # value determined ...
        self.assertIn('edge:1', raw['extra_failures'])             # ... failure still visible

    def test_beta_wrapper_never_uses_headers(self):
        c = case(5, False)
        c['items'][2]['analysis'] = dict(status='unknown')
        self.assertEqual(C.build_bx()['certify'](c, 2)['status'], 'certified')       # alpha
        r = C.build_bx_beta()['certify'](c, 2)
        U, _, _ = M.possible_units(c, 2, header_authoritative=False)
        self.assertEqual(len(U), 2)
        self.assertNotEqual(r['status'], 'certified')

    def test_bx_certificate_proof_validates_and_invalidates(self):
        g = [json.loads(x) for x in (ROOT / 'fixtures' / 'golden.jsonl').read_text(encoding='utf-8').splitlines()][1]
        bundle = C.build_bx()
        r = bundle['certify'](g['case'], g['target'])
        self.assertEqual(r['status'], 'certified')
        self.assertEqual(r['unit'], M.target_unit(ref.complete_plan(g['full_case']), g['target']))
        self.assertTrue(bundle['validate'](r, g['case']))
        positions = [p for p, _ in r['proof'][1]]
        c2 = copy.deepcopy(g['case'])
        c2['items'][positions[0]]['content_version'] += 1
        self.assertFalse(bundle['validate'](r, c2))
        far = [i for i in range(len(g['case']['items'])) if i not in positions]
        if far:
            c3 = copy.deepcopy(g['case'])
            c3['items'][far[0]]['content_version'] += 1
            self.assertTrue(bundle['validate'](r, c3))


class BXProofCompleteness(unittest.TestCase):
    """Review findings: a BX certificate's proof must cover pruned entries and
    alpha header reads; unread positions may change without affecting the unit."""

    def test_pruned_entry_facts_are_in_proof(self):
        def item(i, state):
            it = dict(id=f'i{i}', content_version=0, rotation=0, orientation=1)
            if state is not None:
                it['analysis'] = dict(status='computed', version=1, fact=M.make_fact(state))
            return it
        states = ['NARROW', 'WIDE', 'NARROW', 'NARROW', 'NARROW', 'NARROW', None]
        c = dict(items=[item(i, s) for i, s in enumerate(states)], edges=[],
                 settings=dict(automatic=False, opening='AUTO'))
        b = C.build_bx()
        r = b['certify'](c, 4)
        self.assertEqual(r['status'], 'certified')
        c2 = copy.deepcopy(c)
        c2['items'][1]['analysis'] = dict(status='computed', version=2, fact=M.make_fact('NARROW'))
        c2['items'][1]['content_version'] = 1
        self.assertNotEqual(M.possible_units(c2, 4)[0], {M.canon(r['unit'])})
        self.assertFalse(b['validate'](r, c2))

    def test_alpha_header_over_stale_analysis_is_in_proof(self):
        stale = M.make_fact('NARROW')
        stale['rotation'] = 90
        c = dict(items=[dict(id='i0', analysis=dict(status='computed', version=1, fact=M.make_fact('NARROW'))),
                        dict(id='i1', analysis=dict(status='computed', version=1, fact=stale),
                             header=M.make_fact('NARROW'))],
                 edges=[dict(first=0, second=1, status='computed', version=1, score=1)],
                 settings=dict(automatic=True, opening='PAIR'))
        b = C.build_bx()
        r = b['certify'](c, 1)
        self.assertEqual(r['status'], 'certified')
        c2 = copy.deepcopy(c)
        c2['items'][1]['header'] = M.make_fact('WIDE')
        self.assertFalse(b['validate'](r, c2))

    def test_unread_mutations_never_change_a_kept_certificate(self):
        rng = random.Random(77)
        kept = checked = 0
        for c, t, _ in random_cases(404, 400, 7):
            b = C.build_bx()
            r = b['certify'](c, t)
            if r['status'] != 'certified' or 'bx' in r:
                pass
            if r['status'] != 'certified':
                continue
            for _ in range(3):
                c2 = copy.deepcopy(c)
                i = rng.randrange(len(c2['items']))
                x = c2['items'][i]
                choice = rng.randrange(4)
                if choice == 0:
                    x['analysis'] = dict(status='computed', version=1,
                                         fact=M.make_fact(rng.choice(['NARROW', 'WIDE']), rng.choice(M.SIDES)))
                elif choice == 1:
                    x['header'] = M.make_fact(rng.choice(['NARROW', 'WIDE']))
                elif choice == 2:
                    x['analysis'] = dict(status='unknown')
                else:
                    c2['edges'] = [e for e in c2['edges'] if e['first'] != min(i, len(c2['items']) - 2)]
                if not b['validate'](r, c2):
                    continue
                U, _, tr = M.possible_units(c2, t, cap=15000)
                if tr:
                    continue
                checked += 1
                self.assertEqual(U, {M.canon(r['unit'])}, json.dumps(c2)[:400])
        self.assertGreater(checked, 50)


class Stamps(unittest.TestCase):
    """P_stamp: every evidence change visible through case() bumps stamps."""

    def evidence(self, c, p):
        e = [x for x in c['edges'] if x['first'] in (p - 1, p)]
        return (json.dumps(c['items'][p], sort_keys=True), json.dumps(e, sort_keys=True))

    def _missed(self, mutant=False):
        from lowcost.stamps import StampedKnowledge
        rng = random.Random(31)
        missed = 0
        for _ in range(40):
            n = rng.randint(2, 10)
            k = StampedKnowledge(make_witness(seed=rng.randrange(999), count=n), capacity=rng.randint(2, 16))
            if mutant == 'positions':
                k._bump = lambda *p: None if rng.random() < .5 else StampedKnowledge._bump(k, *p)
            elif mutant == 'global':
                k.set_settings = lambda **f: k.witness['settings'].update(f)
            for _ in range(30):
                before, stamps = k.case(), list(k.stamp)
                i = rng.randrange(n)
                g0 = k.global_stamp
                op = rng.choice(['observe', 'observe', 'fail', 'evict', 'invalidate', 'metadata',
                                 'settings', 'generation'])
                if op == 'metadata':
                    k.metadata(i, orientation=rng.choice([1, 3]))
                elif op == 'settings':
                    k.set_settings(opening=rng.choice(['AUTO', 'SINGLE', 'PAIR']))
                elif op == 'generation':
                    k.advance_generation()
                else:
                    getattr(k, op)(i)
                after = k.case()
                ctx = lambda c: (json.dumps(c['settings'], sort_keys=True), c['generation'], c['order_revision'])  # noqa: E731
                if ctx(before) != ctx(after) and k.global_stamp == g0:
                    missed += 1
                for p in range(n):
                    if self.evidence(before, p) != self.evidence(after, p) and k.stamp[p] == stamps[p]:
                        missed += 1
        return missed

    def test_truthful(self):
        self.assertEqual(self._missed(), 0)

    def test_lossy_stamps_are_caught(self):
        self.assertGreater(self._missed(mutant='positions'), 0)
        self.assertGreater(self._missed(mutant='global'), 0)


class Mutants(unittest.TestCase):
    """Deliberately wrong variants; each must be caught by the checks above."""

    def test_missing_reserved_entry_in_core_is_caught(self):
        src = (ROOT / 'lowcost' / 'fastcore.py').read_text(encoding='utf-8')
        bad = src.replace("entries.append((first, opening, first))", "pass")
        ns = {'__file__': str(ROOT / 'lowcost' / 'fastcore.py'), '__name__': 'mutant_fastcore'}
        exec(compile(bad, 'mutant_fastcore', 'exec'), ns)
        caught = any(not equivalent(c, t, lb, engine=ns['certify']) for c, t, lb in random_cases(101, 1500))
        self.assertTrue(caught)

    def test_single_rank_representative_is_caught(self):
        orig = BX.View.rank

        def wrong(self, j):
            try:
                return orig(self, j)
            except BX.Branch as b:
                raise BX.Branch(b.key, (None,))           # "unknown rank = known null"
        with mock.patch.object(BX.View, 'rank', wrong):
            bad = unsound(lambda c, t: BX.certify(c, t, budget=None, refute=False), 21, 200, rank_focus=True)
        self.assertGreater(len(bad), 0)

    def test_window_ambiguity_as_refutation_is_caught(self):
        orig = BX.Engine.window

        def wrong(self, first, isolated):
            key, live = orig(self, first, isolated)
            if key is None:
                raise _Refuted()
            return key, live

        class _Refuted(Exception):
            pass

        def engine(c, t):
            try:
                return BX.certify(c, t, budget=None, refute=False)
            except _Refuted:
                return dict(status='need_facts', unit=None, reason='refuted')
        c = case(10, False)          # complete facts; phase comes from the far left
        U, _, _ = M.possible_units(c, 7)
        self.assertEqual(len(U), 1)
        good = BX.certify(c, 7, refute=False)
        self.assertEqual(good['status'], 'certified')
        self.assertGreater(good['work']['windows'], 1)                 # needed extension
        with mock.patch.object(BX.Engine, 'window', wrong):
            self.assertEqual(engine(c, 7)['reason'], 'refuted')       # mutant: wrong refutation

    def test_proof_without_identity_is_caught(self):
        c = case(6, False)
        c['items'][3]['analysis'] = dict(status='unknown')
        r = F.certify(c, 3)
        p = r['proof']
        r['proof'] = (p[0], (), p[2], p[3], p[4])          # drop position identities
        c2 = copy.deepcopy(c)
        c2['items'][3]['id'] = 'replacement'
        self.assertTrue(P.valid(r, c2))                    # mutant misses H5 replacement

    def test_tolerant_pending_proof_is_caught(self):
        c = case(6, True)
        c['items'][3]['analysis'] = dict(status='unknown')
        r = F.certify(c, 3)
        p = r['proof']
        r['proof'] = (p[0], p[1], p[2], True, p[4])        # mutant: pending treated as scoped
        c2 = copy.deepcopy(c)
        c2['items'][3]['analysis'] = dict(status='computed', version=1, fact=fact())
        self.assertTrue(P.valid(r, c2))                    # stale need_facts would be reused

    def test_live_only_support_is_caught(self):
        """The pre-review support collection (prereq reads of live entries
        only) must fail the pruned-entry proof test."""
        def old_support(self, first, live, isolated):
            reads, seen = set(), set()
            for state, pre in live:
                if pre is not None:
                    reads |= self.pre[(first, pre)][1]
                stack = [state]
                while stack:
                    s = stack.pop()
                    if s in seen or s[0] > self.target:
                        continue
                    seen.add(s)
                    reads |= self.reads_of[s]
                    stack.extend(self.succ[s][1])
            return reads
        with mock.patch.object(BX.Engine, 'support', old_support):
            with self.assertRaises(AssertionError):
                BXProofCompleteness('test_pruned_entry_facts_are_in_proof').test_pruned_entry_facts_are_in_proof()

    def test_wrapper_without_baseline_is_caught(self):
        c = case(5, True)
        c['edges'][1] = dict(first=1, second=2, status='failed', failures={'1': 'RESOURCE'})
        c['edges'][2]['score'] = None
        self.assertEqual(BX.certify(c, 2)['status'], 'certified')   # raw engine would swallow
        self.assertEqual(C.build_bx()['certify'](c, 2)['status'], 'blocked')


if __name__ == '__main__':
    unittest.main()
