"""Q4: online-stable alternative rules (route B) -- executable counterexamples.

Two natural "online" rule families and why they fail the hard contracts:

R_pub  (publication-anchored phase): the first requested target pairs with its
       right neighbour when allowed; the rest of its maximal run is paired
       outward from that anchor.  Output for the target is available after
       reading only its neighbourhood, but the FINAL partition depends on the
       access order -> violates H1.  `h1_counterexample()` returns two orders
       with different partitions of the same complete input.

R_par  (absolute parity): pair (2k, 2k+1) inside runs.  Local and order-free,
       but it is exactly the "fixed parity" that H11 forbids; listed only as the
       boundary of the design space.

Any rule that is order-independent (H1), segment-relative (no absolute parity,
H11) and leaves o(L) singles per run of length L inherits the Omega(L)
locality barrier proved in the previous round (Theorem 6 there).  This module
only demonstrates the two concrete violations; it is not a proposal.
"""


def runs(n, wide):
    out, i = [], 0
    while i < n:
        if wide[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and not wide[j + 1]:
            j += 1
        out.append((i, j))
        i = j + 1
    return out


def r_pub(n, wide, order):
    """Partition under publication anchoring, processing requests in `order`."""
    unit_of = {}
    for t in order:
        if t in unit_of or wide[t]:
            unit_of.setdefault(t, (t,))
            continue
        lo, hi = next((a, b) for a, b in runs(n, wide) if a <= t <= b)
        if any(x in unit_of for x in range(lo, hi + 1)):
            # run already anchored by an earlier request: phase fixed
            anchor = min(x for x in range(lo, hi + 1) if x in unit_of)
            base = unit_of[anchor][0]
        else:
            base = t if t + 1 <= hi else t - 1
        phase = (base - lo) % 2
        for x in range(lo, hi + 1):
            if (x - lo) % 2 == phase and x + 1 <= hi:
                unit_of[x] = (x, x + 1)
                unit_of[x + 1] = (x, x + 1)
            unit_of.setdefault(x, (x,))
    return sorted(set(unit_of[x] for x in range(n)))


def r_par(n, wide):
    out = []
    i = 0
    while i < n:
        if not wide[i] and i % 2 == 0 and i + 1 < n and not wide[i + 1]:
            out.append((i, i + 1))
            i += 2
        else:
            out.append((i,))
            i += 1
    return out


def h1_counterexample():
    n, wide = 6, [False] * 6
    a = r_pub(n, wide, [1, 0, 2, 3, 4, 5])
    b = r_pub(n, wide, [2, 0, 1, 3, 4, 5])
    return dict(input=dict(n=n, wide=wide), order_a=[1, 0, 2, 3, 4, 5], partition_a=a,
                order_b=[2, 0, 1, 3, 4, 5], partition_b=b, violates_H1=a != b)


if __name__ == '__main__':
    import json
    print(json.dumps(h1_counterexample()))
    print('absolute parity partition:', r_par(6, [False] * 6))
