"""Q2: incremental proof maintenance with per-position change stamps (host-side).

After the compiled core, the dominant per-request cost in the session model is
building the whole input dictionary (Knowledge.case(), O(n)) before any
validation can start.  If the knowledge layer keeps a monotone stamp per
position (bumped whenever evidence that case() would expose for that position
or its adjacent edges changes) and one global stamp (settings, generation,
order revision), a certificate can be revalidated WITHOUT building the input:

    fast path : all stamps of the proof positions + global stamp unchanged
                -> valid (nothing it read can have changed)
    slow path : otherwise build case() and run the fingerprint check
                (keeps refinement tolerance for certified proofs)

Precondition P_stamp (checked by Stamps tests): every evidence change visible
through case() bumps the stamp of each affected position, and every context
change (settings, generation, order revision) bumps the global stamp.  It holds
only if ALL mutations go through this class's methods; code that edits the
witness, settings or knowledge dictionaries directly (as runtime.Session's
metadata handler does) bypasses it and voids the fast path (review finding).  The
fast path is sound under P_stamp; without it, it is not.  This is a model of a
host-side change, not something the benchmark's candidate interface can
express (Session.request always builds case() first).
"""
from generator import Knowledge


class StampedKnowledge(Knowledge):
    def __init__(self, witness, capacity=16):
        super().__init__(witness, capacity)
        self.stamp = [0] * len(witness['items'])
        self.global_stamp = 0

    def _bump(self, *positions):
        for p in positions:
            if 0 <= p < len(self.stamp):
                self.stamp[p] += 1

    def observe(self, index):
        out = super().observe(index)
        # analysis, adjacent ranks AND the adjacent edges' failure evidence
        # (observe clears this item's failure) can change: bump all three.
        # Found by test_stamps_are_truthful: bumping only on rank changes
        # missed edge-failure changes.
        self._bump(index - 1, index, index + 1)
        return out

    def fail(self, index, reason='READ'):
        super().fail(index, reason)
        self._bump(index - 1, index, index + 1)     # failure can surface on adjacent edges

    def evict(self, index):
        super().evict(index)                         # raw samples are not case evidence

    def invalidate(self, index, spec=None):
        super().invalidate(index, spec)
        self._bump(index - 1, index, index + 1)

    def metadata(self, index, **fields):
        spec = self.witness['items'][index]
        spec.update(fields)
        self.samples.pop(index, None)
        self.analyses.pop(index, None)
        self.failures.pop(index, None)
        for a in (index - 1, index):
            self.ranks.pop(a, None)
        self._bump(index - 1, index, index + 1)

    # -- global context: every change must go through these methods ---------
    def set_settings(self, **fields):
        self.witness['settings'].update(fields)
        self.global_stamp += 1

    def advance_generation(self):
        self.generation += 1
        self.global_stamp += 1

    def reorder(self):
        self.order_revision += 1
        self.global_stamp += 1

    def snapshot(self, positions):
        return (self.global_stamp, tuple((p, self.stamp[p]) for p in positions))

    def unchanged(self, snap):
        g, pos = snap
        return g == self.global_stamp and all(self.stamp[p] == s for p, s in pos)
