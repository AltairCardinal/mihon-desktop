"""Q3: which evidence to acquire next, under per-kind costs and round latency.

Abstract extension-domain worlds (prior.model), cold start (no analysis, some
headers).  Every round acquires a batch in parallel; a rank can be acquired
only when both endpoint analyses were valid at the start of the round
(otherwise the endpoints are acquired instead).  Certification is the same for
the BX policies (contract wrapper), so the policies differ only in needs:

  REF        reference certify alone; reference needs
  BX_REF     contract wrapper (fast + BX); reference needs
  BX_PIVOT   contract wrapper; if BX refuted, acquire the refutation pivots
             (facts on which the two refuting worlds differ: at least one of
             them MUST be learned to separate that pair); else reference needs
  BX_PIVOT1  as BX_PIVOT but only the single cheapest pivot per round

Cost of a run: J = cA*#analyses + cR*#ranks + L*rounds (synthetic, symbolic
parameters; no measured service times exist).  A lower bound on #acquisitions
is computed by exhaustive minimum-certificate search where it resolves.

python lowcost/acq_study.py [--worlds 200] --output lowcost/results/acq.json
"""
import argparse
import itertools
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402
from prior import model as M  # noqa: E402
from lowcost import candidates as C, branch as BX  # noqa: E402


def apply(case, world, needs):
    K = M.Knowledge(case)
    items, ranks = set(), set()
    for nd in needs:
        i = nd['item']
        if nd['kind'] in ('ANALYSIS', 'DIMENSIONS'):
            if not K.valid[i]:
                items.add(i)
        elif K.valid[i] and K.valid[i + 1]:
            if K.rank[i][0] != 'known':
                ranks.add(i)
        else:
            items.update(x for x in (i, i + 1) if not K.valid[x])
    c = case
    for i in sorted(items):
        c = M.reveal(c, world, 'ANALYSIS', i)
    for j in sorted(ranks):
        c = M.reveal(c, world, 'RANK', j)
    return c, len(items), len(ranks)


def policy_needs(name, bundle, case, target):
    if name == 'REF':
        r = ref.certify(case, target)
        return r['status'], r['needs']
    r = bundle['certify'](case, target)
    if r['status'] != 'need_facts' or name == 'BX_REF':
        return r['status'], r['needs']
    bx = r.get('bx')
    if bx and bx['reason'] == 'refuted':
        piv = r.get('_pivots')
        if piv:
            if name == 'BX_PIVOT1':
                piv = sorted(piv, key=lambda k: (k[0] == 'R', k[1]))[:1]
            return r['status'], C._pivot_needs(piv)
    return r['status'], r['needs']


def min_certificate(case, world, t, limit=6, call_budget=1500):
    K = M.Knowledge(case)
    lim = min(K.n - 1, t + 3)
    cand = [('ANALYSIS', i) for i in range(lim + 1) if not K.valid[i]]
    if K.automatic:
        cand += [('RANK', j) for j in range(min(K.n - 1, lim + 1)) if K.rank[j][0] != 'known'
                 and world['states'][j] == 'NARROW' and world['states'][j + 1] == 'NARROW']
    calls = 0
    for size in range(0, min(limit, len(cand)) + 1):
        truncated = False
        for combo in itertools.combinations(cand, size):
            if calls >= call_budget:
                return None
            items = {a for k, a in combo if k == 'ANALYSIS'}
            if not all(k != 'RANK' or ((K.valid[a] or a in items) and (K.valid[a + 1] or a + 1 in items))
                       for k, a in combo):
                continue
            c = case
            for k, a in sorted(combo):
                c = M.reveal(c, world, k, a)
            calls += 1
            U, _, tr = M.possible_units(c, t, stop_at=2, cap=20000)
            if tr and len(U) < 2:
                truncated = True
                continue
            if len(U) == 1:
                return size
        if truncated:
            return None
    return None


def build_with_pivots():
    """build_bx whose results also expose the refutation pivots."""
    bundle = C.build_bx()
    inner = bundle['certify']

    def certify(case, target):
        r = inner(case, target)
        if r['status'] == 'need_facts' and r.get('bx', {}).get('reason') == 'refuted':
            b = BX.certify(case, target, budget=4000)
            r['_pivots'] = b['pivots']
        return r
    bundle['certify'] = certify
    return bundle


def run(worlds, seed):
    rng = random.Random(seed)
    names = ['REF', 'BX_REF', 'BX_PIVOT', 'BX_PIVOT1']
    rows = []
    for w_i in range(worlds):
        n = rng.randint(3, 7)
        w = M.random_world(rng, n, legal=True, nonneg=False, automatic=rng.random() < .7,
                           side_bias=rng.choice([0.1, 0.5]), p_wide=0.15)
        c0 = M.mask_world(rng, w, p_analysis=0.0, p_header=rng.choice([0.2, 0.7]), p_edge=0.0,
                          p_fail=0.0, p_stale=0.0)
        t = rng.randrange(n)
        row = dict(world=w_i, n=n, target=t, automatic=w['settings']['automatic'])
        for name in names:
            bundle = build_with_pivots()
            c, rounds, na, nr, status = c0, 0, 0, 0, None
            while rounds <= 12:
                status, needs = policy_needs(name, bundle, c, t)
                if status == 'certified' or not needs:
                    break
                c2, a, r_ = apply(c, w, needs)
                if a + r_ == 0:
                    break
                c, rounds, na, nr = c2, rounds + 1, na + a, nr + r_
            row[name] = dict(rounds=rounds, analyses=na, ranks=nr, certified=status == 'certified')
        row['lower_bound'] = min_certificate(c0, w, t)
        rows.append(row)
    return rows


def summarize(rows, names=('REF', 'BX_REF', 'BX_PIVOT', 'BX_PIVOT1')):
    out = {}
    for name in names:
        rs = [r[name] for r in rows]
        out[name] = dict(rounds=sum(x['rounds'] for x in rs), analyses=sum(x['analyses'] for x in rs),
                         ranks=sum(x['ranks'] for x in rs), certified=sum(x['certified'] for x in rs))
        resolved = [r for r in rows if r['lower_bound'] is not None]
        out[name]['excess_over_lb'] = sum(r[name]['analyses'] + r[name]['ranks'] - r['lower_bound']
                                          for r in resolved)
        out[name]['lb_resolved'] = len(resolved)
    # cost sensitivity J = cA*A + cR*R + L*rounds with cA = 1
    grid = []
    for cR in (0.5, 1, 4):
        for L in (0, 1, 10):
            costs = {name: out[name]['analyses'] + cR * out[name]['ranks'] + L * out[name]['rounds']
                     for name in names}
            best = min(costs, key=costs.get)
            grid.append(dict(cR=cR, L=L, costs=costs, best=best))
    out['sensitivity_cA_1'] = grid
    out['lower_bound_total'] = sum(r['lower_bound'] for r in rows if r['lower_bound'] is not None)
    return out


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--worlds', type=int, default=200)
    ap.add_argument('--seed', type=int, default=97)
    ap.add_argument('--output', type=Path, required=True)
    a = ap.parse_args()
    rows = run(a.worlds, a.seed)
    summ = summarize(rows)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(dict(seed=a.seed, worlds=a.worlds, summary=summ, rows=rows), indent=1))
    print(json.dumps(summ, indent=1)[:4000])
