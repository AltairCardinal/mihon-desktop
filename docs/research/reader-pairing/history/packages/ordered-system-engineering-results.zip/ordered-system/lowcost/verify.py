"""Finite-domain verification run (fixed seeds) -> lowcost/results/verify.json.

1. fastcore vs reference.certify: identical status/unit/needs(order)/failures/
   first/steps/dependent_items and read-key sets (extension domain, generator
   domain with knowledge events, golden rows).
2. BX vs the possible-world oracle (prior.model.possible_units, exhaustive
   with order-type rank grid; truncated instances skipped and counted):
   unsound certificates, wrong refutations, certification count vs oracle
   uniqueness, dominance over reference and prior C-SL.  alpha/beta,
   signed/non-negative, legal/interface, default/rank-focused generators.
"""
import json
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402
from generator import Knowledge, make_witness  # noqa: E402
from prior import model as M  # noqa: E402
from prior import branching as PB  # noqa: E402
from lowcost import fastcore as F, branch as BX  # noqa: E402
from lowcost.test_lowcost import equivalent, random_cases  # noqa: E402


def core_equivalence():
    out = dict(extension=0, extension_mismatch=0, generator=0, generator_mismatch=0, golden=0,
               golden_mismatch=0)
    for c, t, lb in random_cases(9001, 20000, 9):
        out['extension'] += 1
        out['extension_mismatch'] += not equivalent(c, t, lb)
    rng = random.Random(9002)
    for _ in range(400):
        n = rng.randint(2, 24)
        w = make_witness(seed=rng.randrange(10 ** 6), count=n)
        w['settings'].update(opening=rng.choice(['AUTO', 'SINGLE', 'PAIR']),
                             direction=rng.choice(['AB', 'BA']), automatic=rng.random() < .8)
        for spec in w['items']:
            if rng.random() < .2:
                spec['orientation'], spec['rotation'] = rng.randint(1, 8), rng.choice([0, 90, 180, 270])
            if rng.random() < .15:
                spec['width'], spec['height'] = 384, 256
        k = Knowledge(w, capacity=rng.randint(2, 16))
        for _ in range(rng.randint(0, 3 * n)):
            getattr(k, rng.choice(['observe', 'observe', 'observe', 'fail', 'evict', 'invalidate']))(rng.randrange(n))
        c = k.case()
        for t in range(n):
            out['generator'] += 1
            out['generator_mismatch'] += not equivalent(c, t)
    root = Path(__file__).resolve().parent.parent
    for line in (root / 'fixtures' / 'golden.jsonl').read_text(encoding='utf-8').splitlines():
        g = json.loads(line)
        for c in (g['case'], g['full_case']):
            for t in range(len(c['items'])):
                out['golden'] += 1
                out['golden_mismatch'] += not equivalent(c, t)
    return out


CONFIGS = [
    dict(seed=1, count=500, legal=True, nonneg=True, mode='alpha', focus=False),
    dict(seed=2, count=500, legal=False, nonneg=False, mode='alpha', focus=False),
    dict(seed=3, count=400, legal=True, nonneg=False, mode='beta', focus=False),
    dict(seed=4, count=300, legal=True, nonneg=False, mode='alpha', focus=True),
    dict(seed=5, count=300, legal=True, nonneg=True, mode='alpha', focus=True),
    dict(seed=6, count=300, legal=False, nonneg=False, mode='beta', focus=True),
]


def bx_soundness(cfg):
    rng = random.Random(cfg['seed'])
    alpha = cfg['mode'] == 'alpha'
    st = dict(cfg, n=0, truncated=0, oracle_unique=0, ref=0, prior_sl=0, bx=0, unsound=0,
              refuted=0, wrong_refutation=0, budget=0, exhausted=0, dominance_ref=0, dominance_sl=0,
              bx_steps=0, prior_sl_steps=0)
    while st['n'] < cfg['count']:
        n = rng.randint(2, 7)
        if cfg['focus']:
            w = M.random_world(rng, n, legal=cfg['legal'], nonneg=cfg['nonneg'], automatic=True,
                               side_bias=0.1, p_wide=0.1)
        else:
            w = M.random_world(rng, n, legal=cfg['legal'], nonneg=cfg['nonneg'])
        c = M.mask_world(rng, w)
        t = rng.randrange(n)
        U, _, tr = M.possible_units(c, t, nonneg=cfg['nonneg'], header_authoritative=alpha, cap=30000)
        if tr:
            st['truncated'] += 1
            continue
        st['n'] += 1
        uniq = len(U) == 1
        st['oracle_unique'] += uniq
        r = ref.certify(c, t) if alpha else ref.certify(PB._without_authoritative_headers(c), t)
        s = PB.certify_sl(c, t, nonneg=cfg['nonneg'], header_authoritative=alpha)
        b = BX.certify(c, t, mode=cfg['mode'], nonneg=cfg['nonneg'], budget=None)
        st['bx_steps'] += b['work']['steps']
        st['prior_sl_steps'] += s['steps']
        st['ref'] += r['status'] == 'certified'
        st['prior_sl'] += s['status'] == 'certified'
        st['bx'] += b['status'] == 'certified'
        if b['status'] == 'certified' and (not uniq or M.canon(b['unit']) != next(iter(U))):
            st['unsound'] += 1
        st['refuted'] += b['reason'] == 'refuted'
        st['wrong_refutation'] += b['reason'] == 'refuted' and uniq
        st['budget'] += b['reason'] == 'budget'
        st['exhausted'] += b['reason'] == 'exhausted_windows'
        st['dominance_ref'] += r['status'] == 'certified' and b['status'] != 'certified'
        st['dominance_sl'] += s['status'] == 'certified' and b['status'] != 'certified'
    return st


if __name__ == '__main__':
    t0 = time.time()
    res = dict(core=core_equivalence())
    print(res['core'], flush=True)
    res['bx'] = []
    for cfg in CONFIGS:
        st = bx_soundness(cfg)
        print(st, flush=True)
        res['bx'].append(st)
    res['seconds'] = round(time.time() - t0, 1)
    out = Path(__file__).resolve().parent / 'results' / 'verify.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(res, indent=1))
