"""D3: position-scoped, refinement-tolerant certificate validation.

reference.first_changed_read() snapshots the WHOLE identity (all items) and
requires every read to be byte-equal.  Consequences:
  * an unrelated item's content change invalidates every certificate (O(n)
    validation per certificate, O(n) snapshot storage per certificate);
  * a read that was unknown and becomes known (knowledge refinement inside the
    same input version) invalidates, although the certificate held for every
    value of that read.
scoped_snapshot/scoped_changed keep: global context (generation,
order_revision, n, full settings), the identity of every position whose
evidence was read, and each typed read.  A read may refine unknown/failed ->
anything; a known read must stay equal.  Optional eviction tolerance
(known -> unknown) is only sound under precondition P_ver (an analysis
algorithm-version change is visible outside the evidence record); it is off by
default.

The validation reads only the recorded positions and the recorded reads.  It
does not rebuild the input: no deep copy of the case, no full identity and no
full edge index.  `ScopedWork` reports what the validation actually touched so
the cost claim can be checked instead of believed.
"""
import sys
from copy import deepcopy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402


class ScopedWork:
    """What a scoped validation really touched."""

    def __init__(self):
        self.items_touched = 0      # distinct item positions whose evidence was read
        self.edge_records_scanned = 0   # edge records looked at in the provider's list
        self.reads_compared = 0      # recorded reads compared with the current value

    def __repr__(self):
        return (f'ScopedWork(items_touched={self.items_touched}, '
                f'edge_records_scanned={self.edge_records_scanned}, '
                f'reads_compared={self.reads_compared})')


def _positions(key):
    parts = key.split(':')
    if parts[0] in ('analysis', 'header', 'dimension'):
        return [int(parts[1])]
    if parts[0] == 'rank':
        return [int(parts[1]), int(parts[2])]
    return []


def _is_unknownish(v):
    """Evidence that carries no value: unknown or failed record, or None."""
    if v is None:
        return True
    return isinstance(v, dict) and v.get('status') in ('unknown', 'failed')


def _dimension_equivalent(old, new):
    """The scan consumes a dimension read only through its validity and its
    occupancy state (rotation/orientation are covered by position identity).
    Two valid dimension facts with equal state are therefore equivalent."""
    if old is None or new is None:
        return False
    return (ref._geometry(old) and ref._geometry(new) and old['state'] == new['state']
            and old['rotation'] == new['rotation'] and old['orientation'] == new['orientation'])


class _ScopedInput:
    """A lazy input view over one case.

    It never copies the case and never materialises the whole identity: only
    the positions and the edges that the caller actually asks for are read.
    """

    def __init__(self, case, work=None):
        self.case = case
        self.items = case['items']
        self.work = work if work is not None else ScopedWork()
        self._touched = set()

    # -- context -----------------------------------------------------------
    def context(self):
        return dict(generation=self.case.get('generation', 0),
                    order_revision=self.case.get('order_revision', 0),
                    n=len(self.items))

    def settings(self):
        s = self.case.get('settings', {})
        return dict(direction=s.get('direction', 'AB'), automatic=s.get('automatic', False),
                    hard_isolates=sorted(set(s.get('hard_isolates', []))),
                    pinned_links=sorted(set(s.get('pinned_links', []))),
                    opening=s.get('opening', 'AUTO'), revision=s.get('revision', 0))

    # -- one position ------------------------------------------------------
    def _touch(self, index):
        if index not in self._touched:
            self._touched.add(index)
            self.work.items_touched += 1

    def identity_item(self, index):
        self._touch(index)
        x = self.items[index]
        return dict(id=x.get('id', str(index)), content_version=x.get('content_version', 0),
                    rotation=x.get('rotation', 0), orientation=x.get('orientation', 1))

    def analysis(self, index):
        self._touch(index)
        x = self.items[index]
        e = dict(x.get('analysis', {'status': 'unknown'}))
        if e['status'] == 'computed':
            e['fact'] = ref._fact(e['fact'])
            e.setdefault('version', 1)
            e['content'] = self.identity_item(index)
        elif e['status'] == 'failed':
            e['content'] = self.identity_item(index)
        elif e['status'] != 'unknown':
            raise ValueError('invalid analysis status')
        return e

    def header(self, index):
        self._touch(index)
        return ref._fact(self.items[index].get('header'))

    def effective(self, index):
        a = self.analysis(index)
        return a['fact'] if a['status'] == 'computed' else self.header(index)

    def dimension(self, index):
        f = self.effective(index)
        return dict(f, side='UNKNOWN') if f else None

    # -- one edge ----------------------------------------------------------
    def edge(self, first, second):
        """The current evidence of one adjacent edge.

        The provider keeps the edges in a list, so one lookup is a scan of that
        list.  The scan allocates nothing and touches no other item; the last
        matching record wins, as in the reference index.
        """
        found = None
        for e in self.case.get('edges', []):
            self.work.edge_records_scanned += 1
            if e.get('first') == first and e.get('second') == second:
                found = e
        if found is None:
            e = {'status': 'unknown'}
        else:
            e = dict(found)
        aa, bb = self.analysis(first), self.analysis(second)
        if second != first + 1 or aa['status'] != 'computed' or bb['status'] != 'computed':
            return {'status': 'unknown'}
        if aa['fact']['state'] == 'WIDE' or bb['fact']['state'] == 'WIDE':
            out = dict(status='computed', score=None, version=1)
        else:
            out = dict(e)
            out.pop('first', None)
            out.pop('second', None)
            if out['status'] == 'computed':
                out.setdefault('score', None)
                out.setdefault('version', 1)
        if out['status'] != 'unknown':
            out['content'] = [self.identity_item(first), self.identity_item(second)]
        return out


def _current(data, key):
    parts = key.split(':')
    if parts[0] == 'analysis':
        return data.analysis(int(parts[1]))
    if parts[0] == 'header':
        return data.header(int(parts[1]))
    if parts[0] == 'dimension':
        return data.dimension(int(parts[1]))
    return data.edge(int(parts[1]), int(parts[2]))


def scoped_snapshot(result):
    """Build a scoped snapshot from a reference certify() result."""
    reads = result['reads']
    ident = reads['identity']
    keys = [k for k in reads if k not in ('identity', 'settings')]
    pos = sorted({p for k in keys for p in _positions(k)})
    return dict(context=dict(generation=ident['generation'], order_revision=ident['order_revision'],
                             n=len(ident['items'])),
                settings=deepcopy(reads['settings']),
                positions={p: deepcopy(ident['items'][p]) for p in pos},
                reads={k: deepcopy(reads[k]) for k in keys})


def scoped_changed(snap, case, allow_eviction=False, work=None):
    """First violated component or None.

    The comparison work is O(|reads|): only the recorded positions and the
    recorded reads are compared.  The provider lookup of one edge is a scan of
    the provider's edge list, so the total time also depends on the number of
    stored edges; the scan allocates nothing and reads no other item.
    """
    if case.get('closed', False):
        return 'identity'
    data = _ScopedInput(case, work)
    ctx = snap['context']
    if data.context() != ctx:
        return 'context'
    if data.settings() != snap['settings']:
        return 'settings'
    for p, old in snap['positions'].items():
        if data.identity_item(p) != old:
            return f'position:{p}'
    for key, old in snap['reads'].items():
        new = _current(data, key)
        if work is not None:
            work.reads_compared += 1
        if new == old or _is_unknownish(old):
            continue
        if key.startswith('dimension:') and _dimension_equivalent(old, new):
            continue
        if allow_eviction and _is_unknownish(new) and not (isinstance(new, dict) and new.get('status') == 'failed'):
            continue
        return key
    return None


def snapshot_cost(snap):
    """Stored comparison units (positions + reads + constant context)."""
    return 3 + len(snap['positions']) + len(snap['reads'])


def reference_cost(result):
    return 2 + len(result['reads']['identity']['items']) + len(result['reads'])


def support_snapshot(case, support):
    """Scoped snapshot for a branching-certifier certificate.

    support: iterable of ('S', i) | ('D', i) | ('R', j) keys actually read in
    the certifying window.  Maps them onto the reference read vocabulary so
    scoped_changed() applies unchanged."""
    data = _ScopedInput(case)
    keys = set()
    for kind, x in support:
        if kind in ('S', 'D'):
            keys.update((f'analysis:{x}', f'header:{x}', f'dimension:{x}'))
        else:
            keys.add(f'rank:{x}:{x + 1}')
            keys.update((f'analysis:{x}', f'analysis:{x + 1}'))
    pos = sorted({p for k in keys for p in _positions(k)})
    ident = data.context()
    return dict(context=dict(generation=ident['generation'], order_revision=ident['order_revision'],
                             n=ident['n']),
                settings=data.settings(),
                positions={p: data.identity_item(p) for p in pos},
                reads={k: _current(data, k) for k in sorted(keys)})
