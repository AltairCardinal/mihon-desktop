"""Branching certifiers: certify despite proof-irrelevant unknowns.

C-PW  path-sensitive possible-world certifier.  Each entry state of a window is
      explored by lazy depth-first branching: an unknown fact is assigned only
      when the deterministic scan actually reads it, and the assignment is kept
      for the rest of that path (exact correlation).  At first == 0 the entry
      set is exact, so C-PW equals the possible-world oracle on the scan region.
C-SL  step-local set propagation.  Each scanner state is expanded once per
      window; unknowns read inside one step are branched locally and then
      forgotten; successor states are merged.  Sound over-approximation with a
      polynomial bound (<= 4 states per position).

Both reuse reference._Scan unchanged, so the decision rule itself is not
re-implemented.  Unknown/failed/stale evidence is treated as free under the
world model of research.model (branch alpha by default).
"""
import heapq
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import reference as ref  # noqa: E402
from prior.model import Knowledge, STATES, SIDES, rank_grid, canon, _as_number, _valid_for  # noqa: E402


class Branch(Exception):
    def __init__(self, key, options):
        super().__init__(key)
        self.key, self.options = key, options


class Counter:
    def __init__(self):
        self.steps = 0          # scan.step executions (including aborted re-runs)
        self.leaves = 0         # completed paths
        self.branch_nodes = 0   # decision nodes (unknown facts split)
        self.windows = 0
        self.state_visits = 0   # distinct scanner states whose expansion was computed


class View:
    """Fact access under knowledge K plus a (partial) path assignment."""

    def __init__(self, K, grid, asg, reads, branched, failed):
        self.K, self.grid, self.asg = K, grid, asg
        self.reads, self.branched, self.failed = reads, branched, failed

    def _item_failed(self, i):
        a = self.K.items[i].get('analysis', {})
        if a.get('status') == 'failed':
            self.failed[('item', i)] = a.get('reason')

    def state(self, i):
        self.reads.add(('S', i))
        if self.K.state[i] is not None:
            return self.K.state[i]
        self._item_failed(i)
        key = ('S', i)
        if key in self.asg:
            return self.asg[key]
        raise Branch(key, STATES)

    def side(self, i):
        self.reads.add(('D', i))
        if self.K.side[i] is not None:
            return self.K.side[i]
        self._item_failed(i)
        key = ('D', i)
        if key in self.asg:
            return self.asg[key]
        raise Branch(key, SIDES)

    def rank(self, j):
        a, b = self.state(j), self.state(j + 1)
        self.reads.add(('R', j))
        if 'WIDE' in (a, b):
            return None
        r = self.K.rank[j]
        if r[0] == 'known':
            return r[1]
        for e in self.K.case.get('edges', []):
            if (e['first'], e['second']) == (j, j + 1) and e.get('status') == 'failed':
                self.failed[('edge', j)] = dict(e.get('failures', {}))
        key = ('R', j)
        if key in self.asg:
            return self.asg[key]
        raise Branch(key, self.grid)


def _local_grid(K, edges, nonneg):
    """Common representative grid for the (at most two) edges compared inside
    one step: every order type of <=2 unknowns versus the knowns of that pair.
    Sound for step-local enumeration because a step's outcome depends on rank
    values only through comparisons between these edges."""
    known = sorted({K.rank[j][1] for j in edges if 0 <= j < K.n - 1
                    and K.rank[j][0] == 'known' and K.rank[j][1] is not None})
    return [None] + rank_grid(known, 2, nonneg)


def _make_scan(K, settings, view):
    n = K.n

    def dimension(i):
        return dict(state=view.state(i)) if 0 <= i < n else None

    def side(i):
        return view.side(i)

    def distance(a, b):
        v = view.rank(a)
        return _as_number(v) if v is not None else None

    return ref._Scan(n, settings, dimension, side, side, distance)


def _structural_entries(first, target, isolated, forced):
    if first == 0:
        return [(0, True, False, None)]
    if isolated and first == target:
        return [(first, True, False, None), (first, False, False, None)]
    out = []
    boundary_free = first - 1 not in forced and first not in forced
    for opening in ([True] if first == 1 else [True, False]):
        out.append((first, opening, False, None))
        if first > 1 and boundary_free:
            out.append((first, opening, True, 'reserved'))
    if boundary_free:
        out.append((first + 1, False, False, 'paired'))
    return out


def _check_prereq(scan, first, prereq):
    """Path-sensitive reachability of an entry from the step at first-1."""
    if prereq is None:
        return True
    if not scan.allowed(first - 1):
        return False
    if prereq == 'reserved':
        return scan.later_wins(first - 1)
    return True


def _run_from(scan, entry, target, counter, first):
    i, opening, reserved_here, prereq = entry
    if not _check_prereq(scan, first, prereq):
        return 'PRUNED'
    while i <= target:
        # The attempt is counted before the call: an attempt that aborts with
        # Branch is real work and must not disappear from the account.
        counter.steps += 1
        unit, nxt = scan.step((i, opening, i if reserved_here else -1),
                              include_single=i == target, include_pair=i + 1 >= target)
        if unit is not None and any(s['item'] == target for s in unit['slots']):
            return unit
        i, opening = nxt[0], nxt[1]
        reserved_here = nxt[2] == nxt[0]
    return None


def _grid_for(K, target, nonneg):
    free = sum(1 for j in range(min(K.n - 1, target + 3)) if K.rank[j][0] == 'free')
    return [None] + rank_grid(K.known_scores, free, nonneg)


def _need_list(keys):
    out = {}
    for k in sorted(keys):
        if k[0] == 'S':
            out[(k[1], 'DIMENSIONS')] = dict(item=k[1], kind='DIMENSIONS')
        elif k[0] == 'D':
            out[(k[1], 'ANALYSIS')] = dict(item=k[1], kind='ANALYSIS')
        else:
            out[(k[1], 'RANK')] = dict(item=k[1], kind='RANK', second=k[1] + 1)
    return list(out.values())


def _finish(status, unit, first, counter, reads, branched, failed):
    return dict(status=status, unit=unit, first=first, steps=counter.steps,
                leaves=counter.leaves, branch_nodes=counter.branch_nodes, windows=counter.windows,
                state_visits=counter.state_visits,
                needs=_need_list(branched) if status != 'certified' else [],
                support=sorted(reads), branched=sorted(branched),
                extra_failures={f'{k[0]}:{k[1]}': v for k, v in failed.items()})


# ------------------------------------------------------------------ C-PW ----
def certify_pw(case, target, lookbehind=2, extension='exhaustive', budget=None,
               nonneg=False, header_authoritative=True):
    """extension: 'exhaustive' (down to 0), 'budget' (at most `budget` extra
    windows beyond the reference start), or 'heuristic' (stop when every
    surviving entry is internally ambiguous)."""
    data = ref._Input(case)
    K = Knowledge(case, header_authoritative)
    settings = data.settings
    forced = set(settings['hard_isolates'])
    grid = _grid_for(K, target, nonneg)
    counter = Counter()
    isolated = K.state[target] == 'WIDE' or target in forced
    first = target if isolated else max(0, target - lookbehind)
    start = first
    while True:
        counter.windows += 1
        reads, branched, failed = set(), set(), {}
        units, per_entry_ambiguous, live_entries = set(), [], 0
        for entry in _structural_entries(first, target, isolated, forced):
            mine, stack = set(), [{}]
            while stack:
                asg = stack.pop()
                view = View(K, grid, asg, reads, branched, failed)
                scan = _make_scan(K, settings, view)
                try:
                    res = _run_from(scan, entry, target, counter, first)
                except Branch as b:
                    counter.branch_nodes += 1
                    branched.add(b.key)
                    for v in b.options:
                        stack.append({**asg, b.key: v})
                    continue
                counter.leaves += 1
                if res == 'PRUNED':
                    continue
                mine.add(canon(res) if res is not None else 'NONE')
                if len(units | mine) > 1 and extension == 'exhaustive' and first > 0:
                    break          # early exit: this window cannot certify
            if mine:
                live_entries += 1
                per_entry_ambiguous.append(len(mine) > 1)
            units |= mine
            if len(units) > 1 and extension == 'exhaustive' and first > 0:
                break
        if len(units) == 1 and 'NONE' not in units:
            import json
            return _finish('certified', json.loads(next(iter(units))), first, counter, reads, branched, failed)
        stop = first == 0
        if extension == 'budget' and start - first >= (budget or 0):
            stop = True
        if extension == 'heuristic' and per_entry_ambiguous and all(per_entry_ambiguous):
            stop = True
        if stop:
            return _finish('need_facts', None, first, counter, reads, branched, failed)
        first -= 1


# ------------------------------------------------------------------ C-SL ----
def _local_outcomes(K, settings, grid, fn, counter, reads, branched, failed):
    """All results of fn(scan) over assignments of facts read inside fn."""
    outs, stack = [], [{}]
    while stack:
        asg = stack.pop()
        view = View(K, grid, asg, reads, branched, failed)
        scan = _make_scan(K, settings, view)
        try:
            outs.append(fn(scan))
        except Branch as b:
            counter.branch_nodes += 1
            branched.add(b.key)
            for v in b.options:
                stack.append({**asg, b.key: v})
    return outs


def certify_sl(case, target, lookbehind=2, extension='exhaustive', budget=None,
               nonneg=False, header_authoritative=True, local_grid=True, early_exit=True):
    """Window loop as in the reference, with step-local branching.

    The expansion of a scanner state depends only on the knowledge K and on the
    target, never on the window.  The reachable subgraph of a state is therefore
    window independent as well, so both are memoised across the windows:
    extending the window by one position costs only the states that are new to
    the subgraph.  The whole call is linear in the number of scanner states
    instead of quadratic in the number of windows.

    `early_exit` is accepted for compatibility.  It can no longer shorten the
    work: the memo already computes every reachable state once, and a window
    that already holds two different units can never certify.
    """
    import json
    data = ref._Input(case)
    K = Knowledge(case, header_authoritative)
    settings = data.settings
    forced = set(settings['hard_isolates'])
    grid = _grid_for(K, target, nonneg)
    counter = Counter()
    memo = {}
    state_memo = {}      # state -> (units, successors, reads, branched, failed)
    reach_memo = {}      # state -> (units, reads, branched, failed) of its subgraph

    def expand(key, fn, cursor_pos):
        if key not in memo:
            r, b, f = set(), set(), {}
            g = _local_grid(K, (cursor_pos, cursor_pos + 1), nonneg) if local_grid else grid
            outs = _local_outcomes(K, settings, g, fn, counter, r, b, f)
            memo[key] = (outs, r, b, f)
        return memo[key]

    def state_outcome(state):
        """The outcomes of one scanner state and its successors.

        The expansion is memoised globally, so a state is expanded once for
        the whole call and not once per window.
        """
        cached = state_memo.get(state)
        if cached is not None:
            return cached
        i, no, r = state
        cursor = (i, not no, i if r else -1)

        def one(scan, cursor=cursor, i=i):
            counter.steps += 1
            return scan.step(cursor, include_single=i == target, include_pair=i + 1 >= target)
        outs, rr, bb, ff = expand(('st', i, no, r), one, i)
        units, succ = set(), []
        for unit, nxt in outs:
            counter.leaves += 1
            if unit is not None and any(s['item'] == target for s in unit['slots']):
                units.add(canon(unit))
            else:
                succ.append((nxt[0], not nxt[1], nxt[2] == nxt[0]))
        counter.state_visits += 1
        result = (units, tuple(succ), rr, bb, ff)
        state_memo[state] = result
        return result

    def reach(entry):
        """Units, reads, branches and failures of the subgraph of one state.

        The subgraph is collected without re-walking the states that another
        window already resolved, and it is resolved bottom up because every
        successor has a larger index than its predecessor.
        """
        cached = reach_memo.get(entry)
        if cached is not None:
            return cached
        pending, order, seen = [entry], [], set()
        while pending:
            state = pending.pop()
            if state in seen or state in reach_memo:
                continue
            seen.add(state)
            order.append(state)
            for succ in state_outcome(state)[1]:
                if succ[0] <= target and succ not in reach_memo:
                    pending.append(succ)
        order.sort(key=lambda state: -state[0])
        for state in order:
            units, succ, rr, bb, ff = state_outcome(state)
            acc_units, acc_reads, acc_branched, acc_failed = set(units), set(rr), set(bb), dict(ff)
            for nxt in succ:
                if nxt[0] > target:
                    acc_units.add('NONE')
                    continue
                sub = reach_memo.get(nxt)
                if sub is None:
                    sub = reach(nxt)
                acc_units |= sub[0]
                acc_reads |= sub[1]
                acc_branched |= sub[2]
                acc_failed.update(sub[3])
            reach_memo[state] = (acc_units, acc_reads, acc_branched, acc_failed)
        return reach_memo[entry]

    isolated = K.state[target] == 'WIDE' or target in forced
    first = target if isolated else max(0, target - lookbehind)
    start = first
    while True:
        counter.windows += 1
        reads, branched, failed = set(), set(), {}
        units = set()
        for (i, o, r, prereq) in _structural_entries(first, target, isolated, forced):
            if prereq is not None:
                outs, pr, pb, pf = expand(('pre', first, prereq),
                                          lambda s, pr=prereq: _check_prereq(s, first, pr), first - 1)
                reads.update(pr)
                branched.update(pb)
                failed.update(pf)
                if not any(outs):
                    continue
            entry = (i, not o, r)
            sub = reach(entry)
            units |= sub[0]
            reads |= sub[1]
            branched |= sub[2]
            failed.update(sub[3])
        if len(units) == 1 and 'NONE' not in units:
            return _finish('certified', json.loads(next(iter(units))), first, counter, reads, branched, failed)
        stop = first == 0 or (extension == 'budget' and start - first >= (budget or 0))
        if stop:
            return _finish('need_facts', None, first, counter, reads, branched, failed)
        first -= 1


# ------------------------------------------------------- contract wrapper ----
def _support_snapshot(case, support):
    from prior.validity import support_snapshot
    return support_snapshot(case, support)


def _without_authoritative_headers(case):
    """A case whose headers cannot stand in for a missing analysis.

    `reference.certify` reads a valid header as the fact of an item whose
    analysis is missing.  Branch beta says that a header is not authoritative,
    so the header is removed for exactly the items the knowledge model would
    leave free.  The reference file itself stays untouched.
    """
    items = []
    for item in case['items']:
        ident = dict(rotation=item.get('rotation', 0), orientation=item.get('orientation', 1))
        analysis = item.get('analysis', {'status': 'unknown'})
        computed = analysis.get('status') == 'computed' and _valid_for(analysis.get('fact'), ident)
        if computed or 'header' not in item:
            items.append(item)
        else:
            items.append({k: v for k, v in item.items() if k != 'header'})
    out = dict(case)
    out['items'] = items
    return out


def certify_contract(case, target, engine=None, **kw):
    """Route-A composition that preserves the reference failure contract.

    * reference blocked   -> returned unchanged (failures never swallowed);
    * reference certified -> returned unchanged;
    * reference need_facts-> branching engine; adopted only if it certifies.
    Failed evidence first seen by the engine is reported in `extra_failures`
    and never changes status (explicit policy, see report).

    The baseline is always judged under the same knowledge as the engine.  A
    beta request therefore uses a baseline whose headers are not authoritative;
    otherwise an alpha certificate could be returned for a beta request and the
    beta check would never run."""
    engine = engine or certify_sl
    header_authoritative = kw.get('header_authoritative', True)
    baseline_case = case if header_authoritative else _without_authoritative_headers(case)
    base = ref.certify(baseline_case, target)
    out = dict(selected=base, baseline=base, engine=None, adopted=False,
               total_steps=base['steps'])
    if base['status'] != 'need_facts':
        return out
    res = engine(case, target, **kw)
    out['engine'] = res
    out['total_steps'] += res['steps']
    if res['status'] == 'certified':
        out['adopted'] = True
        out['selected'] = dict(status='certified', unit=res['unit'], needs=[], failures={},
                               first=res['first'], steps=res['steps'],
                               extra_failures=res['extra_failures'], support=res['support'],
                               snapshot=_support_snapshot(case, res['support']))
    return out
