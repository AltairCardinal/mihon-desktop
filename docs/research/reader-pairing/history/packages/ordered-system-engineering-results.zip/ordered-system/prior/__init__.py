"""Prior exploratory algorithms; see NOTES.md for scope and limitations."""
