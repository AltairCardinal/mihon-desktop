import unittest
from benchmark import run_benchmark, build_scoped


class BenchmarkContracts(unittest.TestCase):
    def test_quick_reports_real_and_simulated_cost_separately(self):
        result=run_benchmark(quick=True)
        self.assertEqual(result['schema'],'ordered-engineering-benchmark-v1')
        self.assertEqual(result['metadata_rates'],[0,20,100])
        self.assertTrue(all(x['python_wall_ns']>0 for x in result['runs']))
        self.assertTrue(all(x['metrics']['requests']>0 for x in result['runs']))
        self.assertTrue(any(x['metrics']['memo_hits']>0 for x in result['runs']))
        self.assertTrue(any(x['metrics']['published']>0 for x in result['runs']))
        self.assertTrue(all('simulated_service_ns' in x for x in result['runs']))
        self.assertTrue(any(x['candidate_metrics'].get('scope_checks',0)>1 for x in result['runs']))
        baseline={x['metadata_rate_percent']:x for x in result['runs']
                  if x['strategy']=='baseline' and x['scenario']=='mixed'}
        self.assertGreater(baseline[20]['metrics']['engine_runs'],baseline[0]['metrics']['engine_runs'])

    def test_scoped_validation_rejects_changes_and_unowned_results(self):
        from generator import Knowledge,make_witness
        k=Knowledge(make_witness(count=2)); k.observe(0); k.observe(1)
        bundle=build_scoped(); case=k.case()
        proof=bundle['certify'](case,0)
        self.assertTrue(bundle['validate'](proof,case))
        self.assertFalse(bundle['validate']({},case))
        k.invalidate(1)
        self.assertFalse(bundle['validate'](proof,k.case()))

    def test_scoped_session_unread_metadata_hit_read_change_miss(self):
        from generator import make_witness
        from runtime import Session
        witness=make_witness(count=6); witness['settings']['hard_isolates']=[2]
        bundle=build_scoped()
        session=Session(witness,candidate=bundle['certify'],validator=bundle['validate'])
        for i in range(6): session.apply(dict(op='observe',item=i))
        session.request(2)
        session.apply(dict(op='metadata',item=5,orientation=3))
        self.assertTrue(session.request(2)['memo_hit'])
        session.apply(dict(op='metadata',item=2,orientation=3))
        self.assertFalse(session.request(2)['memo_hit'])

    def test_scoped_rejects_known_fact_conflict(self):
        from generator import Knowledge,make_witness
        k=Knowledge(make_witness(count=3))
        for i in range(3): k.observe(i)
        bundle=build_scoped(); proof=bundle['certify'](k.case(),1)
        k.analyses[1]['fact']['side']='A' if k.analyses[1]['fact']['side']!='A' else 'B'
        self.assertFalse(bundle['validate'](proof,k.case()))


if __name__ == '__main__': unittest.main()
