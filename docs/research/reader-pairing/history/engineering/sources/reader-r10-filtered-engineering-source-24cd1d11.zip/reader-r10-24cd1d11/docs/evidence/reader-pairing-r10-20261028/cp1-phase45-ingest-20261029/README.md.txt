# Phase45 W2 animation contrast ingestion

## W2 execution and event derivation

Input is the fixed phase45-animation-contrast batch. The 19 producer artifacts were copied byte-for-byte; input-manifest.json records source and copy SHA-256 values. phase45-w2-derived.json independently joins the six raw action rows to event captures and actual-draws by owner, generation, location sequence, probe ticket and frame, then verifies the integer-nanosecond intervals against intervals-v2.

The native focused run was 1/0/0/0, the run guard passed with 32 samples and 0 sample errors, and all 17 recorded PID/creation identities are now absent. Each jump has two successful capture returns with the same full identity; both are retained. Native ticket and probe ticket use different token spaces and are joined by the receipt; action callToken is separate.

## Original 176 page dimensions

actual176-size/vol08-176-header-dimensions.json records dimensions read from at most the first 30 uncompressed bytes of each manifest-listed CBZ member. The manifest SHA and whole archive SHA both match canonical-oracle-v2; all 176 page filenames and uncompressed member lengths match. Results: 0 square, 8 wide, 168 portrait, 0 unknown. One non-page ComicInfo.xml archive member is excluded.

Page SHA values are references from the manifest, not independently recomputed. No image pixels were decoded. This is metadata for the fixed archive only, not a performance estimate or live UI guarantee.

## Limits

The W2 arms ran true then false in separate fresh runtime/profile/probe epochs, three requests each. FrameClock, motionDurationScale, holder-ready to final prepare consumption, full clipping geometry and fixed page-list mapping are not established. The diagnostic does not validate the 43.335ms conditional bound, a finite permit model, or the original 50-sample 100ms acceptance; animation=false is not inferred as a default or a product gain.
