# Android 同身份普通请求原位提优（候选移植包）

- 基线：`26bc794dcd1029b6d7a9ff8113563d6c36112d34`
- 来源提交：`07114ecf015dd28c84e57b5782840bb1c6f75244`
- 补丁：`android-in-place-promotion.patch`

补丁只带 Android `HttpPageLoader` 的同一普通源请求优先级提升、两个最小 scheduler/runner 支持 API，以及对应的 focused Android integration/真实 HTTP 测试。它要求基线 `ReaderPage` 已含 `ReaderPageContentFact` 与 `captureContentFact` / `consumeContentFact`；该文件在基线与来源提交间未变。

已归档的 7 方法结果是 `:app:testReleaseUnitTest` Android app JVM 测试：6 个 `HttpPageLoaderIntegrationTest` 方法与 1 个真实 HTTP wiring 方法通过，0 失败、0 跳过；另有独立 MockWebServer 原件显示 off 对照 3 请求失败、on 路径 2 请求通过。它不是实体设备验收，也不是主干交付。运行记录的静态 `source_binding` 没有绑定 Android loader 和两个 Android test 文件的字节哈希；manifest 明确保留此限制。

`apply-check-base/` 仅含五个基线版本文件，用于对补丁执行一次 `git apply --check`；未应用补丁、未编译或运行测试。清单列出精确源提交、各文件哈希、命令、XML 与原始 HTTP 证据路径。
