# R10 H02/H04 有限分析证据

本目录是归档输入的重新计算与条件模型，不是新的性能采样或生产可达性证明。

复现（仓库根目录，Python 标准库，UTF-8）：

```powershell
python scripts/tests/reader-pairing-r10-bounds-test.py
python scripts/research/reader_pairing_r10_bounds.py --manifest docs/evidence/reader-pairing-r10-20261028/collaboration-inputs-20261029/input-manifest.json --output <本次输出目录>
```

- `summary.json`：逐一验证14原件的SHA后，使用完整50个ID重算L1/V3中位与必要条件。T为L1总体中位减100ms，即30,196,850ns；不是耗时≤100ms。16ms约束只应用于原表指定的页组/动作组中位，target与complete分别计算。
- `samples.csv`：保留50个ID、旧/候选端点、到T的算术削减和一个充分分配选择。选择原最快26项并降到T只是无耦合构造，不是唯一必要分配。V3受限未加权L1最小总削减为1,641,698,203ns，不与另一研究F0向量混用。
- `groups.csv`：56个原组全保留，包含6个仅作描述的scenario组。重算值与原表逐组一致；没有逐样本16ms断言。
- `diagnostics.json`：V1/V2各3请求全部保留。计算截断至本请求窗口的工作区间并集、区间长度之和及未覆盖墙钟；6个并集均与原件一致。每phase保留观测方法entry/return、缺失release/cancel、correlation、来源SHA及未知因果关系；physical_actual_exit始终未知，方法返回不能证明native/lazy codec/GPU真实退出或许可释放。它们不能相减得到可实现收益，也不能作为不可消除服务下界。
- `model-examples.json`：三个明确假设的小模型，分别计算取消后残余物理阻塞、token持有到消费及无关未来占用不抬高目标完成时间。不是从诊断中推断出来的生产作业。
- `focused-tests.log`、`evidence-manifest.json`：19个focused测试、32个独立离散start-vector穷举oracle实例，以及源码/输入/输出哈希。

## 有限调度模型边界

模型支持至多8个作业、整数时间horizon≤64、显式依赖、release/deadline和分开的resource demands；节点预算耗尽返回SEARCH_LIMIT，不冒称最优。`objective_job_ids`只优化指定终点，所有固定占用仍约束资源；缺省目标是全部作业及固定占用清空，不能解读成本请求完成时间。

`started_at`固定历史开始，不能重排；未开始作业才消费release。`cancel_at`不缩短duration或资源占用。逻辑fact、decode物理与runner current/stale分开建模；固定interval在条件假设中允许逻辑token从admission持有至result消费，物理占用独立保持到假设的actual exit。只有实际job清理证据才能把该假设替换为生产事实；本目录不把诊断call return输入为真实物理退出。current→stale例中同一物理作业跨转换持续占用。未来多资源作业的同duration仅代表声明的服务假设，不代表已重建生产token生命周期。

duration缺失或dependencies_complete缺失时返回UNKNOWN；显式optimistic_relaxation允许未知服务取0、遗漏未知边，但只给RELAXED_MODEL_OPTIMUM。模型最优始终是有限整数域中的条件结论；它不提供生产服务下界、连续时间最优、生产调度许可或生产可达证书。

真实输入现只能保证未来时延非负，即[0,无已证明有限上界]；只有另加单调降低假设才可写[0,L]。缺少必需作业/依赖、admission/消费、准确Certified/发布/呈现机会和可靠服务成本，故生产状态保持UNDETERMINED，H02/H04总体研究仍未完成。
