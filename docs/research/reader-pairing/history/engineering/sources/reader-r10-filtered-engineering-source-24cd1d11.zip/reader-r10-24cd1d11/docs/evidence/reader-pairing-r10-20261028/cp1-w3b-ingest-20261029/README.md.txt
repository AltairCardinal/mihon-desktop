# CP1 W3-B GREEN3 接收

状态以接收期间源目录 27 个文件的前后 SHA 是否一致为准，详见 derived.json。

## 字节绑定

raw-evidence/originals/ 保存 result receipt、postformat freeze、协调器 start/final/state/log、资源守卫 JSONL、wrapper start/final、nativeWindowTest XML、原始 causal ledger、plan/preflight 与中央 state 的字节副本。input-manifest.json 记录源路径、大小、SHA-256 和逐文件复制校验。raw-evidence/sources/ 保存 3 个用于事件与合同来源的精确源码字节；完整 16 项冻结源码摘要及当前 SHA 对照也在 manifest。

receipt 为 VALID_GREEN，中央 coordinator state 为 PASSED / exit 0（19:59:53.183083–20:01:37.931181 +08:00）。新鲜 XML 为 4876 bytes，receipt 与当前 XML SHA 相同，3 个声明 selector 均通过且 failure/error/skipped 为 0。计划声明的编译 test-source closure 有 5 个源；协调器日志与状态原件保留供复核。

## 派生规则与边界

derived.json 保留三个原始 ledger row、每行全部同 generation/locationSequence 的 decision groups（包含选中与未选中）、ACK draw identity 匹配的 decision groups、decision bracket 内捕获、同 location 的全部 capture/draw，以及 ACK 桥接详情。native receipt ticket token 与 Probe event ticket token 属不同命名空间；只按 actual-draw.atNanos == completeUnitAckAtNanos 加 generation/locationSequence/frame 桥接，再按 owner/ticket/frame 保留所有 capture 候选。

所有差值为整数纳秒的描述性跨度。ENTER→ACQUIRED 含 observer 采样开销，不等同 mutex 等待；RETURN→ACK 不证明必要因果前驱。13 个 allowed decision reason 中本次捕获实际观察到 3 个，其余 10 个仅为合同允许值。PID+creation CIM 核查只确认同一进程身份是否仍活动，不能证明硬件执行已退出。

三行不是原 50 样本、优化对照或 100 ms 达标证据；权重及物理 IO/GPU 仍未观测，motionDurationScale 与 frameClock 为 UNKNOWN。
