# R10-04 内容合并轨迹：共同层与Owner已验证，完整资源图继续

本批在原树/HEAD `d94c4f5b947562ab736d288e725c749d35304533` 加各卡明确绑定的WIP上运行；所有Gradle沿中央coordinator/原guard串行、离线、静默，实际运行期间固定源码和HEAD。仅定向范围，没有完整类/模块、原50或发布。

| 阶段 | 实际结果 | 源与原进程身份 |
|---|---|---|
| [RED必要生产编译](common-red-compile-01/execution-receipt.json) | 仅domain:jvmJar成功，0tests | 34源/diff相符、9原身份退出 |
| [共同层RED](common-red-01/execution-receipt.json) | 5/3/0/0；None/overflow通过，后三因缺事件失败 | 34源/diff相符、12原身份退出 |
| [格式01](common-format-01/execution-receipt.json) | 精确3副本的通配import lint失败，0tests；不是行为RED | 37源/diff相符、10原身份退出 |
| [格式02](common-format-02/execution-receipt.json) | 展开为同5显式import后，3精确副本Apply+Check成功；退出后才回拷原源 | 38源/diff相符、10原身份退出 |
| [GREEN必要生产编译](common-green-compile-01/execution-receipt.json) | 仅domain:jvmJar成功，0tests | 36源/diff相符、9原身份退出 |
| [共同层GREEN](common-green-01/execution-receipt.json) | 新5＋受影响既有5，精确10/0/0/0、2Test编译闭包 | 36源/diff相符、12原身份退出 |
| [Desktop Owner RED](owner-red-01/execution-receipt.json) | 3/1/0/0，buffer2支持通过；缺common buffer接线的明确断言在全部健康检查之后失败 | 41源/diff相符、11原身份退出 |
| [Owner精确四源格式](owner-format-01/execution-receipt.json) | 同根editorconfig、4字节副本Apply+Check；退出后回拷，没有新测试 | 43源/diff相符、9原身份退出 |
| [Owner GREEN](owner-green-01/execution-receipt.json) | Owner同因果合同＋直接受影响兼容3，共4/0/0/0，buffer2不重复执行 | 43源/diff相符、11原身份退出 |

新合同实际执行production Coordinator：两caller同Entry仅首port、last waiter取消但producer尚未退出仍可join、close返回早于不合作port/Deferred实际结束、每份lease唯一交付/幂等release。RED均在真实操作和清理后验证事件；默认None原scope不隐式继承caller诊断link。GREEN保持原key、首port选择、synchronized范围及content.start位置，不新增withContext取消点或准入容量。五个既有合同覆盖同一首port/单飞/取消/关闭接线，未运行整类。

`ReaderContentTraceBuffer`是显式可选有界原子缓冲，只有不可变scalar/request/link元数据，不持有content bytes/owner/bitmap，不回调外部代码或IO。默认null不建立buffer/ID/事件，也不读取隐式caller link；显式link可沿既有独立scope进入真实port。新增字段、分支、enum及元数据路径的CPU成本未实测，不能说零成本或默认采用已有净收益。

共同层事件sequence只在该缓冲内排序，不是跨缓冲总序或系统时间。PORT_API_RETURN仅port方法返回/抛出；JOB_COMPLETED为Deferred真实completion；CLOSE_RETURN/取消不是join，也不是native codec/kernel/GPU物理退出。snapshot.bufferComplete只证明无overflow/未发布槽，不能替代producer join、lease守恒和健康检查。完整Desktop Entry/allocation/lease、Runner/decode/global region/optional/sampling资源接线仍继续04，不把本批共同层当完整轨迹。

最终GREEN源字节：buffer `9ec67fc540c053928f3fc7e9783d0f679c96b8cdd9aa1d05a6689bf082cf1981`；Coordinator `b87bcbcd79e54334d1fa2bf36630f5787d574d48b7b5c1d9a574a1f5e5d9034a`；新Test `3b7cd683b595387f4394c217b0b3110963070da9657ffe93d1c5b1d31cea8089`。旧RED及GREEN格式前源ZIP保留，格式映射见[原字节映射](common-format-02/formatted-source-map.json)，不能把最后源码追认到旧测试。

资源边界保持原domain-focused 3072/2048MiB及test256m，生产编译使用现成compile profile，未提高profile限额。format02初次前置等待没有启动guard/Gradle；新主树Gradle daemon52824曾被临时等待器当未知重载，核程序/完整创建身份及日志idle后才允许，并继续检查新build，未关闭用户进程。该配置修订不改变测试判据。

Owner GREEN只给实际共同层Coordinator传入显式buffer。健康marker实测root/reader/两个caller全部completed、leases0/background0；共同Entry/实际port/reader与两个租约以ID关联，不用时间邻近猜join。四源格式前后字节及格式器必需的if代码块展开见[映射](owner-format-01/formatted-source-map.json)。默认None没有buffer/ID/事件存储，但Owner新增包装/局部变量/分支的CPU成本仍未实测；内部研究工具不是默认性能采用。

本批只闭合内容打开这条producer/lease链。Factory选择入口、image Entry/allocation/eviction、Runner/decode/global region/optional/sampling及真实32轨迹继续原04，不能从本批推05离线界、06调度最优或07达标。下一簇原四方法Pipeline/Factory接口RED已在TMP准备，尚未落源/运行，不随本批冒称验证。

[临时执行器当前原字节](tooling/r10-focused-card-control-20261030.py)仅适用于其source hash等于归档值的卡；它是本批运行证据，不是另建产品/维护系统。更早未绑定此脚本SHA的卡不追认同一执行器版本。
