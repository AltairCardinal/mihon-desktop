# R10 资源映射（2026-10-29）

这是固定源码锚点的结构映射，不是运行时追踪或性能结果。11 个源码文件的行号和 SHA-256、v3 输入哈希及字段缺口见同目录 resource-map.json。

## 资源边界

| 资源 | 作用域与容量 | 持有及释放边界 |
|---|---|---|
| Scheduler active | 每 session；当前 3 | pollNext 入 active，complete/cancel/replacement 移出；属于逻辑调度。 |
| Page Runner permit | 每 session；4 = 3 + stale allowance 1 | 覆盖 prepare 和 materializePage；返回后、port.complete 前释放。prepare 可持 permit 等 storeMutex。 |
| Runner work counter | per Runner + process 汇总 | poll 后、Job start 前加；Job completion 回调才减，包含等 permit 的工作，不代表硬件退出。 |
| Chapter permits | 每 session；当前 4 | 只包围 materializeChapter；与页面 Runner 池分开。 |
| Store mutex | 每 session；1 | ensureStoreWritable 内执行 beginSessionFast；prepare 缺 encoded ref 时可能等待。 |
| Fact publisher workers | 每 publisher；4 | loadFactPage 和后续采样期间占用；等 Runner 时仍保留 slot。 |
| Fact budget | 每 pairing location 的逻辑窗口 | required/speculative共用 active上限4；optional逻辑并发2、额外页16；另有32MiB、15s、512KiB header限制。不是 semaphore。 |
| Pipeline decode slots | 每 image pipeline；默认3 | 内容打开后进行 pipeline admission，包住 decoder API，finally释放。 |
| Region gate | pipeline companion 跨 runtime；1 | 仅 REGION_TILE；FULL_PAGE/ANIMATION 不取此门。createEntry 在 loader 前取 CAS，loader 可含 content open 与 pipeline decode wait/API，memory attach 后 finally 释放；因此持门时可能仍在等 content/decode。 |
| Optional token | 同一 companion 跨 pipeline；1 | 仅普通 optional Entry取得，Entry Job completion后释放；与speculation、decode、factBudget optional分开。 |
| Pairing sampling slot | SpreadSampler object跨 runtime；1 | 持有一个 sampling block；regions顺序运行，其他 pairing sample 不交错；与 pipeline Region gate 分开。 |
| Page image Entries | 每 pipeline、按 decode key | singleflight/cache身份，不是有界池；Entry数不等于并发容量。 |
| Content open Entries | 每 owner/coordinator、按 request | singleflight + pending/lease引用，无固定pool cap；Job完成且引用归零后移除。 |

## v3 草案字段核对

v3 manifest 状态为 TMP_V3_UNBUILT_UNRUN_NOT_READY，声明正式源码未修改且未构建/测试。草案有 decode queue/API/slot 事件、Region wait/acquire/release，以及 content Entry/acquire/lease/API return/Job completion 身份链；Runner permit 全链未接线。Optional companion token 缺 acquire/release identity；decode 事件没有实际 limit/permit ID。factory 草案的 researchCacheTrace 默认 null。因此以下是静态草案覆盖情况，不是已运行观测。

| 缺证据 | 草案覆盖 | 最小后续观测范围 |
|---|---|---|
| Runner WAIT/ACQUIRE/RELEASE 与 Job exit | 缺失 | 一个 session 内 stale/cancel work 与最多3个新请求重叠；第二 session核对process counter。 |
| Pipeline decode ID/容量 | 部分：队列、API、slot事件 | 单 pipeline，至少2个重叠waiter，覆盖排队取消和admitted decode；记录实际limit并join Jobs。 |
| 全局 Region gate | 草案有事件，未运行；跨runtime join/cap未证实 | 同 JVM 两 pipeline，共用trace；两个 REGION_TILE竞争、一个 FULL_PAGE对照和等待取消。 |
| Optional companion token | 缺 token identity/lifecycle | 同 JVM 两 pipeline，一个持token、另一个竞争；首Entry Job完成/取消后再试。 |
| Entry/lease/exit | 草案含协程/API身份链，未编译运行 | 同key两个acquire，分别close lease，再覆盖cancel/owner close；join producer并核对buffer及lease terminal。 |
| Pairing sampling slot | 缺失 slot identity/lifecycle | 同 JVM 两 runtime竞争，覆盖 wait、budget pause/cancel 与 release；关联内部 region requests。 |
| 默认 None/wiring | trace默认null，不采集 | 若批准独立采集，显式注入recorder、真实版本/算法，让参与runtime共用或汇总trace。 |

权重、生产并发/持有时长、物理磁盘/网络/kernel I/O、native codec/GPU 子任务退出均为 UNKNOWN。本次未运行测试、构建、应用或进程，也未提交。

root只读复核：11个正式源码SHA全部匹配；另核Pipeline companion中的region/optional两个CAS与SpreadSampler singleton CAS，确认是三种独立全局资源。旧PARTIAL的抄录SHA已按原文件实际哈希纠正，未改旧文件。[UI gate审计](ui-gate-audit.md)补充了FULL_PAGE与REGION_TILE不同的持槽顺序；不把无静态必死证据当真实推进。资源映射仅作为后续观测/条件模型的结构输入，当前不具备运行时权重。
