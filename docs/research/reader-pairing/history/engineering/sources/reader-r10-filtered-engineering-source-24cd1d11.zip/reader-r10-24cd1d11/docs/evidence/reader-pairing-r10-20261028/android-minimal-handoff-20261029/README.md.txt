# Android普通同身份源请求提优：最小源码交付

状态：Android app JVM/Robolectric 的 A/B 定向运行已补齐固定五文件运行时绑定；square BEFORE 保留一项有意 RED。不是实体设备、发布或 CP1 整体采用结论。

- [最小patch](android-in-place-promotion.patch)，SHA-256 `23e278e763502e26c4f8dc4bdf4964572439be578471ea81cd968b85127e82ec`。
- 基线 `26bc794dcd1029b6d7a9ff8113563d6c36112d34`，特性目标 `07114ecf015dd28c84e57b5782840bb1c6f75244`。只含loader、shared scheduler/runner和两份Android测试共5文件；没有Desktop、checkpoint、NoOp或其他研究改动。
- [五文件核查](current-five-source-check.json)证明固定R10树HEAD5df15的这5文件逐字节等于目标；它只核源码，不证明测试进程实际装载字节。
- [原提取清单](source-manifest.json)及[原说明](source-readme.md)保留完整命令、文件指纹和已有7方法/HTTP证据。原说明中的TMP路径记录产生位置；交付patch使用本目录相对链接。

旧测试实际有7方法通过，真实HTTP对照从3次请求降为2次。但其静态运行binding仅完整绑定两个shared文件，未绑定loader及两测试，因此不追认为最终目标的完整运行时字节证据。历史计划：当时安排旧loader反事实RED后恢复目标loader再做7方法GREEN；现由下方2026-10-30 mode-A/mode-B实测替代。B-02的square BEFORE仍为有意RED，不能称8个unique methods全绿。

仅临时基线文件上的`git apply --check`通过，未执行产品整合。本patch针对上述固定基线；最新主干API可能不同，移植时需按实际代码核对及focused验证，不整支cherry-pick研究提交。普通源请求的身份/绑定/优先级更新不授予配对事实许可，也不继承旧fact gate。

## Android 五文件运行时绑定更新（2026-10-30）

原先记录的七方法结果及 source_binding 限制仍准确描述旧 run；以下 mode-A/B 是新的运行证据，并闭合固定五文件候选的本地运行时绑定。

- [mode-A-01 原件](../android-promotion-identity-20261029/mode-A-01/execution-receipt.json)，SHA-256 29730058c3b4e94792ed8d32525a6a7fb049812c03915015aaa40f9b5356c3c9：旧 loader 反事实 RED。原始结果 3 tests / 3 failures / 0 errors / 0 skipped，对应 1 个唯一方法 / 1 个唯一失败（Gradle 重试）。旧路径记录 3 HTTP requests、2 held responses、3 closed responses、remaining=0。32 项源哈希匹配，15 个原 PID+creation 身份退出。
- [mode-B-02 原件](../android-promotion-identity-20261029/mode-B-02/execution-receipt.json)，SHA-256 c7ea262d03c50c7e559d12d5264d20e72163213b4028c305b943b5fa42d2c9a5：目标五文件运行。原始 XML 10/3/0/0 是 square BEFORE 同一方法被配置重试两次后的计数；唯一结果为 8 方法、7 通过、1 square BEFORE RED。6 个 HttpPageLoader integration 方法和 1 个真实 HTTP wiring 方法全绿。
- B-02 的 held-body HTTP 方法记录 2 requests、1 held response、2 closes、remaining=0，promoted 与 original requestId 相同。square BEFORE 记录四种旋转、4 次 stream open、4 次 decoder creation、8 次 region call、400 个 returned edge values；断言 0 对 4。清理健康记录为 owners=4、stream closes=4、decoder recycles=4、regions recycled=8、optionalWork=0、activeChildren=0。
- 已绑定的目标提交为 07114ecf015dd28c84e57b5782840bb1c6f75244（base 26bc794dcd1029b6d7a9ff8113563d6c36112d34）。五文件与目标 SHA-256：app/src/main/java/eu/kanade/tachiyomi/ui/reader/loader/HttpPageLoader.kt — 5aabf3f235f36c77335eddf90a6ac804f63b2dba8502e7111ab0c419e55b1f85；domain/src/commonMain/kotlin/mihon/domain/reader/scheduler/ReaderRequestScheduler.kt — 2dc85fd5eae4249ec2636e15d7e49585e5d8e8a91ed444c16fab1354a7ba4ccb；domain/src/commonMain/kotlin/mihon/domain/reader/scheduler/ReaderPageMaterializeRunner.kt — 188aa3a93a28d9cf3809927faf060c6fd0ba275485db47fa17ac4584e6a87c92；app/src/test/java/eu/kanade/tachiyomi/ui/reader/loader/HttpPageLoaderIntegrationTest.kt — 5befc5adaf34381f428b8e49ac281ca6824e33bc18d847a4363d542f1add8035；app/src/test/java/eu/kanade/tachiyomi/ui/reader/loader/ReaderPageFactProductionWiringTest.kt — 67f4e3043916acf0c4283687a845faa7abdd8e31d9d3631e9fd275f04116f991。B-02 记录 34 个源哈希匹配、sourceDiffMatch=true；29 个原 PID+creation 身份均退出。A 反事实运行后 loader 已恢复为目标 5aab SHA，shared scheduler/runner 与两测试均保持最小包目标字节。
- 运行范围是 Android app JVM/Robolectric 单元测试与 MockWebServer，不含实体设备、发布验收或 CP1 整体采用。HTTP 次数与测试回调数量不等于实际网络吞吐、用户耗时或综合性能结论。Android square独立GREEN另见[单方法回执](../square-sampling-20261029/platform-green-android-01/execution-receipt.json)，不改变本A/B原始8个唯一方法记录。
