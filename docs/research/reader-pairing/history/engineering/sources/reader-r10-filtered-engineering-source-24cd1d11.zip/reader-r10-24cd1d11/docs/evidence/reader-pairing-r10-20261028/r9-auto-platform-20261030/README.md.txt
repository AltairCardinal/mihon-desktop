# 固定R9：真实AUTO成本口及恢复/呈现全程工作

基线HEAD `f1dfd5951f8693896f34b4273dba6884faf4eb82`。原R10工作树不改生产代码；以固定 `3a5af9f9c4674f0cc3eeb43136d0db0b170bb0ec` 的48份domain reader、92份Desktop reader/UI/TestMode及1份原Java适配器构成隔离闭包。其余依赖沿当前R10，**不是整个旧R9仓库重新验收**。两个测试源仅编译到TMP，旧ENABLED方法、旧7成本方法、原64 UI、原176/50均未重跑。

## 结论与实际范围

唯一新方法最终fresh **1/0/0/0**：实际Factory产生Ready及编码引用，原Model成本检查口在冷缓存给true、兼容暖缓存给false；AUTO冷态首次attempt/adopt各1、首次work243，暖态首次attempt/adopt均0。没有注入requiresOriginalDecode常量或用allComputed替代平台成本。

| 新独立runtime | 暖缓存预置FULL | 恢复FULL | 呈现FULL | 所计pipeline FULL合计 | FULL读取API字节 |
|---|---:|---:|---:|---:|---:|
| 官方OFF / cold | 0 | 2 | 0 | 2 | 4483 |
| AUTO / cold | 0 | 0 | 2 | 2 | 4483 |
| AUTO / warm | 2 | 0 | 0 | 2 | 4483 |

三臂prefix读取均0，同为页22 RIGHT/23 LEFT，保留真实FULL asset leases时走原合同的owner capture/prepare/report，scope/background/inFlight/cache/resident/content leases健康均正常。cold成本口观察2次true、warm6次false，查询期间所计opens/decode增量全部0。**恢复0不等于总物化减少：OFF-cold与AUTO-cold的pipeline FULL调用和编码读取API字节差均0。** 此处只证明阶段移动，不宣称速度、物理I/O或原100ms收益。

`firstStrongWork=243`只属初次尝试，不是最终全部kernel或CPU总成本；hint次数也不等于采用次数。没有CPU计时主张或新性能采样。AUTO策略功能按预期工作，但本受控场景没有减少总FULL的采用依据，保留研究/合同，不回移旧Strong到当前R10或擅改默认。

## 忠实输入与新runtime边界

原capture缺Ready/encodedRef/attempt/provenance、FULL cache及全局Entry/cleanup状态；旧hydrator又未传成本回调，AUTO默认null。因此旧attempts0不是生产成本拒绝，历史AUTO仍UNKNOWN。本批采用新受控runtime，保留原owner证据的cold memo/history投影，不恢复旧会话。

原64页CBZ的执行绑定SHA为 `4a72a9ea01e853b9ced5a5dad2d19b2b03f52a63987ee32a6afc6f9d800943dc`。原临时CBZ与22–24 encoded文件已不存在；按实际冻结Main源 `78480c36…20578b143` 与plan `cda61474…da736e59` 重建后，23724字节与原回执/output manifest SHA完全一致。root独核两原件SHA、64 PNG/CRC及字节同一，未以40页writer替代。旧fixture audit的2488源SHA不绑定该实际运行，保持原件并在恢复回执纠正适用范围。一次javac启动参数错误只输出usage/exit2，修正后编译及重建exit0；这不是产品测试或新采样。

Factory对CBZ先给opaque descriptors，不像旧40页目录fixture直接全部Ready。setup在同一20秒总窗口内经原`Session.scheduleViewportWithoutProgress`逐页调度真实编码物化，再恢复anchor23及原all64Ready护栏；不注FakeReady、不延时。每臂64次setup调度单列，不当作恢复节省。Factory CBZ物化/物理解压I/O未计；所计pipeline读取来自其实际抽出的同payload PNG。4483字节也等于原CBZ的022/023 PNG payload大小之和，不代表磁盘或网络字节。

新Model的generation/page IDs/content投影与captured owner严格相等，不重写版本；从真实Model原session取得其成本接口方法引用，再供恢复owner使用，Model绑定当前owner后执行原检查。完整FULL键由实际Ready page的ref/attempt/provenance构造，warm原Skia decoder物化22/23，cold保持空cache。cost wrapper仅记录并原样返回真实hint。原publisher合同Semaphore2及语义ticket路线沿既有Factory合同，不借此证明全局资源容量或默认自然UI；没有Native scene像素/global Γ验收。

## 五次实际执行与失败闭合

| run | 实际方法 | 终态及原因 | 源/diff匹配 | 原PID+creation退出 |
|---|---|---|---:|---:|
| compile-01 | 0 | INVALID：隔离Kotlin闭包漏原Java BodySource | 1000 | 9 |
| compile-02 | 0 | PASSED：141源、Java实class输出及friend ABI编译通过 | 1005 | 9 |
| factory-green-01 | 1/1 | INVALID：Factory前helper把Set和相同内容List直接比较 | 1006 | 12 |
| factory-green-02 | 1/1 | INVALID：未调度CBZ剩余页，3臂在Ready setup等20秒超时 | 1006 | 11 |
| factory-green-03 | 1/0 | 有效新Factory成本合同，三臂及全部健康/单位通过 | 1006 | 12 |

前两次Factory失败不是有效产品RED或候选NoGo。第一次只将两处期望改为严格有序List（19..24及0..63）；第二次只补真实CBZ setup调度并保存失败时有限实际加载状态。真实成本、事实、断言护栏和预算均未放宽。原immutable expected-GREEN卡、XML、log、源码快照原样保留；invalid collector只在已核指定XML SHA及明确失败类型后，在内存取消GREEN期望核对，收据仍记录实际1/1，不改原卡/计数、不伪造retry。

Java补充为原blob `4ebcf4878230bcc96e3c9f96a8f999a7db84e5c6`、1274字节、SHA `8f1e80bf…fb5c3c4`，不是新造stub；Kotlin/Java编译均用该固定源，真实class SHA `385a783a…e6d4c97` 并显式加入测试runtime。旧140源/manifest和compile01原件未改。旧48 domain jar保持 `5b3effb1…e1f7c3ef`，Gradle实际执行了所需domain compile任务，jar为UP-TO-DATE；没有重跑域测试。

全程原control/中央锁/guard串行，运行期间HEAD和被测源码冻结，全部原身份退出后才变更。compile薄入口仅清desktop-focused默认suite18 filters，资源字段逐字不变、拒绝Test/fullScope；实际测试则原runner加唯一selector。job5120/process4096、Gradle1280/512、test512、2400秒不变；五次sampleErrors全0且无fault。最终峰job2737.15/process1238.86MiB。app-desktop无Spotless任务，只核源/维护文本窄diff，未扩大模块/仓库/原50测试。

## 原件与复算

- [root独审与计数](root-review.json)、[独立原件复算](independent-summary.json)逐一核五收据、raw复制SHA、fresh最终XML及三arm汇总。最终XML SHA `975a1ec4…e2da26b9`，与前次 `d6700fa6…9c180291` 不同；对应[有效收据](factory-green-03/execution-receipt.json)。
- [最终被测源码/输入ZIP](final-tested-inputs.zip)415620字节，SHA `7bfbc0fe6491ca08c4e1f8f1bfe563c50fe1457bbb01edb09243a0130b9294dd`；[逐项清单](final-tested-manifest.json)含141 production、2 test、原输入、补充/初始化与恢复证明。最终Test `64fd1d83…deac922e`、hydrator `5c4438a8…5e2beb0`；不用早期draft/handoff中的旧SHA追认运行。
- compile01/02原source ZIP保存各自输入，最终旧domain jar的可复算副本见compile02 ZIP，额外Java bytecode见factory01 ZIP。factory02保存helper差异、factory03保存最后test差异。旧原件不覆盖、不格式化raw/XML/CLI日志；最终归档成员逐SHA回读。
- 重现需在原R10树按各argv/固定输入与init执行，经同中央串行/guard且使用新key；本批不自动再跑已通过方法。Owner字段只作测试投影，不是生产策略或真实UI状态注入方案。

## 下一项与未完成边界

R10-02实际AUTO成本口和所计物化出口得到有限闭合；历史runtime不恢复、默认真实UI采用不能由hydrate合同证明。R10-03下一最小真实操作是同版原Factory→Model→ReaderViewport→ImageComposeScene、同64 CBZ/固定合法历史、默认AUTO/动画及真实endpoint像素护栏，无owner事实注入。若历史未采用，记录本次未见，不自动换历史取绿。

旧Scene inspector含clipped bounds推scale/coerce坐标，不能用于全部中间Γ；本版同render geometry/command消费活性仍需独立真实合同，不把当前R10新接口硬搬回去。原176仍受128门槛排除，原100ms未达。03全局/最短性、04物理层、05在线净成本、06实际调度、07/09及原Goal其余出口保持未完成，不把本单法或总FULL为0差当整个Goal完成。
