# R10 分阶段有限模型验证（2026-10-29）

本轮仅新增分析工具 API，未修改产品实现、既有 19 项 API 或 CLI。新 9 项测试是接管前已有 WIP，本轮未重写。真实 RED 为缺少 `analyze_phase_schedule` / `validate_phase_schedule` 导致 9 个错误，不能称为产品行为 RED。

## 验证

- `phase-red.log` / `.json`：新类实际发现 9、错误 9，退出 1，源 SHA 与交接一致。
- `phase-green.log` / `.json`：同类发现 9、通过 9，退出 0；小模型交叉检查含 18 个显式容量/服务组合。
- `bounds-regression.log` / `.json`：仅受影响的旧 `BoundsTests` 发现 19、通过 19，退出 0；不代表完整脚本 suite 或产品测试。
- `boundary-checks.json`：搜索截断有合法 incumbent 时仍无 optimum；6 个给定非法排程分别覆盖依赖、ready_at、初始运行重排、horizon、缺行、UNKNOWN remaining。均拒绝，未发现新实现反例，不追加无依据红绿循环。另在内存中编译两个 Python 文件，无 pyc。
- `final-check.json`：最终源 SHA、HEAD 与格式检查；格式退出 0。所有 Python 子进程采用 UTF-8 与 `PYTHONDONTWRITEBYTECODE=1`，同步等待退出；无后台任务。

## 模型边界

必须显式提供容量，缺容量、未知容量/服务或不完整依赖返回 UNKNOWN，不填 0；非法 DAG/hold 引用抛出 ValueError。每个模型含 1–8 phase，horizon 为 0–64 的整数，节点预算默认 200000。初始运行 phase 固定在原点，以明确 remaining 表示未来不可抢占工作。取消仅为意图，不减少剩余服务或持有区间。

hold 从 start_phase 开始到 end_phase 退出，跨 phase 必须有依赖可达；包括中间等待，按半开区间统计，不把未知退出当释放。求解器为整数开始时间递归枚举及事件式资源检查；检查器不调用求解器，只检查给定排程并独立逐 tick 检查占用。外部 Cartesian oracle 不调用二者搜索/容量助手。

selected target 只改变优化目标；所有 phase 仍须在 horizon 内完成。返回 target_completion 与该见证的 physical_exit（全部 phase drain）分开，后者不是独立最优值。枚举包含主动空闲以等待 future ready_at。搜索被截断时保留合法 incumbent，`optimum=None`、`EXHAUSTIVENESS=false`；没有 incumbent 不等于无解。完整搜索或目标下界剪枝仅证明声明有限整数时间域中的条件最优或有限域无解。

真实容量/服务权重与生产轨迹尚未绑定；`production_reachability=UNDETERMINED`。不证明产品可达、连续时间最优、原 50 样本改善 100ms 或生产无解。未运行 Gradle、JVM、benchmark、联网或窗口；未修改冻结文件、HEAD、暂存或提交。

## 集中审查修复 revision1

审查发现 dependencies_complete 的字符串 UNKNOWN / 数字 1 会因 truthiness 被错误认证，缺失 ready_at 会被隐式补 0；非 bool initially_running 会被解释成实际状态。已先添加 3 个方法保存 `revision1-red.log/.json`：实际发现 3，8 个断言失败及 1 个 None ready_at 错误。它们是新分析器的真实语义 RED，不是产品性能 RED。

最小修复仅更改新 API 模型校验及 UNKNOWN 诊断：dependencies_complete 仅 literal True 可认证；显式 ready_at 缺失/None 返回 UNKNOWN，checker 不认证；initially_running 缺字段默认 False，提供非 bool 值抛出 ValueError。`revision1-green.log/.json` 发现并通过 12 方法（原 9 + 新 3），包含全部原 oracle。`revision1-final.json` 保存新源 SHA、内存语法 2/2 和格式退出 0。旧 19 项实现及 CLI 未受修改，复用前述通过证据，未重跑。原 RED/GREEN/final-check 原件保持不变，最终身份以 revision1-final 为准。

## Tested source byte archive

tested-python-source-bytes.zip has SHA-256 8e27c0de62af6bb6792a6133fd061de0a80a1534b1a58c440cd4c281fb6a60b0 and contains exactly these two entries, read back and verified byte-for-byte against the current tested sources:

- scripts/research/reader_pairing_r10_bounds.py — SHA-256 78c555092c6fe0acc53cef3ff38168b22323c22b1c6bc80ef1775cbc1d1971d7
- scripts/tests/reader-pairing-r10-bounds-test.py — SHA-256 9d6fd980c4e7871a7e3fda7b44491fb5aed7cd2ab3c3b2baff7905b57f86e073

Both archived source byte streams use CRLF. The archive preserves the exact tested bytes before any later Git line-ending normalization. LF-only normalization changes line endings; it does not change the mathematical behavior described above. This archival step reuses the recorded 12-method and 19-method validation results; no tests were rerun. These bounded-model results still require explicit capacity, service, and complete dependency inputs; UNKNOWN remains unknown, cancellation does not release held work, and the evidence does not establish production reachability or runtime behavior.

## Git LF源码映射（2026-10-30）

仓库源码按LF归档。两份Python只把CRLF转换为LF，Python AST（忽略位置字段）逐项完全一致；复用既有12/19及root192结果，不重复运行测试。受测原字节已在上述ZIP保全，原root-review中的78c555/9d6fd9仍指该受测版本；当前LF文件SHA及严格映射见[canonical-source-map-20261030.json](canonical-source-map-20261030.json)。
